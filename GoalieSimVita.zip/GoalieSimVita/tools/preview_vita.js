// Runs the Vita build's JavaScript (font_metrics + vita_shim + game) in Node with fake native
// functions, plays a scripted sequence of touches, and dumps what the Vita would draw.
// Usage: node tools/preview_vita.js  -> writes preview_out/frames.json, then
//        python3 tools/render_frames.py  -> preview_out/*.png
// Handy for checking UI changes without copying a VPK to the console.
const vm = require('vm'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(__dirname, '..');
const OUT = path.join(ROOT, 'preview_out'); fs.mkdirSync(OUT, { recursive: true });
const html = fs.readFileSync(path.join(ROOT, 'web/goalie.html'), 'utf8');
const game = html.slice(html.indexOf('<script>') + 8, html.lastIndexOf('</script>'));
let clock = 1000, frameCmds = [], files = {}, touches = [], back = [], buttons = 0;
const sb = {
  Math, JSON, Object, Array, String, Number, Date, Float32Array, Uint32Array, RegExp, Error, Map, Set, parseInt, parseFloat, isFinite, isNaN,
  __now: () => clock,
  __log: s => console.log('[log]', s),
  __readFile: p => (p in files ? files[p] : null),
  __writeFile: (p, s) => { files[p] = s; return true; },
  __removeFile: p => { delete files[p]; },
  __drawTris: (pb, cb, n) => { frameCmds.push({ t: 'tri', p: Array.from(new Float32Array(pb).slice(0, n * 2)), c: Array.from(new Uint32Array(cb).slice(0, n)) }); },
  __drawGlyphs: (b, n, col) => { frameCmds.push({ t: 'gly', g: Array.from(new Float32Array(b).slice(0, n * 7)), c: col }); },
  __input: () => { const a = [touches.length]; touches.forEach((t, i) => a.push(t.id ?? i, t.x, t.y)); a.push(back.length); back.forEach((t, i) => a.push(i, t.x, t.y)); a.push(buttons); return a; },
};
sb.globalThis = sb;
vm.createContext(sb);
for (const f of ['vita/js/font_metrics.js', 'vita/js/vita_shim.js']) vm.runInContext(fs.readFileSync(path.join(ROOT, f), 'utf8'), sb, { filename: f });
vm.runInContext(game, sb, { filename: 'game.js' });
const run = s => vm.runInContext(s, sb);
const frames = [];
function step(n = 1, capture) { for (let i = 0; i < n; i++) { frameCmds = []; clock += 1000 / 60; sb.__vitaFrame(); } if (capture) frames.push({ name: capture, cmds: frameCmds }); }
function tap(x, y) { touches = [{ id: 0, x, y }]; step(2); touches = []; step(2); }
function tapBtn(id) { const b = JSON.parse(run(`JSON.stringify((btns.find(b=>b.id==='${id}'))||null)`)); if (!b) throw new Error('button not on screen: ' + id); tap(b.x + b.w / 2, b.y + b.h / 2); }
step(5, 'modes');
tapBtn('mode:pro'); step(2, 'slots');
tapBtn('slot:0'); step(2, 'name');
for (const c of 'VITA') tapBtn('key:' + c);
tapBtn('namego'); step(2, 'difficulty');
tapBtn('diff:0'); step(30, 'draft');
run("C.draft.done=true;screen='main'"); step(2, 'hub');
tapBtn('nav:upg'); step(2, 'upgrades');
tapBtn('nav:main'); tapBtn('nav:stand'); step(2, 'league');
tapBtn('nav:main');
tapBtn('play'); step(80);
touches = [{ id: 0, x: 300, y: 400 }, { id: 1, x: 650, y: 420 }]; step(40, 'gameplay');
back = [{ x: 200, y: 300 }]; step(2); back = []; step(30, 'pad_flat_rear_touch');
touches = []; step(600);
let guard = 0; while (run('state') === 'play' && guard++ < 6000) step(1);
step(2, 'result');
fs.writeFileSync(path.join(OUT, 'frames.json'), JSON.stringify(frames));
console.log('frames:', frames.map(f => f.name + '(' + f.cmds.length + ' draws)').join(', '));
console.log('save files:', Object.keys(files).join(', '), '| game state:', run('state'), run('screen'));

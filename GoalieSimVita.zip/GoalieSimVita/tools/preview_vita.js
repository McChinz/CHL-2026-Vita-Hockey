// Runs the Vita build's JavaScript (font_metrics + vita_shim + game) in Node with fake native
// functions, plays a scripted sequence of touches, and dumps what the Vita would draw.
// Usage: node tools/preview_vita.js  -> writes preview_out/frames.json, then
//        python3 tools/render_frames.py  -> preview_out/*.png
// Handy for checking UI changes without copying a VPK to the console.
const vm = require('vm'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(__dirname, '..');
const OUT = path.join(ROOT, 'preview_out'); fs.mkdirSync(OUT, { recursive: true });
const html = fs.readFileSync(path.join(ROOT, 'web/goalie.html'), 'utf8');
const game = html.slice(html.indexOf('<script>') + 8, html.lastIndexOf('</script>'));
let clock = 1000, frameCmds = [], files = {}, touches = [], back = [], buttons = 0, sticks = [128, 128, 128, 128];
const sb = {
  Math, JSON, Object, Array, String, Number, Date, Float32Array, Uint32Array, RegExp, Error, Map, Set, parseInt, parseFloat, isFinite, isNaN,
  __now: () => clock,
  __log: s => console.log('[log]', s),
  __readFile: p => (p in files ? files[p] : null),
  __writeFile: (p, s) => { files[p] = s; return true; },
  __removeFile: p => { delete files[p]; },
  __drawTris: (pb, cb, n, dx = 0, dy = 0, k = 1) => { const p = Array.from(new Float32Array(pb).slice(0, n * 2)); for (let i = 0; i < p.length; i += 2) { p[i] = p[i] * k + dx; p[i + 1] = p[i + 1] * k + dy; } frameCmds.push({ t: 'tri', p, c: Array.from(new Uint32Array(cb).slice(0, n)) }); },
  __drawGlyphs: (b, n, col, dx = 0, dy = 0, k = 1) => { const g = Array.from(new Float32Array(b).slice(0, n * 7)); for (let i = 0; i < g.length; i += 7) { g[i] = g[i] * k + dx; g[i + 1] = g[i + 1] * k + dy; g[i + 6] *= k; } frameCmds.push({ t: 'gly', g, c: col }); },
  __input: () => { const a = [touches.length]; touches.forEach((t, i) => a.push(t.id ?? i, t.x, t.y)); a.push(back.length); back.forEach((t, i) => a.push(i, t.x, t.y)); a.push(buttons, ...sticks); return a; },
};
sb.globalThis = sb;
vm.createContext(sb);
for (const f of ['vita/js/font_metrics.js', 'vita/js/vita_shim.js']) vm.runInContext(fs.readFileSync(path.join(ROOT, f), 'utf8'), sb, { filename: f });
vm.runInContext(game, sb, { filename: 'game.js' });
const run = s => vm.runInContext(s, sb);
const frames = [];
function step(n = 1, capture) { for (let i = 0; i < n; i++) { frameCmds = []; clock += 1000 / 60; sb.__vitaFrame(); } if (capture) frames.push({ name: capture, cmds: frameCmds }); }
sb.__pad = undefined;
function tap(x, y) { touches = [{ id: 0, x, y }]; step(2); touches = []; step(2); }
function tapBtn(id) { const b = JSON.parse(run(`JSON.stringify((btns.find(b=>b.id==='${id}'))||null)`)); if (!b) throw new Error('button not on screen: ' + id); tap(b.x + b.w / 2, b.y + b.h / 2); }
// days with no game on the calendar have no PLAY button: start the game directly then
function playBtn() { if (run("btns.some(b=>b.id==='play')")) tapBtn('play'); else { run('start()'); step(2); } }
step(5, 'modes');
tapBtn('mode:pro'); step(110, 'slots');
tapBtn('slot:0'); step(2, 'name');
for (const c of 'VITA') tapBtn('key:' + c);
tapBtn('namego'); step(2); tapBtn('num:ok'); step(2, 'position'); tapBtn('pos:G'); step(2, 'difficulty');
tapBtn('diff:0'); step(30, 'draft');
run("C.draft.done=true;screen='main'"); step(2, 'hub');
tapBtn('nav:upg'); step(2, 'upgrades');
tapBtn('nav:main'); tapBtn('nav:stand'); step(2, 'league');
tapBtn('nav:main');
playBtn(); step(80);
touches = [{ id: 0, x: 300, y: 400 }, { id: 1, x: 650, y: 420 }]; step(40, 'gameplay');
touches = []; step(2);
sticks = [40, 40, 230, 60]; step(40, 'sticks_glove_upleft_blocker_upright');
console.log('hands after sticks', run('JSON.stringify({L:[hands.L.x|0,hands.L.y|0],R:[hands.R.x|0,hands.R.y|0]})'));
sticks = [128, 128, 128, 128]; step(40);
buttons = 1; step(1); buttons = 0; step(30, 'L_button_pad_flat');
console.log('pad L after L button', run('pad.L.f.toFixed(2)'));
buttons = 4; step(1); buttons = 0; step(5, 'paused');
console.log('paused?', run('paused'));
const t0 = run('timeLeft'); step(60); console.log('clock frozen while paused:', run('timeLeft') === t0);
buttons = 4; step(1); buttons = 0; step(5);
console.log('resumed?', !run('paused'));
step(600);
let guard = 0; while (run('state') === 'play' && guard++ < 6000) step(1);
step(2, 'result');
// pause + quit match
run("state='menu';screen='main';paused=false"); step(2); playBtn(); step(90); console.log('before pause:', run('state'), run('paused'), run('screen')); buttons = 4; step(1); buttons = 0; step(3); console.log('after START:', run('state'), run('paused'), run('JSON.stringify(btns.map(b=>b.id))'), run('readyT'), run('goalPause')); if (run('state') === 'play') { if (!run('paused')) run('togglePause()'); step(1); tapBtn('quit'); } step(3, 'after_quit');
console.log('after quit:', run('state'), run('screen'), 'record', run("C.L[C.me].w+'-'+C.L[C.me].l"));
// ---- forward career (top-down) driven with the analog sticks and buttons
run("slot=1;mode='pro';newCareer('VITA',1,'F');C.draft.done=true;screen='main';state='menu';lockUntil=0"); step(3, 'forward_hub');
playBtn(); step(70, 'forward_faceoff');
for (let i = 0; i < 900; i++) {
  const s = JSON.parse(run("(()=>{if(!SK)return 'null';const u=SK.user,P=SK.puck,lay=skLayout(),a=skW2S(lay,u.x,u.y),b=skW2S(lay,P.x,P.y),n=skW2S(lay,attackX(0),RK.cy);return JSON.stringify({own:P.owner===u,a,b,n,d:Math.hypot(attackX(0)-u.x,RK.cy-u.y)})})()"));
  if (!s) break;
  const t = s.own ? s.n : s.b, dx = t.x - s.a.x, dy = t.y - s.a.y, m = Math.hypot(dx, dy) || 1;
  sticks = [128 + dx / m * 120, 128 + dy / m * 120, 128, 128];
  if (s.own && s.d < 30) { const ex = s.n.x - s.a.x, ey = s.n.y - s.a.y, em = Math.hypot(ex, ey) || 1; sticks[2] = 128 + ex / em * 125; sticks[3] = 128 + ey / em * 125; if (i % 40 === 39) { sticks[2] = 128; sticks[3] = 128 } }
  buttons = (i % 97 === 0) ? 16 : 0;
  step(1, i === 300 ? 'forward_play' : (s.own && s.d < 30 && sticks[2] !== 128 && !frames.some(f => f.name === 'forward_aim')) ? 'forward_aim' : undefined);
}
sticks = [128, 128, 128, 128]; buttons = 0;
console.log('forward game:', run("SK?JSON.stringify({score:SK.T[0].score+'-'+SK.T[1].score,per:SK.per,clock:SK.clock|0,me:SK.me}):'over'"));
fs.writeFileSync(path.join(OUT, 'frames.json'), JSON.stringify(frames));
console.log('frames:', frames.map(f => f.name + '(' + f.cmds.length + ' draws)').join(', '));
console.log('save files:', Object.keys(files).join(', '), '| game state:', run('state'), run('screen'));

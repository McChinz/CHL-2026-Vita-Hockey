#!/usr/bin/env python3
"""Writes font.rgba (raw RGBA of vita/assets/font.png) for the native PC test build (cpp/, HOST=ON)."""
import os
from PIL import Image
HERE = os.path.dirname(os.path.abspath(__file__))
im = Image.open(os.path.join(HERE, '..', 'vita', 'assets', 'font.png')).convert('RGBA')
open('font.rgba', 'wb').write(im.tobytes())
print('font.rgba', im.size)

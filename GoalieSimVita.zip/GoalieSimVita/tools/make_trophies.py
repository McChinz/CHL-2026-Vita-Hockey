#!/usr/bin/env python3
"""Builds the CHL 2026 trophy pack: vita/sce_sys/trophy/NPWR99626_00/TROPHY.TRP

The trophy list is read straight from web/goalie.html (the `const TRP=[...]` table), so the game
and the pack always agree on ids. The pack is unencrypted (TROPCONF.SFM / TROP.SFM / PNG icons),
which is what the NoTrpDrm plugin lets homebrew use.

KEEP THE ID: the trophy list on the console belongs to NP_COMM_ID. Changing it makes a second list.
Settle the trophies before you start earning them: adding / removing / reordering later can confuse
an existing list. Fixing names, descriptions or icons is fine.

Usage: python3 tools/make_trophies.py      (needs Pillow: pip install pillow)
"""
import io, os, re, struct, json
from PIL import Image, ImageDraw, ImageFont

NP_COMM_ID = 'NPWR99626_00'          # made-up id, high enough not to clash with a real game
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HTML = os.path.join(ROOT, 'web', 'goalie.html')
OUT = os.path.join(ROOT, 'vita', 'sce_sys', 'trophy', NP_COMM_ID, 'TROPHY.TRP')
FONT = os.path.join(ROOT, 'tools', 'DejaVuSans-Bold.ttf')

# nicer spellings for the console than the in-game font can show
PRETTY = {'A Little Sore...': 'A Little Sore…'}


def read_list():
    src = open(HTML, encoding='utf-8').read()
    body = src[src.index('const TRP=['):]
    body = body[:body.index(']];') + 2]
    out = []
    for m in re.finditer(r"\[(\d+),'([PGSB])',(\"(?:[^\"\\]|\\.)*\"|'(?:[^'\\]|\\.)*'),('(?:[^'\\]|\\.)*'|\"(?:[^\"\\]|\\.)*\")\]", body):
        un = lambda q: q[1:-1].replace("\\'", "'").replace('\\"', '"')
        name = un(m.group(3))
        out.append((int(m.group(1)), m.group(2), PRETTY.get(name, name), un(m.group(4))))
    out.sort()
    assert [t[0] for t in out] == list(range(len(out))), 'trophy ids must be 0..n-1'
    assert out[0][1] == 'P', 'trophy 0 is the platinum'
    return out


def esc(t):
    return t.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')


def sfm(trophies, with_text=True):
    x = ['<?xml version="1.0" encoding="UTF-8"?>',
         '<!--This file is created by CHL 2026 tools/make_trophies.py-->',
         '<trophyconf version="1.1" platform="vita">',
         '<npcommid>%s</npcommid>' % NP_COMM_ID,
         '<trophyset-version>01.00</trophyset-version>',
         '<parental-level license-area="default">0</parental-level>',
         '<title-name>CHL 2026</title-name>',
         '<title-detail>CHL 2026 trophies</title-detail>']
    for tid, g, name, det in trophies:
        pid = '-1' if g == 'P' else '000'
        x.append('<trophy id="%03d" hidden="no" ttype="%s" pid="%s">' % (tid, g, pid))
        if with_text:
            x.append('<name>%s</name>' % esc(name))
            x.append('<detail>%s</detail>' % esc(det))
        x.append('</trophy>')
    x.append('</trophyconf>')
    return ('\n'.join(x) + '\n').encode('utf-8')


COL = {'P': (165, 243, 252), 'G': (255, 213, 74), 'S': (203, 213, 225), 'B': (217, 119, 6)}


def png(im):
    b = io.BytesIO(); im.save(b, 'PNG', optimize=True); return b.getvalue()


def icon(tid, g, name):
    S = 128
    im = Image.new('RGB', (S, S), (11, 18, 32))
    d = ImageDraw.Draw(im)
    for y in range(S):                     # navy gradient
        k = y / S
        d.line([(0, y), (S, y)], fill=(int(15 + 20 * k), int(23 + 18 * k), int(42 + 30 * k)))
    c = COL[g]
    d.ellipse([10, 10, S - 10, S - 10], outline=c, width=6)
    # trophy cup
    d.polygon([(40, 34), (88, 34), (82, 66), (72, 74), (56, 74), (46, 66)], fill=c)
    d.rectangle([60, 74, 68, 88], fill=c)
    d.rectangle([48, 88, 80, 96], fill=c)
    d.arc([28, 36, 50, 62], 90, 270, fill=c, width=5)
    d.arc([78, 36, 100, 62], 270, 90, fill=c, width=5)
    f = ImageFont.truetype(FONT, 15)
    t = '%02d' % tid if g != 'P' else 'CHL'
    w = d.textlength(t, font=f)
    d.text(((S - w) / 2, 98), t, font=f, fill=(255, 255, 255))
    return png(im)


def set_icon():
    im = Image.new('RGB', (320, 176), (11, 18, 32))
    d = ImageDraw.Draw(im)
    for y in range(176):
        k = y / 176
        d.line([(0, y), (320, y)], fill=(int(12 + 30 * k), int(20 + 10 * k), int(40 + 20 * k)))
    d.rectangle([0, 150, 320, 158], fill=(200, 16, 46))
    f1 = ImageFont.truetype(FONT, 58); f2 = ImageFont.truetype(FONT, 22)
    for t, f, y, col in [('CHL', f1, 22, (255, 255, 255)), ('2026', f2, 96, (255, 213, 74))]:
        w = d.textlength(t, font=f); d.text(((320 - w) / 2, y), t, font=f, fill=col)
    return png(im)


def trp(files):
    """Unencrypted TRP container: 0x40 header, 0x40 per entry, data padded to 16 bytes (all big-endian)."""
    n = len(files)
    pos = 0x40 + 0x40 * n
    table, data = b'', b''
    for name, blob in files:
        pad = (-len(blob)) % 16
        flag = 1 if name.endswith('.SFM') else 0
        table += name.encode('ascii').ljust(32, b'\0') + struct.pack('>QQI', pos, len(blob), flag) + b'\0' * 12
        data += blob + b'\0' * pad
        pos += len(blob) + pad
    head = b'\xDC\xA2\x4D\x00' + struct.pack('>IQIII', 1, pos, n, 0x40, 0) + b'\0' * 36
    assert len(head) == 0x40
    return head + table + data


def main():
    T = read_list()
    files = [('TROPCONF.SFM', sfm(T)), ('TROP.SFM', sfm(T)), ('ICON0.PNG', set_icon())]
    files += [('TROP%03d.PNG' % tid, icon(tid, g, n)) for tid, g, n, _ in T]
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    open(OUT, 'wb').write(trp(files))
    pts = {'P': 180, 'G': 90, 'S': 30, 'B': 15}
    print('wrote', OUT, '-', len(T), 'trophies',
          json.dumps({g: sum(1 for t in T if t[1] == g) for g in 'PGSB'}), 'points', sum(pts[t[1]] for t in T))


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""make_trophies.py - builds CHL 2026's trophy pack for the PS Vita's own Trophies app.

Writes vita/sce_sys/trophy/NPWR90226_00/TROPHY.TRP: an unsigned TRP (version 2) holding
TROPCONF.SFM, TROP.SFM, ICON0.PNG (320 x 176) and one 240 x 240 picture per trophy (TROP000.PNG ...).
The console only accepts an unsigned pack with Rinnegatamante's NoTrpDrm plugin installed.

The list here must match the ids in cpp/src/trophy.h. Run from the repo root:  python3 tools/make_trophies.py
(needs Pillow; the output is committed, so the cloud build doesn't run this)."""
import hashlib, io, os, struct
from PIL import Image, ImageDraw, ImageFont

COMMID = 'NPWR90226_00'
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'vita', 'sce_sys', 'trophy', COMMID)

# id, grade (P platinum, G gold, S silver, B bronze), hidden, name, detail, picture (a glyph for the icon)
TROPHIES = [
    (0, 'P', False, 'CHL Legend', 'Earn every other trophy in CHL 2026.', 'cup'),
    (1, 'B', False, 'Opening Night', 'Play your first game in Be a Pro.', 'skate'),
    (2, 'B', False, 'Light the Lamp', 'Score your first goal in Be a Pro.', 'lamp'),
    (3, 'S', False, 'Hat Trick', 'Score three goals in one Be a Pro game.', 'hat'),
    (4, 'S', False, 'Playmaker', 'Pick up three assists in one Be a Pro game.', 'pass'),
    (5, 'B', False, 'Draft Day', 'Hear your name called at the draft.', 'pen'),
    (6, 'G', False, 'The Big League', 'Play a game in the top league.', 'star'),
    (7, 'G', False, 'Century', 'Reach 100 career points in Be a Pro.', '100'),
    (8, 'B', False, 'One of the Boys', "Complete a teammate's challenge.", 'hands'),
    (9, 'S', False, 'Inseparable', 'Reach full chemistry with a teammate.', 'heart'),
    (10, 'B', False, 'New Digs', 'Move into a bigger apartment.', 'house'),
    (11, 'B', False, 'Player One', 'Play a game on the CHL Station.', 'pad'),
    (12, 'B', False, 'Pack Rat', 'Open your first Hockeymon pack.', 'pack'),
    (13, 'S', False, 'Shiny', 'Own a holo or gold Hockeymon card.', 'gem'),
    (14, 'G', False, 'Full Binder', 'Own all 60 Hockeymon.', 'book'),
    (15, 'B', False, 'Natural', 'Get dealt a blackjack at the casino.', 'cards'),
    (16, 'S', False, 'High Roller', 'Win 10 times your bet or more on the slots.', '777'),
    (17, 'B', False, 'Franchise Player', 'Win a game in Ultimate Franchise.', 'shield'),
    (18, 'B', False, 'Quick Strike', 'Win a Quick Play game.', 'bolt'),
    (19, 'S', False, 'Brick Wall', "Win a game without letting the other team score.", 'wall'),
    (20, 'B', False, 'Looking Sharp', 'Create your pro in Be a Pro.', 'face'),
]
GRADE = {'P': ((190, 220, 255), (60, 90, 160)), 'G': ((255, 215, 90), (150, 100, 20)),
         'S': ((225, 230, 240), (110, 120, 140)), 'B': ((230, 160, 100), (120, 65, 30))}


def esc(s):
    return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace("'", '&apos;')


def sfm():
    L = ['<?xml version="1.0" encoding="UTF-8"?>', '<trophyconf version="1.1" platform="psp2">',
         '<npcommid>%s</npcommid>' % COMMID, '<trophyset-version>01.00</trophyset-version>',
         '<parental-level license-area="default">0</parental-level>', '<title-name>CHL 2026</title-name>',
         '<title-detail>Trophies for CHL 2026, a homebrew hockey game.</title-detail>']
    for i, g, hid, n, d, _ in TROPHIES:
        L.append('<trophy id="%03d" hidden="%s" ttype="%s" pid="%s"><name>%s</name><detail>%s</detail></trophy>'
                 % (i, 'yes' if hid else 'no', g, '-1' if g == 'P' else '000', esc(n), esc(d)))
    L.append('</trophyconf>')
    return ('\n'.join(L) + '\n').encode('utf-8')


def font(sz):
    for p in ('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', '/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf'):
        if os.path.exists(p):
            return ImageFont.truetype(p, sz)
    return ImageFont.load_default()


def glyph(d, kind, c, cx, cy, s):
    """a simple white symbol for the trophy, s ~ its half-size"""
    w = (255, 255, 255)
    if kind == 'cup':
        d.polygon([(cx - s * .55, cy - s * .7), (cx + s * .55, cy - s * .7), (cx + s * .4, cy + s * .05), (cx - s * .4, cy + s * .05)], fill=w)
        d.ellipse((cx - s * .4, cy - s * .2, cx + s * .4, cy + s * .25), fill=w)
        d.arc((cx - s * .85, cy - s * .6, cx - s * .3, cy - s * .05), 90, 270, fill=w, width=int(s * .1))
        d.arc((cx + s * .3, cy - s * .6, cx + s * .85, cy - s * .05), 270, 90, fill=w, width=int(s * .1))
        d.rectangle((cx - s * .08, cy + s * .2, cx + s * .08, cy + s * .55), fill=w)
        d.rectangle((cx - s * .4, cy + s * .55, cx + s * .4, cy + s * .72), fill=w)
    elif kind in ('100', '777'):
        f = font(int(s * (.9 if kind == '100' else .8)))
        d.text((cx, cy), kind, font=f, fill=w, anchor='mm')
    elif kind == 'star':
        import math
        pts = [(cx + s * (.75 if k % 2 == 0 else .3) * math.sin(math.pi * k / 5), cy - s * (.75 if k % 2 == 0 else .3) * math.cos(math.pi * k / 5)) for k in range(10)]
        d.polygon(pts, fill=w)
    elif kind == 'lamp':
        d.ellipse((cx - s * .45, cy - s * .75, cx + s * .45, cy + s * .15), fill=(255, 80, 60))
        d.rectangle((cx - s * .5, cy + s * .1, cx + s * .5, cy + s * .35), fill=w)
        for a in (-1, 0, 1):
            d.line((cx + a * s * .6, cy - s * .85, cx + a * s * .85, cy - s * 1.0), fill=w, width=int(s * .08))
    elif kind == 'hat':
        d.rectangle((cx - s * .4, cy - s * .6, cx + s * .4, cy + s * .2), fill=w)
        d.rectangle((cx - s * .75, cy + s * .2, cx + s * .75, cy + s * .35), fill=w)
        d.rectangle((cx - s * .4, cy - s * .05, cx + s * .4, cy + s * .08), fill=c)
    elif kind == 'wall':
        for r in range(4):
            for k in range(3):
                o = (r % 2) * s * .25
                x0 = cx - s * .75 + k * s * .5 + o
                d.rectangle((x0, cy - s * .6 + r * s * .32, x0 + s * .44, cy - s * .32 + r * s * .32), fill=w)
    elif kind == 'heart':
        d.ellipse((cx - s * .7, cy - s * .55, cx, cy + s * .1), fill=w); d.ellipse((cx, cy - s * .55, cx + s * .7, cy + s * .1), fill=w)
        d.polygon([(cx - s * .68, cy - s * .12), (cx + s * .68, cy - s * .12), (cx, cy + s * .7)], fill=w)
    else:   # a puck with the trophy's initial: every other one
        d.ellipse((cx - s * .7, cy - s * .2, cx + s * .7, cy + s * .45), fill=(20, 20, 25))
        d.rectangle((cx - s * .7, cy - s * .15, cx + s * .7, cy + s * .15), fill=(20, 20, 25))
        d.ellipse((cx - s * .7, cy - s * .48, cx + s * .7, cy + s * .2), fill=(55, 55, 65))
        f = font(int(s * .5)); d.text((cx, cy - s * .15), kind[:2].upper(), font=f, fill=w, anchor='mm')


def trophy_png(i, g, name, kind):
    S = 240; hi, lo = GRADE[g]
    im = Image.new('RGB', (S, S), (0, 0, 0)); d = ImageDraw.Draw(im)
    for y in range(S):   # a lit gradient in the grade's metal
        t = y / S; d.line((0, y, S, y), fill=tuple(int(hi[k] * (1 - t) + lo[k] * t) for k in range(3)))
    d.ellipse((30, 22, 210, 202), fill=tuple(int(v * .55) for v in lo))
    if kind not in ('cup', '100', '777', 'star', 'lamp', 'hat', 'wall', 'heart'):
        kind = ''.join(w[0] for w in name.split()[:2])   # a puck with the initials
    glyph(d, kind, tuple(int(v * .55) for v in lo), 120, 112, 70)
    d.rectangle((0, 196, S, S), fill=(12, 18, 32))
    f = font(19); d.text((120, 218), name.upper(), font=f, fill=(255, 255, 255), anchor='mm')
    b = io.BytesIO(); im.save(b, 'PNG'); return b.getvalue()


def icon0():
    src = Image.open(os.path.join(ROOT, 'vita', 'sce_sys', 'livearea', 'contents', 'bg.png')).convert('RGB')
    W, H = src.size; h = int(W * 176 / 320); top = max(0, (H - h) // 2)
    im = src.crop((0, top, W, top + h)).resize((320, 176), Image.LANCZOS)
    b = io.BytesIO(); im.save(b, 'PNG'); return b.getvalue()


def trp(files):
    """files: [(name, bytes)] -> an unsigned TRP v2: 64-byte header, 64-byte big-endian entries, data 16-byte aligned,
    SHA-1 of the whole file (with its own field zeroed) in the header"""
    n = len(files); off = 64 + 64 * n; ents = []; data = b''
    for name, b in files:
        pad = (-off) % 16; data += b'\0' * pad; off += pad
        ents.append(struct.pack('>32sQQI12s', name.encode(), off, len(b), 0, b'\0' * 12)); data += b; off += len(b)
    size = 64 + 64 * n + len(data)
    hdr = struct.pack('>IIQIII20s16s', 0xDCA24D00, 2, size, n, 64, 0, b'\0' * 20, b'\0' * 16)
    blob = bytearray(hdr + b''.join(ents) + data)
    blob[28:48] = hashlib.sha1(bytes(blob)).digest()
    return bytes(blob)


if __name__ == '__main__':
    conf = sfm(); files = [('TROPCONF.SFM', conf), ('TROP.SFM', conf), ('ICON0.PNG', icon0())]
    for i, g, hid, n, d, k in TROPHIES:
        files.append(('TROP%03d.PNG' % i, trophy_png(i, g, n, k)))
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, 'TROPHY.TRP'), 'wb') as f:
        f.write(trp(files))
    print('wrote', os.path.join(OUT, 'TROPHY.TRP'), len(TROPHIES), 'trophies')

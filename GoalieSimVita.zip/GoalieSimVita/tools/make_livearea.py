#!/usr/bin/env python3
"""Draws the Vita home-screen icon and LiveArea images (8-bit indexed PNGs, as the Vita requires).
Usage: python3 tools/make_livearea.py   (needs Pillow). Replace the PNGs with your own art any time,
just keep the sizes: icon0 128x128, bg 840x500, startup 280x158, and save them as 8-bit indexed PNG."""
import os
from PIL import Image, ImageDraw, ImageFont
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
SYS = os.path.join(ROOT, 'vita', 'sce_sys'); LA = os.path.join(SYS, 'livearea', 'contents')
F = lambda s: ImageFont.truetype(os.path.join(HERE, 'DejaVuSans-Bold.ttf'), s)

def scene(w, h, title=True):
    im = Image.new('RGB', (w, h), (11, 18, 32)); d = ImageDraw.Draw(im)
    for i in range(h):  # ice gradient lower half
        if i > h * .45:
            t = (i - h * .45) / (h * .55); c = (int(190 + 50 * t), int(215 + 35 * t), int(235 + 20 * t)); d.line([(0, i), (w, i)], fill=c)
    d.rectangle([0, int(h * .43), w, int(h * .45)], fill=(233, 239, 246))
    d.rectangle([0, int(h * .435), w, int(h * .442)], fill=(192, 57, 43))
    nx, nw, ny = w * .5, w * .32, h * .5
    pw = max(3, int(w * .018))
    d.rectangle([nx - nw, ny, nx + nw, ny + pw], fill=(220, 38, 38))
    d.rectangle([nx - nw, ny, nx - nw + pw, h], fill=(220, 38, 38))
    d.rectangle([nx + nw - pw, ny, nx + nw, h], fill=(220, 38, 38))
    for k in range(1, 8):
        xx = nx - nw + k * (2 * nw / 8); d.line([(xx, ny + pw), (xx, h)], fill=(200, 210, 222), width=1)
    pr = h * .05; d.ellipse([w * .62 - pr * 1.4, h * .62 - pr, w * .62 + pr * 1.4, h * .62 + pr], fill=(15, 15, 15))
    if title:
        s = F(int(h * .16)); t = 'GOALIE SIM'
        tw = d.textlength(t, font=s); d.text(((w - tw) / 2 + 3, h * .12 + 3), t, font=s, fill=(0, 0, 0))
        d.text(((w - tw) / 2, h * .12), t, font=s, fill=(255, 213, 74))
    return im

def save8(im, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    im.convert('RGB').quantize(colors=255, method=Image.Quantize.MEDIANCUT).save(path, optimize=True)

ic = Image.new('RGB', (128, 128), (11, 18, 32)); d = ImageDraw.Draw(ic)
d.rounded_rectangle([6, 6, 122, 122], 18, fill=(37, 99, 235))
d.rectangle([22, 40, 106, 46], fill=(220, 38, 38)); d.rectangle([22, 40, 28, 112], fill=(220, 38, 38)); d.rectangle([100, 40, 106, 112], fill=(220, 38, 38))
d.ellipse([46, 64, 82, 82], fill=(10, 10, 10)); d.ellipse([49, 64, 79, 75], fill=(58, 58, 58))
d.text((64, 26), 'GOALIE', font=F(17), fill=(255, 255, 255), anchor='mm')
save8(ic, os.path.join(SYS, 'icon0.png'))
save8(scene(840, 500), os.path.join(LA, 'bg.png'))
save8(scene(280, 158), os.path.join(LA, 'startup.png'))
print('livearea images written')

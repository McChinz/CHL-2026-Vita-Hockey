#!/usr/bin/env python3
"""Builds the two texture atlases of the native game (players, arena) and writes them into cpp/src as
zlib-compressed RGBA inside C headers, together with the rectangle of every picture in them (tex_uv.h).
All the art is drawn here by code: no outside images, no real brands.

    python3 tools/make_textures.py            (needs Pillow and numpy)
"""
import os, sys, zlib, math, random
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '..', 'cpp', 'src')
S = 1024
SS = 3   # supersampling for drawn shapes


def font(size, bold=True):
    for p in ['/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf', '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf']:
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()


class Atlas:
    def __init__(self, h=None):
        self.W, self.H = S, h or S
        self.im = Image.new('RGBA', (self.W, self.H), (255, 255, 255, 0))
        self.rects = {}
        d = ImageDraw.Draw(self.im)
        d.rectangle((0, 0, 47, 47), fill=(255, 255, 255, 255))
        self.rects['WHITE'] = (20, 20, 28, 28)

    def put(self, name, img, x, y, wrapx=False, wrapy=False, pad=6):
        """paste img at (x, y); its edge pixels are repeated (or wrapped) into a gutter so filtering never bleeds"""
        img = img.convert('RGBA'); w, h = img.size; a = np.asarray(img)
        big = np.zeros((h + 2 * pad, w + 2 * pad, 4), np.uint8)
        ys = np.arange(-pad, h + pad); xs = np.arange(-pad, w + pad)
        yi = ys % h if wrapy else np.clip(ys, 0, h - 1); xi = xs % w if wrapx else np.clip(xs, 0, w - 1)
        big[:] = a[yi][:, xi]
        assert x - pad >= 0 and y - pad >= 0 and x + w + pad <= self.W and y + h + pad <= self.H, name
        self.im.paste(Image.fromarray(big, 'RGBA'), (x - pad, y - pad))
        self.rects[name] = (x, y, x + w, y + h)

    def header(self, sym):
        raw = self.im.tobytes(); z = zlib.compress(raw, 9)
        out = ['// made by tools/make_textures.py - do not edit', '#pragma once', 'static const int %s_W = %d, %s_H = %d;' % (sym, self.W, sym, self.H),
               'static const unsigned long %s_Z_LEN = %d;' % (sym, len(z)), 'static const unsigned char %s_Z[] = {' % sym]
        for i in range(0, len(z), 40):
            out.append(','.join(str(b) for b in z[i:i + 40]) + ',')
        out.append('};')
        return '\n'.join(out) + '\n', len(z)


def canvas(w, h, fill=(255, 255, 255, 0)):
    im = Image.new('RGBA', (w * SS, h * SS), fill); return im, ImageDraw.Draw(im)


def done(im):
    return im.resize((im.size[0] // SS, im.size[1] // SS), Image.LANCZOS)


def noise(w, h, scale, seed, wrap=True):
    """smooth value noise in 0..1, tileable"""
    rng = np.random.RandomState(seed); gw, gh = max(1, w // scale), max(1, h // scale)
    g = rng.rand(gh, gw).astype(np.float32)
    im = Image.fromarray((g * 255).astype(np.uint8), 'L')
    big = Image.new('L', (gw * 3, gh * 3)); [big.paste(im, (i * gw, j * gh)) for i in range(3) for j in range(3)]
    big = big.resize((w * 3, h * 3), Image.BICUBIC).crop((w, h, 2 * w, 2 * h))
    return np.asarray(big, np.float32) / 255


def lum_img(a):
    a = np.clip(a, 0, 1); v = (a * 255).astype(np.uint8); return Image.merge('RGBA', [Image.fromarray(v, 'L')] * 3 + [Image.new('L', (a.shape[1], a.shape[0]), 255)])


# ------------------------------------------------------------------ the players' atlas
def fabric():
    w = h = 256; y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    a = np.full((h, w), .9, np.float32)
    # soft folds running down the cloth, a little wavy
    for k, (f, amp, ph) in enumerate([(3, .13, .3), (5, .085, 1.7), (9, .05, 4.1)]):
        a += amp * np.sin(2 * math.pi * f * x / w + ph + .6 * np.sin(2 * math.pi * y / h + k))
    a += (noise(w, h, 32, 1) - .5) * .06 + (noise(w, h, 6, 2) - .5) * .03
    # the mesh of the weave
    a -= .035 * ((x.astype(int) % 4 == 0) & (y.astype(int) % 4 == 0))
    a -= .02 * ((x.astype(int) % 4 == 2) & (y.astype(int) % 4 == 2))
    return lum_img(a)


def digits():
    out = []; f = font(92 * SS)
    for dgt in '0123456789':
        im, d = canvas(72, 100)
        bb = d.textbbox((0, 0), dgt, font=f); tw, th = bb[2] - bb[0], bb[3] - bb[1]
        pos = ((72 * SS - tw) / 2 - bb[0], (100 * SS - th) / 2 - bb[1])
        d.text(pos, dgt, font=f, fill=(255, 255, 255, 255), stroke_width=4 * SS, stroke_fill=(12, 14, 20, 255))
        out.append(done(im))
    sheet = Image.new('RGBA', (80 * 10, 100), (255, 255, 255, 0))
    for i, im in enumerate(out):
        sheet.paste(im, (i * 80 + 4, 0))
    return sheet


def letters():
    """A-Z in two rows of 13 (the name across a player's shoulders)"""
    f = font(84 * SS); sheet = Image.new('RGBA', (76 * 13, 200), (255, 255, 255, 0))
    for i, ch in enumerate('ABCDEFGHIJKLMNOPQRSTUVWXYZ'):
        im, d = canvas(72, 100)
        bb = d.textbbox((0, 0), ch, font=f); tw, th = bb[2] - bb[0], bb[3] - bb[1]
        if tw > 62 * SS:
            f2 = font(int(84 * SS * 62 * SS / tw)); bb = d.textbbox((0, 0), ch, font=f2); tw, th = bb[2] - bb[0], bb[3] - bb[1]
        else:
            f2 = f
        d.text(((72 * SS - tw) / 2 - bb[0], (100 * SS - th) / 2 - bb[1]), ch, font=f2, fill=(255, 255, 255, 255), stroke_width=3 * SS, stroke_fill=(12, 14, 20, 255))
        sheet.paste(done(im), ((i % 13) * 76 + 2, (i // 13) * 100))
    return sheet


def star(d, cx, cy, r, fill, rot=-math.pi / 2, k=.42):
    pts = []
    for i in range(10):
        rr = r if i % 2 == 0 else r * k; a = rot + i * math.pi / 5; pts.append((cx + math.cos(a) * rr, cy + math.sin(a) * rr))
    d.polygon(pts, fill=fill)


def crest(kind):
    im, d = canvas(128, 128); s = SS; ink = (16, 20, 30, 255); mid = (120, 128, 142, 255); wh = (255, 255, 255, 255)
    if kind == 0:   # a shield with a star and two bars
        sh = [(14, 10), (114, 10), (114, 62), (64, 120), (14, 62)]
        d.polygon([(x * s, y * s) for x, y in sh], fill=ink)
        inner = [(22, 18), (106, 18), (106, 59), (64, 108), (22, 59)]
        d.polygon([(x * s, y * s) for x, y in inner], fill=wh)
        d.rectangle((22 * s, 18 * s, 106 * s, 32 * s), fill=mid)
        star(d, 64 * s, 62 * s, 26 * s, ink)
        star(d, 64 * s, 62 * s, 17 * s, mid)
    else:           # a roundel with crossed sticks and a puck
        d.ellipse((6 * s, 6 * s, 122 * s, 122 * s), fill=ink); d.ellipse((14 * s, 14 * s, 114 * s, 114 * s), fill=wh)
        d.ellipse((22 * s, 22 * s, 106 * s, 106 * s), fill=mid); d.ellipse((27 * s, 27 * s, 101 * s, 101 * s), fill=wh)
        for sg in (-1, 1):
            d.line(((64 - sg * 26) * s, 34 * s, (64 + sg * 20) * s, 90 * s), fill=ink, width=7 * s)
            d.line(((64 + sg * 20) * s, 90 * s, (64 + sg * 34) * s, 86 * s), fill=ink, width=8 * s)
        d.ellipse((52 * s, 40 * s, 76 * s, 56 * s), fill=ink)
    return done(im)


def face():
    im, d = canvas(128, 128); s = SS; br = (58, 40, 30, 255); dk = (24, 18, 16, 255)
    for sg in (-1, 1):
        cx = 64 + sg * 22
        d.ellipse(((cx - 11) * s, 50 * s, (cx + 11) * s, 62 * s), fill=(246, 244, 240, 255))        # eye white
        d.ellipse(((cx - 6) * s, 50 * s, (cx + 6) * s, 62 * s), fill=(70, 52, 40, 255))
        d.ellipse(((cx - 3) * s, 53 * s, (cx + 3) * s, 59 * s), fill=dk)
        d.ellipse(((cx - 1) * s, 52 * s, (cx + 2) * s, 55 * s), fill=(255, 255, 255, 255))
        d.arc(((cx - 13) * s, 46 * s, (cx + 13) * s, 66 * s), 195, 345, fill=dk, width=2 * s)       # the lid line
        d.polygon([((cx - 15) * s, (42 + sg * 0) * s), ((cx + 13) * s, 38 * s), ((cx + 15) * s, 42 * s), ((cx - 13) * s, 46 * s)] if sg < 0 else
                  [((cx + 15) * s, 42 * s), ((cx - 13) * s, 38 * s), ((cx - 15) * s, 42 * s), ((cx + 13) * s, 46 * s)], fill=br)   # brow
    d.line((60 * s, 62 * s, 57 * s, 84 * s), fill=(120, 84, 66, 150), width=3 * s)                 # the side of the nose
    d.arc((52 * s, 76 * s, 76 * s, 92 * s), 20, 160, fill=(96, 62, 50, 220), width=3 * s)
    d.line((48 * s, 104 * s, 80 * s, 104 * s), fill=(120, 60, 56, 255), width=4 * s)               # the mouth
    d.arc((46 * s, 98 * s, 82 * s, 116 * s), 25, 155, fill=(90, 50, 44, 160), width=2 * s)
    im = done(im)
    # stubble / jaw shadow as a soft dark veil low on the face
    a = np.asarray(im).copy(); y, x = np.mgrid[0:128, 0:128]
    veil = np.clip((y - 84) / 44, 0, 1) * (1 - np.clip(np.abs(x - 64) / 64, 0, 1) ** 2) * 70
    empty = a[..., 3] < 8
    a[empty, 0] = 60; a[empty, 1] = 44; a[empty, 2] = 38; a[..., 3] = np.maximum(a[..., 3], (veil * empty).astype(np.uint8))
    return Image.fromarray(a, 'RGBA')


SKIN = (242, 199, 155)     # the lightest skin tone in the game: darker players tint this down


def head_tex(face=0):
    """A whole head unwrapped: u goes round it (the face in the middle of the picture, the seam at the back),
    v from the crown (top) to under the chin. Four faces (0 classic, 1 rugged, 2 young and clean-shaven, 3 bearded).
    No hair: that's geometry, in the player's own colour."""
    F = [dict(brow=1.0, bz=0, nose=1.0, stub=.3, eye=1.0, lip=1.0), dict(brow=1.5, bz=-.012, nose=1.25, stub=.5, eye=.85, lip=1.15),
         dict(brow=.7, bz=.01, nose=.9, stub=0, eye=1.12, lip=.9), dict(brow=1.15, bz=0, nose=1.05, stub=.3, eye=1.0, lip=1.0)][face]
    w, h = 480, 200; S2 = 4
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32); th = (xx - w / 2) / w * 360.0; z = 1 - yy / h      # degrees from the front, height 0..1
    a = np.zeros((h, w, 3), np.float32); a[:] = SKIN
    def soft(cx, cz, rx, rz, amt, col=(120, 70, 50)):          # a soft patch of shade (cx in degrees, cz in height)
        d = ((th - cx) / rx) ** 2 + ((z - cz) / rz) ** 2; k = np.clip(1 - d, 0, 1) ** 1.5 * amt
        for c in range(3): a[..., c] += (col[c] - a[..., c]) * k
    # the planes of the face: eye sockets, the sides of the nose, under the nose and lip, cheek hollows, temples
    for sg in (-1, 1):
        soft(sg * 20, .515, 15, .075, .38); soft(sg * 9, .43, 6, .1, .22); soft(sg * 44, .33, 22, .16, .2); soft(sg * 62, .6, 16, .2, .16)
        soft(sg * 30, .43, 12, .05, -.12, (255, 222, 190))                                             # light on the cheekbones
    soft(0, .345, 11, .028, .4); soft(0, .185, 14, .03, .3); soft(0, .47, 4.5, .12, -.18, (255, 226, 196)); soft(0, .7, 30, .1, -.1, (255, 226, 196))
    # stubble along the jaw and round the mouth
    jaw = np.clip((.36 - z) / .2, 0, 1) * np.clip(1 - (np.abs(th) / 78) ** 4, 0, 1) * F['stub']
    lipz = np.clip(1 - np.abs(z - .24) / .1, 0, 1) * np.clip(1 - np.abs(th) / 26, 0, 1) * .16 * (F['stub'] > 0)
    for c, v in enumerate((92, 84, 86)): a[..., c] += (v - a[..., c]) * np.clip(jaw + lipz, 0, .45)
    a += (noise(w, h, 3, 71)[..., None] - .5) * 9
    if face == 3:   # a full beard: jaw, chin, up the cheeks to the sideburns, a moustache; the lips left clear
        at = np.abs(th); bl = np.where(at < 22, .27, .27 + (at - 22) / 66 * .3)
        bd = np.clip((bl - z) / .035, 0, 1) * np.clip((97 - at) / 6, 0, 1) * np.clip((z + .02) / .06, 0, 1)
        mo = np.clip(1 - np.abs(z - .292) / .03, 0, 1) * np.clip((22 - np.abs(th)) / 5, 0, 1)
        lp = np.clip(1 - np.abs(z - .24) / .028, 0, 1) * np.clip(1 - np.abs(th) / 15, 0, 1)
        bd = np.clip(np.maximum(bd, mo) - lp, 0, 1); bn = noise(w, h, 2, 74) * .6 + noise(w, h, 6, 75) * .4
        for c, v in enumerate((58, 42, 30)): a[..., c] += (v * (.75 + .5 * bn) - a[..., c]) * bd * .92
    im = Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), 'RGB').convert('RGBA').resize((w * S2, h * S2), Image.BICUBIC); d = ImageDraw.Draw(im, 'RGBA')
    X = lambda deg: (w / 2 + deg / 360.0 * w) * S2
    Y = lambda zz: (1 - zz) * h * S2
    dk = (34, 24, 20, 255)
    for sg in (-1, 1):
        ex, ez = sg * 20, .5; ek = F['eye']
        d.polygon([(X(ex - 9.5), Y(ez)), (X(ex - 4), Y(ez + .026 * ek)), (X(ex + 4), Y(ez + .026 * ek)), (X(ex + 9.5), Y(ez - .004)), (X(ex + 4), Y(ez - .02 * ek)), (X(ex - 4), Y(ez - .02 * ek))], fill=(238, 232, 226, 255))
        ix = ex - sg * .6
        d.ellipse((X(ix - 4.2), Y(ez + .026), X(ix + 4.2), Y(ez - .02)), fill=(74, 54, 40, 255)); d.ellipse((X(ix - 2), Y(ez + .014), X(ix + 2), Y(ez - .008)), fill=(14, 10, 10, 255))
        d.ellipse((X(ix - 2.6), Y(ez + .02), X(ix - .8), Y(ez + .008)), fill=(255, 255, 255, 230))
        d.line([(X(ex - 10), Y(ez - .002)), (X(ex - 4), Y(ez + .03 * ek)), (X(ex + 4), Y(ez + .03 * ek)), (X(ex + 10), Y(ez - .002))], fill=dk, width=int(1.6 * S2), joint='curve')      # the upper lid
        d.line([(X(ex - 9), Y(ez - .008)), (X(ex - 3), Y(ez - .025)), (X(ex + 5), Y(ez - .022))], fill=(150, 104, 84, 150), width=S2)                                        # the lower lid
        bk, bz = F['brow'], F['bz']; d.polygon([(X(ex - sg * 12), Y(.578 + bz)), (X(ex - sg * 4), Y(.6 + bz + .006 * (bk - 1))), (X(ex + sg * 11), Y(.572 + bz)), (X(ex + sg * 11.5), Y(.572 + bz - .014 * bk)), (X(ex - sg * 4), Y(.6 + bz - .028 * bk)), (X(ex - sg * 12), Y(.578 + bz - .018 * bk))], fill=(58, 42, 32, 235))  # the brow
        nk = F['nose']; d.ellipse((X(sg * 5.2 * nk - 2.6 * nk), Y(.375), X(sg * 5.2 * nk + 2.6 * nk), Y(.35)), fill=(84, 48, 40, 235))                                                                           # a nostril
        d.arc((X(sg * 8 * nk - 6 * nk), Y(.43), X(sg * 8 * nk + 6 * nk), Y(.335)), 20 if sg > 0 else 100, 80 if sg > 0 else 160, fill=(150, 100, 80, 170), width=S2)                              # the wing of the nose
        # an ear, side on
        cx = sg * 90
        d.ellipse((X(cx - 9), Y(.6), X(cx + 9), Y(.36)), fill=(226, 172, 134, 255), outline=(150, 100, 80, 255), width=S2)
        d.arc((X(cx - 5.5), Y(.57), X(cx + 5.5), Y(.42)), 200, 520, fill=(150, 96, 78, 255), width=int(1.5 * S2))
    # the mouth: the line between the lips, the lips themselves
    lk = F['lip']; d.polygon([(X(-15 * lk), Y(.245)), (X(-6), Y(.245 + .017 * lk)), (X(0), Y(.255)), (X(6), Y(.245 + .017 * lk)), (X(15 * lk), Y(.245)), (X(7), Y(.245 - .033 * lk)), (X(-7), Y(.245 - .033 * lk))], fill=(186, 112, 104, 255))
    d.line([(X(-15.5), Y(.243)), (X(-6), Y(.24)), (X(0), Y(.236)), (X(6), Y(.24)), (X(15.5), Y(.243))], fill=(92, 46, 44, 255), width=int(1.5 * S2), joint='curve')
    im = im.filter(ImageFilter.GaussianBlur(S2 * .55)).resize((w, h), Image.LANCZOS)
    return im


def mask_tex():
    """A goalie mask unwrapped (front in the middle, top of the shell at the top, the chin at the bottom). Drawn in
    greys so the team's colours tint it: panels, sweeping stripes back from the opening, vent holes, the chin."""
    w, h = 250, 200; a = np.full((h, w), .96, np.float32); a += (noise(w, h, 30, 81) - .5) * .05
    im = lum_img(a).resize((w * SS, h * SS), Image.BICUBIC); d = ImageDraw.Draw(im, 'RGBA'); s = SS
    X = lambda deg: (w / 2 + deg / 360.0 * w) * s
    for sg in (-1, 1):
        for k in range(4):                                                       # stripes sweeping back and up from the cage
            x0, y0 = X(sg * 64), (70 + k * 22) * s; pts = [(x0, y0), (X(sg * (120 + k * 6)), y0 - (36 - k * 4) * s), (X(sg * (150 + k * 6)), y0 - (30 - k * 4) * s), (x0, y0 + 9 * s)]
            d.polygon(pts, fill=(96, 100, 112, 255) if k % 2 == 0 else (30, 32, 40, 255))
        d.line([(X(sg * 60), 30 * s), (X(sg * 60), 150 * s)], fill=(60, 64, 74, 255), width=3 * s)   # the edge of the opening
        for (dg, yy) in [(92, 52), (108, 84), (96, 118), (128, 64), (140, 104), (76, 166), (100, 150)]:   # vent holes
            d.ellipse((X(sg * dg) - 5 * s, (yy - 4) * s, X(sg * dg) + 5 * s, (yy + 4) * s), fill=(14, 16, 22, 255))
        d.rounded_rectangle((X(sg * 172) - 8 * s, 60 * s, X(sg * 172) + 8 * s, 150 * s), radius=6 * s, outline=(70, 74, 86, 255), width=2 * s)   # the back plate's straps
    d.polygon([(X(-52), 22 * s), (X(0), 6 * s), (X(52), 22 * s), (X(40), 34 * s), (X(0), 24 * s), (X(-40), 34 * s)], fill=(40, 42, 52, 255))    # a blaze over the forehead
    d.line([(X(-60), 30 * s), (X(60), 30 * s)], fill=(60, 64, 74, 255), width=3 * s); d.line([(X(-60), 150 * s), (X(60), 150 * s)], fill=(60, 64, 74, 255), width=3 * s)
    for dg in (-24, -8, 8, 24):
        d.ellipse((X(dg) - 3 * s, 166 * s, X(dg) + 3 * s, 172 * s), fill=(20, 22, 28, 255))            # the chin's breathing holes
    return done(im)


def helm2_tex():
    """A skater's helmet unwrapped (front in the middle; top of the picture = the crown, bottom = its lower edge)."""
    w, h = 240, 200; a = np.full((h, w), .95, np.float32); a += (noise(w, h, 30, 91) - .5) * .04
    im = lum_img(a).resize((w * SS, h * SS), Image.BICUBIC); d = ImageDraw.Draw(im, 'RGBA'); s = SS
    X = lambda deg: (w / 2 + deg / 360.0 * w) * s
    ln = (120, 126, 138, 255); dk = (22, 24, 30, 255)
    d.line([(0, 104 * s), (w * s, 104 * s)], fill=ln, width=2 * s)                                     # where the front and back shells overlap
    d.line([(X(-62), 150 * s), (X(62), 150 * s)], fill=(90, 96, 108, 255), width=3 * s)                # the brim
    d.polygon([(X(-34), 96 * s), (X(-22), 20 * s), (X(22), 20 * s), (X(34), 96 * s)], outline=ln, width=2 * s)   # the raised panel over the top
    for sg in (-1, 1):
        for k in range(3):                                                                             # vents: along the crown, over the temples
            d.rounded_rectangle((X(sg * (14 + k * 2)) - 3 * s, (30 + k * 22) * s, X(sg * (14 + k * 2)) + 3 * s, (44 + k * 22) * s), radius=3 * s, fill=dk)
        for k in range(3):
            d.rounded_rectangle((X(sg * (46 + k * 16)) - 9 * s, (118 + k * 2) * s, X(sg * (46 + k * 16)) + 9 * s, (124 + k * 2) * s), radius=3 * s, fill=dk)
            d.rounded_rectangle((X(sg * (60 + k * 22)) - 8 * s, (62 + k * 3) * s, X(sg * (60 + k * 22)) + 8 * s, (67 + k * 3) * s), radius=2 * s, fill=(40, 44, 52, 255))
        d.ellipse((X(sg * 92) - 12 * s, 158 * s, X(sg * 92) + 12 * s, 192 * s), fill=dk, outline=ln, width=2 * s)     # the ear opening
        for (dg, yy) in [(66, 170), (66, 180), (120, 172)]:
            d.ellipse((X(sg * dg) - 2.5 * s, (yy - 2.5) * s, X(sg * dg) + 2.5 * s, (yy + 2.5) * s), fill=(60, 64, 74, 255))   # screws
        d.rounded_rectangle((X(sg * 170) - 10 * s, 128 * s, X(sg * 170) + 10 * s, 176 * s), radius=5 * s, outline=ln, width=2 * s)   # the adjuster at the back
    return done(im)


def pad_tex():
    """a goalie's leg pad unwrapped: u goes round it (the face is centred on u = 0, so it straddles the left and right
    edges of this picture), v runs from the thigh rise (top) to the boot (bottom)"""
    w, h = 256, 512; y, x = np.mgrid[0:h, 0:w].astype(np.float32); u = x / w; t = 1 - y / h
    a = np.full((h, w), .97, np.float32)
    du = np.minimum(u, 1 - u)                       # distance (round the pad) from the face centre: the face is du < .125
    face = du < .125; side = (du >= .125) & (du < .375); back = du >= .375
    a[side] -= .1; a[back] -= .45
    a += (noise(w, h, 24, 5) - .5) * .05
    # leather grain and scuffs
    a += (noise(w, h, 3, 6) - .5) * .035
    sc = noise(w, h, 40, 7); a -= np.clip(sc - .72, 0, 1) * .5 * face
    # the binding round the face (a dark piped edge) and the vertical seams
    a -= .5 * np.exp(-((du - .122) / .006) ** 2)
    a -= .22 * np.exp(-((du - .07) / .0035) ** 2) * (t > .17)
    # the knee rolls: three padded bars across the face between the boot break and the thigh rise, shaded like tubes
    for t0 in (.16, .33, .5, .64, .8):
        a -= .38 * np.exp(-((t - t0) / .006) ** 2) * (du < .125)
    for lo, hi in ((.5, .64),):
        m = (t > lo) & (t < hi) & face; c = (t - lo) / (hi - lo); a[m] += .05 * np.sin(c[m] * math.pi) - .03
    for lo, hi in ((.16, .33), (.33, .5), (.64, .8), (.8, 1)):
        m = (t > lo) & (t < hi) & face; c = (t - lo) / (hi - lo); a[m] += .035 * np.sin(c[m] * math.pi) - .02
    # stitching either side of every crease
    for t0 in (.16, .33, .5, .64, .8):
        for o in (-.012, .012):
            st = (np.abs(t - t0 - o) < .0025) & (np.floor(x / 3) % 2 == 0) & (du < .115); a[st] -= .2
    # the boot: darker under the toe
    a -= np.clip((.06 - t) / .06, 0, 1) * .25
    # straps round the back
    for t0 in (.12, .3, .47, .7, .88):
        m = (np.abs(t - t0) < .016) & (du > .14); a[m] = .16
        bk = (np.abs(t - t0) < .024) & (np.abs(du - .26) < .012); a[bk] = .7
    return lum_img(a)


def blocker_tex():
    w, h = 128, 192; im, d = canvas(w, h, (236, 238, 242, 255)); s = SS
    d.rounded_rectangle((0, 0, w * s - 1, h * s - 1), radius=10 * s, outline=(40, 44, 54, 255), width=7 * s)
    d.rounded_rectangle((10 * s, 10 * s, (w - 10) * s, (h - 10) * s), radius=7 * s, outline=(150, 156, 168, 255), width=2 * s)
    d.line((10 * s, 58 * s, (w - 10) * s, 58 * s), fill=(120, 126, 138, 255), width=3 * s)      # the bend near the top
    d.line((10 * s, 132 * s, (w - 10) * s, 132 * s), fill=(150, 156, 168, 255), width=2 * s)
    d.rounded_rectangle((26 * s, 76 * s, (w - 26) * s, 114 * s), radius=5 * s, fill=(196, 200, 208, 255))   # a maker's panel
    for i in range(3):
        d.line(((34 + i * 22) * s, 84 * s, (46 + i * 22) * s, 106 * s), fill=(110, 116, 128, 255), width=5 * s)
    im = done(im); a = np.asarray(im).astype(np.float32) / 255
    a[..., :3] += ((noise(w, h, 16, 11) - .5) * .06)[..., None]
    return Image.fromarray((np.clip(a, 0, 1) * 255).astype(np.uint8), 'RGBA')


def trapper_tex():
    """the catching glove seen by the shooter, fingers up: the cuff (bottom), the palm, the pocket with its laced web"""
    w, h = 192, 224; im, d = canvas(w, h); s = SS; edge = (40, 44, 54, 255); body = (240, 242, 246, 255); sh = (176, 182, 194, 255)
    # the mitt
    d.ellipse((30 * s, 4 * s, 186 * s, 168 * s), fill=edge); d.ellipse((37 * s, 11 * s, 179 * s, 161 * s), fill=body)
    # the thumb
    d.rounded_rectangle((6 * s, 70 * s, 58 * s, 170 * s), radius=24 * s, fill=edge); d.rounded_rectangle((13 * s, 77 * s, 51 * s, 163 * s), radius=18 * s, fill=body)
    # the cuff
    d.rounded_rectangle((20 * s, 140 * s, 150 * s, 220 * s), radius=12 * s, fill=edge); d.rounded_rectangle((27 * s, 147 * s, 143 * s, 213 * s), radius=8 * s, fill=body)
    d.line((27 * s, 178 * s, 143 * s, 178 * s), fill=sh, width=3 * s)
    # the pocket: a dark web laced between the thumb and the fingers
    d.pieslice((52 * s, 14 * s, 150 * s, 132 * s), 180, 360, fill=(70, 74, 86, 255))
    d.polygon([(52 * s, 73 * s), (150 * s, 73 * s), (112 * s, 128 * s), (74 * s, 128 * s)], fill=(70, 74, 86, 255))
    for i in range(7):
        x0 = 60 + i * 13; d.line((x0 * s, 26 * s, x0 * s, 118 * s), fill=(200, 204, 212, 255), width=2 * s)
    for j in range(6):
        y0 = 32 + j * 15; d.line((58 * s, y0 * s, 146 * s, y0 * s), fill=(200, 204, 212, 255), width=2 * s)
    d.line((101 * s, 16 * s, 101 * s, 126 * s), fill=body, width=9 * s)       # the T of the web
    d.line((62 * s, 30 * s, 140 * s, 30 * s), fill=body, width=9 * s)
    # finger break lines on the palm side
    for k in range(3):
        d.arc(((120 + k * 14) * s, 40 * s, (190 + k * 6) * s, 150 * s), 300, 60, fill=sh, width=2 * s)
    return done(im)


def cage_tex():
    w = h = 128; im, d = canvas(w, h); s = SS; bar = (205, 212, 222, 255); hi = (255, 255, 255, 255)
    for i in range(1, 8):
        x0 = i * 16; d.line((x0 * s, 6 * s, x0 * s, 122 * s), fill=bar, width=3 * s); d.line(((x0 - 1) * s, 6 * s, (x0 - 1) * s, 122 * s), fill=hi, width=1 * s)
    for j in range(1, 7):
        y0 = 8 + j * 16; d.line((6 * s, y0 * s, 122 * s, y0 * s), fill=bar, width=3 * s); d.line((6 * s, (y0 - 1) * s, 122 * s, (y0 - 1) * s), fill=hi, width=1 * s)
    d.rounded_rectangle((4 * s, 4 * s, 124 * s, 124 * s), radius=26 * s, outline=bar, width=5 * s)
    im = done(im); a = np.asarray(im).copy()
    # keep only what is inside the rounded opening
    m = Image.new('L', (w * SS, h * SS), 0); ImageDraw.Draw(m).rounded_rectangle((3 * SS, 3 * SS, 125 * SS, 125 * SS), radius=26 * SS, fill=255)
    m = np.asarray(m.resize((w, h), Image.LANCZOS)); a[..., 3] = (a[..., 3].astype(np.float32) * m / 255).astype(np.uint8)
    return Image.fromarray(a, 'RGBA')


def helmet_tex():
    """wrapped round the helmet: u round the head (front in the middle of the picture... the seam at the back), v crown to rim"""
    w, h = 256, 128; a = np.full((h, w), .97, np.float32); y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    a += (noise(w, h, 40, 21) - .5) * .04
    im = lum_img(a); d = ImageDraw.Draw(im)
    for k in range(8):                                   # vents round the crown
        x0 = 16 + k * 32
        d.rounded_rectangle((x0 - 9, 30, x0 + 9, 38), radius=3, fill=(30, 34, 42, 255))
        d.rounded_rectangle((x0 - 7, 50, x0 + 7, 56), radius=3, fill=(46, 50, 60, 255))
    d.line((0, 72, w, 72), fill=(150, 156, 168, 255), width=2)      # the seam between the two shells
    d.line((0, 110, w, 110), fill=(120, 126, 138, 255), width=3)    # the rim
    return im


def glove_tex():
    w = h = 64; a = np.full((h, w), .96, np.float32); a += (noise(w, h, 8, 31) - .5) * .06
    im = lum_img(a); d = ImageDraw.Draw(im)
    for i in range(1, 4):
        d.line((0, i * 16, w, i * 16), fill=(70, 74, 84, 255), width=2)
    for i in range(0, 5):
        d.line((i * 16 - 1, 0, i * 16 - 1, h), fill=(110, 116, 128, 255), width=1)
    return im


def build_player():
    A = Atlas(2 * S)
    A.put('FABRIC', fabric(), 60, 8, wrapx=True, wrapy=True)
    A.put('PAD', pad_tex(), 330, 8, wrapx=True)
    A.put('HELMET', helmet_tex(), 600, 8, wrapx=True)
    A.put('GLOVE', glove_tex(), 870, 8, wrapx=True, wrapy=True)
    A.put('BLOCKER', blocker_tex(), 600, 150)
    A.put('TRAPPER', trapper_tex(), 742, 150)
    A.put('DIGITS', digits(), 8, 534, pad=4)
    lt = letters(); A.put('LETTERS', lt.resize((int(lt.size[0] * .7), int(lt.size[1] * .7)), Image.LANCZOS), 8, 650, pad=4)
    A.put('HEAD', head_tex(0), 8, 806, wrapx=True); A.put('HEAD1', head_tex(1), 8, 1032, wrapx=True); A.put('HEAD2', head_tex(2), 500, 1032, wrapx=True); A.put('HEAD3', head_tex(3), 8, 1250, wrapx=True); A.put('MASK', mask_tex(), 502, 806, wrapx=True); A.put('HELM2', helm2_tex(), 766, 806, wrapx=True)
    A.put('CREST0', crest(0), 8, 280); A.put('CREST1', crest(1), 150, 280)
    A.put('FACE', face(), 600, 390); A.put('CAGE', cage_tex(), 742, 390)
    return A


# ------------------------------------------------------------------ the arena's atlas
SHIRTS = [(214, 40, 48), (245, 246, 248), (36, 74, 160), (28, 34, 48), (120, 128, 142), (240, 196, 40), (60, 132, 220), (176, 32, 40), (232, 236, 240),
          (52, 60, 80), (210, 110, 40), (40, 130, 90), (150, 60, 150), (245, 246, 248), (30, 60, 130)]
SKINS = [(241, 198, 165), (217, 164, 124), (168, 113, 79), (107, 70, 48), (232, 184, 150)]
HAIR = [(30, 24, 20), (70, 48, 30), (150, 110, 60), (190, 180, 170), (20, 20, 24), (110, 40, 30)]


def crowd():
    """a packed lower bowl seen from the ice: rows of people, the back rows drawn first; tiles left to right"""
    w, h = 512, 192; rnd = random.Random(7)
    im = Image.new('RGBA', (w * SS, h * SS), (18, 22, 34, 255)); d = ImageDraw.Draw(im); s = SS
    rows = 9
    for r in range(rows):
        base = 26 + r * (h - 20) / rows          # the shoulders' line of this row
        k = .78 + .22 * r / (rows - 1)            # people nearer the glass are a little bigger and brighter
        d.rectangle((0, (base + 6 * k) * s, w * s, (base + 13 * k) * s), fill=(30, 36, 52, 255))    # the seat backs of the row in front
        n = int(w / (15 * k)); off = rnd.random() * 15
        for i in range(n):
            if rnd.random() < .05: continue
            cx = (off + i * w / n + rnd.uniform(-2, 2)) % w; sh = rnd.choice(SHIRTS); sk = rnd.choice(SKINS); hr = rnd.choice(HAIR)
            b = .62 + .38 * r / (rows - 1); sh = tuple(int(c * b) for c in sh); sk = tuple(int(c * b) for c in sk)
            up = rnd.random() < .12; hw = 6.2 * k; hh = 11 * k; hd = 3.6 * k
            for ox in (-w, 0, w):
                x = cx + ox
                d.rounded_rectangle(((x - hw) * s, (base - hh * .2) * s, (x + hw) * s, (base + hh) * s), radius=3 * k * s, fill=sh + (255,))
                d.ellipse(((x - hd) * s, (base - hh * .2 - hd * 2.1) * s, (x + hd) * s, (base - hh * .2 - hd * .1) * s), fill=sk + (255,))
                cap = rnd.random() < .35
                d.pieslice(((x - hd) * s, (base - hh * .2 - hd * 2.2) * s, (x + hd) * s, (base - hh * .2 - hd * .2) * s), 180, 360, fill=(sh if cap else tuple(int(c * b) for c in hr)) + (255,))
                if up:
                    for sg in (-1, 1):
                        d.line(((x + sg * hw * .8) * s, (base + 1) * s, (x + sg * hw * 1.5) * s, (base - hh * .9) * s), fill=sh + (255,), width=int(3 * k * s))
                        d.ellipse(((x + sg * hw * 1.5 - 1.6 * k) * s, (base - hh * .9 - 3 * k) * s, (x + sg * hw * 1.5 + 1.6 * k) * s, (base - hh * .9) * s), fill=sk + (255,))
    return done(im)


BRANDS = [('NORTHWIND', (20, 60, 140), (255, 255, 255)), ('POLAR', (255, 255, 255), (200, 30, 40)), ('IRONLINE', (24, 28, 36), (245, 196, 40)),
          ('GLACIER BANK', (255, 255, 255), (20, 100, 170)), ('KESTREL', (190, 30, 40), (255, 255, 255)), ('TUNDRA TIRE', (245, 196, 40), (24, 28, 36)),
          ('BOREAL AIR', (255, 255, 255), (30, 120, 90)), ('CHL 2026', (30, 40, 70), (255, 255, 255))]


def ads():
    """the dasher-board adverts: eight invented brands, each a 3:1 panel, in two rows of four"""
    pw, ph = 126, 42; sheet = Image.new('RGBA', (pw * 4, ph * 2), (248, 250, 252, 255))
    for i, (name, bg, fg) in enumerate(BRANDS):
        im, d = canvas(pw, ph, (248, 250, 252, 255)); s = SS
        d.rectangle((3 * s, 4 * s, (pw - 3) * s, (ph - 4) * s), fill=bg + (255,))
        size = 22
        while size > 8:
            f = font(size * s); bb = d.textbbox((0, 0), name, font=f)
            if bb[2] - bb[0] < (pw - 16) * s: break
            size -= 1
        d.text(((pw * s - (bb[2] - bb[0])) / 2 - bb[0], (ph * s - (bb[3] - bb[1])) / 2 - bb[1]), name, font=f, fill=fg + (255,))
        sheet.paste(done(im), ((i % 4) * pw, (i // 4) * ph))
    return sheet


def ice_scratch():
    """what skates leave behind: fine pale arcs and a few grey scuffs, see-through, tiles in both directions"""
    w = h = 256; rnd = random.Random(3); im = Image.new('RGBA', (w * SS, h * SS), (255, 255, 255, 0)); d = ImageDraw.Draw(im); s = SS
    for i in range(170):
        cx, cy = rnd.uniform(0, w), rnd.uniform(0, h); r = rnd.uniform(14, 90); a0 = rnd.uniform(0, 360); ln = rnd.uniform(18, 70)
        grey = rnd.random() < .45; col = (120, 138, 160, rnd.randint(26, 60)) if grey else (255, 255, 255, rnd.randint(70, 150))
        for ox in (-w, 0, w):
            for oy in (-h, 0, h):
                d.arc(((cx + ox - r) * s, (cy + oy - r) * s, (cx + ox + r) * s, (cy + oy + r) * s), a0, a0 + ln, fill=col, width=rnd.choice((1, 1, 2)) * s // 2 + 1)
    im = done(im); a = np.asarray(im).copy().astype(np.float32)
    cl = noise(w, h, 64, 9); a[..., 3] = np.clip(a[..., 3] * (.55 + .9 * cl), 0, 255)
    # broad dull patches where the ice has been cut up
    veil = np.clip(noise(w, h, 48, 12) - .55, 0, 1) * 60
    emp = a[..., 3] < veil; a[emp, 0] = 150; a[emp, 1] = 166; a[emp, 2] = 186; a[..., 3] = np.maximum(a[..., 3], veil)
    return Image.fromarray(a.astype(np.uint8), 'RGBA')


def centre_logo():
    w = h = 256; im, d = canvas(w, h); s = SS; navy = (22, 40, 84, 255); red = (206, 44, 52, 255); wh = (250, 252, 255, 255)
    d.ellipse((4 * s, 4 * s, 252 * s, 252 * s), fill=navy); d.ellipse((14 * s, 14 * s, 242 * s, 242 * s), fill=wh)
    d.ellipse((22 * s, 22 * s, 234 * s, 234 * s), fill=red); d.ellipse((34 * s, 34 * s, 222 * s, 222 * s), fill=navy)
    for i in range(12):
        a = i * math.pi / 6; star(d, (128 + math.cos(a) * 100) * s, (128 + math.sin(a) * 100) * s, 6 * s, wh)
    f = font(84 * s); bb = d.textbbox((0, 0), 'CHL', font=f)
    d.text(((w * s - (bb[2] - bb[0])) / 2 - bb[0], 80 * s - bb[1]), 'CHL', font=f, fill=wh, stroke_width=3 * s, stroke_fill=red)
    f2 = font(30 * s); bb = d.textbbox((0, 0), '2026', font=f2); d.text(((w * s - (bb[2] - bb[0])) / 2 - bb[0], 168 * s - bb[1]), '2026', font=f2, fill=(245, 196, 40, 255))
    return done(im)


def ice_ads():
    """wordmarks painted under the ice (four invented brands), one above the other"""
    names = [('NORTHWIND', (40, 70, 130)), ('POLAR ENERGY', (176, 40, 48)), ('IRONLINE', (40, 48, 62)), ('GLACIER BANK', (30, 100, 150))]
    w, h = 448, 64; sheet = Image.new('RGBA', (w, h * 4), (255, 255, 255, 0))
    for i, (nm, col) in enumerate(names):
        im, d = canvas(w, h); s = SS; size = 50
        while True:
            f = font(size * s); bb = d.textbbox((0, 0), nm, font=f)
            if bb[2] - bb[0] < (w - 16) * s: break
            size -= 2
        d.text(((w * s - (bb[2] - bb[0])) / 2 - bb[0], (h * s - (bb[3] - bb[1])) / 2 - bb[1]), nm, font=f, fill=col + (210,))
        sheet.paste(done(im), (0, i * h))
    return sheet


def ribbon():
    """the lit ring between the lower and upper bowls"""
    w, h = 512, 24; im, d = canvas(w, h, (10, 14, 26, 255)); s = SS; f = font(15 * s); x = 6
    items = [('CHL 2026', (245, 196, 40)), ('GO  GO  GO', (255, 255, 255)), ('NORTHWIND', (120, 170, 255)), ('MAKE  SOME  NOISE', (255, 90, 90)), ('POLAR', (255, 255, 255)), ('IRONLINE', (245, 196, 40))]
    for nm, col in items:
        bb = d.textbbox((0, 0), nm, font=f); d.text((x * s - bb[0], (h * s - (bb[3] - bb[1])) / 2 - bb[1]), nm, font=f, fill=col + (255,)); x += (bb[2] - bb[0]) / s + 22
    return done(im)


def upper():
    """the upper bowl: smaller, darker, further away"""
    c = crowd().resize((512, 96), Image.LANCZOS); a = np.asarray(c).astype(np.float32); a[..., :3] *= .55
    return Image.fromarray(a.astype(np.uint8), 'RGBA')


def build_arena():
    A = Atlas()
    A.put('CROWD', crowd(), 8, 60, wrapx=True)
    A.put('UPPER', upper(), 8, 266, wrapx=True)
    A.put('RIBBON', ribbon(), 8, 376, wrapx=True)
    A.put('ADS', ads(), 8, 414, pad=3)
    A.put('ICEADS', ice_ads(), 8, 512)
    A.put('SCRATCH', ice_scratch(), 540, 60, wrapx=True, wrapy=True)
    A.put('LOGO', centre_logo(), 540, 330)
    return A


def main():
    P, R = build_player(), build_arena()
    hp, np_ = P.header('TEXP'); ha, na = R.header('TEXA')
    open(os.path.join(OUT, 'tex_player.h'), 'w').write(hp); open(os.path.join(OUT, 'tex_arena.h'), 'w').write(ha)
    uv = ['// made by tools/make_textures.py - do not edit: where each picture sits in its atlas (u0, v0, u1, v1)', '#pragma once', 'struct TexR { float u0, v0, u1, v1; };']
    for pre, A in (('TP_', P), ('TA_', R)):
        for k, (x0, y0, x1, y1) in sorted(A.rects.items()):
            uv.append('static const TexR %s%s = {%.6ff, %.6ff, %.6ff, %.6ff};' % (pre, k, x0 / A.W, y0 / A.H, x1 / A.W, y1 / A.H))
    open(os.path.join(OUT, 'tex_uv.h'), 'w').write('\n'.join(uv) + '\n')
    P.im.save('/tmp/atlas_player.png'); R.im.save('/tmp/atlas_arena.png')
    print('player %d KB, arena %d KB' % (np_ // 1024, na // 1024))


if __name__ == '__main__':
    main()

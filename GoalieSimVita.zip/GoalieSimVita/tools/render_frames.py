#!/usr/bin/env python3
"""Renders preview_out/frames.json (from preview_vita.js) to PNGs, approximating the Vita renderer."""
import json, os
from PIL import Image, ImageDraw
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'preview_out')
atlas = Image.open(os.path.join(ROOT, 'vita', 'assets', 'font.png')).convert('RGBA')
def unpack(c): return (c & 255, (c >> 8) & 255, (c >> 16) & 255, (c >> 24) & 255)
for fr in json.load(open(os.path.join(OUT, 'frames.json'))):
    img = Image.new('RGB', (960, 544), (11, 18, 32)); d = ImageDraw.Draw(img, 'RGBA')  # RGB base + RGBA draw = alpha blending
    for cmd in fr['cmds']:
        if cmd['t'] == 'tri':
            p, c = cmd['p'], cmd['c']
            for i in range(0, len(c), 3):
                cols = [unpack(c[i + k]) for k in range(3)]
                avg = tuple(sum(x[j] for x in cols) // 3 for j in range(4))
                if avg[3] == 0: continue
                d.polygon([(p[2 * (i + k)], p[2 * (i + k) + 1]) for k in range(3)], fill=avg)
        else:
            g, col = cmd['g'], unpack(cmd['c'])
            for i in range(0, len(g), 7):
                dx, dy, u, v, w, h, s = g[i:i + 7]
                gw, gh = max(1, round(w * s)), max(1, round(h * s))
                glyph = atlas.crop((int(u), int(v), int(u + w), int(v + h))).resize((gw, gh), Image.LANCZOS)
                a = glyph.split()[3].point(lambda x: x * col[3] // 255)
                tint = Image.new('RGBA', (gw, gh), col[:3] + (255,)); tint.putalpha(a)
                img.paste(tint, (int(round(dx)), int(round(dy))), tint)
    img.save(os.path.join(OUT, fr['name'] + '.png'))
    print('wrote', fr['name'] + '.png')

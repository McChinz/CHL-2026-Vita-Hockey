cmake_minimum_required(VERSION 3.16)
# CHL 2026 NATIVE - the C++ build of the game (no JavaScript engine). Separate app from the JS build:
# its own title ID and data folder, so both can be installed at the same time.
#
#   Vita:  cmake -S cpp -B build-native && cmake --build build-native      (needs VitaSDK, like the JS build)
#   PC test build (software renderer, scripted input):  cmake -S cpp -B build-host -DHOST=ON && cmake --build build-host

option(HOST "Build the desktop test version instead of the Vita app" OFF)

if(NOT HOST AND NOT DEFINED CMAKE_TOOLCHAIN_FILE)
  if(DEFINED ENV{VITASDK})
    set(CMAKE_TOOLCHAIN_FILE "$ENV{VITASDK}/share/vita.toolchain.cmake" CACHE PATH "toolchain file")
  else()
    message(FATAL_ERROR "Please install VitaSDK and set the VITASDK environment variable (or pass -DHOST=ON for the PC test build).")
  endif()
endif()

project(CHL2026Native CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

set(GAME_SRC
  src/canvas.cpp src/audio.cpp src/json.cpp src/data.cpp src/league.cpp src/menu.cpp src/ut.cpp src/ut_draw.cpp src/save.cpp src/pro.cpp src/pro_draw.cpp src/hockeymon.cpp src/emblem.cpp src/trophy.cpp src/apt.cpp src/music.cpp src/prac.cpp
  src/sk_core.cpp src/sk_play.cpp src/sk_flow.cpp
  src/sk_draw.cpp src/sk_draw3d.cpp src/hud.cpp src/ui.cpp src/main.cpp)

if(HOST)
  add_executable(chl_host ${GAME_SRC} src/platform_host.cpp src/mus_host.cpp src/test_main.cpp)
  target_compile_definitions(chl_host PRIVATE HOST_BUILD)
  target_compile_options(chl_host PRIVATE -O2 -Wall -Wno-misleading-indentation)
  target_link_libraries(chl_host z)   # the textures are stored compressed
  return()
endif()

include("$ENV{VITASDK}/share/vita.cmake" REQUIRED)
set(VITA_APP_NAME "CHL 2026")
set(VITA_TITLEID  "GOAL00002")
set(VITA_VERSION  "00.70")

# the renderer: vitaGL (GPU 3D with a depth buffer, 4x MSAA) - the only one now (the vita2d fallback is gone)
set(PLAT_SRC src/vita_sys.cpp src/mus_vita.cpp src/platform_vitagl.cpp)
# the game, compiled once and linked twice (see "room for vita-elf-create" below)
add_library(chl_objs OBJECT ${GAME_SRC} ${PLAT_SRC})
# -O3, no errno from maths calls, fused multiply-add, NEON and tuned for the Vita's Cortex-A9
set(CHL_COPTS -O3 -fno-math-errno -ffp-contract=fast -mtune=cortex-a9 -mfpu=neon -Wall -Wno-misleading-indentation -Wno-psabi -fno-strict-aliasing)
target_compile_options(chl_objs PRIVATE ${CHL_COPTS})
# optional stubs: linked only if this VitaSDK has them, so a renamed or missing one can't break the build
set(OPTIONAL_LIBS SceAppMgr_stub SceKernelDmacMgr_stub SceSharedFb_stub SceRtc_stub)
set(EXTRA_LIBS "")
foreach(lib ${OPTIONAL_LIBS})
  find_library(FOUND_${lib} ${lib})
  if(FOUND_${lib})
    list(APPEND EXTRA_LIBS ${FOUND_${lib}})
  endif()
endforeach()
# the system's MP3 decoder for the soundtrack (src/mus_vita.cpp); without it the game builds and plays without music
find_library(FOUND_SceAudiodec_stub SceAudiodec_stub)
if(FOUND_SceAudiodec_stub)
  list(APPEND EXTRA_LIBS ${FOUND_SceAudiodec_stub})
  target_compile_definitions(chl_objs PRIVATE CHL_AUDIODEC)
endif()
# vitaGL and its shader compiler stack (vdpm: vitaGL vitaShaRK SceShaccCgExt libmathneon taihen)
set(GL_OPTIONAL SceIme_stub SceShaccCg_stub SceRazorCapture_stub SceLibKernel_stub)
foreach(lib ${GL_OPTIONAL})
  find_library(FOUND_${lib} ${lib})
  if(FOUND_${lib})
    list(APPEND EXTRA_LIBS ${FOUND_${lib}})
  endif()
endforeach()
# system trophies (the console's Trophies app): needs the SceNpTrophy stub; without it the game builds without them
find_library(FOUND_SceNpTrophy_stub SceNpTrophy_stub)
if(FOUND_SceNpTrophy_stub)
  list(APPEND EXTRA_LIBS ${FOUND_SceNpTrophy_stub})
  target_compile_definitions(chl_objs PRIVATE CHL_TROPHIES)
  message(STATUS "trophies: on")
else()
  message(WARNING "trophies: SceNpTrophy_stub not found - building without system trophies")
endif()
function(chl_link tgt)
  target_compile_options(${tgt} PRIVATE ${CHL_COPTS})
  target_link_libraries(${tgt}
    vitaGL vitashark SceShaccCgExt mathneon taihen_stub
    SceDisplay_stub SceGxm_stub SceSysmodule_stub SceCtrl_stub SceTouch_stub SceAudio_stub
    SceCommonDialog_stub SceAppUtil_stub ScePower_stub
    z
    ${EXTRA_LIBS}
    m c)
endfunction()

# Room for vita-elf-create: it appends its module tables (a few KB) right after the code segment, and the data segment
# starts at the next 64 KB boundary, so when the code happens to end just short of a boundary it fails ("Cannot
# allocate N bytes for SCE data at end of segment 0; segment 1 overlaps") - it comes and goes as the code grows.
# So: a probe link measures where the code ends, and the real link adds a read-only pad (src/sce_pad.cpp) that
# pushes the end past the boundary when the room is short. Always enough room, whatever the code size.
find_program(VITA_READELF arm-vita-eabi-readelf HINTS "$ENV{VITASDK}/bin")
add_executable(${PROJECT_NAME}_probe $<TARGET_OBJECTS:chl_objs> src/sce_pad.cpp)
chl_link(${PROJECT_NAME}_probe)
set(PAD_CPP ${CMAKE_CURRENT_BINARY_DIR}/sce_pad_gen.cpp)
add_custom_command(OUTPUT ${PAD_CPP}
  COMMAND ${CMAKE_COMMAND} -DELF=$<TARGET_FILE:${PROJECT_NAME}_probe> -DREADELF=${VITA_READELF} -DOUT=${PAD_CPP} -DSRC=${CMAKE_CURRENT_SOURCE_DIR}/src/sce_pad.cpp -P ${CMAKE_CURRENT_SOURCE_DIR}/tools/sce_pad.cmake
  DEPENDS ${PROJECT_NAME}_probe ${CMAKE_CURRENT_SOURCE_DIR}/tools/sce_pad.cmake ${CMAKE_CURRENT_SOURCE_DIR}/src/sce_pad.cpp
  COMMENT "Measuring the room after the code segment")
add_executable(${PROJECT_NAME} $<TARGET_OBJECTS:chl_objs> ${PAD_CPP})
chl_link(${PROJECT_NAME})

vita_create_self(eboot.bin ${PROJECT_NAME} UNSAFE)
# the art for the LiveArea and the font atlas come from the JS build's folder (shared, not copied)
set(V ${CMAKE_CURRENT_SOURCE_DIR}/../vita)
set(VPK_NAME CHL2026Native.vpk)
# music and sound effects: everything in assets/music and assets/sfx goes into the VPK as music/... and sfx/...
set(AUDIO_FILES)
foreach(dir music sfx)
  file(GLOB_RECURSE AF RELATIVE ${CMAKE_CURRENT_SOURCE_DIR}/../assets/${dir} ${CMAKE_CURRENT_SOURCE_DIR}/../assets/${dir}/*)
  foreach(f ${AF})
    if(NOT f MATCHES "(^|/)(README\\.md|\\.gitkeep|\\.DS_Store)$")
      list(APPEND AUDIO_FILES FILE ${CMAKE_CURRENT_SOURCE_DIR}/../assets/${dir}/${f} ${dir}/${f})
    endif()
  endforeach()
endforeach()
vita_create_vpk(${VPK_NAME} ${VITA_TITLEID} eboot.bin
  VERSION ${VITA_VERSION}
  NAME ${VITA_APP_NAME}
  FILE ${V}/sce_sys/icon0.png sce_sys/icon0.png
  FILE ${V}/sce_sys/livearea/contents/bg.png sce_sys/livearea/contents/bg.png
  FILE ${V}/sce_sys/livearea/contents/startup.png sce_sys/livearea/contents/startup.png
  FILE ${V}/sce_sys/livearea/contents/template.xml sce_sys/livearea/contents/template.xml
  FILE ${V}/assets/font.png font.png
  FILE ${V}/sce_sys/trophy/NPWR90226_00/TROPHY.TRP sce_sys/trophy/NPWR90226_00/TROPHY.TRP
  ${AUDIO_FILES})
# built from vita/CMakeLists.txt (the old "cmake -S vita" workflow step): put the VPK where that build looks for it too
if(NOT CMAKE_CURRENT_BINARY_DIR STREQUAL CMAKE_BINARY_DIR)
  # (depends on the VPK file itself, whatever VitaSDK names the target that makes it)
  add_custom_command(OUTPUT ${CMAKE_BINARY_DIR}/${VPK_NAME}
    COMMAND ${CMAKE_COMMAND} -E copy ${CMAKE_CURRENT_BINARY_DIR}/${VPK_NAME} ${CMAKE_BINARY_DIR}/${VPK_NAME}
    DEPENDS ${CMAKE_CURRENT_BINARY_DIR}/${VPK_NAME})
  add_custom_target(chl_vpk_copy ALL DEPENDS ${CMAKE_BINARY_DIR}/${VPK_NAME})
  foreach(t ${VPK_NAME} ${VPK_NAME}-vpk ${PROJECT_NAME}.vpk-vpk)
    if(TARGET ${t})
      add_dependencies(chl_vpk_copy ${t})
    endif()
  endforeach()
endif()

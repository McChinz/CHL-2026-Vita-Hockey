cmake_minimum_required(VERSION 3.16)
# CHL 2026 NATIVE - the C++ build of the game (no JavaScript engine). Separate app from the JS build:
# its own title ID and data folder, so both can be installed at the same time.
#
#   Vita:  cmake -S cpp -B build-native && cmake --build build-native      (needs VitaSDK, like the JS build)
#   PC test build (software renderer, scripted input):  cmake -S cpp -B build-host -DHOST=ON && cmake --build build-host

option(HOST "Build the desktop test version instead of the Vita app" OFF)

if(NOT HOST AND NOT DEFINED CMAKE_TOOLCHAIN_FILE)
  if(DEFINED ENV{VITASDK})
    set(CMAKE_TOOLCHAIN_FILE "$ENV{VITASDK}/share/vita.toolchain.cmake" CACHE PATH "toolchain file")
  else()
    message(FATAL_ERROR "Please install VitaSDK and set the VITASDK environment variable (or pass -DHOST=ON for the PC test build).")
  endif()
endif()

project(CHL2026Native CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

set(GAME_SRC
  src/canvas.cpp src/audio.cpp src/json.cpp src/data.cpp src/league.cpp src/menu.cpp src/ut.cpp src/ut_draw.cpp src/save.cpp
  src/sk_core.cpp src/sk_play.cpp src/sk_flow.cpp
  src/sk_draw.cpp src/sk_draw3d.cpp src/hud.cpp src/ui.cpp src/main.cpp)

if(HOST)
  add_executable(chl_host ${GAME_SRC} src/platform_host.cpp src/test_main.cpp)
  target_compile_definitions(chl_host PRIVATE HOST_BUILD)
  target_compile_options(chl_host PRIVATE -O2 -Wall -Wno-misleading-indentation)
  target_link_libraries(chl_host z)   # the textures are stored compressed
  return()
endif()

include("$ENV{VITASDK}/share/vita.cmake" REQUIRED)
set(VITA_APP_NAME "CHL 2026 NATIVE")
set(VITA_TITLEID  "GOAL00002")
set(VITA_VERSION  "00.01")

# the renderer: vitaGL (default: GPU 3D with a depth buffer, 4x MSAA) or vita2d (-DRENDERER=vita2d, the fallback)
set(RENDERER "vitagl" CACHE STRING "vitagl or vita2d")
if(RENDERER STREQUAL "vita2d")
  add_executable(${PROJECT_NAME} ${GAME_SRC} src/vita_sys.cpp src/platform_vita.cpp)
else()
  add_executable(${PROJECT_NAME} ${GAME_SRC} src/vita_sys.cpp src/platform_vitagl.cpp)
endif()
# -O3, no errno from maths calls, fused multiply-add, NEON and tuned for the Vita's Cortex-A9
target_compile_options(${PROJECT_NAME} PRIVATE -O3 -fno-math-errno -ffp-contract=fast -mtune=cortex-a9 -mfpu=neon -Wall -Wno-misleading-indentation -Wno-psabi -fno-strict-aliasing)
# optional stubs: linked only if this VitaSDK has them, so a renamed or missing one can't break the build
set(OPTIONAL_LIBS SceAppMgr_stub SceKernelDmacMgr_stub SceSharedFb_stub SceRtc_stub)
set(EXTRA_LIBS "")
foreach(lib ${OPTIONAL_LIBS})
  find_library(FOUND_${lib} ${lib})
  if(FOUND_${lib})
    list(APPEND EXTRA_LIBS ${FOUND_${lib}})
  endif()
endforeach()
if(RENDERER STREQUAL "vita2d")
  target_link_libraries(${PROJECT_NAME}
    vita2d
    SceDisplay_stub SceGxm_stub SceSysmodule_stub SceCtrl_stub SceTouch_stub SceAudio_stub
    ScePgf_stub ScePvf_stub SceCommonDialog_stub SceAppUtil_stub ScePower_stub
    freetype png jpeg z
    ${EXTRA_LIBS}
    m c)
else()
  # vitaGL and its shader compiler stack (vdpm: vitaGL vitaShaRK SceShaccCgExt libmathneon taihen)
  set(GL_OPTIONAL SceIme_stub SceShaccCg_stub SceRazorCapture_stub SceLibKernel_stub)
  foreach(lib ${GL_OPTIONAL})
    find_library(FOUND_${lib} ${lib})
    if(FOUND_${lib})
      list(APPEND EXTRA_LIBS ${FOUND_${lib}})
    endif()
  endforeach()
  target_link_libraries(${PROJECT_NAME}
    vitaGL vitashark SceShaccCgExt mathneon taihen_stub
    SceDisplay_stub SceGxm_stub SceSysmodule_stub SceCtrl_stub SceTouch_stub SceAudio_stub
    SceCommonDialog_stub SceAppUtil_stub ScePower_stub
    z
    ${EXTRA_LIBS}
    m c)
endif()

vita_create_self(eboot.bin ${PROJECT_NAME} UNSAFE)
# the art for the LiveArea and the font atlas come from the JS build's folder (shared, not copied)
set(V ${CMAKE_SOURCE_DIR}/../vita)
if(RENDERER STREQUAL "vita2d")
  set(VPK_NAME CHL2026Native-vita2d.vpk)
else()
  set(VPK_NAME CHL2026Native.vpk)
endif()
vita_create_vpk(${VPK_NAME} ${VITA_TITLEID} eboot.bin
  VERSION ${VITA_VERSION}
  NAME ${VITA_APP_NAME}
  FILE ${V}/sce_sys/icon0.png sce_sys/icon0.png
  FILE ${V}/sce_sys/livearea/contents/bg.png sce_sys/livearea/contents/bg.png
  FILE ${V}/sce_sys/livearea/contents/startup.png sce_sys/livearea/contents/startup.png
  FILE ${V}/sce_sys/livearea/contents/template.xml sce_sys/livearea/contents/template.xml
  FILE ${V}/assets/font.png font.png)

// emblem.h - every team's emblem: an original badge (circle, shield, hexagon, diamond or square) with a symbol on it,
// in the team's colours. The 32 NHL clubs each have a hand-picked one; any other team (AHL, Ultimate Franchise
// clubs and opponents) gets one picked from its letters. Drawn in 2D (menus, the scorebug) and on the jerseys in 3D.
#pragma once
#include <string>
#include <vector>
#include "canvas.h"

// a triangle in the emblem's own space (-1..1, y up) and which colour it takes: 0 the team colour, 1 its second
// colour, 2 the light (the symbol), 3 a dark shade (rims, facets)
struct ETri { float x[3], y[3]; unsigned char c; };
const std::vector<ETri> &emblemTris(const std::string &key);
// the four colours an emblem is painted in, from a team's two colours
void emblemCols(Col prim, Col sec, Col out[4]);
// 2D: the emblem centred at (cx, cy), r its radius. key: the team's abbreviation (EDM) or, failing that, its name
void drawEmblem(const std::string &key, double cx, double cy, double r, Col prim, Col sec, double alpha = 1);

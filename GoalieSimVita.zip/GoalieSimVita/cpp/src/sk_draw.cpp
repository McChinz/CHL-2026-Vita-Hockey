// CHL 2026 native - drawing the forward game: the rink and the arena (vertical rink, 3/4 view), the skater and
// goalie figures, nets, puck, effects, and the game-time HUD. Ported from the web build's renderer.
#include "game.h"
#include "sk_int.h"
extern bool g_view3d; Pt sk3Proj(double x, double y, double z); double sk3Scale(double x, double y, double z); void skDraw3D();

// screen y just over a player's head (labels, perk pop-ups, pass buttons)
static double headY(const Layout &lay, double x, double y);
static Grad linear(double x0, double y0, double x1, double y1) { Grad g; g.kind = 0; g.a[0] = x0; g.a[1] = y0; g.a[2] = x1; g.a[3] = y1; return g; }
static Grad radial(double x0, double y0, double r0, double x1, double y1, double r1) { Grad g; g.kind = 1; g.a[0] = x0; g.a[1] = y0; g.a[2] = r0; g.a[3] = x1; g.a[4] = y1; g.a[5] = r1; return g; }
void cached(const Key &k, const std::function<void()> &fn) { ctx.cacheBlock(k, fn); }
void cachedScaled(const Key &k, double s, const std::function<void()> &fn) { ctx.cacheBlockScaled(k, (float)s, fn); }
static double fr15(double f) { return std::pow(1.5, std::round(std::log(std::max(1e-3, f)) / std::log(1.5))); }
double SKF_cnt = 0;
extern double skHint;

static double headY(const Layout &lay, double x, double y) { return g_view3d ? sk3Proj(x, y, 7.4).y : skW2S(lay, x, y).y - 5.8 * lay.s * SK_SPR; }
Layout skLayout() {
  double top = safeTop + .17 * U + 12, bot = 6, availH = H - top - bot, cx = W / 2, cy = top + availH / 2;
  double s = std::min((W - 8) / (RK.Wd + 12), availH / (56 * SK_K)), k = SK_K;
  return {s, k, top, availH / (s * k), W / s, cx, cy};
}
Pt skCamClamp(const Layout &lay, double x, double y) {
  double hl = lay.viewLen / 2, hw = lay.viewWid / 2;
  return {lay.viewLen >= RK.L + 30 ? RK.L / 2 : clamp(x, hl - 14, RK.L - hl + 20), lay.viewWid >= RK.Wd + 4 ? RK.Wd / 2 : clamp(y, hw - 6, RK.Wd - hw + 6)};
}
Pt skW2S(const Layout &lay, double x, double y, double z) {
  if (g_view3d && SK) return sk3Proj(x, y, z);
  double cx = SK ? SK->cam : RK.L / 2, cy = SK ? SK->camY : RK.Wd / 2;
  return {lay.cx + (y - cy) * lay.s, lay.cy - (x - cx) * lay.s * lay.k - z * lay.s};
}
static void skWorld(const Layout &lay, double cam, double camY) {
  ctx.translate(lay.cx, lay.cy); ctx.scale(1, lay.k); ctx.translate(-camY * lay.s, cam * lay.s); ctx.rotate(-PI / 2); ctx.scale(lay.s, lay.s);
}
static void skRinkShape(double dx) {
  const double L = RK.L, Wd = RK.Wd, r = RK.cr;
  ctx.beginPath(); ctx.moveTo(r + dx, 0); ctx.arcTo(L + dx, 0, L + dx, Wd, r); ctx.arcTo(L + dx, Wd, dx, Wd, r); ctx.arcTo(dx, Wd, dx, 0, r); ctx.arcTo(dx, 0, L + dx, 0, r); ctx.closePath();
}
// part: 0 = the arena backdrop, 1 = a band of the crowd (x0..x1), 2 = glass, boards, ice and markings
static void skDrawRink(int part, double bx0 = 0, double bx1 = 0) {
  const double L = RK.L, Wd = RK.Wd, cy = RK.cy, K = SK_K;
  if (part == 0) { ctx.fill("#161d2b"); ctx.fillRect(-60, -70, L + 120, Wd + 140); }
  if (part == 1) {
    SkRng R(1234);
    static const char *shirts[12] = {"#ef4444", "#f8fafc", "#3b82f6", "#facc15", "#64748b", "#1e293b", "#f97316", "#22c55e", "#e2e8f0", "#7c3aed", "#dc2626", "#0ea5e9"};
    static const char *skin[4] = {"#f2c79b", "#e0a878", "#c68642", "#8d5524"};
    auto seats = [&](double x0, double x1, double y0, double y1, bool vert) {
      double r0 = vert ? x0 : y0, r1 = vert ? x1 : y1;
      for (double r = r0; r < r1; r += 2.8) {
        double a0 = vert ? y0 : x0, a1 = vert ? y1 : x1;
        for (double a = a0; a < a1; a += 2.6) { if (R() < .22) continue;
          double px = vert ? r + .5 : a + R() * .4, py = vert ? a + R() * .4 : r + .5;
          double sc = R(), sk = R();
          if (px < bx0 || px >= bx1) continue;
          ctx.fill(sk < .5 ? shirts[(int)(sc * 12)] : skin[(int)(sk * 4)]); ctx.fillRect(px, py, vert ? 1.9 : 1.7, vert ? 1.7 : 1.9); }
      }
    };
    seats(-22, L + 26, -20, -2.5, false); seats(-22, L + 26, Wd + 2.5, Wd + 20, false);
    seats(L + 10, L + 34, -6, Wd + 6, true); seats(-30, -8, -6, Wd + 6, true);
    return;
  }
  if (part == 0) {   // seat rows under the fans
    auto rows = [&](double x0, double x1, double y0, double y1, bool vert) {
      double r0 = vert ? x0 : y0, r1 = vert ? x1 : y1;
      for (double r = r0; r < r1; r += 2.8) { ctx.fill(((int)(r / 2.8)) % 2 ? "#273449" : "#1f2a3d"); if (vert) ctx.fillRect(r, y0, 2.8, y1 - y0); else ctx.fillRect(x0, r, x1 - x0, 2.8); } };
    rows(-22, L + 26, -20, -2.5, false); rows(-22, L + 26, Wd + 2.5, Wd + 20, false); rows(L + 10, L + 34, -6, Wd + 6, true); rows(-30, -8, -6, Wd + 6, true);
    return;
  }
  // glass (behind the boards) then the boards: shifted up-ice, so only the far side shows a face
  ctx.fill(rgba(200, 225, 245, .28)); skRinkShape((SK_BH + SK_GH) / K); ctx.fillPath();
  ctx.stroke(rgba(255, 255, 255, .65)); ctx.lineWidth(.3); skRinkShape((SK_BH + SK_GH) / K); ctx.strokePath();
  ctx.fill("#d9e3ee"); skRinkShape(SK_BH / K); ctx.fillPath();
  ctx.stroke("#475569"); ctx.lineWidth(.55); skRinkShape(SK_BH / K); ctx.strokePath();
  ctx.fill("#e4edf5"); skRinkShape(0); ctx.fillPath();
  { SkRng R(99); ctx.stroke(rgba(148, 163, 184, .22)); ctx.lineWidth(.12);
    for (int i = 0; i < 28; i++) { double x = 6 + R() * (L - 12), y = 4 + R() * (Wd - 8), a = R() * 6.3, l = 2 + R() * 6; ctx.line(x, y, x + std::cos(a) * l, y + std::sin(a) * l); } }
  for (double lx : {.16, .38, .62, .84}) for (double ly : {.27, .73}) {
    ctx.save(); ctx.translate(L * lx, Wd * ly); ctx.scale(1.5, 1);
    for (auto ra : {std::make_pair(11.0, .5), std::make_pair(4.5, .4)}) { Grad g = radial(0, 0, 0, 0, 0, ra.first); g.add(0, rgba(255, 255, 255, ra.second)); g.add(1, rgba(255, 255, 255, 0)); ctx.fill(g); ctx.disc(0, 0, ra.first); }
    ctx.restore(); }
  ctx.fill(rgba(96, 165, 250, .5));
  ctx.beginPath(); ctx.arc(RK.gl, cy, 6, -PI / 2, PI / 2); ctx.fillPath();
  ctx.beginPath(); ctx.arc(L - RK.gl, cy, 6, PI / 2, PI * 1.5); ctx.fillPath();
  ctx.stroke(rgba(210, 40, 40, .75)); ctx.lineWidth(.2);
  ctx.beginPath(); ctx.arc(RK.gl, cy, 6, -PI / 2, PI / 2); ctx.strokePath();
  ctx.beginPath(); ctx.arc(L - RK.gl, cy, 6, PI / 2, PI * 1.5); ctx.strokePath();
  ctx.fill(rgba(210, 40, 40, .75)); ctx.fillRect(L / 2 - .5, 0, 1, Wd);
  ctx.fill(rgba(255, 255, 255, .55)); for (double y = 1; y < Wd; y += 3) ctx.fillRect(L / 2 - .12, y, .24, 1.4);
  ctx.fill(rgba(30, 80, 200, .75)); ctx.fillRect(75 - .6, 0, 1.2, Wd); ctx.fillRect(L - 75 - .6, 0, 1.2, Wd);
  ctx.fill(rgba(210, 40, 40, .6)); ctx.fillRect(RK.gl - .15, 4, .3, Wd - 8); ctx.fillRect(L - RK.gl - .15, 4, .3, Wd - 8);
  ctx.lineWidth(.35); ctx.stroke(rgba(30, 80, 200, .75)); ctx.ring(L / 2, cy, 15);
  ctx.fill("#dfe8f1"); ctx.disc(L / 2, cy, 7);
  ctx.stroke(rgba(15, 23, 42, .25)); ctx.lineWidth(.4); ctx.ring(L / 2, cy, 7);
  ctx.fill(rgba(30, 80, 200, .85)); ctx.disc(L / 2, cy, .6);
  ctx.stroke(rgba(210, 40, 40, .65));
  for (double x : {31.0, L - 31}) for (double y : {cy - 22, cy + 22}) {
    ctx.lineWidth(.35); ctx.ring(x, y, 15);
    ctx.fill(rgba(210, 40, 40, .8)); ctx.disc(x, y, 1);
    ctx.lineWidth(.3); for (int sx : {-1, 1}) for (int sy : {-1, 1}) { ctx.line(x + sx * 1.5, y + sy * 15, x + sx * 1.5, y + sy * 17);
      ctx.beginPath(); ctx.moveTo(x + sx * 2, y + sy * 1); ctx.lineTo(x + sx * 4, y + sy * 1); ctx.lineTo(x + sx * 4, y + sy * 3.5); ctx.strokePath(); }
  }
  for (double x : {80.0, L - 80}) for (double y : {cy - 22, cy + 22}) { ctx.fill(rgba(210, 40, 40, .8)); ctx.disc(x, y, 1); }
  ctx.lineWidth(.45); ctx.stroke("#f2c94c"); skRinkShape(0); ctx.strokePath();
}
static const char *SK_ADS[14][3] = {{"CHL 2026", "#0f172a", "#facc15"}, {"FROSTBITE COLA", "#b91c1c", "#fff"}, {"ICE TIME", "#1d4ed8", "#fff"}, {"SNIPER SPORTS", "#065f46", "#d1fae5"}, {"PUCK & PINT", "#7c2d12", "#fde68a"}, {"NORTH POLE BANK", "#f8fafc", "#1e3a8a"},
  {"BLUE LINE AUTO", "#1e3a8a", "#e0f2fe"}, {"TOP SHELF PIZZA", "#f59e0b", "#1c1917"}, {"GLACIER WATER", "#e0f2fe", "#0369a1"}, {"HAT TRICK HARDWARE", "#111827", "#f87171"}, {"BREAKAWAY BURGERS", "#dc2626", "#fef3c7"}, {"FIVE HOLE FITNESS", "#7c3aed", "#fff"}, {"CREASE CREDIT UNION", "#047857", "#fff"}, {"ONE TIMER COFFEE", "#44403c", "#fde68a"}};
static void skDrawSideAds(const Layout &lay) {
  double s = lay.s; int w = (int)std::round(1.7 * s); if (w < 6) return;
  const int n = 6; double x0 = RK.cr + 4, len = (RK.L - 2 * RK.cr - 8) / n;
  for (int side = 0; side < 2; side++) for (int i = 0; i < n; i++) {
    double xa = x0 + i * len + 1, xb = xa + len - 2; Pt top = skW2S(lay, xb, side ? RK.Wd : 0), bot = skW2S(lay, xa, side ? RK.Wd : 0); int h = (int)std::round(bot.y - top.y);
    if (bot.y < 0 || top.y > H || h < 12) continue; const char *const *a = SK_ADS[(i * 2 + side * 5 + 3) % 14];
    ctx.save(); ctx.translate(std::round(side ? top.x - w : top.x), std::round(top.y));
    cached(Key("skside") << a[0] << w << h, [&] {
      ctx.fill(a[1]); ctx.fillRect(0, 0, w, h); ctx.fill(rgba(0, 0, 0, .18)); ctx.fillRect(side ? 0 : w - 2, 0, 2, h);
      std::string t; for (const char *c = a[0]; *c; c++) if (*c != ' ') t += *c;
      double fs = std::min(w * .78, h / (t.size() + .6));
      ctx.fill(a[2]); ctx.font(fs); ctx.textMid();
      double y0 = (h - fs * t.size()) / 2 + fs / 2; for (size_t k = 0; k < t.size(); k++) ctx.fillText(std::string(1, t[k]), w / 2.0, y0 + k * fs); });
    ctx.restore(); }
}
static void skDrawAds(const Layout &lay) {
  Pt b = skW2S(lay, RK.L, 0); double s = lay.s, hb = SK_BH * s;
  if (b.y < -hb * 2 || b.y > H + hb) return;
  ctx.save(); ctx.translate(b.x, b.y);
  cached(Key("skads") << s, [&] {
    double x0 = (RK.cr - 8) * s, x1 = (RK.Wd - RK.cr + 8) * s, w = (x1 - x0) / 4;
    for (int i = 0; i < 4; i++) { const char *const *a = SK_ADS[i]; double x = x0 + i * w;
      ctx.fill(a[1]); ctx.fillRect(x + .2 * s, -hb * .86, w - .4 * s, hb * .62);
      ctx.fill(a[2]); ctx.font(hb * .3); ctx.textMid(); ctx.fillText(a[0], x + w / 2, -hb * .55);
      ctx.alpha(.13); ctx.fill(a[1]); ctx.fillRect(x + .2 * s, hb * .06, w - .4 * s, hb * .34);
      ctx.save(); ctx.translate(x + w / 2, hb * .2); ctx.scale(1, -.55); ctx.fill(a[2]); ctx.fillText(a[0], 0, 0); ctx.restore(); ctx.alpha(1); } });
  ctx.restore();
}

// ----- figures. Everything is in screen pixels around the feet; f = pixels per foot.
// d: facing (0..7, 0 = screen right, 2 = toward the camera, 6 = away), stride -1..1
struct FigO { double f = 10; int d = 0; double stride = 0; Col col, stripe, skin, helm, pants, sock, glove; bool star = false, ref = false, rh = false, hasPants = false, hasSock = false, hasGlove = false;
  double lean = .25, pk = 0, wind = 0, load = 0, fol = 0, dkL = 0, dkF = 0, chz = 0; int arm = 0, drop = 0; };
static void skFig(const FigO &o) {
  const double f = o.f, K = SK_K, th = o.d * PI / 4, fx = std::cos(th), fy = std::sin(th);
  double rx = -fy, ry = fx, lx = fy, ly = -fx;
  const double wrx = rx, wry = ry;
  if (o.rh) { std::swap(rx, lx); std::swap(ry, ly); }
  auto P = [&](double gx, double gy, double z) { return Pt{gx * f, (gy * K - z) * f}; };
  double lean = o.lean + o.load * .75; double sh[2] = {fx * (.25 + lean * .6), fy * (.25 + lean * .6)};
  double st = o.stride, pk = o.pk, wd = o.wind, fo = o.fol;
  const Col out = hex("#0f172a"); double ow = .07 * f;
  Col pants = o.hasPants ? o.pants : shade(o.col, -.55), sock = o.hasSock ? o.sock : o.col, glove = o.hasGlove ? o.glove : shade(o.col, -.35);
  { ctx.save(); ctx.scale(1, .43); Grad g = radial(0, 0, 0, 0, 0, 1.15 * f); g.add(0, rgba(15, 23, 42, .34)); g.add(1, rgba(15, 23, 42, 0)); ctx.fill(g); ctx.disc(0, 0, 1.15 * f); ctx.restore(); }
  auto lit = [&](Col c, double x0, double x1) { Grad g = linear(x0, 0, x1, 0); g.add(0, shade(c, .16)); g.add(.55, c); g.add(1, shade(c, -.3)); return g; };
  std::vector<std::pair<double, std::function<void()>>> parts; Pt HEADcs{0, 0}; double HEADyS = 0;
  auto limb = [&](Pt a, Pt b, double w0, double w1, Col c, bool cap) {
    double dx = b.x - a.x, dy = b.y - a.y, L = hyp(dx, dy); if (!L) L = 1; double nx = -dy / L, ny = dx / L;
    ctx.fill(c); ctx.beginPath(); ctx.moveTo(a.x + nx * w0 / 2, a.y + ny * w0 / 2); ctx.lineTo(b.x + nx * w1 / 2, b.y + ny * w1 / 2); ctx.lineTo(b.x - nx * w1 / 2, b.y - ny * w1 / 2); ctx.lineTo(a.x - nx * w0 / 2, a.y - ny * w0 / 2); ctx.closePath(); ctx.fillPath();
    if (cap) ctx.disc(b.x, b.y, w1 / 2); };
  for (int sd : {-1, 1}) {
    double px = sd < 0 ? lx : rx, py = sd < 0 ? ly : ry, fw = sd * st * .6, lift = std::max(0.0, -sd * st) * .45;
    double foot[2] = {px * .4 + fx * fw, py * .4 + fy * fw}, knee[2] = {px * .32 + fx * (fw * .55 + .34 + lean * .25), py * .32 + fy * (fw * .55 + .34 + lean * .25)}, hip[2] = {px * .27 + sh[0] * .3, py * .27 + sh[1] * .3};
    double F0 = foot[0], F1 = foot[1], K0 = knee[0], K1 = knee[1], H0 = hip[0], H1 = hip[1];
    parts.push_back({foot[1], [=, &o] {
      Pt F = P(F0, F1, .32 + lift), Kn = P(K0, K1, 1.08 + lift * .6), Hp = P(H0, H1, 2.1);
      ctx.lineCap(CAP_BUTT);
      limb(Hp, Kn, .7 * f, .52 * f, shade(pants, sd < 0 ? .06 : -.08), true);
      limb(Kn, {F.x, F.y - .12 * f}, .46 * f, .34 * f, shade(sock, sd < 0 ? .05 : -.1), false);
      ctx.fill(shade(sock, -.18)); ctx.oval(Kn.x, Kn.y + .04 * f, .24 * f, .17 * f);
      ctx.stroke(o.ref ? hex("#111827") : o.stripe); ctx.lineWidth(.12 * f); { double mx = (Kn.x * 2 + F.x) / 3, my = (Kn.y * 2 + F.y) / 3; ctx.line(mx - .17 * f, my, mx + .17 * f, my); }
      double sa = std::atan2(fy * K, fx); Pt B = P(F0, F1, lift);
      ctx.fill("#111827"); ctx.oval(B.x + fx * .1 * f, B.y - .2 * f, (.3 + .18 * std::fabs(fx)) * f, .2 * f);
      ctx.fill(rgba(255, 255, 255, .22)); ctx.oval(B.x + fx * .1 * f - .08 * f, B.y - .27 * f, (.14 + .08 * std::fabs(fx)) * f, .06 * f);
      ctx.fill("#e5e7eb"); ctx.fillRect(B.x - (.16 + .2 * std::fabs(fx)) * f, B.y - .06 * f, (.32 + .4 * std::fabs(fx)) * f, .06 * f);
      ctx.stroke("#cbd5e1"); ctx.lineWidth(.07 * f); ctx.line(B.x - std::cos(sa) * .42 * f, B.y - std::sin(sa) * .42 * f * .5, B.x + std::cos(sa) * .48 * f, B.y + std::sin(sa) * .48 * f * .5);
    }});
  }
  auto lerp = [](double a, double b, double t) { return a + (b - a) * t; };
  double bl[3] = {lx * .75 + fx * (1.9 + pk * 1.6), ly * .75 + fy * (1.9 + pk * 1.6), 0};
  if (o.dkL || o.dkF) { double v = o.dkL, a = v * (((v > 0) != o.rh) ? 1.77 : .35), b = o.dkF; bl[0] += wrx * a + fx * b; bl[1] += wry * a + fy * b; }
  if (o.chz) { bl[0] *= .85; bl[1] *= .85; bl[2] = o.chz; }
  double h1[3] = {rx * .16 + fx * (.55 + pk * .5) + sh[0] * .5, ry * .16 + fy * (.55 + pk * .5) + sh[1] * .5, 2.3 - pk * .3}, h2[3] = {lx * .38 + fx * (.9 + pk * .9) + sh[0] * .4, ly * .38 + fy * (.9 + pk * .9) + sh[1] * .4, 2.0 - pk * .4};
  auto blend3 = [&](double *v, const double *T, double t) { for (int i = 0; i < 3; i++) v[i] = lerp(v[i], T[i], t); };
  if (wd > 0) { double B[3] = {lx * 1.05 - fx * 1.5, ly * 1.05 - fy * 1.5, 6.3}, A[3] = {rx * .3 - fx * .15, ry * .3 - fy * .15, 4.25}, C[3] = {lx * .45 - fx * .45, ly * .45 - fy * .45, 3.6}; blend3(bl, B, wd); blend3(h1, A, wd); blend3(h2, C, wd); }
  double ld = o.load;
  if (ld > 0) { double B[3] = {lx * 1.25 - fx * .35, ly * 1.25 - fy * .35, 0}, A[3] = {rx * .12 + fx * .75, ry * .12 + fy * .75, 2.05}, C[3] = {lx * .5 + fx * .6, ly * .5 + fy * .6, 1.55}; blend3(bl, B, ld); blend3(h1, A, ld); blend3(h2, C, ld); }
  if (fo > 0) { double B[3] = {lx * .1 + fx * 2.7, ly * .1 + fy * 2.7, .3 + 2.6 * fo}, A[3] = {rx * .05 + fx * 1.05, ry * .05 + fy * 1.05, 3.25}, C[3] = {lx * .05 + fx * 1.7, ly * .05 + fy * 1.7, 2.6 + .6 * fo}; blend3(bl, B, std::min(1.0, fo * 1.3)); blend3(h1, A, fo); blend3(h2, C, fo); }
  if (o.ref) { if (o.arm) { h1[0] = rx * .42 + sh[0]; h1[1] = ry * .42 + sh[1]; h1[2] = 5.7; } else if (o.drop) { h1[0] = rx * .12 + fx * 1.55; h1[1] = ry * .12 + fy * 1.55; h1[2] = 3.15; } else { h1[0] = rx * .62 + sh[0] * .5; h1[1] = ry * .62 + sh[1] * .5; h1[2] = 1.95; }
    h2[0] = lx * .62 + sh[0] * .5; h2[1] = ly * .62 + sh[1] * .5; h2[2] = 1.95; }
  if (!o.ref) { double t = wd > 0 ? .3 : ld > 0 ? .52 : .4; for (int i = 0; i < 3; i++) h2[i] = h1[i] + (bl[i] - h1[i]) * t; }
  auto shoulder = [&](int sd, double *S) { double px = sd < 0 ? lx : rx, py = sd < 0 ? ly : ry; S[0] = px * .8 + sh[0]; S[1] = py * .8 + sh[1]; S[2] = 3.6; };
  double B0 = bl[0], B1 = bl[1], B2 = bl[2], A0 = h1[0], A1 = h1[1], A2 = h1[2];
  if (!o.ref) parts.push_back({(bl[1] + h2[1]) * .5, [=] {
    Pt T = P(A0 + (A0 - B0) * .09, A1 + (A1 - B1) * .09, A2 + (A2 - B2) * .09), Bh = P(B0, B1, B2), toe = P(B0 + lx * .85 + fx * .12, B1 + ly * .85 + fy * .12, B2);
    ctx.lineCap(CAP_BUTT);
    ctx.stroke("#1f2937"); ctx.lineWidth(.2 * f); ctx.line(T.x, T.y, Bh.x, Bh.y);
    ctx.stroke("#e5e7eb"); ctx.lineWidth(.17 * f); ctx.line(T.x, T.y, T.x + (Bh.x - T.x) * .12, T.y + (Bh.y - T.y) * .12);
    ctx.stroke("#111827"); ctx.lineWidth(.3 * f); ctx.line(Bh.x, Bh.y, toe.x, toe.y);
    ctx.stroke("#f8fafc"); ctx.lineWidth(.12 * f); ctx.line((Bh.x * 2 + toe.x) / 3, (Bh.y * 2 + toe.y) / 3, toe.x, toe.y);
  }});
  bool behind = fy < -.3 && !o.ref && !wd;
  if (behind) for (int sd : {-1, 1}) { double S[3]; shoulder(sd, S); double px = sd < 0 ? lx : rx, py = sd < 0 ? ly : ry;
    parts.push_back({50, [=, &o] { Pt a = P(S[0], S[1], S[2]), e = P(S[0] + px * .15, S[1] + py * .15, 2.35);
      limb(a, e, .5 * f, .42 * f, out, true); limb(a, e, .4 * f, .32 * f, shade(o.col, sd < 0 ? .08 : -.1), true);
      ctx.fill(shade(o.col, .05)); ctx.disc(a.x, a.y, .27 * f); }}); }
  for (int sd : {-1, 1}) { if (behind) continue; double S[3]; shoulder(sd, S); const double *Hd0 = sd > 0 ? h1 : h2; double Hd[3] = {Hd0[0], Hd0[1], Hd0[2]};
    parts.push_back({(S[1] + Hd[1]) * .5 + .01, [=, &o] {
      double pxx = sd < 0 ? lx : rx, pyy = sd < 0 ? ly : ry; Pt a = P(S[0], S[1], S[2]), b = P(Hd[0], Hd[1], Hd[2]), e = P((S[0] + Hd[0]) / 2 + pxx * .32, (S[1] + Hd[1]) / 2 + pyy * .32, (S[2] + Hd[2]) / 2 - .3);
      limb(a, e, .5 * f, .4 * f, out, true); limb(e, b, .4 * f, .33 * f, out, false);
      Col ac = shade(o.col, sd < 0 ? .08 : -.1); limb(a, e, .4 * f, .3 * f, ac, true); limb(e, b, .3 * f, .24 * f, ac, false);
      ctx.fill(shade(o.col, .05)); ctx.disc(a.x, a.y, .27 * f);
      ctx.stroke(o.stripe); ctx.lineWidth(.1 * f); { double mx = (a.x + e.x * 2) / 3, my = (a.y + e.y * 2) / 3; ctx.line(mx - .12 * f, my - .05 * f, mx + .12 * f, my + .05 * f); }
      ctx.fill(o.ref ? hex("#111827") : shade(o.col, -.1)); ctx.disc(e.x, e.y, .21 * f);
      ctx.fill(glove); ctx.disc(b.x, b.y, .26 * f); ctx.stroke(out); ctx.lineWidth(ow); ctx.ring(b.x, b.y, .26 * f);
      if (!o.ref) { ctx.stroke(o.stripe); ctx.lineWidth(.07 * f); ctx.beginPath(); ctx.arc(b.x, b.y, .2 * f, PI * .15, PI * .85); ctx.strokePath(); }
    }}); }
  parts.push_back({0, [&] {
    double c = P(sh[0] * .3, sh[1] * .3, 0).x; Pt cs = P(sh[0], sh[1], 0); double wS = (.68 + .36 * std::fabs(fy)) * f, wH = (.46 + .24 * std::fabs(fy)) * f;
    double yH = -2.2 * f + P(0, sh[1] * .3, 0).y, yS = -3.95 * f + cs.y, yP = -1.5 * f;
    ctx.fill(lit(pants, c - wH, c + wH)); ctx.beginPath(); ctx.moveTo(c - wH, yH - .1 * f); ctx.lineTo(c + wH, yH - .1 * f); ctx.lineTo(c + wH * .95, yP); ctx.lineTo(c - wH * .95, yP); ctx.closePath(); ctx.fillPath();
    ctx.stroke(out); ctx.lineWidth(ow); ctx.strokePath();
    ctx.fill(lit(o.col, std::min(cs.x, c) - wS, std::max(cs.x, c) + wS)); ctx.beginPath(); ctx.moveTo(cs.x - wS, yS + .15 * f); ctx.lineTo(cs.x - wS * .75, yS - .12 * f); ctx.lineTo(cs.x + wS * .75, yS - .12 * f); ctx.lineTo(cs.x + wS, yS + .15 * f); ctx.lineTo(c + wH * 1.08, yH); ctx.lineTo(c - wH * 1.08, yH); ctx.closePath(); ctx.fillPath();
    ctx.stroke(out); ctx.lineWidth(ow); ctx.strokePath();
    if (o.ref) { ctx.fill("#111827"); for (int k = -2; k <= 2; k++) { double t0 = k / 5.2, xa = cs.x + t0 * wS * 1.6, xb = c + t0 * wH * 1.9; ctx.quad(xa - .08 * f, yS - .05 * f, xa + .08 * f, yS - .05 * f, xb + .08 * f, yH, xb - .08 * f, yH); } }
    else { ctx.fill(o.stripe); double sy0 = yH - .55 * f;
      ctx.quad(c - wH * 1.06, sy0, c + wH * 1.06, sy0, c + wH * 1.07, sy0 + .22 * f, c - wH * 1.07, sy0 + .22 * f);
      ctx.quad(cs.x - wS * .78, yS - .08 * f, cs.x + wS * .78, yS - .08 * f, cs.x + wS * .85, yS + .3 * f, cs.x - wS * .85, yS + .3 * f);
      if (fy > .3) { ctx.fill(o.stripe); ctx.disc((cs.x + c) / 2, (yS + yH) / 2 + .05 * f, .27 * f); ctx.fill(o.col); ctx.disc((cs.x + c) / 2, (yS + yH) / 2 + .05 * f, .15 * f); } }
    HEADcs = cs; HEADyS = yS;
  }});
  parts.push_back({99, [&] {
    Pt cs = HEADcs; double yS = HEADyS, hx = cs.x + fx * .08 * f + o.lean * fx * .2 * f, hy = yS - .66 * f, hr = .47 * f;
    ctx.fill(shade(o.skin, -.12)); ctx.fillRect(hx - .13 * f, hy + .18 * f, .26 * f, .42 * f);
    ctx.fill(lit(o.helm, hx - hr, hx + hr)); ctx.disc(hx, hy, hr); ctx.stroke(out); ctx.lineWidth(ow); ctx.ring(hx, hy, hr);
    ctx.fill(rgba(255, 255, 255, .32)); ctx.oval(hx - hr * .32, hy - hr * .42, hr * .34, hr * .2, -.5);
    if (fy > -.35) {
      double ox = fx * .2 * f, oy = (.1 + .06 * fy) * f;
      ctx.fill(o.skin); ctx.oval(hx + ox, hy + oy + .1 * f, (.3 - .08 * std::fabs(fx)) * f, .31 * f);
      ctx.fill(rgba(148, 197, 255, .55)); ctx.oval(hx + ox, hy + oy - .08 * f, (.33 - .08 * std::fabs(fx)) * f, .11 * f);
      ctx.stroke(shade(o.helm, -.3)); ctx.lineWidth(.05 * f); ctx.beginPath(); ctx.moveTo(hx + ox - .24 * f, hy + oy + .02 * f); ctx.lineTo(hx + ox, hy + oy + .38 * f); ctx.lineTo(hx + ox + .24 * f, hy + oy + .02 * f); ctx.strokePath();
      ctx.fill(o.helm); for (int e : {-1, 1}) if (std::fabs(fx) < .7 || e * fx < 0) ctx.oval(hx + e * hr * .86, hy + .1 * f, .1 * f, .16 * f);
      ctx.fill("#0f172a"); if (fx > -.6) ctx.fillRect(hx + ox + .09 * f, hy + oy + .06 * f, .07 * f, .08 * f); if (fx < .6) ctx.fillRect(hx + ox - .16 * f, hy + oy + .06 * f, .07 * f, .08 * f);
      ctx.fill(rgba(15, 23, 42, .5)); ctx.fillRect(hx + ox - .1 * f, hy + oy + .27 * f, .2 * f, .04 * f);
      ctx.fill(o.helm); ctx.beginPath(); ctx.ellipse(hx, hy - .18 * f, hr * .98, hr * .6, 0, PI, PI * 2); ctx.fillPath();
    } else { ctx.fill(shade(o.helm, -.25)); ctx.fillRect(hx - .25 * f, hy + .1 * f, .5 * f, .08 * f); }
    if (o.star) { ctx.stroke("#facc15"); ctx.lineWidth(.1 * f); ctx.beginPath(); ctx.arc(hx, hy, hr * .75, PI * 1.15, PI * 1.85); ctx.strokePath(); }
  }});
  std::stable_sort(parts.begin(), parts.end(), [](const auto &a, const auto &b) { return a.first < b.first; });
  for (auto &q : parts) q.second();
}
// goalie: wide stance, big pads, catching glove and blocker. Faces the camera if he guards the top net.
struct GFigO { double f; bool toward; Col col, stripe, pants; Pose pose; double k; double side; int set; double lean; };
static void skGoalieFig(const GFigO &o) {
  const double f = o.f; bool toward = o.toward; const Col out = hex("#0f172a"); double ow = .07 * f, k = o.k, side = o.side; Pose P = o.pose;
  { ctx.save(); ctx.scale(1, .38); Grad g = radial(0, 0, 0, 0, 0, 1.8 * f); g.add(0, rgba(15, 23, 42, .36)); g.add(1, rgba(15, 23, 42, 0)); ctx.fill(g); ctx.disc(0, 0, 1.8 * f); ctx.restore(); }
  double gxs = toward ? 1 : -1; bool gloveOn = side == gxs;
  double cr = o.set ? .6 : 0, bf = 0, kick = 0, dive = 0, poke = 0, cover = 0, gUp = 0, gOut = 0, bUp = 0, bOut = 0, mid = 0, lx = o.lean * .18 * f;
  if (P == GP_LO) { bf = k; cr = 1; }
  else if (P == GP_KICK) { kick = k; cr = .8; }
  else if (P == GP_HI) { bf = .35 * k; cr = 1; if (gloveOn) { gUp = k; gOut = k; } else { bUp = k; bOut = k; } }
  else if (P == GP_BODY) { bf = .6 * k; cr = 1; mid = k; }
  else if (P == GP_DIVE) { dive = k; bf = .4 * k; if (gloveOn) { gOut = .25 * k; gUp = 1.15 * k; bUp = .4 * k; } else { bOut = .25 * k; bUp = 1.15 * k; gUp = .4 * k; } }
  else if (P == GP_POKE) { poke = k; cr = .8; bf = .3 * k; }
  else if (P == GP_COVER) { bf = 1; cr = 1; cover = k; }
  else if (P == GP_LOOK) { cr = .8; lx += side * .25 * f * k; }
  ctx.save();
  if (dive) { ctx.translate(side * 1.3 * f * dive, -.15 * f * dive); ctx.rotate(side * 1.2 * dive); }
  ctx.translate(lx, 0);
  double body = (.3 * cr + .8 * std::max(bf, kick)) * f, padTop = -(2.25 - .35 * cr) * f;
  auto stickPart = [&] { double by = (toward ? .55 : -.35) + (toward ? 1 : -1) * 1.7 * poke; ctx.stroke("#1f2937"); ctx.lineWidth(.22 * f); ctx.line(.55 * f * side, (-2.6) * f + body, .2 * f + side * .3 * f * poke, by * f);
    ctx.fill("#111827"); ctx.fillRect(-.45 * f + side * .3 * f * poke, (by - .05) * f, 1.0 * f, .22 * f); };
  if (!toward) stickPart();
  double u = 1.05 * f;
  for (int sd : {-1, 1}) {
    double st[3] = {sd * .55 * f - .31 * f, sd * .55 * f + .31 * f, -padTop};
    double bt[3] = {sd < 0 ? -2.15 * u : 0, sd < 0 ? 0 : 2.15 * u, 1 * u};
    double kt[3]; if (sd == side) { if (side < 0) { kt[0] = -3.4 * u; kt[1] = -.2 * u; } else { kt[0] = .2 * u; kt[1] = 3.4 * u; } kt[2] = .75 * u; } else { if (side < 0) { kt[0] = -.2 * u; kt[1] = 1 * u; } else { kt[0] = -1 * u; kt[1] = .2 * u; } kt[2] = 1 * u; }
    double a = kick > 0 ? kick : bf; const double *T = kick > 0 ? kt : bt; double x0 = st[0] + (T[0] - st[0]) * a, x1 = st[1] + (T[1] - st[1]) * a, ph = st[2] + (T[2] - st[2]) * a;
    ctx.fill("#f8fafc"); ctx.fillRect(x0, -ph, x1 - x0, ph); ctx.stroke(out); ctx.lineWidth(ow); ctx.strokeRect(x0, -ph, x1 - x0, ph);
    ctx.fill(o.col);
    if (x1 - x0 > ph * 1.3) for (double q : {.3, .62}) ctx.fillRect(x0 + (x1 - x0) * q, -ph, .16 * f, ph);
    else for (double q : {.3, .62}) ctx.fillRect(x0, -ph * q, x1 - x0, .14 * f);
  }
  double bx0 = side * .6 * u * kick, yS = -4.35 * f + body, yH = -2.35 * f + body, wS = .95 * f, wH = .8 * f;
  ctx.fill(o.pants); ctx.fillRect(bx0 - wH * .95, yH - .1 * f, wH * 1.9, .75 * f);
  { Grad g = linear(bx0 - wS, 0, bx0 + wS, 0); g.add(0, shade(o.col, .16)); g.add(.55, o.col); g.add(1, shade(o.col, -.3)); ctx.fill(g); }
  ctx.beginPath(); ctx.moveTo(bx0 - wS, yS + .15 * f); ctx.lineTo(bx0 - wS * .75, yS - .2 * f); ctx.lineTo(bx0 + wS * .75, yS - .2 * f); ctx.lineTo(bx0 + wS, yS + .15 * f); ctx.lineTo(bx0 + wH * 1.1, yH); ctx.lineTo(bx0 - wH * 1.1, yH); ctx.closePath(); ctx.fillPath();
  ctx.stroke(out); ctx.lineWidth(ow); ctx.strokePath();
  ctx.fill(o.stripe); ctx.fillRect(bx0 - wH * 1.08, yH - .6 * f, wH * 2.16, .24 * f);
  double s2 = o.set ? .15 : 0;
  double gx = gxs * (1.25 + s2 + .9 * gOut) * f - gxs * .75 * f * mid + bx0, gy = -3.1 * f + body + s2 * f - (1.15 * gUp) * f + .2 * f * mid;
  double bx = -gxs * (1.25 + s2 + .9 * bOut) * f + gxs * .75 * f * mid + bx0, by = -3.0 * f + body + s2 * f - (1.15 * bUp) * f + .2 * f * mid;
  if (cover) { gx = gx + (0 - gx) * cover; gy = gy + ((-.9 * f) - gy) * cover; }
  ctx.fill("#f8fafc"); ctx.oval(gx, gy, .48 * f, .42 * f); ctx.stroke(out); ctx.beginPath(); ctx.ellipse(gx, gy, .48 * f, .42 * f, 0, 0, 7); ctx.strokePath();
  ctx.fill(o.col); ctx.oval(gx, gy, .3 * f, .25 * f);
  ctx.fill("#f8fafc"); ctx.fillRect(bx - .3 * f, by - .45 * f, .6 * f, .9 * f); ctx.stroke(out); ctx.strokeRect(bx - .3 * f, by - .45 * f, .6 * f, .9 * f);
  ctx.fill(o.col); ctx.fillRect(bx - .3 * f, by - .1 * f, .6 * f, .18 * f);
  if (toward) stickPart();
  double hy = yS - .58 * f, hx = bx0;
  ctx.fill(toward ? hex("#f8fafc") : o.col); ctx.disc(hx, hy, .44 * f); ctx.stroke(out); ctx.lineWidth(ow); ctx.ring(hx, hy, .44 * f);
  ctx.fill(rgba(255, 255, 255, .35)); ctx.oval(hx - .16 * f, hy - .22 * f, .15 * f, .09 * f, -.5);
  if (toward) { ctx.stroke("#334155"); ctx.lineWidth(.05 * f); for (double x : {-.15, 0.0, .15}) ctx.line(hx + x * f, hy - .05 * f, hx + x * f, hy + .32 * f);
    ctx.line(hx - .25 * f, hy + .12 * f, hx + .25 * f, hy + .12 * f);
    ctx.fill(o.col); ctx.beginPath(); ctx.ellipse(hx, hy - .25 * f, .42 * f, .16 * f, 0, PI, PI * 2); ctx.fillPath(); }
  else { ctx.fill("#f8fafc"); ctx.fillRect(hx - .06 * f, hy - .45 * f, .12 * f, .6 * f); }
  ctx.restore();
}
// how far the mesh is pushed back after a goal, and the net's jiggle on its pegs
struct Bul { bool on = false; double w = 0, hy = 0, j = 0; Key key; };
static Bul netBul(const NetBulge &o) {
  Bul b; if (!o.on) return b; double k = o.a * std::exp(-3.2 * o.t); if (k < .06) return b;
  double w = std::min(1.5, std::round(k * (.62 + .38 * std::cos(o.t * 20)) / .25) * .25), hy = std::round(o.y / 2) * 2; if (w <= 0) return b;
  b.on = true; b.w = w; b.hy = hy; b.j = o.a * .18 * std::exp(-5 * o.t) * std::sin(o.t * 30); b.key = Key() << w << hy; return b;
}
static void skBottleShape(Pt b, Pt t, double s) {
  double w = std::max(2.5, .32 * s), dx = t.x - b.x, dy = t.y - b.y, L = hyp(dx, dy); if (!L) L = 1; double nx = -dy / L * w / 2, ny = dx / L * w / 2;
  ctx.fill(rgba(147, 197, 253, .95)); ctx.quad(b.x + nx, b.y + ny, b.x - nx, b.y - ny, t.x - nx, t.y - ny, t.x + nx, t.y + ny);
  ctx.fill(rgba(255, 255, 255, .55)); ctx.quad(b.x + nx * .2 + dx * .2, b.y + ny * .2 + dy * .2, b.x + nx * .6 + dx * .2, b.y + ny * .6 + dy * .2, b.x + nx * .6 + dx * .8, b.y + ny * .6 + dy * .8, b.x + nx * .2 + dx * .8, b.y + ny * .2 + dy * .8);
  ctx.fill("#f8fafc"); ctx.quad(t.x + nx * .7, t.y + ny * .7, t.x - nx * .7, t.y - ny * .7, t.x - nx * .4 + dx * .22, t.y - ny * .4 + dy * .22, t.x + nx * .4 + dx * .22, t.y + ny * .4 + dy * .22);
}
static void skDrawBottle(const Bottle &b, double x, double y, double s) {
  double L = .9 * s;
  if (b.s == BT_ICE || b.z < .4) { double c = std::cos(b.a), sn = std::sin(b.a) * .55; skBottleShape({x - c * L / 2, y - sn * L / 2}, {x + c * L / 2, y + sn * L / 2}, s); return; }
  double c = std::sin(b.a), sn = std::cos(b.a); skBottleShape({x - c * L / 2, y + sn * L / 2}, {x + c * L / 2, y - sn * L / 2}, s);
}
static void skDrawNet(const Layout &lay, double gx, int deep, const NetBulge *nbo, bool btl) {
  double s = lay.s, K = lay.k; Pt b = skW2S(lay, gx, RK.cy - RK.post); Bul bl = nbo ? netBul(*nbo) : Bul();
  ctx.save(); ctx.translate(b.x, b.y);
  auto body = [&] {
    const double pw = RK.post, D = RK.netD * 1.1, NH = 4.8;
    auto bf = [&](double y) { return bl.on ? bl.w * std::exp(-std::pow((y - bl.hy) / 2.8, 2)) : 0.0; };
    auto pr = [&](const double *q) { return Pt{(q[0] + pw) * s, -deep * q[1] * s * K - q[2] * s}; };
    auto sq = [&](double y) { return std::pow(std::max(0.0, 1 - std::pow(std::fabs(y) / pw, 4)), .25); };
    struct V3 { double v[3]; };
    auto B = [&](double u) { double y = -pw + 2 * pw * u; return V3{{y, D * sq(y) + bf(y) * sq(y), 0}}; };
    auto T = [&](double u) { double y = -pw + 2 * pw * u, k = sq(y); return V3{{y, D * .42 * k + bf(y) * .7 * k, NH - .55 * k}}; };
    auto S = [&](double u, double t) { V3 a = B(u), c = T(u); return V3{{a.v[0] + (c.v[0] - a.v[0]) * t, a.v[1] + (c.v[1] - a.v[1]) * t, a.v[2] + (c.v[2] - a.v[2]) * t}}; };
    auto poly = [&](const std::vector<V3> &pts, Col fill) { ctx.fill(fill); ctx.beginPath(); for (size_t i = 0; i < pts.size(); i++) { Pt r = pr(pts[i].v); if (i) ctx.lineTo(r.x, r.y); else ctx.moveTo(r.x, r.y); } ctx.closePath(); ctx.fillPath(); };
    auto line = [&](const std::vector<V3> &pts, Col col, double lw) { ctx.stroke(col); ctx.lineWidth(lw); ctx.beginPath(); for (size_t i = 0; i < pts.size(); i++) { Pt r = pr(pts[i].v); if (i) ctx.lineTo(r.x, r.y); else ctx.moveTo(r.x, r.y); } ctx.strokePath(); };
    auto seq = [&](std::function<V3(double)> fn, int n) { std::vector<V3> o; for (int i = 0; i <= n; i++) o.push_back(fn(i / (double)n)); return o; };
    ctx.lineCap(CAP_ROUND);
    auto mesh = [&] {
      const int N = 8; for (int i = 0; i < N; i++) poly({B(i / (double)N), B((i + 1) / (double)N), T((i + 1) / (double)N), T(i / (double)N)}, rgba(71, 85, 105, .24));
      poly({T(0), T(1), V3{{pw, 0, NH}}, V3{{-pw, 0, NH}}}, rgba(71, 85, 105, .18));
      ctx.lineCap(CAP_BUTT);
      Col ml = rgba(51, 65, 85, .55); double lw = std::max(.7, .05 * s); const int M = 9;
      for (int k = -M; k <= M; k++) { double c = k / (double)M; std::vector<V3> d1, d2;
        for (int j = 0; j <= 5; j++) { double t = j / 5.0, u1 = c + t * .55, u2 = c - t * .55 + 1; if (u1 >= 0 && u1 <= 1) d1.push_back(S(u1, t)); if (u2 >= 0 && u2 <= 1) d2.push_back(S(u2, t)); }
        if (d1.size() > 1) line(d1, ml, lw); if (d2.size() > 1) line(d2, ml, lw); }
      for (int i = 1; i < 6; i++) { double t = i / 6.0; line({T(t), V3{{-pw + 2 * pw * t, 0, NH}}}, ml, lw); }
      ctx.lineCap(CAP_ROUND);
    };
    auto tube = [&](const std::vector<V3> &pts, double w) { line(pts, rgba(51, 65, 85, .8), std::max(1.8, w * 1.4 * s)); line(pts, hex("#f1f5f9"), std::max(1.2, w * s)); };
    auto back = [&] {
      tube(seq(B, 14), .34); tube(seq(T, 14), .24);
      for (int uu : {0, 1}) line({B(uu), B(uu ? .92 : .08)}, hex("#dc2626"), std::max(1.4, .3 * s));
      V3 pb = B(.5); double pt[3] = {0, 0, NH - .05}; auto L = [&](double t) { return V3{{0, pb.v[1] + (pt[1] - pb.v[1]) * t, pb.v[2] + (pt[2] - pb.v[2]) * t}}; };
      line({L(0), L(1)}, rgba(51, 65, 85, .8), std::max(2.2, .5 * s)); line({L(0), L(1)}, hex("#f1f5f9"), std::max(1.5, .36 * s));
      line({L(.76), L(.9)}, hex("#dc2626"), std::max(1.8, .4 * s));
    };
    auto frame = [&] { std::vector<V3> fr = {V3{{-pw, 0, 0}}, V3{{-pw, 0, NH}}, V3{{pw, 0, NH}}, V3{{pw, 0, 0}}}; line(fr, hex("#7f1d1d"), std::max(2.4, .44 * s)); line(fr, hex("#dc2626"), std::max(1.6, .32 * s)); };
    if (deep > 0) { mesh(); back(); frame(); } else { frame(); back(); mesh(); }
    if (btl) { double a[3] = {1.3, D * .3, NH - .3}, c[3] = {1.3, D * .3, NH + .6}; skBottleShape(pr(a), pr(c), s); }
  };
  if (bl.on) ctx.translate(0, -deep * bl.j * s * K);
  Key k = Key("sknet2") << deep << s << K << btl; if (bl.on) k << bl.key.h;
  cached(k, body);
  ctx.restore();
}
static void skRingAt(double x, double y, double rx, double ry, double v, bool broke) {
  double f = std::round(clamp(v / 100, 0, 1) * 16) / 16; const int N = 16;
  if (y < -rx || y > H + rx || ry < 2) return;
  auto pts = [&](double k, double k0) { std::vector<Pt> o; for (int i = (int)std::round(N * k0); i <= (int)std::round(N * k); i++) { double a = -PI / 2 + i / (double)N * PI * 2; o.push_back({std::cos(a) * rx, std::sin(a) * ry}); } return o; };
  auto ln = [&](const std::vector<Pt> &P, Col c, double w) { if (P.size() < 2) return; ctx.lineCap(CAP_BUTT); ctx.stroke(c); ctx.lineWidth(w); ctx.beginPath(); for (size_t i = 0; i < P.size(); i++) { if (i) ctx.lineTo(P[i].x, P[i].y); else ctx.moveTo(P[i].x, P[i].y); } ctx.strokePath(); };
  double w = std::max(2.0, std::round(rx * .11));
  ctx.save(); ctx.translate(std::round(x), std::round(y));
  double pulse = std::round((.5 + .5 * std::sin(now() / 170)) * 3) / 3;
  if (broke) { ctx.alpha(.4 + .45 * pulse); cached(Key("pring|b") << rx << ry << w, [&] { ln(pts(1, 0), hex("#ef4444"), w * 1.25); }); }
  else { bool low = f <= .25; Col gc = low && pulse > .5 ? rgba(239, 68, 68, .8) : rgba(34, 197, 94, .8);
    cached(Key("pring") << rx << ry << w << f << gc, [&] { ln(pts(1, f), rgba(0, 0, 0, .55), w); ln(pts(f, 0), gc, w); }); }
  ctx.restore(); ctx.alpha(1);
}
static void skReflect(double x, double y, double f, Col jersey, Col pants, Col helm) {
  double fr = fr15(std::max(1.0, f));
  ctx.save(); ctx.translate(std::round(x), std::round(y));
  cachedScaled(Key("skrfl") << jersey << pants << helm << fr, f / fr, [&] { double F = fr;
    auto part = [&](double y0, double y1, double w0, double w1, Col col, double a0, double a1) { Grad g = linear(0, y0 * F, 0, y1 * F); g.add(0, withA(col, a0)); g.add(1, withA(col, a1)); ctx.fill(g);
      ctx.quad(-w0 * F, y0 * F, w0 * F, y0 * F, w1 * F, y1 * F, -w1 * F, y1 * F); };
    part(.05, .4, .5, .46, hex("#111827"), .32, .26); part(.4, 1.25, .46, .5, pants, .26, .18); part(1.25, 2.55, .6, .82, jersey, .2, .1); part(2.55, 3.05, .36, .3, helm, .1, .02); });
  ctx.restore();
}
static Key skPoseKey(Col col, Col stripe, bool star, Col skin, int d, double f, bool rh) { return Key("skf") << col << stripe << star << skin << d << f << rh; }
static void skDrawSkater(Skater *p, const Layout &lay, Col col, Col stripe, const Pt *s0o = nullptr, double fo = 0, bool refl = false) {
  Pt s0 = s0o ? *s0o : skW2S(lay, p->x, p->y); double f = fo ? fo : lay.s * SK_SPR;
  if (s0.x < -4 * f || s0.x > W + 4 * f || s0.y < -2 * f || s0.y > H + 8 * f) return;
  if (!s0o && !refl && SK->phase != PH_GOAL) { double rx = std::round(1.9 * lay.s); skRingAt(s0.x, s0.y, rx, std::round(rx * std::min(1.0, lay.k * 1.15)), p->st, p->tired || p->st <= 0); }
  double sp = hyp(p->vx, p->vy), stride = std::round(std::sin(p->ph * 3) * std::min(1.0, sp / 10) * 2) / 2;
  double th = std::atan2(-std::cos(p->ang), std::sin(p->ang)); int d = (((int)std::round(th / (PI / 4)) % 8) + 8) % 8;
  bool stun = p->stun > 0, poke = p->pokeA > 0, spin = p->spin > 0, dash = p->dash > 0, wind = p->wind > 0, blk = p->block > 0;
  if (spin) d = (d + (int)std::floor((1 - p->spin / SPIN_T) * 16)) % 8;
  double fr = fr15(f), kf = f / fr; bool rh = p->sh == 'R';
  Key K = skPoseKey(col, stripe, p->star, p->skin, d, fr, rh);
  FigO o; o.f = fr; o.d = d; o.stride = stride; o.col = col; o.stripe = stripe; o.star = p->star; o.skin = p->skin; o.helm = shade(col, -.15); o.lean = .25; o.rh = rh;
  Key key = K; double rot = 0;
  if (blk) { double up = p->block < .25 ? std::round(p->block / .25 * 2) / 2 : 1; rot = (std::cos(p->blkA) > 0 ? 1 : -1) * 1.45 * up; o.lean = 0; o.stride = 0; key << "b"; }
  else if (stun) { double a = p->kd ? std::round(std::min(std::min(1.0, ((p->stunMax ? p->stunMax : p->stun) - p->stun) / .15), p->stun / .35) * 4) / 4 : .25; rot = (p->team ? 1 : -1) * 1.4 * a; o.stride = 0; key << "s0"; }
  else if (poke) { o.pk = std::round(std::sin(PI * (1 - p->pokeA / .28)) * 3) / 3; o.stride = 0; key << "p" << o.pk; }
  else if (wind) { o.wind = std::round(p->wind * 4) / 4; o.stride = 0; key << "w" << o.wind; }
  else if (p->wl > 0) { o.load = std::round(p->wl * 3) / 3; o.stride = 0; key << "l" << o.load; }
  else if (p->chopT > 0) { double t = 1 - p->chopT / .4, z = t < .5 ? t * 2 * 1.3 : std::max(0.0, (1 - t) * 2) * 1.3; o.chz = std::round(z / .33) * .33; o.stride = 0; key << "ch" << o.chz; }
  else if (p->dkLat) { o.dkL = std::round(p->dkLat * 2) / 2; o.dkF = std::round(p->dkF * 2.5) / 2.5; o.stride = 0; key << "k" << o.dkL << o.dkF; }
  else if (p->folT > 0) { double k = clamp(p->folT / (p->folK > .8 ? .38 : .24), 0, 1); o.fol = std::round(std::sin(PI * std::min(1.0, (1 - k) * 1.6)) * p->folK * 4) / 4; o.stride = 0; key << "f" << o.fol; }
  else if (dash) { o.lean = 1; key << "d" << stride; }
  else key << stride;
  if (refl) { if (!rot) skReflect(s0.x, s0.y, f, col, shade(col, -.55), shade(col, -.15)); return; }
  ctx.save(); ctx.translate(s0.x, s0.y);
  if (rot) ctx.rotate(rot);
  cachedScaled(key, kf, [&] { skFig(o); });
  if (rot) ctx.rotate(-rot);
  if (stun) { double t = now() / 180; ctx.fill("#facc15"); for (int i = 0; i < 3; i++) { double a2 = t + i * 2.1; ctx.fillRect(std::cos(a2) * .8 * f - .12 * f, -2.6 * f + std::sin(a2) * .25 * f - .12 * f, .24 * f, .24 * f); } }
  if (!stun && !blk && d >= 5 && d <= 7) { int n = skNum(p);
    cachedScaled(Key("skn") << n << stripe << d << fr, kf, [&] { ctx.fill(stripe); ctx.font(.62 * fr); ctx.textMid(); ctx.fillText(istr(n), std::cos(d * PI / 4) * .15 * fr, -3.1 * fr); }); }
  ctx.restore();
}
// warm the pose cache during stoppages so the first seconds of play don't stutter
void skWarm(const Layout &lay, int n) {
  if (SK->warmQ.empty() && SK->warmT == lay.s) return;
  if (SK->warmT != lay.s) { SK->warmT = lay.s; SK->warmQ.clear();
    double f = fr15(lay.s * SK_SPR);
    for (Skater *p : skAll()) { Team &T = SK->T[p->team]; bool rh = p->sh == 'R';
      for (int d = 0; d < 8; d++) for (double st : {0.0, .5, -.5, 1.0, -1.0}) { Key k = skPoseKey(T.col, T.stripe, p->star, p->skin, d, f, rh); k << st;
        SK->warmQ.push_back({k, d, st, T.col, T.stripe, p->star, p->skin, rh}); } } }
  ctx.save(); ctx.translate(-4000, -4000);
  double f = fr15(lay.s * SK_SPR); int m = n * 2;
  while (!SK->warmQ.empty() && m > 0) { auto it = SK->warmQ.front(); SK->warmQ.erase(SK->warmQ.begin()); if (SK->warmD[it.k.h]) continue; SK->warmD[it.k.h] = true;
    FigO o; o.f = f; o.d = it.d; o.stride = it.stride; o.col = it.col; o.stripe = it.stripe; o.star = it.star; o.skin = it.skin; o.helm = shade(it.col, -.15); o.lean = .25; o.rh = it.rh;
    cachedScaled(it.k, 1, [&] { skFig(o); }); m--; }
  ctx.restore();
}
static void skDrawPRing(const Goalie &g, const Layout &lay) {
  if (g.out) return; Pt s0 = skW2S(lay, g.x, g.y); double rx = std::round(3 * lay.s), ry = std::round(rx * std::min(1.0, lay.k * 1.15));
  skRingAt(s0.x, s0.y, rx, ry, g.ast, g.broke);
}
static void skDrawGoalie(const Goalie &g, const Layout &lay, Col col, Col stripe) {
  if (g.out) return; Pt s0 = skW2S(lay, g.x, g.y); double f = lay.s * 1.3;
  if (s0.y < -2 * f || s0.y > H + 8 * f) return;
  bool toward = g.team == 1; Pose pose = GP_NONE; double k = 0, side = 1;
  if (SK->phase == PH_HOLD && SK->hold.on && SK->hold.g == &g) { pose = GP_COVER; k = 1; }
  else if (g.hasAn) { const GAnim &A = g.an; pose = A.p; side = A.s; k = A.t < A.i ? A.t / A.i : A.t < A.i + A.h ? 1 : 1 - (A.t - A.i - A.h) / A.o; k = std::round(clamp(k, 0, 1) * 3) / 3; }
  else if (g.sv > 0) { pose = GP_LO; side = g.svSide; k = 1; }
  if (!k) pose = GP_NONE;
  int set = g.set ? 1 : 0; double lean = !pose && std::fabs(g.mv) > 2.5 ? (g.mv > 0 ? 1 : -1) : 0;
  ctx.save(); ctx.translate(s0.x, s0.y);
  GFigO o{f, toward, col, stripe, shade(col, -.55), pose, k, side, set, lean};
  cached(Key("skgf") << col << stripe << toward << f << (int)pose << k << side << set << lean, [&] { skGoalieFig(o); });
  ctx.restore();
}
static void skDrawRef(const Layout &lay, bool refl) {
  if (!SK->hasRef) return; const Ref &r = SK->ref; Pt s0 = skW2S(lay, r.x, r.y); double f = lay.s * SK_SPR;
  if (s0.x < -4 * f || s0.x > W + 4 * f || s0.y < -2 * f || s0.y > H + 8 * f) return;
  double th = std::atan2(-std::cos(r.ang), std::sin(r.ang)); int d = (((int)std::round(th / (PI / 4)) % 8) + 8) % 8; double sp = hyp(r.vx, r.vy);
  double stride = std::round(std::sin(r.ph * 3) * std::min(1.0, sp / 10) * 2) / 2, fr = fr15(f), kf = f / fr;
  int arm = r.arm > 0 ? 1 : 0, drop = r.drop && !arm ? 1 : 0;
  if (refl) { skReflect(s0.x, s0.y, f, hex("#f1f5f9"), hex("#111827"), hex("#111827")); return; }
  FigO o; o.f = fr; o.d = d; o.stride = arm || drop ? 0 : stride; o.col = hex("#f1f5f9"); o.stripe = hex("#f97316"); o.pants = hex("#111827"); o.hasPants = true; o.sock = hex("#111827"); o.hasSock = true;
  o.glove = hex("#111827"); o.hasGlove = true; o.skin = hex("#e0a878"); o.helm = hex("#111827"); o.lean = .15; o.ref = true; o.arm = arm; o.drop = drop;
  ctx.save(); ctx.translate(s0.x, s0.y);
  cachedScaled(Key("ref") << d << o.stride << arm << drop << fr, kf, [&] { skFig(o); }); ctx.restore();
}
static void skPuckSprite(double x, double y, double r, const Puck &P) {
  double w = P.wob, tl = w > .05 ? std::round(std::sin(SK->gt * 24 + P.id) * w * 3) / 3 : 0, rq = std::max(1.0, std::round(r * 2) / 2);
  ctx.save(); ctx.translate(std::round(x), std::round(y));
  cached(Key("skpk") << rq << tl, [&] { double ry = rq * (.62 - .22 * std::fabs(tl)), rot = tl * .45;
    ctx.fill("#050505"); ctx.oval(0, 0, rq, ry, rot);
    ctx.fill("#2b3442"); ctx.oval(0, -rq * .16, rq * .9, ry * .68, rot);
    ctx.fill(rgba(255, 255, 255, .35)); ctx.oval(-rq * .25, -rq * .24, rq * .32, ry * .2, rot); });
  ctx.restore();
}
static void skPuckShadow(double x, double y, double r, double k, double z) {
  double a = std::round(clamp(.32 - z * .05, .08, .32) * 8) / 8, rq = std::max(1.0, std::round(r * 2) / 2);
  ctx.save(); ctx.translate(std::round(x), std::round(y)); cached(Key("skps") << rq << a << k, [&] { ctx.fill(rgba(15, 23, 42, a)); ctx.oval(0, 0, rq * 1.05, rq * .62 * k); }); ctx.restore();
}
static void skPkGlow(double ox, double oy, double pkF, const Layout &lay) {
  if (!(pkF > 0)) return; Pt s = skW2S(lay, ox, oy); double f = lay.s * SK_SPR, fr = fr15(f);
  ctx.save(); ctx.translate(std::round(s.x), std::round(s.y)); ctx.alpha(std::ceil(clamp(pkF / .55, 0, 1) * 4) / 4 * .8);
  cachedScaled(Key("pkgl") << fr, f / fr, [&] { ctx.save(); ctx.translate(0, -1.9 * fr); ctx.scale(1, 1.45); Grad g = radial(0, 0, 0, 0, 0, 2.3 * fr);
    g.add(0, rgba(255, 255, 255, .95)); g.add(.55, rgba(255, 255, 255, .55)); g.add(1, rgba(255, 255, 255, 0)); ctx.fill(g); ctx.disc(0, 0, 2.3 * fr); ctx.restore(); });
  ctx.alpha(1); ctx.restore();
}
static void skDrawGlass(const Layout &lay) {
  for (const Glass &q : SK->gls) { double sw = q.a * 1.6 * std::sin(q.t * 17) * std::exp(-q.t * 2.8); if (std::fabs(sw) < .04) continue;
    double tx = -q.ny, ty = q.nx, hw = 4; Pt b0 = skW2S(lay, q.x - tx * hw, q.y - ty * hw, SK_BH), b1 = skW2S(lay, q.x + tx * hw, q.y + ty * hw, SK_BH),
      t0 = skW2S(lay, q.x - tx * hw + q.nx * sw, q.y - ty * hw + q.ny * sw, SK_BH + SK_GH), t1 = skW2S(lay, q.x + tx * hw + q.nx * sw, q.y + ty * hw + q.ny * sw, SK_BH + SK_GH);
    ctx.fill(rgba(225, 240, 255, .3)); ctx.quad(b0.x, b0.y, b1.x, b1.y, t1.x, t1.y, t0.x, t0.y);
    ctx.lineCap(CAP_BUTT); ctx.stroke(rgba(255, 255, 255, .95)); ctx.lineWidth(std::max(1.5, .3 * lay.s)); ctx.beginPath(); ctx.moveTo(t0.x, t0.y); ctx.lineTo(t1.x, t1.y);
    ctx.moveTo(b0.x, b0.y); ctx.lineTo(t0.x, t0.y); ctx.moveTo(b1.x, b1.y); ctx.lineTo(t1.x, t1.y); ctx.strokePath(); }
}
static void skDrawSpray(const Layout &lay) {
  if (SK->spr.empty() || SK->phase != PH_PLAY) return; ctx.fill("#f8fafc");
  for (const Spray &q : SK->spr) { double k = 1 - q.t / q.l; Pt a = skW2S(lay, q.x, q.y, q.z); double w = std::max(1.5, .3 * lay.s * (.6 + .4 * k)); ctx.alpha(std::ceil(k * 4) / 4 * .9); ctx.fillRect(a.x - w / 2, a.y - w / 2, w, w); }
  ctx.alpha(1);
}
static void skDrawScratches(const Layout &lay) {
  auto &S = SK->scr; Pt o = skW2S(lay, 0, 0); Key ks = Key() << lay.s << lay.k;
  auto seg = [&](const std::vector<ScratchSeg> &L) { for (auto &q : L) { Pt a = skW2S(lay, q.x0, q.y0), b = skW2S(lay, q.x1, q.y1); ctx.stroke(rgba(148, 163, 184, q.a)); ctx.lineWidth(std::max(1.0, (double)q.w * lay.s)); ctx.line(a.x - o.x, a.y - o.y, b.x - o.x, b.y - o.y); } };
  ctx.save(); ctx.translate(o.x, o.y);
  for (auto &B : S.b) cached(Key("skscr") << B.id << ks.h, [&] { seg(B.s); });
  if (!S.cur.empty()) { ctx.stroke(rgba(148, 163, 184, .3)); ctx.lineWidth(std::max(1.0, .13 * lay.s)); ctx.beginPath();
    for (auto &q : S.cur) { Pt a = skW2S(lay, q.x0, q.y0), b = skW2S(lay, q.x1, q.y1); ctx.moveTo(a.x - o.x, a.y - o.y); ctx.lineTo(b.x - o.x, b.y - o.y); } ctx.strokePath(); }
  ctx.restore();
}
static void skDrawBattle(const Layout &lay) {
  if (!SK->hasBat || !SK->bat.user) return; Battle &B = SK->bat;
  Pt s = skW2S(lay, (B.a->x + B.b->x) / 2, (B.a->y + B.b->y) / 2); double bw = .3 * U, bh = .024 * U, x = std::round(s.x - bw / 2), y = std::round(s.y - 6.6 * lay.s * SK_SPR - .05 * U);
  ctx.save(); ctx.translate(x, y);
  cached(Key("skbat") << U, [&] { ctx.fill(rgba(8, 12, 24, .88)); ctx.rr(-.01 * U, -.05 * U, bw + .02 * U, bh + .065 * U, .012 * U); ctx.fillPath();
    ctx.font(.019 * U); ctx.textMid(); ctx.fill("#ffd54a"); ctx.fillText("<  WIGGLE THE LEFT STICK  >", bw / 2, -.026 * U);
    ctx.fill("#7f1d1d"); ctx.rr(0, 0, bw, bh, bh / 2); ctx.fillPath(); });
  double f = clamp(B.prog, 0, 1); ctx.fill("#22c55e"); ctx.rr(0, 0, std::max(bh, bw * f), bh, bh / 2); ctx.fillPath();
  ctx.fill("#fff"); ctx.fillRect(std::round(bw * .5) - 1, -2, 2, bh + 4);
  ctx.restore();
}
static void skCelebFx() {
  if (!SK->hasCel || SK->phase != PH_GOAL) return; Team &T = SK->T[SK->cel.team]; double t = SK->cel.t, a = clamp(std::min(t / .3, (3 - t) / .5), 0, 1); if (a <= 0) return;
  ctx.alpha(std::ceil(a * 4) / 4);
  for (int L = 0; L < 2; L++) {
    double off = std::fmod(t * (L ? .42 : .27) * H, H), sx = std::round(std::sin(t * 2.2 + L * 1.7) * .025 * U);
    for (double dy : {off - H, off}) { ctx.save(); ctx.translate(sx, std::round(dy));
      cached(Key("conf") << L << W << H << T.col << T.stripe, [&] { for (int i = 0; i < 14; i++) { int j = i + L * 14; double x = std::fmod(j * 97.3, W), y = std::fmod(j * 53.1 * 3.7, H), w = (.006 + (j % 3) * .003) * U;
          ctx.fill(j % 3 == 2 ? hex("#ffffff") : j % 2 ? T.col : T.stripe); ctx.fillRect(x, y, w, w * (.45 + .55 * ((j * 7) % 5) / 4.0)); } });
      ctx.restore(); }
  }
  ctx.alpha(1);
}
void skHUD(const Layout &lay);

void skDraw() {
  Layout lay = skLayout(); Puck &P = SK->puck; double cam = SK->cam, camY = SK->camY;
  ctx.fill("#161d2b"); ctx.fillRect(0, 0, W, H);
  double shk = SK->shk > 0 ? SK->shk : 0; if (shk) { ctx.save(); ctx.translate(std::round(rand(-1, 1) * shk * .012 * U), std::round(rand(-1, 1) * shk * .009 * U)); }
  if (g_view3d) skDraw3D(); else {
  struct { double x0, x1, y0, y1; } V{cam - lay.viewLen / 2 - 12, cam + lay.viewLen / 2 + (SK_BH + SK_GH) / lay.k + 20, camY - lay.viewWid / 2 - 3, camY + lay.viewWid / 2 + 3};
  ctx.save(); skWorld(lay, cam, camY);
  { Key ks = Key() << lay.s << lay.k;
    cached(Key("skrA") << ks.h, [] { skDrawRink(0); });
    double cj = SK->phase == PH_GOAL && SK->hasCel && SK->cel.team == 0 ? SK->cel.t : -1;
    for (int b = 0; b < 8; b++) { double x0 = -40 + b * 40, x1 = x0 + 40; if (x1 < V.x0 || x0 > V.x1) continue;
      double j = cj >= 0 ? std::max(0.0, std::sin(cj * 11 - b * .9)) * 1.1 * clamp(std::min(cj / .2, (3 - cj) / .6), 0, 1) : 0;
      if (j) ctx.translate(j, 0); cached(Key("skrC") << b << ks.h, [=] { skDrawRink(1, x0, x1); }); if (j) ctx.translate(-j, 0); }
    cached(Key("skrB") << ks.h, [] { skDrawRink(2); }); }
  {
    std::vector<Skater *> all = skAll(); Skater *u = SK->user; bool uOn = onTeam(0, u);
    if (uOn) { ctx.stroke("#ffd54a"); ctx.lineWidth(.45); ctx.beginPath(); ctx.ellipse(u->x, u->y, 2.1, 2.1, 0, 0, 7); ctx.strokePath(); ctx.fill(rgba(255, 213, 74, .18)); ctx.oval(u->x, u->y, 2.1, 2.1); }
    if (P.owner && P.owner != u) { ctx.stroke(P.owner->team == 0 ? rgba(147, 197, 253, .9) : rgba(252, 165, 165, .9)); ctx.lineWidth(.3); ctx.beginPath(); ctx.ellipse(P.owner->x, P.owner->y, 2, 2, 0, 0, 7); ctx.strokePath(); }
    for (Skater *p : all) { if (p->dash <= 0) continue;
      double dx = p->dx, dy = p->dy, nx = -dy, ny = dx, k = std::min(1.0, p->dash / .28);
      ctx.stroke(rgba(15, 23, 42, .25 + .45 * k)); ctx.lineWidth(.32); ctx.lineCap(CAP_ROUND);
      for (double o : {-1.2, 0.0, 1.2}) { double bx = p->x - dx * (2 + std::fabs(o) * .6) + nx * o, by = p->y - dy * (2 + std::fabs(o) * .6) + ny * o; ctx.line(bx, by, bx - dx * (3 + 3 * k), by - dy * (3 + 3 * k)); }
      double a = std::atan2(dy, dx); ctx.stroke(SK->T[p->team].col); ctx.lineWidth(.45); ctx.beginPath(); ctx.arc(p->x, p->y, 2.9, a - .9, a + .9); ctx.strokePath(); }
    for (Skater *p : all) { if (!(p->spin > 0)) continue; double a0 = (1 - p->spin / SPIN_T) * PI * 4;
      ctx.stroke(rgba(37, 99, 235, .75)); ctx.lineWidth(.4); ctx.lineCap(CAP_ROUND);
      for (double o : {0.0, PI}) { ctx.beginPath(); ctx.arc(p->x, p->y, 3, a0 + o, a0 + o + 1.6); ctx.strokePath(); } }
    for (const HitFx &e : SK->fx) { double k = e.t / .5, r = (e.big ? 1.6 : 1.1) + k * (e.big ? 7 : 5);
      ctx.alpha(1 - k); ctx.stroke(e.me ? "#f59e0b" : "#ef4444"); ctx.lineWidth(.4); ctx.ring(e.x, e.y, r);
      ctx.lineWidth(.3); for (int i = 0; i < 8; i++) { double a = i * PI / 4 + .3, r0 = r * .45, r1 = r * .45 + 1.4; ctx.line(e.x + std::cos(a) * r0, e.y + std::sin(a) * r0, e.x + std::cos(a) * r1, e.y + std::sin(a) * r1); }
      ctx.alpha(1); }
    // the NHL aim cone (while the right stick holds a shot): blue = open net, pink = the goalie's body is in the way
    if (u && P.owner == u && (SK->rs.dn || (QO.shotB && SK->rs.aim))) { Pt T = skAimTarget(u); bool zone = skInZone(u); double dx = T.x - P.x, dy = T.y - P.y, L = hyp(dx, dy);
      if (L > 2) { double nx = -dy / L, ny = dx / L, w = std::max(.6, L * std::tan(skAimSpread(u))); const int N = 14; ctx.alpha(.45);
        for (int i = 0; i < N; i++) { double s0 = -1 + 2.0 * i / N, s1 = -1 + 2.0 * (i + 1) / N, ym = T.y + ny * w * (s0 + s1) / 2; double o = zone ? skShotOpen(u, ym) : 1;
          ctx.fill(!zone ? hex("#facc15") : o > 0 ? hex("#5b6cff") : o == 0 ? hex("#ff8fa3") : hex("#94a3b8"));
          ctx.quad(P.x, P.y, T.x + nx * w * s0, T.y + ny * w * s0, T.x + nx * w * s1, T.y + ny * w * s1, T.x + nx * w * s1, T.y + ny * w * s1); }
        ctx.alpha(1);
        if (zone) { double o = skShotOpen(u, T.y); ctx.stroke(o > 0 ? hex("#3b5bff") : o == 0 ? hex("#ff5c7a") : hex("#94a3b8")); ctx.lineWidth(.35); ctx.ring(T.x, T.y, .9); } } }
    { Skater *o = SK->puck.owner; if (o && SK->phase == PH_PLAY) { double k = .5 + .5 * std::sin(now() / 260);
      ctx.stroke(rgba(255, 255, 255, std::round((.18 + .22 * k) * 100) / 100)); ctx.lineWidth(.32); ctx.beginPath(); ctx.ellipse(o->x, o->y, 2.3 + .35 * k, 2.3 + .35 * k, 0, 0, 7); ctx.strokePath(); } }
    if (skBenchOpen()) { BenchSpot B = skBench(); double k = .5 + .5 * std::sin(now() / 170);
      ctx.fill(rgba(34, 197, 94, std::round((.12 + .12 * k) * 100) / 100)); ctx.oval(B.x, B.y, B.r, B.r);
      ctx.stroke(rgba(34, 197, 94, std::round((.55 + .4 * k) * 100) / 100)); ctx.lineWidth(.45); ctx.beginPath(); ctx.ellipse(B.x, B.y, B.r * (.92 + .08 * k), B.r * (.92 + .08 * k), 0, 0, 7); ctx.strokePath(); }
    if ((SK->phase == PH_GOAL && SK->hasCel && SK->cel.t < 2.6) || SK->hitFl > 0) { ctx.fill("#ffffff"); int n = SK->phase == PH_GOAL && SK->hasCel ? (SK->cel.team == 0 ? 7 : 3) : (int)std::ceil(SK->hitFl * 4);
      for (int i = 0; i < n; i++) { bool top = rnd() < .5; double x = rand(-20, RK.L + 24), y = top ? rand(-19, -3) : rand(RK.Wd + 3, RK.Wd + 19); ctx.alpha(rand(.5, 1)); ctx.fillRect(x, y, 1.5, 1.5); } ctx.alpha(1); }
  }
  ctx.restore();
  skDrawAds(lay); skDrawSideAds(lay); skDrawScratches(lay); skDrawGlass(lay);
  static int SKF = 0;
  if (SK->phase == PH_STOP || SK->phase == PH_GOAL || SK->phase == PH_INTRO) skWarm(lay, 2);
  else if (SK->phase == PH_FACEOFF && SK->fo.t < SK->fo.show - .15) skWarm(lay, 1);
  else if (SK->phase == PH_PLAY && !SK->warmQ.empty() && (SKF = (SKF + 1) % 3) == 0) skWarm(lay, 1);
  // upright things, back (top of screen) to front
  struct It { double y; std::function<void()> draw; }; std::vector<It> list;
  auto ytop = [&](double x) { return skW2S(lay, x, RK.cy).y; };
  list.push_back({ytop(RK.L - RK.gl), [&] { skDrawNet(lay, RK.L - RK.gl, 1, &SK->nb[1], SK->btl[1].s == BT_NET); }});
  list.push_back({ytop(RK.gl - RK.netD), [&] { skDrawNet(lay, RK.gl, -1, &SK->nb[0], SK->btl[0].s == BT_NET); }});
  for (Bottle &b : SK->btl) if (b.s != BT_NET) { Pt q = skW2S(lay, b.x, b.y); Bottle bb = b; list.push_back({q.y + .1, [&lay, q, bb] { skDrawBottle(bb, q.x, q.y - bb.z * lay.s, lay.s); }}); }
  for (int ti = 0; ti < 2; ti++) { Team &t = SK->T[ti]; if (!t.g.out) list.push_back({skW2S(lay, t.g.x, t.g.y).y, [&lay, &t] { skDrawGoalie(t.g, lay, t.col, t.stripe); skPkGlow(t.g.x, t.g.y, t.g.pkF, lay); }}); }
  skDrawPRing(SK->T[0].g, lay); skDrawPRing(SK->T[1].g, lay);
  for (Skater *p : skAll()) list.push_back({skW2S(lay, p->x, p->y).y, [&lay, p] { skDrawSkater(p, lay, SK->T[p->team].col, SK->T[p->team].stripe); skPkGlow(p->x, p->y, p->pkF, lay); }});
  if (SK->hasRef) list.push_back({skW2S(lay, SK->ref.x, SK->ref.y).y, [&lay] { skDrawRef(lay, false); }});
  for (Skater *p : skAll()) skDrawSkater(p, lay, SK->T[p->team].col, SK->T[p->team].stripe, nullptr, 0, true);
  if (SK->hasRef) skDrawRef(lay, true);
  { double z = P.bz; list.push_back({skW2S(lay, P.x, P.y).y + (z > .3 ? 0 : -.01), [&lay, &P, z] { Pt q = skW2S(lay, P.x, P.y, z), g0 = skW2S(lay, P.x, P.y, 0); double r = .34 * lay.s;   // a small puck (NHL pucks are 3 inches)
    skPuckShadow(g0.x + r * .3, g0.y + r * .22, r * (1 + std::min(z, 4.0) * .07), lay.k, z); skPuckSprite(q.x, q.y, r, P); }}); }
  std::stable_sort(list.begin(), list.end(), [](const It &a, const It &b) { return a.y < b.y; });
  for (auto &o : list) o.draw();
  skDrawSpray(lay); skDrawBattle(lay);
  if (SK->phase == PH_GOAL && SK->hasNetIn) { double gx = SK->netIn.gx; Pt q = skW2S(lay, gx < RK.L / 2 ? 0 : RK.L, RK.cy, SK_BH + SK_GH + .6); double k = .5 + .5 * std::sin(now() / 90);
    if (q.y > -20 && q.y < H + 20) { double r = .8 * lay.s; ctx.alpha(.3 + .35 * k); ctx.fill("#ff2d2d"); ctx.disc(q.x, q.y, r * (2.2 + k));
      ctx.alpha(1); ctx.fill(k > .5 ? "#ff6b6b" : "#dc2626"); ctx.fillRect(q.x - r, q.y - r * .8, r * 2, r * 1.6); } }
  // the top of the near boards across the bottom end (we look over them)
  { double s = lay.s, r0 = RK.cr; Pt b = skW2S(lay, 0, 0);
    if (b.y < H + SK_BH * s * 2) { std::vector<Pt> pts = {{r0 + 30, 0}};
      for (int i = 0; i <= 10; i++) { double a = PI * 1.5 - i / 10.0 * PI / 2; pts.push_back({r0 + std::cos(a) * r0, r0 + std::sin(a) * r0}); }
      for (int i = 0; i <= 10; i++) { double a = PI - i / 10.0 * PI / 2; pts.push_back({r0 + std::cos(a) * r0, RK.Wd - r0 + std::sin(a) * r0}); }
      pts.push_back({r0 + 30, RK.Wd});
      ctx.save(); ctx.translate(b.x, b.y);
      cached(Key("sknear") << s << lay.k, [&] { ctx.lineCap(CAP_ROUND);
        const double zs[2] = {SK_BH, SK_BH + SK_GH}; const Col cs[2] = {rgba(71, 85, 105, .75), rgba(255, 255, 255, .45)}; const double lws[2] = {.45, .25};
        for (int j = 0; j < 2; j++) { ctx.stroke(cs[j]); ctx.lineWidth(lws[j] * s); ctx.beginPath();
          for (size_t i = 0; i < pts.size(); i++) { Pt v = skW2S(lay, pts[i].x, pts[i].y, zs[j]); if (i) ctx.lineTo(v.x - b.x, v.y - b.y); else ctx.moveTo(v.x - b.x, v.y - b.y); } ctx.strokePath(); }
        ctx.lineCap(CAP_BUTT); });
      ctx.restore(); } }
  }
  // the bench circle's tag (and an arrow at the screen edge when it's out of view)
  if (skBenchOpen()) { BenchSpot B = skBench(); Pt q = skW2S(lay, B.x, B.y); double th = .032 * U, k = .5 + .5 * std::sin(now() / 170);
    bool on = q.x > 0 && q.x < W && q.y > lay.top && q.y < H;
    if (on) { ctx.save(); ctx.translate(std::round(q.x), std::round(q.y - B.r * lay.s * lay.k - th));
      cached(Key("skbench") << U, [&] { ctx.font(.02 * U); ctx.textMid(); std::string t = "LINE CHANGE"; double tw = ctx.measure(t) + .03 * U;
        ctx.fill(rgba(8, 12, 24, .85)); ctx.rr(-tw / 2, -th / 2, tw, th, th / 2); ctx.fillPath(); ctx.fill("#22c55e"); ctx.fillText(t, 0, 1); }); ctx.restore(); }
    else { double ex = clamp(q.x, .05 * U, W - .05 * U), ey = clamp(q.y, lay.top + .05 * U, H - .08 * U), a = std::atan2(q.y - ey, q.x - ex), m = .035 * U;
      ctx.alpha(.6 + .4 * k); ctx.fill("#22c55e"); ctx.beginPath(); ctx.moveTo(ex + std::cos(a) * m, ey + std::sin(a) * m); ctx.lineTo(ex + std::cos(a + 2.5) * m * .7, ey + std::sin(a + 2.5) * m * .7); ctx.lineTo(ex + std::cos(a - 2.5) * m * .7, ey + std::sin(a - 2.5) * m * .7); ctx.closePath(); ctx.fillPath(); ctx.alpha(1); } }
  // the faceoff timing ring, over the players so the centers never hide it
  if (SK->phase == PH_FACEOFF) { Faceoff &F = SK->fo; Skater *me = SK->user, *c0 = nullptr; for (Skater *q : SK->T[0].on) if (q->role == R_C) { c0 = q; break; } if (!c0 && !SK->T[0].on.empty()) c0 = SK->T[0].on[0];
    if (c0 == me && F.t >= F.show && !g_autoplay) { double v = 7.5 / F.close, pr = skFoEase(F, (F.t - F.show) / F.close), rad = std::max(.15, .9 + 7.5 * (1 - pr)), win = skFoWindow(me); Pt c = skW2S(lay, F.x, F.y); double s = g_view3d ? sk3Scale(F.x, F.y, 0) : lay.s; Layout lay = skLayout(); if (g_view3d) lay.k = .5;
      ctx.stroke(rgba(8, 12, 24, .5)); ctx.lineWidth(std::max(.25, 2 * v * win) * s + 4); ctx.beginPath(); ctx.ellipse(c.x, c.y, .9 * s, .9 * s * lay.k, 0, 0, 7); ctx.strokePath();
      ctx.stroke(rgba(34, 197, 94, .9)); ctx.lineWidth(std::max(.25, 2 * v * win) * s); ctx.beginPath(); ctx.ellipse(c.x, c.y, .9 * s, .9 * s * lay.k, 0, 0, 7); ctx.strokePath();
      ctx.stroke("#facc15"); ctx.lineWidth(.4 * s); ctx.beginPath(); ctx.ellipse(c.x, c.y, rad * s, rad * s * lay.k, 0, 0, 7); ctx.strokePath();
      ctx.fill("#0f172a"); ctx.oval(c.x, c.y, .45 * s, .45 * s * lay.k); } }
  // names: you and the puck carrier; perk pop-ups above them
  auto lab = [&](Skater *p, const std::string &txt, Col c) { Pt s = skW2S(lay, p->x, p->y); double th = .034 * U, yy = headY(lay, p->x, p->y) - th / 2;
    ctx.save(); ctx.translate(std::round(s.x), std::round(yy));
    cached(Key("sklab") << txt << c << U, [&] { ctx.font(.024 * U); ctx.textMid(); double tw = ctx.measure(txt) + .02 * U;
      ctx.fill(rgba(8, 12, 24, .75)); ctx.rr(-tw / 2, -th / 2, tw, th, th / 2); ctx.fillPath(); ctx.fill(c); ctx.fillText(txt, 0, 0); }); ctx.restore(); };
  auto pkLab = [&](double ox, double oy, const PkLabel &L, bool high) { if (!(L.t > 0)) return; Pt s = skW2S(lay, ox, oy); double th = .03 * U, k = clamp(L.t / .25, 0, 1);
    double yy = headY(lay, ox, oy) - th * (high ? 2.9 : 1.7) - (1.1 - L.t) * .03 * U;
    ctx.save(); ctx.translate(std::round(s.x), std::round(yy)); ctx.alpha(std::ceil(k * 4) / 4);
    cached(Key("skpkl") << L.uid << L.c << U, [&] { ctx.font(.02 * U); ctx.textMid(); double tw = ctx.measure(L.n) + .03 * U;
      ctx.fill(L.c); ctx.rr(-tw / 2 - 2, -th / 2 - 2, tw + 4, th + 4, th / 2 + 2); ctx.fillPath();
      ctx.fill(rgba(255, 255, 255, .95)); ctx.rr(-tw / 2, -th / 2, tw, th, th / 2); ctx.fillPath(); ctx.fill(PERKS[L.id].col); ctx.rr(-tw / 2, -th / 2, th * .42, th, th * .21); ctx.fillPath();
      ctx.fill("#0f172a"); ctx.fillText(L.n, th * .1, .5); }); ctx.alpha(1); ctx.restore(); };
  for (Skater *o : skAll()) pkLab(o->x, o->y, o->pkL, o == SK->user || o == SK->puck.owner);
  for (auto &t : SK->T) if (!t.g.out) pkLab(t.g.x, t.g.y, t.g.pkL, false);
  // L held with the puck: the button over each teammate's head; "!" over a teammate calling for it
  { Skater *u = SK->user; bool lOn = u && P.owner == u && (g_pad.btn & B_L) && SK->phase == PH_PLAY && !g_autoplay;
    for (Skater *q : SK->T[0].on) { if (q == u) continue; Pt s = skW2S(lay, q->x, q->y); double r = .026 * U, yy = headY(lay, q->x, q->y) - r * 1.4 - (q == P.owner ? .04 * U : 0);
      int btn = -1; if (lOn) for (int k = 0; k < 3; k++) if (skMateFor(k) == q) btn = k;
      if (btn >= 0) { ctx.save(); ctx.translate(std::round(s.x), std::round(yy));
        cached(Key("skbtn") << btn << U, [&] { ctx.fill(rgba(8, 12, 24, .9)); ctx.disc(0, 0, r); ctx.stroke(rgba(255, 255, 255, .85)); ctx.lineWidth(std::max(1.5, r * .1)); ctx.ring(0, 0, r);
          double k = r * .5; ctx.lineWidth(std::max(2.0, r * .16));
          if (btn == 0) { ctx.stroke("#f472b6"); ctx.strokeRect(-k * .8, -k * .8, k * 1.6, k * 1.6); }
          else if (btn == 1) { ctx.stroke("#34d399"); ctx.beginPath(); ctx.moveTo(0, -k * .95); ctx.lineTo(k * .9, k * .65); ctx.lineTo(-k * .9, k * .65); ctx.closePath(); ctx.strokePath(); }
          else { ctx.stroke("#f87171"); ctx.ring(0, 0, k * .85); } });
        ctx.restore(); yy -= r * 2.3; }
      if (q->call > 0 && P.owner == u) { double b = std::round(std::fabs(std::sin(now() / 140)) * 3) / 3 * .006 * U; ctx.save(); ctx.translate(std::round(s.x), std::round(yy - b));
        cached(Key("skcall") << U, [&] { double rr = .022 * U; ctx.fill("#facc15"); ctx.disc(0, 0, rr); ctx.stroke("#0f172a"); ctx.lineWidth(2); ctx.ring(0, 0, rr);
          ctx.fill("#0f172a"); ctx.fillRect(-rr * .14, -rr * .62, rr * .28, rr * .8); ctx.fillRect(-rr * .14, rr * .33, rr * .28, rr * .28); });
        ctx.restore(); } } }
  if (P.owner && P.owner != SK->user) lab(P.owner, (P.owner->star ? "★ " : "") + P.owner->nm, P.owner->team == 0 ? hex("#93c5fd") : hex("#fca5a5"));
  if (onTeam(0, SK->user)) {
    lab(SK->user, "YOU", hex("#ffd54a"));
    Pt s = skW2S(lay, SK->user->x, SK->user->y); double m = .04 * U;
    if (s.x < 0 || s.x > W || s.y < lay.top || s.y > H) { double ex = clamp(s.x, m, W - m), ey = clamp(s.y, lay.top + m, H - m), a = std::atan2(s.y - ey, s.x - ex);
      ctx.fill("#ffd54a"); ctx.beginPath(); ctx.moveTo(ex + std::cos(a) * m * .8, ey + std::sin(a) * m * .8); ctx.lineTo(ex + std::cos(a + 2.5) * m * .6, ey + std::sin(a + 2.5) * m * .6); ctx.lineTo(ex + std::cos(a - 2.5) * m * .6, ey + std::sin(a - 2.5) * m * .6); ctx.closePath(); ctx.fillPath(); }
  }
  if (shk) ctx.restore();
  if (SK->phase == PH_GOAL) { double k = .5 + .5 * std::sin(now() / 70); ctx.fill(SK->gcol); ctx.alpha(.06 + .1 * k); ctx.fillRect(0, 0, W, H); ctx.alpha(1); skCelebFx(); }
  skHUD(lay);
}

// ----- the figures for menus and cards (key art, card fronts)
void menuSkFig(double f, int d, double stride, Col col, Col stripe, Col skin, Col helm, double lean, double wind, bool star) {
  FigO o; o.f = f; o.d = d; o.stride = stride; o.col = col; o.stripe = stripe; o.skin = skin; o.helm = helm; o.lean = lean; o.wind = wind; o.star = star; skFig(o);
}
void menuGoalieFig(double f, Col col, Col stripe, Col pants) {
  GFigO o; o.f = f; o.toward = true; o.col = col; o.stripe = stripe; o.pants = pants; o.pose = GP_NONE; o.k = 0; o.side = 1; o.set = 0; o.lean = 0; skGoalieFig(o);
}

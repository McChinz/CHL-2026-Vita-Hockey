// CHL 2026 native - what the game needs from the machine it runs on.
// platform_vita.cpp: the PS Vita (vita2d, SceCtrl / SceTouch, SceAudio). platform_host.cpp: a desktop build
// with a software renderer and scripted input, used to test the game without a Vita.
#pragma once
#include <cstdint>
#include <string>

// buttons (same bits the JS build used)
enum {
  B_L = 1, B_R = 2, B_START = 4, B_SELECT = 8, B_CROSS = 16, B_CIRCLE = 32, B_SQUARE = 64, B_TRIANGLE = 128,
  B_UP = 256, B_DOWN = 512, B_LEFT = 1024, B_RIGHT = 2048
};
struct Pad { uint32_t btn = 0; int lx = 128, ly = 128, rx = 128, ry = 128; };
struct TouchPt { int id; float x, y; };
struct Touch { int n = 0; TouchPt p[6]; };

bool plat_init();                 // false: could not start (the game shows nothing and exits)
void plat_shutdown();
bool plat_running();              // false once the system asks the app to close
void plat_begin_frame(uint32_t clear);
void plat_end_frame();            // presents, paced to a steady 30 FPS on the Vita
double plat_now_ms();
void plat_input(Pad &pad, Touch &touch);
void plat_log(const std::string &s);
bool plat_read_file(const std::string &path, std::string &out);
bool plat_write_file(const std::string &path, const std::string &data);
std::string plat_data_dir();

// sound: ids follow SND_NAMES in audio.h; returns a voice number for loops (or -1)
int snd_play(int id, float vol, float rate, bool loop);
void snd_set(int voice, float vol);
void snd_stop(int voice);         // -1: everything

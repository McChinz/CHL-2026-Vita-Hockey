// CHL 2026 native - what the game needs from the machine it runs on.
// platform_vita.cpp: the PS Vita (vita2d, SceCtrl / SceTouch, SceAudio). platform_host.cpp: a desktop build
// with a software renderer and scripted input, used to test the game without a Vita.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

// buttons (same bits the JS build used)
enum {
  B_L = 1, B_R = 2, B_START = 4, B_SELECT = 8, B_CROSS = 16, B_CIRCLE = 32, B_SQUARE = 64, B_TRIANGLE = 128,
  B_UP = 256, B_DOWN = 512, B_LEFT = 1024, B_RIGHT = 2048
};
struct Pad { uint32_t btn = 0; int lx = 128, ly = 128, rx = 128, ry = 128; };
struct TouchPt { int id; float x, y; };
struct Touch { int n = 0; TouchPt p[6]; };

bool plat_init();                 // false: could not start (the game shows nothing and exits)
void plat_shutdown();
bool plat_running();              // false once the system asks the app to close
void plat_begin_frame(uint32_t clear);
void plat_end_frame();            // presents, paced to a steady 30 FPS on the Vita
double plat_now_ms();
void plat_input(Pad &pad, Touch &touch);
void plat_log(const std::string &s);
bool plat_read_file(const std::string &path, std::string &out);
std::vector<std::string> plat_list_dir(const std::string &dir);   // the file names in a folder (none if it isn't there)
bool plat_write_file(const std::string &path, const std::string &data);
std::string plat_data_dir();
std::string plat_legacy_dir();    // where the legacy (JavaScript) build kept its saves: imported on the first run

// GPU 3D (the vitaGL build): world-space triangles drawn with a depth buffer. Where it isn't there (vita2d, the
// PC test build) the game projects and sorts the triangles itself and draws them with plat_tris.
struct V3c { float x, y, z; uint32_t c; float u, v; };   // position, colour, texture coordinate
bool plat_gpu3d();
// m16: the clip matrix (column-major); mode 0 solid, 1 painted on the ice (tested, no depth write), 2 see-through,
// 3 shadow: tested, no depth write, and each pixel keeps the DARKER of what's there and the shadow, so shadows that
// overlap never add up (where the machine can't do that it falls back to ordinary see-through blending)
// tex: a texture made with plat_tex (its colours multiply the vertex colours), or -1 for none
void plat_draw3d(const float *m16, const V3c *v, int n, int mode, int tex);
// the same for geometry that never changes (the rink, crowd, nets): converted for the GPU once and kept (ver: rebuilt when it changes)
void plat_draw3d_static(const float *m16, const void *key, const V3c *v, int n, int mode, int tex, uint32_t ver);
void plat_draw3d_free(const void *key);   // drop a static batch now (its memory comes back right away)
// textures for the 3D view: slot 0..7, RGBA bytes (smooth filtering, no mipmaps: the game keeps smaller copies itself)
void plat_tex(int slot, int w, int h, const unsigned char *rgba);

// sound: ids follow SND_NAMES in audio.h; returns a voice number for loops (or -1)
int snd_play(int id, float vol, float rate, bool loop);
void snd_set(int voice, float vol);
void snd_stop(int voice);         // -1: everything

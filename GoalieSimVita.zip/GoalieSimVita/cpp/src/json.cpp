// CHL 2026 native - JSON text <-> J (see json.h)
#include "json.h"
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>

static void dumpStr(const std::string &s, std::string &o) {
  o += '"';
  for (unsigned char c : s) {
    if (c == '"') o += "\\\""; else if (c == '\\') o += "\\\\"; else if (c == '\n') o += "\\n"; else if (c == '\r') o += "\\r"; else if (c == '\t') o += "\\t";
    else if (c < 0x20) { char b[8]; snprintf(b, sizeof b, "\\u%04x", c); o += b; }
    else o += (char)c;
  }
  o += '"';
}
static void dumpNum(double v, std::string &o) {
  if (!std::isfinite(v)) { o += "null"; return; }   // JSON.stringify(NaN) === "null"
  if (v == std::floor(v) && std::fabs(v) < 1e15) { char b[32]; snprintf(b, sizeof b, "%lld", (long long)v); o += b; return; }
  char b[40]; snprintf(b, sizeof b, "%.17g", v);
  // shortest form that reads back the same (like JS)
  for (int p = 1; p <= 17; p++) { char c[40]; snprintf(c, sizeof c, "%.*g", p, v); if (strtod(c, nullptr) == v) { o += c; return; } }
  o += b;
}
static void dumpJ(const J &j, std::string &o) {
  switch (j.t) {
  case J::NUL: o += "null"; break;
  case J::BOOL: o += j.b ? "true" : "false"; break;
  case J::NUM: dumpNum(j.n, o); break;
  case J::STR: dumpStr(j.s, o); break;
  case J::ARR: o += '['; for (size_t i = 0; i < j.a.size(); i++) { if (i) o += ','; dumpJ(j.a[i], o); } o += ']'; break;
  case J::OBJ: o += '{'; for (size_t i = 0; i < j.a.size(); i++) { if (i) o += ','; dumpStr(j.k[i], o); o += ':'; dumpJ(j.a[i], o); } o += '}'; break;
  }
}
std::string J::dump() const { std::string o; o.reserve(4096); dumpJ(*this, o); return o; }

namespace {
struct P {
  const char *s, *e; bool ok = true;
  void ws() { while (s < e && (*s == ' ' || *s == '\n' || *s == '\r' || *s == '\t')) s++; }
  static void utf8(std::string &o, unsigned cp) {
    if (cp < 0x80) o += (char)cp;
    else if (cp < 0x800) { o += (char)(0xC0 | (cp >> 6)); o += (char)(0x80 | (cp & 63)); }
    else if (cp < 0x10000) { o += (char)(0xE0 | (cp >> 12)); o += (char)(0x80 | ((cp >> 6) & 63)); o += (char)(0x80 | (cp & 63)); }
    else { o += (char)(0xF0 | (cp >> 18)); o += (char)(0x80 | ((cp >> 12) & 63)); o += (char)(0x80 | ((cp >> 6) & 63)); o += (char)(0x80 | (cp & 63)); }
  }
  std::string str() {
    std::string o; s++;
    while (s < e && *s != '"') {
      if (*s == '\\' && s + 1 < e) {
        s++; char c = *s++;
        if (c == 'n') o += '\n'; else if (c == 't') o += '\t'; else if (c == 'r') o += '\r'; else if (c == 'b') o += '\b'; else if (c == 'f') o += '\f';
        else if (c == 'u' && s + 4 <= e) { unsigned cp = (unsigned)strtoul(std::string(s, 4).c_str(), nullptr, 16); s += 4;
          if (cp >= 0xD800 && cp < 0xDC00 && s + 6 <= e && s[0] == '\\' && s[1] == 'u') { unsigned lo = (unsigned)strtoul(std::string(s + 2, 4).c_str(), nullptr, 16); s += 6; cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00); }
          utf8(o, cp); }
        else o += c;
      } else o += *s++;
    }
    if (s < e) s++; else ok = false;
    return o;
  }
  J val(int depth) {
    ws(); if (s >= e || depth > 200) { ok = false; return J(); }
    char c = *s;
    if (c == '{') { s++; J o = J::obj(); ws(); if (s < e && *s == '}') { s++; return o; }
      while (ok && s < e) { ws(); if (s >= e || *s != '"') { ok = false; break; } std::string key = str(); ws(); if (s >= e || *s != ':') { ok = false; break; } s++;
        o.k.push_back(key); o.a.push_back(val(depth + 1)); ws(); if (s < e && *s == ',') { s++; continue; } if (s < e && *s == '}') { s++; break; } ok = false; }
      return o; }
    if (c == '[') { s++; J o = J::arr(); ws(); if (s < e && *s == ']') { s++; return o; }
      while (ok && s < e) { o.a.push_back(val(depth + 1)); ws(); if (s < e && *s == ',') { s++; continue; } if (s < e && *s == ']') { s++; break; } ok = false; }
      return o; }
    if (c == '"') return J(str());
    if (!strncmp(s, "true", 4)) { s += 4; return J(true); }
    if (!strncmp(s, "false", 5)) { s += 5; return J(false); }
    if (!strncmp(s, "null", 4)) { s += 4; return J(); }
    char *end; double v = strtod(s, &end); if (end == s) { ok = false; return J(); } s = end; return J(v);
  }
};
}
J J::parse(const std::string &src, bool *ok) {
  P p{src.data(), src.data() + src.size()}; J j = p.val(0);
  if (ok) *ok = p.ok;
  return p.ok ? j : J();
}

// CHL 2026 native - menus, ported from the legacy build: the main menu with its key art, settings, the name
// keyboard, the result screen, Quick Play, the YES / NO modal, D-pad / stick navigation and the router that
// every button goes through. Same layout, sizes, colours and wording as the legacy build.
#include "menu.h"
#include "ut.h"
#include "sk_int.h"

const Col ACC = hex("#f26b5b");
std::vector<Btn> btns;
std::string mFocus; bool mPadUsed = false;
std::string mode = "quick", screen = "modes", pname = "ROOKIE", nameFor = "pro";
int nameTarget = 0;
Settings settings;
Modal modal;
RSum rs; double lockUntil = 0; bool g_lastQuit = false;
static const char *GAME_VER = "0.1";

void pushBtn(const std::string &id, double x, double y, double w, double h, const std::string &lb, bool np) { Btn b; b.id = id; b.x = x; b.y = y; b.w = w; b.h = h; b.lb = lb; b.np = np; btns.push_back(b); }
void askModal(const std::string &t, const std::string &s, std::function<void()> yes) { modal.on = true; modal.t = t; modal.s = s; modal.yes = yes; }

// ---------------------------------------------------------------- text and numbers
std::string fmtN(double n) {
  std::string s = istr((long long)std::floor(n)), o; int neg = s[0] == '-' ? 1 : 0;
  for (size_t i = 0; i < s.size(); i++) { o += s[i]; size_t left = s.size() - 1 - i; if ((int)i >= neg && left > 0 && left % 3 == 0) o += ','; }
  return o;
}
std::string fixed(double v, int d) { char b[48]; double p = std::pow(10.0, d); v = std::floor(v * p + .5) / p; snprintf(b, sizeof b, "%.*f", d, v); return b; }
std::string fmtM(double v) { return "$" + fixed(std::floor(v * 10 + .5) / 10, 1) + "M"; }
std::string svp3(double a, double b) { if (b <= 0) return ".000"; std::string s = fixed(a / b, 3); if (s[0] == '0') s = s.substr(1); return s; }
void tx(const std::string &t, double x, double y, double sz, const char *c, Align al, int, bool it) { tx(t, x, y, sz, hex(c), al, it); }
std::vector<std::string> wrapText(const std::string &t, double maxW) {
  std::vector<std::string> out; std::string cur, w; size_t i = 0;
  while (i <= t.size()) { if (i == t.size() || t[i] == ' ') { std::string n = cur.empty() ? w : cur + " " + w;
      if (ctx.measure(n) > maxW && !cur.empty()) { out.push_back(cur); cur = w; } else cur = n; w.clear(); } else w += t[i]; i++; }
  if (!cur.empty()) out.push_back(cur); return out;
}
void txWrap(const std::string &t, double x, double y, double sz, double maxW, Col c, Align al, int, int maxL) {
  double px = fsz(sz) * U; ctx.font(px); auto ls = wrapText(t, maxW); int k = 0;
  while ((int)ls.size() > maxL && k++ < 5) { px *= .9; ctx.font(px); ls = wrapText(t, maxW); }
  double lh = px * 1.2; int n = std::min((int)ls.size(), maxL); ctx.align(al); ctx.baseline(BL_MIDDLE); ctx.fill(c);
  for (int i = 0; i < n; i++) ctx.fillText(ls[i], x, y + (i - (n - 1) / 2.0) * lh);
}
static double fszInv(double v) { return v < .024 ? (v - .0096) / .6 : v; }
void txFit(const std::string &t, double x, double y, double sz, double maxW, Col c, Align al) {
  ctx.font(fsz(sz) * U); double w = ctx.measure(t); tx(t, x, y, w > maxW ? fszInv(fsz(sz) * maxW / w) : sz, c, al);
}
// the current fill colour, shrunk to fit maxW
double utFitTx(const std::string &t, double x, double y, double px, double maxW, Align al) {
  ctx.font(px); double w = ctx.measure(t); if (w > maxW && w > 0) { px *= maxW / w; ctx.font(px); }
  ctx.align(al); ctx.fillText(t, x, y); return px;
}
void rrPath(double x, double y, double w, double h, double r) { ctx.rr(x, y, w, h, r); }

// ---------------------------------------------------------------- the broadcast look
void menuBG() {
  cached(Key("mbg") << W << H, [] {
    Grad g = gLin(0, 0, W, H); g.add(0, hex("#0b1024")); g.add(.6f, hex("#111a33")); g.add(1, hex("#2a0f1c"));
    ctx.fill(g); ctx.fillRect(0, 0, W, H);
    ctx.fill(rgba(255, 255, 255, .022)); for (int i = -4; i < 12; i++) ctx.quad(i * W * .12, 0, i * W * .12 + W * .05, 0, i * W * .12 - W * .15, H, i * W * .12 - W * .2, H); });
}
void menuSnow() {
  double t = now() / 1000;
  for (int i = 0; i < 34; i++) { double sp = 18 + (i * 37 % 23), x = std::fmod(i * 197.3 + t * sp, W + 60) - 30, y = std::fmod(i * 131.7, H) + std::sin(t * .6 + i) * 12, r = 1.2 + (i % 4) * .7;
    ctx.alpha(.05 + (i % 5) * .018); ctx.fill(i % 3 ? "#dbeafe" : "#93c5fd"); ctx.fillRect(x, y, r * 3.2, r); }
  ctx.alpha(1);
}
double wordmarkW(double s) { ctx.font(s); return ctx.measure("CHL ") + s * .3 + ctx.measure("2026"); }
void wordmarkC(double cx, double y, double s) { wordmark(cx - wordmarkW(s) / 2, y, s); }
void menuSkFig(double f, int d, double stride, Col col, Col stripe, Col skin, Col helm, double lean, double wind, bool star);
void menuGoalieFig(double f, Col col, Col stripe, Col pants);
// key art: one of our own skaters (or goalies) under arena lights
void heroArt(double x, double y, double w, double h, Col col, Col stripe, bool goalie, int seed) {
  ctx.save(); ctx.translate(x, y);
  cached(Key("hero") << (int)std::round(w) << (int)std::round(h) << col << stripe << goalie << seed, [&] {
    Grad g0 = gLin(0, 0, 0, h * .62); g0.add(0, hex("#10162a")); g0.add(1, hex("#1f2946")); ctx.fill(g0); ctx.fillRect(0, 0, w, h * .62);
    Grad g = gLin(0, h * .62, 0, h); g.add(0, hex("#1f2946")); g.add(1, hex("#d9e6f2")); ctx.fill(g); ctx.fillRect(0, h * .62, w, h * .38);
    SkRng R(seed ? seed : 7);
    for (int i = 0; i < 26; i++) { double bx = R() * w, by = R() * h * .55, br = (2 + R() * 7) * U / 400; ctx.fill(rgba(255, 236, 200, (float)(.08 + R() * .35))); ctx.disc(bx, by, br); }
    ctx.fill(rgba(255, 255, 255, .18)); ctx.oval(w * .62, h * .93, w * .36, h * .06);
    ctx.fill(rgba(220, 38, 38, .22)); ctx.fillRect(0, h * .86, w, h * .012);
    double f = h * .86 / 6.4; ctx.save(); ctx.translate(w * .7, h * .95);
    if (goalie) menuGoalieFig(f * .92, col, stripe, shade(col, -.55));
    else menuSkFig(f, 3, .5, col, stripe, hex("#e0a878"), shade(col, -.15), .45, .55, true);
    ctx.restore();
    Grad v = gLin(0, 0, w * .55, 0); v.add(0, rgba(8, 12, 26, .85)); v.add(1, rgba(8, 12, 26, 0)); ctx.fill(v); ctx.fillRect(0, 0, w * .55, h);
  });
  ctx.restore();
}
void footHints(const std::vector<std::pair<std::string, std::string>> &h) {
  double fh = .055 * U, fy = H - fh / 2 - 4, hx = .03 * U;
  for (auto &x : h) { ctx.font(.0216 * U); double bw = ctx.measure(x.first) + .02 * U, bh = .032 * U;
    ctx.stroke("#cbd5e1"); ctx.lineWidth(1.5); ctx.rr(hx, fy - bh / 2, bw, bh, bh * .3); ctx.strokePath(); ctx.fill("#cbd5e1"); ctx.textMid(); ctx.fillText(x.first, hx + bw / 2, fy + 1);
    ctx.textMid(AL_LEFT); ctx.font(.0222 * U); ctx.fillText(x.second, hx + bw + .01 * U, fy + 1); hx += bw + .02 * U + ctx.measure(x.second) + .03 * U; }
}
void menuItem(const std::string &id, const std::string &label, double x, double y, double w, double h, bool big, bool on) {
  ctx.textMid(AL_LEFT);
  if (on) { ctx.fill("#f1f5f9"); ctx.quad(x, y, x + w, y, x + w - h * .25, y + h, x, y + h); ctx.fill("#0f172a"); }
  else ctx.fill(big ? "#fff" : "#cbd5e1");
  { double fs = big ? h * .62 : h * .5; ctx.font(fs); double mw = w - (on ? h * .55 : h * .1), tw = ctx.measure(label); if (tw > mw) ctx.font(fs * mw / tw); }
  ctx.fillText(label, x + (on ? h * .2 : 0), y + h / 2 + 1);
  pushBtn(id, x, y, w, h, label);
}
void ui(const std::string &id, double x, double y, double w, double h, const std::string &label, Col col, bool on, double fs) {
  double sk = std::min(h * .22, 10.0), ab = std::max(4.0, h * .08); bool neutral = col == hex("#334155") || col == hex("#475569");
  auto quad = [&](double x0, double x1, Col c) { ctx.fill(c); ctx.quad(x0 + sk, y, x1 + sk, y, x1 - sk, y + h, x0 - sk, y + h); };
  quad(x + sk, x + w - sk, on ? rgba(30, 41, 59, .96) : rgba(30, 41, 59, .45));
  if (on && !neutral) { ctx.alpha(.38); quad(x + sk, x + w - sk, col); ctx.alpha(1); quad(x + sk, x + sk + ab, col); }
  ctx.fill(on ? "#fff" : "#64748b"); ctx.textMid();
  double px = std::min((fs ? fs : .04) * U, h * .62), mw = w - 2 * sk - std::max(8.0, h * .3); ctx.font(px); double tw = ctx.measure(label); if (tw > mw) ctx.font(px * mw / tw);
  ctx.fillText(label, x + w / 2, y + h / 2 + 1);
  Btn b; b.id = id; b.x = x; b.y = y; b.w = w; b.h = h; b.lb = label; b.dis = !on; btns.push_back(b);
}
void drawModal() {
  if (!modal.on) return;
  btns.clear();
  ctx.fill(rgba(2, 6, 23, .72)); ctx.fillRect(0, 0, W, H);
  double pw = std::min(W - 40.0, 1.05 * U), ph = .42 * U, px = (W - pw) / 2, py = (H - ph) / 2;
  ctx.fill(rgba(15, 23, 42, .98)); ctx.fillRect(px, py, pw, ph); ctx.fill("#dc2626"); ctx.fillRect(px, py, pw, .012 * U);
  ctx.textMid(); ctx.fill("#fff"); ctx.fitPx(modal.t, .055 * U, pw * .94); ctx.fillText(modal.t, W / 2, py + .09 * U);
  ctx.fill("#cbd5e1"); ctx.fitPx(modal.s, .03 * U, pw * .94); ctx.fillText(modal.s, W / 2, py + .17 * U);
  double bw = pw * .36, bh = .095 * U, by = py + ph - bh - .06 * U;
  ui("mdl:yes", W / 2 - bw - .02 * U, by, bw, bh, "YES", "#dc2626", true, .042);
  ui("mdl:no", W / 2 + .02 * U, by, bw, bh, "NO", "#475569", true, .042);
  if (mFocus != "mdl:yes" && mFocus != "mdl:no") mFocus = "mdl:no";
}

// ---------------------------------------------------------------- pad navigation
static bool noPad(const Btn &b) { return b.np || b.id.rfind("gcat:", 0) == 0 || b.id.rfind("utab:", 0) == 0 || b.id.rfind("ucat:", 0) == 0 || b.id.rfind("ptab:", 0) == 0; }
static bool isBackLb(const std::string &l) { return l == "BACK" || l == "CANCEL" || l == "MAIN MENU" || l == "DONE"; }
static const Btn *padFirst() {
  static const char *pref[] = {"mdl:no", "num:ok", "play", "next", "skipday", "off:neg", "simheal", "sim1", "resume", "namego", "draftdone", "neg:ok", "train:0", "ntc:0", "tq:go", "mode:pro"};
  std::vector<const Btn *> nav; for (auto &b : btns) if (!noPad(b)) nav.push_back(&b);
  for (auto *b : nav) if (!b->dis) for (auto p : pref) if (b->id == p) return b;
  for (auto *b : nav) if (!b->dis && !isBackLb(b->lb)) return b;
  if (!nav.empty()) return nav[0]; return btns.empty() ? nullptr : &btns[0];
}
// 1) buttons that overlap the current one across the direction of travel (same row / same column): the closest
// edge. 2) horizontal with nothing in the row: wrap to the other end of the row. 3) otherwise the nearest one
// in that direction, weighting sideways distance heavily.
static const Btn *padMove(const Btn &cur, int dir) {
  bool H_ = dir >= 3; double c0 = H_ ? cur.y : cur.x, c1 = H_ ? cur.y + cur.h : cur.x + cur.w, cc = (c0 + c1) / 2;
  std::vector<const Btn *> nav; for (auto &b : btns) if (&b != &cur && !noPad(b)) nav.push_back(&b);
  auto gap = [&](const Btn *b) { return dir == 1 ? cur.y - (b->y + b->h) : dir == 2 ? b->y - (cur.y + cur.h) : dir == 3 ? cur.x - (b->x + b->w) : b->x - (cur.x + cur.w); };
  auto ctr = [&](const Btn *b) { return dir == 1 ? cur.y + cur.h / 2 - (b->y + b->h / 2) : dir == 2 ? b->y + b->h / 2 - (cur.y + cur.h / 2) : dir == 3 ? cur.x + cur.w / 2 - (b->x + b->w / 2) : b->x + b->w / 2 - (cur.x + cur.w / 2); };
  auto ov = [&](const Btn *b) { double b0 = H_ ? b->y : b->x, b1 = H_ ? b->y + b->h : b->x + b->w; return std::min(c1, b1) - std::max(c0, b0); };
  auto side = [&](const Btn *b) { return std::fabs((H_ ? b->y + b->h / 2 : b->x + b->w / 2) - cc); };
  std::vector<const Btn *> ahead, lined;
  for (auto *b : nav) if (ctr(b) > 4 && gap(b) > -std::min(cur.w, cur.h) * .5) ahead.push_back(b);
  for (auto *b : ahead) if (ov(b) > std::min(H_ ? cur.h : cur.w, H_ ? b->h : b->w) * (H_ ? .5 : .2)) lined.push_back(b);
  if (!lined.empty()) { const Btn *best = nullptr; double bs = 1e9; for (auto *b : lined) { double sc = std::max(0.0, gap(b)) + side(b) * .35; if (sc < bs) { bs = sc; best = b; } } return best; }
  if (H_) { const Btn *r = nullptr; for (auto *b : nav) if (ov(b) > std::min(cur.h, b->h) * .5 && ctr(b) < -4) { if (!r || ctr(b) < ctr(r)) r = b; } if (r) return r; }
  const Btn *best = nullptr; double bs = 1e9; for (auto *b : ahead) { double sc = std::max(0.0, ctr(b)) + side(b) * 2.5; if (sc < bs) { bs = sc; best = b; } }
  return best;
}
void drawFocus() {
  if (!mPadUsed) return; const Btn *b = nullptr; for (auto &q : btns) if (q.id == mFocus && !q.np) { b = &q; break; }
  if (!b && !btns.empty()) { b = padFirst(); if (b) mFocus = b->id; }
  if (!b || b->np) return;
  double t = .5 + .5 * std::sin(now() / 160);
  ctx.stroke(ACC); ctx.lineWidth(3); ctx.alpha(.75 + .25 * t); ctx.strokeRect(b->x - 3, b->y - 3, b->w + 6, b->h + 6); ctx.alpha(1);
  ctx.fill(ACC); ctx.beginPath(); ctx.moveTo(b->x - 12, b->y + b->h / 2 - 7); ctx.lineTo(b->x - 4, b->y + b->h / 2); ctx.lineTo(b->x - 12, b->y + b->h / 2 + 7); ctx.closePath(); ctx.fillPath();
}
static void menuShoulder(int d) {
  if (screen == "utroster") { utShoulder(d); return; }
}
static double mRep = 0, mHeldRep = 0; static int mLastDir = 0, mHeld = 0;
static void tapUI(float x, float y) {
  mPadUsed = false;
  for (auto &b : btns) if (x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h) { std::string id = b.id; bool dis = b.dis; if (!dis) uiTap(id); return; }
}
// the pad on menu screens: D-pad / left stick move (held: repeats), X selects, O backs out, SQUARE deletes or
// sells, TRIANGLE examines a card, L / R page
static void menuPadButtons(uint32_t press, const Pad &pad) {
  if (trActive() || btns.empty()) return;
  if (press & 3) { menuShoulder(press & 1 ? -1 : 1); if (!(press & ~3u)) return; }
  int dir = press & B_UP ? 1 : press & B_DOWN ? 2 : press & B_LEFT ? 3 : press & B_RIGHT ? 4 : 0;
  double t = now(); uint32_t btn = pad.btn;
  int hd = btn & B_UP ? 1 : btn & B_DOWN ? 2 : btn & B_LEFT ? 3 : btn & B_RIGHT ? 4 : 0;
  if (dir) { mHeld = dir; mHeldRep = t + 420; } else if (hd && hd == mHeld && t > mHeldRep) { dir = hd; mHeldRep = t + 130; }
  if (!hd) mHeld = 0;
  double sx = (pad.lx - 128) / 127.0, sy = (pad.ly - 128) / 127.0; int sd = hyp(sx, sy) > .6 ? (std::fabs(sy) > std::fabs(sx) ? (sy < 0 ? 1 : 2) : (sx < 0 ? 3 : 4)) : 0;
  if (!dir && !hd && sd) { if (sd != mLastDir || t > mRep) { dir = sd; mRep = t + (sd != mLastDir ? 420 : 170); } }
  mLastDir = sd;
  if (!dir && !(press & (B_CROSS | B_CIRCLE | B_SQUARE | B_TRIANGLE))) return;
  mPadUsed = true;
  const Btn *cur = nullptr; for (auto &b : btns) if (b.id == mFocus && !b.np) { cur = &b; break; }
  if (cur && noPad(*cur)) cur = nullptr;
  if (!cur) { cur = padFirst(); if (!cur) return; mFocus = cur->id; if (dir) return; }
  Btn C = *cur;
  if (press & B_CROSS) { if (!C.dis) uiTap(C.id); return; }
  if (press & B_CIRCLE) { if (modal.on) { modal.on = false; return; }
    const Btn *bk = nullptr; for (auto &b : btns) if (isBackLb(b.lb)) { bk = &b; break; }
    if (!bk) for (auto &b : btns) if (b.id == "nav:modes" || b.id == "namecancel") { bk = &b; break; }
    if (bk) { std::string id = bk->id; uiTap(id); } return; }
  if (press & B_SQUARE) { if (!modal.on) { if (screen == "utslots" || screen == "utroster") utPadSquare(C.id); } if (!dir) return; }
  if (press & B_TRIANGLE) { if (!modal.on) utPadTriangle(C); if (!dir) return; }
  const Btn *best = padMove(C, dir);
  if (best) mFocus = best->id;
}
// touch on the menus: a press acts on the button under it (cards in Ultimate Franchise: hold to flip)
static Touch prevTouch;
static void menuTouch(const Touch &t) {
  for (int j = 0; j < t.n; j++) { bool was = false; for (int i = 0; i < prevTouch.n; i++) if (prevTouch.p[i].id == t.p[j].id) was = true;
    if (!was) { if (mode == "ut" && utLPDown(t.p[j].x, t.p[j].y, t.p[j].id)) continue; tapUI(t.p[j].x, t.p[j].y); } }
  for (int i = 0; i < prevTouch.n; i++) { bool still = false; float x = prevTouch.p[i].x, y = prevTouch.p[i].y;
    for (int j = 0; j < t.n; j++) if (t.p[j].id == prevTouch.p[i].id) still = true;
    if (!still) utLPUp(prevTouch.p[i].id, x, y, true); }
  prevTouch = t;
}
void menuPad(uint32_t press, const Pad &pad, const Touch &touch) {
  if (trActive()) { prevTouch = touch; return; }
  menuTouch(touch);
  menuPadButtons(press, pad);
}

// ---------------------------------------------------------------- the main menu
struct LastI { std::string m; int i = -1; };
static LastI lastInfo() {
  J &L = lastSave(); LastI o;
  if (L("m").str() == "ut" && L("i").i(-1) >= 0 && L("i").i() < 3 && utSlots[L("i").i()]) { o.m = "ut"; o.i = L("i").i(); return o; }
  for (int i = 0; i < 3; i++) if (utSlots[i]) { o.m = "ut"; o.i = i; return o; }
  return o;
}
static void drawMainMenu() {
  bool land = W > H * 1.15; double m = .035 * U, ty = safeTop + .05 * U;
  wordmark(m, ty, .05 * U);
  ctx.font(.0204 * U); ctx.fill("#94a3b8"); ctx.textMid(AL_RIGHT); ctx.fillText(std::string(IS_VITA ? "PS VITA EDITION  |  " : "") + "v" + GAME_VER, W - m, ty);
  static const char *items[5][2] = {{"mode:pro", "BE A PRO"}, {"mode:ut", "ULTIMATE FRANCHISE"}, {"mode:quick", "QUICK PLAY"}, {"mode:practice", "PRACTICE"}, {"nav:settings", "SETTINGS"}};
  // the big panel: the save you played last - tap it to jump straight back in
  LastI LI = lastInfo(); UTX *ud = LI.m == "ut" ? utSlots[LI.i].get() : nullptr; const char *const *uc = ud ? UT_COLS[ud->col % 12] : nullptr;
  double hx = land ? W * .36 : m, hw = land ? W - hx - m : W - 2 * m, hy = land ? ty + .07 * U : ty + .06 * U, hh = land ? (H - hy - .2 * U) : hw * .62;
  heroArt(hx, hy, hw, hh, hex(uc ? uc[0] : "#c8102e"), hex(uc ? uc[1] : "#ffffff"), false, 99);
  auto big = [&](const std::string &t, double yy, double sz) { ctx.textMid(AL_LEFT); ctx.font(sz); ctx.fill("#fff"); ctx.fillText(t, hx, yy); };
  double cy = hy + hh + .045 * U; TXR = hx + hw;
  if (ud) { big("CONTINUE ULTIMATE FRANCHISE", cy, std::min(.05 * U, hw * .06));
    tx(ud->nm + "  |  TEAM OVR " + istr(utTeamOv(*ud)) + "  |  RECORD " + istr(ud->w) + "-" + istr(ud->l) + "  |  " + fmtN(ud->coins) + " COINS  |  " + istr(ud->cards.size()) + " CARDS", hx, cy + .04 * U, .0216, "#cbd5e1", AL_LEFT, 700); }
  else { big("20 SEASONS. ONE LEGACY.", cy, std::min(.05 * U, hw * .06));
    tx("32 real teams. Draft night, contracts, trades and the salary cap - as a goalie or a forward.", hx, cy + .04 * U, .0216, "#cbd5e1", AL_LEFT, 700); }
  TXR = 1e4;
  if (LI.i >= 0) { pushBtn("cont", hx, hy, hw, hh, "CONTINUE");
    double pw = .26 * U, ph = .06 * U, px = hx + hw - pw - .025 * U, py = hy + hh - ph - .025 * U; ctx.fill(rgba(8, 12, 26, .82)); ctx.fillRect(px, py, pw, ph); ctx.fill(ACC); ctx.fillRect(px, py, .008 * U, ph);
    tx("TAP TO CONTINUE", px + pw / 2 + .004 * U, py + ph / 2, .022, "#fff", AL_CENTER, 800); }
  wordmark(hx + .03 * U, hy + hh * .22, std::min(.075 * U, hw * .085));
  double lx = m, lw = land ? W * .3 : W - 2 * m, ly = land ? hy + .01 * U : cy + .08 * U;
  ctx.font(.0204 * U); ctx.fill(ACC); ctx.textMid(AL_LEFT); ctx.fillText("PLAY", lx, ly + .01 * U); ly += .03 * U;
  double ih = land ? .07 * U : .075 * U;
  for (int k = 0; k < 5; k++) { menuItem(items[k][0], items[k][1], lx, ly, lw, k == 0 ? ih * 1.15 : ih, k == 0, false); ly += k == 0 ? ih * 1.25 : ih * 1.05; }
  footHints({{"D-PAD", "MOVE"}, {"X", "SELECT"}, {"TOUCH", "TAP ANYTHING"}});
}

// ---------------------------------------------------------------- the menu screens
static void drawMenuScreens() {
  if (mode == "ut" && !UT && screen != "modes" && screen != "utslots" && screen != "name" && screen != "settings") screen = "utslots";
  btns.clear();
  menuBG(); menuSnow();
  double w = std::min(W - 24.0, 1.7 * U), x = (W - w) / 2, y = safeTop + .02 * U, bh = .095 * U, bw = std::min(w, .9 * U), bx = (W - bw) / 2, g = bh + .012 * U;
  auto T = [&](const std::string &t, double s, const char *c, double yy) { tx(t, W / 2, yy, s, hex(c), AL_CENTER, s >= .05); };
  auto card = [&](double cx, double cyy, double cw, double ch, Col col) { ctx.fill(rgba(15, 23, 42, .85)); ctx.fillRect(cx, cyy, cw, ch); ctx.alpha(.3); ctx.fill(col); ctx.fillRect(cx, cyy, cw, ch); ctx.alpha(1); ctx.fill(col); ctx.fillRect(cx, cyy, std::max(5.0, ch * .05), ch); };
  auto L = [&](const std::string &t, double s, const char *c, double xx, double yy, Align al) { tx(t, xx, yy, s, hex(c), al); };
  auto row = [&](double cx, double cyy, double cw, double ch, bool hi) { ctx.fill(rgba(15, 23, 42, .62)); ctx.fillRect(cx, cyy, cw, ch); if (hi) { ctx.fill(rgba(255, 213, 74, .14)); ctx.fillRect(cx, cyy, cw, ch); ctx.fill(ACC); ctx.fillRect(cx, cyy, std::max(3.0, ch * .04), ch); } };
  auto B = [&](int i, const std::string &id, const std::string &lb, const char *col, bool on = true) { ui(id, bx, y + .275 * U + i * g, bw, bh, lb, col, on, .045); };
  auto back = [&](const std::string &id, double yy) { ui(id, (W - .5 * U) / 2, yy, .5 * U, .08 * U, "BACK", "#475569", true, .04); };
  (void)card;
  if (screen == "modes") drawMainMenu();
  else if (mode == "ut" && (screen == "main" || screen.rfind("ut", 0) == 0)) { drawUT(); if (UT && utExOn()) drawUTEx(); utLPCheck(); }
  else if (screen == "name") {
    T(nameFor == "ut" ? "NAME YOUR TEAM" : "NAME YOUR PLAYER", .06, "#fff", y + .05 * U);
    row(x, y + .1 * U, w, .1 * U, false);
    T(pname + ((int)std::floor(now() / 500) % 2 ? "_" : " "), .055, "#ffd54a", y + .15 * U);
    double kw = std::min(w / 10.4, .11 * U), kh = .115 * U, gp = kw * .1, y0 = y + .225 * U;
    static const char *rowsK[3] = {"QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM<"};
    for (int ri = 0; ri < 3; ri++) { std::string r = rowsK[ri]; double tot = r.size() * (kw + gp) - gp, sx = (W - tot) / 2;
      for (size_t ci = 0; ci < r.size(); ci++) { std::string ch(1, r[ci]); ui("key:" + ch, sx + ci * (kw + gp), y0 + ri * (kh + gp), kw, kh, ch, r[ci] == '<' ? "#b45309" : "#334155", true, .045); } }
    double by = y0 + 3 * (kh + gp), sw = std::min(w, 10.4 * kw);
    ui("key:_", (W - sw) / 2, by, sw * .62, kh, "SPACE", "#334155", true, .032);
    ui("rand", (W - sw) / 2 + sw * .64, by, sw * .36, kh, "RANDOM", "#7c3aed", true, .03);
    double b2 = std::min(.42 * U, (w - .02 * U) / 2), by2 = by + kh + .03 * U;
    std::string tr = pname; while (!tr.empty() && tr.back() == ' ') tr.pop_back(); while (!tr.empty() && tr[0] == ' ') tr.erase(0, 1);
    ui("namego", W / 2 - b2 - .01 * U, by2, b2, .09 * U, nameFor == "ut" ? "CREATE" : "START", "#16a34a", !tr.empty(), .04);
    ui("namecancel", W / 2 + .01 * U, by2, b2, .09 * U, "CANCEL", "#475569", true, .04);
  } else if (screen == "settings") {
    T("SETTINGS", .07, "#fff", y + .05 * U);
    double rh = .142 * U, ry = y + .11 * U;
    row(x, ry, w, rh, false);
    L("GOALIE ASSIST", .04, "#fff", x + .03 * U, ry + rh * .25, AL_LEFT);
    L("With the left stick centred, your goalie squares up", .024, "#94a3b8", x + .03 * U, ry + rh * .5, AL_LEFT);
    L("to the puck on his own (Casual and Standard only).", .024, "#94a3b8", x + .03 * U, ry + rh * .66, AL_LEFT);
    ui("set:gAssist", x + w - .27 * U, ry + rh * .12, .25 * U, rh * .3, settings.gAssist ? "ON" : "OFF", settings.gAssist ? "#16a34a" : "#475569", true, .04);
    double ry2 = ry + rh + .015 * U; bool aa = settings.autoAim;
    row(x, ry2, w, rh, false);
    L("AUTO AIM (SHOTS)", .04, "#fff", x + .03 * U, ry2 + rh * .25, AL_LEFT);
    TXR = x + w - .3 * U; L(aa ? "ON: in the attacking zone, your shots stay between the posts." : "OFF: shots go exactly where the left stick points,", .024, "#94a3b8", x + .03 * U, ry2 + rh * .5, AL_LEFT);
    L(aa ? "Outside the zone they go where the left stick points." : "so a wild one can miss the net.", .024, "#94a3b8", x + .03 * U, ry2 + rh * .66, AL_LEFT); TXR = 1e4;
    ui("set:autoAim", x + w - .27 * U, ry2 + rh * .12, .25 * U, rh * .3, aa ? "ON" : "OFF", aa ? "#16a34a" : "#475569", true, .04);
    double ry3 = ry2 + rh + .015 * U;
    row(x, ry3, w, rh, false);
    L("SHOT CONTROLS", .04, "#fff", x + .03 * U, ry3 + rh * .25, AL_LEFT);
    TXR = x + w - .04 * U; L("Right stick flick up = wrist, pull back + push up = slap; left stick aims. SQUARE dekes, TRIANGLE saucers.", .024, "#94a3b8", x + .03 * U, ry3 + rh * .5, AL_LEFT);
    L("Hold L: pass to the teammate under SQUARE / TRIANGLE / CIRCLE. Spin: a quick 360 on the left stick.", .024, "#94a3b8", x + .03 * U, ry3 + rh * .66, AL_LEFT); TXR = 1e4;
    double ry4 = ry3 + rh + .015 * U; bool sf = settings.sfx;
    row(x, ry4, w, rh, false);
    L("SOUND", .04, "#fff", x + .03 * U, ry4 + rh * .25, AL_LEFT);
    TXR = x + w - .3 * U; L("Shots, passes, skates, hits, posts and the crowd (cheers, boos and the", .024, "#94a3b8", x + .03 * U, ry4 + rh * .5, AL_LEFT);
    L("murmur in the stands).", .024, "#94a3b8", x + .03 * U, ry4 + rh * .66, AL_LEFT); TXR = 1e4;
    ui("set:sfx", x + w - .27 * U, ry4 + rh * .12, .25 * U, rh * .3, sf ? "ON" : "OFF", sf ? "#16a34a" : "#475569", true, .04);
    back("nav:modes", ry4 + rh + .025 * U);
  } else if (screen == "result") {
    bool wn = rs.hs > rs.as;
    tx(wn ? "YOU WIN!" : "YOU LOSE", W / 2, y + .05 * U, .075, hex(wn ? "#7CFC9A" : "#ff5252"), AL_CENTER, true);
    if (rs.so) T("decided in a shootout", .028, "#ffb300", y + .105 * U);
    double c1 = x + w * .22, c2 = x + w * .78;
    L(rs.hn, .03, "#60a5fa", c1, y + .15 * U, AL_CENTER); L(rs.an, .03, "#ff7a7a", c2, y + .15 * U, AL_CENTER);
    struct Rw { std::string a, b, c; } rows[3] = {{"GOALS", istr(rs.hs), istr(rs.as)}, {"SHOTS ON NET", istr(rs.hsh), istr(rs.ash)}, {"GOALIE SV%", svp3(rs.ash - rs.as, rs.ash), svp3(rs.hsh - rs.hs, rs.hsh)}};
    if (rs.hasF) rows[2] = {"YOU", istr(rs.f.g) + " G  " + istr(rs.f.a) + " A", istr(rs.f.sog) + " SOG  " + istr(rs.f.hits) + " HIT"};
    double rh = .085 * U;
    for (int i = 0; i < 3; i++) { double ry = y + .18 * U + i * (rh + .008 * U); row(x, ry, w, rh, false); bool you = rows[i].a == "YOU";
      L(rows[i].a, .024, "#94a3b8", W / 2, ry + rh / 2, AL_CENTER); L(rows[i].b, you ? .034 : .055, you ? "#ffd54a" : "#fff", c1, ry + rh / 2, AL_CENTER); L(rows[i].c, you ? .034 : .055, you ? "#ffd54a" : "#fff", c2, ry + rh / 2, AL_CENTER); }
    double ey = y + .18 * U + 3 * (rh + .008 * U) + .03 * U;
    if (mode == "ut") { T("+" + istr(rs.cash) + " COINS" + (UT ? "    |    " + fmtN(UT->coins) + " TOTAL" : ""), .034, "#ffd54a", ey); ui("nav:main", bx, ey + .04 * U, bw, bh, "CONTINUE", "#d97706", true, .045); }
    else { ui("play", bx, ey + .04 * U, bw, bh, "PLAY AGAIN", "#2563eb", true, .045); ui("nav:modes", bx, ey + .04 * U + g, bw, bh, "MODES", "#475569", true, .045); }
  } else if (screen == "main" && mode == "quick") {
    T("QUICK PLAY", .075, "#fff", y + .06 * U);
    T("One exhibition game. No progress saved.", .034, "#cbd5e1", y + .14 * U);
    T("Pick a position: same 3v3 game, same rinks, random teams.", .026, "#94a3b8", y + .2 * U);
    B(0, "qp:G", "PLAY AS GOALIE  -  COMING TO NATIVE", "#2563eb", false); B(1, "qp:F", "PLAY AS FORWARD", "#16a34a"); B(2, "nav:modes", "MODES", "#475569");
  } else if (screen == "soon") {
    // modes still being moved over from the legacy build
    T(mode == "pro" ? "BE A PRO" : "PRACTICE", .075, "#fff", y + .06 * U);
    T("Coming to the native build next.", .034, "#cbd5e1", y + .14 * U);
    T(mode == "pro" ? "Your legacy careers will carry over when it lands." : "The legacy drills move over with goalie mode.", .026, "#94a3b8", y + .2 * U);
    B(1, "nav:modes", "MODES", "#475569");
  } else { screen = "modes"; drawMainMenu(); }
}
// menu screens settle in: a quick fade up from dark with a small slide
static std::string MSk; static double MSt = 0;
void drawMenu() {
  TXL = 0; TXR = 1e4;
  std::string key = mode + "|" + screen + "|" + istr((int)state); double t = now(); if (key != MSk) { MSk = key; MSt = trActive() ? 0 : t; }
  double k = clamp((t - MSt) / 190, 0, 1);
  if (k >= 1) drawMenuScreens();
  else { double e = 1 - std::pow(1 - k, 3); ctx.fill("#0b1220"); ctx.fillRect(0, 0, W, H);
    ctx.save(); ctx.translate(0, std::round((1 - e) * .022 * U)); drawMenuScreens(); ctx.restore();
    ctx.fill(rgba(2, 6, 23, (float)((1 - e) * .6))); ctx.fillRect(0, 0, W, H); }
  drawModal(); drawFocus();
}

// ---------------------------------------------------------------- the router
static std::string trim(const std::string &s) { size_t a = s.find_first_not_of(' '), b = s.find_last_not_of(' '); return a == std::string::npos ? "" : s.substr(a, b - a + 1); }
static std::string utPrevName = "ROOKIE";
void startGame() {
  QO.diff = 1; QO.autoAim = settings.autoAim; QO.sfx = settings.sfx;
  skStart(); state = ST_PLAY; paused = false; screen = "main";
}
void uiTap(const std::string &id) {
  if (trActive()) return;
  if (modal.on) { if (id == "mdl:yes") { auto f = modal.yes; modal.on = false; if (f) f(); } else if (id == "mdl:no") modal.on = false; return; }
  if (state == ST_PLAY && paused) { if (id == "resume") paused = false; else if (id.rfind("ptab:", 0) == 0) pauseTab = atoi(id.c_str() + 5); else if (id == "quit") skQuit(); return; }
  if (screen == "result" && now() < lockUntil) return;
  if (id == "play") { if (now() >= lockUntil) startGame(); }
  else if (id == "mode:pro") goMode("BE A PRO", [] { mode = "pro"; screen = "soon"; }, hex("#c8102e"), false);
  else if (id == "mode:ut") goMode("ULTIMATE FRANCHISE", [] { UT = nullptr; utSlot = -1; mode = "ut"; screen = "utslots"; }, hex("#d97706"), false);
  else if (id == "cont") { LastI L = lastInfo(); if (L.m == "ut") { int i = L.i; goMode("ULTIMATE FRANCHISE", [i] { utLoad(i); }, hex("#d97706"), false); } }
  else if (utTap(id)) {}
  else if (id.rfind("key:", 0) == 0) { std::string c = id.substr(4); if (c == "<") { if (!pname.empty()) pname.pop_back(); }
    else if (pname.size() < 12) { if (c == "_") { if (!pname.empty() && pname.back() != ' ') pname += ' '; } else pname += c; } }
  else if (id == "rand") pname = upper(genName());
  else if (id == "namego" && nameFor == "ut") { std::string nm = trim(pname); if (!nm.empty()) { pname = utPrevName; nameFor = "pro"; utNew(nameTarget, nm); } }
  else if (id == "namecancel" && nameFor == "ut") { pname = utPrevName; nameFor = "pro"; screen = "utslots"; }
  else if (id == "namecancel") screen = "modes";
  else if (id == "mode:quick") goMode("QUICK PLAY", [] { mode = "quick"; screen = "main"; }, hex("#2563eb"), false);
  else if (id.rfind("qp:", 0) == 0) { if (id == "qp:F") startGame(); }
  else if (id == "mode:practice") goMode("PRACTICE", [] { mode = "practice"; screen = "soon"; }, hex("#ea580c"), false);
  else if (id == "set:autoPad") { settings.autoPad = !settings.autoPad; saveSettings(); }
  else if (id == "set:gAssist") { settings.gAssist = !settings.gAssist; saveSettings(); }
  else if (id == "set:sfx") { settings.sfx = !settings.sfx; QO.sfx = settings.sfx; if (!settings.sfx) snd_stop(-1); else sfx(S_PASS, .8); saveSettings(); }
  else if (id == "set:autoAim") { settings.autoAim = !settings.autoAim; QO.autoAim = settings.autoAim; saveSettings(); }
  else if (id == "nav:main" && screen == "result") { state = ST_MENU; screen = mode == "ut" && !utRet.empty() ? utRet : "main"; utRet.clear(); lockUntil = now() + 600; }
  else if (id == "nav:modes" && screen != "settings") goMode("MAIN MENU", [] { state = ST_MENU; screen = "modes"; }, hex("#475569"), false);
  else if (id.rfind("nav:", 0) == 0) screen = id.substr(4);
}
// the name screen remembers what you'd typed for your player while you name a team
void utNameStart(int i) { nameFor = "ut"; nameTarget = i; utPrevName = pname; pname = ""; screen = "name"; }

// ---------------------------------------------------------------- after a game
void afterGame(bool won, bool quit) {
  g_lastQuit = quit;
  if (quit) { if (mode == "ut") utAfter(false, true); state = ST_MENU; screen = "main"; return; }
  int cash = mode == "ut" ? utAfter(won, false) : 0;
  rs = RSum(); rs.hn = SK->T[0].name; rs.an = SK->T[1].name; rs.hs = SK->T[0].score; rs.as = SK->T[1].score; rs.hsh = SK->T[0].sog; rs.ash = SK->T[1].sog;
  rs.cash = cash; rs.hasF = true; rs.f = SK->me;
  state = ST_RESULT; screen = "result"; lockUntil = now() + 700;
}

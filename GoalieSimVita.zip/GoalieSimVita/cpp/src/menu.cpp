// CHL 2026 native - menus, ported from the legacy build: the main menu with its key art, settings, the name
// keyboard, the result screen, Quick Play, the YES / NO modal, D-pad / stick navigation and the router that
// every button goes through. Same layout, sizes, colours and wording as the legacy build.
#include "menu.h"
#include <map>
#include "music.h"
#include "pro.h"
#include "apt.h"
#include "ut.h"
#include "sk_int.h"

const Col ACC = hex("#f26b5b");
std::vector<Btn> btns;
std::string mFocus; bool mPadUsed = false;
std::string mode = "quick", screen = "modes", pname = "ROOKIE", nameFor = "pro";
static std::string trim(const std::string &s) { size_t a = s.find_first_not_of(' '), b = s.find_last_not_of(' '); return a == std::string::npos ? "" : s.substr(a, b - a + 1); }
std::string pFirst, pLast; int pField = 0; bool kShift = true, kCaps = false; double kShiftT = 0;   // the name keyboard: first / last name boxes, SHIFT (one capital) and CAPS
int nameTarget = 0;
Settings settings;
Modal modal;
RSum rs; double lockUntil = 0; bool g_lastQuit = false;
static const char *GAME_VER = "0.6";

void pushBtn(const std::string &id, double x, double y, double w, double h, const std::string &lb, bool np) { Btn b; b.id = id; b.x = x; b.y = y; b.w = w; b.h = h; b.lb = lb; b.np = np; btns.push_back(b); }
void askModal(const std::string &t, const std::string &s, std::function<void()> yes) { modal.on = true; modal.t = t; modal.s = s; modal.yes = yes; }

// ---------------------------------------------------------------- text and numbers
std::string fmtN(double n) {
  std::string s = istr((long long)std::floor(n)), o; int neg = s[0] == '-' ? 1 : 0;
  for (size_t i = 0; i < s.size(); i++) { o += s[i]; size_t left = s.size() - 1 - i; if ((int)i >= neg && left > 0 && left % 3 == 0) o += ','; }
  return o;
}
std::string fixed(double v, int d) { char b[48]; double p = std::pow(10.0, d); v = std::floor(v * p + .5) / p; snprintf(b, sizeof b, "%.*f", d, v); return b; }
std::string fmtM(double v) { return "$" + fixed(std::floor(v * 10 + .5) / 10, 1) + "M"; }
std::string svp3(double a, double b) { if (b <= 0) return ".000"; std::string s = fixed(a / b, 3); if (s[0] == '0') s = s.substr(1); return s; }
void tx(const std::string &t, double x, double y, double sz, const char *c, Align al, int, bool it) { tx(t, x, y, sz, hex(c), al, it); }
std::vector<std::string> wrapText(const std::string &t, double maxW) {
  std::vector<std::string> out; std::string cur, w; size_t i = 0;
  while (i <= t.size()) { if (i == t.size() || t[i] == ' ') { std::string n = cur.empty() ? w : cur + " " + w;
      if (ctx.measure(n) > maxW && !cur.empty()) { out.push_back(cur); cur = w; } else cur = n; w.clear(); } else w += t[i]; i++; }
  if (!cur.empty()) out.push_back(cur); return out;
}
void txWrap(const std::string &t, double x, double y, double sz, double maxW, Col c, Align al, int, int maxL) {
  double px = fsz(sz) * U; ctx.font(px); auto ls = wrapText(t, maxW); int k = 0;
  while ((int)ls.size() > maxL && k++ < 5) { px *= .9; ctx.font(px); ls = wrapText(t, maxW); }
  double lh = px * 1.2; int n = std::min((int)ls.size(), maxL); ctx.align(al); ctx.baseline(BL_MIDDLE); ctx.fill(c);
  for (int i = 0; i < n; i++) ctx.fillText(ls[i], x, y + (i - (n - 1) / 2.0) * lh);
}
static double fszInv(double v) { return v < .024 ? (v - .0096) / .6 : v; }
void txFit(const std::string &t, double x, double y, double sz, double maxW, Col c, Align al) {
  ctx.font(fsz(sz) * U); double w = ctx.measure(t); tx(t, x, y, w > maxW ? fszInv(fsz(sz) * maxW / w) : sz, c, al);
}
// the current fill colour, shrunk to fit maxW
double utFitTx(const std::string &t, double x, double y, double px, double maxW, Align al) {
  ctx.font(px); double w = ctx.measure(t); if (w > maxW && w > 0) { px *= maxW / w; ctx.font(px); }
  ctx.align(al); ctx.fillText(t, x, y); return px;
}
void rrPath(double x, double y, double w, double h, double r) { ctx.rr(x, y, w, h, r); }

// ---------------------------------------------------------------- the look: a deep gradient, drifting light, rising particles
Col lerpC(Col a, Col b, double k) { return Col((float)(a.r + (b.r - a.r) * k), (float)(a.g + (b.g - a.g) * k), (float)(a.b + (b.b - a.b) * k), (float)(a.a + (b.a - a.a) * k)); }
// a soft round glow: bright in the middle, fading to nothing at the edge (per-vertex colours, so it costs a few dozen tris)
void softGlow(double cx, double cy, double rx, double ry, Col c, double a) {
  if (a <= .002 || rx < 1 || ry < 1) return;
  const int N = 28; uint32_t c0 = c.pack((float)a), c1 = c.pack((float)(a * .42)), c2 = c.pack(0);
  for (int i = 0; i < N; i++) { double a0 = i * 2 * PI / N, a1 = (i + 1) * 2 * PI / N; float x0 = (float)std::cos(a0), y0 = (float)std::sin(a0), x1 = (float)std::cos(a1), y1 = (float)std::sin(a1);
    float ix0 = (float)(cx + x0 * rx * .42), iy0 = (float)(cy + y0 * ry * .42), ix1 = (float)(cx + x1 * rx * .42), iy1 = (float)(cy + y1 * ry * .42), ox0 = (float)(cx + x0 * rx), oy0 = (float)(cy + y0 * ry), ox1 = (float)(cx + x1 * rx), oy1 = (float)(cy + y1 * ry);
    ctx.rawTri3((float)cx, (float)cy, c0, ix0, iy0, c1, ix1, iy1, c1);
    ctx.rawTri3(ix0, iy0, c1, ox0, oy0, c2, ox1, oy1, c2); ctx.rawTri3(ix0, iy0, c1, ox1, oy1, c2, ix1, iy1, c1); }
}
// a rectangle shaded left to right (or top to bottom)
void gradRect(double x, double y, double w, double h, Col a, double aa, Col b, double ba, bool vert) {
  uint32_t c0 = a.pack((float)aa), c1 = b.pack((float)ba); float x0 = (float)x, y0 = (float)y, x1 = (float)(x + w), y1 = (float)(y + h);
  if (vert) { ctx.rawTri3(x0, y0, c0, x1, y0, c0, x1, y1, c1); ctx.rawTri3(x0, y0, c0, x1, y1, c1, x0, y1, c1); }
  else { ctx.rawTri3(x0, y0, c0, x1, y0, c1, x1, y1, c1); ctx.rawTri3(x0, y0, c0, x1, y1, c1, x0, y1, c0); }
}
double pulseK() { return .5 + .5 * std::sin(now() / 1000 * 2.6); }
static double gR(double w, double h) { return std::min(.02 * U, std::min(w, h) * .3); }
void glass(double x, double y, double w, double h, double dark) {
  if (w <= 1 || h <= 1) return; double r = gR(w, h);
  ctx.fill(rgba(9, 13, 30, (float)std::min(.97, dark))); ctx.rr(x, y, w, h, r); ctx.fillPath();
  ctx.fill(rgba(255, 255, 255, .035)); ctx.rr(x, y, w, h, r); ctx.fillPath();
  ctx.stroke(rgba(255, 255, 255, h < .06 * U ? .05f : .1f)); ctx.lineWidth(1); ctx.rr(x + .5, y + .5, w - 1, h - 1, r); ctx.strokePath();
}
void glassTop(double x, double y, double w, double h, Col c, double dark) {
  glass(x, y, w, h, dark);
  gradRect(x + 2, y + 2, w - 4, std::min(h * .4, .16 * U), c, .22, c, 0, true); topLine(x, y, w, c);
}
void glassHi(double x, double y, double w, double h, double a) {
  if (a <= .01) return; double r = gR(w, h), pl = pulseK();
  ctx.fill(rgba(255, 255, 255, (float)(.07 * a))); ctx.rr(x, y, w, h, r); ctx.fillPath();
  ctx.stroke(rgba(255, 255, 255, (float)((.45 + .3 * pl) * a))); ctx.lineWidth(2); ctx.rr(x + 1, y + 1, w - 2, h - 2, r); ctx.strokePath();
}
void accentBar(double x, double y, double h, Col c) { ctx.fill(c); if (h > .12 * U) ctx.rr(x + 5, y + .02 * U, 3, h - .04 * U, 1.5); else ctx.rr(x + 5, y + h * .2, 3, h * .6, 1.5); ctx.fillPath(); }
void topLine(double x, double y, double w, Col c) { double r = std::min(.02 * U, w * .3); ctx.fill(c); ctx.rr(x + r, y + 1, w - 2 * r, 3, 1.5); ctx.fillPath(); }
void menuBG() {
  cached(Key("mbg2") << W << H, [] {
    Grad g = gLin(0, 0, 0, H); g.add(0, hex("#050816")); g.add(.55f, hex("#0a1230")); g.add(1, hex("#03050d"));
    ctx.fill(g); ctx.fillRect(0, 0, W, H); });
  double t = now() / 1000;
  // big soft lights drifting about, like stadium haze lit from above
  struct Bl { const char *c; double x, y, rx, ry, a, sp, ph; };
  static const Bl bl[6] = {{"#1d4ed8", .80, .28, .70, .62, .42, .21, 0}, {"#0ea5a4", .95, .58, .52, .46, .36, .27, 1.7}, {"#a3e635", .72, .62, .42, .34, .24, .33, 3.1},
    {"#4f46e5", .12, .10, .55, .45, .22, .18, 4.4}, {"#f26b5b", .28, 1.02, .55, .26, .10, .24, 2.2}, {"#38bdf8", .45, .40, .30, .26, .10, .30, 5.3}};
  for (auto &b : bl) { double bx = W * (b.x + .07 * std::sin(t * b.sp * .35 + b.ph)), by = H * (b.y + .06 * std::cos(t * b.sp * .45 + b.ph * 1.3));
    double pulse = .82 + .18 * std::sin(t * .4 + b.ph); softGlow(bx, by, W * b.rx, H * b.ry * 1.4, hex(b.c), b.a * pulse); }
  // a few beams of light leaning in from the top right, slowly swaying
  for (int k = 0; k < 3; k++) { double sw = std::sin(t * (.11 + k * .04) + k * 2.3), ox = W * (.58 + .14 * k) + sw * W * .03, tw = W * (.03 + .015 * k), lean = W * (.3 + .05 * k), bw = W * (.16 + .05 * k);
    uint32_t c0 = Col(210, 235, 255).pack((float)(.055 + .02 * std::sin(t * .7 + k))), c1 = Col(210, 235, 255).pack(0);
    ctx.rawTri3((float)ox, 0, c0, (float)(ox + tw), 0, c0, (float)(ox - lean + bw), (float)H, c1); ctx.rawTri3((float)ox, 0, c0, (float)(ox - lean + bw), (float)H, c1, (float)(ox - lean), (float)H, c1); }
  // keep the bottom (the button hints) and the left (the menu) calm
  gradRect(0, H * .72, W, H * .28, Col(3, 5, 13), 0, Col(3, 5, 13), .7, true);
  gradRect(0, 0, W * .5, H, Col(4, 7, 20), .5, Col(4, 7, 20), 0, false);
}
void menuSnow() {   // particles: specks rising and twinkling, now and then a big out-of-focus one
  double t = now() / 1000, k = U / 544.0;
  for (int i = 0; i < 72; i++) {
    double sp = (7 + (i * 37 % 23)) * k, span = H + .1 * H, y = H + .05 * H - std::fmod(t * sp + i * 97.31, span), x0 = std::fmod(i * .6180339 * 1.7, 1.0) * W, x = x0 + std::sin(t * .35 + i * 1.3) * W * .018;
    double tw = .5 + .5 * std::sin(t * (1.4 + (i % 7) * .3) + i * 1.7), fade = clamp(y / (H * .35), 0, 1) * clamp((H - y) / (H * .1), 0, 1), r = (.7 + (i % 5) * .45) * k;
    const char *c = i % 4 == 0 ? "#d9f99d" : i % 3 == 0 ? "#99f6e4" : "#e0f2fe";
    if (i % 9 == 0) { softGlow(x, y, r * 9, r * 9, hex(c), .1 * tw * fade); continue; }
    ctx.alpha((float)((.12 + .45 * tw) * fade)); ctx.fill(c); ctx.disc(x, y, r);
  }
  ctx.alpha(1);
}
double wordmarkW(double s) { ctx.font(s); return ctx.measure("CHL ") + s * .3 + ctx.measure("2026"); }
void wordmarkC(double cx, double y, double s) { wordmark(cx - wordmarkW(s) / 2, y, s); }
// key art: one of our own skaters (or goalies) under arena lights
void heroArt(double x, double y, double w, double h, const HeroSpec &s, int seed) {
  ctx.save(); ctx.translate(x, y);
  cached(Key("hero") << (int)std::round(w) << (int)std::round(h) << s.j << s.s << s.goalie << seed, [&] {
    Grad g0 = gLin(0, 0, 0, h * .62); g0.add(0, hex("#10162a")); g0.add(1, hex("#1f2946")); ctx.fill(g0); ctx.fillRect(0, 0, w, h * .62);
    Grad g = gLin(0, h * .62, 0, h); g.add(0, hex("#1f2946")); g.add(1, hex("#d9e6f2")); ctx.fill(g); ctx.fillRect(0, h * .62, w, h * .38);
    SkRng R(seed ? seed : 7);
    for (int i = 0; i < 26; i++) { double bx = R() * w, by = R() * h * .55, br = (2 + R() * 7) * U / 400; ctx.fill(rgba(255, 236, 200, (float)(.08 + R() * .35))); ctx.disc(bx, by, br); }
    ctx.fill(rgba(255, 255, 255, .18)); ctx.oval(w * .62, h * .93, w * .36, h * .06);
    ctx.fill(rgba(220, 38, 38, .22)); ctx.fillRect(0, h * .86, w, h * .012);
    Grad v = gLin(0, 0, w * .55, 0); v.add(0, rgba(8, 12, 26, .85)); v.add(1, rgba(8, 12, 26, 0)); ctx.fill(v); ctx.fillRect(0, 0, w * .55, h);
  });
  ctx.restore();
  model3D(x + w * .7, y + h * .95, h * .78, s, s.goalie ? 0 : 1, .35f, true, x, y, x + w, y + h);   // him, in 3D
}
// ---------------------------------------------------------------- the 3D hero (main menu, Ultimate Franchise)
// The model is rebuilt every other frame as he turns (one player costs less than a frame of a game), drawn over a stage:
// sweeping spotlights, dust in the beams, a glossy floor with his reflection, a giant faint number behind him.
static std::string hexOf(Col c) { char b[8]; snprintf(b, sizeof b, "#%02x%02x%02x", (int)c.r & 255, (int)c.g & 255, (int)c.b & 255); return b; }
static HeroSpec g_qh; static int g_qhOk = -1;
bool quickHero(HeroSpec &h) {
  if (g_qhOk < 0) { g_qhOk = 0; std::string s; if (plat_read_file(plat_data_dir() + "chl_qhero.json", s)) { J o = J::parse(s); if (o.isObj() && !o("nm").str().empty()) {
    g_qh.nm = o("nm").str(); g_qh.j = hex(o("j").str()); g_qh.s = hex(o("s").str()); g_qh.skin = hex(o("k").str()); g_qh.num = o("num").i(-1); g_qh.right = o("r").truthy(); g_qh.tag = o("tag").str(); g_qhOk = 1; } } }
  if (g_qhOk == 1) h = g_qh; return g_qhOk == 1;
}
void setQuickHero(const HeroSpec &h) { g_qh = h; g_qhOk = 1; J o = J::obj(); o["nm"] = h.nm; o["j"] = hexOf(h.j); o["s"] = hexOf(h.s); o["k"] = hexOf(h.skin); o["num"] = h.num; o["r"] = h.right; o["tag"] = h.tag; plat_write_file(plat_data_dir() + "chl_qhero.json", o.dump()); }
// ---------------------------------------------------------------- a still 3D player, for panels and avatars
static void triClip(const float *X, const float *Y, const uint32_t *Cc, double x0, double y0, double x1, double y1) {
  struct V { double x, y, a, b; }; std::vector<V> P = {{X[0], Y[0], 1, 0}, {X[1], Y[1], 0, 1}, {X[2], Y[2], 0, 0}};   // a, b: weights of corners 0 and 1
  auto clipE = [&](int e, double v) { std::vector<V> O; for (size_t i = 0; i < P.size(); i++) { V A = P[i], B = P[(i + 1) % P.size()];
      double da = e == 0 ? A.x - v : e == 1 ? v - A.x : e == 2 ? A.y - v : v - A.y, db = e == 0 ? B.x - v : e == 1 ? v - B.x : e == 2 ? B.y - v : v - B.y;
      if (da >= 0) O.push_back(A); if ((da >= 0) != (db >= 0)) { double k = da / (da - db); O.push_back({A.x + (B.x - A.x) * k, A.y + (B.y - A.y) * k, A.a + (B.a - A.a) * k, A.b + (B.b - A.b) * k}); } }
    P.swap(O); };
  clipE(0, x0); if (P.size() > 2) clipE(1, x1); if (P.size() > 2) clipE(2, y0); if (P.size() > 2) clipE(3, y1); if (P.size() < 3) return;
  auto mix = [&](const V &v) { double c = 1 - v.a - v.b; uint32_t o = 0; for (int sh = 0; sh < 32; sh += 8) { double ch = ((Cc[0] >> sh) & 255) * v.a + ((Cc[1] >> sh) & 255) * v.b + ((Cc[2] >> sh) & 255) * c; o |= (uint32_t)std::max(0.0, std::min(255.0, ch + .5)) << sh; } return o; };
  uint32_t c0 = mix(P[0]); for (size_t i = 1; i + 1 < P.size(); i++) ctx.rawTri3((float)P[0].x, (float)P[0].y, c0, (float)P[i].x, (float)P[i].y, mix(P[i]), (float)P[i + 1].x, (float)P[i + 1].y, mix(P[i + 1]));
}
void model3D(double cx, double feetY, double hgt, const HeroSpec &s, int pose, float turn, bool refl, double kx0, double ky0, double kx1, double ky1) {
  struct E { std::vector<PortTri> M; float mx0 = 0, mx1 = 0, my0 = 0, gy = 0; };
  static std::map<std::string, E> cache;
  std::string k = s.nm + hexOf(s.j) + hexOf(s.s) + hexOf(s.skin) + (s.goalie ? "g" : "s") + (s.right ? "r" : "l") + istr(pose) + istr((int)std::lround(turn * 100));
  auto it = cache.find(k);
  if (it == cache.end()) { if (cache.size() > 24) cache.clear(); E e; sk3Portrait(e.M, s.j, s.s, s.skin, s.goalie, pose, s.right, s.nm, turn);
    float my1 = -1e9f; e.mx0 = e.my0 = 1e9f; e.mx1 = -1e9f; for (auto &q : e.M) for (int i = 0; i < 3; i++) { e.mx0 = std::min(e.mx0, q.x[i]); e.mx1 = std::max(e.mx1, q.x[i]); e.my0 = std::min(e.my0, q.y[i]); my1 = std::max(my1, q.y[i]); }
    e.gy = g_portGround; if (!(e.gy > e.my0 && e.gy < my1 + (my1 - e.my0))) e.gy = my1;
    it = cache.emplace(k, std::move(e)).first; }
  E &e = it->second; if (e.M.empty()) return;
  double kk = hgt / std::max(1e-3, (double)(e.gy - e.my0)), mcx = (e.mx0 + e.mx1) / 2; bool clip = kx0 > -1e8;
  auto put = [&](const PortTri &q, bool rf) { float X[3], Y[3]; uint32_t Cc[3];
    for (int i = 0; i < 3; i++) { X[i] = (float)(cx + (q.x[i] - mcx) * kk); Y[i] = (float)(rf ? feetY + (e.gy - q.y[i]) * kk * .35 : feetY + (q.y[i] - e.gy) * kk); Cc[i] = rf ? (q.c[i] & 0x00ffffffu) | (40u << 24) : q.c[i]; }
    if (!clip) { ctx.rawTri3(X[0], Y[0], Cc[0], X[1], Y[1], Cc[1], X[2], Y[2], Cc[2]); return; }
    float a0 = std::min(X[0], std::min(X[1], X[2])), a1 = std::max(X[0], std::max(X[1], X[2])), b0 = std::min(Y[0], std::min(Y[1], Y[2])), b1 = std::max(Y[0], std::max(Y[1], Y[2]));
    if (a1 < kx0 || a0 > kx1 || b1 < ky0 || b0 > ky1) return;
    if (a0 >= kx0 && a1 <= kx1 && b0 >= ky0 && b1 <= ky1) { ctx.rawTri3(X[0], Y[0], Cc[0], X[1], Y[1], Cc[1], X[2], Y[2], Cc[2]); return; }
    triClip(X, Y, Cc, kx0, ky0, kx1, ky1); };
  if (refl) for (auto &q : e.M) put(q, true);
  for (auto &q : e.M) put(q, false);
}
int g_heroPose = -1;   // tests: hold the menu hero in one pose
void hero3D(double x, double y, double w, double h, const HeroSpec &s, bool stage, bool model) {
  double t = now() / 1000;
  if (stage) {
    ctx.save(); ctx.translate(x, y);
    cached(Key("hero3") << (int)std::round(w) << (int)std::round(h) << s.j << s.s, [&] {
      Grad g0 = gLin(0, 0, 0, h * .66); g0.add(0, hex("#070b18")); g0.add(1, shade(s.j, -.62)); ctx.fill(g0); ctx.fillRect(0, 0, w, h * .66);
      Grad g = gLin(0, h * .66, 0, h); g.add(0, hex("#1b2440")); g.add(.35f, hex("#8ea4bf")); g.add(1, hex("#e8f0f8")); ctx.fill(g); ctx.fillRect(0, h * .66, w, h * .34);
      SkRng R(11); for (int i = 0; i < 34; i++) { double bx = R() * w, by = R() * h * .5, br = (2 + R() * 9) * U / 400; ctx.fill(rgba(255, 236, 200, (float)(.05 + R() * .25))); ctx.disc(bx, by, br); }   // arena lights, out of focus
      for (int r = 0; r < 4; r++) { ctx.fill(rgba(255, 255, 255, .03f + r * .01f)); ctx.fillRect(0, h * (.5 + r * .035), w, h * .012); }   // the seats' rows
      ctx.fill(rgba((int)s.j.r, (int)s.j.g, (int)s.j.b, .55f)); ctx.fillRect(0, h * .64, w, h * .025); ctx.fill(rgba(255, 255, 255, .5)); ctx.fillRect(0, h * .665, w, h * .006);   // the boards
      ctx.fill(rgba(220, 38, 38, .25)); ctx.fillRect(0, h * .9, w, h * .01); ctx.fill(rgba(37, 99, 235, .18)); ctx.fillRect(w * .1, h * .78, w * .012, h * .22);
    });
    ctx.restore();
    // the giant number behind him
    if (s.num >= 0) { ctx.alpha(.09); ctx.fill(s.s); ctx.font(h * .62); ctx.textMid(); ctx.fillText(istr(s.num), x + w * .66, y + h * .42); ctx.alpha(1); }
    // sweeping spotlights
    for (int k = 0; k < 2; k++) { double sw = std::sin(t * (.35 + k * .17) + k * 2.1), cx0 = x + w * (.45 + .25 * k), cx1 = x + w * (.66 + sw * .22);
      ctx.fill(rgba(255, 248, 225, .07f)); ctx.quad(cx0 - w * .02, y, cx0 + w * .02, y, cx1 + w * .16, y + h * .97, cx1 - w * .16, y + h * .97); }
    ctx.fill(rgba(255, 250, 235, .16)); ctx.oval(x + w * .66, y + h * .93, w * .2, h * .045);
  }
  if (!model) return;
  // the model
  static std::vector<PortTri> M; static float mx0, my0, mx1, my1, gy, myR; static int frame = 0; static std::string lastK; static int lastPose = -1;
  int pose = s.goalie ? ((int)(t / 7) % 4) : (int)(t / 6) % 5; float turn = (float)(std::sin(t * .45) * .55); if (g_heroPose >= 0) { pose = g_heroPose; turn = .55f; }
  std::string k = s.nm + hexOf(s.j) + hexOf(s.s);
  if (k != lastK || pose != lastPose || (++frame % 2) == 0 || M.empty()) { lastK = k; lastPose = pose;
    sk3Portrait(M, s.j, s.s, s.skin, s.goalie, pose, s.right, s.nm, turn);
    mx0 = my0 = 1e9f; mx1 = my1 = -1e9f; for (auto &q : M) for (int i = 0; i < 3; i++) { mx0 = std::min(mx0, q.x[i]); mx1 = std::max(mx1, q.x[i]); my0 = std::min(my0, q.y[i]); my1 = std::max(my1, q.y[i]); }
    myR = my1; gy = g_portGround; if (!(gy > my0 && gy < my1 + (my1 - my0))) gy = my1; my1 = gy; }   // stand him on the ice, not on the tip of his stick
  if (M.empty()) return;
  double sw = mx1 - mx0, sh = my1 - my0, kk = std::min(w * (s.goalie ? .5 : .55) / std::max(1e-3, (double)sw), h * (s.goalie ? .74 : .84) / std::max(1e-3, (double)sh)), cx = x + w * .66, by = y + h * .93, mcx = (mx0 + mx1) / 2;
  kk = std::min(kk, h * .94 / std::max(1e-3, (double)(std::max(myR, my1) - my0)));   // the stick blade stays inside his box too
  { double low = by + (std::max(myR, my1) - my1) * kk, lim = y + h * .985; if (low > lim) by -= low - lim; }
  double bob = std::sin(t * 1.3) * h * .004;
  // the reflection on the ice (squashed, faint), then him
  if (stage) for (auto &q : M) { uint32_t c[3]; for (int i = 0; i < 3; i++) c[i] = (q.c[i] & 0x00ffffffu) | (40u << 24);
    ctx.rawTri3((float)(cx + (q.x[0] - mcx) * kk), (float)(by + (my1 - q.y[0]) * kk * .35), c[0], (float)(cx + (q.x[1] - mcx) * kk), (float)(by + (my1 - q.y[1]) * kk * .35), c[1], (float)(cx + (q.x[2] - mcx) * kk), (float)(by + (my1 - q.y[2]) * kk * .35), c[2]); }
  for (auto &q : M) ctx.rawTri3((float)(cx + (q.x[0] - mcx) * kk), (float)(by + bob + (q.y[0] - my1) * kk), q.c[0], (float)(cx + (q.x[1] - mcx) * kk), (float)(by + bob + (q.y[1] - my1) * kk), q.c[1], (float)(cx + (q.x[2] - mcx) * kk), (float)(by + bob + (q.y[2] - my1) * kk), q.c[2]);
  if (stage) { // the vignette on the left, for the text
    Grad v = gLin((float)x, 0, (float)(x + w * .5), 0); v.add(0, rgba(6, 10, 22, .9)); v.add(1, rgba(6, 10, 22, 0)); ctx.fill(v); ctx.fillRect(x, y, w * .5, h);
    if (!s.tag.empty()) { double px = .019 * U; ctx.font(px); double tw = ctx.measure(s.tag) + .03 * U; ctx.fill(rgba(8, 12, 26, .78)); ctx.fillRect(x + w - tw - .02 * U, y + .02 * U, tw, .042 * U); ctx.fill(s.j); ctx.fillRect(x + w - tw - .02 * U, y + .02 * U, .006 * U, .042 * U);
      ctx.fill("#fff"); ctx.textMid(); ctx.fillText(s.tag, x + w - tw / 2 - .02 * U + .003 * U, y + .041 * U); }
  }
}
void footHints(const std::vector<std::pair<std::string, std::string>> &h) {
  double fh = .055 * U, fy = H - fh / 2 - 4, hx = .05 * U;
  for (auto &x : h) { double bh = .034 * U, bw; bool circ = x.first.size() == 1;
    ctx.stroke(rgba(226, 232, 240, .85)); ctx.lineWidth(1.5);
    if (circ) { bw = bh; ctx.rr(hx, fy - bh / 2, bw, bh, bh / 2); ctx.strokePath(); }
    else { ctx.font(.019 * U); bw = ctx.measure(x.first) + .022 * U; ctx.rr(hx, fy - bh / 2, bw, bh, bh * .3); ctx.strokePath(); }
    ctx.fill("#e2e8f0"); ctx.font(circ ? .021 * U : .019 * U); ctx.textMid(); ctx.fillText(x.first, hx + bw / 2, fy + 1);
    ctx.textMid(AL_LEFT); ctx.font(.0222 * U); ctx.fill("#cbd5e1"); ctx.fillText(x.second, hx + bw + .012 * U, fy + 1); hx += bw + .024 * U + ctx.measure(x.second) + .035 * U; }
}
void menuItem(const std::string &id, const std::string &label, double x, double y, double w, double h, bool big, bool on) {
  ctx.textMid(AL_LEFT);
  if (on) { glass(x, y + 1, w, h - 2, .45); accentBar(x, y, h, ACC); ctx.fill("#fff"); }
  else ctx.fill(big ? "#fff" : "#cbd5e1");
  { double fs = big ? h * .62 : h * .5; ctx.font(fs); double mw = w - (on ? h * .55 : h * .1), tw = ctx.measure(label); if (tw > mw) ctx.font(fs * mw / tw); }
  ctx.fillText(label, x + (on ? h * .3 : h * .1), y + h / 2 + 1);
  pushBtn(id, x, y, w, h, label);
}
void ui(const std::string &id, double x, double y, double w, double h, const std::string &label, Col col, bool on, double fs) {
  double r = std::min(h * .22, 8.0); bool neutral = col == hex("#334155") || col == hex("#475569");
  ctx.fill(on ? rgba(255, 255, 255, .07) : rgba(255, 255, 255, .025)); ctx.rr(x, y, w, h, r); ctx.fillPath();
  if (on && !neutral) { ctx.alpha(.3); ctx.fill(col); ctx.rr(x, y, w, h, r); ctx.fillPath(); ctx.alpha(1); ctx.fill(col); ctx.fillRect(x + 2, y + h * .22, 3, h * .56); }
  ctx.stroke(rgba(255, 255, 255, on ? .16 : .06)); ctx.lineWidth(1); ctx.rr(x + .5, y + .5, w - 1, h - 1, r); ctx.strokePath();
  ctx.fill(on ? "#fff" : "#64748b"); ctx.textMid();
  double px = std::min((fs ? fs : .04) * U, h * .62), mw = w - std::max(12.0, h * .4); ctx.font(px); double tw = ctx.measure(label); if (tw > mw) ctx.font(px * mw / tw);
  ctx.fillText(label, x + w / 2, y + h / 2 + 1);
  Btn b; b.id = id; b.x = x; b.y = y; b.w = w; b.h = h; b.lb = label; b.dis = !on; btns.push_back(b);
}
void drawModal() {
  if (!modal.on) return;
  btns.clear();
  ctx.fill(rgba(2, 6, 23, .72)); ctx.fillRect(0, 0, W, H);
  double pw = std::min(W - 40.0, 1.05 * U), ph = .42 * U, px = (W - pw) / 2, py = (H - ph) / 2;
  glassTop(px, py, pw, ph, hex("#dc2626"), .95);
  ctx.textMid(); ctx.fill("#fff"); ctx.fitPx(modal.t, .055 * U, pw * .94); ctx.fillText(modal.t, W / 2, py + .09 * U);
  ctx.fill("#cbd5e1"); ctx.fitPx(modal.s, .03 * U, pw * .94); ctx.fillText(modal.s, W / 2, py + .17 * U);
  double bw = pw * .36, bh = .095 * U, by = py + ph - bh - .06 * U;
  ui("mdl:yes", W / 2 - bw - .02 * U, by, bw, bh, "YES", "#dc2626", true, .042);
  ui("mdl:no", W / 2 + .02 * U, by, bw, bh, "NO", "#475569", true, .042);
  if (mFocus != "mdl:yes" && mFocus != "mdl:no") mFocus = "mdl:no";
}

// ---------------------------------------------------------------- pad navigation
static bool noPad(const Btn &b) { return b.np || b.id.rfind("gcat:", 0) == 0 || b.id.rfind("utab:", 0) == 0 || b.id.rfind("ucat:", 0) == 0 || b.id.rfind("ptab:", 0) == 0; }
static bool isBackLb(const std::string &l) { return l == "BACK" || l == "CANCEL" || l == "MAIN MENU" || l == "DONE"; }
static const Btn *padFirst() {
  static const char *pref[] = {"mdl:no", "num:ok", "play", "next", "skipday", "off:neg", "simheal", "sim1", "resume", "namego", "draftdone", "neg:ok", "train:0", "ntc:0", "tq:go", "mode:pro"};
  std::vector<const Btn *> nav; for (auto &b : btns) if (!noPad(b)) nav.push_back(&b);
  for (auto *b : nav) if (!b->dis) for (auto p : pref) if (b->id == p) return b;
  for (auto *b : nav) if (!b->dis && !isBackLb(b->lb)) return b;
  if (!nav.empty()) return nav[0]; return btns.empty() ? nullptr : &btns[0];
}
// 1) buttons that overlap the current one across the direction of travel (same row / same column): the closest
// edge. 2) horizontal with nothing in the row: wrap to the other end of the row. 3) otherwise the nearest one
// in that direction, weighting sideways distance heavily.
static const Btn *padMove(const Btn &cur, int dir) {
  bool H_ = dir >= 3; double c0 = H_ ? cur.y : cur.x, c1 = H_ ? cur.y + cur.h : cur.x + cur.w, cc = (c0 + c1) / 2;
  std::vector<const Btn *> nav; for (auto &b : btns) if (&b != &cur && !noPad(b)) nav.push_back(&b);
  auto gap = [&](const Btn *b) { return dir == 1 ? cur.y - (b->y + b->h) : dir == 2 ? b->y - (cur.y + cur.h) : dir == 3 ? cur.x - (b->x + b->w) : b->x - (cur.x + cur.w); };
  auto ctr = [&](const Btn *b) { return dir == 1 ? cur.y + cur.h / 2 - (b->y + b->h / 2) : dir == 2 ? b->y + b->h / 2 - (cur.y + cur.h / 2) : dir == 3 ? cur.x + cur.w / 2 - (b->x + b->w / 2) : b->x + b->w / 2 - (cur.x + cur.w / 2); };
  auto ov = [&](const Btn *b) { double b0 = H_ ? b->y : b->x, b1 = H_ ? b->y + b->h : b->x + b->w; return std::min(c1, b1) - std::max(c0, b0); };
  auto side = [&](const Btn *b) { return std::fabs((H_ ? b->y + b->h / 2 : b->x + b->w / 2) - cc); };
  std::vector<const Btn *> ahead, lined;
  for (auto *b : nav) if (ctr(b) > 4 && gap(b) > -std::min(cur.w, cur.h) * .5) ahead.push_back(b);
  for (auto *b : ahead) if (ov(b) > std::min(H_ ? cur.h : cur.w, H_ ? b->h : b->w) * (H_ ? .5 : .2)) lined.push_back(b);
  if (!lined.empty()) { const Btn *best = nullptr; double bs = 1e9; for (auto *b : lined) { double sc = std::max(0.0, gap(b)) + side(b) * .35; if (sc < bs) { bs = sc; best = b; } } return best; }
  if (H_) { const Btn *r = nullptr; for (auto *b : nav) if (ov(b) > std::min(cur.h, b->h) * .5 && ctr(b) < -4) { if (!r || ctr(b) < ctr(r)) r = b; } if (r) return r; }
  const Btn *best = nullptr; double bs = 1e9; for (auto *b : ahead) { double sc = std::max(0.0, ctr(b)) + side(b) * 2.5; if (sc < bs) { bs = sc; best = b; } }
  return best;
}
void drawFocus() {
  if (!mPadUsed) return; const Btn *b = nullptr; for (auto &q : btns) if (q.id == mFocus && !q.np) { b = &q; break; }
  if (!b && !btns.empty()) { b = padFirst(); if (b) mFocus = b->id; }
  if (!b || b->np || b->nr) return;
  glassHi(b->x - 3, b->y - 3, b->w + 6, b->h + 6);
}
static void menuShoulder(int d) {
  if (screen == "utroster") { utShoulder(d); return; }
  if (mode == "pro") proShoulder(d);
}
static double mRep = 0, mHeldRep = 0; static int mLastDir = 0, mHeld = 0;
static void tapUI(float x, float y) {
  mPadUsed = false;
  for (auto &b : btns) if (x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h) { std::string id = b.id; bool dis = b.dis; if (!dis) uiTap(id); return; }
}
// the pad on menu screens: D-pad / left stick move (held: repeats), X selects, O backs out, SQUARE deletes or
// sells, TRIANGLE examines a card, L / R page
// ---------------------------------------------------------------- the volume sliders (Settings: SFX and MUSIC, 0-100)
void setVolume(bool music, int v, bool save) {
  v = std::max(0, std::min(100, v)); float g = (float)std::pow(v / 100.0, 1.6);   // a gentle curve: the low end isn't all whisper
  if (music) { settings.musV = v; settings.music = v > 0; g_musVol = g; }
  else { bool was = settings.sfx; settings.sfxV = v; settings.sfx = v > 0; QO.sfx = settings.sfx; g_sfxVol = g; if (was && !settings.sfx) snd_stop(-1); }
  if (save) saveSettings();
}
static double volDirty = 0, volBlip = 0;
static bool isSlider(const std::string &id) { return id == "set:sfx" || id == "set:music"; }
static void volStep(bool mu, int v) {
  int cur = mu ? settings.musV : settings.sfxV; v = std::max(0, std::min(100, v)); if (v == cur) return;
  setVolume(mu, v, false); volDirty = now();
  if (!mu && v > 0 && now() - volBlip > 110) { volBlip = now(); sfx(S_PASS, .7); }   // hear it as you go
}
static bool sliderTouch(float x, float y) {   // touching a slider's track sets it there (drag to slide)
  for (auto &b : btns) if (isSlider(b.id) && x >= b.x - 6 && x <= b.x + b.w + 6 && y >= b.y - 8 && y <= b.y + b.h + 8) {
    double pad = (b.h - 4) * .4, k = (x - b.x - pad) / std::max(1.0, b.w - 2 * pad); volStep(b.id == "set:music", (int)std::lround(clamp(k, 0, 1) * 100)); mFocus = b.id; return true; }
  return false;
}
static void menuPadButtons2(uint32_t press, const Pad &pad);
// a slider with pad focus takes left / right: L / R = 10 a press; D-pad or stick = 1 a press, and held, after a
// moment it runs, faster and faster
static void menuPadButtons(uint32_t press, const Pad &pad0) {
  static int hd = 0; static double h0 = 0, acc = 0, lt = 0; double tt = now();
  bool on = mPadUsed && isSlider(mFocus) && !modal.on; if (on) { on = false; for (auto &b : btns) if (b.id == mFocus) on = true; }
  if (!on) { hd = 0; lt = tt; menuPadButtons2(press, pad0); return; }
  Pad pad = pad0; bool mu = mFocus == "set:music"; int cv = mu ? settings.musV : settings.sfxV;
  if (press & 3) { volStep(mu, cv + (press & 1 ? -10 : 10)); cv = mu ? settings.musV : settings.sfxV; }
  double sx = (pad.lx - 128) / 127.0, sy = (pad.ly - 128) / 127.0;
  int hx = pad.btn & B_LEFT ? -1 : pad.btn & B_RIGHT ? 1 : 0; bool stickH = std::fabs(sx) > .55 && std::fabs(sx) > std::fabs(sy);
  if (!hx && stickH) hx = sx < 0 ? -1 : 1;
  if (hx) { if (hx != hd) { hd = hx; h0 = tt; acc = 0; volStep(mu, cv + hx); }
    else { double h = tt - h0; if (h > 380) { double rate = std::min(150.0, 12 + (h - 380) * .1); acc += rate * std::min(.1, (tt - lt) / 1000); int n = (int)acc; if (n) { acc -= n; volStep(mu, cv + hx * n); } } } }
  else hd = 0;
  lt = tt;
  pad.btn &= ~(uint32_t)(B_LEFT | B_RIGHT); if (stickH) pad.lx = 128;
  menuPadButtons2(press & ~(uint32_t)(B_LEFT | B_RIGHT | 3u), pad);
}
static void menuPadButtons2(uint32_t press, const Pad &pad) {
  if (trActive() || btns.empty()) return;
  if (press & 3) { menuShoulder(press & 1 ? -1 : 1); if (!(press & ~3u)) return; }
  int dir = press & B_UP ? 1 : press & B_DOWN ? 2 : press & B_LEFT ? 3 : press & B_RIGHT ? 4 : 0;
  double t = now(); uint32_t btn = pad.btn;
  int hd = btn & B_UP ? 1 : btn & B_DOWN ? 2 : btn & B_LEFT ? 3 : btn & B_RIGHT ? 4 : 0;
  if (dir) { mHeld = dir; mHeldRep = t + 420; } else if (hd && hd == mHeld && t > mHeldRep) { dir = hd; mHeldRep = t + 130; }
  if (!hd) mHeld = 0;
  double sx = (pad.lx - 128) / 127.0, sy = (pad.ly - 128) / 127.0; int sd = hyp(sx, sy) > .6 ? (std::fabs(sy) > std::fabs(sx) ? (sy < 0 ? 1 : 2) : (sx < 0 ? 3 : 4)) : 0;
  if (!dir && !hd && sd) { if (sd != mLastDir || t > mRep) { dir = sd; mRep = t + (sd != mLastDir ? 420 : 170); } }
  mLastDir = sd;
  if (!dir && !(press & (B_CROSS | B_CIRCLE | B_SQUARE | B_TRIANGLE))) return;
  mPadUsed = true;
  const Btn *cur = nullptr; for (auto &b : btns) if (b.id == mFocus && !b.np) { cur = &b; break; }
  if (cur && noPad(*cur)) cur = nullptr;
  if (!cur) { cur = padFirst(); if (!cur) return; mFocus = cur->id; if (dir) return; }
  Btn C = *cur;
  if (press & B_CROSS) { if (!C.dis) uiTap(C.id); return; }
  if (press & B_CIRCLE) { if (modal.on) { modal.on = false; return; }
    const Btn *bk = nullptr; for (auto &b : btns) if (isBackLb(b.lb)) { bk = &b; break; }
    if (!bk) for (auto &b : btns) if (b.id == "nav:modes" || b.id == "namecancel") { bk = &b; break; }
    if (bk) { std::string id = bk->id; uiTap(id); } return; }
  if (press & B_SQUARE) { if (!modal.on) { if (screen == "utslots" || screen == "utroster") utPadSquare(C.id); else if (screen == "proslots" && C.id.rfind("pslot:", 0) == 0 && proSlotInfo(atoi(C.id.c_str() + 6)).on) uiTap("pdel:" + C.id.substr(6)); } if (!dir) return; }
  if (press & B_TRIANGLE) { if (!modal.on) utPadTriangle(C); if (!dir) return; }
  if (C.id == "cont" && dir == 3 && screen == "modes") { mFocus = "mode:pro"; return; }   // off the main menu's panel: back to the top
  const Btn *best = padMove(C, dir);
  if (best) mFocus = best->id;
}
// touch on the menus: a press acts on the button under it (cards in Ultimate Franchise: hold to flip)
static Touch prevTouch;
static void menuTouch(const Touch &t) {
  for (int j = 0; j < t.n; j++) { bool was = false; for (int i = 0; i < prevTouch.n; i++) if (prevTouch.p[i].id == t.p[j].id) was = true;
    if (!was) { if (sliderTouch(t.p[j].x, t.p[j].y)) { mPadUsed = false; continue; } if (mode == "ut" && utLPDown(t.p[j].x, t.p[j].y, t.p[j].id)) continue; tapUI(t.p[j].x, t.p[j].y); }
    else { for (auto &b : btns) if (isSlider(b.id) && b.id == mFocus) { sliderTouch(t.p[j].x, t.p[j].y); break; } } }
  for (int i = 0; i < prevTouch.n; i++) { bool still = false; float x = prevTouch.p[i].x, y = prevTouch.p[i].y;
    for (int j = 0; j < t.n; j++) if (t.p[j].id == prevTouch.p[i].id) still = true;
    if (!still) utLPUp(prevTouch.p[i].id, x, y, true); }
  prevTouch = t;
}
void menuPad(uint32_t press, const Pad &pad, const Touch &touch) {
  if (trActive()) { prevTouch = touch; return; }
  if (proAptInput(press, pad, touch)) { prevTouch = touch; return; }
  menuTouch(touch);
  menuPadButtons(press, pad);
  if (volDirty > 0 && now() - volDirty > 700) { volDirty = 0; saveSettings(); }
}

// ---------------------------------------------------------------- the main menu
struct LastI { std::string m; int i = -1; };
static LastI lastInfo() {
  J &L = lastSave(); LastI o;
  if (L("m").str() == "pro" && L("i").i(-1) >= 0 && L("i").i() < 3 && proSlotInfo(L("i").i()).on) { o.m = "pro"; o.i = L("i").i(); return o; }
  if (L("m").str() == "ut" && L("i").i(-1) >= 0 && L("i").i() < 3 && utSlots[L("i").i()]) { o.m = "ut"; o.i = L("i").i(); return o; }
  for (int i = 0; i < 3; i++) if (utSlots[i]) { o.m = "ut"; o.i = i; return o; }
  for (int i = 0; i < 3; i++) if (proSlotInfo(i).on) { o.m = "pro"; o.i = i; return o; }
  return o;
}
// a menu row, minimal: just the words. The one with focus grows, turns white, gets its accent bar, a wash of
// its colour and the line about it; the rest sit back in grey. Sizes ease, so moving through the list glides.
static float easeTo(const std::string &id, bool on) { static std::map<std::string, float> A; auto it = A.find(id); float v = it == A.end() ? (on ? 1.f : 0.f) : it->second; v += ((on ? 1.f : 0.f) - v) * .22f; A[id] = v; return v; }
void menuCard(const std::string &id, const std::string &label, const std::string &sub, double x, double y, double w, double h, Col acc, bool big) {
  bool foc = mPadUsed ? mFocus == id : big; float a = easeTo(id, foc);
  if (a > .01f) { glassHi(x, y + 1, w, h - 2, a); gradRect(x + 3, y + 3, w * .6, h - 6, acc, .14 * a, acc, 0, false);
    ctx.alpha(a); accentBar(x, y, h, acc); ctx.alpha(1); }
  ctx.fill(rgba(255, 255, 255, .06)); ctx.fillRect(x, y + h - 1, w, 1);
  bool two = !sub.empty() && a > .3f; double fs = h * (.34 + .08 * a), lx = x + h * .22 + a * h * .1;
  tx(label, lx, y + h * (two ? .38 : .5), fs / U, lerpC(hex("#8b98ab"), hex("#ffffff"), a), AL_LEFT, a > .5f);
  if (two) { ctx.alpha((a - .3f) / .7f); ctx.font(h * .2); ctx.fill("#cbd5e1"); ctx.textMid(AL_LEFT); std::string s2 = sub; ctx.fitPx(s2, h * .2, w - h * .5); ctx.fillText(s2, lx, y + h * .74); ctx.alpha(1); }
  pushBtn(id, x, y, w, h, label); btns.back().nr = true;
}
static void drawMainMenu() {
  bool land = W > H * 1.15; double m = .05 * U, ty = safeTop + .065 * U, t = now() / 1000;
  wordmark(m, ty, .052 * U);
  ctx.font(.02 * U); ctx.fill(rgba(203, 213, 225, .6)); ctx.textMid(AL_RIGHT); ctx.fillText(std::string("v") + GAME_VER, W - m, ty);
  // who stands on the right, in 3D: the save you played last (your pro, your best card), else your last quick-play team's best
  LastI LI = lastInfo(); UTX *ud = LI.m == "ut" ? utSlots[LI.i].get() : nullptr;
  ProSlotInfo pd = LI.m == "pro" ? proSlotInfo(LI.i) : ProSlotInfo();
  HeroSpec hs; bool have = false;
  if (pd.on) { hs.nm = pd.nm; if (!pd.jc.empty()) { hs.j = hex(pd.jc); hs.s = hex(pd.js); } hs.skin = skinOf(pd.nm); hs.num = pd.num; hs.right = pd.sh == 'R'; hs.tag = upper(pd.nm) + "  |  #" + istr(pd.num) + "  |  " + upper(pd.team); have = true; }
  else if (ud) have = utHeroSpec(*ud, hs);
  if (!have) have = quickHero(hs);
  if (!have) { hs.nm = "CHL"; hs.num = 26; hs.tag = "CHL 2026"; }
  double hx = land ? W * .40 : W * .2, hw = W - hx, hy = ty + .01 * U, hh = (land ? H * .70 : H * .5) - hy;
  // the panel: a soft rounded square around him and the continue band, so it reads as one thing to tap
  double pnx = land ? W * .42 : m, pny = ty + .035 * U, pnw = W - m - pnx, pnh = (land ? H * .70 + .13 * U + .018 * U + .05 * U + .02 * U : hy + hh + .2 * U) - pny, pnr = .03 * U;
  bool pnFoc = mPadUsed && mFocus == "cont";
  ctx.fill(rgba(255, 255, 255, .04)); ctx.rr(pnx, pny, pnw, pnh, pnr); ctx.fillPath();
  // his light: a glow in his colours, his number huge and faint, a pool of light on the ice
  softGlow(hx + hw * .66, hy + hh * .5, hw * .38, hh * .62, hs.j, .32 + .05 * std::sin(t * .8));
  softGlow(hx + hw * .58, hy + hh * .3, hw * .22, hh * .35, hs.s, .08);
  if (hs.num >= 0) { ctx.alpha(.045); ctx.fill("#fff"); ctx.font(hh * .6); ctx.textMid(); ctx.fillText(istr(hs.num), hx + hw * .66, hy + hh * .44); ctx.alpha(1); }
  softGlow(hx + hw * .66, hy + hh * .93, hw * .24, hh * .06, Col(255, 255, 255), .22);
  hero3D(hx, hy, hw, hh, hs, false, true);
  if (pnFoc) glassHi(pnx, pny, pnw, pnh); else { ctx.stroke(rgba(255, 255, 255, .16)); ctx.lineWidth(1.2); ctx.rr(pnx + .5, pny + .5, pnw - 1, pnh - 1, pnr); ctx.strokePath(); }
  // the band across the bottom right: carry on with the last save
  double by0 = land ? H * .70 : hy + hh, bh = .13 * U, bx0 = pnx + 1;
  gradRect(bx0, by0, pnx + pnw - 1 - bx0, bh, shade(hs.j, -.5), 0, shade(hs.j, -.35), .75, false);
  gradRect(bx0, by0, pnx + pnw - 1 - bx0, 2, hs.j, 0, hs.j, .9, false);
  std::string tt, st;
  if (pd.on) { tt = "CONTINUE BE A PRO"; st = upper(pd.nm) + "  |  " + (pd.phase == "retired" ? std::string("RETIRED") : "OVR " + istr(pd.ov) + "  |  " + upper(pd.team)) + "  |  AGE " + istr(pd.age) + "  |  SEASON " + istr(pd.season); }
  else if (ud) { tt = "CONTINUE ULTIMATE FRANCHISE"; st = ud->nm + "  |  TEAM OVR " + istr(utTeamOv(*ud)) + "  |  " + istr(ud->w) + "-" + istr(ud->l) + "  |  " + fmtN(ud->coins) + " COINS"; }
  else { tt = "20 SEASONS. ONE LEGACY."; st = "32 real teams. Draft night, contracts, trades and the salary cap - in full 3D."; }
  { double maxW = W - m - bx0 - .07 * U; ctx.font(.052 * U); double tw = ctx.measure(tt); double px = tw > maxW ? .052 * U * maxW / tw : .052 * U;
    tx(tt, W - m - .025 * U, by0 + .05 * U, px / U, hex("#fff"), AL_RIGHT, true);
    ctx.font(.019 * U); ctx.fill("#cbd5e1"); ctx.textMid(AL_RIGHT); std::string s2 = st; ctx.fitPx(s2, .019 * U, maxW); ctx.fillText(s2, W - m - .025 * U, by0 + .097 * U); }
  if (LI.i >= 0) { double pw = .24 * U, ph = .05 * U, px = W - m - .025 * U - pw, py = by0 + bh + .018 * U; bool foc = mPadUsed && mFocus == "cont"; double pulse = .5 + .5 * std::sin(t * 3);
    softGlow(px + pw / 2, py + ph / 2, pw * .75, ph * 1.6, Col(255, 255, 255), foc ? .22 + .1 * pulse : .08 + .05 * pulse);
    ctx.fill(foc ? "#ffffff" : "#e8edf5"); ctx.rr(px, py, pw, ph, ph * .18); ctx.fillPath();
    double cr = ph * .3, cx = px + pw * .22; ctx.stroke("#0b1220"); ctx.lineWidth(1.5); ctx.rr(cx - cr, py + ph / 2 - cr, cr * 2, cr * 2, cr); ctx.strokePath();
    ctx.fill("#0b1220"); ctx.font(cr * 1.2); ctx.textMid(); ctx.fillText("X", cx, py + ph / 2 + 1);
    tx("CONTINUE", px + pw * .6, py + ph / 2, .022, hex("#0b1220"), AL_CENTER, true);
    pushBtn("cont", pnx, pny, pnw, pnh, "CONTINUE"); btns.back().nr = true; }
  // the menu, left: just the words
  struct MI { const char *id, *lb, *sub; };
  static const MI items[5] = {{"mode:pro", "BE A PRO", "Live the life, become an NHL star"}, {"mode:ut", "ULTIMATE FRANCHISE", "Open packs, build a team, chase the Cup"},
    {"mode:quick", "QUICK PLAY", "Drop the puck - one game, right now"}, {"mode:practice", "PRACTICE", "Drills, targets and the shootout"}, {"nav:settings", "SETTINGS", "Controls, camera, sound and the rules"}};
  int cur = -1; for (int k = 0; k < 5; k++) if (mFocus == items[k].id) cur = k;
  if (!mPadUsed) cur = 0;
  double lx = m, lw = land ? W * .4 : W - 2 * m, ly = ty + .12 * U;
  for (int k = 0; k < 5; k++) { float a = easeTo(items[k].id, k == cur); double fs = (.036 + .03 * a) * U, rh = fs * 1.3 + a * .036 * U;
    double bx = lx - .038 * U, bw = lw - .01 * U;
    if (a > .01f) { glassHi(bx, ly - .004 * U, bw, rh, a);   // a soft rounded square around it, its edge breathing like the panel's
      ctx.alpha(a); ctx.fill(ACC); ctx.rr(lx - .024 * U, ly + fs * .2, 3, fs * .95, 1.5); ctx.fillPath(); ctx.alpha(1); }
    { ctx.font(fs); double mw = bx + bw - .02 * U - lx, tw = ctx.measure(items[k].lb) * 1.06; if (tw > mw) fs *= mw / tw; }   // the long one (ULTIMATE FRANCHISE) shrinks to fit its box
    tx(items[k].lb, lx, ly + rh * (a > .05f ? .36 : .5) - .002 * U, fs / U, lerpC(hex("#7d8aa0"), hex("#ffffff"), a), AL_LEFT, true);
    if (a > .05f) { ctx.alpha(a); ctx.font(.019 * U); ctx.fill("#cbd5e1"); ctx.textMid(AL_LEFT); ctx.fillText(items[k].sub, lx, ly + rh * .76); ctx.alpha(1); }
    pushBtn(items[k].id, lx - .03 * U, ly, lw, rh, items[k].lb); btns.back().nr = true; ly += rh + .008 * U; }
  footHints({{"D-PAD", "MOVE"}, {"X", "SELECT"}, {"TOUCH", "TAP ANYTHING"}});
}

// ---------------------------------------------------------------- the menu screens
// the settings screen (also the Settings app on the Be a Pro phone, drawn at the phone's size)
void drawSettingsBody() {
  double w = std::min(W - 24.0, 1.7 * U), x = (W - w) / 2, y = safeTop + .02 * U, t = now() / 1000;
  auto L = [&](const std::string &tt, double sz, const char *c, double xx, double yy, Align al) { tx(tt, xx, yy, sz, hex(c), al); };
  // the header: title, a quiet line about it, a hairline
  tx("SETTINGS", x, y + .045 * U, .06, hex("#fff"), AL_LEFT, true);
  gradRect(x, y + .085 * U, w, 1, Col(255, 255, 255), .25, Col(255, 255, 255), 0, false); (void)t;
  // a row: no box - a hairline under it, a small dot of its colour, the title and two quiet lines. With focus: a wash
  // of its colour from the left and an accent bar
  auto row = [&](double ry, double rh, const char *ic, const char *icCol, const std::string &title, const std::string &l1, const std::string &l2, std::initializer_list<const char *> ids, double txtW) {
    (void)ic; bool foc = false; for (auto id : ids) if (mFocus == id) foc = true; foc = foc && mPadUsed;
    float a = easeTo(std::string("setrow:") + title, foc); Col ac = hex(icCol);
    if (a > .01f) { gradRect(x, ry, w, rh, ac, .16 * a, ac, 0, false); ctx.alpha(a); ctx.fill(ac); ctx.fillRect(x, ry + rh * .15, 3, rh * .7); ctx.alpha(1); }
    ctx.fill(rgba(255, 255, 255, .07)); ctx.fillRect(x, ry + rh - 1, w, 1);
    ctx.fill(ac); ctx.disc(x + .025 * U, ry + rh * (l1.empty() && l2.empty() ? .5 : .24), .006 * U);
    double lx = x + .045 * U; bool one = l1.empty() && l2.empty(); L(title, .028, "#fff", lx, ry + rh * (one ? .5 : .24), AL_LEFT);
    TXR = lx + txtW + .055 * U; L(l1, .0185, "#8b98ab", lx, ry + rh * .56, AL_LEFT); L(l2, .0185, "#8b98ab", lx, ry + rh * .78, AL_LEFT); TXR = 1e4; };
  // an on / off switch: a slim pill with a sliding knob (and its label to the left)
  auto sw = [&](const std::string &id, double sx, double sy, double swd, double sh, const std::string &lb, bool on, const char *onCol) {
    (void)onCol; bool foc = mPadUsed && mFocus == id; double pw = sh * 1.9, px = sx + swd - pw;
    ctx.fill(foc ? "#fff" : "#cbd5e1"); ctx.font(sh * .48); ctx.textMid(AL_RIGHT); ctx.fillText(lb, px - sh * .35, sy + sh / 2 + 1);
    ctx.fill(on ? hex("#2dd4bf") : rgba(255, 255, 255, .12)); ctx.rr(px, sy, pw, sh, sh / 2); ctx.fillPath();
    if (foc) softGlow(px + pw / 2, sy + sh / 2, pw * .9, sh * 1.3, Col(255, 255, 255), .16);
    double kx = on ? px + pw - sh / 2 : px + sh / 2; ctx.fill(rgba(0, 0, 0, .25)); ctx.disc(kx + 1, sy + sh / 2 + 1.5, sh * .38); ctx.fill("#fff"); ctx.disc(kx, sy + sh / 2, sh * .38);
    ctx.fill(on ? "#063b36" : "#94a3b8"); ctx.font(sh * .34); ctx.textMid(); ctx.fillText(on ? "ON" : "OFF", on ? px + sh * .66 : px + pw - sh * .66, sy + sh / 2 + 1);
    pushBtn(id, sx, sy - 2, swd, sh + 4, lb); btns.back().nr = true; };
  // a volume slider: the label, a track filling teal, a white knob, the number
  auto sl = [&](const std::string &id, double sx, double sy, double swd, double sh, const std::string &lb, int v) {
    bool foc = mPadUsed && mFocus == id; double lw = lb.empty() ? 0 : swd * .2, vw = swd * .13, t0 = sx + lw, tw = swd - lw - vw - sh * .4, th = sh * .2, ty0 = sy + sh / 2 - th / 2, k = v / 100.0;
    ctx.fill(foc ? "#fff" : "#cbd5e1"); ctx.font(sh * .48); ctx.textMid(AL_LEFT); ctx.fillText(lb, sx, sy + sh / 2 + 1);
    ctx.fill(rgba(255, 255, 255, .12)); ctx.rr(t0, ty0, tw, th, th / 2); ctx.fillPath();
    if (v > 0) { gradRect(t0 + th / 2, ty0, std::max(0.0, tw * k - th / 2), th, hex("#0d9488"), 1, hex("#2dd4bf"), 1, false); ctx.fill("#0d9488"); ctx.disc(t0 + th / 2, ty0 + th / 2, th / 2); }
    double kx = t0 + tw * k; if (foc) softGlow(kx, sy + sh / 2, sh * 1.1, sh * 1.1, Col(45, 212, 191), .3);
    ctx.fill(rgba(0, 0, 0, .3)); ctx.disc(kx + 1, sy + sh / 2 + 1.5, sh * .36); ctx.fill("#fff"); ctx.disc(kx, sy + sh / 2, sh * .36);
    ctx.fill(v ? (foc ? "#fff" : "#e2e8f0") : "#64748b"); ctx.font(sh * .46); ctx.textMid(AL_RIGHT); ctx.fillText(v ? istr(v) : std::string("OFF"), sx + swd, sy + sh / 2 + 1);
    double pad = sh * .4; pushBtn(id, t0 - pad, sy - 2, tw + 2 * pad, sh + 4, lb); btns.back().nr = true; };
  // a two-way choice: a quiet track, the picked side white
  auto seg = [&](const std::string &id, double sx, double sy, double swd, double sh, const char *a, const char *b, bool second, const char *col) {
    (void)col; bool foc = mPadUsed && mFocus == id; ctx.fill(rgba(255, 255, 255, foc ? .14 : .08)); ctx.rr(sx, sy, swd, sh, sh / 2); ctx.fillPath();
    double hw = swd / 2, kx = second ? sx + hw : sx; ctx.fill("#fff"); ctx.rr(kx + 3, sy + 3, hw - 6, sh - 6, (sh - 6) / 2); ctx.fillPath();
    ctx.font(sh * .4); ctx.textMid(); ctx.fill(second ? "#94a3b8" : "#0b1220"); ctx.fillText(a, sx + hw / 2, sy + sh / 2 + 1); ctx.fill(second ? "#0b1220" : "#94a3b8"); ctx.fillText(b, sx + hw * 1.5, sy + sh / 2 + 1);
    if (foc) softGlow(sx + swd / 2, sy + sh / 2, swd * .65, sh * 1.3, Col(255, 255, 255), .12);
    pushBtn(id, sx, sy, swd, sh, std::string(a) + " / " + b); btns.back().nr = true; };
  double rh = .098 * U, gap = .012 * U, ry = y + .11 * U, cw = .34 * U, cx = x + w - cw - .025 * U, txtW = cx - x - .14 * U;
  row(ry, rh, "GA", "#38bdf8", "GOALIE ASSIST", "With the left stick centred, your goalie squares up", "to the puck on his own (Casual and Standard only).", {"set:gAssist"}, txtW);
  sw("set:gAssist", cx, ry + rh * .3, cw, rh * .4, "ASSIST", settings.gAssist, "#16a34a"); ry += rh + gap;
  bool aa = settings.autoAim;
  row(ry, rh, "AA", "#f26b5b", "AUTO AIM (SHOTS)", aa ? "ON: in the attacking zone, your shots stay between the posts." : "OFF: shots go exactly where the left stick points,", aa ? "Outside the zone they go where the left stick points." : "so a wild one can miss the net.", {"set:autoAim"}, txtW);
  sw("set:autoAim", cx, ry + rh * .3, cw, rh * .4, "AUTO AIM", aa, "#16a34a"); ry += rh + gap;
  bool sb = settings.shotB;
  row(ry, rh, "SC", "#a78bfa", "SHOT CONTROLS", sb ? "TYPE B: the right stick aims. Tap R = wrist, hold R = slap, let go to fire." : "TYPE A: right stick up = wrist, back = slap; slide sideways to aim, let go to shoot.",
    sb ? "With the puck: tap X = pass, hold X = sprint." : "R sprints. Hold L: pass to the teammate under SQUARE / TRIANGLE / CIRCLE.", {"set:shotB"}, txtW);
  seg("set:shotB", cx, ry + rh * .27, cw, rh * .46, "TYPE A", "TYPE B", sb, "#7c3aed"); ry += rh + gap;
  { double rs = rh * .58, slw = cw + .14 * U, slx = cx + cw - slw;
    row(ry, rs, "SF", "#fbbf24", "SOUND EFFECTS", "", "", {"set:sfx"}, txtW); sl("set:sfx", slx, ry + rs * .2, slw, rs * .6, "", settings.sfxV); ry += rs + gap;
    row(ry, rs, "MU", "#f472b6", "MUSIC", "", "", {"set:music"}, txtW); sl("set:music", slx, ry + rs * .2, slw, rs * .6, "", settings.musV); ry += rs + gap; }
  bool chh = settings.camHigh;
  row(ry, rh, "CM", "#4ade80", "CAMERA (SKATERS)", chh ? "HIGH: straight overhead, the attack runs up the screen." : "LOW: the broadcast camera behind the play.", "Also in the pause menu during a game.", {"set:camHigh"}, txtW);
  seg("set:camHigh", cx, ry + rh * .27, cw, rh * .46, "LOW", "HIGH", chh, "#2563eb"); ry += rh + gap;
  row(ry, rh, "RL", "#e2e8f0", "RULES", "Offsides, icing and penalties: here or in Be a Pro /", "Ultimate Franchise settings - never mid-game.", {"set:rOff", "set:rIce", "set:rPen"}, w * .36);
  { const char *ids[3] = {"set:rOff", "set:rIce", "set:rPen"}, *nm[3] = {"OFFSIDES", "ICING", "PENALTIES"}; bool on[3] = {settings.rOff, settings.rIce, settings.rPen};
    double sh = rh * .4, gw[3], tot = 0; ctx.font(sh * .48); for (int k = 0; k < 3; k++) { gw[k] = ctx.measure(nm[k]) + sh * .35 + sh * 1.9; tot += gw[k]; }
    double r1 = x + w - .025 * U, r0 = x + w * .44, gp = std::max(.02 * U, (r1 - r0 - tot) / 2), gx = r1 - tot - 2 * gp;   // three groups, equal gaps, the last one flush right
    for (int k = 0; k < 3; k++) { sw(ids[k], gx, ry + rh * .3, gw[k], sh, nm[k], on[k], "#16a34a"); gx += gw[k] + gp; } }
  ry += rh + gap;
  ui("nav:modes", (W - .5 * U) / 2, ry + .008 * U, .5 * U, .075 * U, "BACK", "#475569", true, .04);
}
static void drawMenuScreens() {
  if (screen == "modes" && aptReady()) aptUnload();   // left Be a Pro (the phone's EXIT app): the apartment's memory goes back
  if (mode == "ut" && !UT && screen != "modes" && screen != "utslots" && screen != "name" && screen != "settings") screen = "utslots";
  btns.clear();
  menuBG(); menuSnow();
  double w = std::min(W - 24.0, 1.7 * U), x = (W - w) / 2, y = safeTop + .02 * U, bh = .095 * U, bw = std::min(w, .9 * U), bx = (W - bw) / 2, g = bh + .012 * U;
  auto T = [&](const std::string &t, double s, const char *c, double yy) { tx(t, W / 2, yy, s, hex(c), AL_CENTER, s >= .05); };
  auto card = [&](double cx, double cyy, double cw, double ch, Col col) { glass(cx, cyy, cw, ch, .85); ctx.alpha(.3); ctx.fill(col); ctx.fillRect(cx, cyy, cw, ch); ctx.alpha(1); ctx.fill(col); ctx.fillRect(cx, cyy, std::max(5.0, ch * .05), ch); };
  auto L = [&](const std::string &t, double s, const char *c, double xx, double yy, Align al) { tx(t, xx, yy, s, hex(c), al); };
  auto row = [&](double cx, double cyy, double cw, double ch, bool hi) { glass(cx, cyy, cw, ch, .62); if (hi) { glassHi(cx, cyy, cw, ch); accentBar(cx, cyy, ch, ACC); } };
  auto B = [&](int i, const std::string &id, const std::string &lb, const char *col, bool on = true) { ui(id, bx, y + .275 * U + i * g, bw, bh, lb, col, on, .045); };
  auto back = [&](const std::string &id, double yy) { ui(id, (W - .5 * U) / 2, yy, .5 * U, .08 * U, "BACK", "#475569", true, .04); };
  (void)card; (void)back;
  if (screen == "modes") drawMainMenu();
  else if (mode == "ut" && (screen == "main" || screen.rfind("ut", 0) == 0)) { if (UT && utExFull()) { ctx.fill("#020617"); ctx.fillRect(0, 0, W, H); drawUTEx(); }   // the viewer covers the roster: don't draw 27 cards (and their 3D portraits) behind it every frame
    else { drawUT(); if (UT && utExOn()) drawUTEx(); } utLPCheck(); }
  else if (mode == "pro" && screen != "name" && (screen != "settings" || proInPhone()) && screen != "result") drawPro();
  else if (mode == "practice" && screen == "main") drawPractice();
  else if (screen == "name") {
    bool two = nameFor == "pro"; bool blink = (int)std::floor(now() / 500) % 2;
    T(two ? "NAME YOUR PLAYER" : "NAME YOUR TEAM", .06, "#fff", y + .05 * U);
    if (two) {   // first and last name: tap a box to type in it
      double hw = (w - .02 * U) / 2;
      for (int f = 0; f < 2; f++) { double fx = x + f * (hw + .02 * U); bool on = pField == f; row(fx, y + .1 * U, hw, .1 * U, on);
        tx(f ? "LAST NAME" : "FIRST NAME", fx + .02 * U, y + .118 * U, .018, hex(on ? "#ffd54a" : "#94a3b8"), AL_LEFT);
        const std::string &v = f ? pLast : pFirst; TXR = fx + hw - .01 * U; tx(v + (on && blink ? "_" : ""), fx + .02 * U, y + .165 * U, .042, hex(on ? "#fff" : "#cbd5e1"), AL_LEFT, true); TXR = 1e4;
        pushBtn("nf:" + istr(f), fx, y + .1 * U, hw, .1 * U, f ? "LAST NAME" : "FIRST NAME", true); }
    } else { row(x, y + .1 * U, w, .1 * U, false); T(pname + (blink ? "_" : " "), .055, "#ffd54a", y + .15 * U); }
    double kw = std::min(w / 10.4, .11 * U), kh = .1 * U, gp = kw * .1, y0 = y + .225 * U;
    static const char *rowsK[3] = {"qwertyuiop", "asdfghjkl", "^zxcvbnm<"};
    for (int ri = 0; ri < 3; ri++) { std::string r = rowsK[ri]; double tot = r.size() * (kw + gp) - gp, sx = (W - tot) / 2;
      for (size_t ci = 0; ci < r.size(); ci++) { char c = r[ci]; std::string lb = c == '^' ? (kCaps ? "CAPS" : "SHIFT") : c == '<' ? "<" : std::string(1, kShift || kCaps ? (char)std::toupper(c) : c);
        ui("key:" + std::string(1, c), sx + ci * (kw + gp), y0 + ri * (kh + gp), kw, kh, lb, c == '<' ? "#b45309" : c == '^' ? (kShift || kCaps ? "#2563eb" : "#475569") : "#334155", true, c == '^' ? .022 : .045); } }
    double by = y0 + 3 * (kh + gp), sw = std::min(w, 10.4 * kw);
    ui("key:_", (W - sw) / 2, by, sw * .62, kh, two ? "SPACE / NEXT BOX" : "SPACE", "#334155", true, .03);
    ui("rand", (W - sw) / 2 + sw * .64, by, sw * .36, kh, "RANDOM", "#7c3aed", true, .03);
    double b2 = std::min(.42 * U, (w - .02 * U) / 2), by2 = by + kh + .025 * U;
    bool ok = two ? !trim(pFirst).empty() && !trim(pLast).empty() : !trim(pname).empty();
    ui("namego", W / 2 - b2 - .01 * U, by2, b2, .085 * U, nameFor == "ut" ? "CREATE" : "NEXT", "#16a34a", ok, .04);
    ui("namecancel", W / 2 + .01 * U, by2, b2, .085 * U, "CANCEL", "#475569", true, .04);
    tx("SHIFT: one capital  |  tap SHIFT twice: CAPS LOCK", W / 2, by2 + .11 * U, .018, hex("#64748b"), AL_CENTER);
  } else if (screen == "settings") {
    drawSettingsBody();
  } else if (screen == "result") {
    bool wn = rs.hs > rs.as;
    tx(wn ? "YOU WIN!" : "YOU LOSE", W / 2, y + .05 * U, .075, hex(wn ? "#7CFC9A" : "#ff5252"), AL_CENTER, true);
    if (rs.so) T("decided in a shootout", .028, "#ffb300", y + .105 * U);
    double c1 = x + w * .22, c2 = x + w * .78;
    L(rs.hn, .03, "#60a5fa", c1, y + .15 * U, AL_CENTER); L(rs.an, .03, "#ff7a7a", c2, y + .15 * U, AL_CENTER);
    struct Rw { std::string a, b, c; } rows[3] = {{"GOALS", istr(rs.hs), istr(rs.as)}, {"SHOTS ON NET", istr(rs.hsh), istr(rs.ash)}, {"GOALIE SV%", svp3(rs.ash - rs.as, rs.ash), svp3(rs.hsh - rs.hs, rs.hsh)}};
    if (rs.hasF) rows[2] = {"YOU", istr(rs.f.g) + " G  " + istr(rs.f.a) + " A", istr(rs.f.sog) + " SOG  " + istr(rs.f.hits) + " HIT"};
    double rh = .085 * U;
    for (int i = 0; i < 3; i++) { double ry = y + .18 * U + i * (rh + .008 * U); row(x, ry, w, rh, false); bool you = rows[i].a == "YOU";
      L(rows[i].a, .024, "#94a3b8", W / 2, ry + rh / 2, AL_CENTER); L(rows[i].b, you ? .034 : .055, you ? "#ffd54a" : "#fff", c1, ry + rh / 2, AL_CENTER); L(rows[i].c, you ? .034 : .055, you ? "#ffd54a" : "#fff", c2, ry + rh / 2, AL_CENTER); }
    double ey = y + .18 * U + 3 * (rh + .008 * U) + .03 * U;
    if (mode == "pro") { T("+" + istr(rs.xp) + " XP    |    +$" + istr(rs.cash) + (rs.note.empty() ? "" : "    |    " + rs.note), .03, "#ffd54a", ey); ui("nav:main", bx, ey + .04 * U, bw, bh, "CONTINUE", "#c8102e", true, .045); }
    else if (mode == "ut") { T("+" + istr(rs.cash) + " COINS" + (UT ? "    |    " + fmtN(UT->coins) + " TOTAL" : ""), .034, "#ffd54a", ey); ui("nav:main", bx, ey + .04 * U, bw, bh, "CONTINUE", "#d97706", true, .045); }
    else { ui("play", bx, ey + .04 * U, bw, bh, "PLAY AGAIN", "#2563eb", true, .045); ui("nav:modes", bx, ey + .04 * U + g, bw, bh, "MODES", "#475569", true, .045); }
  } else if (screen == "main" && mode == "quick") {
    T("QUICK PLAY", .075, "#fff", y + .06 * U);
    T("One exhibition game. No progress saved.", .034, "#cbd5e1", y + .14 * U);
    T("Pick a position: same 3v3 game, same rinks, random teams.", .026, "#94a3b8", y + .2 * U);
    B(0, "qp:G", "PLAY AS GOALIE  -  COMING TO NATIVE", "#2563eb", false); B(1, "qp:F", "PLAY AS FORWARD", "#16a34a"); B(2, "nav:modes", "MODES", "#475569");
  } else if (screen == "soon") {
    // modes still being moved over from the legacy build
    T(mode == "pro" ? "BE A PRO" : "PRACTICE", .075, "#fff", y + .06 * U);
    T("Coming to the native build next.", .034, "#cbd5e1", y + .14 * U);
    T(mode == "pro" ? "Your legacy careers will carry over when it lands." : "The legacy drills move over with goalie mode.", .026, "#94a3b8", y + .2 * U);
    B(1, "nav:modes", "MODES", "#475569");
  } else { screen = "modes"; drawMainMenu(); }
}
// menu screens settle in: a quick fade up from dark with a small slide
static std::string MSk; static double MSt = 0;
void drawMenu() {
  TXL = 0; TXR = 1e4;
  std::string key = mode + "|" + screen + "|" + istr((int)state); double t = now(); if (key != MSk) { MSk = key; MSt = trActive() ? 0 : t; }
  double k = clamp((t - MSt) / 190, 0, 1);
  if (k >= 1) drawMenuScreens();
  else { double e = 1 - std::pow(1 - k, 3); ctx.fill("#0b1220"); ctx.fillRect(0, 0, W, H);
    ctx.save(); ctx.translate(0, std::round((1 - e) * .022 * U)); drawMenuScreens(); ctx.restore();
    ctx.fill(rgba(2, 6, 23, (float)((1 - e) * .6))); ctx.fillRect(0, 0, W, H); }
  drawModal(); drawFocus(); drawMusicPopup();
}

// ---------------------------------------------------------------- the router
static std::string utPrevName = "ROOKIE";
void startGame() {
  if (mode == "pro" && !proCanPlay()) return;
  QO.diff = mode == "pro" && CR ? CR->diff : 1; QO.autoAim = settings.autoAim;
  if (mode == "pro" && CR) { proGainXP = 0; g_leagueAdj = [] { return clamp((CR->lm - 6.2) * .9, -1, 2); }; } else g_leagueAdj = nullptr; QO.sfx = settings.sfx; QO.shotB = settings.shotB;
#ifdef HOST_BUILD
  if (getenv("CHL_SHOTB")) QO.shotB = true;
#endif
  aptUnload();   // the apartment never shares memory with a game
  if (mode == "pro" && CR) proSkillSnap();
  skStart(); state = ST_PLAY; paused = false; screen = "main";
  if (mode == "quick" && SK) { const Src *b = nullptr; for (const Src *q : SK->T[0].bench) if (!q->me && (!b || q->p + q->a > b->p + b->a)) b = q;   // the main menu's hero: this team's best
    if (b) { HeroSpec h; h.nm = b->nm; h.j = SK->T[0].col; h.s = SK->T[0].stripe; h.skin = skinOf(b->nm); h.num = (int)(skHash(b->nm) % 98) + 1; h.right = skHash(b->nm) % 3 == 0;
      h.tag = upper(b->nm) + "  |  " + istr(ovOf(skRatings(b))) + " OVR  |  QUICK PLAY"; setQuickHero(h); } }
}
void uiTap(const std::string &id) {
  if (trActive()) return;
  if (modal.on) { if (id == "mdl:yes") { auto f = modal.yes; modal.on = false; if (f) f(); } else if (id == "mdl:no") modal.on = false; return; }
  if (state == ST_PLAY && paused) { extern bool g_showFps, g_texOn, g_camHigh, g_view3d;
    if (id == "resume") paused = false; else if (id.rfind("ptab:", 0) == 0) pauseTab = atoi(id.c_str() + 5); else if (id == "quit") skQuit();
    else if (id == "ps:fps") { settings.fpsUnlock = !settings.fpsUnlock; g_paceN = settings.fpsUnlock ? 1 : 2; saveSettings(); }
    else if (id == "ps:show") { settings.showFps = g_showFps = !g_showFps; saveSettings(); }
    else if (id == "ps:view") { settings.view3d = g_view3d = !g_view3d; saveSettings(); }
    else if (id == "ps:cam") { settings.camHigh = g_camHigh = !g_camHigh; saveSettings(); }
    else if (id == "ps:tex") { settings.textures = g_texOn = !g_texOn; saveSettings(); }
    else if (id == "ps:aim") { settings.autoAim = QO.autoAim = !settings.autoAim; saveSettings(); }
    else if (id == "ps:shot") { settings.shotB = QO.shotB = !settings.shotB; saveSettings(); }
    return; }
  if (screen == "result" && now() < lockUntil) return;
  if (id == "play") { if (now() >= lockUntil) startGame(); }
  else if (id == "mode:pro") goMode("BE A PRO", [] { proEnter(); }, hex("#c8102e"), false);
  else if (id == "mode:ut") goMode("ULTIMATE FRANCHISE", [] { UT = nullptr; utSlot = -1; mode = "ut"; screen = "utslots"; }, hex("#d97706"), false);
  else if (id == "cont") { LastI L = lastInfo(); if (L.m == "pro") { int i = L.i; goMode("BE A PRO", [i] { proContinue(i); }, hex("#c8102e"), false); } else if (L.m == "ut") { int i = L.i; goMode("ULTIMATE FRANCHISE", [i] { utLoad(i); }, hex("#d97706"), false); } }
  else if (utTap(id)) {}
  else if (proTap(id)) {}
  else if (pracTap(id)) {}
  else if (id.rfind("nf:", 0) == 0) { pField = id[3] == '1'; std::string &v = pField ? pLast : pFirst; kShift = v.empty(); }
  else if (id.rfind("key:", 0) == 0) { std::string c = id.substr(4); bool two = nameFor == "pro"; std::string &v = two ? (pField ? pLast : pFirst) : pname; size_t mx = 14;
    if (c == "^") { double t = now(); if (kShift && t - kShiftT < 450) { kCaps = true; kShift = false; } else if (kCaps) { kCaps = false; kShift = false; } else kShift = !kShift; kShiftT = t; }
    else if (c == "<") { if (!v.empty()) v.pop_back(); if (v.empty() || v.back() == ' ') kShift = true; }
    else if (c == "_") { if (two && pField == 0 && !v.empty()) { pField = 1; kShift = pLast.empty(); } else if (!v.empty() && v.back() != ' ' && v.size() < mx) { v += ' '; kShift = true; } }
    else if (v.size() < mx) { v += kShift || kCaps ? (char)std::toupper(c[0]) : c[0]; kShift = false; }
    if (two) pname = trim(pFirst + " " + pLast); }
  else if (id == "rand") { std::string g = genName(); if (nameFor == "pro") { size_t sp = g.find(' '); pFirst = g.substr(0, sp); pLast = sp == std::string::npos ? "" : g.substr(sp + 1); pname = g; } else pname = g; }
  else if (id == "namego" && nameFor == "ut") { std::string nm = trim(pname); if (!nm.empty()) { pname = utPrevName; nameFor = "pro"; utNew(nameTarget, nm); } }
  else if (id == "namego" && nameFor == "pro" && mode == "pro") { if (!trim(pname).empty()) screen = "pronew"; }
  else if (id == "namecancel" && nameFor == "pro" && mode == "pro") screen = CR && CR->phase == "retired" ? "retired" : "proslots";
  else if (id == "namecancel" && nameFor == "ut") { pname = utPrevName; nameFor = "pro"; screen = "utslots"; }
  else if (id == "namecancel") screen = "modes";
  else if (id == "mode:quick") goMode("QUICK PLAY", [] { mode = "quick"; screen = "main"; }, hex("#2563eb"), false);
  else if (id.rfind("qp:", 0) == 0) { if (id == "qp:F") startGame(); }
  else if (id == "mode:practice") goMode("PRACTICE", [] { mode = "practice"; screen = "main"; }, hex("#ea580c"), false);
  else if (id == "set:autoPad") { settings.autoPad = !settings.autoPad; saveSettings(); }
  else if (id == "set:gAssist") { settings.gAssist = !settings.gAssist; saveSettings(); }
  else if (id == "set:rOff") { settings.rOff = g_rOff = !settings.rOff; saveSettings(); }
  else if (id == "set:rIce") { settings.rIce = g_rIce = !settings.rIce; saveSettings(); }
  else if (id == "set:rPen") { settings.rPen = g_rPen = !settings.rPen; saveSettings(); }
  else if (id == "set:music" || id == "set:sfx") {   // X on a slider: mute, or back to where it was
    static int prev[2] = {100, 100}; bool mu = id == "set:music"; int &pv = prev[mu ? 1 : 0], cv = mu ? settings.musV : settings.sfxV;
    if (cv > 0) { pv = cv; setVolume(mu, 0); } else { setVolume(mu, pv > 0 ? pv : 100); if (!mu) sfx(S_PASS, .8); } }
  else if (id == "set:shotB") { settings.shotB = !settings.shotB; QO.shotB = settings.shotB; saveSettings(); }
  else if (id == "set:camHigh") { extern bool g_camHigh; settings.camHigh = !settings.camHigh; g_camHigh = settings.camHigh; saveSettings(); }
  else if (id == "set:autoAim") { settings.autoAim = !settings.autoAim; QO.autoAim = settings.autoAim; saveSettings(); }
  else if (id == "nav:main" && screen == "result") { state = ST_MENU; screen = mode == "ut" && !utRet.empty() ? utRet : "main"; utRet.clear(); lockUntil = now() + 600;
    if (mode == "pro" && CR) screen = CR->phase == "retired" ? "retired" : CR->showTrade && CR->hasTrade ? "trade" : CR->need ? "office" : "main"; }
  else if (id == "nav:modes" && screen == "settings" && mode == "ut" && UT) screen = "main";   // Ultimate Franchise's Settings: back to the hub
  else if (id == "nav:modes" && screen != "settings") goMode("MAIN MENU", [] { state = ST_MENU; screen = "modes"; }, hex("#475569"), false);
  else if (id.rfind("nav:", 0) == 0) screen = id.substr(4);
}
// the name screen remembers what you'd typed for your player while you name a team
void utNameStart(int i) { nameFor = "ut"; nameTarget = i; utPrevName = pname; pname = ""; kShift = true; kCaps = false; screen = "name"; }
void proNameStart(int i) { nameTarget = i; nameFor = "pro"; pname = ""; pFirst.clear(); pLast.clear(); pField = 0; kShift = true; kCaps = false; screen = "name"; }

// ---------------------------------------------------------------- after a game
void afterGame(bool won, bool quit) {
  g_lastQuit = quit;
  if (quit) { if (mode == "ut") utAfter(false, true); state = ST_MENU; screen = "main"; return; }
  if (mode == "practice") { state = ST_MENU; screen = "main"; return; }
  int cash = mode == "ut" ? utAfter(won, false) : 0;
  rs = RSum(); rs.hn = SK->T[0].name; rs.an = SK->T[1].name; rs.hs = SK->T[0].score; rs.as = SK->T[1].score; rs.hsh = SK->T[0].sog; rs.ash = SK->T[1].sog;
  rs.cash = cash; rs.hasF = true; rs.f = SK->me; rs.np = std::min(4, SK->per); for (int t = 0; t < 2; t++) for (int k = 0; k < 4; k++) { rs.pg[t][k] = SK->pg[t][k]; rs.ps[t][k] = SK->ps[t][k]; }
  if (mode == "pro" && CR) { extern std::string g_simNote; rs.note = g_simNote; g_simNote.clear(); proAfterGame(won, !rs.note.empty()); rs.xp = proGainXP; }
  state = ST_RESULT; screen = mode == "pro" && CR ? "presult" : "result"; lockUntil = now() + 700;
}

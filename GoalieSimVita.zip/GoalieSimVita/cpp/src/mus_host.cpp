// CHL 2026 native - the soundtrack's decoder on the PC test build: ffmpeg does the work (the build has no sound card;
// the test mode mixes to a .wav to check the whole path)
#include "music.h"
#include <cstdio>
#include <cstdlib>
struct MDec { FILE *p; };
std::string plat_asset_dir() { const char *e = getenv("CHL_ASSETS"); return e ? std::string(e) + "/" : std::string("../assets/"); }
MDec *mdec_open(const std::string &path, int *rate, std::string *err) {
  FILE *t = fopen(path.c_str(), "rb"); if (!t) { if (err) *err = "MISSING: " + path; return nullptr; } fclose(t);
  std::string cmd = "ffmpeg -v quiet -i '" + path + "' -f s16le -ac 2 -ar 44100 - 2>/dev/null";
  FILE *p = popen(cmd.c_str(), "r"); if (!p) { if (err) *err = "NO FFMPEG"; return nullptr; }
  *rate = 44100; return new MDec{p};
}
int mdec_read(MDec *d, int16_t *out, int maxFrames) { size_t n = fread(out, 4, (size_t)maxFrames, d->p); return (int)n; }
void mdec_close(MDec *d) { if (d) { pclose(d->p); delete d; } }

// CHL 2026 native - league tables (data.cpp)
#pragma once
constexpr int NT = 32, NLEG = 20, NDRAFT = 32, NSHOOTS = 36;
// "AB|City|Name|division|jersey|stripe|skater:age:ovr,...|goalie:age:ovr,..."
extern const char *TD[NT];
extern const char *AHL_TD[NT];   // the AHL affiliates, same format; AHL_TD[i] is the farm team of TD[i]
struct LegendDef { const char *nm; char pos; int ov; };
extern const LegendDef UT_LEG[NLEG];
struct DraftDef { int pick; const char *team, *nm; int age, ov; };
extern const DraftDef DRAFT26[NDRAFT];
struct ShootDef { const char *nm; char h; };
extern const ShootDef SHOOTS[NSHOOTS];

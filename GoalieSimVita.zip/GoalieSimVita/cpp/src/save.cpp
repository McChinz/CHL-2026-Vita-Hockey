// CHL 2026 native - save files, in the legacy build's formats so nothing is lost moving over:
//   goalie4.json   {slots, hof, settings}   Be a Pro careers (kept as they are until that mode lands) + settings
//   chl_ut.json    {slots}                  Ultimate Franchise
//   chl_last.json  {m, i}                   the save you played last (CONTINUE on the main menu)
// On the first run the legacy build's files (ux0:data/GoalieSim/) are copied over; the legacy files are not touched.
#include "menu.h"
#include "ut.h"
#include "pro.h"

static J g_goalie4, g_last;
static std::string dataPath(const char *f) { return plat_data_dir() + f; }
static bool readOrImport(const char *f, std::string &out) {
  if (plat_read_file(dataPath(f), out) && !out.empty()) return true;
  if (plat_read_file(plat_legacy_dir() + f, out) && !out.empty()) { plat_write_file(dataPath(f), out); plat_log(std::string("imported legacy ") + f); return true; }
  return false;
}
void saveInit() {
  std::string s; bool ok = false;
  if (readOrImport("goalie4.json", s)) { g_goalie4 = J::parse(s, &ok); if (!ok || !g_goalie4.isObj()) g_goalie4 = J::obj(); } else g_goalie4 = J::obj();
  const J &st = g_goalie4("settings");
  if (st.isObj()) { settings.autoPad = st("autoPad").truthy(); settings.gAssist = !(st.has("gAssist") && st("gAssist").t == J::BOOL && !st("gAssist").b);
    settings.autoAim = !(st.has("autoAim") && st("autoAim").t == J::BOOL && !st("autoAim").b); settings.sfx = !(st.has("sfx") && st("sfx").t == J::BOOL && !st("sfx").b); settings.music = !(st.has("music") && st("music").t == J::BOOL && !st("music").b);
    settings.sfxV = st.has("sfxV") ? st("sfxV").i(100) : (settings.sfx ? 100 : 0); settings.musV = st.has("musV") ? st("musV").i(100) : (settings.music ? 100 : 0);
    setVolume(false, settings.sfxV, false); setVolume(true, settings.musV, false);
    settings.view3d = !(st.has("view3d") && st("view3d").t == J::BOOL && !st("view3d").b);
    settings.camHigh = st.has("camHigh") && st("camHigh").t == J::BOOL && st("camHigh").b;
    settings.shotB = st.has("shotB") && st("shotB").t == J::BOOL && st("shotB").b;
    settings.textures = !(st.has("textures") && st("textures").t == J::BOOL && !st("textures").b);
    settings.fpsUnlock = st("fpsUnlock").truthy(); settings.showFps = st("showFps").truthy();
    auto on = [&](const char *k) { return !(st.has(k) && st(k).t == J::BOOL && !st(k).b); }; settings.rOff = on("rOff"); settings.rIce = on("rIce"); settings.rPen = on("rPen"); }
  g_rOff = settings.rOff; g_rIce = settings.rIce; g_rPen = settings.rPen;
  extern bool g_view3d, g_camHigh, g_texOn; g_view3d = settings.view3d = true;   // 3D everywhere (the old top-down 2D view is retired) g_camHigh = settings.camHigh; g_texOn = settings.textures;
  { extern bool g_showFps; g_showFps = settings.showFps; g_paceN = settings.fpsUnlock ? 1 : 2; }
  QO.autoAim = settings.autoAim; QO.sfx = settings.sfx; QO.shotB = settings.shotB;
  if (readOrImport("chl_ut.json", s)) utLoadAll(s);
  if (plat_read_file(dataPath("chl_pro.json"), s) && !s.empty()) proLoadAll(s);
  if (readOrImport("chl_last.json", s)) { g_last = J::parse(s, &ok); if (!ok) g_last = J(); }
}
void saveSettings() {
  J st = J::obj(); st["autoPad"] = settings.autoPad; st["gAssist"] = settings.gAssist; st["autoAim"] = settings.autoAim; st["sfx"] = settings.sfx; st["music"] = settings.music; st["sfxV"] = settings.sfxV; st["musV"] = settings.musV; st["view3d"] = settings.view3d; st["camHigh"] = settings.camHigh; st["shotB"] = settings.shotB; st["textures"] = settings.textures; st["fpsUnlock"] = settings.fpsUnlock; st["showFps"] = settings.showFps; st["rOff"] = settings.rOff; st["rIce"] = settings.rIce; st["rPen"] = settings.rPen;
  g_goalie4["settings"] = st; if (!g_goalie4.has("slots")) { J a = J::arr(); a.push(J()); a.push(J()); a.push(J()); g_goalie4["slots"] = a; }
  if (!g_goalie4.has("hof")) { J h = J::obj(); h["careers"] = 0; h["best"] = 0; g_goalie4["hof"] = h; }
  plat_write_file(dataPath("goalie4.json"), g_goalie4.dump());
}
J &lastSave() { return g_last; }
void setLast(const std::string &m, int i) { g_last = J::obj(); g_last["m"] = m; g_last["i"] = i; plat_write_file(dataPath("chl_last.json"), g_last.dump()); }

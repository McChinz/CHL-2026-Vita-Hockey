// CHL 2026 native - the vitaGL renderer (the main Vita build). The 2D layer (menus, HUD, the classic view, text)
// arrives as coloured triangles and font glyphs and is drawn with an orthographic camera; the 3D view sends
// world-space triangles that the GPU transforms and depth-tests (plat_draw3d). 4x MSAA on everything.
// Needs ur0:data/libshacccg.suprx on the Vita (vitaGL's shader compiler); without it the game shows how to get it.
#include "platform.h"
#include "audio.h"
#include "canvas.h"
#include "vita_sys.h"
#include "font_atlas.h"
#include <vitaGL.h>
#include <psp2/kernel/processmgr.h>
#include <psp2/io/stat.h>
#include <zlib.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

extern "C" {
int _newlib_heap_size_user = 96 * 1024 * 1024;   // the rest of the memory is vitaGL's
unsigned int sceUserMainThreadStackSize = 1 * 1024 * 1024;
}

static GLuint g_font = 0;
static int g_mode = -1;                      // 0 = 2D (ortho, no depth), 1 = 3D
static std::vector<float> g_pos, g_col, g_uv;

static inline void unpack(uint32_t c, float *o) { o[0] = (c & 255) / 255.f; o[1] = ((c >> 8) & 255) / 255.f; o[2] = ((c >> 16) & 255) / 255.f; o[3] = (c >> 24) / 255.f; }

// ---- state: 2D (screen pixels, y down) or 3D (the game's clip matrix, depth buffer)
static void mode2D() {
  if (g_mode == 0) return; g_mode = 0;
  glDisable(GL_DEPTH_TEST); glDepthMask(GL_FALSE);
  glMatrixMode(GL_PROJECTION); glLoadIdentity();
  const float o[16] = {2.f / 960, 0, 0, 0, 0, -2.f / 544, 0, 0, 0, 0, -1, 0, -1, 1, 0, 1};
  glLoadMatrixf(o);
  glMatrixMode(GL_MODELVIEW); glLoadIdentity();
}
void plat_tris(const float *p, const uint32_t *c, int n, float ox, float oy, float k) {
  n -= n % 3; if (n <= 0) return;
  mode2D();
  g_pos.resize(n * 3); g_col.resize(n * 4);
  for (int i = 0; i < n; i++) { g_pos[i * 3] = p[i * 2] * k + ox; g_pos[i * 3 + 1] = p[i * 2 + 1] * k + oy; g_pos[i * 3 + 2] = 0; unpack(c[i], &g_col[i * 4]); }
  glDisable(GL_TEXTURE_2D); glDisableClientState(GL_TEXTURE_COORD_ARRAY);
  glEnableClientState(GL_VERTEX_ARRAY); glEnableClientState(GL_COLOR_ARRAY);
  glVertexPointer(3, GL_FLOAT, 0, g_pos.data()); glColorPointer(4, GL_FLOAT, 0, g_col.data());
  glDrawArrays(GL_TRIANGLES, 0, n);
}
void plat_glyphs(const float *g, int n, uint32_t col, float ox, float oy, float k) {
  if (!g_font || n <= 0) return;
  mode2D();
  g_pos.resize(n * 18); g_uv.resize(n * 12); g_col.resize(n * 24); float cc[4]; unpack(col, cc);
  for (int i = 0; i < n; i++, g += 7) {
    float x0 = g[0] * k + ox, y0 = g[1] * k + oy, s = g[6] * k, x1 = x0 + g[4] * s, y1 = y0 + g[5] * s;
    float u0 = g[2] / FONT_W, v0 = g[3] / FONT_H, u1 = (g[2] + g[4]) / FONT_W, v1 = (g[3] + g[5]) / FONT_H;
    const float P[18] = {x0, y0, 0, x1, y0, 0, x1, y1, 0, x0, y0, 0, x1, y1, 0, x0, y1, 0}, T[12] = {u0, v0, u1, v0, u1, v1, u0, v0, u1, v1, u0, v1};
    memcpy(&g_pos[i * 18], P, sizeof P); memcpy(&g_uv[i * 12], T, sizeof T);
    for (int j = 0; j < 6; j++) memcpy(&g_col[(i * 6 + j) * 4], cc, sizeof cc);
  }
  glEnable(GL_TEXTURE_2D); glBindTexture(GL_TEXTURE_2D, g_font);
  glEnableClientState(GL_VERTEX_ARRAY); glEnableClientState(GL_COLOR_ARRAY); glEnableClientState(GL_TEXTURE_COORD_ARRAY);
  glVertexPointer(3, GL_FLOAT, 0, g_pos.data()); glColorPointer(4, GL_FLOAT, 0, g_col.data()); glTexCoordPointer(2, GL_FLOAT, 0, g_uv.data());
  glDrawArrays(GL_TRIANGLES, 0, n * 6);
  glDisableClientState(GL_TEXTURE_COORD_ARRAY); glDisable(GL_TEXTURE_2D);
}
bool plat_gpu3d() { return true; }
void plat_draw3d(const float *m16, const V3c *v, int n, int mode) {
  n -= n % 3; if (n <= 0) return;
  g_mode = 1;
  glMatrixMode(GL_PROJECTION); glLoadMatrixf(m16); glMatrixMode(GL_MODELVIEW); glLoadIdentity();
  glEnable(GL_DEPTH_TEST); glDepthFunc(GL_LEQUAL); glDepthMask(mode == 0 ? GL_TRUE : GL_FALSE);
  g_pos.resize(n * 3); g_col.resize(n * 4);
  for (int i = 0; i < n; i++) { g_pos[i * 3] = v[i].x; g_pos[i * 3 + 1] = v[i].y; g_pos[i * 3 + 2] = v[i].z; unpack(v[i].c, &g_col[i * 4]); }
  glDisable(GL_TEXTURE_2D); glDisableClientState(GL_TEXTURE_COORD_ARRAY);
  glEnableClientState(GL_VERTEX_ARRAY); glEnableClientState(GL_COLOR_ARRAY);
  glVertexPointer(3, GL_FLOAT, 0, g_pos.data()); glColorPointer(4, GL_FLOAT, 0, g_col.data());
  glDrawArrays(GL_TRIANGLES, 0, n);
}

// ---- the font: built into the app as zlib-compressed alpha, inflated to white RGBA once
static void loadFont() {
  std::vector<unsigned char> a((size_t)FONT_W * FONT_H); uLongf len = (uLongf)a.size();
  if (uncompress(a.data(), &len, FONT_Z, FONT_Z_LEN) != Z_OK) return;
  std::vector<unsigned char> rgba(a.size() * 4);
  for (size_t i = 0; i < a.size(); i++) { rgba[i * 4] = rgba[i * 4 + 1] = rgba[i * 4 + 2] = 255; rgba[i * 4 + 3] = a[i]; }
  glGenTextures(1, &g_font); glBindTexture(GL_TEXTURE_2D, g_font);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, FONT_W, FONT_H, 0, GL_RGBA, GL_UNSIGNED_BYTE, rgba.data());
}

// ---- lifecycle
static bool fileThere(const char *p) { SceIoStat st; return sceIoGetstat(p, &st) >= 0; }
bool plat_init() {
  vita_sys_init();
  // vitaGL compiles its shaders with the system's shader compiler: without it, say how to get it and stop
  if (!fileThere("ur0:data/libshacccg.suprx") && !fileThere("ur0:data/external/libshacccg.suprx")) {
    FILE *f = fopen(DATA_DIR "/README_libshacccg.txt", "w");
    if (f) { fputs("CHL 2026 needs libshacccg.suprx (the Vita's shader compiler) in ur0:data/.\n"
                   "Install it once with the ShaRKF00D app (it extracts it from the PSM Runtime), then start the game again.\n", f); fclose(f); }
    plat_log("libshacccg.suprx missing - see README_libshacccg.txt");
  }
  vglInitExtended(0x800000, 960, 544, 0x1000000, SCE_GXM_MULTISAMPLE_4X);
  vglWaitVblankStart(GL_FALSE);
  glViewport(0, 0, 960, 544);
  glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glDisable(GL_CULL_FACE); glDisable(GL_LIGHTING);
  loadFont();
  return true;
}
void plat_shutdown() {
  vita_sys_fini();
  if (g_font) glDeleteTextures(1, &g_font);
  vglEnd();
  sceKernelExitProcess(0);
}
void plat_begin_frame(uint32_t clear) {
  float c[4]; unpack(clear, c); glClearColor(c[0], c[1], c[2], 1);
  glDepthMask(GL_TRUE); glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  g_mode = -1; mode2D();
}
void plat_end_frame() { vita_pace(); vglSwapBuffers(GL_FALSE); vita_paced(); }

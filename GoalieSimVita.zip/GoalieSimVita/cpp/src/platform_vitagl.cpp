// CHL 2026 native - the vitaGL renderer (the main Vita build). The 2D layer (menus, HUD, the classic view, text)
// arrives as coloured triangles and font glyphs and is drawn with an orthographic camera; the 3D view sends
// world-space triangles that the GPU transforms and depth-tests (plat_draw3d). 4x MSAA on everything.
// Needs ur0:data/libshacccg.suprx on the Vita (vitaGL's shader compiler); without it the game shows how to get it.
#include <map>
#include <algorithm>
#include "platform.h"
#include "audio.h"
#include "canvas.h"
#include "vita_sys.h"
#include "font_atlas.h"
#include <vitaGL.h>
#include <psp2/kernel/processmgr.h>
#include <psp2/io/stat.h>
#include <zlib.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

extern "C" {
int _newlib_heap_size_user = 96 * 1024 * 1024;   // the rest of the memory is vitaGL's
unsigned int sceUserMainThreadStackSize = 1 * 1024 * 1024;
}

static GLuint g_font = 0, g_tex3d[8] = {0};
static int g_mode = -1;                      // 0 = 2D (ortho, no depth), 1 = 3D
static std::vector<float> g_pos, g_col, g_uv;

static inline void unpack(uint32_t c, float *o) { o[0] = (c & 255) / 255.f; o[1] = ((c >> 8) & 255) / 255.f; o[2] = ((c >> 16) & 255) / 255.f; o[3] = (c >> 24) / 255.f; }

// ---- state: 2D (screen pixels, y down) or 3D (the game's clip matrix, depth buffer)
static void mode2D() {
  if (g_mode == 0) return; g_mode = 0;
  glDisable(GL_DEPTH_TEST); glDepthMask(GL_FALSE);
  glMatrixMode(GL_PROJECTION); glLoadIdentity();
  const float o[16] = {2.f / 960, 0, 0, 0, 0, -2.f / 544, 0, 0, 0, 0, -1, 0, -1, 1, 0, 1};
  glLoadMatrixf(o);
  glMatrixMode(GL_MODELVIEW); glLoadIdentity();
}
void plat_tris(const float *p, const uint32_t *c, int n, float ox, float oy, float k) {
  n -= n % 3; if (n <= 0) return;
  mode2D();
  g_pos.resize(n * 3); g_col.resize(n * 4);
  for (int i = 0; i < n; i++) { g_pos[i * 3] = p[i * 2] * k + ox; g_pos[i * 3 + 1] = p[i * 2 + 1] * k + oy; g_pos[i * 3 + 2] = 0; unpack(c[i], &g_col[i * 4]); }
  glDisable(GL_TEXTURE_2D); glDisableClientState(GL_TEXTURE_COORD_ARRAY);
  glEnableClientState(GL_VERTEX_ARRAY); glEnableClientState(GL_COLOR_ARRAY);
  for (int at = 0; at < n; at += 30000) { int cnt = std::min(30000, n - at);   // (16-bit draws: see plat_draw3d)
    glVertexPointer(3, GL_FLOAT, 0, g_pos.data() + at * 3); glColorPointer(4, GL_FLOAT, 0, g_col.data() + at * 4); glDrawArrays(GL_TRIANGLES, 0, cnt); }
}
void plat_glyphs(const float *g, int n, uint32_t col, float ox, float oy, float k) {
  if (!g_font || n <= 0) return;
  mode2D();
  g_pos.resize(n * 18); g_uv.resize(n * 12); g_col.resize(n * 24); float cc[4]; unpack(col, cc);
  for (int i = 0; i < n; i++, g += 7) {
    float x0 = g[0] * k + ox, y0 = g[1] * k + oy, s = g[6] * k, x1 = x0 + g[4] * s, y1 = y0 + g[5] * s;
    float u0 = g[2] / FONT_W, v0 = g[3] / FONT_H, u1 = (g[2] + g[4]) / FONT_W, v1 = (g[3] + g[5]) / FONT_H;
    const float P[18] = {x0, y0, 0, x1, y0, 0, x1, y1, 0, x0, y0, 0, x1, y1, 0, x0, y1, 0}, T[12] = {u0, v0, u1, v0, u1, v1, u0, v0, u1, v1, u0, v1};
    memcpy(&g_pos[i * 18], P, sizeof P); memcpy(&g_uv[i * 12], T, sizeof T);
    for (int j = 0; j < 6; j++) memcpy(&g_col[(i * 6 + j) * 4], cc, sizeof cc);
  }
  glEnable(GL_TEXTURE_2D); glBindTexture(GL_TEXTURE_2D, g_font);
  glEnableClientState(GL_VERTEX_ARRAY); glEnableClientState(GL_COLOR_ARRAY); glEnableClientState(GL_TEXTURE_COORD_ARRAY);
  glVertexPointer(3, GL_FLOAT, 0, g_pos.data()); glColorPointer(4, GL_FLOAT, 0, g_col.data()); glTexCoordPointer(2, GL_FLOAT, 0, g_uv.data());
  glDrawArrays(GL_TRIANGLES, 0, n * 6);
  glDisableClientState(GL_TEXTURE_COORD_ARRAY); glDisable(GL_TEXTURE_2D);
}
bool plat_gpu3d() { return true; }
void plat_tex(int slot, int w, int h, const unsigned char *rgba) {
  if (slot < 0 || slot >= 8 || !rgba) return;
  if (!g_tex3d[slot]) glGenTextures(1, &g_tex3d[slot]);
  glBindTexture(GL_TEXTURE_2D, g_tex3d[slot]);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, rgba);
}
// one draw of world-space triangles from ready arrays (positions, float colours, texture coordinates)
static void draw3dArrays(const float *m16, const float *pos, const float *col, const float *uv, int n, int mode, int tex) {
  g_mode = 1;
  glMatrixMode(GL_PROJECTION); glLoadMatrixf(m16); glMatrixMode(GL_MODELVIEW); glLoadIdentity();
  glEnable(GL_DEPTH_TEST); glDepthFunc(GL_LEQUAL); glDepthMask(mode == 0 ? GL_TRUE : GL_FALSE);
  bool tx = uv && tex >= 0 && tex < 8 && g_tex3d[tex];
  if (tx) { glEnable(GL_TEXTURE_2D); glBindTexture(GL_TEXTURE_2D, g_tex3d[tex]); glEnableClientState(GL_TEXTURE_COORD_ARRAY); }
  else { glDisable(GL_TEXTURE_2D); glDisableClientState(GL_TEXTURE_COORD_ARRAY); }
  glEnableClientState(GL_VERTEX_ARRAY); glEnableClientState(GL_COLOR_ARRAY);
#if defined(GL_MIN) && defined(GL_FUNC_ADD)
  if (mode == 3) glBlendEquation(GL_MIN);   // shadows: keep the darker, so overlapping shadows never add up
#endif
  // in pieces of at most 30000 vertices: vitaGL indexes a draw with 16 bits
  for (int at = 0; at < n; at += 30000) { int cnt = std::min(30000, n - at);
    glVertexPointer(3, GL_FLOAT, 0, pos + at * 3); glColorPointer(4, GL_FLOAT, 0, col + at * 4);
    if (tx) glTexCoordPointer(2, GL_FLOAT, 0, uv + at * 2);
    glDrawArrays(GL_TRIANGLES, 0, cnt); }
#if defined(GL_MIN) && defined(GL_FUNC_ADD)
  if (mode == 3) glBlendEquation(GL_FUNC_ADD);
#endif
  if (tx) { glDisableClientState(GL_TEXTURE_COORD_ARRAY); glDisable(GL_TEXTURE_2D); }
}
// colours unpacked through a table (no divides per vertex)
static float g_u8f[256]; static bool g_u8init = false;
static void convert(const V3c *v, int n, std::vector<float> &pos, std::vector<float> &col, std::vector<float> *uv) {
  if (!g_u8init) { for (int i = 0; i < 256; i++) g_u8f[i] = i / 255.f; g_u8init = true; }
  pos.resize(n * 3); col.resize(n * 4); if (uv) uv->resize(n * 2);
  float *P = pos.data(), *Cl = col.data(), *T = uv ? uv->data() : nullptr;
  for (int i = 0; i < n; i++) { const V3c &q = v[i]; P[0] = q.x; P[1] = q.y; P[2] = q.z; P += 3; uint32_t c = q.c;
    Cl[0] = g_u8f[c & 255]; Cl[1] = g_u8f[(c >> 8) & 255]; Cl[2] = g_u8f[(c >> 16) & 255]; Cl[3] = g_u8f[c >> 24]; Cl += 4;
    if (T) { T[0] = q.u; T[1] = q.v; T += 2; } }
}
void plat_draw3d(const float *m16, const V3c *v, int n, int mode, int tex) {
  n -= n % 3; if (n <= 0) return;
  bool tx = tex >= 0 && tex < 8 && g_tex3d[tex];
  convert(v, n, g_pos, g_col, tx ? &g_uv : nullptr);
  draw3dArrays(m16, g_pos.data(), g_col.data(), tx ? g_uv.data() : nullptr, n, mode, tex);
}
struct StaticArr { int n = -1; uint32_t ver = 0; const void *data = nullptr; unsigned used = 0; std::vector<float> pos, col, uv; };
static std::map<const void *, StaticArr> g_static; static unsigned g_staticFrame = 0;
// key: the cache (stable for the life of the game). Entries not drawn for ~10 s are freed, so this can never grow
void plat_draw3d_static(const float *m16, const void *key, const V3c *v, int n, int mode, int tex, uint32_t ver) {
  n -= n % 3; if (n <= 0) return;
  StaticArr &S = g_static[key]; S.used = g_staticFrame;
  if (S.n != n || S.ver != ver || S.data != (const void *)v) { S.n = n; S.ver = ver; S.data = v; convert(v, n, S.pos, S.col, &S.uv); }
  bool tx = tex >= 0 && tex < 8 && g_tex3d[tex];
  draw3dArrays(m16, S.pos.data(), S.col.data(), tx ? S.uv.data() : nullptr, n, mode, tex);
}
void plat_static_tick() {
  if (++g_staticFrame % 300) return;
  for (auto it = g_static.begin(); it != g_static.end();) { if (g_staticFrame - it->second.used > 600) it = g_static.erase(it); else ++it; }
}

// ---- the font: built into the app as zlib-compressed alpha, inflated to white RGBA once
static void loadFont() {
  std::vector<unsigned char> a((size_t)FONT_W * FONT_H); uLongf len = (uLongf)a.size();
  if (uncompress(a.data(), &len, FONT_Z, FONT_Z_LEN) != Z_OK) return;
  std::vector<unsigned char> rgba(a.size() * 4);
  for (size_t i = 0; i < a.size(); i++) { rgba[i * 4] = rgba[i * 4 + 1] = rgba[i * 4 + 2] = 255; rgba[i * 4 + 3] = a[i]; }
  glGenTextures(1, &g_font); glBindTexture(GL_TEXTURE_2D, g_font);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, FONT_W, FONT_H, 0, GL_RGBA, GL_UNSIGNED_BYTE, rgba.data());
}

// ---- lifecycle
static bool fileThere(const char *p) { SceIoStat st; return sceIoGetstat(p, &st) >= 0; }
bool plat_init() {
  vita_sys_init();
  // vitaGL compiles its shaders with the system's shader compiler: without it, say how to get it and stop
  if (!fileThere("ur0:data/libshacccg.suprx") && !fileThere("ur0:data/external/libshacccg.suprx")) {
    FILE *f = fopen(DATA_DIR "/README_libshacccg.txt", "w");
    if (f) { fputs("CHL 2026 needs libshacccg.suprx (the Vita's shader compiler) in ur0:data/.\n"
                   "Install it once with the ShaRKF00D app (it extracts it from the PSM Runtime), then start the game again.\n", f); fclose(f); }
    plat_log("libshacccg.suprx missing - see README_libshacccg.txt");
  }
  vglInitExtended(0x800000, 960, 544, 0x1000000, SCE_GXM_MULTISAMPLE_4X);
  vglWaitVblankStart(GL_TRUE);   // flips on the vertical blank: no tearing (the frame pacing below keeps a steady 30)
  glViewport(0, 0, 960, 544);
  glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glDisable(GL_CULL_FACE); glDisable(GL_LIGHTING);
  loadFont();
  return true;
}
void plat_shutdown() {
  vita_sys_fini();
  if (g_font) glDeleteTextures(1, &g_font);
  for (GLuint &t : g_tex3d) if (t) { glDeleteTextures(1, &t); t = 0; }

  sceKernelExitProcess(0);
}
void plat_begin_frame(uint32_t clear) {
  float c[4]; unpack(clear, c); glClearColor(c[0], c[1], c[2], 1);
  glDepthMask(GL_TRUE); glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  g_mode = -1; mode2D();
}
// vglSwapBuffers already waits for the next refresh (vsync), so pacing only waits ONE refresh here: waiting two
// and then the swap's own refresh made every frame last three refreshes - a hard cap of 20 FPS however fast the frame was
extern int g_paceN;
void plat_end_frame() { plat_static_tick(); vita_pace(g_paceN); vglSwapBuffers(GL_FALSE); vita_paced(); }

// CHL 2026 native - synthesized sounds (no sample files) and a small software mixer.
// The recipes are the same ones the web build and the JS Vita build use, at 22050 Hz mono.
#pragma once
#include <cstdint>

enum Snd { S_SLAP, S_WRIST, S_PASS, S_SAVE, S_SKATE, S_STOP, S_GRUNT1, S_GRUNT2, S_GRUNT3, S_HIT, S_POST, S_AMB, S_CHEER, S_BOO, S_COUNT };
// per-sound level (SND.gain in the web build)
static const float SND_GAIN[S_COUNT] = {1, .85f, .6f, .7f, .32f, .75f, .85f, .85f, .85f, .9f, .9f, 1, 1, 1};

// mixer (audio.cpp): any platform can drive it - the Vita from its audio thread
void au_synth_all();                                  // build every sound (call once, off the main thread if possible)
int au_play(int id, float vol, float rate, bool loop);
void au_set(int voice, float vol);
void au_stop(int voice);
void au_mix(int16_t *out, int n, int outRate);        // fill n mono samples at outRate
bool au_ready();

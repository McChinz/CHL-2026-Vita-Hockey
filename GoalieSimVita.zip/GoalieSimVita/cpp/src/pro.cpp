// CHL 2026 native - BE A PRO: the career logic (league, season, sims, injuries, trades, contracts, playoffs, the
// off-season) and the save files. Ported from the legacy build's career code: same formulas and odds.
#include "pro.h"
#include "apt.h"
#include "platform.h"
#include <algorithm>
#include <cstring>

std::unique_ptr<Career> CR; int proSlot = -1; std::string proMsg; int proGainXP = 0;
int proHofCareers = 0, proHofBest = 0;
const char *DIVN[4] = {"ATLANTIC", "METROPOLITAN", "CENTRAL", "PACIFIC"};
const char *ADIVN[4] = {"ATLANTIC", "NORTH", "CENTRAL", "PACIFIC"};
const char *RN[4] = {"FIRST ROUND", "SECOND ROUND", "CONFERENCE FINAL", "FINAL"};
static const char *INJ_T[8] = {"UPPER BODY", "LOWER BODY", "KNEE", "SHOULDER", "ANKLE", "HAND", "CONCUSSION", "GROIN"};
static const double INJ_P = .0032, BB_P = 1.1e-5, BB_ME = 5e-6;
static const int NTm = 32;
#define C (*CR)

static int confOf(int t) { return C.L[t].d < 2 ? 0 : 1; }
double infl() { return std::pow(1.025, C.season - 1); }
double market(int ov) { return .9 * std::exp((std::max(40, ov) - 50) * .061) * infl(); }
double capOf() { return C.cap * infl(); }
static int stv(const std::string &k) { const J *v = g_stats.get(k); return v ? v->i(50) : 50; }
int proOvr() { return ovOf(userRatings()); }
static void logS(const std::string &s) { C.log.insert(C.log.begin(), {s, C.season}); if (C.log.size() > 40) C.log.resize(40); C.newsN++; }
static std::string f2(double v) { return fixed(v, 2); }
static std::string tagQ(PP *q);
template <class T> static T pickOne(const std::vector<T> &v) { return v[(size_t)std::floor(rnd() * v.size())]; }
static std::vector<int> allTeams() { std::vector<int> v; for (int i = 0; i < NTm; i++) v.push_back(i); return v; }   // the NHL
static int lgOf(int t) { return t >= NA ? 1 : 0; }
static bool hasAHL() { return (int)C.L.size() == NALL; }
std::vector<int> lgTeams(int lg) { std::vector<int> v; for (int i = 0; i < NTm; i++) v.push_back(lg * NA + i); return v; }
int proLg() { return CR && C.me >= NA ? 1 : 0; }
std::string divName(int t) { const std::vector<PTeam> &LL = CR->L; int d = LL[(size_t)t].d & 3; return t >= NA ? ADIVN[d] : DIVN[d]; }
std::string teamFull(int t) { const PTeam &L = C.L[t]; return t >= NA ? L.n : L.city + " " + L.n; }
static std::string shortN(int t) { const std::string &n = C.L[t].n; if (t < NA) return n; size_t k = n.rfind(' '); return k == std::string::npos ? n : n.substr(k + 1); }

// ---------------------------------------------------------------- players
static PP *mine() { for (auto &q : C.P) if (q->me) return q.get(); return nullptr; }
PP *youMe() { return CR ? mine() : nullptr; }
int ovQ(PP *q) {
  if (!q) return 50;
  if (q->g) return (int)gStats(&q->gsrc).ovr;
  if (q->me) return proOvr();
  if (q->ocP != q->src.p || q->ocA != q->src.a || q->ocAr != (int)q->src.ar) { q->ocP = q->src.p; q->ocA = q->src.a; q->ocAr = (int)q->src.ar; q->ocV = ovSk(&q->src); }
  return q->ocV;
}
int potOv(const PP *q) { return q->g ? (int)jround(clamp(32 + q->pot * 7, 40, 99)) : (int)jround(clamp(50 + (q->pot - 3.5) / 6.5 * 49, 40, 99)); }
static double av2(const PP *q) { return (q->src.p + q->src.a) / 2; }
static double wgt(const PP *q) { return 3 + std::pow(av2(q), 1.5); }
std::vector<PP *> teamS(int t, bool healthy, bool core) { std::vector<PP *> v; for (auto &q : C.P) if (!q->g && q->t == t && (!healthy || !q->inj) && (!core || !q->isCu)) v.push_back(q.get()); return v; }
std::vector<PP *> teamG(int t) { std::vector<PP *> v; for (auto &q : C.P) if (q->g && q->t == t) v.push_back(q.get()); return v; }
static std::vector<PP *> actP(int t) { return teamS(t, true); }
// the rest of the league only keeps goals and assists, so their other numbers are filled in from those, their ice time
// (by how good they are) and a steady per-player hash (no jitter between looks), sized to their team's games
void proLeagueRanks(int rk[10], int &n) {
  static long long key = -1; static int R[10]; static int N = 0;
  const PSeason &S = C.st; long long k = (((long long)C.season * 1000 + C.day) * 1000 + S.gp) * 100 + C.me;
  if (k != key) { key = k;
    int lg = lgOf(C.me); std::vector<PP *> ps; for (auto &q : C.P) if (!q->g && !q->me && q->t >= 0 && lgOf(q->t) == lg) ps.push_back(q.get());
    std::vector<double> av; for (PP *q : ps) av.push_back(av2(q)); std::vector<double> so = av; std::sort(so.begin(), so.end());
    double gpU = std::max(1, S.gp), mine[10] = {(double)S.g, (double)S.a, (double)S.pm, (double)S.sh, (double)S.pass, (double)S.hits, (double)S.pim, S.toi / gpU, (double)S.blk, S.sh ? (double)S.sog / S.sh : 0};
    int cnt[10] = {0};
    for (size_t i = 0; i < ps.size(); i++) { PP *q = ps[i]; const PTeam &T = C.L[q->t]; double gp = std::min(T.w + T.l, std::max(0, C.day));
      double pr = so.size() > 1 ? (double)(std::lower_bound(so.begin(), so.end(), av[i]) - so.begin()) / (so.size() - 1) : .5;
      uint64_t h = 1469598103934665603ULL; for (char c : q->nm()) h = (h ^ (unsigned char)c) * 1099511628211ULL; h ^= (uint64_t)C.season * 0x9E3779B97F4A7C15ULL;
      auto u = [&]() { h += 0x9E3779B97F4A7C15ULL; uint64_t z = h; z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL; z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL; return (double)((z ^ (z >> 31)) >> 11) / 9007199254740992.0; };
      double toi = 11.5 + 8 * pr + (u() - .5) * 2.5, shots = q->gl * (5.5 + 3 * u()) + gp * (.6 + 1.6 * pr) * (.7 + .6 * u()), sog = q->gl + std::max(0.0, shots - q->gl) * (.42 + .2 * u());
      double pass = q->as * 3.5 + gp * (3 + 4 * pr) * (.7 + .6 * u()), hits = gp * (.3 + 1.9 * u()), u6 = u(), pim = 2 * std::round(gp * (.05 + .45 * u6 * u6)), blk = gp * (.15 + 1.1 * u());
      double pm = std::round((T.gf - T.ga) * toi / 60 + (q->gl + q->as) * .15 - gp * .05 + (u() - .5) * std::sqrt(gp) * 2.5);
      double v[10] = {(double)q->gl, (double)q->as, pm, std::round(shots), std::round(pass), std::round(hits), pim, gp > 0 ? toi : 0, std::round(blk), shots >= 1 ? sog / shots : 0};
      for (int s = 0; s < 10; s++) if (v[s] > mine[s] + 1e-9) cnt[s]++; }
    for (int s = 0; s < 10; s++) R[s] = cnt[s] + 1; N = (int)ps.size() + 1; }
  for (int s = 0; s < 10; s++) rk[s] = R[s]; n = N;
}
static std::vector<PP *> coreP(int t) { return teamS(t, false, true); }
static PP *byName(const std::string &n, int t = -99, int g = -1) { for (auto &q : C.P) if (q->nm() == n && (t == -99 || q->t == t) && (g < 0 || q->g == (g == 1))) return q.get(); return nullptr; }
double payroll(int t) { double s = 0; for (auto &q : C.P) if (q->t == t && !(q->isCu && !q->g)) s += q->sal; return s; }
static std::string uname() { std::string n; int k = 0; do { n = genName(); k++; } while (C.used.count(n) && k < 50); C.used.insert(n); return n; }
static std::string tagQ(PP *q) { return q->nm() + (q->g ? " (G)" : "") + " (" + istr(ovQ(q)) + ")"; }
static std::string nmTag(PP *q) { return q->nm() + (q->g ? " (G)" : ""); }
static double gR(const PP *q) { return q->gsrc.r; }
static double gRel(const PP *q) { return clamp(gR(q) - (C.gmA[q->t >= NA ? 1 : 0] - 5), .3, 9.9); }
static void setContract(PP *q, bool rookie, bool fa) {
  if (rookie) { q->sal = .95 * infl(); q->cy = 3; }
  else if (fa) { q->sal = .85 * infl(); q->cy = 1; }
  else { q->sal = market(ovQ(q)) * rand(.6, 1.4); q->cy = 1 + (int)std::floor(rnd() * 5); }
}
static double ageCurve(int a) { return a <= 20 ? .6 : a <= 28 ? .6 + .4 * (a - 20) / 8 : a <= 30 ? 1 : std::max(.55, 1 - (a - 30) * .04); }
static int starAge() { return rnd() < .7 ? 27 + (int)std::floor(rnd() * 4) : 24 + (int)std::floor(rnd() * 10); }
enum MkK { MK_NORM, MK_ROOKIE, MK_CALLUP, MK_FA };
static PP *mkS(int t, MkK o) {
  double q = t >= 0 ? C.L[t].q : 4.5, p, a, pot; int age;
  if (o == MK_ROOKIE) { age = 19 + (int)std::floor(rnd() * 3); p = rand(1.6, 4.4); a = rand(1.6, 4.4); pot = clamp(rand(4, 9.4) + (rnd() < .1 ? 1 : 0), 4, 10); }
  else if (o == MK_CALLUP) { age = 20 + (int)std::floor(rnd() * 8); pot = rand(4.6, 8.4); double k = clamp(ageCurve(age) * .92, .5, .95); p = clamp(pot * k + rand(-.3, .3), 2, 7); a = clamp(pot * k + rand(-.3, .3), 2, 7); }
  else if (o == MK_FA) { age = 24 + (int)std::floor(rnd() * 8); pot = rand(5.4, 7.2); p = clamp(pot + rand(-.4, .3), 1, 10); a = clamp(pot + rand(-.4, .3), 1, 10); }
  else { age = 19 + (int)std::floor(rnd() * 16); double u = rnd(); pot = u < .22 ? rand(4.6, 6.2) : u < .3 && age <= 24 ? rand(8.7, 9.8) : clamp(rand(6.6, 8.5) + (q - 4.5) * .12, 5, 9.2); double k = ageCurve(age);
    p = clamp(pot * k + rand(-.4, .4), 1, 9.8); a = clamp(pot * k + rand(-.4, .4), 1, 9.8); }
  if (t >= NA && o != MK_ROOKIE) {   // the AHL: minor-league depth (call-ups come from the ECHL)
    double c = o == MK_NORM ? rand(4.3, 6.0) : rand(3.6, 5.3); p = clamp(c + rand(-.3, .3), 1, 10); a = clamp(c + rand(-.3, .3), 1, 10);
    pot = std::max(p, a) + (age <= 23 ? rand(.4, 2.4) : rand(0, .4)); }
  auto s = std::make_unique<PP>(); PP *r = s.get(); r->src.nm = uname(); r->t = t; r->age = age; r->src.p = p; r->src.a = a; r->pot = pot;
  ensureTraits(r->src, t >= 0 ? C.L[t].pref : -1); setContract(r, o == MK_ROOKIE, o == MK_FA || o == MK_CALLUP);
  C.P.push_back(std::move(s)); return r;
}
static PP *mkG(int t, MkK o) {
  double q = t >= 0 ? C.L[t].q : 4.5, r, pot; int age;
  if (o == MK_ROOKIE) { age = 19 + (int)std::floor(rnd() * 3); pot = clamp(rand(4, 9.6), 4, 10); r = clamp(pot * ageCurve(age) + rand(-.5, .3), 1, 6); }
  else if (o == MK_FA) { age = 26 + (int)std::floor(rnd() * 8); r = rand(4.6, 6); pot = r; }
  else { age = rnd() < .35 ? starAge() : 19 + (int)std::floor(rnd() * 17); double u = rnd(); pot = u < .15 ? rand(8, 9.6) : u < .35 ? rand(3.6, 5.6) : rand(5.8, 7.8) + (q - 4.5) * .1; r = clamp(pot * ageCurve(age) + rand(-.4, .4), .5, 9.7); }
  if (t >= NA && o != MK_ROOKIE) { r = rand(3.0, 4.8); pot = r + (age <= 24 ? rand(.3, 2) : 0); }
  auto s = std::make_unique<PP>(); PP *g = s.get(); g->g = true; g->gsrc.nm = uname(); g->t = t; g->age = age; g->gsrc.r = r; g->pot = pot;
  ensureGTraits(g->gsrc); setContract(g, o == MK_ROOKIE, o == MK_FA);
  C.P.push_back(std::move(s)); return g;
}
static std::unique_ptr<PP> drop(PP *q) {
  for (size_t i = 0; i < C.P.size(); i++) if (C.P[i].get() == q) { std::unique_ptr<PP> o = std::move(C.P[i]); C.P.erase(C.P.begin() + i); return o; }
  return nullptr;
}
static void recalc(int t) {
  PTeam &L = C.L[t]; std::vector<PP *> S = actP(t), GG = teamG(t);
  for (PP *q : S) if (q->me) { q->src.p = (uAttr("spow") + uAttr("wpow")) / 2; q->src.a = (uAttr("sacc") + uAttr("slacc") + uAttr("pass") * 2) / 4; q->age = C.age; }
  std::sort(S.begin(), S.end(), [](PP *a, PP *b) { return b->src.p + b->src.a < a->src.p + a->src.a; });
  if (S.size() > (size_t)PRO_ROS) S.resize(PRO_ROS);
  double av = 0; for (PP *q : S) av += av2(q); av = av / std::max<size_t>(1, S.size()) - std::max(0, PRO_ROS - (int)S.size()) * .25;
  std::string key = istr(C.day) + "|" + istr(C.season);
  if (C.lmT != key) { C.lmT = key; double a[2] = {0, 0}, g[2] = {0, 0}; int n[2] = {0, 0}, m[2] = {0, 0};
    for (auto &q : C.P) { int l = q->t >= NA ? 1 : 0; if (q->g) { g[l] += gR(q.get()); m[l]++; } else { a[l] += av2(q.get()); n[l]++; } }
    for (int l = 0; l < 2; l++) { C.lmA[l] = n[l] ? a[l] / n[l] : C.lmA[0]; C.gmA[l] = m[l] ? g[l] / m[l] : C.gmA[0]; } C.lm = C.lmA[0]; C.gmn = C.gmA[0]; }
  int lg = t >= NA ? 1 : 0;
  std::vector<double> gs; for (PP *q : GG) gs.push_back(gR(q)); std::sort(gs.rbegin(), gs.rend());
  double gk = gs.size() > 1 ? gs[0] * .72 + gs[1] * .28 : gs.empty() ? 3 : gs[0];
  L.s = clamp(4.5 + (av - C.lmA[lg]) * 1.9, .2, 9.5); L.g = clamp(gk - (C.gmA[lg] - 5), .3, 9.9);
}
static void recalcAll() { C.lmT.clear(); for (int t = 0; t < (int)C.L.size(); t++) recalc(t); }
static void setStars(bool announce) {
  int n = 0;
  for (int t = 0; t < (int)C.L.size(); t++) { std::vector<PP *> S = teamS(t); std::vector<std::pair<int, PP *>> sc; for (PP *q : S) sc.push_back({ovQ(q), q});
    std::stable_sort(sc.begin(), sc.end(), [](const std::pair<int, PP *> &a, const std::pair<int, PP *> &b) { return a.first > b.first; });
    for (auto &e : sc) { bool was = e.second->star; e.second->star = e.first >= 85; e.second->src.star = e.second->star;
      if (announce && t < NA && e.second->star && !was && n < 2) { n++; logS(e.second->nm() + " is now a star for the " + C.L[t].n); } } }
}
// form: how a player's season is going against what his rating says
static struct { std::string k; double tw[NALL]; } FC;
static double form(PP *q) {
  if (q->t < 0 || q->me) return 0;
  if (q->g) { if (q->sa < 300) return 0; return clamp(((double)q->sv / q->sa - (.911 + (gRel(q) - 5) * .0072)) * 250, -7, 7); }
  PTeam &L = C.L[q->t]; if (L.w + L.l < 6) return 0;
  std::string key = istr(C.season) + "|" + istr(C.day) + "|" + istr(C.P.size());
  if (FC.k != key) { FC.k = key; for (double &v : FC.tw) v = 0; for (auto &x : C.P) if (!x->g && x->t >= 0 && x->t < NALL) FC.tw[x->t] += wgt(x.get()); }
  return clamp((q->gl - L.gf * wgt(q) / std::max(1.0, FC.tw[q->t])) * 1.1, -10, 10);
}
static double eff(PP *q) { return ovQ(q) + form(q) * .5; }

// ---------------------------------------------------------------- goalies and the games around the league
static PP *pickStarter(int t) {
  std::vector<PP *> G = teamG(t); std::sort(G.begin(), G.end(), [](PP *a, PP *b) { return ovQ(a) > ovQ(b); });
  if (G.size() < 2) return G.empty() ? nullptr : G[0];
  double p = clamp(.6 + (ovQ(G[0]) - ovQ(G[1])) * .018, .55, .8); return rnd() < p ? G[0] : G[1];
}
static void setStarters() { PP *h = pickStarter(C.me), *a = pickStarter(C.opp); C.sgH = h ? h->nm() : ""; C.sgA = a ? a->nm() : ""; }
PP *homeG() { PP *g = byName(C.sgH, C.me, 1); if (g) return g; auto G = teamG(C.me); return G.empty() ? nullptr : G[0]; }
PP *awayG() { PP *g = byName(C.sgA, C.opp, 1); if (g) return g; auto G = teamG(C.opp); return G.empty() ? nullptr : G[0]; }
static double rt(int i) { return C.L[i].s * .6 + C.L[i].g * .4; }
struct GRes { int ga, gb, w; PP *GA, *GB; };
static GRes simGameFull(int a, int b, PP *GA = nullptr, PP *GB = nullptr) {
  PTeam &A = C.L[a], &B = C.L[b]; if (!GA) GA = pickStarter(a); if (!GB) GB = pickStarter(b);
  double ag = GA ? gRel(GA) : A.g, bg = GB ? gRel(GB) : B.g;
  int ga = poisson(clamp(2.5 + (A.s - 4.5) * .22 - (bg - 5) * .2, .8, 5.5)), gb = poisson(clamp(2.5 + (B.s - 4.5) * .22 - (ag - 5) * .2, .8, 5.5));
  if (ga == gb) { if (rnd() < 1 / (1 + std::exp(-(rt(a) - rt(b)) * .4))) ga++; else gb++; }
  return {ga, gb, ga > gb ? a : b, GA, GB};
}
static void gLine(PP *G, int ag) { if (!G) return; int sh = std::max(ag + 3, (int)jround(rand(22, 34))); G->sa += sh; G->sv += sh - ag; G->gp++; }
static void wl(int w, int l) { PTeam &A = C.L[w], &B = C.L[l]; A.w++; B.l++; A.sk = (A.sk > 0 ? A.sk : 0) + 1; B.sk = (B.sk < 0 ? B.sk : 0) - 1; }
static void scoreFor(int t, int n, PP *ex = nullptr) {
  std::vector<PP *> ps; for (PP *q : actP(t)) if (q != ex) ps.push_back(q); if (ps.empty()) return;
  std::vector<double> w; double tot = 0; for (PP *q : ps) { w.push_back(wgt(q)); tot += w.back(); }
  for (int k = 0; k < n; k++) { double r = rnd() * tot; size_t i = 0; while (i < ps.size() - 1 && (r -= w[i]) > 0) i++; ps[i]->gl++;
    for (double ap : {.88, .62}) if (rnd() < ap && ps.size() > 2) { size_t j; do { j = (size_t)std::floor(rnd() * ps.size()); } while (j == i); ps[j]->as++; } }
}
// ---------------------------------------------------------------- injuries and call-ups
static int injLen() { double r = rnd(); return r < .55 ? 1 + (int)std::floor(rnd() * 4) : r < .85 ? 5 + (int)std::floor(rnd() * 8) : r < .97 ? 13 + (int)std::floor(rnd() * 13) : 26 + (int)std::floor(rnd() * 25); }
// you change teams inside the organization (or get traded inside the AHL): the alert, the schedule, the season line
static std::vector<int> makeSched(); static void pickOpp();
static bool alive(const PP *q) { for (auto &x : C.P) if (x.get() == q) return true; return false; }
static int g_pendUp = -1; static std::string g_pendFor;   // an NHL injury wants you: applied once the day is done
static void userMoved(int from, int to, const std::string &title, const std::string &why, bool quiet = false) {
  PP *Y = mine(); C.me = to; C.mvG = 0; if (Y && lgOf(from) != lgOf(to)) { Y->gl = Y->as = 0; }
  C.lmT.clear(); recalc(from); recalc(to); C.hasTreq = false; C.offers.clear();
  if (C.phase == "reg") { C.sched = makeSched(); pickOpp(); }
  if (to < NA && from >= NA) { C.calls++; if (!C.debut) { C.debut = C.age; logS("NHL DEBUT: " + C.nm + " gets the call from the " + C.L[to].n + " at age " + istr(C.age)); } }
  if (quiet) return;
  logS("YOU: " + title + " - " + teamFull(from) + " to the " + teamFull(to));
  C.hasTrade = true; C.showTrade = true; C.trade = PTrade(); C.trade.from = from; C.trade.to = to; C.trade.why = why; C.trade.title = title;
}
static PP *ahlFill(int a, const std::string &forNm) { PP *s = mkS(a, MK_CALLUP); s->isCu = true; s->cu = forNm; return s; }
static PP *callUp(int t, const std::string &forNm, bool perm) {
  if (t < NA && !perm && hasAHL()) {   // the NHL: the farm team sends up its best healthy player (maybe you)
    int a = t + NA; PP *best = nullptr, *Y = mine(); for (PP *q : coreP(a)) if (!q->inj && !q->me && (!best || eff(q) > eff(best))) best = q;
    bool you = Y && Y->t == a && !Y->inj && !Y->isCu && C.phase == "reg" && g_pendUp < 0 && C.mvG >= 8 && readiness() >= callBar() - 6 && (!best || proOvr() >= ovQ(best) - 3 || rnd() < .35);
    if (you) { g_pendUp = t; g_pendFor = forNm; return Y; }
    if (best) { best->t = t; best->isCu = true; best->cu = forNm; best->home = a; ahlFill(a, best->nm()); return best; }
  }
  PP *s = mkS(t, MK_CALLUP); s->isCu = !perm; s->cu = perm ? "" : forNm; if (perm) s->pot = clamp(s->pot + rand(0, 1.6), 4, 9.6); return s;
}
// a call-up becomes a regular: his AHL stand-in stays on the farm for good
static void makePerm(PP *q) {
  if (q->home >= 0) { for (auto &x : C.P) if (x->t == q->home && x->isCu && x->cu == q->nm()) { x->isCu = false; x->cu.clear(); } }
  q->isCu = false; q->cu.clear(); q->home = -1;
}
static void returnHome(PP *q, bool quiet = false) {
  int h = q->home; if (h < 0) { if (!q->me) drop(q); return; }
  for (auto &x : C.P) if (x->t == h && x->isCu && x->cu == q->nm()) { drop(x.get()); break; }
  int from = q->t; q->t = h; q->isCu = false; q->cu.clear(); q->home = -1;
  if (q->me) userMoved(from, h, "SENT DOWN", "The injured regular is back, so the " + C.L[from].n + " send you back to the " + C.L[h].n + ". Keep producing.", quiet);
}
static void sendDown(int t, const std::string &forNm) {
  for (auto &q : C.P) if (q->t == t && q->isCu && q->cu == forNm) { PP *p = q.get();
    if (p->me && p->home >= 0 && !p->inj && readiness() >= callBar() - 1) {   // you played your way onto the team: the weakest regular goes down instead
      int h = p->home; PP *w = nullptr; for (PP *x : coreP(t)) if (!x->me && !x->star && (!w || eff(x) < eff(w))) w = x;
      for (auto &x : C.P) if (x->t == h && x->isCu && x->cu == p->nm()) { drop(x.get()); break; }   // a regular takes your old AHL spot
      p->isCu = false; p->cu.clear(); p->home = -1; C.mvG = 0; if (w) w->t = h;
      C.orgMsg = "You stuck: the " + C.L[t].n + " kept you after the injured regular came back.";
      logS("YOU: " + C.nm + " plays his way onto the " + C.L[t].n + (w ? " - " + w->nm() + " goes down to the " + C.L[h].n : ""));
      C.hasTrade = true; C.showTrade = true; C.trade = PTrade(); C.trade.from = h; C.trade.to = t; C.trade.title = "YOU MADE THE TEAM"; C.trade.why = "The injured regular is back, but you are staying. " + (w ? w->nm() + " goes down to the " + C.L[h].n + " instead." : std::string());
      return; }
    if (p->home >= 0) returnHome(p); else if (!p->me) drop(p); return; }
}
static void injure(PP *q) {
  q->inj = injLen(); q->it = INJ_T[(int)std::floor(rnd() * 8)];
  q->src.p = clamp(q->src.p - rand(.02, .1), 1, 10); q->src.a = clamp(q->src.a - rand(.02, .1), 1, 10);
  PP *cu = callUp(q->t, q->nm(), false);
  if (ovQ(q) >= 84 || q->t == C.me) logS("INJURY: " + q->nm() + " (" + C.L[q->t].ab + ") - " + q->it + ", out " + istr(q->inj) + (q->inj == 1 ? " game. " : " games. ") + cu->nm() + " called up");
}
static void careerEnd(PP *q) {
  int t = q->t; std::string nm = q->nm();
  if (q->g) { drop(q); PP *g = mkG(t, MK_FA); logS("CAREER OVER: " + nm + " (G, " + C.L[t].ab + ") breaks his back. " + g->nm() + " comes up from the minors"); return; }
  PP *cu = nullptr; for (auto &x : C.P) if (x->t == t && x->isCu && x->cu == nm) cu = x.get();
  drop(q);
  if (cu) { makePerm(cu); if (!cu->me) cu->pot = clamp(cu->pot + rand(0, 1.6), 4, 9.6); else C.orgMsg = "With " + nm + " gone for good, the " + C.L[t].n + " keep you up."; }
  PP *nn = cu ? cu : callUp(t, "", true);
  C.L[t].needT++;
  logS("CAREER OVER: " + nm + " (" + C.L[t].ab + ") breaks his back. " + nn->nm() + " gets his shot");
}
static void teamGameDone(int t) {
  std::vector<std::string> back; for (auto &q : C.P) if (!q->g && q->t == t && q->inj > 0 && !q->me) { q->inj--; if (q->inj <= 0) { q->inj = 0; q->it.clear(); back.push_back(q->nm()); } }
  for (auto &n : back) sendDown(t, n);
  std::vector<PP *> hl; for (auto &q : C.P) if (!q->g && q->t == t && !q->inj && !q->me) hl.push_back(q.get());
  for (PP *q : hl) { if (rnd() < BB_P) { careerEnd(q); continue; } if (rnd() < INJ_P) injure(q); }
  for (PP *g : teamG(t)) if (!g->me && rnd() < BB_P * .5) careerEnd(g);
}
static void healAll() {
  for (auto &q : C.P) if (q->inj && !q->me) { q->inj = 0; q->it.clear(); }
  PP *Y = mine(); if (Y) { Y->inj = 0; Y->it.clear(); }
  std::vector<PP *> cu; for (auto &q : C.P) if (q->isCu) cu.push_back(q.get());
  for (PP *q : cu) { if (!alive(q) || !q->isCu) continue; if (q->home >= 0) returnHome(q, true); else if (!q->me) drop(q); }
}
// the gear shop: every piece has an upside and (mostly) a downside
const std::vector<GearCat> GEARF = {
  {"curve", "CURVE", {{"NORMAL", 0, "", 1, "A neutral blade. No surprises."}, {"CURVED", 350, "sacc:3,hand:2,deke:1,slacc:-2,spow:-1", 1, "Big hook: picks corners and dangles, but clappers wobble."},
    {"STIFF", 350, "spow:4,wpow:2,slacc:1,hand:-2,pass:-1", 1, "Heavy flex: bombs from the point, hard to cradle a pass."},
    {"WRIST CURVE", 400, "wpow:4,sacc:1,spow:-3,slacc:-1", 1, "Mid-heel pocket: a heavy wrister, a weak clapper."},
    {"PLAYMAKER", 400, "pass:4,deke:2,hand:1,sacc:-2,wpow:-2,slacc:-1", 1, "Open toe: saucers and dangles. You'll shoot less - and worse."}}},
  {"len", "LENGTH", {{"SHORT", 250, "hand:3,deke:2,check:-1,spow:-2", 1, "Tight to the body: quick hands, less leverage."}, {"NORMAL", 0, "", 1, "Chin height. The standard."},
    {"LONG", 250, "spow:2,check:2,pass:1,hand:-2,deke:-2", 1, "Reach and leverage, slower in tight."}}},
  {"shaft", "SHAFT", {{"STANDARD", 0, "", 1, "A composite one-piece."}, {"HOLLOWED", 450, "sacc:3,slacc:2,pass:1,spow:-3,wpow:-2", 1, "Scooped out and light: more touch, less snap."},
    {"REINFORCED", 450, "spow:3,wpow:2,check:1,sacc:-2,hand:-1", 1.05, "Extra wraps: hammers it, but it's a club in tight."}}},
  {"helm", "HELMET", {{"STANDARD", 0, "", 1, "The basic shell."}, {"PRO SHELL", 400, "fstam:-1", .7, "30% fewer injuries. A little heavier."},
    {"CARBON LITE", 650, "fstam:2,edge:1", 1.15, "Featherweight: more gas, a bit less protection."}, {"ELITE CAGE", 1100, "fstam:1", .6, "40% fewer injuries and still light."},
    {"FIBERGLASS", 550, "poise:1,fstam:-1", .8, "Tough shell, solid in traffic. 20% fewer injuries."},
    {"NO VISOR", 300, "pass:1,hand:1,poise:1", 1.25, "Old school: you see everything. So do the sticks."}}},
  {"skate", "SKATES", {{"STANDARD", 0, "", 1, "Off-the-rack boots."}, {"SPEED", 450, "skate:3,edge:-1", 1, "Long, flat blade: straight-line speed."},
    {"AGILITY", 450, "edge:3,skate:-1", 1, "Rockered blade: tight turns and quick stops."}, {"ELITE", 1400, "skate:2,edge:2,fstam:1", 1, "The best boots money can buy."},
    {"PADDED", 500, "poise:2,skate:-1", .85, "Extra foam and a hard toe cap. Blocks shots, costs a step."},
    {"LIGHT", 550, "skate:2,fstam:1,poise:-1", 1.1, "Paper-thin boot: quick and fresh, nothing between you and a puck."}}},
  {"chest", "CHEST", {{"STANDARD", 0, "", 1, "Shoulder pads off the shelf."}, {"LIGHTWEIGHT", 450, "fstam:2,edge:1", 1.15, "Barely there: more gas, more bruises."},
    {"ARMORED", 600, "check:2,poise:2,skate:-1", .8, "Hard caps: lay the hits and take them. 20% fewer injuries."},
    {"HYBRID FLEX", 950, "edge:1,fstam:1,poise:1", .9, "Moves with you and still protects. 10% fewer injuries."}}}};
static std::vector<std::pair<std::string, int>> parseFx(const char *fx) {
  std::vector<std::pair<std::string, int>> o; std::string s = fx; size_t i = 0;
  while (i < s.size()) { size_t c = s.find(':', i), e = s.find(',', i); if (c == std::string::npos) break; if (e == std::string::npos) e = s.size(); o.push_back({s.substr(i, c - i), atoi(s.substr(c + 1, e - c - 1).c_str())}); i = e + 1; }
  return o;
}
std::string fxTxt(const char *fx) { std::string o; for (auto &p : parseFx(fx)) { if (!o.empty()) o += "   "; o += (p.second > 0 ? "+" : "") + istr(p.second) + " " + FNICE(p.first); } return o; }
static int gearIdx(const GearCat &g) { auto it = C.gearEq.find(g.k); if (it != C.gearEq.end()) return it->second; for (size_t i = 0; i < g.it.size(); i++) if (!g.it[i].c) return (int)i; return 0; }
static struct { int ver = -1; Career *c = nullptr; std::map<std::string, double> m; double inj = 1; } GP; static int gearVer = 0;
static void gearBuild() { if (GP.ver == gearVer && GP.c == CR.get()) return; GP.ver = gearVer; GP.c = CR.get(); GP.m.clear(); GP.inj = 1;
  for (auto &g : GEARF) { const GearIt &it = g.it[gearIdx(g)]; for (auto &p : parseFx(it.fx)) GP.m[p.first] += p.second; GP.inj *= it.inj; } }
double gearPts(const std::string &k) { if (mode != "pro" || !CR) return 0; gearBuild(); auto it = GP.m.find(k); return (it == GP.m.end() ? 0 : it->second) + homePts(k); }   // gear + the apartment's nudges
void gearChanged() { gearVer++; }
double gearInj() { if (!CR) return 1; gearBuild(); return GP.inj; }
void gearTap(const std::string &cat, int i) {
  for (auto &g : GEARF) if (g.k == cat) { if (i < 0 || i >= (int)g.it.size()) return; const GearIt &it = g.it[i]; std::string key = cat + ":" + istr(i);
    bool own = !it.c || C.gearOwn.count(key);
    if (own) { C.gearEq[cat] = i; gearVer++; proSave(); return; }
    if (C.money >= it.c) { C.money -= it.c; C.gearOwn.insert(key); C.gearEq[cat] = i; gearVer++; proSave(); } return; }
}
// your odds of getting hurt in a game: the base rate, your gear, your age, how physical your last ten games were
InjRisk injRisk() {
  InjRisk r; r.base = INJ_P; r.gear = gearInj(); int a = CR ? C.age : 20; r.age = a <= 24 ? .9 : a <= 29 ? 1 : 1 + (a - 29) * .07;
  int n = 0, h = 0; if (CR) for (int i = (int)C.hist.size() - 1; i >= 0 && n < 10; i--) if (C.hist[i].ln && !C.hist[i].dnp) { n++; h += C.hist[i].hits; }
  r.hitsPG = n ? (double)h / n : 0; r.hits = clamp(.85 + .06 * r.hitsPG, .85, 1.6); r.games = n;
  r.p = r.base * r.gear * r.age * r.hits; return r;
}
// you: forwards can get hurt; anybody can suffer the one that ends it all
static void userInjuryRoll() {
  PP *Y = mine(); if (!Y || C.phase == "retired") return;
  if (rnd() < BB_ME * gearInj()) { C.cei = true; logS("CAREER OVER: " + C.nm + " suffers a broken back"); return; }
  if (Y->inj) return;
  if (rnd() < injRisk().p) {
    Y->inj = injLen(); Y->it = INJ_T[(int)std::floor(rnd() * 8)];
    std::vector<std::string> ks(FKEYS, FKEYS + 13); shuffle(ks); ks.resize(2);
    for (auto &k : ks) g_stats[k] = std::max(40, stv(k) - 1);
    callUp(C.me, Y->nm(), false);
    C.injMsg = Y->it + " INJURY - OUT " + istr(Y->inj) + (Y->inj == 1 ? " GAME" : " GAMES") + "  (" + FNICE(ks[0]) + " -1, " + FNICE(ks[1]) + " -1)";
    logS("INJURY: " + C.nm + " (" + C.L[C.me].ab + ") - " + Y->it + ", out " + istr(Y->inj) + (Y->inj == 1 ? " game" : " games"));
  }
}
static void userHealTick() { PP *Y = mine(); if (Y && Y->inj > 0) { Y->inj--; if (Y->inj <= 0) { Y->inj = 0; Y->it.clear(); sendDown(C.me, Y->nm()); C.injMsg = "YOU ARE BACK IN THE LINEUP"; } } }
bool userHurt() { PP *Y = CR ? mine() : nullptr; return Y && Y->inj > 0; }

// ---------------------------------------------------------------- schedule and calendar
static std::vector<int> makeSched() {
  int me = C.me, d = C.L[me].d; std::vector<int> others, div, rest, L; for (int i : lgTeams(lgOf(me))) if (i != me) { others.push_back(i); if (C.L[i].d == d) div.push_back(i); else if (confOf(i) == confOf(me)) rest.push_back(i); }
  for (int k = 0; k < 2; k++) L.insert(L.end(), others.begin(), others.end()); for (int k = 0; k < 2; k++) L.insert(L.end(), div.begin(), div.end());
  shuffle(rest); while ((int)L.size() < PRO_GAMES) L.push_back(rest[L.size() % rest.size()]);
  shuffle(L); L.resize(PRO_GAMES);
  for (int pass = 0; pass < 3; pass++) for (size_t i = 1; i < L.size(); i++) if (L[i] == L[i - 1]) {
    for (size_t j = 0; j < L.size(); j++) { int jp = j ? L[j - 1] : -1, jn = j + 1 < L.size() ? L[j + 1] : -1, inx = i + 1 < L.size() ? L[i + 1] : -1;
      if (j != i && L[j] != L[i - 1] && L[j] != inx && L[i] != jp && L[i] != jn) { std::swap(L[i], L[j]); break; } } }
  return L;
}
static std::vector<int> makeCal() {
  std::vector<int> cal; int g = 0; static const int NW[5] = {4, 5, 5, 5, 6};
  while (g < PRO_GAMES) { int n = std::min(PRO_GAMES - g, NW[(int)std::floor(rnd() * 5)]); std::vector<int> days = {0, 1, 2, 3, 4, 5, 6}; shuffle(days);
    std::set<int> on(days.begin(), days.begin() + n); if (cal.empty() && !on.count(0)) { on.erase(days[0]); on.insert(0); }
    for (int d = 0; d < 7; d++) { if (on.count(d) && g < PRO_GAMES) cal.push_back(g++); else cal.push_back(-1); } }
  while (!cal.empty() && cal.back() < 0) cal.pop_back();
  return cal;
}
std::string calDate(int i) {
  static const char *MN[9] = {"OCT", "NOV", "DEC", "JAN", "FEB", "MAR", "APR", "MAY", "JUN"}; static const int ML[9] = {31, 30, 31, 31, 28, 31, 30, 31, 30};
  int d = 6 + (int)jround(i * 1.55), m = 0; while (m < 8 && d >= ML[m]) { d -= ML[m]; m++; } return std::string(MN[m]) + " " + istr(d + 1);
}
bool offDay() { return CR && C.phase == "reg" && !C.cal.empty() && C.ci < (int)C.cal.size() && C.cal[C.ci] < 0; }
static void ensureWeek();
static void officeDay();
static void calStep() { C.ci = std::min((int)C.cal.size() - 1, C.ci + 1); ensureWeek(); officeDay(); }
static void skipOffDays() { if (C.phase != "reg") return; int k = 0; while (offDay() && k++ < 10) calStep(); }
// weekly goals: three a week, scaled to how good you are
struct WGDef { const char *k, *txt; double a, b; };
static const WGDef WG_F[6] = {{"g", "Score %n goal%s", .35, .5}, {"a", "Get %n assist%s", .45, .5}, {"p", "Record %n point%s", .8, 1}, {"sog", "Put %n shot%s on goal", 2.4, 2}, {"w", "Win %n game%s", .5, 0}, {"hits", "Throw %n hit%s", 1.4, 1}};
static void ensureWeek() {
  if (C.cal.empty()) return; int wk = C.ci / 7;
  if (C.wk.w == wk && C.wk.season == C.season) return;
  int n = 0; for (int i = wk * 7; i < wk * 7 + 7 && i < (int)C.cal.size(); i++) if (C.cal[i] >= 0) n++;
  C.wk = PWeek(); C.wk.w = wk; C.wk.season = C.season; C.wk.games = n; if (!n) return;
  double t = clamp((proOvr() - 50) / 49.0, 0, 1); std::vector<int> pool = {0, 1, 2, 3, 4, 5}; shuffle(pool);
  for (int i = 0; i < 3; i++) { const WGDef &p = WG_F[pool[i]]; PGoal g; g.k = p.k; g.tg = std::max(1, (int)std::ceil((p.a + p.b * t) * n * 1.05));
    std::string s = p.txt; size_t at = s.find("%n"); s.replace(at, 2, istr(g.tg)); at = s.find("%s"); s.replace(at, 2, g.tg > 1 ? "s" : "");
    g.txt = s; g.xp = (int)jround(rand(22, 36)); g.cash = (int)jround(rand(20, 40)); C.wk.goals.push_back(g); }
}
static GoalRes g_gr;
const GoalRes &proGoalRes() { return g_gr; }
int weekAllBonus() { return proLg() ? 100 : 250; }          // all three weekly goals: AHL / NHL
int yearAllBonus() { return (int)jround(gamePay() * 100); }   // every season goal
static void yearProgress();
static void weekProgress(const PHist &h, bool won, bool played) {
  yearProgress();
  if (C.phase != "reg") return; std::vector<std::string> msgs;
  for (auto &g : C.wk.goals) { if (g.done) continue; if (!played && g.k != "w") continue;
    int d = g.k == "g" ? h.g : g.k == "a" ? h.a : g.k == "p" ? h.g + h.a : g.k == "sog" ? h.sog : g.k == "hits" ? h.hits : g.k == "w" ? (won ? 1 : 0) : 0;
    g.pr += d; if (g.pr >= g.tg) { g.done = true; C.xp += g.xp; proGainXP += g.xp; C.money += g.cash; msgs.push_back(upper(g.txt) + "  +" + istr(g.xp) + " XP +$" + istr(g.cash)); } }
  if (!msgs.empty()) { std::string s; for (auto &m : msgs) s += (s.empty() ? "" : "  |  ") + m; C.wkMsg = "WEEKLY GOAL DONE: " + s; logS("Weekly goal complete: " + s); }
  bool all = !C.wk.goals.empty(); for (auto &g : C.wk.goals) if (!g.done) all = false;
  if (all && !C.wk.allPaid) { C.wk.allPaid = true; int c = weekAllBonus(); C.money += c; C.xp += 60; proGainXP += 60; g_gr.allW = c;
    C.wkMsg = "EVERY WEEKLY GOAL DONE!  BONUS +$" + istr(c) + " +60 XP"; logS(C.nm + " clears every weekly goal: a $" + istr(c) + " bonus"); }
}

// the season's bonus goals (the Goals app): three targets plus making the playoffs, paid like a contract bonus when you
// hit them. Sized to your pay (about 25 games' worth each, half again with performance bonuses in your deal) so the
// apartment stays a grind.
static const WGDef YG_F[4] = {{"g", "Score %n goal%s", 6, 22}, {"p", "Record %n point%s", 14, 46}, {"gp", "Play %n game%s", 50, 18}, {"hits", "Throw %n hit%s", 45, 55}};
int yearBonusCash(const PGoal &g) { return (int)jround(g.cash * (C.perfB ? 1.5 : 1)); }
void ensureYear() {
  if (!CR || (C.yr.season == C.season && !C.yr.goals.empty())) return;
  C.yr = PWeek(); C.yr.season = C.season; double t = clamp((proOvr() - 50) / 49.0, 0, 1); int pay = gamePay();
  std::vector<int> pool = {0, 1, 2, 3}; shuffle(pool);
  for (int i = 0; i < 3; i++) { const WGDef &p = YG_F[pool[i]]; PGoal g; g.k = p.k; g.tg = std::max(1, (int)jround(p.a + p.b * t)); if (g.k == "gp") g.tg = std::min(g.tg, PRO_GAMES - 6);
    std::string s = p.txt; size_t at = s.find("%n"); s.replace(at, 2, istr(g.tg)); at = s.find("%s"); s.replace(at, 2, g.tg > 1 ? "s" : "");
    g.txt = s; g.xp = (int)jround(rand(120, 200)); g.cash = (int)jround(pay * rand(55, 70)); C.yr.goals.push_back(g); }
  PGoal po; po.k = "po"; po.tg = 1; po.txt = "Make the playoffs"; po.xp = 150; po.cash = (int)jround(pay * 45); C.yr.goals.push_back(po);
}
static void yearProgress() {
  ensureYear(); std::vector<std::string> msgs; const PSeason &S = C.st;
  bool inPo = false; if (C.phase == "po") for (auto &rd : C.br) for (auto &sr : rd) if (sr.a == C.me || sr.b == C.me) inPo = true;
  for (auto &g : C.yr.goals) { if (g.done) continue;
    g.pr = g.k == "g" ? S.g : g.k == "p" ? S.g + S.a : g.k == "gp" ? S.gp : g.k == "hits" ? S.hits : g.k == "po" ? (inPo ? 1 : 0) : 0;
    if (g.pr >= g.tg) { g.done = true; int c = yearBonusCash(g); C.money += c; C.xp += g.xp; proGainXP += g.xp; msgs.push_back(upper(g.txt) + "  +$" + istr(c)); } }
  if (!msgs.empty()) { std::string s; for (auto &m : msgs) s += (s.empty() ? "" : "  |  ") + m; C.wkMsg = "SEASON BONUS: " + s; logS(C.nm + " earns a season bonus: " + s); }
  bool all = !C.yr.goals.empty(); for (auto &g : C.yr.goals) if (!g.done) all = false;
  if (all && !C.yr.allPaid) { C.yr.allPaid = true; int c = yearAllBonus(); C.money += c; C.xp += 250; proGainXP += 250; g_gr.allY = c;
    C.wkMsg = "EVERY SEASON GOAL DONE!  BONUS +$" + fmtN(c) + " +250 XP"; logS(C.nm + " clears every season goal: a $" + fmtN(c) + " bonus"); }
}
// the skill bars on the post-game screen: every rating's level + progress, before the game and now
static const char *SKK[] = {"skate", "edge", "sacc", "wpow", "slacc", "spow", "bha", "pass", "hand", "deke", "fo", "check", "poise", "fstam"};
static std::map<std::string, double> g_skSnap;
static double skLv(const std::string &k) { auto it = C.sxp.find(k); return g_stats(k).i(50) + (it == C.sxp.end() ? 0 : clamp(it->second, 0, .999)); }
void proSkillSnap() { g_skSnap.clear(); if (!CR) return; for (auto k : SKK) g_skSnap[k] = skLv(k);
  ensureYear(); g_gr = GoalRes(); for (auto &g : C.wk.goals) g_gr.preW.push_back(g.pr); for (auto &g : C.yr.goals) g_gr.preY.push_back(g.pr); g_gr.wk = C.wk; g_gr.yr = C.yr; }
std::vector<SkillGain> proSkillGains() {
  std::vector<SkillGain> o; if (!CR) return o;
  for (auto k : SKK) { auto it = g_skSnap.find(k); if (it == g_skSnap.end()) continue; double b = skLv(k); if (b - it->second > .0005) o.push_back({k, it->second, b}); }
  std::sort(o.begin(), o.end(), [](const SkillGain &a, const SkillGain &b) { return a.b - a.a > b.b - b.a; }); return o;
}
// training on an off day: spend cash, grow two to four ratings
static const char *TRN[4] = {"SKATING", "SHOOTING", "PLAYMAKING", "PHYSICAL"};
static const std::vector<std::vector<std::string>> TRK = {{"skate", "edge"}, {"sacc", "wpow", "slacc", "spow"}, {"pass", "hand", "deke", "fo"}, {"check", "poise", "fstam"}};
int trainCost() { return (int)jround(25 + std::max(0, proOvr() - 50) * 1.6); }
bool canTrain() { return offDay(); }

// ---------------------------------------------------------------- your ratings: XP upgrades and growth from play
bool proInGame() { return CR && mode == "pro"; }
void award(int n) { if (!proInGame()) return; C.xp += n; proGainXP += n; }
std::string xpTag(const std::string &s, int n) { return proInGame() && n ? s + "  +" + istr(n) + " XP" : s; }
void fillStat(const std::string &k, double a) {
  if (!proInGame()) return; int v = stv(k); if (v >= 99) return;
  double lvB = 1 + (v - 50) * 9.0 / 49; double &x = C.sxp[k]; x += a * std::max(.2, 1 - (lvB - 1) / 11.5);
  while (x >= 1 && v < 99) { x -= 1; v++; g_stats[k] = v; if (SK) pushFeed("UP: " + FNICE(k) + " +1  (" + istr(v) + ")", "#ffd54a"); }
  if (v >= 99) x = 0;
}
int proCostN(const std::string &k, int n, int *m) { int c = 0, v = stv(k), mm = 0; for (int i = 0; i < n && v < 99; i++) { c += (int)jround(27 * (1 + (v - 50) * 9.0 / 49)); v++; mm++; } if (m) *m = mm; return c; }
void proUpgrade(const std::string &k, int n) { int m; int c = proCostN(k, n, &m); if (m > 0 && C.xp >= c) { C.xp -= c; g_stats[k] = stv(k) + m; C.sxp[k] = 0; proSave(); } }
void proDoTrain(int i) {
  if (!canTrain() || i < 0 || i > 3) return; int c = trainCost(); if (C.money < c) return;
  C.money -= c; double per = .7 / TRK[i].size() + .15; std::string up;
  for (auto &k : TRK[i]) { int b = stv(k); fillStat(k, per); if (stv(k) > b) up += "  " + FNICE(k) + " +1"; }
  proMsg = "TRAINED " + std::string(TRN[i]) + "  -$" + istr(c) + up; calStep(); proSave();
}
// perks: bought with XP, upgraded to silver and gold, equipped in the slots your overall opens
int proUserTier(const PerkDef &pk) { Ratings r = userRatings(); return pkTierOf(pk, [&](const std::string &k) { return r.get(k); }); }
int pkUpCost(const PerkDef &pk, int next) { return (int)jround(pk.c * std::pow(1.5, next - 1) / 10) * 10; }
int pkMine(const std::string &id) { int i = perkIndex(id); if (i < 0) return 0; auto it = C.perkLv.find(id); int lv = it == C.perkLv.end() ? 1 : it->second; return std::min(lv, proUserTier(PERKS[i])); }
static bool owns(const std::string &id) { return std::find(C.perkOwn.begin(), C.perkOwn.end(), id) != C.perkOwn.end(); }
void pkBuy(const std::string &id) { int i = perkIndex(id); if (i < 0 || owns(id) || C.xp < PERKS[i].c) return; C.xp -= PERKS[i].c; C.perkOwn.push_back(id); C.perkLv[id] = 1; proSave(); }
void pkUp(const std::string &id) { int i = perkIndex(id); if (i < 0 || !owns(id)) return; int nx = C.perkLv[id] + 1, c = pkUpCost(PERKS[i], nx);
  if (nx <= 3 && C.xp >= c && proUserTier(PERKS[i]) >= nx) { C.xp -= c; C.perkLv[id] = nx; proSave(); } }
void pkEquip(const std::string &id) {
  auto it = std::find(C.perkEq.begin(), C.perkEq.end(), id);
  if (it != C.perkEq.end()) C.perkEq.erase(it);
  else { int i = perkIndex(id); if (i >= 0 && owns(id) && proUserTier(PERKS[i]) > 0) { int n = pkSlots(proOvr()); if (n) { if ((int)C.perkEq.size() < n) C.perkEq.push_back(id); else C.perkEq[n - 1] = id; } } }
  proSave();
}
std::vector<PerkE> proUserPerks() {
  std::vector<PerkE> o; if (!proInGame()) return o; int n = pkSlots(proOvr());
  for (int k = 0; k < (int)C.perkEq.size() && k < n; k++) { int i = perkIndex(C.perkEq[k]); if (i >= 0 && proUserTier(PERKS[i]) > 0) o.push_back({i, pkMine(C.perkEq[k])}); }
  return o;
}

// ---------------------------------------------------------------- AI rosters and trades
static double evalTeam(int t, std::vector<PP *> S, std::vector<PP *> GS, double *payOut = nullptr) {
  PTeam &L = C.L[t]; std::sort(S.begin(), S.end(), [](PP *a, PP *b) { return eff(b) < eff(a); }); std::sort(GS.begin(), GS.end(), [](PP *a, PP *b) { return eff(b) < eff(a); });
  static const double LW[9] = {1.3, 1.3, 1.3, 1, 1, 1, .7, .7, .7};
  double off = 0, pay = 0; for (int i = 0; i < PRO_ROS; i++) { PP *q = i < (int)S.size() ? S[i] : nullptr; off += (q ? eff(q) : 64.0) * LW[i]; pay += q ? q->sal : .85 * infl(); }
  double g0 = GS.size() > 0 ? eff(GS[0]) : 63, g1 = GS.size() > 1 ? eff(GS[1]) : 63; pay += (GS.size() > 0 ? GS[0]->sal : .85 * infl()) + (GS.size() > 1 ? GS[1]->sal : .85 * infl());
  double u = off * 5 / PRO_ROS + (g0 * .75 + g1 * .25) * 1.9;
  if (L.build) { for (int i = 0; i < PRO_ROS && i < (int)S.size(); i++) if (S[i]->age <= 24) u += std::max(0, potOv(S[i]) - ovQ(S[i])) * .25; for (PP *g : GS) if (g->age <= 24) u += std::max(0, potOv(g) - ovQ(g)) * .25; }
  double cap = capOf(); u += pay > cap ? -(pay - cap) * 1.2 : (cap - pay) * (L.build ? .14 : .05);
  if (payOut) *payOut = pay; return u;
}
static double keepVal(PP *q) { return q->me ? 1e9 : eff(q) + (q->age <= 23 ? std::max(0, potOv(q) - ovQ(q)) * (q->g ? .2 : .6) : 0); }
static std::vector<std::unique_ptr<PP>> *g_FA = nullptr;
static void toFA(PP *q) { std::unique_ptr<PP> o = drop(q); if (g_FA && o && ovQ(o.get()) >= 60) { o->t = -1; g_FA->push_back(std::move(o)); } }
static void fixRoster(int t, bool noFill = false) {
  std::vector<PP *> S = coreP(t); std::sort(S.begin(), S.end(), [](PP *a, PP *b) { return keepVal(b) < keepVal(a); });
  bool farm = t < NA && hasAHL();
  for (size_t i = PRO_ROS; i < S.size(); i++) { if (farm && S[i]->age <= 26 && !S[i]->me) S[i]->t = t + NA; else toFA(S[i]); }
  if (!noFill) for (int k = std::min((int)S.size(), PRO_ROS); k < PRO_ROS; k++) mkS(t, MK_FA);
  std::vector<PP *> G = teamG(t); std::sort(G.begin(), G.end(), [](PP *a, PP *b) { return keepVal(b) < keepVal(a); });
  for (size_t i = PRO_NG; i < G.size(); i++) { if (farm && G[i]->age <= 27) G[i]->t = t + NA; else toFA(G[i]); }
  if (!noFill) for (int k = (int)G.size(); k < PRO_NG; k++) mkG(t, MK_FA);
}
static bool tryTrade(int fix = -1) {
  int a = fix >= 0 ? fix : (int)std::floor(rnd() * NTm), b; do { b = (int)std::floor(rnd() * NTm); } while (b == a);
  auto ok = [](PP *q) { return !q->me && !q->inj && !q->isCu; };
  std::vector<PP *> SA = coreP(a), SB = coreP(b), GA = teamG(a), GB = teamG(b), la, lb;
  for (PP *q : SA) if (ok(q)) la.push_back(q); for (PP *q : GA) if (ok(q)) la.push_back(q);
  for (PP *q : SB) if (ok(q)) lb.push_back(q); for (PP *q : GB) if (ok(q)) lb.push_back(q);
  if (la.empty() || lb.empty()) return false;
  auto over = [](PP *q) { return q->sal - market(std::max(40, (int)eff(q))); };
  PP *x1 = pickOne(la), *x2 = pickOne(la), *X = over(x1) >= over(x2) ? x1 : x2;
  std::vector<PP *> lbp; for (PP *q : lb) if (q->g == X->g) lbp.push_back(q); if (lbp.empty()) lbp = lb;
  PP *y1 = pickOne(lbp), *y2 = pickOne(lbp), *Y = -over(y1) >= -over(y2) ? y1 : y2;
  if (X->g != Y->g) return false;   // goalie for goalie, skater for skater: rosters stay 9 + 2
  double sa0 = evalTeam(a, SA, GA), sb0 = evalTeam(b, SB, GB);
  auto swp = [](std::vector<PP *> l, PP *out, PP *in) { l.erase(std::remove(l.begin(), l.end(), out), l.end()); l.push_back(in); return l; };
  std::vector<PP *> nSA = SA, nSB = SB, nGA = GA, nGB = GB;
  if (!X->g) { nSA = swp(SA, X, Y); nSB = swp(SB, Y, X); } else { nGA = swp(GA, X, Y); nGB = swp(GB, Y, X); }
  double sa1 = evalTeam(a, nSA, nGA), sb1 = evalTeam(b, nSB, nGB), cap = capOf(), need = fix >= 0 ? -1 : 1;
  if (sa1 - sa0 < need || sb1 - sb0 < 1) return false;
  double pa = payroll(a) - X->sal + Y->sal, pb = payroll(b) - Y->sal + X->sal;
  if (!(pa <= cap || pa <= payroll(a)) || !(pb <= cap || pb <= payroll(b))) return false;
  std::string tx = tagQ(X), ty = tagQ(Y);
  X->t = b; Y->t = a; fixRoster(a); fixRoster(b);
  logS("TRADE: " + C.L[a].n + " send " + tx + " to the " + C.L[b].n + " for " + ty);
  return true;
}
static void squeeze() {
  for (int t = 0; t < NTm; t++) { double cap = capOf(), p = payroll(t); if (p <= cap) continue;
    double sum = 0; std::vector<PP *> o; for (auto &q : C.P) if (q->t == t && !q->me && !q->isCu) { o.push_back(q.get()); sum += q->sal; }
    double f = clamp((cap - (p - sum)) / sum, .8, 1); for (PP *q : o) q->sal *= f; }
}
// team quality (the depth players they sign): by strength, inside each league
static void rankQ() {
  for (int lg = 0; lg < 1 + (hasAHL() ? 1 : 0); lg++) { std::vector<int> rk = lgTeams(lg); std::sort(rk.begin(), rk.end(), [](int a, int b) { return C.L[b].s + C.L[b].g < C.L[a].s + C.L[a].g; });
    for (int i = 0; i < NTm; i++) { C.L[rk[i]].q = 9 - i * 8.5 / (NTm - 1); if (!lg) C.L[rk[i]].build = i >= NTm * .6; } }
}
// the AHL: the 32 farm teams and their real rosters (also added to careers saved before the AHL existed)
static void buildAHL(bool after) {
  if ((int)C.L.size() != NTm || (int)ADP.size() != NTm) return;
  for (auto &T : ADP) { PTeam L; L.n = T.n; L.ab = T.ab; L.city = T.city; L.d = T.d; L.pref = rnd() < .85 ? 1 + (int)std::floor(rnd() * 5) : 0; C.L.push_back(L); }
  for (int i = 0; i < NTm; i++) { int t = NA + i; const TeamDef &T = ADP[i];
    for (auto &r : T.S) { if (after && C.used.count(r.nm)) { mkS(t, MK_NORM); continue; } auto s = std::make_unique<PP>(); PP *q = s.get(); double b = 3.5 + (r.ov - 50) / 49.0 * 6.5;
      q->src.nm = r.nm; q->t = t; q->age = r.age; q->src.p = b + rand(-.25, .25); q->src.a = b + rand(-.25, .25); q->real = true; C.used.insert(r.nm);
      ensureTraits(q->src, C.L[t].pref); fitS(q->src, r.ov); double cur = av2(q);
      q->pot = r.age <= 25 ? clamp(cur + (26 - r.age) * rand(.12, .34) + (r.age <= 21 ? rand(.2, 1.1) : 0), cur, 10) : cur + rand(0, .15);
      C.P.push_back(std::move(s)); q->sal = .8 * infl() * rand(1, 1.2); q->cy = 1 + (int)std::floor(rnd() * 3); }
    for (auto &r : T.G) { if (after && C.used.count(r.nm)) { mkG(t, MK_NORM); continue; } auto s = std::make_unique<PP>(); PP *g = s.get(); g->g = true; g->gsrc.nm = r.nm; g->t = t; g->age = r.age; g->gsrc.r = (r.ov - 34) / 7.0; g->real = true; C.used.insert(r.nm);
      ensureGTraits(g->gsrc); fitG(g->gsrc, r.ov); g->pot = r.age <= 25 ? clamp(g->gsrc.r + (26 - r.age) * rand(.1, .28), g->gsrc.r, 9.9) : g->gsrc.r + rand(0, .1);
      C.P.push_back(std::move(s)); g->sal = .8 * infl(); g->cy = 1 + (int)std::floor(rnd() * 3); } }
  if (after) { setStars(false); recalcAll(); rankQ(); }
}
static void buildLeague() {
  C.L.clear(); C.P.clear(); C.used.clear(); C.log.clear();
  for (auto &T : TDP) { PTeam L; L.n = T.n; L.ab = T.ab; L.city = T.city; L.d = T.d; L.pref = rnd() < .85 ? 1 + (int)std::floor(rnd() * 5) : 0; C.L.push_back(L); }
  for (int t = 0; t < (int)TDP.size(); t++) {
    for (auto &r : TDP[t].S) { auto s = std::make_unique<PP>(); PP *q = s.get(); double b = 3.5 + (r.ov - 50) / 49.0 * 6.5;
      q->src.nm = r.nm; q->t = t; q->age = r.age; q->src.p = b + rand(-.25, .25); q->src.a = b + rand(-.25, .25); q->real = true; C.used.insert(r.nm);
      ensureTraits(q->src, C.L[t].pref); fitS(q->src, r.ov); double cur = av2(q);
      q->pot = r.age <= 26 ? clamp(cur + (27 - r.age) * rand(.1, .32), cur, 10) : cur + rand(0, .15);
      C.P.push_back(std::move(s)); setContract(q, false, false); if (r.age <= 21) { q->sal = .95 * infl() * rand(1, 1.1); q->cy = 1 + (int)std::floor(rnd() * 3); } }
    for (auto &r : TDP[t].G) { auto s = std::make_unique<PP>(); PP *g = s.get(); g->g = true; g->gsrc.nm = r.nm; g->t = t; g->age = r.age; g->gsrc.r = (r.ov - 34) / 7.0; g->real = true; C.used.insert(r.nm);
      ensureGTraits(g->gsrc); fitG(g->gsrc, r.ov); g->pot = r.age <= 26 ? clamp(g->gsrc.r + (27 - r.age) * rand(.08, .25), g->gsrc.r, 9.9) : g->gsrc.r + rand(0, .1);
      C.P.push_back(std::move(s)); setContract(g, false, false); }
  }
  C.cap = 70;   // the cap for a top-9 + 2 goalie roster: stacked teams have to make choices
  buildAHL(false);
  squeeze(); setStars(false); recalcAll(); rankQ();
}
static void grow(PP *q) {
  double d; if (q->age <= 30) d = std::max(0.0, q->pot - av2(q)) * rand(.1, .26) * q->dev + rand(-.12, .12); else d = -rand(.12, .32) - (q->age - 31) * .06;
  d += q->boost; q->src.p = clamp(q->src.p + d + rand(-.25, .25), 1, 10); q->src.a = clamp(q->src.a + d + rand(-.25, .25), 1, 10);
}
static void growG(PP *q) {
  double d; if (q->age <= 30) d = std::max(0.0, q->pot - q->gsrc.r) * rand(.1, .26) * q->dev + rand(-.12, .12); else d = -rand(.08, .22) - (q->age - 31) * .045;
  q->gsrc.r = clamp(q->gsrc.r + d + q->boost + rand(-.2, .2), .5, 9.9);
}
// perks move with the ratings over the summer: the biggest changes make the headlines (your team's first)
static void pkNews(const std::map<PP *, std::vector<PerkE>> &before) {
  struct Ev { double w; std::string s; }; std::vector<Ev> ev;
  for (auto &b : before) { PP *q = b.first; bool alive = false; for (auto &x : C.P) if (x.get() == q) alive = true; if (!alive || q->t < 0) continue;
    std::vector<PerkE> a = q->g ? pkOfG(&q->gsrc) : pkOfSrc(&q->src); int ov = ovQ(q), mn = q->t == C.me ? 100 : 0; std::string who = q->nm() + " (" + C.L[q->t].n + ")";
    for (auto &e : a) { const PerkE *o = nullptr; for (auto &x : b.second) if (x.id == e.id) o = &x;
      if (!o) ev.push_back({(double)mn + ov + e.t * 3, who + " earned " + TIERN[e.t] + " " + PERKS[e.id].n});
      else if (e.t > o->t) ev.push_back({(double)mn + ov + e.t * 2, who + ": " + PERKS[e.id].n + " is now " + TIERN[e.t]}); }
    for (auto &o : b.second) { bool still = false; for (auto &e : a) if (e.id == o.id) still = true; if (!still) ev.push_back({(double)mn + ov - 5, who + " lost " + PERKS[o.id].n}); } }
  std::sort(ev.begin(), ev.end(), [](const Ev &x, const Ev &y) { return x.w > y.w; }); if (ev.size() > 4) ev.resize(4);
  for (int i = (int)ev.size() - 1; i >= 0; i--) logS("PERKS: " + ev[i].s);
}
static PP *mkDraftee(int t, int k) {
  std::vector<PP *> og = teamG(t); bool old = false; for (PP *g : og) if (g->age >= 33) old = true;
  bool gk = rnd() < (old ? .25 : .08), bust = rnd() < .1, steal = rnd() < .05;
  double pot = k < 3 ? rand(9, 9.95) : k < 10 ? rand(7.9, 9.1) : k < 20 ? rand(7.1, 8.5) : rand(6.2, 7.9);
  if (bust) pot -= rand(1, 2.2); if (steal) pot = std::min(9.9, pot + rand(.8, 1.6));
  double dev = k < 3 ? rand(1.8, 2.3) : k < 10 ? rand(1.3, 1.7) : rand(.85, 1.3); int age = 18 + (int)std::floor(rnd() * 2);
  PP *q;
  if (gk) { q = mkG(t, MK_ROOKIE); q->pot = pot - .4; q->gsrc.r = clamp(q->pot * .6 + rand(-.3, .3), 1, 7); }
  else { q = mkS(t, MK_ROOKIE); q->pot = pot; q->src.p = clamp(pot * .62 + rand(-.4, .4), 1, 8); q->src.a = clamp(pot * .62 + rand(-.4, .4), 1, 8); }
  q->age = age; q->dev = dev; q->dY = C.season; q->dN = k + 1; q->sal = .95 * infl(); q->cy = 3;
  return q;
}
// the organizations move players between the NHL and the farm: an AHL player better than an NHL regular goes up
static void farmMoves(bool news) {
  if (!hasAHL()) return; int nlog = 0;
  for (int i = 0; i < NTm; i++) { int a = i + NA;
    for (int k = 0; k < 2; k++) { PP *up = nullptr, *dn = nullptr;
      auto v = [](PP *q) { return ovQ(q) + form(q) * .15; };   // overall first: a hot AHL month is not an NHL job
      for (PP *q : coreP(a)) if (!q->me && !q->inj && q->age <= 31 && (!up || v(q) > v(up))) up = q;
      for (PP *q : coreP(i)) if (!q->me && !q->inj && !q->star && (!dn || v(q) < v(dn))) dn = q;
      if (!up || !dn || v(up) < v(dn) + 1.5) break;
      up->t = i; dn->t = a; if (news && nlog < 3 && ovQ(up) >= 76) { nlog++; logS("CALL-UP: the " + C.L[i].n + " bring up " + tagQ(up) + " from the " + C.L[a].n); } }
    PP *gu = nullptr, *gd = nullptr; for (PP *g : teamG(a)) if (!g->me && (!gu || eff(g) > eff(gu))) gu = g; for (PP *g : teamG(i)) if (!g->me && (!gd || eff(g) < eff(gd))) gd = g;
    if (gu && gd && ovQ(gu) >= ovQ(gd) + 2) { gu->t = i; gd->t = a; } }
}
static void offseason() {
  std::vector<std::unique_ptr<PP>> FA; g_FA = &FA; double cap = capOf();
  // 1. contracts run out: a raise for the ones they can fit, a trade or free agency for the rest
  for (int t = 0; t < NTm; t++) {
    std::vector<PP *> mn; for (auto &q : C.P) if (q->t == t && !q->me) mn.push_back(q.get());
    for (PP *q : mn) q->cy--;
    std::vector<PP *> exp; for (PP *q : mn) if (q->cy <= 0) exp.push_back(q); std::sort(exp.begin(), exp.end(), [](PP *a, PP *b) { return ovQ(a) > ovQ(b); });
    double committed = payroll(t); for (PP *q : exp) committed -= q->sal;
    for (PP *q : exp) {
      int ov = ovQ(q); double ask = std::max(market(ov) * rand(.9, 1.12), ov >= 70 && q->age <= 31 ? q->sal * rand(1.03, 1.15) : 0.0); bool old = q->age >= 33 && ov < 78;
      if (!old && committed + ask <= cap) { q->sal = ask; q->cy = 1 + (int)std::floor(rnd() * 5); committed += ask; continue; }
      if (!old && ov >= 76 && rnd() < .4) {   // sign-and-trade instead of losing him for nothing
        std::vector<int> to; for (int i = 0; i < NTm; i++) if (i != t) to.push_back(i); shuffle(to); bool done = false;
        for (int b : to) { PP *back = nullptr; for (PP *x : q->g ? teamG(b) : coreP(b)) if (!x->me && x->cy > 0 && x->sal < ask * .7 && ovQ(x) >= ov - 12 && (!back || ovQ(x) > ovQ(back))) back = x;
          if (!back) continue; if (payroll(b) - back->sal + ask > cap) continue;
          q->sal = ask; q->cy = 1 + (int)std::floor(rnd() * 5); q->t = b; back->t = t; committed += back->sal; done = true;
          if (ov >= 82) logS("SIGN-AND-TRADE: the " + C.L[t].n + " move " + tagQ(q) + " to the " + C.L[b].n + " for " + tagQ(back)); break; }
        if (done) continue;
      }
      if (ov >= 85) logS("FREE AGENT: " + tagQ(q) + " leaves the " + C.L[t].n + " - they could not fit him under the cap");
      std::unique_ptr<PP> o = drop(q); o->t = -1; o->from = t; FA.push_back(std::move(o));
    }
  }
  // 2. the draft, worst record picks first
  std::vector<int> order = allTeams(); shuffle(order); std::stable_sort(order.begin(), order.end(), [](int a, int b) { return C.L[a].w < C.L[b].w; });
  C.ldY = C.season; C.ldPicks.clear();
  for (int k = 0; k < NTm; k++) { PP *q = mkDraftee(order[k], k); C.ldPicks.push_back({q->nm(), q->t, q->g, ovQ(q), potOv(q)}); if (hasAHL()) q->t += NA;   // juniors grow up on the farm
    if (k < 3) logS("DRAFT #" + istr(k + 1) + ": the " + C.L[q->t].n + " take " + q->nm() + (q->g ? " (G)" : "") + "  -  potential " + istr(potOv(q))); }
  // 3. rosters back to 9 skaters + 2 goalies (cuts go to free agency)
  for (int t = 0; t < NTm; t++) fixRoster(t, true);
  // 4. free agency: teams with holes sign the best player they can afford
  std::stable_sort(FA.begin(), FA.end(), [](const std::unique_ptr<PP> &a, const std::unique_ptr<PP> &b) { return ovQ(a.get()) > ovQ(b.get()); });
  for (int round = 0; round < 12; round++) {
    std::vector<int> need; for (int t : allTeams()) if ((int)coreP(t).size() < PRO_ROS || (int)teamG(t).size() < PRO_NG) need.push_back(t);
    if (need.empty()) break; shuffle(need);
    for (int t : need) {
      double room = cap - payroll(t); bool wantG = (int)teamG(t).size() < PRO_NG && ((int)coreP(t).size() >= PRO_ROS || rnd() < .5);
      int pick = -1; for (size_t i = 0; i < FA.size(); i++) if (FA[i]->g == wantG && market(ovQ(FA[i].get())) * .95 <= room) { pick = (int)i; break; }
      if (pick >= 0) { PP *q = FA[pick].get(); q->sal = std::max(.85 * infl(), std::min(market(ovQ(q)) * rand(.9, 1.05), room)); }
      else if (room >= infl()) { for (size_t i = 0; i < FA.size(); i++) if (FA[i]->g == wantG && ovQ(FA[i].get()) < 85) { pick = (int)i; break; } if (pick >= 0) FA[pick]->sal = room * .9; }
      if (pick < 0) continue;
      std::unique_ptr<PP> q = std::move(FA[pick]); FA.erase(FA.begin() + pick); q->t = t; q->cy = 1 + (int)std::floor(rnd() * 3);
      if (ovQ(q.get()) >= 84 && q->from >= 0 && q->from != t) logS("SIGNED: " + tagQ(q.get()) + " joins the " + C.L[t].n + " from the " + C.L[q->from].n);
      C.P.push_back(std::move(q));
    }
  }
  g_FA = nullptr;
  for (int t = 0; t < NTm; t++) fixRoster(t);   // anything still missing gets a depth player
  farmMoves(true);
  if (hasAHL()) for (int t = NA; t < NALL; t++) fixRoster(t);
}
static void rollover() {
  healAll();
  std::vector<int> rank = allTeams(); std::sort(rank.begin(), rank.end(), [](int a, int b) { return C.L[b].w < C.L[a].w; });
  for (int i = 0; i < NTm; i++) { C.L[rank[i]].build = i >= NTm / 2; C.L[rank[i]].needT = 0; }
  for (auto &q : C.P) q->boost = q->g ? (q->me ? 0 : clamp(form(q.get()) * .02, -.25, .3)) : clamp(form(q.get()) * .035, -.35, .35);
  std::map<PP *, std::vector<PerkE>> pk0; for (auto &q : C.P) if (!q->me) pk0[q.get()] = q->g ? pkOfG(&q->gsrc) : pkOfSrc(&q->src);
  for (auto &q : C.P) { if (q->me) { q->age = C.age; continue; } q->age++; if (q->g) growG(q.get()); else grow(q.get()); }
  pkNews(pk0);
  std::vector<PP *> ret; for (auto &q : C.P) if (!q->me) { if (!q->g && (q->age >= 38 || (q->age >= 33 && rnd() < (q->age - 32) * .13))) ret.push_back(q.get()); if (q->g && (q->age >= 40 || (q->age >= 35 && rnd() < (q->age - 34) * .11))) ret.push_back(q.get()); }
  for (PP *q : ret) { if (q->t < NA && (ovQ(q) >= 82 || (q->real && ovQ(q) >= 78))) logS("RETIRED: " + q->nm() + (q->g ? " (G)" : "") + " of the " + C.L[q->t].n + ", age " + istr(q->age)); drop(q); }
  offseason();
  setStars(true); recalcAll();
  for (int w = 0; w < 14; w++) for (int k = 0; k < 60; k++) if (tryTrade()) break;
  for (int t = 0; t < NTm; t++) for (int k = 0; k < 40 && payroll(t) > capOf(); k++) tryTrade(t);   // teams over the cap have to move money
  setStars(true); recalcAll();
}
static void pickOpp() {
  if (C.phase == "reg" && C.day < (int)C.sched.size()) { int o = C.sched[C.day]; if (o != C.me) { C.opp = o; setStarters(); return; } }
  int b = lgOf(C.me) * NA, o; do { o = b + (int)std::floor(rnd() * NTm); } while (o == C.me || o == C.opp); C.opp = o; setStarters();
}
static void newSeason() {
  for (auto &t : C.L) { t.w = t.l = t.gf = t.ga = t.sk = 0; }
  for (auto &q : C.P) { q->gl = q->as = 0; q->sa = q->sv = q->gp = 0; }
  recalcAll();
  C.phase = "reg"; C.day = 0; C.round = 0; C.champ = -1; C.br.clear(); C.obr.clear(); C.ochamp = -1; C.sched = makeSched(); C.hist.clear(); C.st = PSeason(); C.yr = PWeek(); C.cal = makeCal(); C.ci = 0; C.wk = PWeek(); C.offers.clear();
  pickOpp(); ensureWeek();
}
static void placeUser(int team) {
  std::vector<PP *> mn = coreP(team); std::sort(mn.begin(), mn.end(), [](PP *a, PP *b) { return ovQ(a) < ovQ(b); }); if ((int)mn.size() >= PRO_ROS) drop(mn[0]);
  auto u = std::make_unique<PP>(); PP *q = u.get(); q->src.nm = C.nm; q->src.me = true; q->me = true; q->t = team; q->age = C.age; q->src.p = q->src.a = 3.5; q->pot = 9.8;
  q->src.hasAr = true; q->src.ar = AR_BALANCED; ensureTraits(q->src); q->sal = .95 * infl(); q->cy = 3; C.P.push_back(std::move(u));
  C.me = team; C.lo = .3; C.ntc = false;
}
void proNew(int slot, const std::string &nm, int num, int diff, char pos, char sh, const Look *lk) {
  CR.reset(new Career()); homeFromJ(J()); proSlot = slot; C.nm = nm; C.look = lk ? *lk : lookOf(nm); lookOverride(nm, &C.look); C.num = num; C.diff = diff; C.sh = sh == 'R' ? 'R' : 'L'; C.age = 18;
  C.pos = pos == 'L' || pos == 'R' ? pos : 'C'; C.cen = C.pos == 'C';
  statsDefaults(g_stats); for (auto k : FKEYS) g_stats[k] = 50; g_stats["bhp"] = 46; g_stats["bha"] = 46;
  buildLeague();
  C.dOrder = allTeams(); shuffle(C.dOrder); C.dPick = (int)std::floor(rnd() * NTm); for (int i = 0; i < NTm; i++) C.dNm.push_back(genName());
  int org = C.dOrder[C.dPick]; C.used.insert(C.nm); placeUser(hasAHL() ? org + NA : org);
  newSeason(); C.draftDone = false; logS("DRAFT: the " + C.L[org].n + " take " + C.nm + " with pick #" + istr(C.dPick + 1) + (hasAHL() ? " and send him to the " + C.L[C.me].n : ""));
  if (hasAHL()) C.orgMsg = "The " + C.L[org].n + " want to see you develop in the AHL. Earn the call.";
  proSave();
}

// ---------------------------------------------------------------- performance, contracts, trades involving you
static double rateG(int ov);
// your line this regular season in the league you play in now
static void curLine(int &gp, int &g, int &a) { gp = g = a = 0; int lg = proLg(); for (auto &h : C.hist) if (!h.po && h.ln && !h.dnp && h.lg == lg) { gp++; g += h.g; a += h.a; } }
void proLine(int &gp, int &g, int &a) { if (!CR) { gp = g = a = 0; return; } curLine(gp, g, a); }
double perfScore() {
  PP *Y = mine(); if (!Y) return .5; double st = C.lastSt < 0 ? .5 : C.lastSt;
  std::vector<PP *> S; for (PP *q : coreP(C.me)) if (!q->me) S.push_back(q); int ov = proOvr(), lower = 0; for (PP *q : S) if (ovQ(q) < ov) lower++;
  double rk = (double)lower / std::max<size_t>(1, S.size());
  int gp, g, a; curLine(gp, g, a);
  if (gp >= 5) { double ppg = (double)(g + a) / gp, ex = .15 + (ov + (proLg() ? 8 : 0) - 50) / 49.0 * .95; st = clamp(.5 + (ppg - ex) * 1.1, 0, 1); }
  return clamp(rk * .55 + st * .45, 0, 1);
}
// the organization: the bar is the weakest regular on the NHL club; your case is your overall, your production
// against what your overall should give (the AHL is easier to score in), and your age (kids get a look, and the
// longer you grind in the minors the more a club values a proven pro)
int callBar() {
  if (!CR) return 75; std::vector<int> o; for (PP *q : coreP(orgOf(C.me))) if (!q->me) o.push_back(ovQ(q)); if (o.empty()) return 72;
  std::sort(o.begin(), o.end()); return o[0];
}
static double prodAdj() {
  int gp, g, a; curLine(gp, g, a); if (gp < 6) return 0;
  double ex = rateG(proOvr() + (proLg() ? 8 : 0)) * 2.25, ppg = (double)(g + a) / gp;
  return clamp((ppg - ex) * 8, -4, 6) * std::min(1.0, gp / 20.0);
}
int readiness() {
  if (!CR) return 50; double r = proOvr() + prodAdj(); int a = C.age;
  if (a <= 20) r += 1.5; if (a >= 26) r += (a - 25) * 1.1;
  return (int)jround(r);
}
std::string prospectNote() {
  if (!CR || !hasAHL()) return ""; int bar = callBar(), r = readiness(), gp, g, a; curLine(gp, g, a); std::string org = C.L[orgOf(C.me)].n;
  if (proLg() == 0) { PP *Y = mine(); if (Y && Y->isCu) return "You are up on an injury call-up. Produce and the " + org + " will find room for you."; return ""; }
  std::string line = gp ? istr(g + a) + (g + a == 1 ? " point in " : " points in ") + istr(gp) + (gp == 1 ? " game. " : " games. ") : "";
  if (r >= bar) return line + "The " + org + " like what they see - a call-up could come any day.";
  if (r >= bar - 4) return line + "You are close. The " + org + " need you to pass their weakest regular (OVR " + istr(bar) + ").";
  return line + "The " + org + " want more. You rate " + istr(r) + "; their weakest regular is " + istr(bar) + ".";
}
double loyalty() { return clamp(C.lo, 0, 1); }
int gamePay() { PP *Y = mine(); return Y ? (int)jround((4 + Y->sal / infl() * 4) * (proLg() ? .5 : 1)) : 4; }   // the AHL side of a two-way deal pays less
bool tradeOpen() { return CR && C.phase == "reg" && C.day < PRO_DEADLINE; }
static bool buildPackage(int to, std::vector<PP *> &best) {
  PP *Y = mine(); int from = C.me; double cap = capOf(), pT = payroll(to), pF = payroll(from);
  std::vector<PP *> pool; for (PP *q : coreP(to)) if (!q->me && !q->inj && !q->isCu && !q->star) pool.push_back(q);
  std::sort(pool.begin(), pool.end(), [](PP *a, PP *b) { return a->sal < b->sal; }); if (pool.size() > 8) pool.resize(8);
  double target = proOvr() - 4, bs = 1e9; bool found = false;
  auto test = [&](const std::vector<PP *> &all) {
    if (all.empty()) return; double sum = 0, ov = 0; for (PP *q : all) { sum += q->sal; ov += ovQ(q); }
    if (pT - sum + Y->sal > std::max(cap, pT) + .01) return; if (pF - Y->sal + sum > std::max(cap, pF) + .01) return;
    double sc = sum + all.size() * .6 + std::fabs(ov / all.size() - target) * .08; if (sc < bs) { bs = sc; best = all; found = true; } };
  for (size_t i = 0; i < pool.size(); i++) { test({pool[i]}); for (size_t j = i + 1; j < pool.size(); j++) { test({pool[i], pool[j]}); for (size_t k = j + 1; k < pool.size(); k++) test({pool[i], pool[j], pool[k]}); } }
  return found;
}
static void moveUser(int to, const std::vector<PP *> &ret, const std::string &why, const std::string &title = "TRADE ALERT") {
  PP *Y = mine(); int from = C.me; Y->t = to; for (PP *q : ret) q->t = from; if (lgOf(from) != lgOf(to)) Y->gl = Y->as = 0;
  C.me = to; C.lo = .15; C.hasTreq = false; C.offers.clear();
  std::vector<std::string> rn; for (PP *q : ret) rn.push_back(nmTag(q));
  fixRoster(from); fixRoster(to); C.lmT.clear(); recalc(from); recalc(to);
  if (C.phase == "reg") { C.sched = makeSched(); pickOpp(); }
  std::string rs; for (auto &n : rn) rs += (rs.empty() ? "" : ", ") + n;
  logS("YOU: " + (title == "FREE AGENCY" ? "signed with the " + C.L[to].n : "traded from the " + C.L[from].n + " to the " + C.L[to].n + (rn.empty() ? "" : " for " + rs)));
  C.hasTrade = true; C.trade = PTrade(); C.trade.from = from; C.trade.to = to; C.trade.why = why; C.trade.title = title; C.trade.ret = rn;
}
// inside the organization: up to the NHL (the weakest regular goes down), down to the farm (its best comes up)
static void promoteUser(const std::string &why, const std::string &title = "CALLED UP") {
  PP *Y = mine(); int a = C.me, t = orgOf(a); if (!Y || a < NA) return;
  PP *w = nullptr; for (PP *x : coreP(t)) if (!x->me && !x->star && (!w || eff(x) < eff(w))) w = x;
  Y->t = t; if (w) w->t = a; userMoved(a, t, title, why); C.orgMsg.clear();
  logS("CALL-UP: the " + C.L[t].n + " bring up " + C.nm + " from the " + C.L[a].n + (w ? "; " + w->nm() + " goes down" : ""));
}
static void tempUp(int t, const std::string &forNm) {
  PP *Y = mine(); int a = C.me; if (!Y || a != t + NA) return;
  Y->t = t; Y->isCu = true; Y->cu = forNm; Y->home = a; ahlFill(a, Y->nm());
  userMoved(a, t, "CALLED UP", forNm + " is hurt and the " + C.L[t].n + " want you. Play well and they may not send you back.");
}
static void demoteUser(const std::string &why) {
  PP *Y = mine(); int t = C.me, a = t + NA; if (!Y || t >= NA || !hasAHL()) return;
  PP *b = nullptr; for (PP *x : coreP(a)) if (!x->me && !x->inj && (!b || eff(x) > eff(b))) b = x;
  Y->t = a; if (b) b->t = t; userMoved(t, a, "SENT DOWN", why);
  C.orgMsg = "Back in the AHL. Produce and the " + C.L[t].n + " will call again.";
}
// a trade inside the AHL: your rights go to another organization
static void ahlTrade(int to, const std::string &why) {
  PP *Y = mine(); int from = C.me; if (!Y || from < NA || to < NA || to == from) return;
  PP *r = nullptr; for (PP *x : coreP(to)) if (!x->me && !x->star && (!r || std::abs(ovQ(x) - proOvr()) < std::abs(ovQ(r) - proOvr()))) r = x;
  Y->t = to; if (r) r->t = from; userMoved(from, to, "TRADED", why); C.ntc = false; C.lo = .15;
  if (r) C.trade.ret = {r->nm()};
  logS("TRADE: the " + C.L[orgOf(from)].n + " send " + C.nm + " to the " + C.L[orgOf(to)].n + " organization" + (r ? " for " + r->nm() : "") + ". He reports to the " + C.L[to].n);
  C.orgMsg = "A fresh start: the " + C.L[orgOf(to)].n + " get a look at you with the " + C.L[to].n + ".";
}
static int ahlDest() { std::vector<int> c; for (int i = NA; i < NALL; i++) if (i != C.me) c.push_back(i); return pickOne(c); }
// the organization's review: weekly in season, and at training camp
static void orgReview(bool camp) {
  PP *Y = mine(); if (!Y || !hasAHL() || Y->isCu || Y->inj || C.need) return;
  int bar = callBar(), r = readiness(), gap = r - bar, gp, g, a; curLine(gp, g, a); std::string org = C.L[orgOf(C.me)].n;
  if (proLg() == 1) {
    if (camp ? gap >= -1 : (gap >= 0 && C.mvG >= 6 && C.day < PRO_GAMES - 6 && rnd() < clamp(.35 + gap * .15, .35, 1.0))) {
      promoteUser(camp ? "You earned a spot with the " + org + " at training camp. Welcome to the NHL!" : (gp ? istr(g + a) + " points in " + istr(gp) + " games forced the " + org + "' hand." : "The " + org + " have seen enough.") + " Welcome to the NHL!", camp ? "MADE THE TEAM" : "CALLED UP");
      return; }
    if (camp && C.age >= 21 && gap <= -9 && rnd() < .3) { int to = ahlDest(); ahlTrade(to, "The " + org + " do not see you in their plans. Your rights go to the " + C.L[orgOf(to)].n + " and you report to the " + C.L[to].n + "."); return; }
    if (!camp && C.ci % 28 == 3 && C.age >= 22 && gap <= -10 && tradeOpen() && rnd() < .12) { int to = ahlDest(); ahlTrade(to, "The " + org + " moved on. The " + C.L[orgOf(to)].n + " picked up your rights - you report to the " + C.L[to].n + "."); return; }
    C.orgMsg = prospectNote();
  } else {
    if (C.age > 25) return;   // veterans are not sent down
    int rival = 0; for (PP *q : coreP(C.me + NA)) if (!q->inj) rival = std::max(rival, ovQ(q));   // the farm's best: the one who would take your spot
    if (camp ? r < rival - 2 : (gp >= 15 && C.mvG >= 20 && r < rival - 3 && prodAdj() < 0 && rnd() < .25)) demoteUser(camp ? "The " + org + " want you to play big minutes in the minors this year. You start in the AHL with the " + C.L[C.me + NA].n + "." : "You have not been able to keep up. The " + org + " send you down to the " + C.L[C.me + NA].n + " to find your game.");
  }
}
static bool aiTradeCall(const std::string &kind) {
  { PP *Y = mine(); if (Y && Y->isCu) return false; }
  if (proLg() == 1) {   // in the AHL a trade is a change of organization (nobody deals a teenager they just drafted)
    if (C.age < 21) return false; int t = ahlDest(); std::string why = kind == "poor" ? "Your rough season convinced the " + C.L[orgOf(C.me)].n + " to move you." : "The " + C.L[orgOf(t)].n + " traded for your rights.";
    if (C.ntc) { POffer o; o.t = t; o.why = why; o.exp = C.ci + 7; C.offers.push_back(o); C.offMsg = "TRADE OFFER: the " + C.L[orgOf(t)].n + " want you. Your no-trade clause means it is your call."; return false; }
    ahlTrade(t, why + " You report to the " + C.L[t].n + "."); return true; }
  std::vector<int> cands; for (int i = 0; i < NTm; i++) if (i != C.me) cands.push_back(i); shuffle(cands);
  for (size_t k = 0; k < cands.size() && k < 10; k++) { int t = cands[k]; std::vector<PP *> ret; if (!buildPackage(t, ret)) continue;
    std::string why = kind == "poor" ? "Your rough season convinced management to move you." : kind == "great" ? "The " + C.L[t].n + " paid up after your big year." : "The " + C.L[t].n + " made an offer your team could not refuse.";
    if (C.ntc) { C.offers.erase(std::remove_if(C.offers.begin(), C.offers.end(), [t](const POffer &o) { return o.t == t; }), C.offers.end());
      POffer o; o.t = t; for (PP *q : ret) o.ret.push_back(q->nm()); o.why = why; o.exp = C.ci + 7; C.offers.push_back(o);
      C.offMsg = "TRADE OFFER: the " + C.L[t].n + " want you. Your no-trade clause means it is your call."; return false; }
    moveUser(t, ret, why); return true; }
  return false;
}
static bool evalTrade() {
  PTeam &L = C.L[C.me]; double wp = (double)L.w / std::max(1, L.w + L.l); std::string kind;
  if (wp <= .36 && rnd() < .3) kind = "poor"; else if (wp >= .66 && perfScore() > .7 && rnd() < .22) kind = "great";
  return kind.empty() ? false : aiTradeCall(kind);
}
static bool execTradeReq() {
  if (!C.hasTreq) return false; C.hasTreq = false; std::vector<int> l = C.treqT; shuffle(l);
  if (proLg() == 1) { for (int t : l) { int d = t % NA + NA; if (d == C.me) continue; ahlTrade(d, "Your trade request was granted. You report to the " + C.L[d].n + "."); return true; } return false; }
  for (int t : l) { if (t == C.me) continue; std::vector<PP *> ret; if (buildPackage(t, ret)) { moveUser(t, ret, "Your trade request was granted."); return true; } }
  C.offMsg = "TRADE REQUEST FAILED: none of your teams could fit you under the cap."; logS("Trade request: no team on " + C.nm + "'s list could fit him under the cap"); return false;
}
static void officeDay() {
  if (C.phase != "reg") return;
  C.offers.erase(std::remove_if(C.offers.begin(), C.offers.end(), [](const POffer &o) { return o.exp < C.ci || !tradeOpen(); }), C.offers.end());
  if (C.hasTreq && C.ci >= C.treqAt && tradeOpen()) { if (execTradeReq()) C.showTrade = true; }
  if (tradeOpen() && !C.hasTreq && C.ci >= 14 && C.ci % 7 == 0 && rnd() < .013 + (perfScore() > .8 ? .012 : 0)) { if (aiTradeCall("call")) C.showTrade = true; }
  if (C.ci >= 7 && C.ci % 7 == 3 && !C.hasTrade) orgReview(false);
}
double ntcChance(bool cut) { return clamp(perfScore() * .6 + loyalty() * .45 + (cut ? .25 : 0) - .18, .04, .95); }
void negStart(bool forced) {
  double p = perfScore(); PP *Y = mine();
  C.neg = PNeg(); C.neg.base = std::max(.95 * infl(), market(proOvr()) * (.8 + p * .36) * (Y && Y->inj ? .9 : 1));
  C.neg.yrs = (int)clamp(jround(1.5 + p * 3 + (C.age <= 26 ? 1 : 0) - (C.age >= 33 ? 1.5 : 0)), 1, 5); C.neg.pat = 2 + (p > .7 ? 1 : 0); C.neg.forced = forced; C.hasNeg = true;
}
double negSal() { PNeg &N = C.neg; int a = C.age; double f = a <= 26 ? 1 + .025 * (N.yrs - 2) : a >= 32 ? 1 - .045 * (N.yrs - 2) : 1 + .01 * (N.yrs - 2); return N.base * f * (N.ntc && ntcChance(false) >= .5 ? .94 : 1) * (1 - .04 * N.bonus) * (N.perf ? .95 : 1); }
// a signing bonus is paid up front: 15 (or 30) games' pay at the new salary
int negBonusCash() { PNeg &N = C.neg; return N.bonus ? (int)jround((4 + negSal() / infl() * 4) * 15 * N.bonus) : 0; }
void negPush() {
  PNeg &N = C.neg; if (!C.hasNeg || N.pat <= 0) return;
  double ch = clamp(.3 + perfScore() * .45 + loyalty() * .12 - N.push * .13, .08, .85); N.push++;
  if (rnd() < ch) { double r = rand(1.05, 1.11); N.base *= r; N.msg = "They came up " + istr((int)jround((r - 1) * 100)) + "%."; }
  else { N.pat--; N.base *= rand(.97, .995); N.msg = N.pat > 0 ? "They are not happy with that ask." : "That is our final offer."; if (N.pat <= 0) N.fin = true; }
}
void negAccept() {
  PNeg &N = C.neg; PP *Y = mine(); if (!C.hasNeg || !Y) return;
  double s = negSal(); bool ntcOk = N.ntc && ntcChance(false) >= .5;
  int bc = negBonusCash(); C.money += bc; C.perfB = N.perf; C.deals++;
  if (N.forced || Y->cy <= 0) { Y->sal = s; Y->cy = N.yrs; C.need = false; C.ntc = ntcOk; }
  else { Y->hasExt = true; Y->extSal = s; Y->extYrs = N.yrs; Y->extNtc = ntcOk; }
  C.lo = clamp(loyalty() + .08, 0, 1);
  logS("CONTRACT: " + C.nm + " signs " + istr(N.yrs) + " year" + (N.yrs > 1 ? "s" : "") + " at $" + f2(s) + "M with the " + C.L[C.me].n + (ntcOk ? " (no-trade clause)" : ""));
  C.offMsg = "SIGNED: " + istr(N.yrs) + " x $" + f2(s) + "M" + (N.ntc ? (ntcOk ? "  |  NO-TRADE CLAUSE" : "  |  NO-TRADE REFUSED") : "") + (N.forced ? "" : "  (starts next season)") + (bc ? "  |  SIGNING BONUS $" + istr(bc) : std::string()) + (N.perf ? "  |  PERFORMANCE BONUSES" : "");
  C.hasNeg = false; proSave();
}
void proFreeAgency() {
  PP *Y = mine(); int from = C.me; double cap = capOf();
  std::vector<int> cands; for (int i = 0; i < NTm; i++) if (i != from) cands.push_back(i); shuffle(cands);
  int to = cands[0]; for (int t : cands) if (payroll(t) + market(proOvr()) * .6 <= cap) { to = t; break; }
  double sal = std::max(.95 * infl(), market(proOvr()) * rand(.55, 1.15)); int yrs = 1 + (int)std::floor(rnd() * 4);
  Y->sal = sal; Y->cy = yrs; C.ntc = false; C.need = false; C.hasNeg = false; C.deals++; C.perfB = false;
  std::vector<int> o; for (PP *q : coreP(to)) o.push_back(ovQ(q)); std::sort(o.begin(), o.end()); bool farm = hasAHL() && !o.empty() && readiness() < o[0] - 2;
  if (farm) to += NA;
  moveUser(to, {}, "Nobody matched your ask, so you hit the open market. The " + C.L[orgOf(to)].n + " signed you: " + istr(yrs) + " year" + (yrs > 1 ? "s" : "") + " at $" + f2(sal) + "M" + (farm ? " - you start with the " + C.L[to].n + " in the AHL." : "."), "FREE AGENCY");
}
void askNTC(bool cut) {
  if (C.ntc || C.ntcTry == C.season) return; C.ntcTry = C.season; double ch = ntcChance(cut); PP *Y = mine();
  if (rnd() < ch) { C.ntc = true; if (cut) { Y->sal *= .9; C.lo = clamp(loyalty() + .1, 0, 1); } C.offMsg = "NO-TRADE CLAUSE GRANTED" + (cut ? "  (pay cut to $" + f2(Y->sal) + "M)" : std::string()); logS(C.nm + " gets a no-trade clause from the " + C.L[C.me].n); }
  else C.offMsg = "NO-TRADE CLAUSE DENIED - play better or show you want to stay. Try again next season.";
  proSave();
}
void submitTradeReq(const std::vector<int> &l) {
  if (!tradeOpen() || l.empty()) return; C.hasTreq = true; C.treqT = l; if (C.treqT.size() > 10) C.treqT.resize(10); C.treqAt = C.ci + 7; C.lo = clamp(loyalty() - .3, 0, 1);
  C.offMsg = "TRADE REQUESTED: you will be moved in 7 days (if a team on your list can fit you)."; logS(C.nm + " asks the " + C.L[C.me].n + " for a trade"); proSave();
}
void acceptOffer(int i) {
  if (i < 0 || i >= (int)C.offers.size() || !tradeOpen()) return; POffer o = C.offers[i]; std::vector<PP *> ret;
  for (auto &n : o.ret) { PP *q = byName(n, o.t); if (!q) { C.offers.erase(C.offers.begin() + i); C.offMsg = "That deal fell apart."; return; } ret.push_back(q); }
  moveUser(o.t, ret, "You accepted the trade."); screen = "trade"; proSave();
}
void rejectOffer(int i) { if (i < 0 || i >= (int)C.offers.size()) return; C.offMsg = "You turned down the " + C.L[C.offers[i].t].n + "."; C.offers.erase(C.offers.begin() + i); C.lo = clamp(loyalty() + .05, 0, 1); proSave(); }

// ---------------------------------------------------------------- standings and playoffs: 16 teams, best-of-3 all the way
std::vector<int> standOrd(std::vector<int> ids) {
  std::sort(ids.begin(), ids.end(), [](int a, int b) { const PTeam &A = C.L[a], &B = C.L[b];
    if (A.w != B.w) return A.w > B.w; int da = A.gf - A.ga, db = B.gf - B.ga; if (da != db) return da > db; if (A.gf != B.gf) return A.gf > B.gf; return a < b; });
  return ids;
}
std::string ordn(int n) { int m = n % 100; return istr(n) + (n % 10 == 1 && m != 11 ? "st" : n % 10 == 2 && m != 12 ? "nd" : n % 10 == 3 && m != 13 ? "rd" : "th"); }
TRank teamRank(int t) { std::vector<int> o = standOrd(lgTeams(lgOf(t))); TRank r{1, 1}; int dv = 0; for (size_t i = 0; i < o.size(); i++) { if (C.L[o[i]].d == C.L[t].d) dv++; if (o[i] == t) { r.all = (int)i + 1; r.div = dv; } } return r; }
Seeds seeds(int conf, int lg) {
  Seeds S; std::vector<std::vector<int>> div(2); for (int k = 0; k < 2; k++) { std::vector<int> ids; for (int i : lgTeams(lg)) if (i < (int)C.L.size() && C.L[i].d == conf * 2 + k) ids.push_back(i); div[k] = standOrd(ids); }
  for (int k = 0; k < 2; k++) S.top.push_back(std::vector<int>(div[k].begin(), div[k].begin() + 3));
  std::vector<int> rest(div[0].begin() + 3, div[0].end()); rest.insert(rest.end(), div[1].begin() + 3, div[1].end()); rest = standOrd(rest); S.wc = {rest[0], rest[1]};
  int better = standOrd({S.top[0][0], S.top[1][0]})[0] == S.top[0][0] ? 0 : 1; auto &A = S.top[better], &B = S.top[1 - better];
  S.pairs = {{A[0], S.wc[1]}, {A[1], A[2]}, {B[0], S.wc[0]}, {B[1], B[2]}};
  S.all = S.top[0]; S.all.insert(S.all.end(), S.top[1].begin(), S.top[1].end()); S.all.insert(S.all.end(), S.wc.begin(), S.wc.end());
  return S;
}
static void finishRound();
static void beginRound() {
  auto &R = C.br[C.round]; int pi = -1;
  for (size_t i = 0; i < R.size(); i++) { PSeries &s = R[i]; if (s.a == C.me || s.b == C.me) { pi = (int)i; continue; }
    int x = 0, y = 0; while (x < 2 && y < 2) { if (simGameFull(s.a, s.b).w == s.a) x++; else y++; } s.wa = x; s.wb = y; s.w = x > y ? s.a : s.b; }
  if (pi < 0) { finishRound(); return; }
  PSeries &s = R[pi]; C.opp = s.a == C.me ? s.b : s.a; C.sw = C.sl = 0; C.pi = pi; setStarters();
}
static void finishRound() {
  auto R = C.br[C.round]; std::vector<int> ws; for (auto &s : R) ws.push_back(s.w);
  if (ws.size() == 1) { C.champ = ws[0]; C.phase = "over"; bool ahl = ws[0] >= NA;
    if (ws[0] == C.me) { if (ahl) { C.calder++; C.money += 250; } else { C.titles++; C.money += 600; } aptDirty(); }
    logS(std::string(ahl ? "CALDER CUP" : "STANLEY CUP") + ": the " + C.L[ws[0]].n + " win the title, beating the " + C.L[R[0].a == ws[0] ? R[0].b : R[0].a].n + " " + istr(std::max(R[0].wa, R[0].wb)) + "-" + istr(std::min(R[0].wa, R[0].wb))); return; }
  std::vector<PSeries> N; for (size_t i = 0; i + 1 < ws.size(); i += 2) { PSeries s; s.a = ws[i]; s.b = ws[i + 1]; N.push_back(s); }
  C.br.push_back(N); C.round++; beginRound();
}
static std::vector<PSeries> firstRound(int lg) { Seeds E = seeds(0, lg), Wt = seeds(1, lg); std::vector<PSeries> r; for (auto *S : {&E, &Wt}) for (auto &p : S->pairs) { PSeries s; s.a = p.first; s.b = p.second; r.push_back(s); } return r; }
// the other league's playoffs: all at once, when yours begin
static int simBracket(std::vector<std::vector<PSeries>> &br, int lg) {
  br.clear(); br.push_back(firstRound(lg));
  for (;;) { std::vector<PSeries> &R = br.back(); std::vector<int> ws;
    for (auto &s : R) { int x = 0, y = 0; while (x < 2 && y < 2) { if (simGameFull(s.a, s.b).w == s.a) x++; else y++; } s.wa = x; s.wb = y; s.w = x > y ? s.a : s.b; ws.push_back(s.w); }
    if (ws.size() == 1) { const PSeries &f = R[0]; logS(std::string(lg ? "CALDER CUP" : "STANLEY CUP") + ": the " + C.L[f.w].n + " win the " + (lg ? "AHL" : "NHL") + " title, beating the " + C.L[f.w == f.a ? f.b : f.a].n + " " + istr(std::max(f.wa, f.wb)) + "-" + istr(std::min(f.wa, f.wb))); return f.w; }
    std::vector<PSeries> N; for (size_t i = 0; i + 1 < ws.size(); i += 2) { PSeries s; s.a = ws[i]; s.b = ws[i + 1]; N.push_back(s); } br.push_back(N); }
}
static void startPlayoffs() {
  C.phase = "po"; C.round = 0; int lg = proLg();
  struct YP { ~YP() { if (CR) yearProgress(); } } yp_;   // made the playoffs: a season bonus
  if (hasAHL()) C.ochamp = simBracket(C.obr, 1 - lg);
  C.br.clear(); C.br.push_back(firstRound(lg)); beginRound();
}
static void dayEvents() {
  if (rnd() < .3) for (int k = 0; k < 30; k++) if (tryTrade()) break;
  for (int t = 0; t < NTm; t++) if (C.L[t].needT && tradeOpen()) { for (int k = 0; k < 25; k++) if (tryTrade(t)) break; C.L[t].needT = 0; }
  if (C.day % 20 == 10) farmMoves(true);
  if (C.day % 10 == 0) setStars(true);
  recalcAll();
}
static void simLeague(int lg, int m, int o) {
  std::vector<int> ids; for (int i : lgTeams(lg)) if (i != m && i != o) ids.push_back(i); shuffle(ids);
  for (size_t i = 0; i + 1 < ids.size(); i += 2) { int a = ids[i], b = ids[i + 1]; GRes r = simGameFull(a, b); int l = r.w == a ? b : a; wl(r.w, l);
    C.L[a].gf += r.ga; C.L[a].ga += r.gb; C.L[b].gf += r.gb; C.L[b].ga += r.ga; scoreFor(a, r.ga); scoreFor(b, r.gb); gLine(r.GA, r.gb); gLine(r.GB, r.ga);
    teamGameDone(a); teamGameDone(b); }
}
static void simDay(int m, int o) { simLeague(lgOf(m), m, o); if (hasAHL()) simLeague(1 - lgOf(m), -1, -1); }   // both leagues play every day
// a game is in the books: your line, the standings, the rest of the league's night, the calendar
struct GameLine { int hs = 0, as = 0, sa = 0, hsh = 0; bool ln = false; int g = 0, a = 0, sog = 0, hits = 0, sh = 0, pass = 0, pim = 0, blk = 0, pm = 0; double toi = 0; };
static void coachGame(const GameLine &L, const MeStats *f, bool won);
static void textAfterGame(int g, int a, int pm, int pim, int sog, bool won);
static void teamGoalProgress(const GameLine &L); static void offerTeamGoal();
static void proResult(bool won, bool sim, const GameLine &L) {
  if (!sim) { if (won) C.money += 20; C.money += gamePay(); }
  if (L.ln && !userHurt()) { bool ahl = proLg(); int pg = ahl ? 10 : 25, pa = ahl ? 5 : 10, b = L.g * pg + L.a * pa;   // the performance bonus: per goal, per assist
    if (b > 0) { C.money += b; g_gr.perf = b; g_gr.pg = L.g; g_gr.pa = L.a; } }
  int o = C.opp, m = C.me; bool played = !userHurt();
  PHist h; h.d = C.day; h.o = o; h.hs = L.hs; h.as = L.as; h.w = won; h.po = C.phase == "po"; h.r = C.round; h.sim = sim; h.dnp = !played;
  h.lg = lgOf(m); if (C.phase == "reg") C.mvG++;
  if (played && L.ln) { h.ln = true; h.g = L.g; h.a = L.a; h.sog = L.sog; h.hits = L.hits; h.fs = (int)jround(clamp(30 + L.g * 25 + L.a * 15 + L.sog * 4 + (won ? 8 : 0), 0, 100));
    if (h.lg) { C.aG += L.g; C.aA += L.a; C.aGP++; } else { C.cG += L.g; C.cA += L.a; C.cGP++; }
    if (C.phase == "reg") { PSeason &S = C.st; S.gp++; S.g += L.g; S.a += L.a; S.sog += L.sog; S.sh += std::max(L.sh, L.sog); S.hits += L.hits; S.pass += L.pass; S.pim += L.pim; S.blk += L.blk; S.pm += L.pm; S.toi += L.toi; } } else h.fs = 40;
  if (played && L.ln) { size_t n0 = C.texts.size(); teamGoalProgress(L); textAfterGame(L.g, L.a, L.pm, L.pim, L.sog, won); if (C.texts.size() == n0 && rnd() < .24) offerTeamGoal(); }
  { int n = 0; for (int k = 0; k < HM_NP; k++) { n += C.hmPend[k]; C.hmDoor[k] += C.hmPend[k]; C.hmPend[k] = 0; } if (n) C.hmArrived += n; }   // the Hockeymon order lands at the door
  C.hist.push_back(h); if (C.hist.size() > 90) C.hist.erase(C.hist.begin());
  PP *GH = homeG(), *GA = awayG();
  userHealTick();
  if (C.phase == "reg") {
    if (won) wl(m, o); else wl(o, m);
    C.L[m].gf += L.hs; C.L[m].ga += L.as; C.L[o].gf += L.as; C.L[o].ga += L.hs;
    if (GH) { GH->sa += L.sa; GH->sv += std::max(0, L.sa - L.as); GH->gp++; } if (GA) { GA->sa += L.hsh; GA->sv += std::max(0, L.hsh - L.hs); GA->gp++; }
    teamGameDone(m); teamGameDone(o);
    if (played) userInjuryRoll();
    simDay(m, o); C.day++; dayEvents();
    { int wid = C.wk.w; weekProgress(h, won, played); if (g_gr.wk.w != wid) g_gr.preW.clear(); g_gr.wk = C.wk; g_gr.yr = C.yr; } if (!C.cal.empty()) calStep();
    if (g_pendUp >= 0) { int t = g_pendUp; g_pendUp = -1; if (C.day < PRO_GAMES && !userHurt()) tempUp(t, g_pendFor); }
    if (C.day >= PRO_GAMES) startPlayoffs(); else pickOpp();
  } else if (C.phase == "po") {
    if (played) userInjuryRoll();
    PSeries *S = C.round < (int)C.br.size() && C.pi < (int)C.br[C.round].size() ? &C.br[C.round][C.pi] : nullptr;
    if (won) C.sw++; else C.sl++;
    if (S) { if (S->a == m) { S->wa = C.sw; S->wb = C.sl; } else { S->wb = C.sw; S->wa = C.sl; } }
    if (C.sw >= 2 || C.sl >= 2) { bool w = C.sw >= 2; if (w) { C.money += 150; C.xp += 10; proGainXP += 10; } if (S) S->w = w ? m : o; finishRound(); }
    else setStarters();
  }
  if (C.cei) { C.phase = "retired"; C.retWhy = "injury"; proHofCareers++; proHofBest = std::max(proHofBest, C.titles); }
}
// your scoring rate by overall (goals per game on an average team in an average season): 70 OVR ~.22 (18 a season),
// 80 ~.38 (30), 90 ~.58 (46), 99 ~.75 (60). Each season has its own form (a hot year runs ~25% over), and better
// teams give you a little more. Assists run 1.25 a goal. Returned as the chance each team goal is yours / you assist.
static double rateG(int ov) { static const double X[10] = {50, 60, 65, 70, 75, 80, 85, 90, 95, 99}, Y[10] = {.04, .10, .15, .22, .30, .38, .48, .58, .68, .75};
  if (ov <= 50) return .04; for (int i = 1; i < 10; i++) if (ov <= X[i]) return Y[i - 1] + (Y[i] - Y[i - 1]) * (ov - X[i - 1]) / (X[i] - X[i - 1]); return .75; }
void proUserShare(double &pg, double &pa) {
  if (!CR) { pg = .15; pa = .2; return; }
  double sf = .82 + .4 * ((skHash(C.nm + istr(C.season) + "form") % 1000) / 1000.0), tf = clamp(1 + (C.L[C.me].s - 4.5) * .05, .85, 1.15);
  double lf = C.line <= 0 ? 1 : C.line == 1 ? .84 : .68;   // the line you're on: less ice time, fewer points
  double eg = rateG(proOvr() + (proLg() ? 8 : 0)) * sf * tf * lf, ea = eg * 1.25, tg = 3.0;   // the AHL is easier to score in
  pg = clamp(eg / tg, 0, .6); pa = clamp(ea / tg / (1 - pg), 0, .8);
}
struct SimR { bool won; int hs, as, xp, cash, g, a; bool dnp; };
static SimR simOneF() {
  int o = C.opp, m = C.me; PTeam &A = C.L[m], &B = C.L[o]; int G = proOvr(); PP *ag0 = awayG(), *hg0 = homeG(); double bg = ag0 ? gRel(ag0) : 5, ag = hg0 ? gRel(hg0) : 5;
  auto hot = [] { return rand(.8, 1.25) * (rnd() < .08 ? 1.4 : 1) * (rnd() < .08 ? .65 : 1); };
  int hs = poisson(clamp(3.0 + (A.s - 4.5) * .3 - (bg - 5) * .3, .7, 6.2) * hot()), as = poisson(clamp(3.0 + (B.s - 4.5) * .3 - (ag - 5) * .3, .7, 6.2) * hot());
  bool so = false; if (hs == as) { so = true; if (rnd() < .5 + (G - 60) / 400.0) hs++; else as++; }
  bool won = hs > as; PP *me = mine();
  double pg, pa; proUserShare(pg, pa);   // NHL-like: your share of the team's goals follows your overall
  int g = 0, a = 0; for (int i = 0; i < hs - (so && won ? 1 : 0); i++) { if (rnd() < pg) g++; else if (rnd() < pa) a++; }
  int sog = g + poisson(1.2 + std::max(0, proOvr() - 50) * .055);
  if (C.phase == "reg" && me) { me->gl += g; me->as += a; scoreFor(m, std::max(0, hs - g), me); }
  GameLine L; L.hs = hs; L.as = as; L.sa = std::max(as + 1, (int)jround(rand(20, 32) + (B.s - 4.5) * 1.2)); L.hsh = std::max(hs + 1, (int)jround(rand(20, 32) + (A.s - 4.5) * 1.2));
  for (int i = 0; i < g; i++) { if (rnd() < .65) { fillStat("sacc", .02); fillStat("wpow", .015); } else { fillStat("slacc", .02); fillStat("spow", .015); } }
  for (int i = 0; i < a; i++) fillStat("pass", .02);
  for (auto k : {"skate", "edge", "deke", "poise"}) fillStat(k, .006); for (auto k : {"fo", "fstam", "check", "hand"}) fillStat(k, .008);
  double opr = (B.s + B.g) / 2, mult = .8 + opr * .06;
  int gx = (int)jround((g * 10 + a * 7 + sog * 1.5 + (won ? 8 : 0) + 4) * mult), gc = (won ? (int)jround(15 * mult) : 4) + gamePay();
  C.xp += gx; C.money += gc;
  L.ln = true; L.g = g; L.a = a; L.sog = sog; L.hits = (int)std::floor(rand(0, 4)); L.sh = sog + poisson(1.6); L.pass = poisson(5 + std::max(0, proOvr() - 55) * .12); L.blk = poisson(.5); L.pim = rnd() < .14 ? 2 : 0; L.toi = rand(13.5, 19.5);
  { int gf = hs - (so && won ? 1 : 0), ga = as - (so && !won ? 1 : 0), pm = g + a, rest = std::max(0, gf - g - a); double sh = L.toi / 60 * 1.1;   // a simmed +/-: your points count, the rest by your share of the ice
    for (int i = 0; i < rest; i++) if (rnd() < sh) pm++; for (int i = 0; i < ga; i++) if (rnd() < sh * 1.05) pm--; L.pm = pm; }
  coachGame(L, nullptr, won);
  proResult(won, true, L);
  return {won, hs, as, gx, gc, g, a, false};
}
static SimR simTeamOnly() {   // a night you don't dress: the team plays, you get paid
  GRes r = simGameFull(C.me, C.opp, homeG(), awayG()); int hs = r.ga, as = r.gb;
  if (C.phase == "reg") scoreFor(C.me, hs);
  bool won = hs > as; int gc = gamePay() + (won ? 6 : 0); C.money += gc;
  GameLine L; L.hs = hs; L.as = as; L.sa = std::max(as + 1, (int)jround(rand(22, 32))); L.hsh = std::max(hs + 1, (int)jround(rand(22, 32)));
  proResult(won, true, L);
  return {won, hs, as, 0, gc, 0, 0, true};
}
static SimR simOne() { skipOffDays(); if (userHurt()) return simTeamOnly(); return simOneF(); }
void proSimGames(int n) {
  if (!CR || C.phase == "over" || C.phase == "retired" || C.need) return;
  int o0 = proOvr(), w = 0, l = 0, xp = 0, cash = 0, gf = 0, ga = 0, pg = 0, pa = 0; std::string ph = C.phase; int r0 = C.round, me0 = C.me;
  for (int i = 0; i < n; i++) { if (C.phase != ph || C.round != r0 || C.me != me0 || C.phase == "retired") break;
    bool wasHurt = userHurt(); SimR r = simOne(); if (r.won) w++; else l++; xp += r.xp; cash += r.cash; gf += r.hs; ga += r.as; pg += r.g; pa += r.a;
    if (!wasHurt && userHurt() && n > 1) break; }
  int g = proOvr() - o0;
  proMsg = "SIM " + istr(w) + "-" + istr(l) + "  (" + istr(gf) + "-" + istr(ga) + ")  YOU " + istr(pg) + "G " + istr(pa) + "A  +" + istr(xp) + " XP  +$" + istr(cash) + (g > 0 ? "  OVR +" + istr(g) : "");
  if (C.hasTrade) C.showTrade = true;
  proSave();
}
void proSimHealthy() {
  if (!userHurt()) return; std::string ph = C.phase; int k = 0, w = 0, l = 0, cash = 0;
  while (userHurt() && C.phase == ph && C.phase != "over" && C.phase != "retired" && k++ < 60) { SimR r = simOne(); if (r.won) w++; else l++; cash += r.cash; }
  proMsg = "MISSED " + istr(w + l) + " GAMES  (TEAM WENT " + istr(w) + "-" + istr(l) + ")  +$" + istr(cash); if (C.hasTrade) C.showTrade = true; proSave();
}
void proSkipDay() { if (offDay()) { calStep(); proMsg = "RESTED - " + calDate(C.ci); if (C.hasTrade) C.showTrade = true; proSave(); } }
void proNextSeason() {
  proMsg.clear(); C.injMsg.clear();
  C.lastSt = perfScore(); C.age++; C.season++;
  if (C.age >= 40) { C.phase = "retired"; C.retWhy = "age"; proHofCareers++; proHofBest = std::max(proHofBest, C.titles); proSave(); return; }
  PP *Y = mine(); Y->cy--; if (Y->hasExt) { Y->sal = Y->extSal; Y->cy = Y->extYrs; if (Y->extNtc) C.ntc = true; Y->hasExt = false; }
  C.lo = clamp(loyalty() + .12, 0, 1);
  rollover();
  bool tr = false;
  if (C.hasTreq) { C.phase = "reg"; C.day = 0; tr = execTradeReq(); }
  if (Y->cy <= 0) { C.ntc = false; bool keep = rnd() < .4 + perfScore() * .55 + loyalty() * .1;
    if (!keep && !tr) { C.phase = "reg"; C.day = 0; tr = aiTradeCall("exp"); } C.need = true; }
  else if (!tr) { C.phase = "reg"; C.day = 0; if (proLg() == 0) tr = evalTrade(); }
  if (!tr) C.hasTrade = false;
  // training camp: last season's play decides where you start (the NHL club or its farm team)
  if (!tr && !C.need) { std::string ph = C.phase; C.phase = "camp"; orgReview(true); C.phase = ph; tr = C.hasTrade; }
  newSeason();
  screen = tr ? "trade" : C.need ? "office" : "main"; proSave();
}
bool proCanPlay() { return CR && !C.need && !userHurt() && C.phase != "over" && C.phase != "retired" && !offDay(); }
std::string headline() {
  PP *Y = mine(); PTeam &L = C.L[C.me]; TRank rk = teamRank(C.me); int gp = 0; for (auto &h : C.hist) if (!h.po) gp++;
  if (C.phase == "po") return "The " + L.n + " are in the playoffs: " + std::string(RN[std::min(3, C.round)]) + ", series " + istr(C.sw) + "-" + istr(C.sl);
  if (gp == 0) return C.nm + " suits up for the " + L.n + ". Opening night is here";
  if (Y && Y->inj) return C.nm + " is out with a " + std::string(Y->it) + " injury";
  if (L.sk >= 4) return "The " + L.n + " have won " + istr(L.sk) + " straight";
  if (L.sk <= -4) return "The " + L.n + " have dropped " + istr(-L.sk) + " in a row";
  int lgp, lg, la; curLine(lgp, lg, la);
  if (proLg() == 1 && hasAHL() && gp >= 6 && (gp / 3) % 2 == 0) { int bar = callBar(), r = readiness(); std::string org = C.L[orgOf(C.me)].n;
    return r >= bar ? "The " + org + " are watching: " + C.nm + " has " + istr(lg + la) + " points in " + istr(lgp) + " games" : C.nm + " is grinding in the AHL - the " + org + " want more before a call-up"; }
  if (lg >= 5) return C.nm + " has " + istr(lg) + " goals and " + istr(lg + la) + " points in " + istr(lgp) + " games";
  return "The " + L.n + " sit " + ordn(rk.div) + " in the " + divName(C.me) + " at " + istr(L.w) + "-" + istr(L.l);
}

// ---------------------------------------------------------------- the engine: rosters for a career game, credit for goals, after the game
void proGameRosters(Rosters &R) {
  std::vector<PP *> mn, op; for (PP *q : actP(C.me)) if (!q->me) mn.push_back(q); op = actP(C.opp);
  for (PP *q : mn) { ensureTraits(q->src, C.L[C.me].pref); R.home.push_back(&q->src); }
  for (PP *q : op) { ensureTraits(q->src, C.L[C.opp].pref); R.away.push_back(&q->src); }
  PP *gH = homeG(), *gA = awayG();
  R.hg = gH ? gH->gsrc.r : 5; R.ag = gA ? gA->gsrc.r : 5; R.hn = upper(shortN(C.me)); R.an = upper(shortN(C.opp));
  R.hc = hex(teamCol(C.me)); R.ac = hex(teamCol(C.opp)); R.hs = hex(teamStr(C.me)); R.as = hex(teamStr(C.opp));
  R.hgn = gH ? gH->nm() : "G"; R.agn = gA ? gA->nm() : "G"; R.hgs = gStats(gH ? &gH->gsrc : nullptr); R.ags = gStats(gA ? &gA->gsrc : nullptr);
  R.hgo = gH ? &gH->gsrc : nullptr; R.ago = gA ? &gA->gsrc : nullptr;
  g_meSh = C.sh; g_meLook = C.look; g_meLookOn = true;
}
static PP *ppOf(const Src *s) { if (!s) return nullptr; for (auto &q : C.P) if (&q->src == s) return q.get(); return nullptr; }
// the lineup card before a game: real records and season lines from the career (not the made-up ones)
bool proPreview(int ti, PvTeam &o, const std::vector<Skater *> &on, const Goalie &G) {
  if (mode != "pro" || !CR) return false; int t = ti ? C.opp : C.me; const PTeam &r = C.L[(size_t)t];
  o.rec = istr(r.w) + "-" + istr(r.l); o.recL = isAHL(t) ? "AHL RECORD" : "RECORD"; o.sk.clear();
  for (Skater *s : on) { PP *q = s->user ? mine() : ppOf(s->src); o.sk.push_back({roleName(s->role), s->nm, q ? q->gl : 0, s->pks}); }
  PP *gp = nullptr; if (G.src) for (auto &q : C.P) if (&q->gsrc == G.src) { gp = q.get(); break; }
  o.hasG = true; o.gk = {"G", G.nm, 0, G.pks}; o.gsv = gp && gp->sa > 0 ? svp(gp->sv, gp->sa) : std::string(".000"); o.gsub = istr(gp ? gp->gp : 0) + " GP";
  return true;
}
void proCredit(Skater *sc, Skater *as) {
  if (!proInGame() || C.phase != "reg") return;
  PP *a = sc ? (sc->user ? mine() : ppOf(sc->src)) : nullptr; if (a) a->gl++;
  PP *b = as ? (as->user ? mine() : ppOf(as->src)) : nullptr; if (b) b->as++;
}
// ---------------------------------------------------------------- the coach
// He watches every game you play: goals, assists, hits, poke checks, time spent in their end and your +/- raise his view of
// you; a quiet night, a minus and penalties lower it, and it drifts back toward the middle. His view (with your overall)
// sets your line. He also runs the faceoff circle: a winger who's winning draws gets asked to move to center; a center
// keeps the job until his draws (or the coach's patience) fall away, then a linemate gets his shot.
// ---------------------------------------------------------------- Hockeymon
bool proHmBuy(int k) { const HmPack &p = hmPack(k); if (C.money < p.price) return false; C.money -= p.price; C.hmPend[k]++; proSave(); return true; }
std::vector<HmCard> proHmOpen(int k) { std::vector<HmCard> v; if (k < 0 || k >= HM_NP || C.hmDoor[k] <= 0) return v; C.hmDoor[k]--; v = hmRoll(k);
  for (auto &c : v) { C.hmCnt[c.id][c.v]++; if (C.hmBest < 0 || hmValue(c.id, c.v) > hmValue(C.hmBest / 3, C.hmBest % 3)) C.hmBest = c.id * 3 + c.v; }
  C.hmOpened++; proSave(); return v; }
int proHmSell(int id, int v, int n) { if (id < 0 || id >= HM_N || v < 0 || v >= HM_NV) return 0; n = std::min(n, C.hmCnt[id][v]); if (n <= 0) return 0;
  int c = hmValue(id, v) * n; C.hmCnt[id][v] -= n; C.hmCents += c; C.money += C.hmCents / 100; C.hmCents %= 100; proSave(); return c; }
int proHmDupValue() { int s = 0; for (int i = 0; i < HM_N; i++) { bool kept = false; for (int v = HM_NV - 1; v >= 0; v--) { int n = C.hmCnt[i][v]; if (n && !kept) { n--; kept = true; } s += n * hmValue(i, v); } } return s; }
int proHmSellDups() { int s = 0; for (int i = 0; i < HM_N; i++) { bool kept = false; for (int v = HM_NV - 1; v >= 0; v--) { int n = C.hmCnt[i][v]; if (n && !kept) { n--; kept = true; }   // keep the best copy
      if (n > 0) { s += hmValue(i, v) * n; C.hmCnt[i][v] -= n; } } }
  C.hmCents += s; C.money += C.hmCents / 100; C.hmCents %= 100; proSave(); return s; }
int proHmOwned() { int n = 0; for (int i = 0; i < HM_N; i++) if (C.hmCnt[i][0] + C.hmCnt[i][1] + C.hmCnt[i][2] > 0) n++; return n; }
int proHmValue() { int s = 0; for (int i = 0; i < HM_N; i++) for (int v = 0; v < HM_NV; v++) s += C.hmCnt[i][v] * hmValue(i, v); return s; }
// ---------------------------------------------------------------- teammates: texts after games, and chemistry
double proChem(const std::string &nm) { auto it = C.chem.find(nm); return it == C.chem.end() ? 50 : it->second; }
static void chemAdd(const std::string &nm, double d) { C.chem[nm] = clamp(proChem(nm) + d, 0, 100); }
double proTeamChem() { double s = 0; int n = 0; for (PP *q : teamS(C.me, false, false)) if (!q->me) { s += proChem(q->nm()); n++; } for (PP *q : teamG(C.me)) { s += proChem(q->nm()); n++; } return n ? s / n : 50; }
int proUnreadTexts() { int n = 0; for (auto &t : C.texts) if (t.ans == -1 || (t.ans == -2 && !t.read)) n++; return n; }
void proReadTexts() { for (auto &t : C.texts) t.read = true; }
void proAnswerText(int i, int opt) { if (i < 0 || i >= (int)C.texts.size() || opt < 0 || opt > 2) return; PText &t = C.texts[(size_t)i]; if (t.ans >= 0) return;
  t.ans = opt; t.read = true; chemAdd(t.from, t.dc[opt]);
  if (t.gk >= 0 && opt != 1) {   // took the challenge on
    TGoal g; g.from = t.from; g.k = t.gk; g.tg = t.gt; g.games = g.left = t.gn; g.season = C.season; bool ahl = proLg();
    g.xp = 25 + 12 * t.gn; g.cash = (ahl ? 15 : 30) + (ahl ? 8 : 15) * t.gn; if (opt == 2) g.cash = g.cash * 3 / 2; g.ch = 6 + t.gn;
    C.tgoals.push_back(g);
    for (size_t k = 0; C.tgoals.size() > 8 && k < C.tgoals.size();) { if (C.tgoals[k].st) C.tgoals.erase(C.tgoals.begin() + (long)k); else k++; } }
  proSave(); }
int proTeamGoalsOn() { int n = 0; for (auto &g : C.tgoals) if (!g.st) n++; return n; }
std::string tgoalText(const TGoal &g) {
  std::string N = istr(g.tg), G = istr(g.games) + (g.games == 1 ? " GAME" : " GAMES");
  switch (g.k) { case 0: return "SCORE " + N + (g.tg == 1 ? " GOAL" : " GOALS") + " IN " + G;
    case 1: return "PUT UP " + N + (g.tg == 1 ? " POINT" : " POINTS") + " IN " + G;
    case 2: return N + " SHOTS ON GOAL IN " + G;
    case 3: return "THROW " + N + " HITS IN " + G;
    case 4: return "BLOCK " + N + " SHOTS IN " + G;
    case 5: return "GO +" + N + " OR BETTER OVER " + G;
    default: return "STAY OUT OF THE BOX FOR " + G; } }
static const char *pickS(std::initializer_list<const char *> l) { int n = (int)l.size(); int k = std::min(n - 1, (int)std::floor(rnd() * n)); return *(l.begin() + k); }
static std::string subst(std::string s, const char *key, const std::string &v) { size_t p; while ((p = s.find(key)) != std::string::npos) s.replace(p, strlen(key), v); return s; }
// after a game you played: maybe one teammate has something to say about it
static void textAfterGame(int g, int a, int pm, int pim, int sog, bool won) {
  std::vector<PP *> mates; for (PP *q : teamS(C.me, false, false)) if (!q->me) mates.push_back(q); for (PP *q : teamG(C.me)) mates.push_back(q);
  if (mates.empty()) return;
  double sc = g * 2 + a + pm * .7 + (won ? .8 : -.4) - pim * .35 - (sog == 0 ? 1 : 0);
  int kind = 0; double r = rnd();
  if (sc >= 3) kind = r < .7 ? 1 : 0; else if (sc >= 1.5) kind = r < .32 ? 1 : 0; else if (sc <= -1.8) kind = r < .6 ? -1 : 0; else if (sc <= -.8) kind = r < .25 ? -1 : 0; else if (won && g + a > 0) kind = r < .2 ? 1 : 0;
  if (!kind) return;
  PP *q = mates[(size_t)std::floor(rnd() * mates.size()) % mates.size()]; PText t; t.from = q->nm(); t.kind = kind; t.day = C.day; t.season = C.season;
  std::string body;
  if (kind > 0) {
    if (g >= 3) body = pickS({"A HAT TRICK?! Hats are still landing on the ice, bro.", "Three goals. Three! Somebody frame that stick."});
    else if (g == 2) body = pickS({"Two goals tonight - save some for the rest of us.", "Two snipes. Their goalie is going to have nightmares."});
    else if (g + a >= 3) body = subst(pickS({"That's a {P}-point night. Dinner's on you.", "{P} points! You were everywhere out there."}), "{P}", istr(g + a));
    else if (pm >= 2) body = subst(pickS({"+{M} tonight. Every shift you had, good things happened.", "+{M}. That's how you play a 200-foot game."}), "{M}", istr(pm));
    else if (g == 1) body = pickS({"Big goal tonight. The room loved it.", "Nice finish on that goal. Clean."});
    else body = pickS({"Great feed tonight. Made my job easy.", "Love the way you moved the puck tonight.", "Good win. You were flying out there."});
    t.opt[0] = "Team win. Couldn't do it without you."; t.re[0] = pickS({"That's why the room loves you.", "Humble AND good. Annoying.", "Same time next game?"}); t.dc[0] = 5;
    t.opt[1] = "Get used to it."; t.re[1] = pickS({"...okay, superstar. Stay humble.", "Wow. Somebody's head is getting big.", "Easy there. One game."}); t.dc[1] = -3;
    t.opt[2] = "Next round's on me."; t.re[2] = pickS({"Holding you to that!", "I'm ordering the expensive stuff.", "Screenshotted. No take-backs."}); t.dc[2] = 3;
  } else {
    if (pim >= 4) body = subst(pickS({"{N} penalty minutes. We can't kill all night, man.", "You spent half the game in the box. We needed you out there."}), "{N}", istr(pim));
    else if (pm <= -2) body = subst(pickS({"{M} tonight. You've got to come back and help.", "{M}. We were chasing every time you were out there."}), "{M}", istr(pm));
    else if (sog == 0) body = pickS({"Zero shots? Put the puck on net, bud.", "You didn't test their goalie once tonight."});
    else body = pickS({"Flat game. We need more from you.", "That wasn't you out there tonight. Shake it off and be better.", "Rough one. We needed a push and didn't get it."});
    t.opt[0] = "You're right. I'll be better next game."; t.re[0] = pickS({"That's all we ask. Let's go.", "Respect. We bounce back together.", "Good. Shake it off."}); t.dc[0] = 4;
    t.opt[1] = "Worry about your own game."; t.re[1] = pickS({"Wow. Noted.", "Okay then. See you at practice.", "Didn't know you were that sensitive."}); t.dc[1] = -6;
    t.opt[2] = "Rough one. Extra skate tomorrow?"; t.re[2] = pickS({"I'm in. 9 AM.", "Now we're talking. Bring coffee.", "Deal. Let's fix it."}); t.dc[2] = 2;
  }
  t.body = body; chemAdd(t.from, kind > 0 ? 1 : -1);
  C.texts.push_back(t); if (C.texts.size() > 40) C.texts.erase(C.texts.begin());
}
// a teammate's challenge over text (now and then after a game when nobody had anything else to say)
static void offerTeamGoal() {
  if (proTeamGoalsOn() >= 2) return; for (auto &t : C.texts) if (t.gk >= 0 && t.ans == -1) return;   // one open offer at a time
  std::vector<PP *> mates; for (PP *q : teamS(C.me, false, false)) if (!q->me) mates.push_back(q); for (PP *q : teamG(C.me)) mates.push_back(q);
  if (mates.empty()) return;
  PP *q = mates[(size_t)std::floor(rnd() * mates.size()) % mates.size()]; PText t; t.from = q->nm(); t.kind = 3; t.day = C.day; t.season = C.season;
  int k = (int)std::floor(rnd() * 7) % 7, n = 2 + (int)std::floor(rnd() * 3) % 3, tg = 1;   // over 2-4 games
  switch (k) { case 0: tg = n >= 4 ? 2 : 1 + (rnd() < .25); break; case 1: tg = n; break; case 2: tg = 2 * n + (rnd() < .5 ? 1 : 0); break; case 3: tg = 2 * n; break; case 4: tg = n; break; case 5: tg = 2; break; default: tg = n; }
  t.gk = k; t.gt = tg; t.gn = n; TGoal g; g.k = k; g.tg = tg; g.games = n; std::string what = tgoalText(g); for (auto &c : what) c = (char)std::tolower((unsigned char)c);
  static const char *OPEN[7] = {"Bet you can't {W}. Loser buys wings.", "Coach wants more offence from our line. You in? Let's {W}.", "The goalie coach says you never shoot. Prove him wrong: {W}.",
    "We need some bite out there. Let's {W}.", "D-men are tired of eating pucks alone. {W} with me?", "Two-way hockey, bud. Let's {W}.", "Ref's got your number lately. Let's {W}."};
  std::string w = what; t.body = subst(OPEN[k], "{W}", w); if (!t.body.empty() && t.body[0] >= 'a' && t.body[0] <= 'z') t.body[0] = (char)(t.body[0] - 32);
  t.opt[0] = "You're on."; t.re[0] = pickS({"Let's go. I'm keeping score.", "That's what I like to hear.", "Deal. Don't make me regret it."}); t.dc[0] = 2;
  t.opt[1] = "Not this time."; t.re[1] = pickS({"Okay... boring, but okay.", "Your loss. Literally.", "Fine. Offer's off the table."}); t.dc[1] = -2;
  t.opt[2] = "Easy. Make it worth my while."; t.re[2] = pickS({"Fine - the bet's bigger. Now deliver.", "Big talk. Bigger payout. Go.", "Ha! You're on. Double or nothing."}); t.dc[2] = 1;
  C.texts.push_back(t); if (C.texts.size() > 40) C.texts.erase(C.texts.begin());
}
static void teamGoalNews(const TGoal &g, bool done) {
  PText t; t.from = g.from; t.kind = done ? 1 : -1; t.day = C.day; t.season = C.season; t.ans = -2;
  t.body = done ? pickS({"You did it. I owe you dinner - and the room noticed.", "Called it. Knew you had it in you. Pay day!", "That's the guy I know. Challenge complete."})
                : pickS({"Didn't happen this time. We'll get the next one.", "Close, but no. You're buying the wings.", "Missed it. I still believe in you... mostly."});
  C.texts.push_back(t); if (C.texts.size() > 40) C.texts.erase(C.texts.begin());
}
static void teamGoalProgress(const GameLine &L) {
  for (auto &g : C.tgoals) { if (g.st) continue;
    int d = g.k == 0 ? L.g : g.k == 1 ? L.g + L.a : g.k == 2 ? L.sog : g.k == 3 ? L.hits : g.k == 4 ? L.blk : g.k == 5 ? L.pm : (L.pim == 0 ? 1 : 0);
    g.pr += d; g.left--;
    bool fail = (g.k == 6 && L.pim > 0) || (g.left <= 0 && g.pr < g.tg);
    if (g.pr >= g.tg && !fail) { g.st = 1; C.xp += g.xp; proGainXP += g.xp; C.money += g.cash; chemAdd(g.from, g.ch); teamGoalNews(g, true);
      logS("Team goal with " + g.from + " complete: +" + istr(g.xp) + " XP +$" + istr(g.cash)); }
    else if (fail) { g.st = 2; chemAdd(g.from, -3); teamGoalNews(g, false); } }
}
static int coachLine() { double o = clamp((proOvr() - 55) * 1.5, 0, 45), v = C.coach * .75 + o * .6;
  int want = v >= 58 ? 0 : v >= 40 ? 1 : 2, cur = std::max(0, std::min(2, C.line));
  if (want < cur && v < (cur == 1 ? 61 : 43)) want = cur;   // a little hysteresis: no yo-yo between lines
  if (want > cur && v > (cur == 0 ? 55 : 37)) want = cur;
  return want; }
double proFoPct() { return C.cFoT >= 1 ? C.cFoW / C.cFoT : 0; }
bool proTakeDraw(double mateFo, bool special) {
  if (!CR) return true;
  if (C.cen) { double my = C.cFoT >= 10 ? C.cFoW / C.cFoT : .5, mate = .5 + (mateFo - 5.5) * .045;
    return !(mate > my + .05 && rnd() < .55); }   // a center takes most of them - just not over a linemate who's winning more
  return special ? rnd() < .3 : false;           // a winger: now and then on the power play / penalty kill
}
void proLineProgress(int &line, double &v, double &need, double &prog, double &coachNeed) {
  double o = clamp((proOvr() - 55) * 1.5, 0, 45); v = C.coach * .75 + o * .6; line = std::max(0, std::min(2, C.line));
  if (line == 0) { need = 0; prog = 1; coachNeed = 0; return; }
  need = line == 1 ? 61 : 43; double floor0 = line == 1 ? 40 : 0;   // the bar to move up (as coachLine: past the hysteresis)
  prog = clamp((v - floor0) / (need - floor0), 0, 1); coachNeed = clamp((need - o * .6) / .75, 0, 100);
}
static void coachGame(const GameLine &L, const MeStats *f, bool won) {
  static const char *LN[3] = {"the first line", "the second line", "the third line"};
  double d = L.g * 3.2 + L.a * 2.2 + L.hits * .45 - L.pim * .5;
  if (f) { double ozf = f->toi > 1 ? f->ozt / f->toi : 0; d += f->tk * .7 + f->pm * 2.4 + (ozf - .3) * 9 - f->offs * .6 + std::min(f->blk, 4) * .4;
    C.cFoW = C.cFoW * .85 + f->fow; C.cFoT = C.cFoT * .85 + f->fot; }
  else d += (won ? 1.2 : -.8) + rand(-.8, .8);   // a simmed game: just the result and your points
  d -= C.line == 0 ? 2.2 : C.line == 1 ? 1.6 : 1.1;   // what he expects of the line you're on
  d += (55 - C.coach) * .035;
  C.coachD = d; C.coach = clamp(C.coach + d, 0, 100); C.lineWas = C.line; C.cGames++;
  int nl = coachLine(); C.coachMsg.clear();
  if (nl < C.line) { C.coachMsg = "You've earned a promotion to " + std::string(LN[nl]) + "."; logS("LINES: the " + C.L[C.me].n + " move " + C.nm + " up to " + LN[nl]); }
  else if (nl > C.line) { C.coachMsg = "I need more from you. You're on " + std::string(LN[nl]) + " for now."; logS("LINES: " + C.nm + " drops to " + LN[nl]); }
  C.line = nl;
  // the faceoff circle
  double pct = C.cFoT >= 1 ? C.cFoW / C.cFoT : 0; int fo = stv("fo");
  if (!C.cen) { if (!C.cOffer && C.cGames >= 5 && C.coach >= 45 && (fo >= 70 || (C.cFoT >= 8 && pct >= .55))) { C.cOffer = 1; C.coachMsg = "You're winning draws. Want to take the middle?"; logS("COACH: the " + C.L[C.me].n + " want to try " + C.nm + " at center"); } }
  else { bool bad = (C.cFoT >= 15 && pct < .4) || C.coach < 25; C.cLow = bad ? C.cLow + 1 : std::max(0, C.cLow - 1);
    if (C.cLow >= 3 && C.cGames >= 4) { C.cen = false; C.cLow = 0; C.cGames = 0; C.cOffer = 0; C.coachMsg = "Your linemate gets a shot at center. You're on the wing."; logS("COACH: " + C.nm + " moves to the wing; a linemate takes the draws"); } }
}
void proCoachAnswer(bool yes) { if (!CR || !C.cOffer) return; C.cOffer = 0; C.cGames = 0;
  if (yes) { C.cen = true; C.cLow = 0; C.coachMsg = "You're my center now. Win me some draws."; logS("COACH: " + C.nm + " moves to center"); }
  else C.coachMsg = "Fair enough. Stay on the wing."; proSave(); }
void proAfterGame(bool won, bool sim) {
  if (!CR) return; (void)sim;
  GameLine L; L.hs = SK->T[0].score; L.as = SK->T[1].score; L.sa = SK->T[1].sog; L.hsh = std::max(L.hs, SK->T[0].sog);
  L.ln = true; L.g = SK->me.g; L.a = SK->me.a; L.sog = SK->me.sog; L.hits = SK->me.hits; L.sh = SK->me.shots; L.pass = SK->me.pass; L.pim = SK->me.pim; L.blk = SK->me.blk; L.pm = SK->me.pm; L.toi = SK->me.toi / SK_PER * 20;
  award(won ? 12 : 0);
  if (!userHurt()) coachGame(L, &SK->me, won);
  int m0 = C.money; proResult(won, false, L); rs.cash = C.money - m0; g_gr.yr = C.yr;
  if (C.hasTrade) C.showTrade = true;
  proSave();
}

// ---------------------------------------------------------------- saves: chl_pro.json {info[3], hof}, one file per career (chl_pro1..3.json)
static std::string dataPath(const std::string &f) { return plat_data_dir() + f; }
static ProSlotInfo g_info[3];
ProSlotInfo proSlotInfo(int i) { return i >= 0 && i < 3 ? g_info[i] : ProSlotInfo(); }
static void writeIndex() {
  J o = J::obj(), a = J::arr();
  for (int i = 0; i < 3; i++) { const ProSlotInfo &s = g_info[i]; if (!s.on) { a.push(J()); continue; } J x = J::obj(); x["nm"] = s.nm; x["team"] = s.team; x["ov"] = s.ov; x["age"] = s.age; x["season"] = s.season; x["titles"] = s.titles; x["phase"] = s.phase; x["jc"] = s.jc; x["js"] = s.js; x["num"] = s.num; x["sh"] = std::string(1, s.sh); a.push(x); }
  o["info"] = a; J h = J::obj(); h["careers"] = proHofCareers; h["best"] = proHofBest; o["hof"] = h;
  plat_write_file(dataPath("chl_pro.json"), o.dump());
}
void proLoadAll(const std::string &s) {
  bool ok = false; J o = J::parse(s, &ok); if (!ok || !o.isObj()) return;
  const J &a = o("info"); for (int i = 0; i < 3 && i < (int)a.size(); i++) { const J &x = a[i]; if (!x.isObj()) continue; ProSlotInfo &p = g_info[i]; p.on = true; p.nm = x("nm").str(); p.team = x("team").str(); p.ov = x("ov").i(); p.age = x("age").i(); p.season = x("season").i(); p.titles = x("titles").i(); p.phase = x("phase").str(); p.jc = x("jc").str(); p.js = x("js").str(); p.num = x("num").i(); p.sh = x("sh").str().empty() ? 'L' : x("sh").str()[0]; }
  proHofCareers = o("hof")("careers").i(); proHofBest = o("hof")("best").i();
}
// a player in one string: fields split by '|'
static std::string nf(double v) { char b[32]; snprintf(b, sizeof b, "%.4g", v); return b; }
static std::string ppStr(const PP *q) {
  const Src &s = q->src; const GSrc &g = q->gsrc; std::string o; auto A = [&](const std::string &v) { o += v; o += '|'; };
  A(q->nm()); A(istr(q->t)); A(istr((q->g ? 1 : 0) | (q->me ? 2 : 0) | (q->real ? 4 : 0) | (q->isCu ? 8 : 0) | (q->star ? 16 : 0) | (q->hasExt ? 32 : 0) | (q->extNtc ? 64 : 0)));
  A(istr(q->age)); A(nf(q->pot)); A(nf(q->dev)); A(nf(q->boost)); A(nf(q->sal)); A(istr(q->cy)); A(istr(q->gl)); A(istr(q->as)); A(istr(q->sa)); A(istr(q->sv)); A(istr(q->gp));
  A(istr(q->inj)); A(q->it); A(q->cu); A(istr(q->from)); A(istr(q->dY)); A(istr(q->dN)); A(nf(q->extSal)); A(istr(q->extYrs));
  if (!q->g) { A(nf(s.p)); A(nf(s.a)); A(istr(s.hasAr ? (int)s.ar : -1)); A(istr((int)s.tend));
    A(istr(s.hasTv ? 1 : 0)); for (int i = 0; i < 3; i++) A(nf(s.tv[i])); for (int i = 0; i < 3; i++) A(nf(s.ta[i]));
    const Fx &f = s.fx; A(istr(s.hasFx ? 1 : 0)); for (double v : {f.spd, f.pass, f.sacc, f.spow, f.wpow, f.lacc, f.stam, f.fo, f.chk, f.hand}) A(nf(v)); A(istr((f.hasW ? 1 : 0) | (f.hasL ? 2 : 0))); }
  else { A(nf(g.r)); A(g.gar); A(istr((g.hasGo ? 1 : 0) | (g.hasRd ? 2 : 0))); for (int i = 0; i < 8; i++) A(nf(g.go[i])); }
  A(istr(q->home + 1));
  return o;
}
static std::unique_ptr<PP> ppFrom(const std::string &str) {
  std::vector<std::string> f; size_t i = 0; while (i <= str.size()) { size_t e = str.find('|', i); if (e == std::string::npos) e = str.size(); f.push_back(str.substr(i, e - i)); i = e + 1; }
  size_t k = 0; auto S = [&]() -> std::string { return k < f.size() ? f[k++] : std::string(); }; auto I = [&] { return atoi(S().c_str()); }; auto D = [&] { return atof(S().c_str()); };
  auto q = std::make_unique<PP>(); std::string nm = S(); q->t = I(); int fl = I(); q->g = fl & 1; q->me = fl & 2; q->real = fl & 4; q->isCu = fl & 8; q->star = fl & 16; q->hasExt = fl & 32; q->extNtc = fl & 64;
  q->age = I(); q->pot = D(); q->dev = D(); q->boost = D(); q->sal = D(); q->cy = I(); q->gl = I(); q->as = I(); q->sa = I(); q->sv = I(); q->gp = I();
  q->inj = I(); q->it = S(); q->cu = S(); q->from = I(); q->dY = I(); q->dN = I(); q->extSal = D(); q->extYrs = I();
  if (!q->g) { Src &s = q->src; s.nm = nm; s.me = q->me; s.star = q->star; s.p = D(); s.a = D(); int ar = I(); if (ar >= 0) { s.hasAr = true; s.ar = (Arch)ar; } s.tend = (Tend)I();
    s.hasTv = I() != 0; for (int j = 0; j < 3; j++) s.tv[j] = D(); for (int j = 0; j < 3; j++) s.ta[j] = D();
    Fx &x = s.fx; s.hasFx = I() != 0; for (double *v : {&x.spd, &x.pass, &x.sacc, &x.spow, &x.wpow, &x.lacc, &x.stam, &x.fo, &x.chk, &x.hand}) *v = D(); int w = I(); x.hasW = w & 1; x.hasL = w & 2; }
  else { GSrc &g = q->gsrc; g.nm = nm; g.me = q->me; g.r = D(); g.gar = S(); int b = I(); g.hasGo = b & 1; g.hasRd = b & 2; for (int j = 0; j < 8; j++) g.go[j] = D(); }
  q->home = I() - 1;   // older saves: missing, so -1
  return q;
}
static J iv(const std::vector<int> &v) { J a = J::arr(); for (int x : v) a.push(x); return a; }
static std::vector<int> vi(const J &a) { std::vector<int> v; for (size_t i = 0; i < a.size(); i++) v.push_back(a[i].i()); return v; }
static J sv(const std::vector<std::string> &v) { J a = J::arr(); for (auto &x : v) a.push(x); return a; }
static std::vector<std::string> vs(const J &a) { std::vector<std::string> v; for (size_t i = 0; i < a.size(); i++) v.push_back(a[i].str()); return v; }
void proSave() {
  if (!CR || proSlot < 0) return;
  J o = J::obj(); o["v"] = 1;
  o["nm"] = C.nm; o["num"] = C.num; o["sh"] = std::string(1, C.sh); o["pos"] = std::string(1, C.pos); o["cen"] = C.cen; o["coach"] = std::round(C.coach * 100) / 100; o["line"] = C.line;
  o["cOf"] = C.cOffer; o["cG"] = C.cGames; o["cFW"] = std::round(C.cFoW * 100) / 100; o["cFT"] = std::round(C.cFoT * 100) / 100; o["cLo"] = C.cLow; o["cMsg"] = C.coachMsg; o["age"] = C.age; o["season"] = C.season; o["titles"] = C.titles; o["diff"] = C.diff;
  o["me"] = C.me; o["opp"] = C.opp; o["day"] = C.day; o["round"] = C.round; o["champ"] = C.champ; o["sw"] = C.sw; o["sl"] = C.sl; o["pi"] = C.pi;
  o["phase"] = C.phase; o["retWhy"] = C.retWhy; o["cap"] = C.cap; o["lo"] = C.lo; o["lastSt"] = C.lastSt; o["ntc"] = C.ntc; o["need"] = C.need; o["cei"] = C.cei; o["ntcTry"] = C.ntcTry;
  J L = J::arr(); for (auto &t : C.L) { J x = J::arr(); for (double v : {t.s, t.g, t.q}) x.push(std::round(v * 1000) / 1000); for (int v : {t.w, t.l, t.gf, t.ga, t.sk, t.build ? 1 : 0, t.pref, t.needT}) x.push(v); L.push(x); } o["L"] = L;
  J P = J::arr(); for (auto &q : C.P) P.push(ppStr(q.get())); o["P"] = P;
  o["used"] = sv(std::vector<std::string>(C.used.begin(), C.used.end()));
  o["sched"] = iv(C.sched); o["cal"] = iv(C.cal); o["ci"] = C.ci;
  J H = J::arr(); for (auto &h : C.hist) H.push(iv({h.d, h.o, h.hs, h.as, h.w, h.po, h.sim, h.dnp, h.r, h.fs, h.ln, h.g, h.a, h.sog, h.hits, h.lg})); o["hist"] = H;
  J wk = J::obj(); wk["w"] = C.wk.w; wk["s"] = C.wk.season; wk["n"] = C.wk.games; J gl = J::arr(); for (auto &g : C.wk.goals) { J x = J::arr(); x.push(g.k); x.push(g.txt); for (int v : {g.tg, g.pr, g.xp, g.cash, g.done ? 1 : 0}) x.push(v); gl.push(x); } wk["g"] = gl; wk["ap"] = C.wk.allPaid; o["wk"] = wk;
  J of = J::arr(); for (auto &f : C.offers) { J x = J::obj(); x["t"] = f.t; x["ret"] = sv(f.ret); x["why"] = f.why; x["exp"] = f.exp; of.push(x); } o["offers"] = of;
  if (C.hasTreq) { J x = J::obj(); x["teams"] = iv(C.treqT); x["at"] = C.treqAt; o["treq"] = x; }
  if (C.hasTrade) { J x = J::obj(); x["from"] = C.trade.from; x["to"] = C.trade.to; x["why"] = C.trade.why; x["title"] = C.trade.title; x["ret"] = sv(C.trade.ret); x["show"] = C.showTrade; o["trade"] = x; }
  J lg = J::arr(); for (auto &l : C.log) { J x = J::arr(); x.push(l.s); x.push(l.y); lg.push(x); } o["log"] = lg;
  { J tx = J::arr(); for (auto &t : C.texts) { J x = J::obj(); x["f"] = t.from; x["b"] = t.body; x["k"] = t.kind; x["d"] = t.day; x["s"] = t.season; x["a"] = t.ans; x["r"] = t.read; if (t.gk >= 0) x["g"] = iv({t.gk, t.gt, t.gn});
      J op = J::arr(), re = J::arr(), dc = J::arr(); for (int k = 0; k < 3; k++) { op.push(t.opt[k]); re.push(t.re[k]); dc.push(t.dc[k]); } x["o"] = op; x["re"] = re; x["dc"] = dc; tx.push(x); }
    { J hm = J::arr(); for (int i = 0; i < HM_N; i++) for (int v = 0; v < HM_NV; v++) hm.push(C.hmCnt[i][v]); o["hm"] = hm;
      J hp = J::arr(), hd = J::arr(); for (int k = 0; k < HM_NP; k++) { hp.push(C.hmPend[k]); hd.push(C.hmDoor[k]); } o["hmp"] = hp; o["hmd"] = hd;
      o["hmc"] = C.hmCents; o["hmo"] = C.hmOpened; o["hmb"] = C.hmBest; o["hma"] = C.hmArrived; }
    { J tg = J::arr(); for (auto &g : C.tgoals) { J x = J::arr(); x.push(g.from); for (int v : {g.k, g.tg, g.pr, g.games, g.left, g.xp, g.cash, g.st, g.season}) x.push(v); x.push(g.ch); tg.push(x); } o["tg"] = tg; }
    o["lk"] = iv({C.look.skin, C.look.face, C.look.hair, C.look.hairC});
    o["tx"] = tx; J ch = J::obj(); for (auto &c : C.chem) ch[c.first] = std::round(c.second * 10) / 10; o["chem"] = ch; }
  auto brJ = [](const std::vector<std::vector<PSeries>> &B) { J br = J::arr(); for (auto &r : B) { J rr = J::arr(); for (auto &s : r) rr.push(iv({s.a, s.b, s.wa, s.wb, s.w})); br.push(rr); } return br; };
  o["br"] = brJ(C.br); o["obr"] = brJ(C.obr); o["ochamp"] = C.ochamp;
  o["aG"] = C.aG; o["aA"] = C.aA; o["aGP"] = C.aGP; o["calder"] = C.calder; o["debut"] = C.debut; o["calls"] = C.calls; o["orgMsg"] = C.orgMsg; o["mvG"] = C.mvG;
  o["sgH"] = C.sgH; o["sgA"] = C.sgA;
  o["draftDone"] = C.draftDone; o["dOrder"] = iv(C.dOrder); o["dPick"] = C.dPick; o["dNm"] = sv(C.dNm);
  o["ldY"] = C.ldY; J lp = J::arr(); for (auto &p : C.ldPicks) { J x = J::arr(); x.push(p.nm); for (int v : {p.t, p.g ? 1 : 0, p.ov, p.pot}) x.push(v); lp.push(x); } o["ldPicks"] = lp;
  o["xp"] = C.xp; o["money"] = C.money; o["stats"] = g_stats;
  J sx = J::obj(); for (auto &e : C.sxp) sx[e.first] = std::round(e.second * 1000) / 1000; o["sxp"] = sx;
  o["home"] = homeToJ();
  { const PSeason &S = C.st; o["st"] = iv({S.gp, S.sh, S.sog, S.g, S.a, S.pass, S.hits, S.pim, S.blk, (int)jround(S.toi * 60), S.pm}); }
  { J y = J::obj(); y["s"] = C.yr.season; J gl = J::arr(); for (auto &g : C.yr.goals) { J x = J::arr(); x.push(g.k); x.push(g.txt); for (int v : {g.tg, g.pr, g.xp, g.cash, g.done ? 1 : 0}) x.push(v); gl.push(x); } y["g"] = gl; y["ap"] = C.yr.allPaid; o["yr"] = y; }
  o["perfB"] = C.perfB; o["deals"] = C.deals; o["newsN"] = C.newsN; o["newsSeen"] = C.newsSeen; o["callSeen"] = C.callSeen; o["perkOwn"] = sv(C.perkOwn); o["perkEq"] = sv(C.perkEq); J pl = J::obj(); for (auto &e : C.perkLv) pl[e.first] = e.second; o["perkLv"] = pl;
  o["gearOwn"] = sv(std::vector<std::string>(C.gearOwn.begin(), C.gearOwn.end())); J ge = J::obj(); for (auto &e : C.gearEq) ge[e.first] = e.second; o["gearEq"] = ge;
  o["cG"] = C.cG; o["cA"] = C.cA; o["cGP"] = C.cGP;
  plat_write_file(dataPath("chl_pro" + istr(proSlot + 1) + ".json"), o.dump());
  ProSlotInfo &s = g_info[proSlot]; s.on = true; s.nm = C.nm; s.team = C.L[C.me].n; s.ov = proOvr(); s.age = C.age; s.season = C.season; s.titles = C.titles; s.phase = C.phase; s.jc = teamCol(C.me); s.js = teamStr(C.me); s.num = C.num; s.sh = C.sh;
  writeIndex();
}
void proLoadSlot(int i) {
  std::string s; bool ok = false; if (!plat_read_file(dataPath("chl_pro" + istr(i + 1) + ".json"), s)) { g_info[i] = ProSlotInfo(); writeIndex(); return; }
  J o = J::parse(s, &ok); if (!ok || !o.isObj()) return;
  CR.reset(new Career()); proSlot = i; gearVer++;
  C.nm = o("nm").str(); C.num = o("num").i(19); C.sh = o("sh").str().empty() ? 'L' : o("sh").str()[0];
  { std::string ps = o("pos").str(); C.pos = ps.empty() ? 'C' : ps[0]; } C.cen = o.has("cen") ? o("cen").truthy() : C.pos == 'C'; C.coach = o.has("coach") ? o("coach").num() : 50; C.line = o.has("line") ? o("line").i(1) : 0;
  C.cOffer = o("cOf").i(); C.cGames = o("cG").i(); C.cFoW = o("cFW").num(); C.cFoT = o("cFT").num(); C.cLow = o("cLo").i(); C.coachMsg = o("cMsg").str(); C.age = o("age").i(20); C.season = o("season").i(1); C.titles = o("titles").i(); C.diff = o("diff").i(1);
  C.me = o("me").i(); C.opp = o("opp").i(); C.day = o("day").i(); C.round = o("round").i(); C.champ = o("champ").i(-1); C.sw = o("sw").i(); C.sl = o("sl").i(); C.pi = o("pi").i();
  C.phase = o("phase").str(); C.retWhy = o("retWhy").str(); C.cap = o("cap").num(70); C.lo = o("lo").num(.3); C.lastSt = o("lastSt").num(-1); C.ntc = o("ntc").truthy(); C.need = o("need").truthy(); C.cei = o("cei").truthy(); C.ntcTry = o("ntcTry").i();
  const J &L = o("L"); for (size_t k = 0; k < L.size() && k < (size_t)NALL; k++) { const J &x = L[k]; PTeam t; const TeamDef &T = k >= (size_t)NA && ADP.size() == (size_t)NTm ? ADP[k - NA] : TDP[k % TDP.size()]; t.n = T.n; t.ab = T.ab; t.city = T.city; t.d = T.d;
    t.s = x[0].num(); t.g = x[1].num(); t.q = x[2].num(); t.w = x[3].i(); t.l = x[4].i(); t.gf = x[5].i(); t.ga = x[6].i(); t.sk = x[7].i(); t.build = x[8].i(); t.pref = x[9].i(); t.needT = x[10].i(); C.L.push_back(t); }
  const J &P = o("P"); for (size_t k = 0; k < P.size(); k++) C.P.push_back(ppFrom(P[k].str()));
  for (auto &u : vs(o("used"))) C.used.insert(u);
  C.sched = vi(o("sched")); C.cal = vi(o("cal")); C.ci = o("ci").i();
  const J &H = o("hist"); for (size_t k = 0; k < H.size(); k++) { std::vector<int> v = vi(H[k]); if (v.size() < 15) continue; PHist h; h.d = v[0]; h.o = v[1]; h.hs = v[2]; h.as = v[3]; h.w = v[4]; h.po = v[5]; h.sim = v[6]; h.dnp = v[7]; h.r = v[8]; h.fs = v[9]; h.ln = v[10]; h.g = v[11]; h.a = v[12]; h.sog = v[13]; h.hits = v[14]; h.lg = v.size() > 15 ? v[15] : 0; C.hist.push_back(h); }
  const J &wk = o("wk"); C.wk.w = wk("w").i(-1); C.wk.season = wk("s").i(); C.wk.games = wk("n").i(); for (size_t k = 0; k < wk("g").size(); k++) { const J &x = wk("g")[k]; PGoal g; g.k = x[0].str(); g.txt = x[1].str(); g.tg = x[2].i(); g.pr = x[3].i(); g.xp = x[4].i(); g.cash = x[5].i(); g.done = x[6].i(); C.wk.goals.push_back(g); } C.wk.allPaid = wk("ap").truthy();
  for (size_t k = 0; k < o("offers").size(); k++) { const J &x = o("offers")[k]; POffer f; f.t = x("t").i(); f.ret = vs(x("ret")); f.why = x("why").str(); f.exp = x("exp").i(); C.offers.push_back(f); }
  if (o("treq").isObj()) { C.hasTreq = true; C.treqT = vi(o("treq")("teams")); C.treqAt = o("treq")("at").i(); }
  if (o("trade").isObj()) { const J &x = o("trade"); C.hasTrade = true; C.trade.from = x("from").i(); C.trade.to = x("to").i(); C.trade.why = x("why").str(); C.trade.title = x("title").str(); C.trade.ret = vs(x("ret")); C.showTrade = x("show").truthy(); }
  for (size_t k = 0; k < o("log").size(); k++) C.log.push_back({o("log")[k][0].str(), o("log")[k][1].i()});
  C.texts.clear(); for (size_t k = 0; k < o("tx").size(); k++) { const J &x = o("tx")[k]; PText t; t.from = x("f").str(); t.body = x("b").str(); { std::vector<int> g = vi(x("g")); if (g.size() >= 3) { t.gk = g[0]; t.gt = g[1]; t.gn = g[2]; } } t.kind = x("k").i(1); t.day = x("d").i(); t.season = x("s").i(1); t.ans = x("a").i(-1); t.read = x("r").truthy();
    for (int q = 0; q < 3 && q < (int)x("o").size(); q++) { t.opt[q] = x("o")[q].str(); t.re[q] = x("re")[q].str(); t.dc[q] = x("dc")[q].num(); } C.texts.push_back(t); }
  { const J &hm = o("hm"); for (int i = 0; i < HM_N; i++) for (int v = 0; v < HM_NV; v++) { size_t q = (size_t)(i * HM_NV + v); C.hmCnt[i][v] = q < hm.size() ? std::max(0, hm[q].i()) : 0; }
    for (int k = 0; k < HM_NP; k++) { C.hmPend[k] = (size_t)k < o("hmp").size() ? o("hmp")[(size_t)k].i() : 0; C.hmDoor[k] = (size_t)k < o("hmd").size() ? o("hmd")[(size_t)k].i() : 0; }
    C.hmCents = o("hmc").i(); C.hmOpened = o("hmo").i(); C.hmBest = o("hmb").i(-1); C.hmArrived = o("hma").i(); }
  C.tgoals.clear(); for (size_t k = 0; k < o("tg").size(); k++) { const J &x = o("tg")[k]; if (x.size() < 11) continue; TGoal g; g.from = x[0].str();
    int *f[9] = {&g.k, &g.tg, &g.pr, &g.games, &g.left, &g.xp, &g.cash, &g.st, &g.season}; for (int q = 0; q < 9; q++) *f[q] = x[(size_t)q + 1].i(); g.ch = x[10].num(); C.tgoals.push_back(g); }
  { std::vector<int> lk = vi(o("lk")); if (lk.size() >= 4) { C.look.skin = lk[0]; C.look.face = lk[1]; C.look.hair = lk[2]; C.look.hairC = lk[3]; } else C.look = lookOf(C.nm); lookOverride(C.nm, &C.look); }
  C.chem.clear(); { const J &ch = o("chem"); for (size_t k = 0; k < ch.k.size(); k++) C.chem[ch.k[k]] = ch.a[k].num(); }
  auto brL = [&](const J &B, std::vector<std::vector<PSeries>> &out) { for (size_t k = 0; k < B.size(); k++) { std::vector<PSeries> r; const J &rr = B[k]; for (size_t j = 0; j < rr.size(); j++) { std::vector<int> v = vi(rr[j]); if (v.size() < 5) continue; PSeries s; s.a = v[0]; s.b = v[1]; s.wa = v[2]; s.wb = v[3]; s.w = v[4]; r.push_back(s); } out.push_back(r); } };
  brL(o("br"), C.br); brL(o("obr"), C.obr); C.ochamp = o("ochamp").i(-1);
  C.aG = o("aG").i(); C.aA = o("aA").i(); C.aGP = o("aGP").i(); C.calder = o("calder").i(); C.debut = o("debut").i(); C.calls = o("calls").i(); C.orgMsg = o("orgMsg").str(); C.mvG = o("mvG").i(99);
  C.sgH = o("sgH").str(); C.sgA = o("sgA").str();
  C.draftDone = o("draftDone").truthy(); C.dOrder = vi(o("dOrder")); C.dPick = o("dPick").i(); C.dNm = vs(o("dNm"));
  C.ldY = o("ldY").i(); for (size_t k = 0; k < o("ldPicks").size(); k++) { const J &x = o("ldPicks")[k]; C.ldPicks.push_back({x[0].str(), x[1].i(), x[2].i() != 0, x[3].i(), x[4].i()}); }
  C.xp = o("xp").i(); C.money = o("money").i(); g_stats = o("stats"); statsDefaults(g_stats);
  const J &sx = o("sxp"); for (size_t k = 0; k < sx.k.size(); k++) C.sxp[sx.k[k]] = sx.a[k].num();
  homeFromJ(o("home"));
  { std::vector<int> v = vi(o("st")); if (v.size() >= 10) { PSeason &S = C.st; S.gp = v[0]; S.sh = v[1]; S.sog = v[2]; S.g = v[3]; S.a = v[4]; S.pass = v[5]; S.hits = v[6]; S.pim = v[7]; S.blk = v[8]; S.toi = v[9] / 60.0; S.pm = v.size() >= 11 ? v[10] : 0; }
    else { int lg = proLg(); for (auto &h : C.hist) if (!h.po && h.ln && !h.dnp && h.lg == lg) { C.st.gp++; C.st.g += h.g; C.st.a += h.a; C.st.sog += h.sog; C.st.sh += h.sog; C.st.hits += h.hits; C.st.toi += 16; } } }
  { const J &y = o("yr"); C.yr.season = y("s").i(-1); for (size_t k = 0; k < y("g").size(); k++) { const J &x = y("g")[k]; PGoal g; g.k = x[0].str(); g.txt = x[1].str(); g.tg = x[2].i(); g.pr = x[3].i(); g.xp = x[4].i(); g.cash = x[5].i(); g.done = x[6].i(); C.yr.goals.push_back(g); } C.yr.allPaid = y("ap").truthy(); }
  C.perfB = o("perfB").truthy(); C.deals = o.has("deals") ? o("deals").i() : (C.season > 3 ? 1 : 0); C.newsN = o.has("newsN") ? o("newsN").i() : (int)C.log.size(); C.newsSeen = o.has("newsSeen") ? o("newsSeen").i() : C.newsN; C.callSeen = o("callSeen").i(); C.perkOwn = vs(o("perkOwn")); C.perkEq = vs(o("perkEq")); const J &pl = o("perkLv"); for (size_t k = 0; k < pl.k.size(); k++) C.perkLv[pl.k[k]] = pl.a[k].i(1);
  for (auto &g : vs(o("gearOwn"))) C.gearOwn.insert(g); const J &ge = o("gearEq"); for (size_t k = 0; k < ge.k.size(); k++) C.gearEq[ge.k[k]] = ge.a[k].i();
  C.cG = o("cG").i(); C.cA = o("cA").i(); C.cGP = o("cGP").i();
  if ((C.L.size() != (size_t)NTm && C.L.size() != (size_t)NALL) || !mine()) { CR.reset(); proSlot = -1; return; }
  if (C.L.size() == (size_t)NTm) { buildAHL(true); if (!C.debut) C.debut = C.age - (C.season - 1); }   // a career from before the AHL: add the minor league
  setStars(false); recalcAll(); ensureWeek(); g_meSh = C.sh; g_pendUp = -1;
}
void proDelete(int i) { if (i < 0 || i > 2) return; g_info[i] = ProSlotInfo(); plat_write_file(dataPath("chl_pro" + istr(i + 1) + ".json"), "{}"); if (proSlot == i) { CR.reset(); proSlot = -1; } writeIndex(); }
#undef C

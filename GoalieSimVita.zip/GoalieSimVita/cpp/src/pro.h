// CHL 2026 native - BE A PRO (skater careers), ported from the legacy build's career mode: the real 32-team league,
// draft night, an 80-game season on a calendar with off days, weekly goals, training, the gear shop, upgrades and
// perks paid for with XP, injuries and call-ups, AI trades, the trade deadline, contracts (extensions, no-trade
// clauses, trade requests, offers, free agency), 16-team best-of-3 playoffs, the off-season (aging, the draft, free
// agency, retirements) and retirement at 40 (or a broken back). Goalie careers come later.
// The AHL: every NHL club has its real farm team (C.L[32..63], C.L[32 + i] belongs to C.L[i]). You are drafted at 18
// and start in the minors; the organization calls you up when your play earns it, sends you down, or trades you to
// another AHL club. The AHL runs its own season, standings, scoring race and Calder Cup playoffs.
// Saves: chl_pro.json {slots[3], hof}. The legacy goalie4.json careers are left as they are.
#pragma once
#include "menu.h"
#include "league.h"
#include <memory>
#include <set>

constexpr int PRO_GAMES = 80, PRO_ROS = 9, PRO_NG = 2, PRO_DEADLINE = 60, NA = 32, NALL = 64;
extern const char *DIVN[4];
extern const char *ADIVN[4];
extern const char *RN[4];

// a career league player (skater or goalie). The engine plays src / gsrc directly (ratings, traits, perks).
struct PP {
  bool g = false, me = false, star = false, real = false;
  int t = -1, age = 25; double pot = 5, dev = 1, boost = 0;
  double sal = 1; int cy = 1;
  int gl = 0, as = 0;                 // season goals / assists (skaters)
  int sa = 0, sv = 0, gp = 0;         // season shots against / saves / games (goalies)
  int inj = 0; std::string it;        // games out, what's hurt
  bool isCu = false; std::string cu;  // a call-up, filling in for cu ("" = a permanent call-up)
  int from = -1, dY = 0, dN = 0;      // free agent from / drafted (season, pick)
  int home = -1;                      // an AHL player called up to cover an injury: his AHL club
  bool hasExt = false; double extSal = 0; int extYrs = 0; bool extNtc = false;
  Src src; GSrc gsrc;
  // overall cache
  double ocP = -1, ocA = -1; int ocAr = -1, ocV = 0;
  const std::string &nm() const { return g ? gsrc.nm : src.nm; }
};
struct PTeam { std::string n, ab, city; int d = 0; double s = 4.5, g = 5; int w = 0, l = 0, gf = 0, ga = 0, sk = 0; double q = 4.5; bool build = false; int pref = 0, needT = 0; };
struct PHist { int d = 0, o = 0, hs = 0, as = 0; bool w = false, po = false, sim = false, dnp = false; int r = 0, fs = 50; bool ln = false; int g = 0, a = 0, sog = 0, hits = 0, lg = 0; };
struct PGoal { std::string k, txt; int tg = 1, pr = 0, xp = 25, cash = 25; bool done = false; };
struct PWeek { int w = -1, season = 0, games = 0; std::vector<PGoal> goals; bool allPaid = false; };   // allPaid: the all-of-them bonus is paid
struct POffer { int t = 0; std::vector<std::string> ret; std::string why; int exp = 0; };
struct PNeg { double base = 1; int yrs = 2, pat = 2, push = 0, bonus = 0; bool perf = false, ntc = false, forced = false, fin = false, sure = false; std::string msg; };
struct PSeason { int gp = 0, sh = 0, sog = 0, g = 0, a = 0, pass = 0, hits = 0, pim = 0, blk = 0; double toi = 0; };   // your season, for the Performance app
struct PSeries { int a = 0, b = 0, wa = 0, wb = 0, w = -1; bool proj = false; };
struct PTrade { int from = 0, to = 0; std::string why, title; std::vector<std::string> ret; };
struct PLog { std::string s; int y = 1; };
struct PDraftPick { std::string nm; int t = 0; bool g = false; int ov = 0, pot = 0; };

struct Career {
  std::string nm = "ROOKIE"; int num = 19; char sh = 'L';
  int age = 20, season = 1, titles = 0, diff = 1; bool fwd = true;
  int me = 0, opp = 1, day = 0, round = 0, champ = -1, sw = 0, sl = 0, pi = 0;
  std::string phase = "reg", retWhy;   // reg / po / over / retired
  double cap = 70, lo = .3, lastSt = -1, lm = 6, gmn = 5; std::string lmT;
  bool ntc = false, need = false, cei = false, showTrade = false; int ntcTry = 0;
  std::vector<PTeam> L; std::vector<std::unique_ptr<PP>> P; std::set<std::string> used;
  std::vector<int> sched, cal; int ci = 0; std::vector<PHist> hist; PWeek wk;
  std::vector<POffer> offers; bool hasTreq = false; std::vector<int> treqT; int treqAt = 0;
  bool hasNeg = false; PNeg neg; bool hasTrade = false; PTrade trade;
  std::vector<PLog> log; std::vector<std::vector<PSeries>> br; std::string sgH, sgA;
  // draft night
  bool draftDone = false; std::vector<int> dOrder; int dPick = 0; std::vector<std::string> dNm;
  int ldY = 0; std::vector<PDraftPick> ldPicks;
  // you: XP, cash, ratings, rating progress, perks, gear
  int xp = 0, money = 0; std::map<std::string, double> sxp;
  std::vector<std::string> perkOwn, perkEq; std::map<std::string, int> perkLv;
  std::set<std::string> gearOwn; std::map<std::string, int> gearEq;
  std::string injMsg, wkMsg, offMsg;
  // career totals (for the retired screen): NHL, then AHL
  int cG = 0, cA = 0, cGP = 0, aG = 0, aA = 0, aGP = 0, calder = 0, debut = 0, calls = 0;
  // the other league's playoffs (simulated when yours start) and the organization's last word on you
  std::vector<std::vector<PSeries>> obr; int ochamp = -1; std::string orgMsg; int mvG = 99;   // games since you last changed teams
  double lmA[2] = {6, 6}, gmA[2] = {5, 5};   // league means (not saved)
  PSeason st; PWeek yr;                      // this season's line; the season's bonus goals (yr.goals)
  bool perfB = false; int deals = 0;         // performance bonuses in your deal; contracts signed after the entry-level one
  int newsN = 0, newsSeen = 0;               // league news written / read (the News app's badge)
  int callSeen = 0;                          // the last incoming call you answered or declined (a hash of what it was about)
  // your position and the coach: pos is what you signed up as (C / L / R); cen: you're the one taking your line's draws
  // right now (a winger can be moved there, a center can lose it). coach: what he thinks of you (0-100) - it sets your line
  char pos = 'C'; bool cen = true; double coach = 55; int line = 1, cOffer = 0, cGames = 0, cLow = 0; double cFoW = 0, cFoT = 0;
  double coachD = 0; int lineWas = -1;       // the last game's change in his view, and your line before it (not saved)
  std::string coachMsg;                      // the coach's last word (after a game)
};
extern std::unique_ptr<Career> CR;
extern int proSlot;
extern std::string proMsg;          // the last sim / training message on the hub
extern int proGainXP;               // XP earned in the game just played

// ---- logic (pro.cpp)
inline bool isAHL(int t) { return t >= NA; }
inline int orgOf(int t) { return t % NA; }
int proLg();                         // the league you play in: 0 NHL, 1 AHL
std::vector<int> lgTeams(int lg);
std::string divName(int t);
std::string teamFull(int t);         // "Boston Bruins", "Providence Bruins"
int callBar();                       // the overall your NHL club needs to see (its weakest regular)
int readiness();                     // how the organization rates you right now
std::string prospectNote();          // the organization's view, one line
void proLine(int &gp, int &g, int &a);   // your regular season so far in the league you play in
PP *youMe();
int proOvr();                        // your overall (skater ratings)
int ovQ(PP *q);
int potOv(const PP *q);
double market(int ov);
double infl();
double capOf();
double payroll(int t);
std::vector<PP *> teamS(int t, bool healthy = false, bool core = false);
std::vector<PP *> teamG(int t);
PP *homeG(); PP *awayG();
bool userHurt();
bool offDay();
bool tradeOpen();
int trainCost();
void ensureYear();   // the season's bonus goals (Goals app)
// after a game (the post-game GOALS page): the week's and the season's goals as the game left them, where they stood
// before it, the all-goals bonuses it paid, and the performance bonus (per goal / assist)
struct GoalRes { PWeek wk, yr; std::vector<int> preW, preY; int allW = 0, allY = 0, perf = 0, pg = 0, pa = 0; };
const GoalRes &proGoalRes();
int weekAllBonus(); int yearAllBonus();
int yearBonusCash(const PGoal &g);
struct SkillGain { std::string k; double a, b; };   // a rating's level + progress before and after a game
void proSkillSnap(); std::vector<SkillGain> proSkillGains();
bool proAptInput(uint32_t press, const Pad &pad, const Touch &touch);
bool canTrain();
double perfScore(); double loyalty(); int gamePay();
double ntcChance(bool cut);
std::string calDate(int i);
std::vector<int> standOrd(std::vector<int> ids);
struct Seeds { std::vector<std::pair<int, int>> pairs; std::vector<int> all, wc; std::vector<std::vector<int>> top; };
Seeds seeds(int conf, int lg = 0);
std::string ordn(int n);
struct TRank { int all, div; }; TRank teamRank(int t);
std::string headline();

void proNew(int slot, const std::string &nm, int num, int diff, char pos = 'C', char sh = 'L');
void proLoadSlot(int i); void proSave(); void proLoadAll(const std::string &s); void proDelete(int i);
struct ProSlotInfo { bool on = false; std::string nm, team; int ov = 0, age = 0, season = 0, titles = 0; std::string phase; };
ProSlotInfo proSlotInfo(int i);
extern int proHofCareers, proHofBest;
void proSimGames(int n); void proSimHealthy(); void proSkipDay();
void proDoTrain(int i);
void proUpgrade(const std::string &k, int n); int proCostN(const std::string &k, int n, int *m);
void proNextSeason();
void negStart(bool forced); double negSal(); int negBonusCash(); void negPush(); void negAccept(); void proFreeAgency();
void askNTC(bool cut); void submitTradeReq(const std::vector<int> &l); void acceptOffer(int i); void rejectOffer(int i);
void gearTap(const std::string &cat, int i);
struct GearIt { const char *n; int c; const char *fx; double inj; const char *d; };
struct GearCat { const char *k, *n; std::vector<GearIt> it; };
extern const std::vector<GearCat> GEARF;
std::string fxTxt(const char *fx);
double gearInj();
void gearChanged();   // the gear or the apartment changed: re-add the bonuses
struct InjRisk { double base = 0, gear = 1, age = 1, hits = 1, hitsPG = 0, p = 0; int games = 0; };
InjRisk injRisk();
int pkMine(const std::string &id);
int pkUpCost(const PerkDef &pk, int next);
void pkBuy(const std::string &id); void pkUp(const std::string &id); void pkEquip(const std::string &id);
int proUserTier(const PerkDef &pk);

// ---- the game (engine hooks)
bool proInGame();                    // a Be a Pro game is on (XP and rating growth count)
void award(int n);
void fillStat(const std::string &k, double a);
std::string xpTag(const std::string &s, int n);   // "HIT!  +2 XP" in Be a Pro, "HIT!" anywhere else
void proGameRosters(Rosters &R);
std::vector<PerkE> proUserPerks();
void proCredit(Skater *sc, Skater *as);
bool proTakeDraw(double mateFo, bool special);
void proCoachAnswer(bool yes);   // the coach asked you to move to center
double proFoPct();               // your recent faceoff win rate   // this faceoff: do you take it (vs your best linemate)?   // a goal in a career game (season stats)
void proAfterGame(bool won, bool sim);    // the game is over (sim: the rest of it was simulated)
bool proCanPlay();
void proUserShare(double &pg, double &pa);   // your chance to score / assist each team goal (sims)

// ---- screens (pro_draw.cpp)
void drawPro();
bool proTap(const std::string &id);
struct PvTeam; struct Skater; struct Goalie;
bool proPreview(int ti, PvTeam &o, const std::vector<Skater *> &on, const Goalie &G);
bool proAptWorld();
bool proInPhone();   // a career app is open on the phone (its screen is drawn inside it)   // walking around the apartment (no phone, no panel)
bool proAptInput(uint32_t press, const Pad &pad, const Touch &touch);
void proShoulder(int d);
void proEnter();
void proContinue(int i);           // CONTINUE on the main menu                     // BE A PRO from the main menu
extern double proBusyT;

// ---- practice (prac.cpp)
extern int pracKind, pracOv;         // 0 skating gates, 1 shooting, 2 aim
void drawPractice();
bool pracTap(const std::string &id);
void pracSetup(); bool pracUpdate(double dt); void pracGoal(int team); void pracDraw(const Layout &lay);

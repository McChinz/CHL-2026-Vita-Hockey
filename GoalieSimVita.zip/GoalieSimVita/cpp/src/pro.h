// CHL 2026 native - BE A PRO (skater careers), ported from the legacy build's career mode: the real 32-team league,
// draft night, an 80-game season on a calendar with off days, weekly goals, training, the gear shop, upgrades and
// perks paid for with XP, injuries and call-ups, AI trades, the trade deadline, contracts (extensions, no-trade
// clauses, trade requests, offers, free agency), 16-team best-of-3 playoffs, the off-season (aging, the draft, free
// agency, retirements) and retirement at 40 (or a broken back). Goalie careers come later.
// The AHL: every NHL club has its real farm team (C.L[32..63], C.L[32 + i] belongs to C.L[i]). You are drafted at 18
// and start in the minors; the organization calls you up when your play earns it, sends you down, or trades you to
// another AHL club. The AHL runs its own season, standings, scoring race and Calder Cup playoffs.
// Saves: chl_pro.json {slots[3], hof}. The legacy goalie4.json careers are left as they are.
#pragma once
#include "menu.h"
#include "league.h"
#include <memory>
#include <set>

constexpr int PRO_GAMES = 80, PRO_ROS = 9, PRO_NG = 2, PRO_DEADLINE = 60, NA = 32, NALL = 64;
extern const char *DIVN[4];
extern const char *ADIVN[4];
extern const char *RN[4];

// a career league player (skater or goalie). The engine plays src / gsrc directly (ratings, traits, perks).
struct PP {
  bool g = false, me = false, star = false, real = false;
  int t = -1, age = 25; double pot = 5, dev = 1, boost = 0;
  double sal = 1; int cy = 1;
  int gl = 0, as = 0;                 // season goals / assists (skaters)
  int sa = 0, sv = 0, gp = 0;         // season shots against / saves / games (goalies)
  int inj = 0; std::string it;        // games out, what's hurt
  bool isCu = false; std::string cu;  // a call-up, filling in for cu ("" = a permanent call-up)
  int from = -1, dY = 0, dN = 0;      // free agent from / drafted (season, pick)
  int home = -1;                      // an AHL player called up to cover an injury: his AHL club
  bool hasExt = false; double extSal = 0; int extYrs = 0; bool extNtc = false;
  Src src; GSrc gsrc;
  // overall cache
  double ocP = -1, ocA = -1; int ocAr = -1, ocV = 0;
  const std::string &nm() const { return g ? gsrc.nm : src.nm; }
};
struct PTeam { std::string n, ab, city; int d = 0; double s = 4.5, g = 5; int w = 0, l = 0, gf = 0, ga = 0, sk = 0; double q = 4.5; bool build = false; int pref = 0, needT = 0; };
struct PHist { int d = 0, o = 0, hs = 0, as = 0; bool w = false, po = false, sim = false, dnp = false; int r = 0, fs = 50; bool ln = false; int g = 0, a = 0, sog = 0, hits = 0, lg = 0; };
struct PGoal { std::string k, txt; int tg = 1, pr = 0, xp = 25, cash = 25; bool done = false; };
struct PWeek { int w = -1, season = 0, games = 0; std::vector<PGoal> goals; };
struct POffer { int t = 0; std::vector<std::string> ret; std::string why; int exp = 0; };
struct PNeg { double base = 1; int yrs = 2, pat = 2, push = 0; bool ntc = false, forced = false, fin = false, sure = false; std::string msg; };
struct PSeries { int a = 0, b = 0, wa = 0, wb = 0, w = -1; bool proj = false; };
struct PTrade { int from = 0, to = 0; std::string why, title; std::vector<std::string> ret; };
struct PLog { std::string s; int y = 1; };
struct PDraftPick { std::string nm; int t = 0; bool g = false; int ov = 0, pot = 0; };

struct Career {
  std::string nm = "ROOKIE"; int num = 19; char sh = 'L';
  int age = 20, season = 1, titles = 0, diff = 1; bool fwd = true;
  int me = 0, opp = 1, day = 0, round = 0, champ = -1, sw = 0, sl = 0, pi = 0;
  std::string phase = "reg", retWhy;   // reg / po / over / retired
  double cap = 70, lo = .3, lastSt = -1, lm = 6, gmn = 5; std::string lmT;
  bool ntc = false, need = false, cei = false, showTrade = false; int ntcTry = 0;
  std::vector<PTeam> L; std::vector<std::unique_ptr<PP>> P; std::set<std::string> used;
  std::vector<int> sched, cal; int ci = 0; std::vector<PHist> hist; PWeek wk;
  std::vector<POffer> offers; bool hasTreq = false; std::vector<int> treqT; int treqAt = 0;
  bool hasNeg = false; PNeg neg; bool hasTrade = false; PTrade trade;
  std::vector<PLog> log; std::vector<std::vector<PSeries>> br; std::string sgH, sgA;
  // draft night
  bool draftDone = false; std::vector<int> dOrder; int dPick = 0; std::vector<std::string> dNm;
  int ldY = 0; std::vector<PDraftPick> ldPicks;
  // you: XP, cash, ratings, rating progress, perks, gear
  int xp = 0, money = 0; std::map<std::string, double> sxp;
  std::vector<std::string> perkOwn, perkEq; std::map<std::string, int> perkLv;
  std::set<std::string> gearOwn; std::map<std::string, int> gearEq;
  std::string injMsg, wkMsg, offMsg;
  // career totals (for the retired screen): NHL, then AHL
  int cG = 0, cA = 0, cGP = 0, aG = 0, aA = 0, aGP = 0, calder = 0, debut = 0, calls = 0;
  // the other league's playoffs (simulated when yours start) and the organization's last word on you
  std::vector<std::vector<PSeries>> obr; int ochamp = -1; std::string orgMsg; int mvG = 99;   // games since you last changed teams
  double lmA[2] = {6, 6}, gmA[2] = {5, 5};   // league means (not saved)
};
extern std::unique_ptr<Career> CR;
extern int proSlot;
extern std::string proMsg;          // the last sim / training message on the hub
extern int proGainXP;               // XP earned in the game just played

// ---- logic (pro.cpp)
inline bool isAHL(int t) { return t >= NA; }
inline int orgOf(int t) { return t % NA; }
int proLg();                         // the league you play in: 0 NHL, 1 AHL
std::vector<int> lgTeams(int lg);
std::string divName(int t);
std::string teamFull(int t);         // "Boston Bruins", "Providence Bruins"
int callBar();                       // the overall your NHL club needs to see (its weakest regular)
int readiness();                     // how the organization rates you right now
std::string prospectNote();          // the organization's view, one line
void proLine(int &gp, int &g, int &a);   // your regular season so far in the league you play in
PP *youMe();
int proOvr();                        // your overall (skater ratings)
int ovQ(PP *q);
int potOv(const PP *q);
double market(int ov);
double infl();
double capOf();
double payroll(int t);
std::vector<PP *> teamS(int t, bool healthy = false, bool core = false);
std::vector<PP *> teamG(int t);
PP *homeG(); PP *awayG();
bool userHurt();
bool offDay();
bool tradeOpen();
int trainCost();
bool canTrain();
double perfScore(); double loyalty(); int gamePay();
double ntcChance(bool cut);
std::string calDate(int i);
std::vector<int> standOrd(std::vector<int> ids);
struct Seeds { std::vector<std::pair<int, int>> pairs; std::vector<int> all, wc; std::vector<std::vector<int>> top; };
Seeds seeds(int conf, int lg = 0);
std::string ordn(int n);
struct TRank { int all, div; }; TRank teamRank(int t);
std::string headline();

void proNew(int slot, const std::string &nm, int num, int diff);
void proLoadSlot(int i); void proSave(); void proLoadAll(const std::string &s); void proDelete(int i);
struct ProSlotInfo { bool on = false; std::string nm, team; int ov = 0, age = 0, season = 0, titles = 0; std::string phase; };
ProSlotInfo proSlotInfo(int i);
extern int proHofCareers, proHofBest;
void proSimGames(int n); void proSimHealthy(); void proSkipDay();
void proDoTrain(int i);
void proUpgrade(const std::string &k, int n); int proCostN(const std::string &k, int n, int *m);
void proNextSeason();
void negStart(bool forced); double negSal(); void negPush(); void negAccept(); void proFreeAgency();
void askNTC(bool cut); void submitTradeReq(const std::vector<int> &l); void acceptOffer(int i); void rejectOffer(int i);
void gearTap(const std::string &cat, int i);
struct GearIt { const char *n; int c; const char *fx; double inj; const char *d; };
struct GearCat { const char *k, *n; std::vector<GearIt> it; };
extern const std::vector<GearCat> GEARF;
std::string fxTxt(const char *fx);
double gearInj();
int pkMine(const std::string &id);
int pkUpCost(const PerkDef &pk, int next);
void pkBuy(const std::string &id); void pkUp(const std::string &id); void pkEquip(const std::string &id);
int proUserTier(const PerkDef &pk);

// ---- the game (engine hooks)
bool proInGame();                    // a Be a Pro game is on (XP and rating growth count)
void award(int n);
void fillStat(const std::string &k, double a);
std::string xpTag(const std::string &s, int n);   // "HIT!  +2 XP" in Be a Pro, "HIT!" anywhere else
void proGameRosters(Rosters &R);
std::vector<PerkE> proUserPerks();
void proCredit(Skater *sc, Skater *as);   // a goal in a career game (season stats)
void proAfterGame(bool won, bool sim);    // the game is over (sim: the rest of it was simulated)
bool proCanPlay();
void proUserShare(double &pg, double &pa);   // your chance to score / assist each team goal (sims)

// ---- screens (pro_draw.cpp)
void drawPro();
bool proTap(const std::string &id);
void proShoulder(int d);
void proEnter();
void proContinue(int i);           // CONTINUE on the main menu                     // BE A PRO from the main menu
extern double proBusyT;

// ---- practice (prac.cpp)
extern int pracKind, pracOv;         // 0 skating gates, 1 shooting, 2 aim
void drawPractice();
bool pracTap(const std::string &id);
void pracSetup(); bool pracUpdate(double dt); void pracGoal(int team); void pracDraw(const Layout &lay);

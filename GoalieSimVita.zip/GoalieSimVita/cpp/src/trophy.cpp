// trophy.cpp - see trophy.h. The calls into the console's trophy library run on their own thread: registering the
// pack takes a moment the first time (the console installs it) and an unlock waits on the system, so the game queues
// the ids and moves on.
#include "trophy.h"
#include "pro.h"
#include "apt.h"
#include "hockeymon.h"
#include "platform.h"
#include <string>
#include <vector>
#include <cstring>
#include <cstdint>

static bool g_sent[TR_COUNT];   // asked for this session (the console keeps the real record)
static bool g_ok = false;

#if defined(CHL_TROPHIES)
#include <psp2/sysmodule.h>
#include <psp2/kernel/threadmgr.h>
#include <psp2/common_dialog.h>
#include <taihen.h>
#include <psp2/io/stat.h>
#include <psp2/io/fcntl.h>
#include <cstdio>
// The pack ships at app0:trophy/TROPHY.TRP: a VPK with anything under sce_sys/trophy is refused by the installer
// (error 0x8010320D). The trophy library reads it from app0:sce_sys/trophy/<id>/, so the first run (and any run after
// an update changes it) copies it there - app0 is this app's own folder, ux0:app/GOAL00002, writable to an unsafe app.
static void placePack() {
  const std::string src = "app0:trophy/TROPHY.TRP", dir = "ux0:app/GOAL00002/sce_sys/trophy", sub = dir + "/NPWR90226_00", dst = sub + "/TROPHY.TRP";
  std::string a, b; if (!plat_read_file(src, a) || a.empty()) { plat_log("trophy: no pack in the app"); return; }
  if (plat_read_file(dst, b) && b == a) { plat_log("trophy: pack in place"); return; }
  int m1 = sceIoMkdir(dir.c_str(), 0777), m2 = sceIoMkdir(sub.c_str(), 0777);
  SceUID fd = sceIoOpen(dst.c_str(), SCE_O_WRONLY | SCE_O_CREAT | SCE_O_TRUNC, 0777); int w = -1;
  if (fd >= 0) { w = sceIoWrite(fd, a.data(), (SceSize)a.size()); sceIoClose(fd); }
  char buf[160]; snprintf(buf, sizeof buf, "trophy: pack placed mkdir %08x %08x open %08x wrote %d of %d", (unsigned)m1, (unsigned)m2, (unsigned)fd, w, (int)a.size()); plat_log(buf);
}
// a crash in the trophy library must not stop the game launching: each step is noted in a file first, and a run that
// finds a step still noted (the last run died there) leaves trophies off - until a new build, which tries again
static const char *TR_STEP = "ux0:data/GoalieSimNative/trophy_step.txt";
static const std::string TR_BUILD = std::string(__DATE__) + " " + __TIME__;
static void step(const char *s) { plat_write_file(TR_STEP, TR_BUILD + "|" + s); plat_log(std::string("trophy: ") + s + "..."); }
static void stepDone() { plat_write_file(TR_STEP, TR_BUILD + "|ok"); }
// The trophy functions are looked up by NID at run time (the SDK's stub library doesn't carry all of them). A Vita game
// installs its pack through the trophy setup dialog (a system common dialog), not sceNpTrophyRegisterContext.
// NIDs as retail games import them (SceNpTrophy, SceCommonDialog).
typedef int SceNpTrophyContext; typedef int SceNpTrophyHandle; typedef int SceNpTrophyId;
typedef struct { char data[9]; char term; unsigned char num; char dummy; } NpCommId;
typedef struct { unsigned char data[160]; } NpCommSig;
typedef struct { unsigned int sdkVersion; SceCommonDialogParam commonParam; SceNpTrophyContext context; unsigned int options; unsigned char reserved[128]; } TrSetupParam;
typedef struct { int result; unsigned char reserved[128]; } TrSetupResult;
static int (*pInit)(void *);
static int (*pCreateContext)(SceNpTrophyContext *, const NpCommId *, const NpCommSig *, unsigned long long);
static int (*pCreateHandle)(SceNpTrophyHandle *);
static int (*pUnlock)(SceNpTrophyContext, SceNpTrophyHandle, SceNpTrophyId, SceNpTrophyId *);
static int (*pDlgInit)(const TrSetupParam *); static int (*pDlgStatus)(void); static int (*pDlgResult)(TrSetupResult *); static int (*pDlgTerm)(void);
static SceUID g_mx = -1; static std::vector<int> g_q; static SceUID g_sema = -1;
struct Lk { Lk() { sceKernelLockMutex(g_mx, 1, nullptr); } ~Lk() { sceKernelUnlockMutex(g_mx, 1); } };
static SceNpTrophyContext g_ctx = -1; static SceNpTrophyHandle g_h = -1;
static volatile int g_stage = 0;   // 0 starting, 1 ready for the setup dialog (main thread), 2 dialog up, 3 ready, -1 off
template <class F> static bool look(const char *mod, unsigned nid, F &f) { uintptr_t p = 0; int r = taiGetModuleExportFunc(mod, TAI_ANY_LIBRARY, nid, &p);
  if (r < 0 || !p) { plat_log("trophy: no " + std::string(mod) + " export " + std::to_string(nid) + " (" + std::to_string(r) + ")"); return false; } f = (F)p; return true; }
static int trophyThread(SceSize, void *) {
  { std::string prev; plat_read_file(TR_STEP, prev); size_t bar = prev.find('|');
    if (bar != std::string::npos && prev.substr(0, bar) == TR_BUILD && prev.substr(bar + 1) != "ok") { plat_log("trophy: off - this build crashed at '" + prev.substr(bar + 1) + "' last time"); g_stage = -1; return 0; } }
  step("place pack"); placePack();
  step("load module"); int r = sceSysmoduleLoadModule(SCE_SYSMODULE_NP_TROPHY); plat_log("trophy: module " + std::to_string(r));
  step("find functions");
  bool ok = r >= 0 && look("SceNpTrophy", 0x34516838, pInit) && look("SceNpTrophy", 0xC49FD33F, pCreateContext) && look("SceNpTrophy", 0x4EBC6977, pCreateHandle)
    && look("SceNpTrophy", 0xB397AA24, pUnlock) && look("SceCommonDialog", 0x9E2C02C9, pDlgInit) && look("SceCommonDialog", 0xC3A59547, pDlgStatus)
    && look("SceCommonDialog", 0xE37069D5, pDlgResult) && look("SceCommonDialog", 0xA81082DD, pDlgTerm);
  if (ok) { step("init"); r = pInit(nullptr); plat_log("trophy: init " + std::to_string(r)); ok = r >= 0; }
  if (ok) { NpCommId id = {}; const char *c = "NPWR90226"; for (int i = 0; i < 9; i++) id.data[i] = c[i]; id.num = 0;
    NpCommSig sig = {};   // (NoTrpDrm turns the signature check off)
    step("create context"); r = pCreateContext(&g_ctx, &id, &sig, 0); plat_log("trophy: context " + std::to_string(r)); ok = r >= 0; }
  if (ok) { step("create handle"); r = pCreateHandle(&g_h); ok = r >= 0; }
  if (!ok) stepDone();
  if (!ok) { g_stage = -1; plat_log("trophy: unavailable (is NoTrpDrm installed?) " + std::to_string(r)); return 0; }
  step("setup dialog"); g_stage = 1;   // the main thread runs the setup dialog (it installs the pack), then lets the unlocks through
  for (;;) { sceKernelWaitSema(g_sema, 1, nullptr); if (g_stage != 3) continue;
    for (;;) { int t = -1; { Lk l; if (!g_q.empty()) { t = g_q.front(); g_q.erase(g_q.begin()); } } if (t < 0) break;
      SceNpTrophyId plat = -1; int u = pUnlock(g_ctx, g_h, t, &plat); plat_log("trophy " + std::to_string(t) + ": " + std::to_string(u)); } }
  return 0;
}
// every frame on the main thread (before the swap): runs the setup dialog. true while it's on screen (vitaGL then draws it)
bool trophyTick() {
  if (g_stage == 1) { TrSetupParam p; memset(&p, 0, sizeof p); _sceCommonDialogSetMagicNumber(&p.commonParam); p.sdkVersion = 0x03150021; p.context = g_ctx;
    int r = pDlgInit(&p); plat_log("trophy: setup dialog " + std::to_string(r)); g_stage = r >= 0 ? 2 : -1; if (r < 0) stepDone(); }
  if (g_stage == 2) { int st = pDlgStatus(); if (st == SCE_COMMON_DIALOG_STATUS_FINISHED) { TrSetupResult res; memset(&res, 0, sizeof res); pDlgResult(&res); pDlgTerm();
      stepDone(); plat_log("trophy: setup result " + std::to_string(res.result)); g_ok = res.result == 0; g_stage = g_ok ? 3 : -1; if (g_ok) sceKernelSignalSema(g_sema, 1); return false; }
    return true; }
  return false;
}
void trophyInit() {
  g_sema = sceKernelCreateSema("chl_trophy", 0, 0, 64, nullptr); g_mx = sceKernelCreateMutex("chl_trophy_q", 0, 0, nullptr);
  // (0x10000100 is the default user priority; an offset past the user range makes the call fail, which v0.7's first
  // trophy build did: +40 - no thread, so nothing at all happened)
  SceUID th = sceKernelCreateThread("chl_trophy", trophyThread, 0x10000100, 0x40000, 0, 0, nullptr);
  int r = th >= 0 ? sceKernelStartThread(th, 0, nullptr) : th; plat_log("trophy: start " + std::to_string(th) + " / " + std::to_string(r));
}
void trophyUnlock(int id) {
  if (id <= 0 || id >= TR_COUNT || g_sent[id]) return; g_sent[id] = true;   // (the platinum comes by itself)
  if (g_mx >= 0) { Lk l; g_q.push_back(id); } if (g_sema >= 0 && g_stage == 3) sceKernelSignalSema(g_sema, 1);
}
#else
// the PC build: just logs them (the tests check it)
void trophyInit() {}
bool trophyTick() { return false; }
void trophyUnlock(int id) { if (id <= 0 || id >= TR_COUNT || g_sent[id]) return; g_sent[id] = true; plat_log("TROPHY " + std::to_string(id)); }
#endif
bool trophyActive() { return g_ok; }

// Be a Pro: what the career already shows (its game log, the draft, the apartment, the binder, the texts)
void trophyCheckPro() {
  if (!CR) return; const Career &c = *CR; int pts = 0;
  for (auto &h : c.hist) { if (!h.ln || h.dnp || h.sim) continue; trophyUnlock(TR_FIRST_GAME);
    if (h.g > 0) trophyUnlock(TR_FIRST_GOAL); if (h.g >= 3) trophyUnlock(TR_HAT_TRICK); if (h.a >= 3) trophyUnlock(TR_PLAYMAKER); if (h.lg == 0) trophyUnlock(TR_BIG_LEAGUE); }
  for (auto &h : c.hist) if (h.ln && !h.dnp) pts += h.g + h.a;
  if (pts >= 100) trophyUnlock(TR_CENTURY);
  if (c.draftDone) trophyUnlock(TR_DRAFTED);
  for (auto &g : c.tgoals) if (g.st == 1) trophyUnlock(TR_TEAM_GOAL);
  for (auto &k : c.chem) if (k.second >= 99.5) trophyUnlock(TR_CHEMISTRY);
  if (HOME.lvl >= 1) trophyUnlock(TR_NEW_DIGS);
  if (c.hmOpened > 0) trophyUnlock(TR_PACK_RAT);
  int own = 0; bool shiny = false; for (int i = 0; i < HM_N; i++) { int n = 0; for (int v = 0; v < HM_NV; v++) { n += c.hmCnt[i][v]; if (v > 0 && c.hmCnt[i][v] > 0) shiny = true; } if (n > 0) own++; }
  if (shiny) trophyUnlock(TR_SHINY); if (own >= HM_N) trophyUnlock(TR_FULL_BINDER);
}

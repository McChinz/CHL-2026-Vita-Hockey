// trophy.cpp - see trophy.h. The calls into the console's trophy library run on their own thread: registering the
// pack takes a moment the first time (the console installs it) and an unlock waits on the system, so the game queues
// the ids and moves on.
#include "trophy.h"
#include "pro.h"
#include "apt.h"
#include "hockeymon.h"
#include "platform.h"
#include <string>
#include <vector>

static bool g_sent[TR_COUNT];   // asked for this session (the console keeps the real record)
static bool g_ok = false;

#if defined(CHL_TROPHIES)
#include <psp2/sysmodule.h>
#include <psp2/kernel/threadmgr.h>
extern "C" {
// SceNpTrophy (vitasdk stub: SceNpTrophy_stub). Declared here so the build doesn't depend on a header
typedef int SceNpTrophyContext; typedef int SceNpTrophyHandle; typedef int SceNpTrophyId;
typedef struct { char data[9]; char term; unsigned char num; char dummy; } SceNpCommunicationId;
typedef struct { unsigned char data[160]; } SceNpCommunicationSignature;
int sceNpTrophyInit(void *opt);
int sceNpTrophyCreateContext(SceNpTrophyContext *ctx, const SceNpCommunicationId *id, const SceNpCommunicationSignature *sig, unsigned long long options);
int sceNpTrophyCreateHandle(SceNpTrophyHandle *h);
int sceNpTrophyRegisterContext(SceNpTrophyContext ctx, SceNpTrophyHandle h, unsigned long long options);
int sceNpTrophyUnlockTrophy(SceNpTrophyContext ctx, SceNpTrophyHandle h, SceNpTrophyId id, SceNpTrophyId *platinum);
}
static SceUID g_mx = -1; static std::vector<int> g_q; static SceUID g_sema = -1;
struct Lk { Lk() { sceKernelLockMutex(g_mx, 1, nullptr); } ~Lk() { sceKernelUnlockMutex(g_mx, 1); } };
static SceNpTrophyContext g_ctx = -1; static SceNpTrophyHandle g_h = -1;
static int trophyThread(SceSize, void *) {
  int r = sceSysmoduleLoadModule(SCE_SYSMODULE_NP_TROPHY); plat_log("trophy: module " + std::to_string(r));
  if (r >= 0) r = sceNpTrophyInit(nullptr);
  if (r >= 0) { SceNpCommunicationId id = {}; const char *c = "NPWR90226"; for (int i = 0; i < 9; i++) id.data[i] = c[i]; id.num = 0;
    SceNpCommunicationSignature sig = {};   // (NoTrpDrm turns the signature check off)
    r = sceNpTrophyCreateContext(&g_ctx, &id, &sig, 0); }
  if (r >= 0) r = sceNpTrophyCreateHandle(&g_h);
  if (r >= 0) r = sceNpTrophyRegisterContext(g_ctx, g_h, 0);
  g_ok = r >= 0; plat_log("trophy: " + std::string(g_ok ? "ready" : "unavailable (is NoTrpDrm installed?) ") + std::to_string(r));
  if (!g_ok) return 0;
  for (;;) { sceKernelWaitSema(g_sema, 1, nullptr); int t = -1; { Lk l; if (!g_q.empty()) { t = g_q.front(); g_q.erase(g_q.begin()); } }
    if (t >= 0) { SceNpTrophyId plat = -1; int u = sceNpTrophyUnlockTrophy(g_ctx, g_h, t, &plat); plat_log("trophy " + std::to_string(t) + ": " + std::to_string(u)); } }
  return 0;
}
void trophyInit() {
  g_sema = sceKernelCreateSema("chl_trophy", 0, 0, 64, nullptr); g_mx = sceKernelCreateMutex("chl_trophy_q", 0, 0, nullptr);
  SceUID th = sceKernelCreateThread("chl_trophy", trophyThread, 0x10000100 + 40, 0x10000, 0, 0, nullptr); if (th >= 0) sceKernelStartThread(th, 0, nullptr);
}
void trophyUnlock(int id) {
  if (id <= 0 || id >= TR_COUNT || g_sent[id]) return; g_sent[id] = true;   // (the platinum comes by itself)
  if (g_mx >= 0) { Lk l; g_q.push_back(id); } if (g_sema >= 0) sceKernelSignalSema(g_sema, 1);
}
#else
// the PC build: just logs them (the tests check it)
void trophyInit() {}
void trophyUnlock(int id) { if (id <= 0 || id >= TR_COUNT || g_sent[id]) return; g_sent[id] = true; plat_log("TROPHY " + std::to_string(id)); }
#endif
bool trophyActive() { return g_ok; }

// Be a Pro: what the career already shows (its game log, the draft, the apartment, the binder, the texts)
void trophyCheckPro() {
  if (!CR) return; const Career &c = *CR; int pts = 0;
  for (auto &h : c.hist) { if (!h.ln || h.dnp || h.sim) continue; trophyUnlock(TR_FIRST_GAME);
    if (h.g > 0) trophyUnlock(TR_FIRST_GOAL); if (h.g >= 3) trophyUnlock(TR_HAT_TRICK); if (h.a >= 3) trophyUnlock(TR_PLAYMAKER); if (h.lg == 0) trophyUnlock(TR_BIG_LEAGUE); }
  for (auto &h : c.hist) if (h.ln && !h.dnp) pts += h.g + h.a;
  if (pts >= 100) trophyUnlock(TR_CENTURY);
  if (c.draftDone) trophyUnlock(TR_DRAFTED);
  for (auto &g : c.tgoals) if (g.st == 1) trophyUnlock(TR_TEAM_GOAL);
  for (auto &k : c.chem) if (k.second >= 99.5) trophyUnlock(TR_CHEMISTRY);
  if (HOME.lvl >= 1) trophyUnlock(TR_NEW_DIGS);
  if (c.hmOpened > 0) trophyUnlock(TR_PACK_RAT);
  int own = 0; bool shiny = false; for (int i = 0; i < HM_N; i++) { int n = 0; for (int v = 0; v < HM_NV; v++) { n += c.hmCnt[i][v]; if (v > 0 && c.hmCnt[i][v] > 0) shiny = true; } if (n > 0) own++; }
  if (shiny) trophyUnlock(TR_SHINY); if (own >= HM_N) trophyUnlock(TR_FULL_BINDER);
}

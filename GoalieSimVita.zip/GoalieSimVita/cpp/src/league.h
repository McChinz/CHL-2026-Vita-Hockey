// CHL 2026 native - players and ratings, shared by every mode: archetypes and traits, the 13 skater ratings
// (+ backhands) and 8 goalie ratings on the 50-99 card scale, overall, sizes, shooting hands, perks, the real
// league (32 teams), the Ultimate Franchise player pool (current players, the 2026 draft class, legends).
// Same formulas and the same random-number order as the legacy build, so every player and card comes out the same.
#pragma once
#include "util.h"
#include "json.h"
#include <map>
#include <functional>

// JS Math.round (halves go up)
inline double jround(double v) { return std::floor(v + .5); }
// Math.random swapped for the legacy seeded generator inside fn (cards, CPU teams: fixed per seed)
void withSeed(int seed, const std::function<void()> &fn);

// ---- perks
enum PerkId { PK_ONETOUCH, PK_OTKING, PK_DEMON, PK_FLICK, PK_EYES, PK_FREIGHT, PK_WALL, PK_LUNGS, PK_DANGLE,
  PK_LEATHER, PK_STPAUL, PK_ROBBER, PK_RESET, PK_IRONMAN, PK_PADLOCK, PK_CROSS, PK_N };
enum PerkKind { PKK_USE, PKK_PAS, PKK_CD };
struct PerkDef { const char *id, *n, *ab; char pos; const char *col; const char *k; int rq[3]; PerkKind kind; int uses[3]; int cd[3]; bool user; int c; const char *d; const char *td[3]; };
extern const PerkDef PERKS[PK_N];
int perkIndex(const std::string &id);
extern const Col TIERC[4];
extern const char *TIERN[4];
struct PerkE { int id, t; };
inline int pkSlots(int ov) { return ov >= 89 ? 2 : ov >= 78 ? 1 : 0; }

// ---- ratings
struct Attr { double spd = 5, agl = 5, deke = 5, pass = 5, wacc = 5, wpow = 5, lacc = 5, spow = 5, chk = 5, hand = 5, stam = 5, fo = 5, poise = 5, bhp = 4, bha = 4; };
// skater ratings on the card scale (FKEYS + backhands)
struct Ratings {
  int skate = 50, edge = 50, deke = 50, pass = 50, sacc = 50, wpow = 50, slacc = 50, spow = 50, fstam = 50, check = 50, poise = 50, hand = 50, fo = 50, bhp = 46, bha = 46;
  int get(const std::string &k) const; void set(const std::string &k, int v);
};
extern const char *FKEYS[13];      // the 13 that make up overall
extern const char *BHKEYS[2];
extern const char *UT_SK[13];      // card order
extern const char *UT_GK[8];
extern const char *UT_GKD[10];   // what a goalie card shows (glove and blocker split high / low)
std::string FNICE(const std::string &k);
std::string UT_GN(const std::string &k);
int ovOf(const Ratings &r);
enum Arch { AR_BALANCED, AR_SNIPER, AR_SLAPPER, AR_PLAYMAKER, AR_FINISHER, AR_POWER };
extern const char *ARK[6];         // keys (BALANCED ... POWER)
extern const char *ARN[6];         // shown names (SLAPPER is "CANNON")
enum Tend { TD_NONE, TD_CRASH, TD_NET, TD_REB, TD_USER };
struct Fx { double spd = 0, pass = 0, sacc = 0, spow = 0, wpow = 0, lacc = 0, stam = 0, fo = 0, chk = 0, hand = 0; bool hasW = true, hasL = true; };
// a skater as a person (roster player, card, career player): what the game engine plays
struct Src {
  std::string nm; double p = 4, a = 4; bool star = false; bool hasAr = false; Arch ar = AR_BALANCED; Fx fx; bool hasFx = false; Tend tend = TD_NONE;
  double tv[3] = {1, 1, 1}, ta[3] = {0, 0, 0}; bool hasTv = false;    // shot speed / accuracy traits: wr, sl, ot
  bool hasRt = false; Ratings rt;     // Ultimate Franchise cards carry their ratings
  std::string utk, pkSeed;            // card key (for card stats), perk seed
  double en = -1, et = 0; int lg = 0; // energy when he came off (the bench refills it)
  bool me = false;                    // you
  J *jp = nullptr;                    // career player record (stats are credited to it)
};
// goalie ratings (50-99)
struct GS { double agi = 62, glv = 62, blk = 62, pad = 62, chs = 62, sta = 62, rec = 62, rd = 62, ovr = 62;
  // glove high / glove low / blocker high / blocker low: glv and blk are their averages (so overalls don't move);
  // every goalie has his own split (gsSplit), the same in every mode and on his card
  double gh = 62, gl = 62, bh = 62, bl = 62; bool sp = false;
  double get(const std::string &k) const; };
void gsSplit(GS &g, const std::string &seed);   // fills gh/gl/bh/bl from glv/blk (once; stable per goalie)
struct GSrc {
  std::string nm; double r = 5; std::string gar; bool hasGo = false; double go[8] = {0}; bool hasRd = false;   // offsets agi glv blk pad chs sta rec rd
  bool hasGst = false; GS gst; std::string pkSeed, utk; bool me = false; J *jp = nullptr;
};
extern const char *GARK[5];

// user's stats (the career's 50-99 ratings; quick play uses them too, like the legacy build)
extern J g_stats;
void statsDefaults(J &st);
double gearPts(const std::string &k);
Ratings userRatings();
double uAttr(const std::string &k);      // your on-ice ability from your stat (+ gear): rookie ~3.5, maxed 10
extern char g_meSh;                       // your shooting hand
extern std::function<double()> g_leagueAdj;   // Be a Pro: CPU skaters play to the league's level
GS userGS();

void ensureTraits(Src &q, int pref = -1);   // pref: an archetype the team leans toward
struct Profile { double fq[4]; double spd[3], acc[3]; };   // fq: pass wr sl ot
Profile profile(Src &q);
struct Raw { double spd, agl, deke, pass, wacc, wpow, lacc, spow, chk, poise, hand, stam, fo; };
Raw skRaw(const Src *s);
double rt2at(double v);
int at2rt(double a);
Ratings skRatings(const Src *q);
int ovSk(const Src *q);
void fitS(Src &s, int ov);
void ensureGTraits(GSrc &g);
GS gStats(const GSrc *g);
void fitG(GSrc &g, int ov);
char skShoots(const Src *q);
Tend skTend(Src *q);
struct Size { int ht, wt; };
Size skSize(const Src *s);
std::string fmtHt(int i);
std::string genName();
template <class T> void shuffle(std::vector<T> &a) { for (int i = (int)a.size() - 1; i > 0; i--) { int j = (int)std::floor(rnd() * (i + 1)); std::swap(a[i], a[j]); } }
int pkTierOf(const PerkDef &pk, const std::function<int(const std::string &)> &rt);
std::vector<PerkE> pkAuto(const std::function<int(const std::string &)> &rt, int ov, bool g, const std::string &seed);
std::vector<PerkE> pkOfSrc(const Src *q);
std::vector<PerkE> pkOfG(const GSrc *g);

// ---- the league
struct TPl { std::string nm; int age, ov; };
struct TeamDef { std::string ab, city, n; int d; std::string col, st; std::vector<TPl> S, G; };
extern std::vector<TeamDef> TDP;
const std::string &teamCol(int t);
const std::string &teamStr(int t);
int teamIndex(const std::string &ab);
// Ultimate Franchise player pool
struct UTPDef { std::string k, nm; char pos; int ov; int t; bool leg = false, dr = false; int age = 0; };
extern std::vector<UTPDef> UTP;
const UTPDef *UTM(const std::string &k);
extern std::vector<const UTPDef *> UT_CUR, UT_LEGP;
void leagueInit();

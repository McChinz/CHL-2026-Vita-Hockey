// CHL 2026 native - the league: 32 real teams and their 32 AHL affiliates (2026-27 rosters, Nov 2026), the retired
// legends of Ultimate Franchise, the real shooting hands of known players, and the 2026 draft class (round 1).
// Generated from web/goalie.html (+ the 2026 draft) - edit here from now on.
#include "data.h"

const char *TD[NT] = {
  "BOS|Boston|Bruins|0|#111111|#ffb81c|David Pastrnak:30:91,Charlie McAvoy:29:85,Morgan Geekie:28:81,Elias Lindholm:32:79,Pavel Zacha:29:79,Casey Mittelstadt:28:77,James Hagens:19:77,Fraser Minten:22:76,Nikita Zadorov:31:76|Jeremy Swayman:28:83,Michael DiPietro:27:74",
  "BUF|Buffalo|Sabres|0|#003087|#ffb81c|Rasmus Dahlin:26:88,Tage Thompson:29:87,Owen Power:24:81,Zach Benson:21:80,Jack Quinn:25:79,Josh Norris:27:79,Olen Zellweger:23:77,Mattias Samuelsson:26:77,Noah Ostlund:22:76|Ukko-Pekka Luukkonen:27:80,Colten Ellis:25:73",
  "DET|Detroit|Red Wings|0|#ce1126|#ffffff|Lucas Raymond:24:86,Dylan Larkin:30:85,Alex DeBrincat:29:85,Moritz Seider:25:85,Justin Faulk:34:78,Viktor Arvidsson:33:77,Michael Brandsegg-Nygard:21:77,Emmitt Finnie:21:76,Andrew Copp:32:75|John Gibson:33:81,Daniil Tarasov:27:77",
  "FLA|Florida|Panthers|0|#c8102e|#b9975b|Matthew Tkachuk:29:90,Sam Reinhart:31:89,Brady Tkachuk:27:87,Gustav Forsling:30:84,Sam Bennett:30:84,Carter Verhaeghe:31:83,Seth Jones:32:82,Aaron Ekblad:30:82,Anton Lundell:25:81|Jacob Markstrom:36:80,Akira Schmid:26:76",
  "MTL|Montreal|Canadiens|0|#af1e2d|#192168|Nick Suzuki:27:87,Lane Hutson:22:87,Cole Caufield:25:86,Noah Dobson:26:83,Juraj Slafkovsky:22:82,Alex Newhook:25:78,Josh Anderson:32:77,Chris Kreider:35:77,Zachary Bolduc:23:77|Jacob Fowler:22:79,Jakub Dobes:25:78",
  "OTT|Ottawa|Senators|0|#111111|#c52032|Jake Sanderson:24:86,Drake Batherson:28:82,Thomas Chabot:29:81,Shane Pinto:26:80,Dylan Cozens:25:80,Claude Giroux:38:77,Fabian Zetterlund:26:77,Ridly Greig:24:77,Michael Amadio:30:75|Linus Ullmark:33:82,Samuel Ersson:27:76",
  "TBL|Tampa Bay|Lightning|0|#002868|#ffffff|Nikita Kucherov:33:95,Brayden Point:30:87,Jake Guentzel:32:87,Brandon Hagel:28:86,Victor Hedman:36:84,Anthony Cirelli:29:83,JJ Moser:26:79,Ryan McDonagh:37:76,Yanni Gourde:34:75|Andrei Vasilevskiy:32:89,Hugo Alnefelt:25:71",
  "TOR|Toronto|Maple Leafs|0|#00205b|#ffffff|Auston Matthews:29:92,William Nylander:30:89,Kirill Marchenko:26:84,John Tavares:36:81,Gavin McKenna:18:80,Morgan Rielly:32:80,Jack Roslovic:29:78,Easton Cowan:21:77,Darren Raddysh:30:77|Sergei Bobrovsky:38:82,Anthony Stolarz:32:80",
  "CAR|Carolina|Hurricanes|1|#ce1126|#111111|Sebastian Aho:29:87,Seth Jarvis:24:85,Andrei Svechnikov:26:83,Nikolaj Ehlers:30:82,Logan Stankoven:23:82,Jackson Blake:23:80,Shayne Gostisbehere:33:79,Sean Walker:31:77,Jesperi Kotkaniemi:26:76|Pyotr Kochetkov:27:81,Brandon Bussi:28:75",
  "CBJ|Columbus|Blue Jackets|1|#002654|#ce1126|Zach Werenski:29:90,Adam Fantilli:22:84,Matthew Knies:24:82,Kent Johnson:24:80,Valeri Nichushkin:31:80,Sean Monahan:32:79,Charlie Coyle:34:77,Denton Mateychuk:22:77,Cole Sillinger:23:76|Jet Greaves:25:78,Cam Talbot:39:75",
  "NJD|New Jersey|Devils|1|#ce1126|#111111|Jack Hughes:25:90,Nico Hischier:27:87,Jesper Bratt:28:87,Luke Hughes:23:82,Timo Meier:30:81,Dougie Hamilton:33:80,Arseny Gritsyuk:25:78,Brett Pesce:32:77,Evan Rodrigues:33:76|Connor Hellebuyck:33:91,Jake Allen:36:76",
  "NYI|New York|Islanders|1|#00539b|#f47d30|Matthew Schaefer:19:86,Bo Horvat:31:83,Brayden Schenn:35:78,Simon Holmstrom:25:77,Matias Maccelli:26:77,Kyle Palmieri:35:77,Victor Eklund:20:76,Jean-Gabriel Pageau:34:76,Emil Heineman:25:74|Ilya Sorokin:31:87,Semyon Varlamov:38:74",
  "NYR|New York|Rangers|1|#0038a8|#ce1126|Adam Fox:28:88,JT Miller:33:84,Mika Zibanejad:33:83,Alexis Lafreniere:25:82,Pavel Dorofeyev:26:80,Vladislav Gavrikov:31:79,Will Cuylle:24:78,Gabe Perreault:21:77,Oliver Bjorkstrand:31:77|Igor Shesterkin:31:89,Dylan Garand:24:76",
  "PHI|Philadelphia|Flyers|1|#f74902|#111111|Travis Konecny:29:85,Matvei Michkov:22:84,Trevor Zegras:25:81,Travis Sanheim:30:80,Tyson Foerster:24:79,Jamie Drysdale:24:78,Porter Martone:19:77,Christian Dvorak:30:77,Sean Couturier:34:76|Dan Vladar:29:79,Joseph Woll:28:78",
  "PIT|Pittsburgh|Penguins|1|#fcb514|#111111|Sidney Crosby:39:88,Erik Karlsson:36:82,Rickard Rakell:33:81,Bryan Rust:34:80,Evgeni Malkin:40:79,Ben Kindel:19:76,Tommy Novak:29:76,Nick Robertson:25:76,Kris Letang:39:75|Arturs Silovs:25:76,Sergei Murashov:22:75",
  "WSH|Washington|Capitals|1|#c8102e|#041e42|Tom Wilson:32:84,Dylan Strome:29:83,Alex Tuch:30:83,Jordan Kyrou:28:82,Jakob Chychrun:28:82,Pierre-Luc Dubois:28:80,Alex Ovechkin:41:80,Ryan Leonard:22:79,Cole Hutson:20:78|Logan Thompson:29:84,Charlie Lindgren:32:77",
  "CHI|Chicago|Blackhawks|2|#cf0a2c|#111111|Connor Bedard:21:91,Frank Nazar:22:81,Alex Vlasic:25:81,Patrick Kane:38:80,Tyler Bertuzzi:31:78,Teuvo Teravainen:32:78,Anton Frondell:19:77,Roman Kantserov:22:77,Sam Rinzel:22:76|Spencer Knight:25:80,Arvid Soderblom:27:73",
  "COL|Colorado|Avalanche|2|#6f263d|#236192|Nathan MacKinnon:31:96,Cale Makar:28:96,Martin Necas:27:87,Nazem Kadri:36:82,Devon Toews:32:81,Artturi Lehkonen:31:81,Brock Nelson:35:80,Jaden Schwartz:34:79,Gabriel Landeskog:34:77|Mackenzie Blackwood:30:83,Scott Wedgewood:34:76",
  "DAL|Dallas|Stars|2|#006847|#a2aaad|Mikko Rantanen:30:90,Miro Heiskanen:27:88,Jason Robertson:27:88,Wyatt Johnston:23:86,Roope Hintz:30:84,Thomas Harley:25:84,Jamie Benn:37:77,Tyler Seguin:34:77,Arttu Hyry:25:74|Jake Oettinger:28:85,Casey DeSmith:35:74",
  "MIN|Minnesota|Wild|2|#154734|#a6192e|Kirill Kaprizov:29:93,Quinn Hughes:27:92,Matt Boldy:25:85,Joel Eriksson Ek:29:82,Jonas Brodin:33:78,Danila Yurov:22:77,Maxim Shabanov:26:77,Blake Coleman:35:77,Jared Spurgeon:37:76|Jesper Wallstedt:24:82,Calvin Pickard:34:72",
  "NSH|Nashville|Predators|2|#ffb81c|#041e42|Roman Josi:36:85,Filip Forsberg:32:84,Ryan O'Reilly:35:80,Steven Stamkos:36:80,Jonathan Marchessault:36:78,Brady Skjei:32:77,Nils Hoglander:25:76,Ross Colton:30:76,Adam Wilsby:25:75|Juuse Saros:31:83,Justus Annunen:26:75",
  "STL|St. Louis|Blues|2|#002f87|#fcb514|Robert Thomas:27:86,Mason McTavish:23:82,Pavel Buchnevich:31:80,Connor McMichael:25:80,Jimmy Snuggerud:22:79,Philip Broberg:25:79,Colton Parayko:33:79,Jake Neighbours:24:77,Pius Suter:30:76|Joel Hofer:26:80,Jordan Binnington:33:77",
  "UTA|Utah|Mammoth|2|#1c1c1c|#6cace4|Clayton Keller:28:86,Logan Cooley:22:85,Mikhail Sergachev:28:84,Dylan Guenther:23:84,Nick Schmaltz:30:81,Vincent Trocheck:33:81,Barrett Hayton:26:77,Dmitri Simashev:21:75,Anders Lee:36:74|Karel Vejmelka:30:80,Sebastian Cossa:23:73",
  "WPG|Winnipeg|Jets|2|#041e42|#a2aaad|Kyle Connor:30:89,Mark Scheifele:33:87,Josh Morrissey:31:85,Gabriel Vilardi:27:82,Cole Perfetti:24:81,Dawson Mercer:25:79,Neal Pionk:31:78,Dylan Samberg:27:77,Dylan DeMelo:33:76|Stuart Skinner:28:77,Clay Stevenson:27:72",
  "ANA|Anaheim|Ducks|3|#fc4c02|#111111|Leo Carlsson:22:86,Cutter Gauthier:22:85,Troy Terry:29:81,Jackson LaCombe:25:81,Mikael Granlund:34:79,Beckett Sennecke:20:78,Pavel Mintyukov:23:77,Frank Vatrano:32:76,Noah Warren:22:74|Lukas Dostal:26:81,Petr Mrazek:34:73",
  "CGY|Calgary|Flames|3|#c8102e|#f1be48|Matt Coronato:24:81,Zayne Parekh:20:79,Joel Farabee:26:78,Morgan Frost:27:77,Simon Nemec:22:77,Matvei Gridin:21:76,Martin Pospisil:27:75,Mikael Backlund:37:75,Ryan Strome:33:74|Dustin Wolf:25:81,Devin Cooley:29:76",
  "EDM|Edmonton|Oilers|3|#041e42|#ff4c00|Connor McDavid:29:97,Leon Draisaitl:31:94,Evan Bouchard:27:86,Ryan Nugent-Hopkins:33:81,Zach Hyman:34:80,Mattias Ekholm:36:79,Vasily Podkolzin:25:77,Kasperi Kapanen:30:74,Mathieu Joseph:29:74|Tristan Jarry:31:78,Devon Levi:24:75",
  "LAK|Los Angeles|Kings|3|#111111|#a2aaad|Artemi Panarin:35:88,Adrian Kempe:30:85,Quinton Byfield:24:82,Brandt Clarke:23:80,Drew Doughty:37:79,Alex Laferriere:25:77,Scott Laughton:32:75,Erik Haula:35:74,Joel Armia:33:74|Darcy Kuemper:36:81,Anton Forsberg:33:74",
  "SJS|San Jose|Sharks|3|#006d75|#111111|Macklin Celebrini:20:93,Will Smith:21:83,Ivar Stenberg:18:78,Michael Misa:19:78,Tyler Toffoli:34:78,Dmitry Orlov:35:76,Mason Marchment:31:76,Kiefer Sherwood:31:75,Darnell Nurse:31:78|Yaroslav Askarov:24:80,Alex Nedeljkovic:30:74",
  "SEA|Seattle|Kraken|3|#001628|#99d9d9|Matty Beniers:23:81,Vince Dunn:30:81,Jared McCann:30:80,Brandon Montour:32:80,Berkly Catton:20:78,Kaapo Kakko:25:77,Jordan Eberle:36:77,Chandler Stephenson:32:76,Mackie Samoskevich:23:76|Joey Daccord:30:80,Philipp Grubauer:35:75",
  "VAN|Vancouver|Canucks|3|#00205b|#00843d|Elias Pettersson:28:85,Marco Rossi:25:80,Filip Hronek:29:80,Brock Boeser:29:80,Jake DeBrusk:30:78,Jonathan Lekkerimaki:22:77,Zeev Buium:21:77,Linus Karlsson:27:75,Liam Ohgren:22:74|Leevi Merilainen:24:76,Kevin Lankinen:31:75",
  "VGK|Vegas|Golden Knights|3|#b4975a|#333f42|Jack Eichel:30:91,Mitch Marner:29:90,Shea Theodore:31:84,Mark Stone:34:82,Tomas Hertl:33:81,Ivan Barbashev:31:81,Rasmus Andersson:30:81,Noah Hanifin:29:81,Trevor Connelly:21:75|Adin Hill:30:80,Carter Hart:28:79",
};
// the AHL: each NHL club's affiliate, in the same order as TD (AHL_TD[i] is the farm team of TD[i]).
// Divisions: 0 ATLANTIC, 1 NORTH, 2 CENTRAL, 3 PACIFIC. Rosters: the top skaters and goalies as of the 2026-27 season.
const char *AHL_TD[NT] = {
  "PRO|Providence|Providence Bruins|0|#111111|#fcb514|Lukas Reichel:24:71,Mikey Eyssimont:30:70,Riley Duran:25:68,Alex Steeves:26:68,Henri Jokiharju:27:68,Jordan Harris:26:67,Brendan Gaunce:32:66,Dans Locmelis:23:66,Ty Gallagher:22:65|Jiri Patera:27:69,Simon Zajicek:21:62",
  "ROC|Rochester|Rochester Americans|1|#00205b|#c8102e|Conor Sheary:34:69,Matthew Peca:33:67,Jason Polin:27:67,Trevor Kuntar:24:66,Caleb Jones:29:66,Aidan McDonough:27:65,Riley Fiddler-Schultz:24:64,Vsevolod Komarov:22:64,Jake Richard:21:63|Matthew Villalta:27:67,Talyn Boyko:23:63",
  "GR|Grand Rapids|Grand Rapids Griffins|2|#ce1126|#111111|Axel Sandin-Pellikka:21:70,John Leonard:28:69,Carter Bear:19:68,Dominik Shine:33:67,Shai Buium:23:66,Jesse Kiiskinen:21:65,Dylan James:22:65,William Lagesson:31:65,Ondrej Becher:22:64|Trey Augustine:21:69,Michal Postava:25:67",
  "CLT|Charlotte|Charlotte Checkers|0|#c8102e|#111111|Sam Lafferty:31:67,Jack Devine:23:66,Gracyn Sawchyn:22:65,John Beecher:25:65,Nathan Smith:28:64,Will Bitten:28:64,Donovan Sebrango:24:64,Robert Mastrosimone:25:63,Alex Petrovic:34:63|Cooper Black:23:66,Kirill Gerasimyuk:23:65",
  "LAV|Laval|Laval Rocket|1|#0b2341|#c8102e|David Reinbacher:22:69,Laurent Dauphin:31:69,Luke Mittelstadt:27:67,Sasha Pastujov:23:66,Filip Mesar:22:66,Brett Berard:24:65,Xavier Simoneau:25:65,Alex Belzile:35:65,Josh Nadeau:23:64|Kaapo Kahkonen:30:69,Kevin Mandolese:26:64",
  "BEL|Belleville|Belleville Senators|1|#c52032|#111111|Philip Tomasino:25:68,Kasper Halttunen:21:67,Xavier Bourgault:24:67,Samuel Blais:30:65,Ryan Suzuki:25:64,Tyler Boucher:23:64,Christian Kyrou:23:64,Philippe Daoust:22:63,Djibril Toure:24:62|Jonas Johansson:31:68,Jackson Parsons:23:64",
  "SYR|Syracuse|Syracuse Crunch|1|#003da5|#a2aaad|Conor Geekie:22:68,Nick Abruzzese:27:67,Ethan Gauthier:21:65,Gabriel Szturc:23:64,Maxim Groshev:25:64,Connor Kurth:22:63,Brendan Furry:27:63,Matteo Pietroniro:23:63,Milo Roelens:21:62|Mads Sogaard:26:67,Olivier Rodrigue:26:64",
  "TRM|Toronto|Toronto Marlies|1|#00205b|#ffffff|Brendan Brisson:25:67,Aatu Raty:24:67,Logan Shaw:34:66,Philippe Myers:29:66,Vinni Lettieri:31:65,Ryan Tverberg:24:64,Vinny Borgesi:22:64,Luke Haymes:23:63,Borya Valis:20:62|Artur Akhtyamov:25:66,Samuel Hlavaj:25:65",
  "CHW|Chicago|Chicago Wolves|2|#8b2332|#c0c0c0|Bradly Nadeau:21:69,Felix Unger Sorum:21:67,Pierre-Olivier Joseph:27:65,Aleksi Heimosalmi:23:65,Ivan Ryabkin:20:64,Viktor Neuchev:23:64,Gabriel Seger:25:63,Justin Robidas:23:63,Skyler Brind'Amour:27:62|Cayden Primeau:27:68,Zach Sawchenko:29:65",
  "CLE|Cleveland|Cleveland Monsters|1|#002654|#ce1126|Steven Lorentz:30:65,Luca Pinelli:22:64,Owen Sillinger:25:64,James Malatesta:23:64,Mikael Pyyhtia:25:64,Oiva Keskinen:22:63,Guillaume Richard:23:63,Boston Buckberger:20:62,Luca Marrelli:21:62|Pheonix Copley:34:65,Evan Gardner:23:62",
  "UTI|Utica|Utica Comets|1|#12294b|#d50032|Stefan Noesen:33:68,Lenni Hameenaho:22:66,Colin White:29:65,Anton Silaev:20:65,Topias Vilen:23:63,Xavier Parent:23:62,Ben Steeves:26:62,Marc McLaughlin:26:62,Gabe Klassen:22:61|David Rittich:34:69,Jakub Malek:20:63",
  "HAM|Hamilton|Hamilton Hammers|1|#00539b|#f47d30|Pierre Engvall:30:67,Robby Fabbri:30:67,Ethan Bear:29:67,Cole Eiserman:20:66,Liam Foudy:26:65,Kashawn Aitcheson:20:65,Matt Luff:29:64,Quinn Finley:22:63,Marshall Warren:25:62|Vitek Vanecek:30:70,Josh Kotai:20:61",
  "HFD|Hartford|Hartford Wolf Pack|0|#0038a8|#ce1126|Liam Greentree:20:67,Taylor Raddysh:28:67,Juuso Parssinen:25:65,Glenn Gawdin:29:64,Justin Dowling:36:63,Carey Terrance:21:63,Marc Del Gaizo:27:63,Anton Blidh:31:62,Drew Fortescue:21:62|Spencer Martin:31:66,Callum Tung:23:65",
  "LV|Lehigh Valley|Lehigh Valley Phantoms|0|#f74902|#111111|Alex Bump:23:66,Jett Luchanko:20:66,Jack Studnicka:27:64,Zach Aston-Reese:32:64,Carl Grundstrom:29:64,Nolan Foote:26:63,Jacob Gaucher:23:63,Spencer Gill:23:63,Helge Grans:24:63|Alexei Kolosov:24:67,Carson Bjarnason:21:62",
  "WBS|Wilkes-Barre/Scranton|Wilkes-Barre/Scranton Penguins|0|#111111|#fcb514|Rutger McGroarty:22:68,Owen Pickering:22:65,Avery Hayes:24:64,Rafael Harvey-Pinard:27:64,Harrison Brunicke:20:64,Tristan Broz:23:63,Hugh McGing:25:62,Atley Calvert:22:62,Mikhail Ilyin:21:62|Joel Blomqvist:24:67,Taylor Gauthier:25:64",
  "HER|Hershey|Hershey Bears|0|#4f2c1d|#c69214|Andrew Cristall:21:66,Jonny Brodzinski:33:65,Ryan Chesley:22:64,Louis Belpedio:30:64,Bogdan Trineyev:24:63,Petr Sikora:19:63,Spencer Smallman:30:62,Lynden Lakovic:20:62,Joshua Dunne:24:61|Cal Petersen:32:66,Mitchell Gibson:27:62",
  "RFD|Rockford|Rockford IceHogs|2|#cf0a2c|#111111|Nick Lardis:21:66,Brett Seney:30:65,Gavin Hayes:22:64,Derrick Pouliot:32:64,Sacha Boisvert:20:63,Marek Vanacker:20:63,Jiri Felcman:22:62,Landon Slaggert:24:62,Dominic Toninato:32:62|Drew Commesso:24:66,Stanislav Berezhnoy:22:61",
  "COE|Loveland|Colorado Eagles|3|#002a5c|#c6a75c|Gavin Brindley:22:67,Domenick Fensore:25:65,Tristen Nielsen:26:64,Vince Hinostroza:32:64,Sean Behrens:23:64,Adam Beckman:25:63,Jayson Megna:36:62,Nikita Prishchepov:23:62,Taylor Makar:24:61|Ilya Nabokov:23:67,Trent Miner:25:63",
  "TEX|Cedar Park|Texas Stars|2|#006847|#ffffff|Mike Sgarbossa:34:64,Tristan Bertucci:21:63,Dylan Hryckowian:23:62,Matthew Seminoff:24:62,Ellis Rickwood:21:62,Artem Shlaine:24:62,Curtis McKenzie:35:62,Kyle Looft:24:62,Charlie Paquette:22:61|Remi Poirier:25:66,Brandon Halverson:30:64",
  "IOW|Des Moines|Iowa Wild|2|#154734|#a6192e|Riley Heidt:21:65,Jack Peart:23:65,Justin Kirkland:30:64,Charlie Stramel:22:64,Carson Lambos:23:64,Dylan Gambrell:30:63,Mason Shaw:28:63,Hunter Haight:22:63,Michael Koster:25:62|Riley Mercer:23:63,William Rousseau:26:62",
  "MIL|Milwaukee|Milwaukee Admirals|2|#00205b|#7da7d9|Joakim Kemell:22:68,Brady Martin:19:67,Tanner Molendyk:21:66,Cole O'Hara:22:65,Aiden Fink:21:65,Tyson Jost:28:65,Ryan Ufko:23:64,David Edstrom:22:63,Felix Nilsson:22:62|Matthew Murray:28:66,Isak Posch:20:62",
  "SPR|Springfield|Springfield Thunderbirds|0|#002f87|#fcb514|T.J. Tynan:34:66,Calle Rosen:32:65,Theo Lindstein:21:65,Otto Stenberg:21:64,Oskar Sundqvist:32:64,Justin Carbonneau:19:63,Nathan Walker:32:63,Aleksanteri Kaskimaki:21:62,Michael Buchinger:22:62|Georgi Romanov:26:64,Will Cranley:25:63",
  "TUC|Tucson|Tucson Roadrunners|3|#b5121b|#e8d7b0|Tij Iginla:20:67,Caleb Desnoyers:19:67,Cameron Hebig:27:65,Ben McCartney:25:64,Zac Jones:26:64,Brandon Tanev:35:63,Austin Poganski:30:62,Tomas Lavoie:21:62,Yegor Borikov:20:61|Michael Hrabal:21:66,Jaxson Stauber:27:63",
  "MB|Winnipeg|Manitoba Moose|2|#041e42|#a2aaad|Brayden Yager:21:67,Nikita Chibrikov:23:65,Danny Zhilkin:22:64,Noah Gregor:28:64,Isaak Phillips:25:64,Henry Thrun:25:64,Colby Barlow:21:63,Parker Ford:24:62,Jacob Julien:20:62|Dom DiVincentiis:22:66,Thomas Milic:23:63",
  "SDG|San Diego|San Diego Gulls|3|#fc4c02|#111111|Stian Solberg:21:66,Matthew Phillips:28:65,Roger McQueen:19:65,Tristan Luneau:22:65,Anton Wahlberg:21:63,Lucas Pettersson:20:63,Nico Myatovic:21:62,Nathan Gaucher:23:62,Ryan Carpenter:35:62|Damian Clara:21:67,Laurent Brossoit:33:66",
  "CGW|Calgary|Calgary Wranglers|3|#c8102e|#f1be48|Alexander Nylander:28:66,Hunter Brzustewicz:22:65,Ben Jones:27:64,Rory Kerins:24:64,Dryden Hunt:31:62,William Stromgren:23:62,Sam Morton:23:62,Michael Benning:24:62,Axel Hurtig:23:61|Arseni Sergeev:24:66,Kirill Zarubin:22:62",
  "BAK|Bakersfield|Bakersfield Condors|3|#ff4c00|#041e42|Quinn Hutson:24:67,Seth Griffith:33:65,Matt Copponi:26:62,Rhett Pitlick:25:62,Samuel Sjolund:21:62,Aku Raty:25:61,Tucker Robertson:25:61,Tomas Cibulka:22:61,Daniel D'Amato:25:60|Matt Tomkins:32:65,Samuel Jonsson:21:63",
  "ONT|Ontario|Ontario Reign|3|#111111|#a2aaad|Scott Perunovich:28:65,Lane Pederson:29:64,Cole Guttman:27:64,Martin Chromiak:24:64,Koehn Ziemmer:21:64,Kirill Kirsanov:24:64,Francesco Pinelli:23:62,Jared Wright:23:62,Angus Booth:21:62|Erik Portillo:26:67,Carter George:20:65",
  "SJB|San Jose|San Jose Barracuda|3|#006d75|#f4793e|Alex Barre-Boulet:29:66,Filip Bystedt:22:65,Jimmy Huntington:27:64,Cam Lund:22:64,Ethan Cardwell:24:63,Leo Sahlin Wallenius:20:63,Andre Gasseau:23:62,Brett Leason:27:62,Eric Pohlkamp:24:62|Ilya Samsonov:29:70,Eric Comrie:31:64",
  "CV|Palm Desert|Coachella Valley Firebirds|3|#001628|#e9072b|Jani Nyman:22:68,Jagger Firkus:22:67,Logan Morrison:27:64,Eduard Sale:21:64,Tyson Jugnauth:22:64,Julius Miettinen:20:63,Lukas Dragicevic:21:63,J.R. Avon:25:62,John Hayden:31:61|Nikke Kokko:23:65,Victor Ostman:26:63",
  "ABB|Abbotsford|Abbotsford Canucks|3|#00205b|#00843d|Braeden Cootes:19:66,Kole Lind:28:64,Kirill Kudryavtsev:23:64,Ty Mueller:23:63,Trey Fix-Wolansky:27:63,Riley Patterson:22:62,Sawyer Mynio:22:62,Jimmy Schuldt:31:62,Vilmer Alriksson:21:61|Nikita Tolopilo:26:66,Ty Young:20:61",
  "HSK|Henderson|Henderson Silver Knights|3|#333f42|#b4975a|Alexander Holtz:24:67,Ville Heinola:25:65,Lukas Cormier:24:64,Matyas Sapovaliv:23:63,Ben Hemmerling:20:63,Tanner Laczynski:29:62,Jakub Demek:22:62,Mitch McLain:24:61,Joe Fleming:24:61|Carl Lindbom:23:65,Cameron Whitehead:23:64",
};
const LegendDef UT_LEG[NLEG] = {
  {"Wayne Gretzky", 'F', 97},
  {"Mario Lemieux", 'F', 96},
  {"Bobby Orr", 'F', 95},
  {"Gordie Howe", 'F', 94},
  {"Jaromir Jagr", 'F', 93},
  {"Mark Messier", 'F', 92},
  {"Steve Yzerman", 'F', 92},
  {"Joe Sakic", 'F', 91},
  {"Nicklas Lidstrom", 'F', 91},
  {"Mike Bossy", 'F', 91},
  {"Guy Lafleur", 'F', 91},
  {"Peter Forsberg", 'F', 91},
  {"Ray Bourque", 'F', 90},
  {"Teemu Selanne", 'F', 90},
  {"Pavel Bure", 'F', 90},
  {"Joe Thornton", 'F', 89},
  {"Dominik Hasek", 'G', 95},
  {"Patrick Roy", 'G', 94},
  {"Martin Brodeur", 'G', 93},
  {"Henrik Lundqvist", 'G', 90},
};
// first round of the 2026 NHL Draft (June 26, Buffalo): pick, team, name, age, rookie OVR
const DraftDef DRAFT26[NDRAFT] = {
  {1, "TOR", "Gavin McKenna", 18, 80},
  {2, "SJS", "Ivar Stenberg", 18, 79},
  {3, "VAN", "Caleb Malhotra", 18, 76},
  {4, "BUF", "Daxon Rudolph", 18, 75},
  {5, "NYR", "Alberts Smits", 18, 76},
  {6, "CGY", "Carson Carels", 18, 74},
  {7, "SEA", "Chase Reid", 18, 75},
  {8, "WPG", "Viggo Bjorck", 18, 74},
  {9, "SJS", "Keaton Verhoeff", 18, 74},
  {10, "NSH", "Wyatt Cullen", 18, 72},
  {11, "STL", "Tynan Lawrence", 18, 72},
  {12, "NJD", "Alexander Command", 18, 72},
  {13, "NYI", "Malte Gustafsson", 18, 71},
  {14, "CBJ", "Oscar Hemming", 18, 71},
  {15, "ANA", "Nikita Klepov", 18, 71},
  {16, "STL", "Maddox Dagenais", 18, 70},
  {17, "UTA", "Ethan Belchetz", 18, 71},
  {18, "WSH", "Oliver Suvanto", 18, 70},
  {19, "LAK", "Elton Hermansson", 18, 70},
  {20, "BUF", "Ilia Morozov", 19, 70},
  {21, "SJS", "Ryan Lin", 18, 69},
  {22, "PIT", "Liam Ruck", 18, 69},
  {23, "DET", "JP Hurlbert", 18, 69},
  {24, "VAN", "Adam Novotny", 18, 69},
  {25, "OTT", "Jonas Lagerberg Hoen", 18, 67},
  {26, "MTL", "Gleb Pugachyov", 18, 68},
  {27, "PHI", "Maksim Sokolovskii", 18, 68},
  {28, "ANA", "Marcus Nordmark", 18, 67},
  {29, "VGK", "Juho Piiparinen", 18, 68},
  {30, "CGY", "Jack Hextall", 18, 67},
  {31, "NSH", "Tommy Bleyl", 18, 67},
  {32, "OTT", "Jaxon Cover", 18, 68},
};
const ShootDef SHOOTS[NSHOOTS] = {
  {"Connor McDavid", 'L'},
  {"Sidney Crosby", 'L'},
  {"Alex Ovechkin", 'R'},
  {"Nathan MacKinnon", 'R'},
  {"Auston Matthews", 'L'},
  {"Nikita Kucherov", 'L'},
  {"Leon Draisaitl", 'L'},
  {"David Pastrnak", 'R'},
  {"Cale Makar", 'R'},
  {"Kirill Kaprizov", 'L'},
  {"Quinn Hughes", 'L'},
  {"Jack Hughes", 'L'},
  {"Mitch Marner", 'R'},
  {"Artemi Panarin", 'R'},
  {"Matthew Tkachuk", 'L'},
  {"Brady Tkachuk", 'L'},
  {"Brayden Point", 'R'},
  {"Steven Stamkos", 'R'},
  {"Patrick Kane", 'L'},
  {"Jack Eichel", 'R'},
  {"Aleksander Barkov", 'L'},
  {"Mikko Rantanen", 'L'},
  {"Victor Hedman", 'L'},
  {"Roope Hintz", 'L'},
  {"Jason Robertson", 'L'},
  {"Sebastian Aho", 'L'},
  {"Mika Zibanejad", 'R'},
  {"Anze Kopitar", 'L'},
  {"Elias Pettersson", 'L'},
  {"J.T. Miller", 'R'},
  {"William Nylander", 'R'},
  {"Dylan Larkin", 'L'},
  {"Cole Caufield", 'R'},
  {"Nick Suzuki", 'R'},
  {"Connor Bedard", 'R'},
  {"Macklin Celebrini", 'L'},
};

// forwards' natural positions (C / L = left wing / R = right wing), from the NHL and AHL rosters; the defensemen
// who skate as forwards here are on the wing of their shooting side (my call), and so are the 2026 draft class
const char *POS_TBL =
  "David Pastrnak:R,Charlie McAvoy:R,Morgan Geekie:C,Elias Lindholm:C,Pavel Zacha:C,Casey Mittelstadt:C,James Hagens:C,Fraser Minten:C,Nikita Zadorov:L,Rasmus Dahlin:L,Tage Thompson:C,"
  "Owen Power:L,Zach Benson:L,Jack Quinn:R,Josh Norris:C,Olen Zellweger:L,Mattias Samuelsson:L,Noah Ostlund:C,Lucas Raymond:L,Dylan Larkin:C,Alex DeBrincat:R,Moritz Seider:R,"
  "Justin Faulk:R,Viktor Arvidsson:R,Michael Brandsegg-Nygard:R,Emmitt Finnie:L,Andrew Copp:C,Matthew Tkachuk:R,Sam Reinhart:R,Brady Tkachuk:L,Gustav Forsling:L,Sam Bennett:C,"
  "Carter Verhaeghe:L,Seth Jones:R,Aaron Ekblad:R,Anton Lundell:C,Nick Suzuki:C,Lane Hutson:L,Cole Caufield:R,Noah Dobson:R,Juraj Slafkovsky:L,Alex Newhook:C,Josh Anderson:R,"
  "Chris Kreider:L,Zachary Bolduc:R,Jake Sanderson:L,Drake Batherson:R,Thomas Chabot:L,Shane Pinto:C,Dylan Cozens:C,Claude Giroux:R,Fabian Zetterlund:L,Ridly Greig:C,Michael Amadio:R,"
  "Nikita Kucherov:R,Brayden Point:C,Jake Guentzel:L,Brandon Hagel:L,Victor Hedman:L,Anthony Cirelli:C,JJ Moser:L,Ryan McDonagh:L,Yanni Gourde:C,Auston Matthews:C,William Nylander:R,"
  "Kirill Marchenko:R,John Tavares:C,Gavin McKenna:L,Morgan Rielly:L,Jack Roslovic:C,Easton Cowan:R,Darren Raddysh:R,Sebastian Aho:C,Seth Jarvis:R,Andrei Svechnikov:L,Nikolaj Ehlers:L,"
  "Logan Stankoven:R,Jackson Blake:R,Shayne Gostisbehere:L,Sean Walker:R,Jesperi Kotkaniemi:C,Zach Werenski:L,Adam Fantilli:C,Matthew Knies:L,Kent Johnson:L,Valeri Nichushkin:R,"
  "Sean Monahan:C,Charlie Coyle:C,Denton Mateychuk:L,Cole Sillinger:C,Jack Hughes:C,Nico Hischier:C,Jesper Bratt:L,Luke Hughes:L,Timo Meier:R,Dougie Hamilton:R,Arseny Gritsyuk:R,"
  "Brett Pesce:R,Evan Rodrigues:C,Matthew Schaefer:L,Bo Horvat:C,Brayden Schenn:C,Simon Holmstrom:R,Matias Maccelli:L,Kyle Palmieri:R,Victor Eklund:L,Jean-Gabriel Pageau:C,"
  "Emil Heineman:L,Adam Fox:R,JT Miller:C,Mika Zibanejad:C,Alexis Lafreniere:L,Pavel Dorofeyev:R,Vladislav Gavrikov:L,Will Cuylle:L,Gabe Perreault:R,Oliver Bjorkstrand:R,"
  "Travis Konecny:R,Matvei Michkov:R,Trevor Zegras:C,Travis Sanheim:L,Tyson Foerster:R,Jamie Drysdale:R,Porter Martone:R,Christian Dvorak:C,Sean Couturier:C,Sidney Crosby:C,"
  "Erik Karlsson:R,Rickard Rakell:R,Bryan Rust:R,Evgeni Malkin:C,Ben Kindel:C,Tommy Novak:C,Nick Robertson:L,Kris Letang:R,Tom Wilson:R,Dylan Strome:C,Alex Tuch:R,Jordan Kyrou:R,"
  "Jakob Chychrun:L,Pierre-Luc Dubois:C,Alex Ovechkin:L,Ryan Leonard:R,Cole Hutson:L,Connor Bedard:C,Frank Nazar:C,Alex Vlasic:L,Patrick Kane:R,Tyler Bertuzzi:L,Teuvo Teravainen:L,"
  "Anton Frondell:C,Roman Kantserov:R,Sam Rinzel:R,Nathan MacKinnon:C,Cale Makar:R,Martin Necas:R,Nazem Kadri:C,Devon Toews:L,Artturi Lehkonen:L,Brock Nelson:C,Jaden Schwartz:L,"
  "Gabriel Landeskog:L,Mikko Rantanen:R,Miro Heiskanen:L,Jason Robertson:L,Wyatt Johnston:C,Roope Hintz:C,Thomas Harley:L,Jamie Benn:L,Tyler Seguin:C,Arttu Hyry:R,Kirill Kaprizov:L,"
  "Quinn Hughes:L,Matt Boldy:L,Joel Eriksson Ek:C,Jonas Brodin:L,Danila Yurov:C,Maxim Shabanov:R,Blake Coleman:C,Jared Spurgeon:R,Roman Josi:L,Filip Forsberg:L,Ryan O'Reilly:C,"
  "Steven Stamkos:C,Jonathan Marchessault:R,Brady Skjei:L,Nils Hoglander:L,Ross Colton:C,Adam Wilsby:L,Robert Thomas:C,Mason McTavish:C,Pavel Buchnevich:L,Connor McMichael:C,"
  "Jimmy Snuggerud:R,Philip Broberg:L,Colton Parayko:R,Jake Neighbours:L,Pius Suter:C,Clayton Keller:C,Logan Cooley:C,Mikhail Sergachev:L,Dylan Guenther:R,Nick Schmaltz:C,"
  "Vincent Trocheck:C,Barrett Hayton:C,Dmitri Simashev:L,Anders Lee:L,Kyle Connor:L,Mark Scheifele:C,Josh Morrissey:L,Gabriel Vilardi:C,Cole Perfetti:L,Dawson Mercer:C,Neal Pionk:R,"
  "Dylan Samberg:L,Dylan DeMelo:R,Leo Carlsson:C,Cutter Gauthier:L,Troy Terry:R,Jackson LaCombe:L,Mikael Granlund:C,Beckett Sennecke:R,Pavel Mintyukov:L,Frank Vatrano:R,Noah Warren:R,"
  "Matt Coronato:R,Zayne Parekh:R,Joel Farabee:L,Morgan Frost:C,Simon Nemec:R,Matvei Gridin:R,Martin Pospisil:C,Mikael Backlund:C,Ryan Strome:C,Connor McDavid:C,Leon Draisaitl:C,"
  "Evan Bouchard:R,Ryan Nugent-Hopkins:C,Zach Hyman:L,Mattias Ekholm:L,Vasily Podkolzin:R,Kasperi Kapanen:R,Mathieu Joseph:R,Artemi Panarin:L,Adrian Kempe:R,Quinton Byfield:C,"
  "Brandt Clarke:R,Drew Doughty:R,Alex Laferriere:R,Scott Laughton:C,Erik Haula:C,Joel Armia:R,Macklin Celebrini:C,Will Smith:C,Ivar Stenberg:L,Michael Misa:C,Tyler Toffoli:R,"
  "Dmitry Orlov:L,Mason Marchment:L,Kiefer Sherwood:L,Darnell Nurse:L,Matty Beniers:C,Vince Dunn:L,Jared McCann:C,Brandon Montour:R,Berkly Catton:C,Kaapo Kakko:R,Jordan Eberle:R,"
  "Chandler Stephenson:C,Mackie Samoskevich:R,Elias Pettersson:C,Marco Rossi:C,Filip Hronek:R,Brock Boeser:R,Jake DeBrusk:L,Jonathan Lekkerimaki:R,Zeev Buium:L,Linus Karlsson:R,"
  "Liam Ohgren:L,Jack Eichel:C,Mitch Marner:R,Shea Theodore:L,Mark Stone:R,Tomas Hertl:C,Ivan Barbashev:L,Rasmus Andersson:R,Noah Hanifin:L,Trevor Connelly:L,Lukas Reichel:C,"
  "Mikey Eyssimont:L,Riley Duran:C,Alex Steeves:C,Henri Jokiharju:R,Jordan Harris:L,Brendan Gaunce:L,Dans Locmelis:C,Ty Gallagher:R,Conor Sheary:L,Matthew Peca:C,Jason Polin:R,"
  "Trevor Kuntar:C,Caleb Jones:L,Aidan McDonough:L,Riley Fiddler-Schultz:C,Vsevolod Komarov:R,Axel Sandin-Pellikka:R,John Leonard:L,Carter Bear:L,Dominik Shine:C,Shai Buium:L,"
  "Jesse Kiiskinen:R,Dylan James:C,William Lagesson:L,Ondrej Becher:C,Sam Lafferty:C,Jack Devine:R,Gracyn Sawchyn:C,John Beecher:C,Nathan Smith:C,Will Bitten:R,Donovan Sebrango:L,"
  "Robert Mastrosimone:L,Alex Petrovic:R,David Reinbacher:R,Laurent Dauphin:C,Luke Mittelstadt:L,Sasha Pastujov:L,Filip Mesar:R,Brett Berard:L,Xavier Simoneau:C,Alex Belzile:R,"
  "Josh Nadeau:L,Philip Tomasino:C,Kasper Halttunen:R,Xavier Bourgault:R,Samuel Blais:L,Ryan Suzuki:C,Tyler Boucher:R,Christian Kyrou:R,Philippe Daoust:C,Conor Geekie:C,"
  "Nick Abruzzese:C,Ethan Gauthier:R,Gabriel Szturc:C,Maxim Groshev:R,Connor Kurth:R,Brendan Furry:C,Matteo Pietroniro:R,Milo Roelens:C,Brendan Brisson:L,Aatu Raty:C,Logan Shaw:R,"
  "Philippe Myers:R,Vinni Lettieri:R,Ryan Tverberg:C,Vinny Borgesi:R,Luke Haymes:C,Borya Valis:C,Bradly Nadeau:L,Felix Unger Sorum:R,Pierre-Olivier Joseph:L,Aleksi Heimosalmi:R,"
  "Ivan Ryabkin:C,Viktor Neuchev:L,Gabriel Seger:C,Justin Robidas:C,Skyler Brind'Amour:C,Steven Lorentz:C,Luca Pinelli:C,Owen Sillinger:C,James Malatesta:L,Mikael Pyyhtia:L,"
  "Oiva Keskinen:C,Guillaume Richard:L,Boston Buckberger:R,Luca Marrelli:R,Stefan Noesen:R,Lenni Hameenaho:R,Colin White:C,Anton Silaev:C,Topias Vilen:L,Xavier Parent:L,Ben Steeves:L,"
  "Marc McLaughlin:C,Gabe Klassen:C,Pierre Engvall:L,Robby Fabbri:L,Ethan Bear:R,Cole Eiserman:L,Liam Foudy:C,Kashawn Aitcheson:L,Matt Luff:R,Quinn Finley:L,Marshall Warren:L,"
  "Liam Greentree:R,Taylor Raddysh:R,Juuso Parssinen:C,Glenn Gawdin:C,Justin Dowling:C,Carey Terrance:C,Marc Del Gaizo:L,Anton Blidh:L,Drew Fortescue:R,Alex Bump:L,Jett Luchanko:C,"
  "Jack Studnicka:C,Zach Aston-Reese:L,Carl Grundstrom:L,Nolan Foote:L,Jacob Gaucher:C,Helge Grans:R,Rutger McGroarty:L,Owen Pickering:L,Avery Hayes:R,Rafael Harvey-Pinard:L,"
  "Harrison Brunicke:R,Tristan Broz:L,Hugh McGing:C,Atley Calvert:L,Mikhail Ilyin:C,Andrew Cristall:L,Jonny Brodzinski:C,Ryan Chesley:R,Louis Belpedio:R,Bogdan Trineyev:R,"
  "Petr Sikora:C,Spencer Smallman:R,Lynden Lakovic:L,Joshua Dunne:C,Nick Lardis:L,Brett Seney:L,Gavin Hayes:R,Derrick Pouliot:L,Sacha Boisvert:C,Marek Vanacker:L,Jiri Felcman:C,"
  "Landon Slaggert:L,Dominic Toninato:C,Gavin Brindley:R,Domenick Fensore:L,Tristen Nielsen:C,Vince Hinostroza:C,Sean Behrens:L,Adam Beckman:L,Jayson Megna:C,Nikita Prishchepov:R,"
  "Taylor Makar:L,Mike Sgarbossa:C,Tristan Bertucci:L,Dylan Hryckowian:L,Matthew Seminoff:R,Ellis Rickwood:C,Artem Shlaine:C,Curtis McKenzie:L,Kyle Looft:L,Charlie Paquette:C,"
  "Riley Heidt:C,Jack Peart:L,Justin Kirkland:L,Charlie Stramel:C,Carson Lambos:L,Dylan Gambrell:C,Mason Shaw:C,Hunter Haight:C,Michael Koster:L,Joakim Kemell:R,Brady Martin:C,"
  "Tanner Molendyk:L,Cole O'Hara:R,Aiden Fink:R,Tyson Jost:C,Ryan Ufko:R,David Edstrom:C,Felix Nilsson:C,T.J. Tynan:C,Calle Rosen:L,Theo Lindstein:L,Otto Stenberg:C,Oskar Sundqvist:C,"
  "Justin Carbonneau:R,Nathan Walker:L,Aleksanteri Kaskimaki:C,Michael Buchinger:L,Tij Iginla:C,Caleb Desnoyers:C,Cameron Hebig:C,Ben McCartney:L,Zac Jones:L,Brandon Tanev:L,"
  "Austin Poganski:R,Tomas Lavoie:R,Yegor Borikov:L,Brayden Yager:C,Nikita Chibrikov:R,Danny Zhilkin:C,Noah Gregor:C,Isaak Phillips:L,Henry Thrun:L,Colby Barlow:L,Parker Ford:C,"
  "Jacob Julien:C,Stian Solberg:L,Matthew Phillips:R,Roger McQueen:C,Tristan Luneau:R,Anton Wahlberg:C,Lucas Pettersson:C,Nico Myatovic:L,Nathan Gaucher:C,Ryan Carpenter:C,"
  "Alexander Nylander:R,Hunter Brzustewicz:R,Ben Jones:C,Rory Kerins:C,Dryden Hunt:L,William Stromgren:L,Sam Morton:C,Michael Benning:R,Axel Hurtig:L,Quinn Hutson:R,Seth Griffith:C,"
  "Matt Copponi:C,Rhett Pitlick:L,Samuel Sjolund:L,Aku Raty:R,Tucker Robertson:C,Tomas Cibulka:R,Daniel D'Amato:C,Scott Perunovich:L,Lane Pederson:C,Cole Guttman:C,Martin Chromiak:R,"
  "Koehn Ziemmer:R,Kirill Kirsanov:L,Francesco Pinelli:C,Jared Wright:L,Angus Booth:L,Alex Barre-Boulet:C,Filip Bystedt:C,Jimmy Huntington:L,Cam Lund:C,Ethan Cardwell:R,"
  "Leo Sahlin Wallenius:L,Andre Gasseau:C,Brett Leason:R,Eric Pohlkamp:R,Jani Nyman:R,Jagger Firkus:R,Logan Morrison:C,Eduard Sale:L,Tyson Jugnauth:L,Julius Miettinen:C,"
  "Lukas Dragicevic:R,J.R. Avon:R,John Hayden:C,Braeden Cootes:C,Kole Lind:R,Kirill Kudryavtsev:L,Ty Mueller:C,Trey Fix-Wolansky:R,Riley Patterson:C,Sawyer Mynio:L,Jimmy Schuldt:R,"
  "Vilmer Alriksson:C,Alexander Holtz:R,Ville Heinola:L,Lukas Cormier:L,Matyas Sapovaliv:C,Ben Hemmerling:R,Tanner Laczynski:C,Jakub Demek:C,Mitch McLain:L,Joe Fleming:L,"
  "Jake Richard:R,Djibril Toure:L,Spencer Gill:R,Wayne Gretzky:C,Mario Lemieux:C,Bobby Orr:L,Gordie Howe:R,Jaromir Jagr:R,Mark Messier:C,Steve Yzerman:C,Joe Sakic:C,Nicklas Lidstrom:L,"
  "Mike Bossy:R,Guy Lafleur:R,Peter Forsberg:C,Ray Bourque:L,Teemu Selanne:R,Pavel Bure:R,Joe Thornton:C,Caleb Malhotra:C,Daxon Rudolph:R,Alberts Smits:L,Carson Carels:L,Chase Reid:R,"
  "Viggo Bjorck:C,Keaton Verhoeff:R,Wyatt Cullen:L,Tynan Lawrence:C,Alexander Command:C,Malte Gustafsson:L,Oscar Hemming:L,Nikita Klepov:R,Maddox Dagenais:C,Ethan Belchetz:L,"
  "Oliver Suvanto:C,Elton Hermansson:R,Ilia Morozov:C,Ryan Lin:R,Liam Ruck:R,JP Hurlbert:L,Adam Novotny:L,Jonas Lagerberg Hoen:R,Gleb Pugachyov:L,Maksim Sokolovskii:R,"
  "Marcus Nordmark:R,Juho Piiparinen:R,Jack Hextall:C,Tommy Bleyl:R,Jaxon Cover:R,";

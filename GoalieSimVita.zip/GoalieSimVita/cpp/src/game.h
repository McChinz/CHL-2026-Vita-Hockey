// CHL 2026 native - the forward (skater) game: types and shared state.
// Ported from the web build's SK engine. World units are feet: the rink runs along x (0..200), its width
// along y (0..85). Team 0 is yours (defends the left net, attacks right).
#pragma once
#include "util.h"
#include "canvas.h"
#include "platform.h"
#include "audio.h"
#include <map>
#include <memory>
#include <array>
#include <functional>

extern Canvas ctx;
extern float W, H, U, safeTop;
constexpr bool IS_VITA = true;   // controls and hints are the Vita's (the host test build reads a virtual pad)
extern double g_nowMs;           // this frame's clock (performance.now())
inline double now() { return g_nowMs; }

// ---- rink
struct Rink { double L = 200, Wd = 85, cr = 28, gl = 11, netD = 3.6, cy = 42.5, post = 5.8; };
constexpr Rink RK{};
constexpr double SK_PER = 120, SK_K = .8, SK_SPR = 1.5, SK_BH = 3.6, SK_GH = 9, PG = 32, PZ = 4.2, SK_BLUE = 70, SPIN_T = .55, SK_BLK = 1.15, SK_PEN = 20;
inline double attackX(int t) { return t == 0 ? RK.L - RK.gl : RK.gl; }
inline double defendX(int t) { return t == 0 ? RK.gl : RK.L - RK.gl; }
inline double tdir(int t) { return t == 0 ? 1 : -1; }

#include "league.h"

enum Role { R_C, R_LW, R_RW, R_X, R_F };
inline const char *roleName(Role r) { static const char *n[] = {"C", "LW", "RW", "X", "F"}; return n[r]; }

struct PkLabel { std::string n; int id = 0; Col c; double t = 0, at = -99; int uid = 0; };
struct Deke { double t = 0, s = 1, rel = -1, end = -1, d0 = 0; bool drag = false; };
struct Waypt { double x, y; };

struct Skater {
  int team = 0; Role role = R_C; Src *src = nullptr; bool user = false; std::string nm; bool star = false; Attr at;
  double x = 0, y = 0, vx = 0, vy = 0, ang = 0, stun = 0, cool = 0, dash = 0, dcd = 0, dx = 0, dy = 0, ph = 0;
  std::vector<PerkE> pks; char sh = 'L'; Tend tend = TD_REB; double lane = 0, dec = 0, poke = 0, pokeA = 0, st = 100, stT = 0;
  bool sprint = false, wantSprint = false, tired = false; double wind = 0, windT = 0, wl = 0; std::vector<double> pokes;
  double spin = 0, spinCd = 0, block = 0, blkA = 0, hitPow = 1, lostT = -9, passT = -9, hitT = -9, chopT = 0;
  double gotT = -99; bool gotPass = false; double aiCh = -1; struct { double x, y, ch, h; } windAim{0, 0, -1, .3};
  double folK = 0, folT = 0; bool hasDk = false; Deke dk; double dkCd = 0, dkLat = 0, dkF = 0; bool dkHeld = false;
  double hs = 0, hsCd = 0, hb = 0; bool turnHard = false; double sprT = 0; int dmF = 0, dmT = 0; bool kd = false; double stunMax = 0, step = 0;
  double pkF = 0; PkLabel pkL; std::vector<Waypt> iw; double idel = 0; bool benchGhost = false;
  bool scrInit = false; double sx = 0, sy = 0, sv = 0, sf = 1, stopT = 0;
  int num = -1;
  Col skin;
  double call = 0;   // a teammate calling for the puck (the "!" over his head)
};

enum Pose { GP_NONE, GP_LO, GP_KICK, GP_HI, GP_BODY, GP_DIVE, GP_POKE, GP_COVER, GP_LOOK };
struct GAnim { Pose p = GP_NONE; double s = 1, t = 0, i = .09, h = .38, o = .22; bool done = false; };
struct Goalie {
  int team = 0; double r = 5; GS gs; std::string nm; bool out = false, user = false; GSrc *src = nullptr;
  double x = 0, y = 0, vx = 0, vy = 0;
  bool hasAn = false; GAnim an; bool hasRq = false; struct { double t; Pose p; double s; } rq{0, GP_NONE, 1};
  double sv = 0, svSide = 1; Skater *pk = nullptr; double mv = 0, fum = 0, cd = 0;
  double aimY = 0, aimWY = 0, aimZ = 0, aimT = -99, hitT = -99, rqH = -1, stkOff = -99, hugK = 0, hugS = 1, slideK = 0, pE = 0, pEv = 0, pEt = 0, form = 0, conf = 0; int svRun = 0; bool read = true; int rid = -1, fz = -1;   // where he's reaching for (puck offset from him, 3D height) — drives the save animation
  bool hasBite = false; struct { double t, s; } bite{0, 1};
  double ast = 100; bool broke = false; int set = 0; int faced = 0; double hot = -1, lastSv = -99;
  std::vector<PerkE> pks; double pkCd[PK_N] = {0}; double pkF = 0; PkLabel pkL;
  std::vector<Waypt> iw; double idel = 0;
};
struct Box { Skater *p; double t; bool ko = false; int ob = 0; };   // ob: 1 over the boards, 2 through the glass
struct Team {
  int score = 0, sog = 0, shots = 0; std::vector<Src *> bench; std::vector<Skater *> on; Goalie g; bool pulled = false;
  Col col, stripe; std::string name; double lineT = 0; std::vector<Box> box;
  std::vector<std::vector<Src *>> lines; int li = 0; std::vector<Src *> allSk; Skater *extra = nullptr; double pullC = -1; Skater *prs = nullptr;
  int hits = 0, pa = 0, pc = 0, fow = 0, pen = 0, ppn = 0, shg = 0; double ppt = 0, toa = 0; bool swapped = false;
  GSrc *bk = nullptr;   // Ultimate Franchise: the G2 card (comes in if the starter is pulled)
};
enum ShotKind { SH_WRIST, SH_SLAP, SH_BACK, SH_MANUAL };
struct Shot { int team = 0; Skater *by = nullptr; double t = 0, spd = 0, h = .3; int flk = 0, otk = 0; bool dk = false; ShotKind kind = SH_WRIST; bool gnd = false, tip = false, defl = false; };
struct Puck {
  double x = RK.L / 2, y = RK.cy, vx = 0, vy = 0; Skater *owner = nullptr, *last = nullptr, *lastPasser = nullptr, *passTo = nullptr;
  bool hasShot = false; Shot shot; long chk = -1; int id = 0; int ice = -1; double bz = 0, bvz = 0, wob = 0, mag = 0; bool pl = false;
  bool tipOn = false; int8_t tipT[16]; int8_t thru[16]; int8_t sth[16]; int sthId = -1; bool saucer = false; double passT = -1e9, pp = 0;
  long lbk = -1, blk = -1; double hop = 0, roll = 0; int hopN = 0; std::map<int, int> hopR; int hopRid = -1;
  void clearTips() { tipOn = true; memset(tipT, -1, sizeof tipT); }
  void clearThru() { memset(thru, -1, sizeof thru); }
};
enum Phase { PH_PREVIEW, PH_INTRO, PH_FACEOFF, PH_PLAY, PH_STOP, PH_GOAL, PH_TRANS, PH_HOLD };
struct Banner { double t = 0; std::string txt, sub; Col col; };
struct Faceoff { double x = 0, y = 0, t = 0, show = 1, close = 1; int ease = 0; std::string res; };
struct Ref { double x = 0, y = 0, vx = 0, vy = 0, ang = 0, arm = 0, ph = 0; bool drop = false; };
struct Battle { Skater *a, *b; struct { double x, y, nx, ny; } w; double t = 0, prog = .5; int ls = 0; bool user = false; };
struct Celeb { int team = 0; Skater *sc = nullptr, *as = nullptr; double t = 0; bool hasTg = false; double tgx = 0, tgy = 0; bool gl = false; };
struct NetBulge { bool on = false; double y = 0, a = 0, t = 0; };
enum BottleS { BT_NET, BT_FLY, BT_ICE };
struct Bottle { BottleS s = BT_NET; double x = 0, y = 0, z = 0, vx = 0, vy = 0, vz = 0, a = 0, va = 0; };
struct Spray { double x, y, z, vx, vy, vz, t, l; };
struct Glass { double x, y, nx, ny, a, t; };
struct HitFx { double x, y, t; bool big, me; };
struct ScratchSeg { float x0, y0, x1, y1, w, a; };
struct ScratchBatch { int id; std::vector<ScratchSeg> s; };
struct MeStats { int g = 0, a = 0, sog = 0, hits = 0, tk = 0, pim = 0, shots = 0, fow = 0, fot = 0; };
struct PvTeam { std::string name, rec, recL; Col col, stripe; struct Row { std::string pos, nm; int g; std::vector<PerkE> pk; }; std::vector<Row> sk; Row gk; std::string gsv, gsub; bool hasG = false; };
struct Input {
  double mx = 0, my = 0, ax = 0, ay = 0, am = 0, rsx = 0, rsy = 0, rsm = 0;
  bool pass = false, xdown = false, ppass = false, block = false, check = false, chkDown = false, dk = false, dkP = false, tri = false, sprint = false, spin = false, rb = false, lb = false;
  bool hasRel = false; double relx = 0, rely = 0;
  bool lHold = false; int lpass = -1; bool rDown = false;   // rDown: R held (shot type B)   // L held: SQUARE / TRIANGLE / CIRCLE pass to the teammate under that button
};
struct Layout { double s, k, top, viewLen, viewWid, cx, cy; };
struct Pt { double x, y; };

struct Game {
  int per = 1; double clock = SK_PER; Phase phase = PH_FACEOFF; double stopT = 0, cam = RK.L / 2, camY = RK.Wd / 2;
  Team T[2]; Puck puck; MeStats me; double gt = 0; Banner banner; Faceoff fo; double callPass = 0;
  Skater *user = nullptr; int foN = 0; bool ftUsed = false; bool ftU[2] = {false, false};
  bool hasBat = false; Battle bat; double batCd = 0; bool hasRef = true; Ref ref;
  struct { double t = 0; PvTeam T[2]; } pv; double introT = 0; bool tap = false;
  bool hasNextFo = false; Pt nextFo{0, 0}; bool endAfter = false, nextPer = false;
  bool hasCel = false; Celeb cel; bool hasNetIn = false; struct { int ti; double gx, s; } netIn{0, 0, 1};
  NetBulge nb[2]; Bottle btl[2]; std::vector<Spray> spr; std::vector<Glass> gls; std::vector<HitFx> fx;
  double shk = 0, hstop = 0, hitFl = 0, lx = 0, ly = 0; Col gcol; double goalT = 0;
  struct { std::vector<ScratchBatch> b; std::vector<ScratchSeg> cur; int id = 0; } scr;
  struct { bool on = false, dn = false, fire = false, aim = false; int kind = 0; double t = 0, back = 0, rest = 0, hi = 0, rx = 0, h = .25; } rs;
  struct { bool on = false; double t = 0; } xh; struct { bool dn = false; double t = 0; } ck; double dimeOk = 0;
  double lastMx = 0, lastMy = 0; bool gcd = false; struct { double t = 0; int li = 0; } lineNote;
  std::map<const void *, std::array<int, PK_N>> pkU; double pullT = 0, benchCd = 0;
  // pose warm-up
  struct WarmItem { Key k; int d; double stride; Col col, stripe; bool star; Col skin; bool rh; };
  std::vector<WarmItem> warmQ; double warmT = -1; std::map<uint64_t, bool> warmD;
  struct { double x, y, w, h; } bugB{0, 0, 0, 0};
  std::vector<std::unique_ptr<Skater>> pool; std::vector<std::unique_ptr<Src>> srcs; std::vector<std::unique_ptr<GSrc>> gsrcs;
  struct { bool on = false; double t = 0, dec = 0; Goalie *g = nullptr; } hold;
  int pkLabelId = 0; bool sim = false;
  bool ut = false; std::map<std::string, int> utG, utA, utPM;   // Ultimate Franchise: goals, assists, +/- per card player   // sim: a test run (no camera smoothing changes)
};
extern Game *SK;
// who plays: built by skStart (Quick Play) or by the mode (Ultimate Franchise cards and CPU teams)
struct Rosters {
  bool ut = false; std::vector<Src *> home, away; std::vector<std::vector<Src *>> hl, al;
  double hg = 5, ag = 5; std::string hn = "HOME", an = "AWAY"; Col hc, ac, hs, as; std::string hgn = "G", agn = "G"; GS hgs, ags;
  GSrc *hbk = nullptr, *abk = nullptr, *hgo = nullptr, *ago = nullptr;
  std::vector<std::unique_ptr<Src>> own; std::vector<std::unique_ptr<GSrc>> gown;   // players made for this game
};
extern bool g_autoplay;   // tests: the CPU plays your skater

struct Feed { std::string txt; Col col; double t = 0, y = -1; };
extern std::vector<Feed> feed;
void pushFeed(const std::string &txt, Col col);
inline void pushFeed(const std::string &txt, const char *col) { pushFeed(txt, hex(col)); }

// game options
struct QuickOpts { int diff = 1; bool autoAim = true; bool sfx = true; bool shotB = false; };   // shotB: R shoots, the right stick only aims   // what the engine reads (set from the settings and the mode)
extern QuickOpts QO;
// last finished game (result screen)
struct Result { std::string hn, an; int hs = 0, as = 0, hsh = 0, ash = 0; bool so = false; MeStats f; bool valid = false; };
extern Result RS;

// ---- engine (sk_core.cpp)
void skStart();
void skUpdate(double dt, const Pad &pad, uint32_t press);
std::vector<Skater *> skAll();
bool skInZone(const Skater *p);
Pt stickPt(const Skater *p);
Pt skATarget(const Skater *p, double mx, double my, bool &none);
Pt skAimTarget(const Skater *p);                   // where the held shot (right stick) is aimed
double skShotOpen(const Skater *u, double ty);     // the net at ty from the puck: 1 open, 0 the goalie's body is in the way, -1 off the net
double skAimSpread(const Skater *u);               // the shot's spread (half angle, radians) for the aim cone
bool skBenchOpen();
struct BenchSpot { double x, y, r; };
inline BenchSpot skBench() { return {RK.L / 2 - tdir(0) * 9, RK.Wd - 7.5, 5.5}; }
double skFoWindow(const Skater *p);
double skFoEase(const Faceoff &F, double u);
int pkT(const Skater *p, int id); int pkLeftS(const Skater *p, int id);
double skSpinCost(const Skater *p);
void skResume();
void skEnd();
void skQuit();
void sfx(int id, double vol, double rate = 1, bool loop = false);
double sndAt(double x, double y);
Col skinOf(const std::string &nm);
int skNum(Skater *p);
void skFaceoff(double x, double y);
// pad state the engine reads this frame (set by main)
extern Pad g_pad; extern uint32_t g_press;
extern Touch g_touch;

// ---- drawing (sk_draw.cpp)
Layout skLayout();
Pt skW2S(const Layout &lay, double x, double y, double z = 0);
Pt skCamClamp(const Layout &lay, double x, double y);
void skDraw();
void skDrawPreview();
void skWarm(const Layout &lay, int n);
void cached(const Key &k, const std::function<void()> &fn);
void cachedScaled(const Key &k, double s, const std::function<void()> &fn);

// ---- menus, transitions, pause (ui.cpp)
enum AppState { ST_MENU, ST_PLAY, ST_RESULT };
extern AppState state; extern bool paused;
void goMode(const std::string &name, std::function<void()> fn, Col col, bool game, const std::string &sub = "");
bool trActive(); double trLeft();
void drawTrans(); void trTick();
void drawPause(); void pausePad(uint32_t press, const Pad &pad, const Touch &touch);
void drawMenu(); void menuPad(uint32_t press, const Pad &pad, const Touch &touch);
extern int pauseTab;
void tx(const std::string &t, double x, double y, double sz, Col c, Align al = AL_LEFT, bool it = false);
double fsz(double s);
extern double TXL, TXR;
void wordmark(double x, double y, double s);

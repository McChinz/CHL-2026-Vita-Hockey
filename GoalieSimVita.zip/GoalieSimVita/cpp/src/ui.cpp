// CHL 2026 native - the pause screen, the mode transition and the shared text helpers (the menus are in menu.cpp).
#include "game.h"
#include "sk_int.h"
#include "menu.h"

AppState state = ST_MENU; bool paused = false; Result RS;
double TXL = 0, TXR = 1e4;

double fsz(double s) { return s < .024 ? s + (.024 - s) * .4 : s; }
// text that always fits between TXL and TXR
void tx(const std::string &t, double x, double y, double sz, Col c, Align al, bool) {
  double px = fsz(sz) * U; ctx.align(al); ctx.baseline(BL_MIDDLE); ctx.font(px);
  double L = std::max(0.0, TXL), R = std::min((double)W, TXR), mw = al == AL_CENTER ? 2 * std::min(x - L, R - x) : al == AL_RIGHT ? x - L : R - x;
  if (mw > 8) { double w = ctx.measure(t); if (w > mw) ctx.font(px * mw / w); }
  ctx.fill(c); ctx.fillText(t, x, y);
}
void wordmark(double x, double y, double s) {
  ctx.textMid(AL_LEFT); ctx.font(s); ctx.fill("#fff"); ctx.fillText("CHL", x, y);
  double w1 = ctx.measure("CHL "); ctx.fill(ACC); ctx.quad(x + w1 - s * .12, y + s * .42, x + w1 + s * .08, y - s * .42, x + w1 + s * .2, y - s * .42, x + w1, y + s * .42);
  ctx.fill("#fff"); ctx.fillText("2026", x + w1 + s * .3, y);
}
// ---------------------------------------------------------------- transitions
struct Trans { bool on = false; double t0 = 0; std::string name, sub; std::function<void()> fn; Col col; bool game = false, done = false; double hold = 0; };
static Trans TR;
static const double TR_IN = .36, TR_LOAD = .42, TR_OUT = 1.3, TR_END = 1.68;
static double trT() { if (!TR.on) return 0; double raw = (now() - TR.t0) / 1000, Hh = TR.hold; return raw < TR_LOAD + .05 ? raw : raw < TR_LOAD + .05 + Hh ? TR_LOAD + .05 : raw - Hh; }
bool trActive() { return TR.on; }
double trLeft() { return TR.on ? std::max(0.0, TR_END - trT()) : 0; }
void goMode(const std::string &name, std::function<void()> fn, Col col, bool game, const std::string &sub) {
  if (TR.on) return; modal.on = false; TR = Trans(); TR.on = true; TR.t0 = now(); TR.name = name; TR.sub = sub; TR.fn = fn; TR.col = col; TR.game = game; TR.hold = game ? 0 : .85;
}
// the transition's clock: runs the load step under cover, then ends (called every frame, drawn or not)
void trTick() {
  if (!TR.on) return;
  double t = trT();
  if (!TR.done && t >= TR_LOAD) { TR.done = true; btns.clear(); if (TR.hold > 0) ctx.cacheClear(); auto fn = TR.fn; fn(); mFocus.clear(); mPadUsed = false; }
  if (t >= TR_END) TR.on = false;
}
void drawTrans() {
  trTick();
  if (!TR.on) return;
  double t = trT();
  const int N = 6; double sk = H * .28, bw = (W + sk * 2) / N;
  auto ez = [](double k) { return 1 - std::pow(1 - clamp(k, 0, 1), 3); }; auto ei = [](double k) { return std::pow(clamp(k, 0, 1), 3); };
  static const char *cols[6] = {"#0b1024", "#121b36", "#0b1024", "#1a1430", "#0b1024", "#121b36"};
  double offs[N]; bool full = true;
  for (int i = 0; i < N; i++) { double d = i * .035; offs[i] = t < TR_OUT ? (1 - ez((t - d) / (TR_IN - .12))) * (W + sk * 2 + bw) : -ei((t - TR_OUT - d) / (TR_END - TR_OUT - .15)) * (W + sk * 2 + bw); if (std::fabs(offs[i]) >= 1) full = false; }
  if (full) { ctx.fill("#0d1328"); ctx.fillRect(0, 0, W, H); }
  else for (int i = 0; i < N; i++) { double x0 = -sk + i * bw + offs[i] - 1, x1 = x0 + bw + 2;
    ctx.fill(cols[i]); ctx.quad(x0 + sk, 0, x1 + sk, 0, x1 - sk, H, x0 - sk, H);
    ctx.fill(i % 2 ? TR.col : ACC); ctx.quad(x0 + sk, 0, x0 + sk + .012 * U, 0, x0 - sk + .012 * U, H, x0 - sk, H); }
  double cov = t < TR_OUT ? ez((t - .05) / TR_IN) : 1 - ez((t - TR_OUT) / (TR_END - TR_OUT - .1));
  if (cov > .05) { ctx.alpha(clamp(cov, 0, 1) * .5); ctx.fill("#dbeafe");
    for (int i = 0; i < 9; i++) { double y = H * (.12 + .09 * i), sp = std::fmod(t * 2.6 + i * .37, 1.0), len = W * (.18 + .1 * (i % 3)), x = W - sp * (W + len * 2) + len; ctx.fillRect(x, y, len, std::max(1.5, .004 * U)); }
    ctx.alpha(1); }
  if (cov < .15) return;
  ctx.alpha(clamp((cov - .15) / .5, 0, 1));
  double ent = ez((t - .12) / .4), lv = t > TR_OUT ? ei((t - TR_OUT) / .3) : 0, nx = W / 2 + (1 - ent) * W * .35 - lv * W * .45 + (t - .4) * .03 * U, ny = H * .4;
  ctx.fill(TR.col); ctx.fillRect(nx - .36 * U, ny + .055 * U, .72 * U, .008 * U);
  ctx.textMid(); ctx.fill("#fff"); ctx.fitPx(TR.name, .1 * U, W * .9); ctx.fillText(TR.name, nx, ny);
  wordmark(W / 2 - .11 * U, ny - .1 * U, .04 * U);
  if (!TR.sub.empty()) { ctx.textMid(); ctx.fill("#e2e8f0"); ctx.fitPx(TR.sub, fsz(.032) * U, W * .86); ctx.fillText(TR.sub, nx, ny + .11 * U); }
  if (!TR.game) { ctx.fill("#94a3b8"); ctx.font(fsz(.022) * U); ctx.textMid(AL_LEFT); std::string l = "LOADING" + std::string("...").substr(0, 1 + (int)std::floor(t * 4) % 3); ctx.fillText(l, W / 2 - ctx.measure("LOADING...") / 2, H * .6); }
  ctx.alpha(1);
}

// ---------------------------------------------------------------- the pause screen (broadcast style)
int pauseTab = 0;
static void togglePause() { if (state != ST_PLAY || TR.on) return; paused = !paused; mFocus = "resume"; mPadUsed = true; }
// START pauses / resumes; on the pause screen the pad moves like any menu (L / R switch tabs, O resumes)
void pausePad(uint32_t press, const Pad &pad, const Touch &touch) {
  if (press & B_START) { togglePause(); return; }
  if (!paused) return;
  if (press & B_L) { pauseTab = (pauseTab + 2) % 3; return; }
  if (press & B_R) { pauseTab = (pauseTab + 1) % 3; return; }
  if (press & B_CIRCLE) { paused = false; return; }
  menuPad(press, pad, touch);
}
static std::string ABBR(const std::string &n) { std::string o; for (char ch : n) if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) o += ch; o = upper(o.substr(0, 3)); return o.empty() ? "---" : o; }
void drawPause() {
  btns.clear();
  ctx.fill(rgba(10, 14, 30, .95)); ctx.fillRect(0, 0, W, H);
  ctx.fill(rgba(255, 255, 255, .025)); for (int i = -4; i < 12; i++) ctx.quad(i * W * .12, 0, i * W * .12 + W * .05, 0, i * W * .12 - W * .15, H, i * W * .12 - W * .2, H);
  Team &A = SK->T[0], &B = SK->T[1];
  double m = .03 * U, top = safeTop + .035 * U;
  ctx.textMid(AL_LEFT); ctx.font(.026 * U); ctx.fill("#cbd5e1"); ctx.fillText("PAUSE", m, top);
  double pw = ctx.measure("PAUSE  "); ctx.fill("#fff");
  std::string per = SK->per > 3 ? "OVERTIME" : std::string(SK->per == 1 ? "1ST" : SK->per == 2 ? "2ND" : "3RD") + " PERIOD";
  ctx.fillText(ABBR(A.name) + " " + istr(A.score) + " - " + ABBR(B.name) + " " + istr(B.score) + "  |  " + mmss(SK->clock) + "  |  " + per, m + pw, top);
  ctx.fill(ACC); ctx.fillRect(m, top + .022 * U, .06 * U, .006 * U);
  const char *tabs[3] = {"HOME", "GAME STATS", "CONTROLS"}; double ty = top + .055 * U, th = .058 * U, tw = std::min(.27 * U, (W - 2 * m) / 3 - .01 * U), sk = th * .35;
  for (int k = 0; k < 3; k++) { double x = m + k * (tw + .012 * U); bool on = pauseTab == k;
    ctx.fill(on ? ACC : rgba(51, 65, 85, .85)); ctx.quad(x + sk, ty, x + tw + sk, ty, x + tw - sk, ty + th, x - sk, ty + th);
    ctx.fill("#fff"); ctx.textMid(); ctx.font(.024 * U); ctx.fillText(tabs[k], x + tw / 2, ty + th / 2 + 1); pushBtn(std::string("ptab:") + char('0' + k), x - sk, ty, tw + 2 * sk, th, tabs[k], true); }
  double bodyY = ty + th + .035 * U, footH = .06 * U, bodyH = H - bodyY - footH - .02 * U;
  struct R4 { double x, y, w, h; } L{m, bodyY, W * .44, bodyH}, R{W * .5, bodyY, W * .5 - m, bodyH};
  { double ch = std::min(L.h * .55, L.w * .45);
    ctx.fill(rgba(30, 41, 59, .85)); ctx.fillRect(L.x, L.y, L.w, ch);
    ctx.fill(rgba(255, 255, 255, .04)); for (int i = 0; i < 6; i++) ctx.fillRect(L.x, L.y + i * ch / 6, L.w, ch / 12);
    ctx.fill(ACC); ctx.fillRect(L.x, L.y + ch - .008 * U, L.w, .008 * U);
    ctx.fill("#fff"); ctx.textMid(); ctx.font(std::min(.1 * U, L.w * .16)); ctx.fillText("RESUME", L.x + L.w / 2, L.y + ch / 2);
    pushBtn("resume", L.x, L.y, L.w, ch, "RESUME");
    double ih = std::min(.07 * U, (L.h - ch) / 2.2), y = L.y + ch + .012 * U;
    ctx.fill(rgba(148, 163, 184, .35)); ctx.fillRect(L.x + L.w * .03, y + ih, L.w * .94, 1.5);
    ctx.fill("#fca5a5"); ctx.font(.032 * U); ctx.fillText("QUIT MATCH", L.x + L.w / 2, y + ih / 2); pushBtn("quit", L.x, y, L.w, ih, "QUIT MATCH");
    if (mode == "ut") { ctx.font(.0222 * U); ctx.fill("#94a3b8"); ctx.textMid(); ctx.fillText("Quitting counts as a loss and pays no coins.", L.x + L.w / 2, L.y + ch + .012 * U + ih * 1.45); }
    { double cy2 = y + ih * 2.0, cw = L.w * .8, cx2 = L.x + (L.w - cw) / 2; extern bool g_camHigh;   // the camera, switchable mid-game
      ctx.fill(g_camHigh ? rgba(37, 99, 235, .85) : rgba(71, 85, 105, .85)); ctx.fillRect(cx2, cy2, cw, ih * .85);
      ctx.fill("#fff"); ctx.font(.028 * U); ctx.textMid(); ctx.fillText(std::string("CAMERA: ") + (g_camHigh ? "HIGH" : "LOW"), L.x + L.w / 2, cy2 + ih * .43); pushBtn("pcam", cx2, cy2, cw, ih * .85, "CAMERA");
      extern bool g_showFps; double fy2 = cy2 + ih;   // the performance read-out
      ctx.fill(g_showFps ? rgba(22, 163, 74, .85) : rgba(71, 85, 105, .85)); ctx.fillRect(cx2, fy2, cw, ih * .7);
      ctx.fill("#fff"); ctx.font(.024 * U); ctx.fillText(std::string("SHOW FPS: ") + (g_showFps ? "ON" : "OFF"), L.x + L.w / 2, fy2 + ih * .35); pushBtn("pfps", cx2, fy2, cw, ih * .7, "FPS"); }
  }
  auto logo = [&](double x, double y, double r, Col col, Col st, const std::string &nm) { ctx.fill(col); ctx.disc(x, y, r); ctx.stroke(st); ctx.lineWidth(r * .16); ctx.ring(x, y, r * .84);
    ctx.fill(st); ctx.font(r * .62); ctx.textMid(); ctx.fillText(ABBR(nm).substr(0, 1), x, y + 1); };
  double hy = R.y + .04 * U, lr = .035 * U;
  logo(R.x + lr, hy, lr, A.col, A.stripe, A.name); logo(R.x + R.w - lr, hy, lr, B.col, B.stripe, B.name);
  ctx.font(.06 * U); ctx.fill("#e2e8f0"); ctx.textMid(AL_RIGHT); ctx.fillText(ABBR(A.name), R.x + R.w * .37, hy); ctx.textMid(AL_LEFT); ctx.fillText(ABBR(B.name), R.x + R.w * .63, hy);
  { double bx0 = R.x + R.w * .39, bx1 = R.x + R.w * .61, bh = .05 * U; ctx.fill("#94a3b8"); ctx.quad(bx0 + bh * .25, hy - bh / 2, bx1 + bh * .25, hy - bh / 2, bx1 - bh * .25, hy + bh / 2, bx0 - bh * .25, hy + bh / 2);
    ctx.fill("#0f172a"); ctx.textMid(); ctx.font(.045 * U); ctx.fillText(fmt("%d-%d", A.score, B.score), R.x + R.w / 2, hy + 1); }
  double ry0 = hy + .06 * U;
  if (pauseTab == 0) {
    struct Rw { std::string n, a, b; double va, vb; };
    std::vector<Rw> rows = {{"TOTAL SHOTS", istr(A.sog), istr(B.sog), (double)A.sog, (double)B.sog}, {"HITS", istr(A.hits), istr(B.hits), (double)A.hits, (double)B.hits},
      {"TIME ON ATTACK", mmss(A.toa), mmss(B.toa), A.toa, B.toa}, {"PASSING", pct(A.pc, A.pa), pct(B.pc, B.pa), A.pa ? (double)A.pc / A.pa : 0, B.pa ? (double)B.pc / B.pa : 0},
      {"FACEOFFS WON", istr(A.fow), istr(B.fow), (double)A.fow, (double)B.fow}, {"PENALTY MINUTES", mmss(A.pen * 120), mmss(B.pen * 120), (double)A.pen, (double)B.pen},
      {"POWERPLAYS", istr(A.ppn), istr(B.ppn), (double)A.ppn, (double)B.ppn}, {"POWERPLAY MINUTES", mmss(A.ppt * 6), mmss(B.ppt * 6), A.ppt, B.ppt},
      {"SHORTHANDED GOALS", istr(A.shg), istr(B.shg), (double)A.shg, (double)B.shg},
      {"SAVE %", svp(B.sog - B.score, B.sog), svp(A.sog - A.score, A.sog), B.sog ? (double)(B.sog - B.score) / B.sog : 0, A.sog ? (double)(A.sog - A.score) / A.sog : 0}};
    double rh = std::min(.062 * U, (R.y + R.h - ry0) / rows.size());
    for (size_t k = 0; k < rows.size(); k++) { auto &r = rows[k]; double y = ry0 + k * rh, cx = R.x + R.w / 2;
      ctx.fill("#e2e8f0"); ctx.font(.021 * U); ctx.textMid(); ctx.fillText(r.n, cx, y + rh * .28);
      double lw = R.w * .6, lx = cx - lw / 2, ly = y + rh * .62; ctx.fill(rgba(148, 163, 184, .25)); ctx.fillRect(lx, ly, lw, 2);
      if (r.va + r.vb > 0) { double f = r.va / (r.va + r.vb); ctx.fill(rgba(96, 165, 250, .9)); ctx.fillRect(lx, ly, lw * f, 2); ctx.fill("#fff"); ctx.disc(lx + lw * f, ly + 1, .006 * U); }
      ctx.font(.034 * U); ctx.fill("#f8fafc"); ctx.textMid(AL_LEFT); ctx.fillText(r.a, R.x, y + rh * .55); ctx.textMid(AL_RIGHT); ctx.fillText(r.b, R.x + R.w, y + rh * .55); }
  } else {
    std::vector<std::pair<std::string, std::string>> lines;
    const std::string HD = "\x01";
    if (pauseTab == 1) { auto &me = SK->me;
      lines = {{"YOUR GAME", HD}, {"GOALS", istr(me.g)}, {"ASSISTS", istr(me.a)}, {"POINTS", istr(me.g + me.a)}, {"SHOTS ON GOAL", fmt("%d / %d shots", me.sog, me.shots)},
        {"HITS", istr(me.hits)}, {"TAKEAWAYS", istr(me.tk)}, {"FACEOFFS", fmt("%d / %d", me.fow, me.fot)}, {"PENALTY MINUTES", istr(me.pim)}, {"GOALIES", HD},
        {"HOME GOALIE (" + A.g.nm + ")", fmt("%d SV / %d SA   ", B.sog - B.score, B.sog) + svp(B.sog - B.score, B.sog)}, {"AWAY GOALIE (" + B.g.nm + ")", fmt("%d SV / %d SA   ", A.sog - A.score, A.sog) + svp(A.sog - A.score, A.sog)}};
    } else lines = {{"FORWARD CONTROLS", HD}, {"LEFT STICK", "skate"}, {"R (hold)", "sprint"}, {"RIGHT STICK (puck)", QO.shotB ? "aims (shot type B; X: tap pass, hold sprint)" : "hold up: wrist   hold back: slap   let go: shoot"}, {QO.shotB ? "R (puck)" : "RIGHT STICK SIDEWAYS", QO.shotB ? "tap: wrist   hold: slap, let go to fire" : "aims while held (blue cone = open net)"},
        {"CIRCLE (no puck)", "tap = bump; hold and let go = big hit"}, {"SQUARE", "deke: tap = pull it wide, hold = toe drag"}, {"TRIANGLE", "saucer pass"}, {"X", "pass (hold: power pass) / call / poke"},
        {"L (no puck)", "drop to block shots"}, {"L (hold, with the puck)", "SQUARE / TRIANGLE / CIRCLE: pass to him"}, {"LEFT STICK: QUICK 360", "spin deke"}, {"X on the draw", "win the faceoff"}, {"SELECT", "3D view / classic view"}};
    double lh = std::min(.05 * U, (R.y + R.h - ry0) / std::max<size_t>(1, lines.size()));
    for (size_t k = 0; k < lines.size(); k++) { double y = ry0 + k * lh + lh / 2;
      if (lines[k].second == HD) { ctx.font(.026 * U); ctx.fill(ACC); ctx.textMid(AL_LEFT); ctx.fillText(lines[k].first, R.x, y); continue; }
      ctx.fill(rgba(148, 163, 184, .18)); ctx.fillRect(R.x, y + lh / 2 - 1, R.w, 1);
      ctx.font(.0228 * U); ctx.fill("#cbd5e1"); ctx.textMid(AL_LEFT); ctx.fillText(lines[k].first, R.x, y);
      ctx.fill("#fff"); ctx.textMid(AL_RIGHT); double lw = ctx.measure(lines[k].first) + .03 * U; ctx.fitPx(lines[k].second, .026 * U, R.w - lw); ctx.fillText(lines[k].second, R.x + R.w, y); }
  }
  double fy = H - footH / 2 - .012 * U; ctx.fill(rgba(2, 6, 23, .6)); ctx.fillRect(0, fy - footH / 2, W, footH);
  const char *hints[4][2] = {{"X", "SELECT"}, {"O", "RESUME"}, {"L", "PREVIOUS"}, {"R", "NEXT"}}; double hx = m;
  for (auto &h : hints) { ctx.font(.0216 * U); double bw = ctx.measure(h[0]) + .02 * U, bh2 = .034 * U;
    ctx.stroke("#e2e8f0"); ctx.lineWidth(1.5); ctx.rr(hx, fy - bh2 / 2, bw, bh2, bh2 * .3); ctx.strokePath(); ctx.fill("#e2e8f0"); ctx.textMid(); ctx.fillText(h[0], hx + bw / 2, fy + 1);
    ctx.textMid(AL_LEFT); ctx.font(.0228 * U); ctx.fillText(h[1], hx + bw + .01 * U, fy + 1); hx += bw + .02 * U + ctx.measure(h[1]) + .03 * U; }
}

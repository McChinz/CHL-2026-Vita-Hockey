// CHL 2026 native - menus (Quick Play), the result screen, the pause screen and the mode transition.
// Same broadcast look as the web build. D-pad / left stick moves, X selects, O goes back; touch works too.
#include "game.h"
#include "sk_int.h"

AppState state = ST_MENU; bool paused = false; Result RS;
double TXL = 0, TXR = 1e4;
static const Col ACC = hex("#f26b5b");

double fsz(double s) { return s < .024 ? s + (.024 - s) * .4 : s; }
// text that always fits between TXL and TXR
void tx(const std::string &t, double x, double y, double sz, Col c, Align al, bool) {
  double px = fsz(sz) * U; ctx.align(al); ctx.baseline(BL_MIDDLE); ctx.font(px);
  double L = std::max(0.0, TXL), R = std::min((double)W, TXR), mw = al == AL_CENTER ? 2 * std::min(x - L, R - x) : al == AL_RIGHT ? x - L : R - x;
  if (mw > 8) { double w = ctx.measure(t); if (w > mw) ctx.font(px * mw / w); }
  ctx.fill(c); ctx.fillText(t, x, y);
}
void wordmark(double x, double y, double s) {
  ctx.textMid(AL_LEFT); ctx.font(s); ctx.fill("#fff"); ctx.fillText("CHL", x, y);
  double w1 = ctx.measure("CHL "); ctx.fill(ACC); ctx.quad(x + w1 - s * .12, y + s * .42, x + w1 + s * .08, y - s * .42, x + w1 + s * .2, y - s * .42, x + w1, y + s * .42);
  ctx.fill("#fff"); ctx.fillText("2026", x + w1 + s * .3, y);
}
static void menuBG() {
  cached(Key("mbg") << W << H, [] {
    Grad g; g.kind = 0; g.a[0] = 0; g.a[1] = 0; g.a[2] = W; g.a[3] = H; g.add(0, hex("#0b1024")); g.add(.6, hex("#111a33")); g.add(1, hex("#2a0f1c"));
    ctx.fill(g); ctx.fillRect(0, 0, W, H);
    ctx.fill(rgba(255, 255, 255, .022)); for (int i = -4; i < 12; i++) ctx.quad(i * W * .12, 0, i * W * .12 + W * .05, 0, i * W * .12 - W * .15, H, i * W * .12 - W * .2, H); });
}
static void menuSnow() {
  double t = now() / 1000;
  for (int i = 0; i < 34; i++) { double sp = 18 + (i * 37 % 23), x = std::fmod(i * 197.3 + t * sp, W + 60) - 30, y = std::fmod(i * 131.7, H) + std::sin(t * .6 + i) * 12, r = 1.2 + (i % 4) * .7;
    ctx.alpha(.05 + (i % 5) * .018); ctx.fill(i % 3 ? "#dbeafe" : "#93c5fd"); ctx.fillRect(x, y, r * 3.2, r); }
  ctx.alpha(1);
}
// ---- buttons: slanted broadcast buttons; the focused one gets a glowing outline
struct Btn { std::string id; double x, y, w, h; bool dis; };
static std::vector<Btn> btns; static std::string mFocus;
static void ui(const std::string &id, double x, double y, double w, double h, const std::string &label, Col col, bool on, double fs) {
  double sk = std::min(h * .22, 10.0), ab = std::max(4.0, h * .08); bool neutral = col == hex("#334155") || col == hex("#475569");
  auto quad = [&](double x0, double x1, Col c) { ctx.fill(c); ctx.quad(x0 + sk, y, x1 + sk, y, x1 - sk, y + h, x0 - sk, y + h); };
  quad(x + sk, x + w - sk, on ? rgba(30, 41, 59, .96) : rgba(30, 41, 59, .45));
  if (on && !neutral) { ctx.alpha(.38); quad(x + sk, x + w - sk, col); ctx.alpha(1); quad(x + sk, x + sk + ab, col); }
  ctx.fill(on ? "#fff" : "#64748b"); ctx.textMid();
  double px = std::min(fs * U, h * .62), mw = w - 2 * sk - std::max(8.0, h * .3); ctx.font(px); double tw = ctx.measure(label); if (tw > mw) ctx.font(px * mw / tw);
  ctx.fillText(label, x + w / 2, y + h / 2 + 1);
  btns.push_back({id, x, y, w, h, !on});
}
static void drawFocus() {
  if (btns.empty()) return;
  const Btn *b = nullptr; for (auto &q : btns) if (q.id == mFocus && !q.dis) b = &q;
  if (!b) { for (auto &q : btns) if (!q.dis) { b = &q; break; } if (!b) return; mFocus = b->id; }
  double k = .5 + .5 * std::sin(now() / 220), sk = std::min(b->h * .22, 10.0);
  ctx.stroke(rgba(255, 213, 74, .55 + .45 * k)); ctx.lineWidth(3); ctx.beginPath(); ctx.moveTo(b->x + sk * 2, b->y - 2); ctx.lineTo(b->x + b->w + 2, b->y - 2); ctx.lineTo(b->x + b->w - sk * 2, b->y + b->h + 2); ctx.lineTo(b->x - 2, b->y + b->h + 2); ctx.closePath(); ctx.strokePath();
}
static void moveFocus(int dir) {
  std::vector<int> en; for (size_t i = 0; i < btns.size(); i++) if (!btns[i].dis) en.push_back((int)i); if (en.empty()) return;
  int cur = 0; for (size_t i = 0; i < en.size(); i++) if (btns[en[i]].id == mFocus) cur = (int)i;
  cur = (cur + dir + (int)en.size()) % (int)en.size(); mFocus = btns[en[cur]].id;
}
static std::string tapHit(const Touch &t) {
  static Touch prev; std::string hit;
  for (int i = 0; i < prev.n; i++) { bool still = false; for (int j = 0; j < t.n; j++) if (t.p[j].id == prev.p[i].id) still = true;
    if (!still) for (auto &b : btns) if (!b.dis && prev.p[i].x >= b.x && prev.p[i].x <= b.x + b.w && prev.p[i].y >= b.y && prev.p[i].y <= b.y + b.h) hit = b.id; }
  prev = t; return hit;
}

// ---------------------------------------------------------------- transitions
struct Trans { bool on = false; double t0 = 0; std::string name, sub; std::function<void()> fn; Col col; bool game = false, done = false; double hold = 0; };
static Trans TR;
static const double TR_IN = .36, TR_LOAD = .42, TR_OUT = 1.3, TR_END = 1.68;
static double trT() { if (!TR.on) return 0; double raw = (now() - TR.t0) / 1000, Hh = TR.hold; return raw < TR_LOAD + .05 ? raw : raw < TR_LOAD + .05 + Hh ? TR_LOAD + .05 : raw - Hh; }
bool trActive() { return TR.on; }
double trLeft() { return TR.on ? std::max(0.0, TR_END - trT()) : 0; }
void goMode(const std::string &name, std::function<void()> fn, Col col, bool game, const std::string &sub) {
  if (TR.on) return; TR = Trans(); TR.on = true; TR.t0 = now(); TR.name = name; TR.sub = sub; TR.fn = fn; TR.col = col; TR.game = game; TR.hold = game ? 0 : .85;
}
// the transition's clock: runs the load step under cover, then ends (called every frame, drawn or not)
void trTick() {
  if (!TR.on) return;
  double t = trT();
  if (!TR.done && t >= TR_LOAD) { TR.done = true; btns.clear(); if (TR.hold > 0) ctx.cacheClear(); auto fn = TR.fn; fn(); mFocus.clear(); }
  if (t >= TR_END) TR.on = false;
}
void drawTrans() {
  trTick();
  if (!TR.on) return;
  double t = trT();
  const int N = 6; double sk = H * .28, bw = (W + sk * 2) / N;
  auto ez = [](double k) { return 1 - std::pow(1 - clamp(k, 0, 1), 3); }; auto ei = [](double k) { return std::pow(clamp(k, 0, 1), 3); };
  static const char *cols[6] = {"#0b1024", "#121b36", "#0b1024", "#1a1430", "#0b1024", "#121b36"};
  double offs[N]; bool full = true;
  for (int i = 0; i < N; i++) { double d = i * .035; offs[i] = t < TR_OUT ? (1 - ez((t - d) / (TR_IN - .12))) * (W + sk * 2 + bw) : -ei((t - TR_OUT - d) / (TR_END - TR_OUT - .15)) * (W + sk * 2 + bw); if (std::fabs(offs[i]) >= 1) full = false; }
  if (full) { ctx.fill("#0d1328"); ctx.fillRect(0, 0, W, H); }
  else for (int i = 0; i < N; i++) { double x0 = -sk + i * bw + offs[i] - 1, x1 = x0 + bw + 2;
    ctx.fill(cols[i]); ctx.quad(x0 + sk, 0, x1 + sk, 0, x1 - sk, H, x0 - sk, H);
    ctx.fill(i % 2 ? TR.col : ACC); ctx.quad(x0 + sk, 0, x0 + sk + .012 * U, 0, x0 - sk + .012 * U, H, x0 - sk, H); }
  double cov = t < TR_OUT ? ez((t - .05) / TR_IN) : 1 - ez((t - TR_OUT) / (TR_END - TR_OUT - .1));
  if (cov > .05) { ctx.alpha(clamp(cov, 0, 1) * .5); ctx.fill("#dbeafe");
    for (int i = 0; i < 9; i++) { double y = H * (.12 + .09 * i), sp = std::fmod(t * 2.6 + i * .37, 1.0), len = W * (.18 + .1 * (i % 3)), x = W - sp * (W + len * 2) + len; ctx.fillRect(x, y, len, std::max(1.5, .004 * U)); }
    ctx.alpha(1); }
  if (cov < .15) return;
  ctx.alpha(clamp((cov - .15) / .5, 0, 1));
  double ent = ez((t - .12) / .4), lv = t > TR_OUT ? ei((t - TR_OUT) / .3) : 0, nx = W / 2 + (1 - ent) * W * .35 - lv * W * .45 + (t - .4) * .03 * U, ny = H * .4;
  ctx.fill(TR.col); ctx.fillRect(nx - .36 * U, ny + .055 * U, .72 * U, .008 * U);
  ctx.textMid(); ctx.fill("#fff"); ctx.fitPx(TR.name, .1 * U, W * .9); ctx.fillText(TR.name, nx, ny);
  wordmark(W / 2 - .11 * U, ny - .1 * U, .04 * U);
  if (!TR.sub.empty()) { ctx.textMid(); ctx.fill("#e2e8f0"); ctx.fitPx(TR.sub, fsz(.032) * U, W * .86); ctx.fillText(TR.sub, nx, ny + .11 * U); }
  if (!TR.game) { ctx.fill("#94a3b8"); ctx.font(fsz(.022) * U); ctx.textMid(AL_LEFT); std::string l = "LOADING" + std::string("...").substr(0, 1 + (int)std::floor(t * 4) % 3); ctx.fillText(l, W / 2 - ctx.measure("LOADING...") / 2, H * .6); }
  ctx.alpha(1);
}

// ---------------------------------------------------------------- the Quick Play menu and the result screen
static const int OVRS[4] = {50, 70, 85, 99};
static const char *DIFFN[3] = {"CASUAL", "STANDARD", "HARD"};
static void startGame() { goMode("QUICK PLAY", [] { skStart(); state = ST_PLAY; paused = false; }, hex("#16a34a"), false, "FORWARD  |  " + istr(QO.ovr) + " OVR  |  " + DIFFN[QO.diff]); }
static void menuAct(const std::string &id, int dir) {
  if (id == "ovr") { int i = 0; for (int k = 0; k < 4; k++) if (OVRS[k] == QO.ovr) i = k; QO.ovr = OVRS[(i + (dir ? dir : 1) + 4) % 4]; }
  else if (id == "hand") QO.hand = QO.hand == 'L' ? 'R' : 'L';
  else if (id == "diff") QO.diff = (QO.diff + (dir ? dir : 1) + 3) % 3;
  else if (id == "aim") QO.autoAim = !QO.autoAim;
  else if (id == "sfx") QO.sfx = !QO.sfx;
  else if (id == "play" && !dir) startGame();
  else if (id == "menu" && !dir) { state = ST_MENU; mFocus = "play"; }
}
void drawMenu() {
  btns.clear(); menuBG(); menuSnow();
  double w = std::min(W - 24.0, 1.7 * U), x = (W - w) / 2, y = safeTop + .02 * U, bh = .095 * U, bw = std::min(w, .9 * U), bx = (W - bw) / 2, g = bh + .012 * U;
  auto T = [&](const std::string &t, double s, Col c, double yy) { tx(t, W / 2, yy, s, c, AL_CENTER); };
  if (state == ST_RESULT && RS.valid) {
    bool wn = RS.hs > RS.as;
    T(wn ? "YOU WIN!" : "YOU LOSE", .075, wn ? hex("#7CFC9A") : hex("#ff5252"), y + .05 * U);
    if (RS.so) T("decided in a shootout", .028, hex("#ffb300"), y + .105 * U);
    double c1 = x + w * .22, c2 = x + w * .78, rh = .085 * U;
    tx(RS.hn, c1, y + .15 * U, .03, hex("#60a5fa"), AL_CENTER); tx(RS.an, c2, y + .15 * U, .03, hex("#ff7a7a"), AL_CENTER);
    struct Row { std::string a, b, c; bool you; } rows[3] = {{"GOALS", istr(RS.hs), istr(RS.as), false}, {"SHOTS ON NET", istr(RS.hsh), istr(RS.ash), false},
      {"YOU", fmt("%d G  %d A", RS.f.g, RS.f.a), fmt("%d SOG  %d HIT", RS.f.sog, RS.f.hits), true}};
    for (int i = 0; i < 3; i++) { double ry = y + .18 * U + i * (rh + .008 * U); ctx.fill(rgba(15, 23, 42, .62)); ctx.fillRect(x, ry, w, rh);
      tx(rows[i].a, W / 2, ry + rh / 2, .024, hex("#94a3b8"), AL_CENTER); Col cc = rows[i].you ? hex("#ffd54a") : hex("#fff"); double s = rows[i].you ? .034 : .055;
      tx(rows[i].b, c1, ry + rh / 2, s, cc, AL_CENTER); tx(rows[i].c, c2, ry + rh / 2, s, cc, AL_CENTER); }
    double ey = y + .18 * U + 3 * (rh + .008 * U) + .03 * U;
    ui("play", bx, ey + .04 * U, bw, bh, "PLAY AGAIN", hex("#2563eb"), true, .045); ui("menu", bx, ey + .04 * U + g, bw, bh, "QUICK PLAY MENU", hex("#475569"), true, .045);
  } else {
    wordmark(W / 2 - .2 * U, y + .045 * U, .07 * U);
    T("QUICK PLAY", .075, hex("#fff"), y + .14 * U);
    T("One exhibition game. Same 3v3 game, random teams. No progress saved.", .026, hex("#94a3b8"), y + .2 * U);
    double oy = y + .25 * U, ow = (w - .04 * U) / 5, oh = .07 * U;
    ui("ovr", x, oy, ow, oh, "YOU: " + istr(QO.ovr) + " OVR", hex("#7c3aed"), true, .028);
    ui("hand", x + (ow + .01 * U), oy, ow, oh, std::string("SHOOTS ") + QO.hand, hex("#0891b2"), true, .028);
    ui("diff", x + 2 * (ow + .01 * U), oy, ow, oh, DIFFN[QO.diff], hex("#ea580c"), true, .028);
    ui("aim", x + 3 * (ow + .01 * U), oy, ow, oh, QO.autoAim ? "AUTO AIM ON" : "AUTO AIM OFF", hex("#0d9488"), true, .028);
    ui("sfx", x + 4 * (ow + .01 * U), oy, ow, oh, QO.sfx ? "SOUND ON" : "SOUND OFF", hex("#64748b"), true, .028);
    double by = oy + oh + .04 * U;
    ui("play", bx, by, bw, bh, "PLAY AS FORWARD", hex("#16a34a"), true, .045);
    ui("goalie", bx, by + g, bw, bh, "PLAY AS GOALIE  -  NEXT UPDATE", hex("#2563eb"), false, .04);
    tx("LEFT / RIGHT: CHANGE AN OPTION     X: SELECT     TOUCH WORKS TOO", W / 2, H - .04 * U, .02, hex("#64748b"), AL_CENTER);
    tx("NATIVE C++ BUILD", W - .03 * U, safeTop + .03 * U, .018, hex("#475569"), AL_RIGHT);
  }
  if (mFocus.empty()) mFocus = "play";
  drawFocus();
}
void menuPad(uint32_t press) {
  if (TR.on) return;
  std::string hit = tapHit(g_touch); if (!hit.empty()) { mFocus = hit; menuAct(hit, 0); return; }
  bool row = mFocus == "ovr" || mFocus == "hand" || mFocus == "diff" || mFocus == "aim" || mFocus == "sfx";
  if (press & B_UP) { if (row) mFocus = "play"; else moveFocus(-1); }
  if (press & B_DOWN) { if (row) mFocus = "play"; else moveFocus(1); }
  if (press & B_LEFT) { if (row) menuAct(mFocus, -1); else mFocus = "ovr"; }
  if (press & B_RIGHT) { if (row) menuAct(mFocus, 1); else mFocus = "ovr"; }
  if (press & B_L) moveFocus(-1);
  if (press & B_R) moveFocus(1);
  if (press & B_CROSS) menuAct(mFocus, 0);
  if ((press & B_CIRCLE) && state == ST_RESULT) { state = ST_MENU; mFocus = "play"; }
}

// ---------------------------------------------------------------- the pause screen (broadcast style)
static int pauseTab = 0;
static void togglePause() { if (state != ST_PLAY || TR.on) return; paused = !paused; mFocus = "resume"; }
void pausePad(uint32_t press) {
  if (press & B_START) { togglePause(); return; }
  if (!paused) return;
  std::string hit = tapHit(g_touch);
  if (hit.rfind("ptab", 0) == 0) { pauseTab = hit[4] - '0'; return; }
  if (hit == "resume") { paused = false; return; }
  if (hit == "quit") { skQuit(); return; }
  if (press & B_L) pauseTab = (pauseTab + 2) % 3;
  if (press & B_R) pauseTab = (pauseTab + 1) % 3;
  if (press & B_CIRCLE) { paused = false; return; }
  if (press & (B_UP | B_DOWN)) mFocus = mFocus == "resume" ? "quit" : "resume";
  if (press & B_CROSS) { if (mFocus == "quit") skQuit(); else paused = false; }
}
void drawPause() {
  btns.clear();
  ctx.fill(rgba(10, 14, 30, .95)); ctx.fillRect(0, 0, W, H);
  ctx.fill(rgba(255, 255, 255, .025)); for (int i = -4; i < 12; i++) ctx.quad(i * W * .12, 0, i * W * .12 + W * .05, 0, i * W * .12 - W * .15, H, i * W * .12 - W * .2, H);
  Team &A = SK->T[0], &B = SK->T[1];
  double m = .03 * U, top = safeTop + .035 * U;
  ctx.textMid(AL_LEFT); ctx.font(.026 * U); ctx.fill("#cbd5e1"); ctx.fillText("PAUSE", m, top);
  double pw = ctx.measure("PAUSE  "); ctx.fill("#fff");
  std::string per = SK->per > 3 ? "OVERTIME" : std::string(SK->per == 1 ? "1ST" : SK->per == 2 ? "2ND" : "3RD") + " PERIOD";
  ctx.fillText(fmt("HOM %d - AWA %d  |  %s  |  %s", A.score, B.score, mmss(SK->clock).c_str(), per.c_str()), m + pw, top);
  ctx.fill(ACC); ctx.fillRect(m, top + .022 * U, .06 * U, .006 * U);
  const char *tabs[3] = {"HOME", "GAME STATS", "CONTROLS"}; double ty = top + .055 * U, th = .058 * U, tw = std::min(.27 * U, (W - 2 * m) / 3 - .01 * U), sk = th * .35;
  for (int k = 0; k < 3; k++) { double x = m + k * (tw + .012 * U); bool on = pauseTab == k;
    ctx.fill(on ? ACC : rgba(51, 65, 85, .85)); ctx.quad(x + sk, ty, x + tw + sk, ty, x + tw - sk, ty + th, x - sk, ty + th);
    ctx.fill("#fff"); ctx.textMid(); ctx.font(.024 * U); ctx.fillText(tabs[k], x + tw / 2, ty + th / 2 + 1); btns.push_back({std::string("ptab") + char('0' + k), x - sk, ty, tw + 2 * sk, th, false}); }
  double bodyY = ty + th + .035 * U, footH = .06 * U, bodyH = H - bodyY - footH - .02 * U;
  struct R4 { double x, y, w, h; } L{m, bodyY, W * .44, bodyH}, R{W * .5, bodyY, W * .5 - m, bodyH};
  { double ch = std::min(L.h * .55, L.w * .45);
    ctx.fill(rgba(30, 41, 59, .85)); ctx.fillRect(L.x, L.y, L.w, ch);
    ctx.fill(rgba(255, 255, 255, .04)); for (int i = 0; i < 6; i++) ctx.fillRect(L.x, L.y + i * ch / 6, L.w, ch / 12);
    ctx.fill(ACC); ctx.fillRect(L.x, L.y + ch - .008 * U, L.w, .008 * U);
    ctx.fill("#fff"); ctx.textMid(); ctx.font(std::min(.1 * U, L.w * .16)); ctx.fillText("RESUME", L.x + L.w / 2, L.y + ch / 2);
    btns.push_back({"resume", L.x, L.y, L.w, ch, false});
    double ih = std::min(.07 * U, (L.h - ch) / 2.2), y = L.y + ch + .012 * U;
    ctx.fill(rgba(148, 163, 184, .35)); ctx.fillRect(L.x + L.w * .03, y + ih, L.w * .94, 1.5);
    ctx.fill("#fca5a5"); ctx.font(.032 * U); ctx.fillText("QUIT MATCH", L.x + L.w / 2, y + ih / 2); btns.push_back({"quit", L.x, y, L.w, ih, false});
    // focus
    const Btn &f = mFocus == "quit" ? btns.back() : btns[btns.size() - 2]; double k = .5 + .5 * std::sin(now() / 220);
    ctx.stroke(rgba(255, 213, 74, .55 + .45 * k)); ctx.lineWidth(3); ctx.beginPath(); ctx.rect(f.x - 2, f.y - 2, f.w + 4, f.h + 4); ctx.strokePath(); }
  auto logo = [&](double x, double y, double r, Col col, Col st, const std::string &nm) { ctx.fill(col); ctx.disc(x, y, r); ctx.stroke(st); ctx.lineWidth(r * .16); ctx.ring(x, y, r * .84);
    ctx.fill(st); ctx.font(r * .62); ctx.textMid(); ctx.fillText(nm.substr(0, 1), x, y + 1); };
  double hy = R.y + .04 * U, lr = .035 * U;
  logo(R.x + lr, hy, lr, A.col, A.stripe, A.name); logo(R.x + R.w - lr, hy, lr, B.col, B.stripe, B.name);
  ctx.font(.06 * U); ctx.fill("#e2e8f0"); ctx.textMid(AL_RIGHT); ctx.fillText("HOM", R.x + R.w * .37, hy); ctx.textMid(AL_LEFT); ctx.fillText("AWA", R.x + R.w * .63, hy);
  { double bx0 = R.x + R.w * .39, bx1 = R.x + R.w * .61, bh = .05 * U; ctx.fill("#94a3b8"); ctx.quad(bx0 + bh * .25, hy - bh / 2, bx1 + bh * .25, hy - bh / 2, bx1 - bh * .25, hy + bh / 2, bx0 - bh * .25, hy + bh / 2);
    ctx.fill("#0f172a"); ctx.textMid(); ctx.font(.045 * U); ctx.fillText(fmt("%d-%d", A.score, B.score), R.x + R.w / 2, hy + 1); }
  double ry0 = hy + .06 * U;
  if (pauseTab == 0) {
    struct Rw { std::string n, a, b; double va, vb; };
    std::vector<Rw> rows = {{"TOTAL SHOTS", istr(A.sog), istr(B.sog), (double)A.sog, (double)B.sog}, {"HITS", istr(A.hits), istr(B.hits), (double)A.hits, (double)B.hits},
      {"TIME ON ATTACK", mmss(A.toa), mmss(B.toa), A.toa, B.toa}, {"PASSING", pct(A.pc, A.pa), pct(B.pc, B.pa), A.pa ? (double)A.pc / A.pa : 0, B.pa ? (double)B.pc / B.pa : 0},
      {"FACEOFFS WON", istr(A.fow), istr(B.fow), (double)A.fow, (double)B.fow}, {"PENALTY MINUTES", mmss(A.pen * 120), mmss(B.pen * 120), (double)A.pen, (double)B.pen},
      {"POWERPLAYS", istr(A.ppn), istr(B.ppn), (double)A.ppn, (double)B.ppn}, {"POWERPLAY MINUTES", mmss(A.ppt * 6), mmss(B.ppt * 6), A.ppt, B.ppt},
      {"SHORTHANDED GOALS", istr(A.shg), istr(B.shg), (double)A.shg, (double)B.shg},
      {"SAVE %", svp(B.sog - B.score, B.sog), svp(A.sog - A.score, A.sog), B.sog ? (double)(B.sog - B.score) / B.sog : 0, A.sog ? (double)(A.sog - A.score) / A.sog : 0}};
    double rh = std::min(.062 * U, (R.y + R.h - ry0) / rows.size());
    for (size_t k = 0; k < rows.size(); k++) { auto &r = rows[k]; double y = ry0 + k * rh, cx = R.x + R.w / 2;
      ctx.fill("#e2e8f0"); ctx.font(.021 * U); ctx.textMid(); ctx.fillText(r.n, cx, y + rh * .28);
      double lw = R.w * .6, lx = cx - lw / 2, ly = y + rh * .62; ctx.fill(rgba(148, 163, 184, .25)); ctx.fillRect(lx, ly, lw, 2);
      if (r.va + r.vb > 0) { double f = r.va / (r.va + r.vb); ctx.fill(rgba(96, 165, 250, .9)); ctx.fillRect(lx, ly, lw * f, 2); ctx.fill("#fff"); ctx.disc(lx + lw * f, ly + 1, .006 * U); }
      ctx.font(.034 * U); ctx.fill("#f8fafc"); ctx.textMid(AL_LEFT); ctx.fillText(r.a, R.x, y + rh * .55); ctx.textMid(AL_RIGHT); ctx.fillText(r.b, R.x + R.w, y + rh * .55); }
  } else {
    std::vector<std::pair<std::string, std::string>> lines;
    const std::string HD = "\x01";
    if (pauseTab == 1) { auto &me = SK->me;
      lines = {{"YOUR GAME", HD}, {"GOALS", istr(me.g)}, {"ASSISTS", istr(me.a)}, {"POINTS", istr(me.g + me.a)}, {"SHOTS ON GOAL", fmt("%d / %d shots", me.sog, me.shots)},
        {"HITS", istr(me.hits)}, {"TAKEAWAYS", istr(me.tk)}, {"FACEOFFS", fmt("%d / %d", me.fow, me.fot)}, {"PENALTY MINUTES", istr(me.pim)}, {"GOALIES", HD},
        {"HOME GOALIE (" + A.g.nm + ")", fmt("%d SV / %d SA   ", B.sog - B.score, B.sog) + svp(B.sog - B.score, B.sog)}, {"AWAY GOALIE (" + B.g.nm + ")", fmt("%d SV / %d SA   ", A.sog - A.score, A.sog) + svp(A.sog - A.score, A.sog)}};
    } else lines = {{"FORWARD CONTROLS", HD}, {"LEFT STICK", "skate"}, {"R (hold)", "sprint"}, {"RIGHT STICK (puck)", "flick up: wrist   back + up: slap"}, {"LEFT STICK", "aims the shot"},
        {"CIRCLE (no puck)", "tap = bump; hold and let go = big hit"}, {"SQUARE", "deke: tap = pull it wide, hold = toe drag"}, {"TRIANGLE", "saucer pass"}, {"X", "pass (hold: power pass) / call / poke"},
        {"L (no puck)", "drop to block shots"}, {"L (with the puck)", "spin deke"}, {"X on the draw", "win the faceoff"}, {"TOUCH", "left: skate   right: shoot / tap = pass"}};
    double lh = std::min(.05 * U, (R.y + R.h - ry0) / std::max<size_t>(1, lines.size()));
    for (size_t k = 0; k < lines.size(); k++) { double y = ry0 + k * lh + lh / 2;
      if (lines[k].second == HD) { ctx.font(.026 * U); ctx.fill(ACC); ctx.textMid(AL_LEFT); ctx.fillText(lines[k].first, R.x, y); continue; }
      ctx.fill(rgba(148, 163, 184, .18)); ctx.fillRect(R.x, y + lh / 2 - 1, R.w, 1);
      ctx.font(.0228 * U); ctx.fill("#cbd5e1"); ctx.textMid(AL_LEFT); ctx.fillText(lines[k].first, R.x, y);
      ctx.fill("#fff"); ctx.textMid(AL_RIGHT); double lw = ctx.measure(lines[k].first) + .03 * U; ctx.fitPx(lines[k].second, .026 * U, R.w - lw); ctx.fillText(lines[k].second, R.x + R.w, y); }
  }
  double fy = H - footH / 2 - .012 * U; ctx.fill(rgba(2, 6, 23, .6)); ctx.fillRect(0, fy - footH / 2, W, footH);
  const char *hints[4][2] = {{"X", "SELECT"}, {"O", "RESUME"}, {"L", "PREVIOUS"}, {"R", "NEXT"}}; double hx = m;
  for (auto &h : hints) { ctx.font(.0216 * U); double bw = ctx.measure(h[0]) + .02 * U, bh2 = .034 * U;
    ctx.stroke("#e2e8f0"); ctx.lineWidth(1.5); ctx.rr(hx, fy - bh2 / 2, bw, bh2, bh2 * .3); ctx.strokePath(); ctx.fill("#e2e8f0"); ctx.textMid(); ctx.fillText(h[0], hx + bw / 2, fy + 1);
    ctx.textMid(AL_LEFT); ctx.font(.0228 * U); ctx.fillText(h[1], hx + bw + .01 * U, fy + 1); hx += bw + .02 * U + ctx.measure(h[1]) + .03 * U; }
}

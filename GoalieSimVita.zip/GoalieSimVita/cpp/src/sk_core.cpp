// CHL 2026 native - forward game engine, part 1: perks, ratings, rosters, setup, faceoffs, physics,
// puck actions (shots, passes, dekes, pokes, hits, blocks) and the CPU's reads. Ported from the web build.
#include "game.h"
#include "sk_int.h"
#include "pro.h"
#include "menu.h"
#include "ut.h"

Game *SK = nullptr;
std::vector<Feed> feed;
QuickOpts QO;
Pad g_pad; uint32_t g_press = 0; Touch g_touch;
double skHint = 0; int g_pulls = 0;

Attr skAttr(const Src *src, bool user) {
  // CPU skaters play to their rating relative to the league (the real-roster league starts stacked)
  double adj = !user && g_leagueAdj ? g_leagueAdj() : 0;
  Ratings r = user ? userRatings() : skRatings(src);
  auto A = [&](const char *k, int v) { return user ? uAttr(k) : clamp(rt2at(v) - adj, 1, 10.5); };
  Attr t; t.spd = A("skate", r.skate); t.agl = A("edge", r.edge); t.deke = A("deke", r.deke); t.pass = A("pass", r.pass); t.wacc = A("sacc", r.sacc); t.wpow = A("wpow", r.wpow); t.lacc = A("slacc", r.slacc);
  t.spow = A("spow", r.spow); t.chk = A("check", r.check); t.hand = A("hand", r.hand); t.stam = A("fstam", r.fstam); t.fo = A("fo", r.fo); t.poise = A("poise", r.poise); t.bhp = A("bhp", r.bhp); t.bha = A("bha", r.bha);
  return t;
}
// a slap / wrist preference by archetype (profile().fq in the web build)
double fqSl(const Src *q) { static const double sl[6] = {1, .5, 2.3, .6, .7, 1.5}; return sl[q->ar] * (.25 + .04 * q->p); }
double fqWr(const Src *q) { static const double wr[6] = {1, 1.7, .7, 1, .9, 1.1}; return wr[q->ar]; }

// ---------------------------------------------------------------- perks
static int gsGet(const GS &g, const std::string &k) { return (int)g.get(k); }
int pkT(const Skater *p, int id) { if (!p) return 0; for (auto &q : p->pks) if (q.id == id) return q.t; return 0; }
int pkTg(const Goalie *g, int id) { if (!g) return 0; for (auto &q : g->pks) if (q.id == id) return q.t; return 0; }
int pkLeftS(const Skater *p, int id) {
  int t = pkT(p, id); if (!t || !SK) return 0; const PerkDef &d = PERKS[id]; if (d.kind == PKK_PAS) return 99;
  const void *k = p->src ? (const void *)p->src : (const void *)p;
  auto it = SK->pkU.find(k); if (it == SK->pkU.end()) { std::array<int, PK_N> a; a.fill(-1); it = SK->pkU.emplace(k, a).first; }
  if (it->second[id] < 0) it->second[id] = d.uses[t - 1];
  return it->second[id];
}
static int pkCan(const Skater *p, int id) { return pkLeftS(p, id) > 0 ? pkT(p, id) : 0; }
int pkCanG(const Goalie *g, int id) { int t = pkTg(g, id); if (!t || !SK) return 0; const PerkDef &d = PERKS[id];
  if (d.kind == PKK_PAS) return t; if (d.kind == PKK_CD) return g->pkCd[id] <= SK->gt ? t : 0; return 0; }
static void pkLabel(PkLabel &L, double &pkF, int id, int t, bool user) {
  pkF = .55; double k = SK->gt;
  if (k - L.at > 2.5) { L.n = PERKS[id].n; L.id = id; L.c = TIERC[t]; L.t = 1.1; L.at = k; L.uid = ++SK->pkLabelId; }
  if (user) pushFeed(std::string(TIERN[t]) + " " + PERKS[id].n, TIERC[t]);
}
void skPkFire(Skater *p, int id, int t) { if (!p) return; if (!t) t = pkT(p, id) ? pkT(p, id) : 1; pkLabel(p->pkL, p->pkF, id, t, p->user); }
static void pkSpend(Skater *p, int id) {
  int t = pkT(p, id); if (!t) return;
  if (PERKS[id].kind == PKK_USE) { const void *k = p->src ? (const void *)p->src : (const void *)p; auto it = SK->pkU.find(k); if (it != SK->pkU.end() && it->second[id] > 0) it->second[id]--; }
  skPkFire(p, id, t);
}
void pkSpendG(Goalie *g, int id) {
  int t = pkTg(g, id); if (!t) return;
  if (PERKS[id].kind == PKK_CD) g->pkCd[id] = SK->gt + PERKS[id].cd[t - 1];
  pkLabel(g->pkL, g->pkF, id, t, false);
}

// ---------------------------------------------------------------- difficulty
const SkD &SKD() {
  static const SkD D[3] = {{.8, -.18, -1.4, .62, .35, .45, 1.5, .98, .65, .75, .12, 3.2}, {.95, -.06, 0, 1, .65, .8, .5, .94, .55, .65, .2, 2.4}, {1.04, .02, .5, 1.2, 1, 1, 0, .9, .45, .55, .28, 1.6}};
  return D[std::max(0, std::min(2, QO.diff))];
}

// ---------------------------------------------------------------- skaters and the game
std::vector<Skater *> skAll() { std::vector<Skater *> a = SK->T[0].on; a.insert(a.end(), SK->T[1].on.begin(), SK->T[1].on.end()); return a; }
static double skLane(Role r, int ti) { return r == R_LW ? -tdir(ti) : r == R_RW ? tdir(ti) : 0; }
Skater *skMk(int team, Role role, Src *src, bool user) {
  SK->pool.emplace_back(new Skater()); Skater *p = SK->pool.back().get();
  p->team = team; p->role = role; p->src = src; p->user = user; p->nm = user ? "ROOKIE" : src ? src->nm : "?"; p->star = src && src->star;
  p->at = skAttr(src, user); p->ang = team == 0 ? 0 : PI; p->ph = rnd() * 6;
  p->pks = user ? proUserPerks() : pkOfSrc(src); p->sh = user ? g_meSh : skShoots(src); p->tend = user ? TD_USER : skTend(src);
  p->dec = rnd() * .3; { Look L = user && g_meLookOn ? g_meLook : lookOf(p->nm); p->skin = skinTone(L.skin); p->face = L.face; p->hair = L.hair; p->hairC = L.hairC; }
  return p;
}
// ---------------------------------------------------------------- looks
static const char *SKT[NSKIN] = {"#f2c79b", "#e6b48a", "#d39b6a", "#b07a4c", "#8a5a36", "#64402a"};
static const char *HCT[NHAIRC] = {"#17120f", "#3a281c", "#6a4a2e", "#9c7646", "#d4b57c", "#9a4a26"};
Col skinTone(int i) { return hex(SKT[std::max(0, std::min(NSKIN - 1, i))]); }
Col hairCol(int i) { return hex(HCT[std::max(0, std::min(NHAIRC - 1, i))]); }
const char *faceName(int i) { static const char *N[NFACE] = {"CLASSIC", "RUGGED", "YOUNG", "BEARDED"}; return N[std::max(0, std::min(NFACE - 1, i))]; }
const char *hairName(int i) { static const char *N[NHAIR] = {"SHORT", "BUZZ", "BALD", "FLOW", "CURLY", "LONG"}; return N[std::max(0, std::min(NHAIR - 1, i))]; }
const char *hairCName(int i) { static const char *N[NHAIRC] = {"BLACK", "DARK BROWN", "BROWN", "DARK BLONDE", "BLONDE", "RED"}; return N[std::max(0, std::min(NHAIRC - 1, i))]; }
Look g_meLook; bool g_meLookOn = false;
static std::map<std::string, Look> &lookOv() { static std::map<std::string, Look> m; return m; }
void lookOverride(const std::string &nm, const Look *L) { if (L) lookOv()[nm] = *L; else lookOv().erase(nm); }
// players whose skin isn't the league's usual: name, tone (the rest of the league is spread over the light tones)
static const struct { const char *nm; int tone; } KNOWN_LOOK[] = {
  {"Darnell Nurse", 5}, {"Quinton Byfield", 5}, {"Seth Jones", 4}, {"Caleb Jones", 4}, {"Mathieu Joseph", 4}, {"Pierre-Olivier Joseph", 4},
  {"Jordan Harris", 4}, {"Isaak Phillips", 5}, {"Jet Greaves", 4}, {"Evander Kane", 4}, {"K'Andre Miller", 5}, {"Anthony Duclair", 4},
  {"Ryan Reaves", 4}, {"Jalen Chatfield", 4}, {"Jayden Struble", 4}, {"Isaiah George", 5}, {"Givani Smith", 5}, {"Akil Thomas", 4},
  {"Jordan Greenway", 5}, {"Keegan Kolesar", 3}, {"Dakota Joshua", 3}, {"Andre Lee", 5}, {"Bokondji Imama", 5}, {"Kashawn Aitcheson", 5},
  {"Jarome Iginla", 4}, {"Grant Fuhr", 4}, {"P.K. Subban", 5}, {"Wayne Simmonds", 5}, {"Dustin Byfuglien", 4}, {"Joel Ward", 5},
  {"Jason Robertson", 2}, {"Nick Robertson", 2}, {"Matt Dumba", 2}, {"Kailer Yamamoto", 2}, {"Nick Suzuki", 1}};
Look lookOf(const std::string &nm) {
  auto it = lookOv().find(nm); if (it != lookOv().end()) return it->second;
  Look L; unsigned h = skHash(nm.empty() ? "x" : nm), h2 = skHash(nm + "#look"); int known = -1;
  for (auto &k : KNOWN_LOOK) if (nm == k.nm) { known = k.tone; break; }
  int r = h % 100; L.skin = known >= 0 ? known : r < 42 ? 0 : r < 78 ? 1 : r < 93 ? 2 : 3;
  L.face = (int)(h2 % NFACE); int hs = (int)(h2 / 7 % 100), hc = (int)(h2 / 701 % 100);
  if (L.skin >= 4) { L.hair = hs < 34 ? HAIR_CURLY : hs < 64 ? HAIR_BUZZ : hs < 84 ? HAIR_SHORT : HAIR_BALD; L.hairC = 0; }
  else { L.hair = hs < 38 ? HAIR_SHORT : hs < 52 ? HAIR_BUZZ : hs < 58 ? HAIR_BALD : hs < 82 ? HAIR_FLOW : hs < 89 ? HAIR_CURLY : HAIR_LONG;
    L.hairC = L.skin >= 2 ? (hc < 60 ? 0 : 1) : hc < 30 ? 1 : hc < 52 ? 2 : hc < 66 ? 0 : hc < 80 ? 3 : hc < 92 ? 4 : 5; }
  return L;
}
Col skinOf(const std::string &nm) { return skinTone(lookOf(nm).skin); }
int skNum(Skater *p) { if (p->num < 0) p->num = p->user ? skHash("me") % 97 + 2 : skHash(p->nm.empty() ? "x" : p->nm) % 97 + 2; return p->num; }

static void skRefInit() { SK->hasRef = true; SK->ref = Ref(); SK->ref.x = RK.L / 2; SK->ref.y = RK.Wd - 4; SK->ref.ang = -PI / 2; }
void skRefSnap() { if (!SK || !SK->hasRef) return; Ref &r = SK->ref; Faceoff &f = SK->fo; r.x = f.x; r.y = f.y + (f.y > RK.cy + 10 ? -2.7 : 2.7); r.vx = r.vy = 0; r.arm = 0; r.drop = true; r.ang = std::atan2(f.y - r.y, f.x - r.x); }

// the made-up season line on the lineup card (exhibitions and CPU teams): fixed per seed
void skPvFake(PvTeam &o, const std::vector<Skater *> &on, const Goalie &G, int seed, double ovd) {
  withSeed(seed, [&] { int gp = rint(8, 30), w = (int)clamp(jround(gp * clamp(.5 + ovd / 24, .15, .85) + rand(-2, 2)), 0, gp);
    o.rec = istr(w) + "-" + istr(gp - w); o.sk.clear();
    for (size_t i = 0; i < on.size(); i++) o.sk.push_back({roleName(on[i]->role), on[i]->nm, rint(0, (int)jround(gp * (.5 - i * .06))), on[i]->pks});
    o.hasG = true; o.gk = {"G", G.nm, 0, G.pks}; o.gsv = svp(rand(.885, .93) * 1000, 1000); o.gsub = istr(w) + "-" + istr(gp - w); });
}
static void skPvTeam(int ti, PvTeam &o) {
  Team &T = SK->T[ti]; Goalie &G = T.g;
  std::vector<Skater *> on = T.on; auto ord = [](Role r) { return r == R_LW ? 0 : r == R_C ? 1 : r == R_RW ? 2 : 0; };
  std::stable_sort(on.begin(), on.end(), [&](Skater *a, Skater *b) { return ord(a->role) < ord(b->role); });
  o.name = T.name; o.col = T.col; o.stripe = T.stripe; o.rec = "-"; o.recL = "RECORD";
  if (SK->ut && utPreview(ti, o, on, G)) return;
  if (proPreview(ti, o, on, G)) return;   // Be a Pro: the real season lines
  skPvFake(o, on, G, (int)std::floor(rnd() * 1e9), 0); o.recL = "EXHIBITION"; o.rec = ""; if (o.gk.nm == "G") o.gk.nm = "GOALIE";
}
void skPreviewStart() { SK->phase = PH_PREVIEW; SK->pv.t = 0; skPvTeam(0, SK->pv.T[0]); skPvTeam(1, SK->pv.T[1]); }

static void skIntroStart() {
  double gateY = RK.Wd - 4;
  for (int ti = 0; ti < 2; ti++) {
    Team &t = SK->T[ti]; double d = tdir(ti), gx = RK.L / 2 - d * 16;
    for (size_t k = 0; k < t.on.size(); k++) { Skater *p = t.on[k];
      p->iw = {{RK.L / 2 - d * (38 + k * 6), RK.cy + ((int)k - 1) * 12.0 + 8}, {RK.L / 2 - d * (22 + k * 4), RK.cy - 14 + k * 6.0}, {p->x, p->y}};
      p->idel = .15 + k * .25 + ti * .1; p->x = gx - d * k * 2; p->y = gateY; p->vx = p->vy = 0; p->ang = -PI / 2; }
    Goalie &g = t.g; g.iw = {{g.x, g.y}}; g.idel = 0; g.x = gx + d * 4; g.y = gateY; g.vx = g.vy = 0;
  }
  SK->phase = PH_INTRO; SK->introT = 0; pushFeed("X: SKIP INTRO", "#cbd5e1");
}
template <class O> static bool introMove(O &p, double sp, bool goalie, double dt, double It) {
  if (It < p.idel) return false;
  if (p.iw.empty()) return true;
  Waypt w = p.iw[0]; double dx = w.x - p.x, dy = w.y - p.y, dd = hyp(dx, dy); bool last = p.iw.size() == 1;
  if (!last && dd < 6) { p.iw.erase(p.iw.begin()); return false; }
  if (last && dd < 1.2 && hyp(p.vx, p.vy) < 5) { p.vx = p.vy = 0; return true; }
  double v = last ? std::min(sp, dd * 2.4) : sp, wx = dx / (dd ? dd : 1) * v, wy = dy / (dd ? dd : 1) * v, k = std::min(1.0, dt * (last ? 3.2 : 1.6));
  p.vx += (wx - p.vx) * k; p.vy += (wy - p.vy) * k; p.x += p.vx * dt; p.y += p.vy * dt;
  return false;
}
static void skIntroUpdate(double dt) {
  SK->introT += dt; double It = SK->introT;
  bool skip = (g_press & B_CROSS) || SK->tap; SK->tap = false;
  bool done = true;
  for (int ti = 0; ti < 2; ti++) {
    for (Skater *p : SK->T[ti].on) {
      if (!introMove(*p, 38, false, dt, It)) done = false;
      double s2 = hyp(p->vx, p->vy);
      if (s2 > 2) { p->ang = wrapA(p->ang); double da = wrapA(std::atan2(p->vy, p->vx) - p->ang); p->ang += da * std::min(1.0, dt * 6); }
      p->ph += s2 * dt * .45;
    }
    if (!introMove(SK->T[ti].g, 26, true, dt, It)) done = false;
  }
  if (skip || done || It > 6) {
    for (int ti = 0; ti < 2; ti++) {
      for (Skater *p : SK->T[ti].on) { if (!p->iw.empty()) { p->x = p->iw.back().x; p->y = p->iw.back().y; } p->vx = p->vy = 0; p->ang = ti == 0 ? 0 : PI; p->iw.clear(); }
      Goalie &g = SK->T[ti].g; g.iw.clear();   // (the goalie keeps skating to his crease during the faceoff set-up)
    }
    SK->phase = PH_FACEOFF; SK->fo.t = 0; SK->banner.t = 0; skRefSnap();
  }
}
void skIntroTick(double dt) { skIntroUpdate(dt); }
void skIntroBegin() { skIntroStart(); }

// how long before the end the coach pulls his goalie (decided once per game)
static double skPullAt(int ti) { Team &t = SK->T[ti]; if (t.pullC < 0) t.pullC = clamp(.5 + rand(-.35, .35), 0, 1);
  int tr = SK->T[1 - ti].score - t.score; double c = t.pullC; return tr == 1 ? 16 + c * 34 : tr == 2 ? (c > .55 ? 22 + c * 26 : 0) : 0; }
bool skWantPull(int ti) { return SK->per == 3 && SK->clock < skPullAt(ti); }
void skCheckPull(int ti) {
  Team &t = SK->T[ti], &o = SK->T[1 - ti]; int trail = o.score - t.score;
  bool want = skWantPull(ti) && trail >= 1 && trail <= 2;
  if (want && !t.pulled && !t.bench.empty()) {
    g_pulls++; t.pulled = true; t.g.out = true; Src *s = t.bench.front(); t.bench.erase(t.bench.begin());
    Skater *p = skMk(ti, R_X, s, false); p->lane = 0; t.on.push_back(p); t.extra = p;
    if (SK->phase == PH_PLAY) { p->x = RK.L / 2 - tdir(ti) * 4; p->y = RK.Wd - 3; p->ang = ti == 0 ? 0 : PI; }
    if (ti == 1) pushFeed(t.name + " PULL THEIR GOALIE", "#ff9800"); else pushFeed("GOALIE PULLED - EXTRA ATTACKER", "#ff9800");
  } else if (!want && t.pulled) {
    t.pulled = false; t.g.out = false;
    Skater *ex = nullptr;
    if (std::find(t.on.begin(), t.on.end(), t.extra) != t.on.end()) ex = t.extra;
    else for (auto it = t.on.rbegin(); it != t.on.rend(); ++it) if (!(*it)->user) { ex = *it; break; }
    if (ex && t.on.size() > 3) { t.on.erase(std::find(t.on.begin(), t.on.end(), ex)); if (ex->src) t.bench.push_back(ex->src); }
    t.extra = nullptr;
  }
}

Role skUserRole() { if (mode == "pro" && CR && !(SK && SK->ut) && !CR->cen) return CR->pos == 'R' ? R_RW : R_LW; return R_C; }
std::vector<Role> skMateRoles(Role ur) { std::vector<Role> v; for (Role r : {R_C, R_LW, R_RW}) if (r != ur) v.push_back(r); return v; }
void skPosLine(std::vector<Src *> &L, const std::vector<Role> &roles) {
  std::vector<Src *> left = L, out(L.size(), nullptr);
  auto take = [&](size_t slot, char want) {
    int bi = -1; double bv = -1e9;
    for (size_t i = 0; i < left.size(); i++) { Src *q = left[i]; char np = q && !q->me ? natPos(q->nm) : 'C';
      double v = (np == want ? 100 : 0) + (want == 'C' && q ? skRatings(q).fo * .5 : 0) + (want != 'C' && np == 'C' ? -20 : 0); if (v > bv) { bv = v; bi = (int)i; } }
    if (bi >= 0) { out[slot] = left[(size_t)bi]; left.erase(left.begin() + bi); } };
  for (int pass = 0; pass < 3; pass++) for (size_t k = 0; k < L.size() && k < roles.size(); k++) { Role r = roles[k];
    if ((pass == 0 && r == R_C) || (pass == 1 && r == R_LW) || (pass == 2 && r == R_RW)) take(k, r == R_C ? 'C' : r == R_LW ? 'L' : 'R'); }
  for (size_t k = 0; k < out.size(); k++) if (!out[k] && !left.empty()) { out[k] = left[0]; left.erase(left.begin()); }
  L = out;
}
void skFaceoff(double x, double y) {
  SK->gcd = false; SK->hasBat = false;
  Puck &P = SK->puck; P.owner = nullptr; P.vx = P.vy = 0; P.x = x; P.y = y; P.passTo = nullptr; P.hasShot = false; P.chk = -1; P.bz = 0; P.bvz = 0; P.wob = 0;
  double tl = trLeft();
  SK->phase = PH_FACEOFF; SK->fo = Faceoff(); SK->fo.x = x; SK->fo.y = y; SK->fo.show = rand(1.15, 2.4) + (tl > 0 ? tl + .7 : 0); SK->fo.close = rand(.5, 1.15); SK->fo.ease = (int)std::floor(rnd() * 4);
  { Team &T = SK->T[0]; Skater *u = SK->user;
    if (u && std::find(T.on.begin(), T.on.end(), u) != T.on.end()) {
      // who takes it: you, except in Be a Pro, where a winger takes the odd one on the power play / penalty kill and a
      // center gives way to a linemate who's winning more of them
      bool take = true;
      if (mode == "pro" && CR && !SK->ut) { Skater *bm = nullptr; for (Skater *c : T.on) if (c != u && (!bm || c->at.fo > bm->at.fo)) bm = c;
        if (bm) take = proTakeDraw(bm->at.fo, SK->T[0].box.size() != SK->T[1].box.size()); }
      if (take && u->role != R_C) { for (Skater *c : T.on) if (c->role == R_C) { c->role = u->role; c->lane = skLane(c->role, 0); break; }
        u->role = R_C; u->lane = skLane(R_C, 0); }
      else if (!take) { Role want = skUserRole() == R_C ? R_LW : skUserRole(); Skater *bm = nullptr; for (Skater *c : T.on) if (c != u && (!bm || c->at.fo > bm->at.fo)) bm = c;
        if (bm && bm->role != R_C) { for (Skater *c : T.on) if (c->role == R_C && c != u) { c->role = bm->role; c->lane = skLane(c->role, 0); } bm->role = R_C; bm->lane = 0; }
        if (u->role == R_C || u->role == (bm ? bm->role : R_C)) { Role fr = want; for (Skater *c : T.on) if (c != u && c->role == fr) { fr = fr == R_LW ? R_RW : R_LW; break; } u->role = fr; }
        u->lane = skLane(u->role, 0); } } }
  skRefSnap();
  SK->foN++; SK->pzIn[0] = SK->pzIn[1] = -1;
  for (int ti = 0; ti < 2; ti++) skCheckPull(ti);
  for (int ti = 0; ti < 2; ti++) {
    Team &t = SK->T[ti]; double d = tdir(ti);
    Skater *cen = nullptr; for (Skater *p : t.on) if (p->role == R_C) { cen = p; break; } if (!cen && !t.on.empty()) cen = t.on[0];
    int k = 0;
    for (Skater *p : t.on) {
      double px, py;
      if (p == cen) { px = x - d * 3; py = y; }
      else { double ln = p->lane ? p->lane : (k++ % 2 ? 1 : -1); px = x - d * 13; py = y + ln * 13; }
      p->x = clamp(px, 6, RK.L - 6); p->y = clamp(py, 6, RK.Wd - 6); p->vx = p->vy = 0; p->stun = 0; p->dash = 0; p->ang = ti == 0 ? 0 : PI;
    }
    t.g.x = defendX(ti) + tdir(ti) * 2; t.g.y = RK.cy;
    SK->scr.b.clear(); SK->scr.cur.clear();
    Goalie &g = t.g; g.hasAn = false; g.hasRq = false; g.sv = 0; g.pk = nullptr; g.mv = 0; g.fum = 0; g.cd = 0; g.hasBite = false;
  }
}

void skStart() {
  g_meLookOn = false; static unsigned serialN = 0; delete SK; SK = new Game(); SK->serial = ++serialN;
  Rosters R;
  if (mode == "ut" && utHasPick()) utGameRosters(R);
  else if (mode == "pro" && CR) proGameRosters(R);
  else {
    // random teams (quick play): 8 skaters behind you, 9 for them
    auto mk = [&](int n) { std::vector<Src *> v; for (int k = 0; k < n; k++) { R.own.emplace_back(new Src()); Src *q = R.own.back().get();
      q->nm = genName(); q->p = rand(3, 7); q->a = rand(3, 7); q->star = k == 0; ensureTraits(*q); v.push_back(q); } return v; };
    auto gg = [] { GS g; g.agi = jround(rand(55, 85)); g.glv = jround(rand(55, 85)); g.blk = jround(rand(55, 85)); g.pad = jround(rand(55, 85));
      g.chs = jround(rand(55, 85)); g.sta = jround(rand(55, 85)); g.rec = jround(rand(55, 85)); return g; };
    R.home = mk(8); R.away = mk(9); R.hg = 5; R.ag = rand(3, 7); R.hc = hex("#1e88e5"); R.ac = hex("#c8102e"); R.hs = hex("#ffffff"); R.as = hex("#ffffff"); R.hgs = gg(); R.ags = gg();
  }
  for (auto &q : R.own) SK->srcs.push_back(std::move(q));
  for (auto &q : R.gown) SK->gsrcs.push_back(std::move(q));
  for (Src *s : R.home) s->en = -1; for (Src *s : R.away) s->en = -1;   // a fresh game: everyone starts rested
  // like the NHL, the visitors wear white when the two jerseys would look alike
  if (colDist(R.hc, R.ac) < 200) { R.as = R.ac; R.ac = hex("#f1f5f9"); }
  for (int ti = 0; ti < 2; ti++) {
    Team &t = SK->T[ti]; t.bench = ti ? R.away : R.home; t.col = ti ? R.ac : R.hc; t.stripe = ti ? R.as : R.hs; t.name = ti ? R.an : R.hn;
    Goalie &g = t.g; g.r = ti ? R.ag : R.hg; g.gs = ti ? R.ags : R.hgs; g.src = ti ? R.ago : R.hgo; g.x = ti ? RK.L - RK.gl - 2 : RK.gl + 2; g.y = RK.cy; g.team = ti; g.nm = ti ? R.agn : R.hgn; gsSplit(g.gs, g.nm.empty() ? std::string(ti ? "away g" : "home g") : g.nm);
    // tonight's form: about one night in eight he's HOT (in the zone, hard to beat), one in eight he's off; and he builds
    // (or loses) confidence save by save during the game (conf)
    { double r = rnd(); g.form = r < .13 ? rand(.6, 1) : r > .87 ? -rand(.5, .9) : rand(-.15, .15); g.conf = 0; g.svRun = 0; }
#ifdef HOST_BUILD
    if (const char *e = getenv("CHL_GFORM")) g.form = atof(e);   // test: every goalie's form tonight
#endif
#ifdef HOST_BUILD
    if (const char *e = getenv("CHL_GOVR")) { double v = atof(e); GS &q = g.gs; q.agi = q.glv = q.blk = q.pad = q.chs = q.sta = q.rec = q.rd = q.ovr = q.gh = q.gl = q.bh = q.bl = v; }   // test: every goalie at one rating
    if (const char *e = getenv("CHL_GSET")) { double a, b, c, dd; if (sscanf(e, "%lf,%lf,%lf,%lf", &a, &b, &c, &dd) == 4) { g.gs.gh = a; g.gs.gl = b; g.gs.bh = c; g.gs.bl = dd; } }   // test: every goalie's glove/blocker splits
#endif
  }
  // lines: you center every line and your wingers rotate in pairs; the other team rolls three full lines
  auto best = [](std::vector<Src *> a) { std::stable_sort(a.begin(), a.end(), [](Src *p, Src *q) { return (q->p + q->a) < (p->p + p->a); }); return a; };
  auto chunk = [](const std::vector<Src *> &a, size_t n) { std::vector<std::vector<Src *>> L;
    for (size_t i = 0; i < 3; i++) if ((i + 1) * n <= a.size()) L.push_back(std::vector<Src *>(a.begin() + i * n, a.begin() + (i + 1) * n));
    if (L.empty()) L.push_back(std::vector<Src *>(a.begin(), a.begin() + std::min(n, a.size()))); return L; };
  if (R.ut) { SK->ut = true; SK->T[0].lines = R.hl; SK->T[1].lines = R.al; SK->T[0].bk = R.hbk; SK->T[1].bk = R.abk; }   // Ultimate Franchise: your lines as you set them
  else if (mode == "pro" && SK->T[0].bench.size() >= 8) {   // Be a Pro: you center the top line with the two best wingers; lines 2 and 3 play while you rest
    // the coach puts you on a line (your two linemates come from that tier of the roster)
    std::vector<Src *> b = best(SK->T[0].bench); int ul = CR ? std::max(0, std::min(2, CR->line)) : 0; SK->uLine = ul; size_t k = 0; SK->T[0].lines.clear();
    for (int li = 0; li < 3; li++) { size_t n = li == ul ? 2 : 3; std::vector<Src *> L(b.begin() + k, b.begin() + k + n); k += n; SK->T[0].lines.push_back(L); }
    SK->T[1].lines = chunk(best(SK->T[1].bench), 3); SK->T[0].allSk = SK->T[0].bench; }
  else { SK->T[0].lines = chunk(best(SK->T[0].bench), 2); SK->T[1].lines = chunk(best(SK->T[1].bench), 3); SK->T[0].allSk = SK->T[0].bench; }
  if (!R.ut) {   // every line: centers in the middle, wingers on their wing
    const std::vector<Role> R3v = {R_C, R_LW, R_RW};
    for (size_t li = 0; li < SK->T[1].lines.size(); li++) skPosLine(SK->T[1].lines[li], R3v);
    for (size_t li = 0; li < SK->T[0].lines.size(); li++) { auto &L = SK->T[0].lines[li]; skPosLine(L, L.size() == 2 ? skMateRoles(skUserRole()) : R3v); } }
  for (auto &t : SK->T) { t.li = 0; std::vector<Src *> b; for (Src *s : t.bench) if (std::find(t.lines[0].begin(), t.lines[0].end(), s) == t.lines[0].end()) b.push_back(s); t.bench = b; }
  bool proOff = mode == "pro" && !SK->ut && SK->uLine != 0 && SK->T[0].lines.size() == 3;   // Be a Pro, not on the first line: you start on the bench
  const Role R3[3] = {R_C, R_LW, R_RW};
  if (SK->ut) {
    // you play the center of whichever line is on the ice
    for (size_t k = 0; k < SK->T[0].lines[0].size(); k++) SK->T[0].on.push_back(skMk(0, R3[k], SK->T[0].lines[0][k], false));
    Skater *you = SK->T[0].on[0]; you->user = true; you->tend = TD_USER; SK->user = you;
  } else {
    Skater *you = skMk(0, R_F, nullptr, true); SK->user = you; you->role = skUserRole();
    if (mode == "pro" && CR) { you->nm = CR->nm; you->num = CR->num; }
    if (proOff) { for (size_t k = 0; k < SK->T[0].lines[0].size(); k++) SK->T[0].on.push_back(skMk(0, R3[k], SK->T[0].lines[0][k], false));
      SK->uBench = true; BenchSpot B = skBench(); you->x = B.x; you->y = B.y + 4; you->vx = you->vy = 0; }
    else { std::vector<Role> mr = skMateRoles(you->role); SK->T[0].on = {you}; for (size_t k = 0; k < SK->T[0].lines[0].size(); k++) SK->T[0].on.push_back(skMk(0, k < mr.size() ? mr[k] : R_RW, SK->T[0].lines[0][k], false)); }
  }
  for (size_t k = 0; k < SK->T[1].lines[0].size(); k++) SK->T[1].on.push_back(skMk(1, R3[k], SK->T[1].lines[0][k], false));
  SK->foN = 0;
  for (int ti = 0; ti < 2; ti++) for (Skater *p : SK->T[ti].on) p->lane = skLane(p->role, ti);
  SK->ftUsed = false; SK->hasBat = false; SK->batCd = 0; skRefInit();
  for (auto &t : SK->T) { Goalie &g = t.g;
    if (g.src) g.pks = pkOfG(g.src);
    else { int ov = (int)jround((g.gs.agi + g.gs.glv + g.gs.blk + g.gs.pad + g.gs.chs + g.gs.sta + g.gs.rec) / 7); GS gs = g.gs; g.pks = pkAuto([gs](const std::string &k) { return gsGet(gs, k); }, ov, true, g.nm.empty() ? "g" : g.nm); } }
  feed.clear();
  if (mode == "practice") { skFaceoff(RK.L / 2, RK.cy); pracSetup(); skHint = 0; return; }
  skFaceoff(RK.L / 2, RK.cy); skPreviewStart();
  skHint = SK_PER;
}

// ---------------------------------------------------------------- physics helpers
bool skBoards0(double &x, double &y, double &vx, double &vy, double r, double bounce, bool isPuck) {
  const double L = RK.L, Wd = RK.Wd, cr = RK.cr; double cx = -1, cy = -1; bool corner = true;
  if (x < cr && y < cr) { cx = cr; cy = cr; } else if (x > L - cr && y < cr) { cx = L - cr; cy = cr; }
  else if (x < cr && y > Wd - cr) { cx = cr; cy = Wd - cr; } else if (x > L - cr && y > Wd - cr) { cx = L - cr; cy = Wd - cr; } else corner = false;
  bool hit = false;
  if (corner) {
    double dx = x - cx, dy = y - cy, d = hyp(dx, dy); if (!d) d = 1; double lim = cr - r;
    if (d > lim) { double nx = dx / d, ny = dy / d; x = cx + nx * lim; y = cy + ny * lim; double vn = vx * nx + vy * ny;
      if (vn > 0) { double sp = hyp(vx, vy); if (!sp) sp = 1; double flat = isPuck ? clamp(1 - vn / sp * 1.6, 0, 1) : 0, b = bounce * (1 - flat * .6);
        vx -= (1 + b) * vn * nx; vy -= (1 + b) * vn * ny; hit = true; } }
  } else {
    if (x < r) { x = r; if (vx < 0) { vx = -vx * bounce; hit = true; } }
    if (x > L - r) { x = L - r; if (vx > 0) { vx = -vx * bounce; hit = true; } }
    if (y < r) { y = r; if (vy < 0) { vy = -vy * bounce; hit = true; } }
    if (y > Wd - r) { y = Wd - r; if (vy > 0) { vy = -vy * bounce; hit = true; } }
  }
  return hit;
}
bool skBoardsP(Skater *o, double r, double b) { return skBoards0(o->x, o->y, o->vx, o->vy, r, b, false); }
bool skBoardsPuck(double r, double bounce) {
  Puck &P = SK->puck; double sp = hyp(P.vx, P.vy); bool hi = P.bz > SK_BH - .45;
  bool hit = skBoards0(P.x, P.y, P.vx, P.vy, r, hi ? .68 : bounce, true);
  if (hit && sp > 14) { double vs = hyp(P.vx, P.vy); if (!vs) vs = 1;
    if (hi) { double a = std::atan2(P.vy, P.vx) + rand(-.42, .42); P.vx = std::cos(a) * vs; P.vy = std::sin(a) * vs; P.bvz = std::min(P.bvz, -2.0); P.wob = std::max(P.wob, .6);
      skGlassHit(P.x, P.y, clamp(sp / 90, .15, .55)); }
    else { double k = rand(.9, 1), a = std::atan2(P.vy, P.vx) + rand(-.12, .12) * clamp(sp / 60, 0, 1); P.vx = std::cos(a) * vs * k; P.vy = std::sin(a) * vs * k; } }
  return hit;
}
bool skNetBox(double &x, double &y, double &vx, double &vy, double r, double bounce, bool isPuck) {
  bool any = false;
  for (double gx : {RK.gl, RK.L - RK.gl}) {
    bool left = gx < RK.L / 2; double x0 = left ? gx - RK.netD : gx, x1 = left ? gx : gx + RK.netD, y0 = RK.cy - RK.post, y1 = RK.cy + RK.post;
    if (x > x0 - r && x < x1 + r && y > y0 - r && y < y1 + r) {
      double pen[4] = {x - (x0 - r), (x1 + r) - x, y - (y0 - r), (y1 + r) - y}; int k = 0; for (int i = 1; i < 4; i++) if (pen[i] < pen[k]) k = i;
      if (isPuck && k == (left ? 1 : 0) && y > y0 && y < y1) continue;
      any = true;
      if (k == 0) { x = x0 - r; if (vx > 0) vx = -vx * bounce; }
      else if (k == 1) { x = x1 + r; if (vx < 0) vx = -vx * bounce; }
      else if (k == 2) { y = y0 - r; if (vy > 0) vy = -vy * bounce; }
      else { y = y1 + r; if (vy < 0) vy = -vy * bounce; }
    }
  }
  return any;
}
Pt stickPt(const Skater *p) { return {p->x + std::cos(p->ang) * 2.2, p->y + std::sin(p->ang) * 2.2}; }
double skTilt(int t) { if (!SK) return 0; int df = SK->T[1 - t].score - SK->T[t].score; return df <= 0 ? 0 : df == 1 ? .5 : df <= 3 ? 1 : .4; }
double skMaxSpd(const Skater *p) { const SkD &D = SKD(); double s = (19 + p->at.spd * 1.55) * (p->user ? 1 : D.sp * (1 + .045 * skTilt(p->team))); if (SK->puck.owner == p) s *= p->user ? D.carry : .9; return s; }
bool skShort(int t) { return SK->T[t].box.size() > SK->T[1 - t].box.size(); }
bool skInZone(const Skater *p) { double ax = attackX(p->team); return std::fabs(ax - p->x) < SK_BLUE && (ax - p->x) * tdir(p->team) > 0; }
bool onIce(const Skater *p) { for (auto &t : SK->T) if (std::find(t.on.begin(), t.on.end(), p) != t.on.end()) return true; return false; }
bool onTeam(int ti, const Skater *p) { auto &v = SK->T[ti].on; return std::find(v.begin(), v.end(), p) != v.end(); }
int alIndex(const std::vector<Skater *> &AL, const Skater *p) { for (size_t i = 0; i < AL.size(); i++) if (AL[i] == p) return (int)i; return -1; }

// ---------------------------------------------------------------- sound
float g_sfxVol = 1.f;
void sfx(int id, double vol, double rate, bool loop) {
  if (!QO.sfx) return; double v = std::max(0.0, std::min(1.5, vol)) * SND_GAIN[id] * g_sfxVol; if (v < .01 && !loop) return;
  snd_play(id, (float)v, (float)rate, loop);
}
double sndAt(double x, double y) { if (!SK) return 1; double d = hyp(x - SK->cam, y - SK->camY); return std::max(.18, std::min(1.0, 1.15 - d / 110)); }

// ---------------------------------------------------------------- puck actions
void skRelease(Skater *p) { Puck &P = SK->puck; if (P.owner == p) { P.owner = nullptr; p->cool = .35; p->lostT = SK->gt; } }
void skTagIcing(Skater *p) {
  Puck &P = SK->puck; Skater *to = P.passTo;
  P.ice = !skShort(p->team) && SK->T[p->team].on.size() >= SK->T[1 - p->team].on.size() && (p->x - RK.L / 2) * tdir(p->team) < 0 && (!to || hyp(to->x - p->x, to->y - p->y) > 60) ? p->team : -1;
}
void skShoot(Skater *p, double dx, double dy, double charge, ShotKind kind, double h, bool kindGiven) {
  if (p->chopT > 0) return;
  Puck &P = SK->puck; if (P.owner != p) return;
  double d = hyp(dx, dy); if (!d) d = 1; dx /= d; dy /= d;
  const SkD &D = SKD(); bool ai = !p->user; double ad = ai ? D.acc : D.uacc;
  if (!kindGiven) kind = p->user ? (charge > .6 ? SH_SLAP : SH_WRIST) : SH_WRIST;
  double ch = p->user ? clamp(charge, 0, 1) : p->aiCh >= 0 ? clamp(p->aiCh, 0, 1) : (kind == SH_SLAP ? rand(.25, 1) : std::pow(rnd(), 1.3));
  double wrA = clamp(p->at.wacc + ad, 1, 10), slA = clamp(p->at.lacc + ad, 1, 10), spd, err;
  auto tri = [] { return (rnd() + rnd() - 1) * 1.6; };
  { double rel = wrapA(std::atan2(dy, dx) - p->ang); bool back = p->sh == 'R' ? rel < -.52 : rel > .52;
    if (back && !p->user && rnd() < .65 + p->at.hand * .025) p->ang = std::atan2(dy, dx);
    else if (back) { kind = SH_BACK; if (p->user) { pushFeed("BACKHAND", "#94a3b8"); fillStat("bhp", .012); } } }
  if (kind == SH_SLAP) { spd = (58 + p->at.spow * 6.6) * (ai ? .76 + .28 * ch : .82 + .3 * ch); err = (11 - slA) * (ai ? .55 : 1.1) * (.9 + .25 * ch); }
  else if (kind == SH_WRIST) { spd = (50 + p->at.wpow * 5) * (ai ? .9 + .2 * ch : .94 + .24 * ch); err = (11 - wrA) * (ai ? .42 : .82) * (.9 + .25 * ch); }
  else if (kind == SH_BACK) { double bA = clamp(p->at.bha + ad, 1, 10); spd = (42 + p->at.bhp * 4.6) * (ai ? .9 + .15 * ch : .92 + .18 * ch); err = (11 - bA) * (ai ? .5 : .95) * (.95 + .25 * ch); }
  else if (ch > .6) { spd = (52 + p->at.spow * 6.8) * (.62 + .38 * ch); err = (11 - slA) * .8 * (.55 + .6 * ch); }
  else { spd = (46 + p->at.wpow * 5) * (.75 + .25 * ch); err = (11 - wrA) * .8 * (.55 + .6 * ch); }
  int flk = 0, otk = 0;
  { double dn0 = hyp(attackX(p->team) - p->x, RK.cy - p->y);
    if (kind == SH_WRIST && dn0 < 45 && skInZone(p)) { int t = pkCan(p, PK_FLICK); if (t) { flk = t; spd *= (t == 1 ? 1.15 : t == 2 ? 1.25 : 1.35); err *= .85; pkSpend(p, PK_FLICK); } }
    if (p->gotPass && SK->gt - p->gotT < .6 && dn0 < 50) { int t = pkCan(p, PK_OTKING); if (t) { otk = t; spd *= (t == 1 ? 1.15 : t == 2 ? 1.25 : 1.35); pkSpend(p, PK_OTKING); } } }
  double fat = p->tired ? 0 : clamp(p->st / 30, 0, 1); spd *= .8 + .2 * fat; err *= 1 + (1 - fat) * .7;
  { double near = 1e9; for (Skater *o : SK->T[1 - p->team].on) near = std::min(near, hyp(o->x - p->x, o->y - p->y));   // POISE: shooting with a man on you
    if (near < 7) err *= 1 + (1 - near / 7) * (1 - clamp(p->at.poise / 10, 0, 1)) * .8; }
  bool slapT = kind == SH_SLAP || (kind == SH_MANUAL && ch > .6);
  p->st = std::max(0.0, p->st - (slapT ? 9 : 5) * (1.3 - p->at.stam * .08)); p->stT = std::max(p->stT, .9);
  double a = std::atan2(dy, dx) + err * PI / 180 * tri();
  skRelease(p); P.x = p->x + std::cos(p->ang) * 2.2; P.y = p->y + std::sin(p->ang) * 2.2;
  P.vx = std::cos(a) * spd; P.vy = std::sin(a) * spd;
  sfx(slapT ? S_SLAP : S_WRIST, sndAt(p->x, p->y) * (.75 + .3 * std::min(1.0, spd / 120)), rand(.95, 1.06));
  double hh = kind == SH_MANUAL ? (h >= 0 ? clamp(h, 0, 1) : clamp(.2 + ch * .55 + rand(-.25, .25), 0, 1))
    : clamp((h >= 0 ? h : .08 + ch * .82) + rand(-1, 1) * (11 - (slapT ? slA : wrA)) * .035 * (2 - fat), 0, p->user ? 1.3 : 1);
  { double ax = attackX(p->team), Dd = std::max(4.0, std::fabs(ax - P.x)), sp = std::max(20.0, hyp(P.vx, P.vy)), tt = Dd / sp, zt = clamp(hh, 0, 1.3) * PZ * .94 + .1;
    if (zt < .75) { P.bz = .06; P.bvz = rand(.5, 2); } else { P.bz = .15; P.bvz = (zt - .15 + .5 * PG * tt * tt) / tt; }
    P.wob = kind == SH_SLAP ? .15 : .05; }
  P.id++;
  P.mag = 0; P.hasShot = true; P.shot = Shot(); P.shot.team = p->team; P.shot.by = p; P.shot.spd = spd; P.shot.h = hh; P.shot.flk = flk; P.shot.otk = otk;
  P.shot.dk = (p->hasDk && p->dk.drag) || (p->hasDk && p->dk.t < .6); P.shot.kind = slapT ? SH_SLAP : kind == SH_BACK ? SH_BACK : SH_WRIST;
  skGoalieReact(SK->T[1 - p->team].g, P.x, P.y, P.vx, P.vy, hh);   // after the shot is set up: his read uses what kind of shot it is
  P.pl = false; P.clearTips(); P.last = p; P.passTo = nullptr; P.chk = -1; P.saucer = false;
  p->wind = 0; p->windT = 0; p->folK = slapT ? 1 : .62; p->folT = slapT ? .38 : .24;
  skTagIcing(p);
  SK->T[p->team].shots++;
  if (p->user) { SK->me.shots++; fillStat(slapT ? "spow" : "wpow", .018); }   // power grows with every shot you take
}
// auto aim: the best shot on the goalie - the bigger gap, high or low by which of glove / blocker / pads is weakest
void skAutoShot(Skater *p, ShotKind kind, double charge) {
  Goalie &g = SK->T[1 - p->team].g; double ax = attackX(p->team), ty = RK.cy, h = .3;
  if (!g.out) {
    double gapA = g.y - (RK.cy - RK.post), gapB = (RK.cy + RK.post) - g.y, side = gapA > gapB ? -1 : 1;
    double acc = kind == SH_SLAP ? p->at.lacc : p->at.wacc, margin = clamp(1 + (10 - acc) * .17, 1.05, 2.3);
    ty = RK.cy + side * (RK.post - margin);
    h = .08 + clamp(charge, 0, 1) * .82;
    if (charge < .3 && std::max(gapA, gapB) < RK.post + .9 && rnd() < .3) { ty = g.y; h = .05; }
  }
  Pt sp = stickPt(p);
  skShoot(p, ax - sp.x, ty - sp.y, charge, kind, h, true);
}
bool skLaneBlocked(const Skater *p, const Skater *to) {
  double dx = to->x - p->x, dy = to->y - p->y, L = hyp(dx, dy); if (!L) L = 1;
  for (Skater *o : SK->T[1 - p->team].on) { double t = ((o->x - p->x) * dx + (o->y - p->y) * dy) / (L * L); if (t < .12 || t > .88) continue;
    if (std::fabs((o->x - p->x) * dy - (o->y - p->y) * dx) / L < 3) return true; }
  return false;
}
void skPass(Skater *p, Skater *to, double pw, bool sau) {
  Puck &P = SK->puck; if (P.owner != p || !to || p->chopT > 0) return;
  const SkD &D = SKD(); double acc = p->user ? p->at.pass : clamp(p->at.pass + D.acc * .6, 1, 10);
  double dist0 = hyp(to->x - p->x, to->y - p->y);
  if (!p->user && !sau && dist0 > 22 && p->at.pass >= 5 && skLaneBlocked(p, to) && rnd() < .45) sau = true;
  int otT = (dist0 > 35 || skLaneBlocked(p, to) || (skInZone(to) && hyp(attackX(p->team) - to->x, RK.cy - to->y) < 30 && dist0 > 12)) ? pkCan(p, PK_ONETOUCH) : 0;
  bool perk = otT > 0, saucer = sau;
  double spd = (46 + p->at.pass * 4.2) * (1 + .55 * pw) * (saucer ? .84 : 1);
  double dist = hyp(to->x - p->x, to->y - p->y), tt = dist / spd, lx = to->x + to->vx * tt * .85, ly = to->y + to->vy * tt * .85;
  if (saucer || perk) { for (int k = 0; k < 3; k++) tt = hyp(to->x + to->vx * tt - p->x, to->y + to->vy * tt - p->y) / spd; lx = to->x + to->vx * tt; ly = to->y + to->vy * tt; }
  double err = (perk ? (otT == 1 ? .4 : otT == 2 ? .15 : 0) : 1) * (11 - acc) * (1 + pw * (2.2 - acc * .15)) * (saucer ? 1.2 : 1) * PI / 180 * (rnd() + rnd() - 1) * 1.5;
  double a = std::atan2(ly - p->y, lx - p->x) + err;
  skRelease(p); P.vx = std::cos(a) * spd; P.vy = std::sin(a) * spd; P.x = p->x + std::cos(a) * 2; P.y = p->y + std::sin(a) * 2;
  sfx(S_PASS, sndAt(p->x, p->y) * (.7 + .35 * pw), rand(.95, 1.08));
  SK->T[p->team].pa++;
  if (saucer) { double ft = hyp(lx - p->x, ly - p->y) / spd; P.bz = .15; P.bvz = clamp(PG * ft * .5 * (.85 + p->at.pass * .012), 5, 12.5); }
  p->passT = SK->gt; P.passTo = to; P.lastPasser = p; P.passT = now(); P.last = p; P.hasShot = false; P.id++; P.saucer = saucer;
  P.mag = perk ? (otT == 1 ? 3 : otT == 2 ? 5 : 8) : 0; P.pl = true; P.clearThru(); P.clearTips(); P.pp = pw;
  if (perk) pkSpend(p, PK_ONETOUCH);
  if (pw > .3 && p->user) pushFeed("POWER PASS", "#93c5fd");
  if (saucer && p->user) pushFeed("SAUCER PASS", "#93c5fd");
  skTagIcing(p);
}
double skSpinCost(const Skater *p) { return 50 - p->at.stam * 1.5; }
bool skSpin(Skater *p) {
  if (SK->puck.owner != p || p->spin > 0 || p->stun > 0) return false;
  if (p->spinCd > 0 || p->tired || p->st < skSpinCost(p)) { if (p->user) pushFeed("TOO TIRED TO SPIN", "#ffb300"); return false; }
  p->spin = SPIN_T; p->spinCd = p->user ? 1.5 : 9; p->st = std::max(0.0, p->st - skSpinCost(p)); p->stT = 1.5; p->dash = 0;
  if (p->user) { pushFeed("SPIN-O-RAMA", "#93c5fd"); fillStat("hand", .02); }
  return true;
}
double skDekeSide(const Skater *p, double mx, double my) {
  double c = std::cos(p->ang) * my - std::sin(p->ang) * mx; if (std::fabs(c) > .25) return c > 0 ? 1 : -1;
  Skater *o = nullptr; double od = 1e9; for (Skater *q : SK->T[1 - p->team].on) { double d = hyp(q->x - p->x, q->y - p->y); if (d < od) { od = d; o = q; } }
  if (o && od < 14) { double k = std::cos(p->ang) * (o->y - p->y) - std::sin(p->ang) * (o->x - p->x); return k > 0 ? -1 : 1; }
  return rnd() < .5 ? -1 : 1;
}
bool skDeke(Skater *p, double s) {
  if (SK->puck.owner != p || p->hasDk || p->spin > 0 || p->stun > 0 || p->dkCd > SK->gt) return false;
  p->hasDk = true; p->dk = Deke(); p->dk.s = s;
  static const double DG[4] = {1, .8, .65, .5};
  p->dkCd = SK->gt + (p->user ? .5 : 2.5) * DG[pkT(p, PK_DANGLE)]; p->st = std::max(0.0, p->st - 2.5); if (p->user) fillStat("deke", .01);
  double k = 3 + p->at.hand * .15 + p->at.deke * .25; p->vx += -std::sin(p->ang) * s * k; p->vy += std::cos(p->ang) * s * k;   // DEKING (and hands) sell it
  Goalie &g = SK->T[1 - p->team].g; double dn = hyp(attackX(p->team) - p->x, RK.cy - p->y);
  if (!g.out && !g.user && dn < 26 && std::fabs(p->y - RK.cy) < 16) { double rd = g.gs.rd;
    if (rnd() < clamp(.3 + ((p->at.hand + p->at.deke) / 2 - 5) * .07 - (rd - 60) * .008 - (g.form + g.conf) * .12, .06, .75)) {
      g.hasBite = true; g.bite.t = .3; double sv = sgn(std::cos(p->ang) * s); g.bite.s = sv ? sv : s; g.cd = std::max(g.cd, SK->gt + .3); if (p->user) { pushFeed("DEKED HIM!", "#7CFC9A"); fillStat("deke", .012); } } }
  return true;
}
void skDekeUpdate(Skater *p, double dt) {
  if (!p->hasDk) { p->dkLat = 0; p->dkF = 0; return; }
  Deke &k = p->dk;
  if (SK->puck.owner != p || p->stun > 0 || p->spin > 0) { p->hasDk = false; p->dkLat = 0; p->dkF = 0; return; }
  k.t += dt; bool held = p->user && p->dkHeld; auto e = [](double x) { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); };
  if (!k.drag && held && k.t > .16) { k.drag = true; k.d0 = k.t; }
  double lat, fw = 0;
  if (!k.drag) {
    lat = k.s * 1.7 * (k.t < .12 ? e(k.t / .12) : k.t < .3 ? 1 : 1 - e((k.t - .3) / .22)); if (k.t > .52) { p->hasDk = false; p->dkLat = 0; p->dkF = 0; return; }
  } else {
    if (!held && k.rel < 0) k.rel = k.t; if (k.t - k.d0 > 3 && k.rel < 0) k.rel = k.t;
    double a = e((k.t - k.d0) / .18), out = k.rel >= 0 && k.t - k.rel > 1 ? e((k.t - k.rel - 1) / .2) : 0;
    lat = (k.s * 1.7 + (-k.s * .75 - k.s * 1.7) * a) * (1 - out); fw = -.85 * a * (1 - out);
    if (out >= 1) { p->hasDk = false; p->dkLat = 0; p->dkF = 0; return; }
  }
  p->dkLat = lat; p->dkF = fw;
}
void skPenalty(Skater *p, const char *kind);
bool skPoke(Skater *p, Skater *c, double base) {
  Puck &P = SK->puck; p->pokeA = .28;
  std::vector<double> keep; for (double t : p->pokes) if (SK->gt - t < 2.6) keep.push_back(t); keep.push_back(SK->gt); p->pokes = keep;
  if (c && c->spin > 0) return false;
  if (!c || hyp(c->x - p->x, c->y - p->y) > 4.6) return false;
  bool wnd = c->windT > 0 || (c->user && SK->rs.dn && SK->rs.kind == 1);   // only a slap-shot wind-up leaves the puck hanging
  double dkK = c->hasDk ? (c->dk.drag ? .55 : .3) : 1; int eT = pkCan(p, PK_EYES); double eyK = eT ? (eT == 1 ? 1.15 : eT == 2 ? 1.25 : 1.35) : 1;
  double q0 = dkK * (wnd ? clamp(base + .35 + p->at.hand * .03 - c->at.hand * .015, .35, .9) : clamp(base + p->at.hand * .03 - c->at.hand * .022 - c->at.deke * .028, c->user && !p->user ? .02 : .04, .8)), r0 = rnd();
  bool won = r0 < q0 * eyK;
  if (won && eT && r0 >= q0) pkSpend(p, PK_EYES);
  if (won && c->hasDk) { int t = pkCan(c, PK_DANGLE); if (t && rnd() < (t == 1 ? .6 : t == 2 ? .8 : 1)) { won = false; pkSpend(c, PK_DANGLE); } }
  if (won) {
    if (wnd) { c->windT = 0; c->wind = 0; if (c->user) SK->rs.dn = false; }
    skRelease(c); c->cool = .6; p->cool = std::max(p->cool, .4); { double a = p->ang + rand(-.75, .75), sp = rand(26, 38); P.vx = std::cos(a) * sp + c->vx * .35; P.vy = std::sin(a) * sp + c->vy * .35; }
    P.last = c; P.hasShot = false; P.passTo = nullptr; P.ice = -1; return true;
  }
  if (rnd() < (p->user ? (p->pokes.size() >= 3 ? .38 : .03) : (p->pokes.size() >= 3 ? .08 : .012))) { c->stun = std::max(c->stun, .5); skPenalty(p, "TRIPPING"); }
  return false;
}
double skStam(Skater *p, bool want, bool moving, double dt) {
  double f = clamp((p->at.stam - 3.5) / 6.5, 0, 1);
  if (p->st <= 0 && !p->tired) { p->tired = true; if (p->user) pushFeed("EXHAUSTED - YOU NEED A CHANGE", "#ffb300"); }
  else if (p->tired && p->st >= 20) p->tired = false;
  p->sprint = want && moving && !p->tired && p->st > 0 && p->stun <= 0;
  static const double LG[4] = {1, .85, .77, .7};
  double k = (1.25 - .5 * f) * LG[pkT(p, PK_LUNGS)];
  if (p->sprint) { p->sprT += dt; if (p->sprT > 1.2 && !p->dmF) { p->dmF = 1; Puck &P = SK->puck; int t = (P.owner == p || !P.owner) ? pkCan(p, PK_DEMON) : 0; if (t) { p->dmT = t; pkSpend(p, PK_DEMON); } } }
  else { p->sprT = 0; p->dmF = 0; p->dmT = 0; }
  if (p->sprint) { p->st = std::max(0.0, p->st - (p->user ? 3.4 : 2.2) * k * dt); p->stT = .6; if (p->user) fillStat("fstam", .0012); }
  else p->st = std::min(100.0, p->st + .2 * (.6 + .8 * f) * dt);
  static const double DM[3] = {.1, .16, .22};
  return p->tired ? .8 : (p->sprint ? (1.06 + .26 * f) * (p->dmT ? 1 + std::min(DM[p->dmT - 1], .02 + (p->sprT - 1.2) * .075) : 1) : 1) * (p->st < 30 ? .93 : 1);
}
std::string skShotName(const Puck &P) {
  if (!P.hasShot) return "SHOT"; const Shot &s = P.shot;
  return s.tip ? "TIP" : s.defl ? "DEFLECTION" : s.kind == SH_SLAP ? "SLAP SHOT" : s.kind == SH_BACK ? "BACKHAND" : "WRIST SHOT";
}
enum Job { J_PRESS, J_MARK, J_NET, J_SLOT };
static Job skDefJob(Skater *p, Team &T, Skater *car, double ownX) {
  std::vector<Skater *> cand; for (Skater *q : T.on) if (!q->user || g_autoplay || p->team != 0) cand.push_back(q);
  auto dc = [&](Skater *q) { return hyp(q->x - car->x, q->y - car->y); };
  std::stable_sort(cand.begin(), cand.end(), [&](Skater *a, Skater *b) { return dc(a) < dc(b); });
  Skater *press = cand.empty() ? nullptr : cand[0];
  if (press && press->tend == TD_NET && cand.size() > 1 && dc(cand[1]) < dc(press) + 8) press = cand[1];
  if (T.prs && T.prs != press && std::find(cand.begin(), cand.end(), T.prs) != cand.end() && dc(T.prs) < dc(press) + 7) press = T.prs;
  T.prs = press;
  if (p == press) return J_PRESS;
  if (std::fabs(car->x - ownX) > 75) return J_MARK;
  std::vector<Skater *> rest; for (Skater *q : T.on) if (q != press && (!q->user || g_autoplay)) rest.push_back(q);
  auto want = [](Skater *q) { return q->tend == TD_NET ? 0 : q->tend == TD_REB ? 1 : 2; };
  std::stable_sort(rest.begin(), rest.end(), [&](Skater *a, Skater *b) { return want(a) < want(b); });
  const Job jobs[3] = {J_NET, J_SLOT, J_MARK}; bool used[4] = {false, false, false, false};
  for (Skater *q : rest) { Job j = jobs[want(q)]; if (used[j]) { j = J_MARK; for (Job x : jobs) if (!used[x]) { j = x; break; } } used[j] = true; if (q == p) return j; }
  return J_MARK;
}
int skDefJobPub(Skater *p, Team &T, Skater *car, double ownX) { return (int)skDefJob(p, T, car, ownX); }
double skFoWindow(const Skater *p) { int D = QO.diff; return .045 + clamp((p->at.fo - 3.5) / 6.5, 0, 1) * .1 + (D == 0 ? .03 : D == 1 ? .01 : 0); }
double skFoEase(const Faceoff &F, double u) { u = clamp(u, 0, 1); return F.ease == 1 ? u * u : F.ease == 2 ? 1 - (1 - u) * (1 - u) : F.ease == 3 ? (u < .5 ? u * 1.3 : .65 + (u - .5) * .7) : u; }
bool skBlock(Skater *p) {
  if (p->block > 0 || p->stun > 0 || SK->puck.owner == p) return false;
  double cost = 20 - p->at.stam * .8;
  if (p->tired || p->st < cost) { if (p->user) pushFeed("TOO TIRED TO BLOCK", "#ffb300"); return false; }
  p->block = SK_BLK; p->st = std::max(0.0, p->st - cost); p->stT = 1.2; p->dash = 0;
  Puck &P = SK->puck; double gx = defendX(p->team); p->blkA = std::atan2(RK.cy - P.y, gx - P.x) + PI / 2;
  if (p->user) pushFeed("BLOCKING", "#93c5fd");
  return true;
}
bool skStartCheck(Skater *p, double dx, double dy, double pw) {
  if (p->dcd > 0 || p->stun > 0 || p->st < 12 || p->tired || p->block > 0) return false;
  double m = hyp(dx, dy); if (!m) m = 1; p->dash = pw < .7 ? .24 : .32; p->dcd = pw < .7 ? .7 : 1.0; p->dx = dx / m; p->dy = dy / m; p->hitPow = pw;
  p->st = std::max(0.0, p->st - (20 - p->at.chk * .6) * (pw < .7 ? .4 : 1)); p->stT = .8; return true;
}

// ---------------------------------------------------------------- the CPU's reads
double skLaneOpen(double ax, double ay, double bx, double by, int team, const Skater *skip) {
  double dx = bx - ax, dy = by - ay, L2 = dx * dx + dy * dy; if (!L2) L2 = 1; double m = 99;
  for (Skater *o : SK->T[1 - team].on) { if (o == skip || o->stun > 0) continue; double t = clamp(((o->x - ax) * dx + (o->y - ay) * dy) / L2, 0, 1);
    double r = hyp(o->x - (ax + dx * t), o->y - (ay + dy * t)) - (t > .15 && t < .9 ? .6 : 0); m = std::min(m, r); }
  return m - 1.5;
}
double skShotQ(int team, double x, double y) {
  double ax = attackX(team), d = tdir(team), fx = (ax - x) * d; if (fx < 2.5) return 0;
  double dist = hyp(ax - x, RK.cy - y), ang = std::fabs(std::atan2(RK.cy - y, fx));
  bool en = SK->T[1 - team].g.out;
  double q = en ? clamp(1.2 - dist / 150, 0, 1) * clamp(1 - ang / 1.45, 0, 1) : clamp(1.15 - dist / 62, 0, 1) * clamp(1 - ang / 1.25, 0, 1); if (q <= 0) return 0;
  for (Skater *o : SK->T[1 - team].on) { if (o->stun > 0) continue; double t = ((o->x - x) * (ax - x) + (o->y - y) * (RK.cy - y)) / (dist * dist != 0 ? dist * dist : 1);
    if (t > 0 && t < 1) { double r = hyp(o->x - (x + (ax - x) * t), o->y - (y + (RK.cy - y) * t)); if (r < 2.4) q *= .4; else if (r < 4) q *= .8; } }
  Goalie &g = SK->T[1 - team].g;
  if (g.out) q *= 1.5;
  else { double den = ax - x; double yl = y + (RK.cy - y) * clamp((g.x - x) / (den ? den : 1), 0, 1), off = std::fabs(g.y - yl); q *= 1 + std::min(off, 4.0) * .12; if (g.broke) q *= 1.15; if (g.sv > 0 || (g.hasAn && g.an.p == GP_DIVE)) q *= 1.35; }
  return q;
}
void skAIShot(Skater *p, ShotKind kind) {
  Goalie &g = SK->T[1 - p->team].g; double ax = attackX(p->team); Pt sp = stickPt(p);
  double ty = RK.cy, h = .3, ch = .4;
  if (!g.out) {
    double gapA = g.y - (RK.cy - RK.post), gapB = (RK.cy + RK.post) - g.y, side = std::fabs(gapA - gapB) < .6 ? (rnd() < .5 ? -1 : 1) : (gapA > gapB ? -1 : 1);
    double acc = kind == SH_SLAP ? p->at.lacc : p->at.wacc, margin = clamp(2 + (10 - acc) * .18, 2, 3.2);
    ty = RK.cy + side * (RK.post - margin * rand(.9, 1.3));
    bool glove = g.team == 0 ? side < 0 : side > 0; double hi = glove ? g.gs.gh : g.gs.bh, lo = std::min(glove ? g.gs.gl : g.gs.bl, g.gs.pad + 4);
    double lowP = clamp(.5 + (hi - lo) * .025, .15, .85);   // shoot at whichever of his high or low saves is weaker on that side
    if (rnd() < lowP) { ch = rand(.05, .3); h = .08 + ch * .5; } else { ch = rand(.65, 1); h = .45 + ch * .45; }
    if (std::max(gapA, gapB) < RK.post + .9 && h < .3 && rnd() < .35) ty = g.y;
  } else ch = rand(.1, .4);
  if (kind == SH_SLAP) { p->windT = .42; p->windAim = {ax, ty, ch, h}; return; }
  p->aiCh = ch; skShoot(p, ax - sp.x, ty - sp.y, ch, kind, h, true); p->aiCh = -1;
}
Skater *skBestPassTarget(Skater *p, double dirx, double diry) {
  Skater *best = nullptr; double bs = -1e9;
  for (Skater *q : SK->T[p->team].on) {
    if (q == p || q->stun > 0) continue;
    double dx = q->x - p->x, dy = q->y - p->y, d = hyp(dx, dy); if (!d) d = 1;
    double open = 99; for (Skater *o : SK->T[1 - p->team].on) { double t = clamp(((o->x - p->x) * dx + (o->y - p->y) * dy) / (d * d), 0, 1), cx = p->x + dx * t, cy = p->y + dy * t; open = std::min(open, hyp(o->x - cx, o->y - cy)); }
    double sc = std::min(open, 10.0) * 2 - d * .08 + (q->x - p->x) * tdir(p->team) * .12;
    if (dirx || diry) sc += ((dx * dirx + dy * diry) / d) * 14;
    if (q->user) sc += 3;
    if (sc > bs) { bs = sc; best = q; }
  }
  return best;
}

// ---------------------------------------------------------------- game feel: shake, glass, spray
void skShake(double a) { SK->shk = std::max(SK->shk, a); }
Wall skWall(double x, double y) {
  const double L = RK.L, Wd = RK.Wd, cr = RK.cr; double cx = -1, cy = -1; bool c = true;
  if (x < cr && y < cr) { cx = cr; cy = cr; } else if (x > L - cr && y < cr) { cx = L - cr; cy = cr; } else if (x < cr && y > Wd - cr) { cx = cr; cy = Wd - cr; } else if (x > L - cr && y > Wd - cr) { cx = L - cr; cy = Wd - cr; } else c = false;
  if (c) { double dx = x - cx, dy = y - cy, d = hyp(dx, dy); if (!d) d = 1; return {cx + dx / d * cr, cy + dy / d * cr, dx / d, dy / d}; }
  double ds[4][3] = {{x, -1, 0}, {L - x, 1, 0}, {y, 0, -1}, {Wd - y, 0, 1}}; int m = 0; for (int i = 1; i < 4; i++) if (ds[i][0] < ds[m][0]) m = i;
  return {ds[m][1] ? (ds[m][1] < 0 ? 0 : L) : x, ds[m][2] ? (ds[m][2] < 0 ? 0 : Wd) : y, ds[m][1], ds[m][2]};
}
void skGlassHit(double x, double y, double a) {
  if (!SK) return; Wall w = skWall(x, y); auto &G = SK->gls;
  for (auto &q : G) if (hyp(q.x - w.x, q.y - w.y) < 7) { q.a = std::max(q.a * std::exp(-q.t * 3.2), a); q.t = 0; return; }
  if (G.size() >= 4) G.erase(G.begin());
  G.push_back({w.x, w.y, w.nx, w.ny, a, 0});
}
void skSpray(Skater *p, double v) {
  auto &S = SK->spr; double sp = hyp(p->vx, p->vy); if (!sp) sp = 1; double ux = p->vx / sp, uy = p->vy / sp; int n = std::min(8, 3 + (int)(v / 6));
  for (int i = 0; i < n; i++) { if (S.size() >= 40) S.erase(S.begin()); double j = rand(-1, 1);
    S.push_back({p->x + ux * .9 - uy * j * .7, p->y + uy * .9 + ux * j * .7, .15, ux * v * rand(.3, .65) - uy * j * rand(3, 7), uy * v * rand(.3, .65) + ux * j * rand(3, 7), rand(3.5, 8), 0, rand(.32, .5)}); }
}
void skSprayUpd(double dt) {
  auto &S = SK->spr; double f = std::exp(-4 * dt);
  for (int i = (int)S.size() - 1; i >= 0; i--) { Spray &q = S[i]; q.t += dt; if (q.t > q.l) { S[i] = S.back(); S.pop_back(); continue; }
    q.x += q.vx * dt; q.y += q.vy * dt; q.vx *= f; q.vy *= f; q.vz -= PG * dt; q.z += q.vz * dt; if (q.z < 0) { q.z = 0; q.vz = 0; } }
}

// ---------------------------------------------------------------- hits, the box, the referee
static void skOverBoards(Skater *b, bool glass) {
  Team &T = SK->T[b->team]; auto it = std::find(T.on.begin(), T.on.end(), b); if (it == T.on.end()) return;
  if (SK->puck.owner == b) { Puck &P = SK->puck; P.owner = nullptr; P.vx *= .3; P.vy *= .3; P.last = b; }
  T.on.erase(it); T.box.push_back({b, glass ? 14.0 : 9.0, true, glass ? 2 : 1}); b->stun = 0; b->kd = false; b->dash = 0; b->vx = b->vy = 0;
  SK->fx.push_back({b->x, b->y < RK.cy ? .5 : RK.Wd - .5, 0, true, true});
  SK->banner = {1.6, glass ? "THROUGH THE GLASS!" : "OVER THE BOARDS!", (b->user ? std::string("YOU are") : b->nm + " is") + " out for " + (glass ? "14" : "9") + "s", hex("#ffb300")};
}
static void skKnockout(Skater *b) {
  Team &T = SK->T[b->team]; auto it = std::find(T.on.begin(), T.on.end(), b); if (it == T.on.end()) return;
  SK->ftUsed = true; SK->ftU[1 - b->team] = true; T.on.erase(it); T.box.push_back({b, 30, true, 0}); b->stun = 0; b->dash = 0;
  Puck &P = SK->puck; P.owner = nullptr; P.vx = P.vy = 0; P.hasShot = false; P.passTo = nullptr; P.ice = -1;
  SK->phase = PH_STOP; SK->stopT = 1.8; SK->hasNextFo = true; SK->nextFo = {RK.L / 2, RK.cy};
  SK->banner = {1.8, "KNOCKOUT!", "FREIGHT TRAIN - " + b->nm + " is out 30s  |  3 ON 2", hex("#ff9800")};
  if (b->team == 1) pushFeed("FREIGHT TRAIN", "#ff9800"); else pushFeed("FREIGHT TRAIN - YOU'RE A MAN DOWN", "#ff7a7a");
}
void skHit(Skater *a, Skater *b) {
  if (b->block > 0) return;
  if (b->spin > 0 && SK->puck.owner == b) {
    double dx = b->x - a->x, dy = b->y - a->y, d = hyp(dx, dy); if (!d) d = 1; b->vx += dx / d * 4; b->vy += dy / d * 4; a->dash = 0;
    if (b->user) pushFeed("SPUN OFF THE HIT", "#93c5fd"); else if (a->user) pushFeed("HE SPUN OFF YOU", "#ff7a7a");
    return;
  }
  Puck &P = SK->puck; bool had = P.owner == b, nearP = !P.owner && hyp(P.x - b->x, P.y - b->y) < 5;
  double hp = a->hitPow ? a->hitPow : 1; a->hitPow = 1;
  double bp = b->at.poise, pw = clamp((.65 + (a->at.chk - bp) * .06 + a->at.chk * .025) * hp, .25, 1.7);
  double dx = b->x - a->x, dy = b->y - a->y, d = hyp(dx, dy); if (!d) d = 1;
  double bs = hyp(b->vx, b->vy), into = bs > 6 ? (-(b->vx * dx + b->vy * dy) / (bs * d)) : 0, spdK = clamp(bs / 24, 0, 1);
  bool headOn = into > .45, behind = into < -.45;
  b->vx += dx / d * 15 * pw; b->vy += dy / d * 15 * pw;
  SK->T[a->team].hits++;
  SK->fx.push_back({(a->x + b->x) / 2, (a->y + b->y) / 2, 0, pw > .9 || a->at.chk > 7, a->user || b->user});
  double easy = b->user && !a->user ? SKD().hit : 1;
  double stunP = clamp((.3 + a->at.chk * .06 - bp * .045) * (hp < .7 ? .35 : hp * hp), .03, .92) * easy;
  bool stunned = rnd() < stunP;
  if (stunned) { int t = pkCan(b, PK_WALL); if (t && rnd() < (t == 1 ? .5 : t == 2 ? .75 : 1)) { stunned = false; pkSpend(b, PK_WALL); } }
  a->hitT = b->hitT = SK->gt;
  { double v = sndAt(b->x, b->y); std::string nm = b->nm.empty() ? "x" : b->nm;
    sfx(S_HIT, v * std::min(1.1, .45 + .5 * pw), rand(.92, 1.05)); sfx(S_GRUNT1 + skHash(nm) % 3, v * (stunned ? .95 : .7), (.94 + (skHash(nm + "v") % 12) * .01) * rand(.97, 1.03)); }
  if (stunned || (hp > .8 && pw > .95)) { SK->hstop = .07; skShake(.9); SK->hitFl = 1.1; } else skShake(.25);
  if (std::min(std::min(b->y, RK.Wd - b->y), std::min(b->x, RK.L - b->x)) < 6) skGlassHit(b->x + dx / d * 3, b->y + dy / d * 3, clamp(pw * .8, .3, 1));
  if (stunned) { b->stun = std::max(b->stun, clamp(1.2 + (a->at.chk - bp) * .1, .8, 2.1)); b->kd = true; b->stunMax = b->stun; b->rgA = std::atan2(dy, dx) + rand(-.25, .25); b->rgT = 0; b->rgSp = rand(-.9, .9); }
  static const double WL[4] = {1, .8, .65, .5};
  double looseP = clamp(.35 + a->at.chk * .04 - b->at.hand * .035 - bp * .015 + (headOn ? .4 * spdK * into : 0), .1, .95) * (behind ? .75 : 1) * easy * WL[pkT(b, PK_WALL)];
  if (had && headOn && spdK > .4 && (a->user || b->user)) pushFeed("HEAD-ON HIT!", "#ffb300");
  if (had && (stunned || rnd() < looseP)) {
    P.owner = nullptr; b->cool = .7; a->cool = std::max(a->cool, .45); b->stun = std::max(b->stun, stunned ? b->stun + .35 : .45); if (b->kd) b->stunMax = b->stun;
    { double sp = stunned ? rand(5, 10) : rand(3, 7); P.vx = b->vx * .35 + dx / d * sp + rand(-2, 2); P.vy = b->vy * .35 + dy / d * sp + rand(-2, 2); }   // knocked off his stick: it squirts a few feet the way he was hit
    P.last = b; P.hasShot = false; P.passTo = nullptr; P.ice = -1;
  }
  if (stunned && SK->phase == PH_PLAY) { Team &T = SK->T[b->team]; double nb = std::min(b->y, RK.Wd - b->y), toward = (b->y < RK.cy ? -dy : dy) / d;
    if (nb < 5.5 && toward > .25 && T.box.empty() && T.on.size() >= 3 && onTeam(b->team, b) && rnd() < .1 + (a->at.chk - bp) * .02) {
      if (a->user) { SK->me.hits++; award(5); fillStat("check", .04); pushFeed(xpTag("SENT HIM FLYING!", 5), "#7CFC9A"); } skOverBoards(b, rnd() < .4); return; } }
  int ftT = had ? pkCan(a, PK_FREIGHT) : 0;
  if (ftT && !SK->ftU[a->team] && SK->phase == PH_PLAY && SK->T[b->team].box.empty() && SK->T[b->team].on.size() >= 3 && rnd() < (ftT == 1 ? .06 : ftT == 2 ? .1 : .15)) {
    if (a->user) { SK->me.hits++; award(10); fillStat("check", .06); } pkSpend(a, PK_FREIGHT); skKnockout(b); return;
  }
  if (a->user) { SK->me.hits++; award(2); fillStat("check", stunned ? .03 : .015); pushFeed(xpTag(stunned ? "BIG HIT!" : "HIT!", 2), "#7CFC9A"); }
  if (b->user) { pushFeed(stunned ? "YOU GOT ROCKED" : "YOU GOT HIT", "#ff7a7a"); fillStat("poise", stunned ? .02 : .012); }
  bool justHad = SK->gt - b->passT < .8 || (SK->puck.last == b && SK->gt - b->lostT < .8);
  if (!had && !nearP && !justHad && rnd() < (hp < .7 ? .1 : .42) + a->at.chk * .015) skPenalty(a, rnd() < .6 ? "INTERFERENCE" : "ROUGHING");
}
bool g_rOff = true, g_rIce = true, g_rPen = true;
void skPenalty(Skater *p, const char *kind) {
  if (!g_rPen) return;   // penalties off (Settings)
  Team &T = SK->T[p->team]; if (!T.box.empty() || SK->phase != PH_PLAY) return;
  if (SK->hasRef) SK->ref.arm = 2.6;
  auto it = std::find(T.on.begin(), T.on.end(), p); if (it == T.on.end()) return;
  T.on.erase(it); T.box.push_back({p, SK_PEN, false, 0}); p->stun = 0; p->dash = 0;
  T.pen++; SK->T[1 - p->team].ppn++;
  if (p->user) SK->me.pim += 2;
  Puck &P = SK->puck; P.owner = nullptr; P.vx = P.vy = 0; P.hasShot = false; P.passTo = nullptr; P.ice = -1;
  SK->phase = PH_STOP; SK->stopT = 1.6;
  SK->hasNextFo = true; SK->nextFo = {defendX(p->team) + tdir(p->team) * 20, P.y < RK.cy ? RK.cy - 22 : RK.cy + 22};
  SK->banner = {1.6, "PENALTY", (p->user ? std::string("YOU") : p->nm) + " - " + kind + " (2:00 = 20s)", hex("#ffb300")};
}
void skBoxOut(Team &T, int ti, Skater *p) {
  if (p->benchGhost) return;
  p->x = RK.L / 2 - tdir(ti) * 6; p->y = RK.Wd - 3; p->vx = 0; p->vy = 0; p->stun = 0; T.on.push_back(p);
  p->st = 100; p->tired = false;
  if (p->user) pushFeed("BACK ON THE ICE", "#7CFC9A");
}
void skBoxTick(double dt) {
  for (int ti = 0; ti < 2; ti++) { Team &T = SK->T[ti]; std::vector<Box> keep, out;
    for (Box &b : T.box) { b.t -= dt; if (b.t > 0) keep.push_back(b); else out.push_back(b); }
    T.box = keep; for (Box &b : out) skBoxOut(T, ti, b.p); }
}
void skRefUpdate(double dt) {
  if (!SK->hasRef) return; Ref &r = SK->ref; Puck &P = SK->puck; r.arm = std::max(0.0, r.arm - dt);
  double tx, ty, sp = 24; r.drop = false;
  if (SK->phase == PH_FACEOFF) { skRefSnap(); return; }
  else if (SK->phase == PH_INTRO) { tx = RK.L / 2; ty = RK.cy + 9; sp = 14; }
  else if (SK->phase == PH_GOAL || SK->phase == PH_STOP || SK->phase == PH_TRANS) { tx = RK.L / 2 + (r.x > RK.L / 2 ? 8 : -8); ty = RK.Wd - 6; sp = 12; }
  else { Skater *o = P.owner; tx = clamp(P.x + (o ? tdir(o->team) * 7 : 0), 16, RK.L - 16); ty = P.y < RK.cy ? RK.Wd - 4.5 : 4.5; }
  double dx = tx - r.x, dy = ty - r.y, m = hyp(dx, dy), v = std::min(sp, m * 1.8), a = std::min(1.0, 2.2 * dt);
  r.vx += ((m > .3 ? dx / m * v : 0) - r.vx) * a; r.vy += ((m > .3 ? dy / m * v : 0) - r.vy) * a; r.x += r.vx * dt; r.y += r.vy * dt;
  r.x = clamp(r.x, 4, RK.L - 4); r.y = clamp(r.y, 2.5, RK.Wd - 2.5);
  double s = hyp(r.vx, r.vy); if (s > 2.5 && !r.drop) r.ang = std::atan2(r.vy, r.vx); else if (!r.drop && s < 1) r.ang = std::atan2(P.y - r.y, P.x - r.x); r.ph += s * dt * .45;
}
// the event feed on the right (the web build strips "+XP" outside Be a Pro; Quick Play never shows XP)
void pushFeed(const std::string &txt, Col col) { Feed f; f.txt = txt; f.col = col; feed.push_back(f); if (feed.size() > 6) feed.erase(feed.begin()); }

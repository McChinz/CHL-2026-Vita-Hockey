// CHL 2026 native - BE A PRO: Hockeymon, the card-collecting side game on your phone. Buy packs (they ship to your door
// after your next game), open them, fill the 60-monster collection, sell the cards (each has a value: most are worth less
// than the pack, now and then a break-even card, very rarely a huge hit). Trading comes later.
#pragma once
#include <string>
#include <vector>

constexpr int HM_N = 60, HM_NV = 3, HM_NP = 3;   // monsters, card variants (normal, holo, gold), pack kinds
enum { HMT_ICE, HMT_FIRE, HMT_STEEL, HMT_SPARK, HMT_LEAF, HMT_WATER, HMT_STONE, HMT_SHADE, HMT_WIND, HMT_N };
struct HmMon { const char *n; int type, tier, line, stage; };   // tier 0 common, 1 uncommon, 2 rare, 3 ultra rare, 4 legend
const HmMon &hmMon(int id);
const char *hmTypeName(int t);
const char *hmTierName(int tier);       // "COMMON"...
const char *hmVarName(int v);           // "", "HOLO", "GOLD"
int hmValue(int id, int v);             // cents
struct HmPack { const char *n, *d; int price, cards; const char *c1, *c2; };
const HmPack &hmPack(int k);
struct HmCard { int id, v; };
std::vector<HmCard> hmRoll(int k);      // open a pack: its cards, the best one last
std::string hmCash(int cents);          // "$12.50"

// drawing: a monster in a sz x sz box (cx, cy its middle); a card face (x, y, w, h); a pack's wrapper
void hmDrawMon(int id, double cx, double cy, double sz);
void hmDrawCard(double x, double y, double w, double h, int id, int v, bool owned = true);
void hmDrawPack(double x, double y, double w, double h, int k);

#include <chrono>
// CHL 2026 native - the 3D view (first pass): a perspective broadcast camera behind the play, and the arena,
// nets, puck, skaters, goalies and the ref as low-poly lit models. Everything is projected here and drawn as
// flat-shaded triangles, back to front (no depth buffer on vita2d). The game itself is unchanged: same world
// (feet, x along the rink, y across, z up), same physics. SELECT switches between this and the classic view.
#include "game.h"
#include "sk_int.h"
#include <functional>
#include <cstdlib>

bool g_view3d = true;
bool g_camHigh = false;   // CAMERA HIGH: the overhead view (attack straight up the screen); LOW: the broadcast view

// ---------------------------------------------------------------- the camera
// single precision: the Vita's CPU does floats far faster than doubles, and every triangle goes through these
struct V3 { float x, y, z; V3() : x(0), y(0), z(0) {} V3(double a, double b, double c) : x((float)a), y((float)b), z((float)c) {} };
static inline V3 operator+(V3 a, V3 b) { V3 o; o.x = a.x + b.x; o.y = a.y + b.y; o.z = a.z + b.z; return o; }
static inline V3 operator-(V3 a, V3 b) { V3 o; o.x = a.x - b.x; o.y = a.y - b.y; o.z = a.z - b.z; return o; }
static inline V3 operator*(V3 a, double k) { float f = (float)k; V3 o; o.x = a.x * f; o.y = a.y * f; o.z = a.z * f; return o; }
static inline double dot(V3 a, V3 b) { return (double)(a.x * b.x + a.y * b.y + a.z * b.z); }
static inline V3 cross(V3 a, V3 b) { V3 o; o.x = a.y * b.z - a.z * b.y; o.y = a.z * b.x - a.x * b.z; o.z = a.x * b.y - a.y * b.x; return o; }
static inline V3 norm(V3 a) { float l = std::sqrt(dot(a, a)); return l > 1e-9f ? a * (1 / l) : V3{0, 0, 1}; }
static struct { V3 e, f, r, u; double F, sx, sy; } C3;
static const double NEARZ = 4.0;   // the camera never gets closer than this; a larger near plane keeps depth precise far away (no flicker)
static void cam3Update() {
  // our own follow: the puck (or whoever has it), a little ahead of it, smoothed; ends kept in view
  static double fx = RK.L / 2, fy = RK.cy; static const Game *last = nullptr;
  double tx = RK.L / 2, ty = RK.cy;
  if (SK) { const Puck &P = SK->puck; tx = P.x + (P.owner ? std::cos(P.owner->ang) * 6 : 0); ty = P.y; if (SK->phase == PH_PREVIEW || SK->phase == PH_INTRO) tx = RK.L / 2; }
  static bool lastHigh = false; bool hi = g_camHigh;
#ifdef HOST_BUILD
  if (getenv("CHL_CAMHI")) hi = true;
#endif
  // HIGH: straight down over the play, the full width of the ice (both benches) in view; it runs right to each end,
  // so in your own zone your net sits at the bottom of the screen and in theirs at the top.
  // LOW: the NHL low camera - up above the end, about 40 degrees down; in your own zone it backs up over the end
  // boards so your net is near the bottom of the screen, in theirs the net and end boards fill the top.
  if (hi) { tx = clamp(tx + 1, 21, RK.L - 21); ty = RK.cy + (ty - RK.cy) * .15; }
  else { tx = clamp(tx - 6, 12, RK.L - 32); ty = RK.cy + (ty - RK.cy) * .3; }
  if (last != SK || lastHigh != hi) { fx = tx; fy = ty; last = SK; lastHigh = hi; } else { fx += (tx - fx) * .09; fy += (ty - fy) * (hi ? .08 : .06); }
  double cx = fx, cy = fy;
  V3 t;
  if (hi) { C3.e = {cx - 13, cy, 84}; t = {cx, cy, 0}; }             // overhead, tipped just a little toward the attack
  else { C3.e = {cx - 56, cy, 50}; t = {cx + 8, cy, 0}; }
#ifdef HOST_BUILD
  if (const char *cs = getenv("CHL_CAM")) { double v[6]; if (sscanf(cs, "%lf,%lf,%lf,%lf,%lf,%lf", &v[0], &v[1], &v[2], &v[3], &v[4], &v[5]) == 6) { C3.e = {v[0], v[1], v[2]}; t = {v[3], v[4], v[5]}; } }   // tests: a close-up camera
#endif
  C3.f = norm(t - C3.e); C3.r = norm(cross({0, 0, 1}, C3.f)); C3.u = cross(C3.f, C3.r);
  C3.F = W * .9; C3.sx = W / 2; C3.sy = H * .5 + .05 * U;
}
static inline V3 toCam(V3 p) { V3 v = p - C3.e; return {dot(v, C3.r), dot(v, C3.u), dot(v, C3.f)}; }
static inline Pt camProj(V3 c) { return {C3.sx + c.x / c.z * C3.F, C3.sy - c.y / c.z * C3.F}; }
Pt sk3Proj(double x, double y, double z) { V3 c = toCam({x, y, z}); if (c.z < NEARZ) c.z = NEARZ; return camProj(c); }
double sk3Scale(double x, double y, double z) { V3 c = toCam({x, y, z}); return C3.F / std::max(NEARZ, (double)c.z); }

// ---------------------------------------------------------------- the triangle queue
struct Tri3 { float x[3], y[3]; uint32_t c; float od, td; };
static std::vector<Tri3> Q;          // sorted (back to front)
static double g_objDepth = 0;         // the object being built: its triangles sort together
static const V3 LIGHT = norm({-.35, .45, 1});
static V3 g_half = {0, 0, 1};   // the sheen's half vector (set per frame)
static Col litColAvg(uint32_t a, uint32_t b, uint32_t c) {
  auto ch = [&](int sh) { return (float)((((a >> sh) & 255) + ((b >> sh) & 255) + ((c >> sh) & 255)) / 3.0); };
  return Col(ch(0), ch(8), ch(16), ch(24) / 255.f);
}
static uint32_t litCol(Col c, V3 n, double a) {
  // a key light from above, a fill from the camera's side (so faces toward us never go muddy), a touch of sheen
  double key = std::max(0.0, dot(n, LIGHT)), fill = std::max(0.0, -dot(n, C3.f)), k = .5 + .38 * key + .3 * fill;
  double hv = std::max(0.0, dot(n, g_half)), h2 = hv * hv, h4 = h2 * h2, h8 = h4 * h4, sh = h8 * h4 * .35;
  Col o(std::min(255.0, c.r * k + 255 * sh), std::min(255.0, c.g * k + 255 * sh), std::min(255.0, c.b * k + 255 * sh), c.a * a); return o.pack();
}
// GPU path (vitaGL): world-space triangles by pass; the see-through ones are sorted back to front
static bool g_gpu = false;
static std::vector<V3c> GB[3];                       // 0 solid, 1 painted on the ice, 2 reflections under the ice
static bool g_refl = false;                          // what's being built shows in the ice (GPU path)
static bool g_keep = false;                          // building cached geometry: keep every face (no culling)
struct ATri { V3c v[3]; float d; }; static std::vector<ATri> GA;
static inline V3c vc(V3 p, uint32_t c) { V3c o; o.x = (float)p.x; o.y = (float)p.y; o.z = (float)p.z; o.c = c; return o; }
// geometry built once and kept (ice, crowd, nets) still has to be cut at the camera's near plane every frame: the GPU
// does not do that reliably, and a triangle reaching behind the camera turns into a long smeared strip on screen
static void appendClip(std::vector<V3c> &dst, const std::vector<V3c> &src);
// a convex polygon in world space: near-clipped, then either queued for the GPU or projected and fanned here.
// n: its outward normal (back faces skipped), or null for both sides; immediate: painted on the ice (drawn under
// everything standing on it)
static void poly(const V3 *p, int n, Col col, const V3 *nrm, double a = 1, bool lit = true, bool immediate = false) {
  if (n < 3) return;
  V3 cen = {0, 0, 0}; for (int i = 0; i < n; i++) cen = cen + p[i]; cen = cen * (1.0 / n);
  V3 N = nrm ? *nrm : norm(cross(p[1] - p[0], p[2] - p[0]));
  if (nrm && !g_keep && dot(N, cen - C3.e) >= 0) return;          // facing away
  if (!nrm && dot(N, cen - C3.e) > 0) N = N * -1;      // two-sided: light the side we see
  uint32_t c = lit ? litCol(col, N, a) : withA(col, (float)(col.a * a)).pack();
  // clip against the near plane (in front of the camera by NEARZ)
  V3 out[20]; int m = std::min(n, 16), k = 0;
  if (g_keep && g_gpu) { for (int i = 0; i < m; i++) out[k++] = p[i]; }   // geometry built once and kept: the GPU clips it each frame
  else for (int i = 0; i < m; i++) { V3 A = p[i], B = p[(i + 1) % m]; double da = dot(A - C3.e, C3.f) - NEARZ, db = dot(B - C3.e, C3.f) - NEARZ;
    if (da >= 0) out[k++] = A; if ((da >= 0) != (db >= 0)) { double t = da / (da - db); out[k++] = A + (B - A) * t; } }
  if (k < 3) return;
  double td = dot(cen - C3.e, C3.f);
  if (g_gpu) {
    bool see = (c >> 24) < 250;
    for (int i = 1; i + 1 < k; i++) {
      if (immediate) { GB[1].push_back(vc(out[0], c)); GB[1].push_back(vc(out[i], c)); GB[1].push_back(vc(out[i + 1], c)); }
      else if (see) { ATri t; t.v[0] = vc(out[0], c); t.v[1] = vc(out[i], c); t.v[2] = vc(out[i + 1], c); t.d = (float)td; GA.push_back(t); }
      else { GB[0].push_back(vc(out[0], c)); GB[0].push_back(vc(out[i], c)); GB[0].push_back(vc(out[i + 1], c));
        if (g_refl) { Col rc((float)((c & 255) * .78 + 8), (float)(((c >> 8) & 255) * .78 + 12), (float)(((c >> 16) & 255) * .78 + 20)); uint32_t r = rc.pack();
          for (V3 q : {out[0], out[i], out[i + 1]}) { q.z = -q.z; GB[2].push_back(vc(q, r)); } } }
    }
    return;
  }
  Pt s[20]; double minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9;
  for (int i = 0; i < k; i++) { V3 cc = toCam(out[i]); if (cc.z < NEARZ) cc.z = NEARZ; s[i] = camProj(cc); minX = std::min(minX, s[i].x); maxX = std::max(maxX, s[i].x); minY = std::min(minY, s[i].y); maxY = std::max(maxY, s[i].y); }
  if (maxX < 0 || minX > W || maxY < 0 || minY > H) return;
  for (int i = 1; i + 1 < k; i++) {
    if (immediate) ctx.rawTri(s[0].x, s[0].y, s[i].x, s[i].y, s[i + 1].x, s[i + 1].y, c);
    else { Tri3 t; t.x[0] = s[0].x; t.y[0] = s[0].y; t.x[1] = s[i].x; t.y[1] = s[i].y; t.x[2] = s[i + 1].x; t.y[2] = s[i + 1].y; t.c = c; t.od = (float)g_objDepth; t.td = (float)td; Q.push_back(t); }
  }
}
// the GPU's clip matrix for this camera: the same projection the CPU path uses (near 4 ft, far 500 ft)
static void clipMatrix(float *m) {
  const double n = NEARZ, f = 500, A = 2 * C3.F / W, B = 2 * C3.sx / W - 1, Cc = 2 * C3.F / H, D = 1 - 2 * C3.sy / H, E = (f + n) / (f - n), G = -2 * f * n / (f - n);
  // rows of P * V, V = [r; u; fwd] with -dot(axis, eye)
  const V3 R = C3.r, Uu = C3.u, Fw = C3.f, e = C3.e;
  double rows[4][4] = {
    {A * R.x + B * Fw.x, A * R.y + B * Fw.y, A * R.z + B * Fw.z, -A * dot(R, e) - B * dot(Fw, e)},
    {Cc * Uu.x + D * Fw.x, Cc * Uu.y + D * Fw.y, Cc * Uu.z + D * Fw.z, -Cc * dot(Uu, e) - D * dot(Fw, e)},
    {E * Fw.x, E * Fw.y, E * Fw.z, -E * dot(Fw, e) + G},
    {Fw.x, Fw.y, Fw.z, -dot(Fw, e)}};
  for (int c = 0; c < 4; c++) for (int r = 0; r < 4; r++) m[c * 4 + r] = (float)rows[r][c];
}
static void flushGPU() {
  ctx.flush();   // the 2D drawn so far (the backdrop) goes first
  float M[16]; clipMatrix(M);
  if (!GB[2].empty()) plat_draw3d(M, GB[2].data(), (int)GB[2].size(), 0);   // the players, nets and boards mirrored under the ice
  if (!GB[0].empty()) plat_draw3d(M, GB[0].data(), (int)GB[0].size(), 0);
  if (!GB[1].empty()) plat_draw3d(M, GB[1].data(), (int)GB[1].size(), 1);
  if (!GA.empty()) { std::sort(GA.begin(), GA.end(), [](const ATri &a, const ATri &b) { return a.d > b.d; });
    std::vector<V3c> v; v.reserve(GA.size() * 3); for (auto &t : GA) for (int i = 0; i < 3; i++) v.push_back(t.v[i]); plat_draw3d(M, v.data(), (int)v.size(), 2); }
  GB[0].clear(); GB[1].clear(); GB[2].clear(); GA.clear();
}
static void quad(V3 a, V3 b, V3 c, V3 d, Col col, const V3 *n, double al = 1, bool lit = true, bool imm = false) { V3 p[4] = {a, b, c, d}; poly(p, 4, col, n, al, lit, imm); }
static void flushQ() {
  std::sort(Q.begin(), Q.end(), [](const Tri3 &a, const Tri3 &b) { if (a.od != b.od) return a.od > b.od; return a.td > b.td; });
  for (auto &t : Q) ctx.rawTri(t.x[0], t.y[0], t.x[1], t.y[1], t.x[2], t.y[2], t.c);
  Q.clear();
}
static void objAt(double x, double y, double z = 0) { g_objDepth = toCam({x, y, z}).z; }

// ---------------------------------------------------------------- models: boxes in a local frame
// local frame: x forward, y to the left, z up; M = rotation (3 columns) + origin
struct M3 { V3 X, Y, Z, O; V3 ap(V3 p) const { return O + X * p.x + Y * p.y + Z * p.z; } V3 dir(V3 p) const { return X * p.x + Y * p.y + Z * p.z; } };
static M3 frameAt(double x, double y, double z, double yaw) { M3 m; m.X = {std::cos(yaw), std::sin(yaw), 0}; m.Y = {-std::sin(yaw), std::cos(yaw), 0}; m.Z = {0, 0, 1}; m.O = {x, y, z}; return m; }
// rotate the frame about its own y (pitch: + tips the top forward), x (roll: + tips toward -y), z (yaw)
static M3 pitch(M3 m, double a) { double c = std::cos(a), s = std::sin(a); M3 o = m; o.X = m.X * c + m.Z * -s; o.Z = m.X * s + m.Z * c; return o; }
static M3 roll(M3 m, double a) { double c = std::cos(a), s = std::sin(a); M3 o = m; o.Y = m.Y * c + m.Z * s; o.Z = m.Y * -s + m.Z * c; return o; }
static M3 moveTo(M3 m, V3 p) { m.O = m.ap(p); return m; }
static M3 yawFrame(V3 p, double yaw) { return frameAt(p.x, p.y, p.z, yaw); }
// a box: center c, half sizes h, in frame m
// a box hanging from a joint: from the joint down its own -z by len
// an n-sided prism standing on z (puck, posts)
static void prism(V3 c, double r, double h, int n, Col side, Col top) {
  std::vector<V3> b(n), t(n);
  for (int i = 0; i < n; i++) { double a = i * 2 * PI / n; b[i] = {c.x + std::cos(a) * r, c.y + std::sin(a) * r, c.z}; t[i] = b[i] + V3{0, 0, h}; }
  for (int i = 0; i < n; i++) { int j = (i + 1) % n; double a = (i + .5) * 2 * PI / n; V3 nn = {std::cos(a), std::sin(a), 0}; quad(b[i], b[j], t[j], t[i], side, &nn); }
  V3 up = {0, 0, 1}; poly(t.data(), std::min(n, 16), top, &up);
}
// a flat disc / ring on the ice, drawn now (under everything standing on it)
static void iceDisc(double x, double y, double r, Col c, int n = 12, double z = .03) {
  std::vector<V3> p(n); for (int i = 0; i < n; i++) { double a = i * 2 * PI / n; p[i] = {x + std::cos(a) * r, y + std::sin(a) * r, z}; } poly(p.data(), n, c, nullptr, 1, false, true);
}
static void iceArc(double x, double y, double r0, double r1, double a0, double a1, Col c, int n = 20, double z = .02) {
  for (int i = 0; i < n; i++) { double u0 = a0 + (a1 - a0) * i / n, u1 = a0 + (a1 - a0) * (i + 1) / n;
    quad({x + std::cos(u0) * r0, y + std::sin(u0) * r0, z}, {x + std::cos(u1) * r0, y + std::sin(u1) * r0, z}, {x + std::cos(u1) * r1, y + std::sin(u1) * r1, z}, {x + std::cos(u0) * r1, y + std::sin(u0) * r1, z}, c, nullptr, 1, false, true); }
}
static void iceRect(double x0, double y0, double x1, double y1, Col c, double z = .02) { quad({x0, y0, z}, {x1, y0, z}, {x1, y1, z}, {x0, y1, z}, c, nullptr, 1, false, true); }

// ---------------------------------------------------------------- the arena
// the rink's outline (rounded corners), counter-clockwise
static const std::vector<Pt> &rinkOutline() {
  static std::vector<Pt> o; if (!o.empty()) return o;
  const double L = RK.L, Wd = RK.Wd, r = RK.cr; const int n = 8;
  auto corner = [&](double cx, double cy, double a0) { for (int i = 0; i <= n; i++) { double a = a0 + i * (PI / 2) / n; o.push_back({cx + std::cos(a) * r, cy + std::sin(a) * r}); } };
  corner(L - r, r, -PI / 2); corner(L - r, Wd - r, 0); corner(r, Wd - r, PI / 2); corner(r, r, PI);
  // the long straight sides in pieces (so the boards sort well against the players)
  std::vector<Pt> f; for (size_t i = 0; i < o.size(); i++) { Pt a = o[i], b = o[(i + 1) % o.size()]; double d = hyp(b.x - a.x, b.y - a.y); int k = std::max(1, (int)std::ceil(d / 10));
    for (int j = 0; j < k; j++) f.push_back({a.x + (b.x - a.x) * j / k, a.y + (b.y - a.y) * j / k}); }
  o = f; return o;
}
static void drawCrowd() {
  // stands: rows rising away from the boards, a colour per seat block (fixed)
  static const char *shirts[12] = {"#ef4444", "#f8fafc", "#3b82f6", "#facc15", "#64748b", "#1e293b", "#f97316", "#22c55e", "#e2e8f0", "#7c3aed", "#dc2626", "#0ea5e9"};
  const auto &O = rinkOutline(); size_t n = O.size(); double cx = RK.L / 2, cy = RK.cy;
  for (size_t i = 0; i < n; i++) {
    Pt a = O[i], b = O[(i + 1) % n]; double ex = (a.x + b.x) / 2 - cx, ey = (a.y + b.y) / 2 - cy;
    double ox = b.y - a.y, oy = -(b.x - a.x), ol = hyp(ox, oy); ox /= ol; oy /= ol; if (ox * ex + oy * ey < 0) { ox = -ox; oy = -oy; }   // outward
    V3 on = {-ox, -oy, .9}; on = norm(on);
    objAt((a.x + b.x) / 2 + ox * 30, (a.y + b.y) / 2 + oy * 30, 20);
    for (int r = 0; r < 6; r++) {
      double d0 = 6 + r * 4.2, d1 = d0 + 4.2, z0 = 6 + r * 2.6, z1 = z0 + 2.6;
      SkRng R((int)(i * 31 + r * 7 + 3)); Col c = hex(R() < .5 ? shirts[(int)(R() * 12) % 12] : (r % 2 ? "#273449" : "#1f2a3d"));
      quad({a.x + ox * d0, a.y + oy * d0, z0}, {b.x + ox * d0, b.y + oy * d0, z0}, {b.x + ox * d1, b.y + oy * d1, z1}, {a.x + ox * d1, a.y + oy * d1, z1}, c, &on);
      V3 rn = {-ox, -oy, 0}; quad({a.x + ox * d1, a.y + oy * d1, z0}, {b.x + ox * d1, b.y + oy * d1, z0}, {b.x + ox * d1, b.y + oy * d1, z1}, {a.x + ox * d1, a.y + oy * d1, z1}, hex("#151c2b"), &rn);
    }
  }
}
// the GPU crowd: tiered seating with rows of fans (a shirt and a head each, a good share in the home colours),
// built once per game and kept - depth-tested with everything else, and no CPU cost per frame
static void appendClip(std::vector<V3c> &dst, const std::vector<V3c> &src) {
  const float ex = (float)C3.e.x, ey = (float)C3.e.y, ez = (float)C3.e.z, fx = (float)C3.f.x, fy = (float)C3.f.y, fz = (float)C3.f.z, nz = (float)NEARZ;
  auto dep = [&](const V3c &v) { return (v.x - ex) * fx + (v.y - ey) * fy + (v.z - ez) * fz - nz; };
  auto mix = [](const V3c &a, const V3c &b, float t) { V3c o; o.x = a.x + (b.x - a.x) * t; o.y = a.y + (b.y - a.y) * t; o.z = a.z + (b.z - a.z) * t; uint32_t c = 0;
    for (int k = 0; k < 32; k += 8) { float ca = (a.c >> k) & 255, cb = (b.c >> k) & 255; c |= (uint32_t)(ca + (cb - ca) * t + .5f) << k; } o.c = c; return o; };
  dst.reserve(dst.size() + src.size());
  for (size_t i = 0; i + 2 < src.size(); i += 3) {
    const V3c *v = &src[i]; float d[3] = {dep(v[0]), dep(v[1]), dep(v[2])};
    if (d[0] >= 0 && d[1] >= 0 && d[2] >= 0) { dst.push_back(v[0]); dst.push_back(v[1]); dst.push_back(v[2]); continue; }
    if (d[0] < 0 && d[1] < 0 && d[2] < 0) continue;
    V3c out[4]; int k = 0;
    for (int j = 0; j < 3; j++) { int n = (j + 1) % 3; if (d[j] >= 0) out[k++] = v[j]; if ((d[j] >= 0) != (d[n] >= 0)) out[k++] = mix(v[j], v[n], d[j] / (d[j] - d[n])); }
    for (int j = 1; j + 1 < k; j++) { dst.push_back(out[0]); dst.push_back(out[j]); dst.push_back(out[j + 1]); }
  }
}
static void drawCrowdGeo() {
  static const char *shirts[10] = {"#f8fafc", "#1e293b", "#64748b", "#facc15", "#3b82f6", "#ef4444", "#22c55e", "#f97316", "#cbd5e1", "#7c3aed"};
  static const char *skins[4] = {"#f1c6a5", "#d9a47c", "#a8714f", "#6b4630"};
  Col home = SK ? SK->T[0].col : hex("#2563eb"), homeS = SK ? SK->T[0].stripe : hex("#f8fafc"), away = SK ? SK->T[1].col : hex("#dc2626");
  const auto &O = rinkOutline(); size_t n = O.size(); double cx = RK.L / 2, cy = RK.cy; V3 up = {0, 0, 1};
  for (size_t i = 0; i < n; i++) {
    Pt a = O[i], b = O[(i + 1) % n]; double ex = (a.x + b.x) / 2 - cx, ey = (a.y + b.y) / 2 - cy;
    double ox = b.y - a.y, oy = -(b.x - a.x), ol = hyp(ox, oy); ox /= ol; oy /= ol; if (ox * ex + oy * ey < 0) { ox = -ox; oy = -oy; }
    double sx = b.x - a.x, sy = b.y - a.y, sl = hyp(sx, sy); V3 fn = {-ox, -oy, 0};
    for (int r = 0; r < 6; r++) {
      double d0 = 6 + r * 3.6, d1 = d0 + 3.6, z0 = 5.5 + r * 2.4, z1 = z0 + 2.4;
      Col step = hex(r % 2 ? "#1b2333" : "#202a3c"), rise = hex("#121826");
      quad({a.x + ox * d0, a.y + oy * d0, z0}, {b.x + ox * d0, b.y + oy * d0, z0}, {b.x + ox * d1, b.y + oy * d1, z0}, {a.x + ox * d1, a.y + oy * d1, z0}, step, &up);
      quad({a.x + ox * d1, a.y + oy * d1, z0}, {b.x + ox * d1, b.y + oy * d1, z0}, {b.x + ox * d1, b.y + oy * d1, z1}, {a.x + ox * d1, a.y + oy * d1, z1}, rise, &fn);
      int m = std::max(1, (int)(sl / 2.3)); SkRng R((int)(i * 131 + r * 17 + 5));
      for (int k = 0; k < m; k++) { if (R() < .12) continue;   // an empty seat here and there
        double t = (k + .5 + (R() - .5) * .35) / m, px = a.x + sx * t + ox * (d0 + 1.6), py = a.y + sy * t + oy * (d0 + 1.6), w = .65, h = 1.5 + R() * .35;
        double q = R(); Col sh = q < .38 ? home : q < .46 ? homeS : q < .55 ? away : hex(shirts[(int)(R() * 10) % 10]);
        double tx = sx / sl * w, ty = sy / sl * w;
        quad({px - tx, py - ty, z0}, {px + tx, py + ty, z0}, {px + tx * .9, py + ty * .9, z0 + h}, {px - tx * .9, py - ty * .9, z0 + h}, sh, &fn);   // the shirt
        double hz = z0 + h, hs = .38; Col sk = hex(skins[(int)(R() * 4) % 4]);
        quad({px - tx * .55, py - ty * .55, hz}, {px + tx * .55, py + ty * .55, hz}, {px + tx * .55, py + ty * .55, hz + hs * 2}, {px - tx * .55, py - ty * .55, hz + hs * 2}, sk, &fn); } }
  }
}
static void drawCrowd3() {
  static std::vector<V3c> C; static const Game *cg = nullptr; static uint32_t ck = 0; uint32_t key = SK ? SK->T[0].col.pack() * 7u ^ SK->T[1].col.pack() : 0;
  if (cg != SK || ck != key || C.empty()) { size_t b0 = GB[0].size(); bool kk = g_keep, kr = g_refl; g_keep = true; g_refl = false; drawCrowdGeo(); g_keep = kk; g_refl = kr;
    C.assign(GB[0].begin() + b0, GB[0].end()); GB[0].resize(b0); cg = SK; ck = key; }
  appendClip(GB[0], C);
}
static void drawIceGeo() {
  const auto &O = rinkOutline(); std::vector<V3> p; for (auto &q : O) p.push_back({q.x, q.y, 0});
  // the ice as a fan (convex), drawn in slices so the near-plane clip stays small
  V3 c = {RK.L / 2, RK.cy, 0}; Col ice = hex("#e9f1f8");
  if (g_gpu) {   // polished ice: a floor well under it, the reflections in between, the ice itself a little see-through
    Col fl = hex("#cfdbe8"); quad({-40, -40, -16}, {RK.L + 40, -40, -16}, {RK.L + 40, RK.Wd + 40, -16}, {-40, RK.Wd + 40, -16}, fl, nullptr, 1, false);
    ice = withA(ice, .72f); }
  for (size_t i = 0; i < p.size(); i++) { V3 t[3] = {c, p[i], p[(i + 1) % p.size()]}; poly(t, 3, ice, nullptr, 1, false, true); }
  const double L = RK.L, Wd = RK.Wd, cy = RK.cy, gl = RK.gl;
  Col red = hex("#d43a3a"), blue = hex("#2f5fc4"), crease = hex("#8fb8f0");
  iceRect(L / 2 - .5, 0.6, L / 2 + .5, Wd - .6, red);
  for (double bx : {L / 2 - SK_BLUE / 2 - 0.0, L / 2 + SK_BLUE / 2}) iceRect(bx - .5, .6, bx + .5, Wd - .6, blue);
  for (double gx : {gl, L - gl}) iceRect(gx - .15, 3.5, gx + .15, Wd - 3.5, red);
  iceArc(L / 2, cy, 14.6, 15, 0, 2 * PI, blue, 32); iceDisc(L / 2, cy, .7, blue, 10);
  for (double fx : {gl + 20, L - gl - 20}) for (double fy : {cy - 22, cy + 22}) { iceArc(fx, fy, 14.6, 15, 0, 2 * PI, red, 28); iceDisc(fx, fy, 1, red, 10); }
  for (double fx : {L / 2 - SK_BLUE / 2 + 5, L / 2 + SK_BLUE / 2 - 5}) for (double fy : {cy - 22, cy + 22}) iceDisc(fx, fy, 1, red, 10);
  iceArc(gl, cy, 0, 6, -PI / 2, PI / 2, crease, 10); iceArc(L - gl, cy, 0, 6, PI / 2, PI * 1.5, crease, 10);
  // the NHL details: the crease outline, hash marks and L's at the end-zone circles, the trapezoid behind each net,
  // the referee's crease, and the home team's logo disc at centre ice
  iceArc(gl, cy, 5.85, 6.1, -PI / 2, PI / 2, red, 12, .025); iceArc(L - gl, cy, 5.85, 6.1, PI / 2, PI * 1.5, red, 12, .025);
  for (double fx : {gl + 20, L - gl - 20}) for (double fy : {cy - 22, cy + 22}) {
    for (double sx : {-1.0, 1.0}) for (double sy : {-1.0, 1.0}) {
      iceRect(fx + sx * 1.5 - .1, fy + sy * 15, fx + sx * 1.5 + .1, fy + sy * 17, red, .025);                 // hash marks
      double ax = fx + sx * 2, ay = fy + sy * .75;                                                             // the L's around the dot
      iceRect(std::min(ax, ax + sx * 4), ay - .1, std::max(ax, ax + sx * 4), ay + .1, red, .025);
      iceRect(ax - .1, std::min(ay, ay + sy * 3), ax + .1, std::max(ay, ay + sy * 3), red, .025); } }
  for (int e = 0; e < 2; e++) { double gx = e ? L - gl : gl, bk = e ? L - .8 : .8; for (double sy : {-1.0, 1.0}) {   // the trapezoid
      double y0 = cy + sy * 11, y1 = cy + sy * 14; V3 a = {gx, y0, .025}, b = {bk, y1, .025}, n = {0, sy * .1, 0};
      quad(a - n, b - n, b + n, a + n, red, nullptr, 1, false, true); } }
  iceArc(L / 2, .7, 9.6, 10, 0, PI, red, 14, .025);                                                            // the referee's crease
  if (SK) { const Team &H = SK->T[0]; Col hc = H.col, hs = H.stripe;   // (opaque: see-through decals would sort against the polished ice)
    iceArc(L / 2, cy, 2.2, 7.5, 0, 2 * PI, hc, 24, .028); iceArc(L / 2, cy, 6.2, 6.9, 0, 2 * PI, hs, 24, .029);
    iceArc(L / 2, cy, 1.4, 2.2, 0, 2 * PI, hs, 12, .029); iceArc(L / 2, cy, 0, 1.4, 0, 2 * PI, hc, 10, .029); }
}
// the ice and all its markings never change during a game: on the GPU it's built once and reused every frame
static void drawIce() {
  if (!g_gpu) { drawIceGeo(); return; }
#ifdef HOST_BUILD
  if (getenv("CHL_NOICECACHE")) { drawIceGeo(); return; }
#endif
  static std::vector<V3c> C0, C1; static const Game *cg = nullptr; static uint32_t ck = 0; uint32_t key = SK ? SK->T[0].col.pack() ^ (SK->T[0].stripe.pack() * 31u) : 0;
  if (cg != SK || ck != key || C1.empty()) { size_t b0 = GB[0].size(), b1 = GB[1].size(); bool kk = g_keep; g_keep = true; drawIceGeo(); g_keep = kk;
    C0.assign(GB[0].begin() + b0, GB[0].end()); C1.assign(GB[1].begin() + b1, GB[1].end()); GB[0].resize(b0); GB[1].resize(b1); cg = SK; ck = key;
#ifdef HOST_BUILD
    if (getenv("CHL_PROF")) fprintf(stderr, "ICE cache %zu %zu (GA %zu)\n", C0.size(), C1.size(), GA.size());
#endif
  }
  appendClip(GB[0], C0); appendClip(GB[1], C1);
}
// the arena lights reflected in the polished ice: each light in the roof shows up where the ice mirrors it toward the
// camera - soft white glows, stretched toward you, that slide across the ice as the camera moves (like the real thing)
static void drawIceLights() {
  static const double LX[4] = {.16, .39, .61, .84}, LY[2] = {.27, .73}; const double LZ = 70; V3 E = C3.e;
  for (double fx : LX) for (double fy : LY) {
    V3 Lp = {RK.L * fx, RK.Wd * fy, -LZ}; double t = E.z / (E.z + LZ); V3 P = E + (Lp - E) * t; P.z = .035;
    if (P.x < 4 || P.x > RK.L - 4 || P.y < 4 || P.y > RK.Wd - 4) continue;
    double dx = P.x - E.x, dy = P.y - E.y, dl = hyp(dx, dy); V3 ua = dl > 1 ? V3{dx / dl, dy / dl, 0} : V3{1, 0, 0}, ub = {-ua.y, ua.x, 0};
    double a = 4.5 + dl * .06, b = 2.6; const int N = 16;
    for (int layer = 0; layer < 3; layer++) { double k = 1 - layer * .3; Col c = rgba(255, 255, 255, .09 + layer * .04);
      for (int i = 0; i < N; i++) { double a0 = 2 * PI * i / N, a1 = 2 * PI * (i + 1) / N;
        V3 tri[3] = {P, P + ua * (std::cos(a0) * a * k) + ub * (std::sin(a0) * b * k), P + ua * (std::cos(a1) * a * k) + ub * (std::sin(a1) * b * k)};
        poly(tri, 3, c, nullptr, 1, false, true); } }
  }
}
static void drawBoards() {
  const auto &O = rinkOutline(); size_t n = O.size(); double cx = RK.L / 2, cy = RK.cy;
  for (size_t i = 0; i < n; i++) {
    Pt a = O[i], b = O[(i + 1) % n]; double mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
    V3 in = norm({cx - mx, (cy - my) * 2.3, 0});
    objAt(mx, my, 1);
    quad({a.x, a.y, 0}, {b.x, b.y, 0}, {b.x, b.y, SK_BH}, {a.x, a.y, SK_BH}, hex("#f8fafc"), nullptr);            // the boards
    { V3 k = norm(V3{in.x, in.y, 0}) * .06; V3 a0 = V3{a.x, a.y, 0} + k, b0 = V3{b.x, b.y, 0} + k;      // kick plate: a hair in front of the boards (the same plane flickered)
      quad(a0, b0, b0 + V3{0, 0, .9}, a0 + V3{0, 0, .9}, hex("#f2c230"), nullptr); }
    V3 o = in * -.5; V3 up = {0, 0, 1};
    quad({a.x, a.y, SK_BH}, {b.x, b.y, SK_BH}, V3{b.x, b.y, SK_BH} + o, V3{a.x, a.y, SK_BH} + o, hex("#d43a3a"), &up);   // the top rail
    quad({a.x, a.y, SK_BH}, {b.x, b.y, SK_BH}, {b.x, b.y, SK_BH + 5.5}, {a.x, a.y, SK_BH + 5.5}, rgba(200, 225, 245, .16), nullptr, 1, false);   // glass
  }
}
// the far end banners and the scoreboard lights (simple)
static void drawArena() {
  ctx.fill("#0e1422"); ctx.fillRect(0, 0, W, H);
  Grad g = gLin(0, 0, 0, H * .45); g.add(0, hex("#060a14")); g.add(1, hex("#18213a")); ctx.fill(g); ctx.fillRect(0, 0, W, H * .45);
  if (g_gpu) drawCrowd3(); else { drawCrowd(); flushQ(); }
  drawIce();
  if (g_gpu) drawIceLights();
}

// ---------------------------------------------------------------- smooth shapes (Gouraud: a lit colour per corner)
// heights in the 3D view are drawn 1.7x the physics' (players, nets and the puck are NHL Hitz-sized; the puck's
// flight and the crossbar line up with what the game decides)
static const double VZ = 1.7;
// level of detail: 1 near the camera, down to about .45 far away (fewer sides on every round shape, no reflection)
static double g_lod = 1;
static double lodFor(double x, double y, double z) { double dpt = dot(V3{x, y, z} - C3.e, C3.f); return clamp(48 / std::max(1.0, dpt), .45, 1); }
static void stri(V3 a, V3 b, V3 c, V3 na, V3 nb, V3 nc, Col col) {
  V3 cen = (a + b + c) * (1.0 / 3), nn = na + nb + nc; if (!g_keep && dot(nn, cen - C3.e) > 0) return;    // facing away (convex shapes)
  if (!g_keep && (dot(a - C3.e, C3.f) < NEARZ || dot(b - C3.e, C3.f) < NEARZ || dot(c - C3.e, C3.f) < NEARZ)) return;
  uint32_t ca = litCol(col, na, 1), cb = litCol(col, nb, 1), cc = litCol(col, nc, 1);
  if (g_gpu) {
    GB[0].push_back(vc(a, ca)); GB[0].push_back(vc(b, cb)); GB[0].push_back(vc(c, cc));
    if (g_refl && g_lod > .72) for (int i = 0; i < 3; i++) { V3 q = i == 0 ? a : i == 1 ? b : c; uint32_t k = i == 0 ? ca : i == 1 ? cb : cc;
      Col rc((float)((k & 255) * .78 + 8), (float)(((k >> 8) & 255) * .78 + 12), (float)(((k >> 16) & 255) * .78 + 20)); q.z = -q.z; GB[2].push_back(vc(q, rc.pack())); }
    return;
  }
  Pt s[3]; V3 P[3] = {a, b, c}; for (int i = 0; i < 3; i++) s[i] = camProj(toCam(P[i]));
  double minX = std::min({s[0].x, s[1].x, s[2].x}), maxX = std::max({s[0].x, s[1].x, s[2].x}); if (maxX < 0 || minX > W) return;
  Col avg = litColAvg(ca, cb, cc);
  Tri3 t; for (int i = 0; i < 3; i++) { t.x[i] = (float)s[i].x; t.y[i] = (float)s[i].y; } t.c = avg.pack(); t.od = (float)g_objDepth; t.td = (float)dot(cen - C3.e, C3.f); Q.push_back(t);
}
// a unit sphere, made once: rings of points with their normals
struct UnitSphere { int st, sl; std::vector<V3> p; };
static const UnitSphere &sphereT(int st, int sl) {
  static std::map<int, UnitSphere> M; int key = st * 100 + sl; auto it = M.find(key); if (it != M.end()) return it->second;
  UnitSphere S; S.st = st; S.sl = sl;
  for (int i = 0; i <= st; i++) { double v = PI * i / st, z = std::cos(v), r = std::sin(v); for (int j = 0; j <= sl; j++) { double u = 2 * PI * j / sl; S.p.push_back({r * std::cos(u), r * std::sin(u), z}); } }
  return M[key] = S;
}
// an ellipsoid: centre c in frame m, radii (along the frame's x, y, z)
static void blob(const M3 &m, V3 c, V3 r, Col col, int st = 5, int sl = 8) {
  st = std::max(3, (int)std::lround((st - 1) * (.4 + .6 * g_lod))); sl = std::max(5, (int)std::lround((sl - 2) * g_lod));
  const UnitSphere &S = sphereT(st, sl); V3 o = m.ap(c);
  auto P = [&](int i, int j) { const V3 &q = S.p[i * (S.sl + 1) + j]; return o + m.X * (q.x * r.x) + m.Y * (q.y * r.y) + m.Z * (q.z * r.z); };
  auto N = [&](int i, int j) { const V3 &q = S.p[i * (S.sl + 1) + j]; return norm(m.X * (q.x / r.x) + m.Y * (q.y / r.y) + m.Z * (q.z / r.z)); };
  for (int i = 0; i < S.st; i++) for (int j = 0; j < S.sl; j++) {
    V3 a = P(i, j), b = P(i + 1, j), c2 = P(i + 1, j + 1), d = P(i, j + 1); V3 na = N(i, j), nb = N(i + 1, j), nc = N(i + 1, j + 1), nd = N(i, j + 1);
    if (i > 0) stri(a, c2, b, na, nc, nb, col);   // (wound so the normals face out)
    if (i < S.st - 1) stri(a, d, c2, na, nd, nc, col);
  }
}
static void ball(V3 c, double r, Col col, int st = 4, int sl = 7) { M3 m = frameAt(c.x, c.y, c.z, 0); blob(m, {0, 0, 0}, {r, r, r}, col, st, sl); }
// a tapered tube from a (radius ra) to b (radius rb), with round ends
static void tube(V3 a, V3 b, double ra, double rb, Col col, int n = 7, bool caps = true) {
  n = std::max(3, (int)std::lround((n - 1) * g_lod));
  V3 d = b - a; double L = std::sqrt(dot(d, d)); if (L < 1e-4) return; V3 z = d * (1 / L);
  V3 x = std::fabs(z.z) < .9 ? norm(cross(z, {0, 0, 1})) : norm(cross(z, {1, 0, 0})), y = cross(z, x);
  double sl = (ra - rb) / L;   // the side's slope: normals tilt toward the thin end
  for (int i = 0; i < n; i++) { double u0 = 2 * PI * i / n, u1 = 2 * PI * (i + 1) / n;
    V3 r0 = x * std::cos(u0) + y * std::sin(u0), r1 = x * std::cos(u1) + y * std::sin(u1), n0 = norm(r0 + z * sl), n1 = norm(r1 + z * sl);
    V3 A0 = a + r0 * ra, A1 = a + r1 * ra, B0 = b + r0 * rb, B1 = b + r1 * rb;
    stri(A0, A1, B1, n0, n1, n1, col); stri(A0, B1, B0, n0, n1, n0, col); }
  if (caps) { ball(a, ra, col, 4, n); ball(b, rb, col, 4, n); }   // (blob trims these to 3 x n-2)
}
// a box with its edges softened by the shading (pads, blockers, skates)
static void rbox(const M3 &m, V3 c, V3 h, Col col, double soft = .9) {
  static const int F[6][4] = {{4, 6, 7, 5}, {0, 1, 3, 2}, {2, 3, 7, 6}, {0, 4, 5, 1}, {1, 5, 7, 3}, {0, 2, 6, 4}};
  V3 P[8], Nc[8]; int i = 0;
  for (int sx = -1; sx <= 1; sx += 2) for (int sy = -1; sy <= 1; sy += 2) for (int sz = -1; sz <= 1; sz += 2) { P[i] = m.ap({c.x + sx * h.x, c.y + sy * h.y, c.z + sz * h.z}); Nc[i] = norm(m.X * sx + m.Y * sy + m.Z * sz); i++; }
  const V3 Fn[6] = {m.X, m.X * -1, m.Y, m.Y * -1, m.Z, m.Z * -1};
  for (int f = 0; f < 6; f++) { V3 n[4]; for (int k = 0; k < 4; k++) n[k] = norm(Fn[f] + Nc[F[f][k]] * soft);
    stri(P[F[f][0]], P[F[f][1]], P[F[f][2]], n[0], n[1], n[2], col); stri(P[F[f][0]], P[F[f][2]], P[F[f][3]], n[0], n[2], n[3], col); }
}

// ---------------------------------------------------------------- nets: NHL shape (posts, crossbar, the rounded base hoop, mesh)
// ---------------------------------------------------------------- lofted surfaces: rings swept along a path
// each ring: centre c, axes u (radius a) and v (radius b), a superellipse profile (n = 2 round, higher = boxier),
// and the colour of the band from this ring to the next. Smooth normals from the grid itself.
struct Ring { V3 c, u, v; double a, b, n; Col col; };
static void loft(const std::vector<Ring> &R, int seg, bool capA, bool capB, const std::function<Col(int, int, Col)> &colf = nullptr) {
  int nr = (int)R.size(); if (nr < 2) return;
  static std::vector<V3> P, N; P.resize(nr * seg); N.resize(nr * seg);
  static std::map<int, std::vector<double>> tab;   // the superellipse profile (x, y per segment) made once per shape
  for (int i = 0; i < nr; i++) { int key = seg * 1000 + (int)std::lround(R[i].n * 100); auto it = tab.find(key);
    if (it == tab.end()) { std::vector<double> t2(seg * 2); double e = 2 / R[i].n;
      for (int j = 0; j < seg; j++) { double t = 2 * PI * j / seg, cs = std::cos(t), sn = std::sin(t); t2[j * 2] = (cs < 0 ? -1 : 1) * std::pow(std::fabs(cs), e); t2[j * 2 + 1] = (sn < 0 ? -1 : 1) * std::pow(std::fabs(sn), e); }
      it = tab.emplace(key, t2).first; }
    const double *pr = it->second.data();
    for (int j = 0; j < seg; j++) P[i * seg + j] = R[i].c + R[i].u * (pr[j * 2] * R[i].a) + R[i].v * (pr[j * 2 + 1] * R[i].b); }
  for (int i = 0; i < nr; i++) for (int j = 0; j < seg; j++) {
    V3 tj = P[i * seg + (j + 1) % seg] - P[i * seg + (j + seg - 1) % seg], ti = P[std::min(nr - 1, i + 1) * seg + j] - P[std::max(0, i - 1) * seg + j];
    V3 n = norm(cross(tj, ti)); if (dot(n, P[i * seg + j] - R[i].c) < 0) n = n * -1; N[i * seg + j] = n; }
  for (int i = 0; i + 1 < nr; i++) for (int j = 0; j < seg; j++) {
    int a = i * seg + j, b = i * seg + (j + 1) % seg, c = (i + 1) * seg + (j + 1) % seg, d = (i + 1) * seg + j;
    Col col = colf ? colf(i, j, R[i].col) : R[i].col;
    stri(P[a], P[b], P[c], N[a], N[b], N[c], col); stri(P[a], P[c], P[d], N[a], N[c], N[d], col); }
  auto cap = [&](int i, double sgn) { V3 ax = norm(R[std::min(nr - 1, i + (sgn > 0 ? 0 : 1))].c - R[std::max(0, i - (sgn > 0 ? 1 : 0))].c) * sgn, ctr = R[i].c + ax * (std::min(R[i].a, R[i].b) * .35);
    for (int j = 0; j < seg; j++) { int a = i * seg + j, b = i * seg + (j + 1) % seg; stri(P[a], P[b], ctr, N[a], N[b], ax, R[i].col); } };
  if (capA) cap(0, -1); if (capB) cap(nr - 1, 1);
}
static inline V3 lerp3(V3 a, V3 b, double t) { return a + (b - a) * t; }
// two axes across a direction (for round sections along it)
static void across(V3 d, V3 hint, V3 &u, V3 &v) { u = norm(hint - d * dot(hint, d)); if (dot(u, u) < .5) u = norm(cross(d, {0, 0, 1})); v = norm(cross(d, u)); }
// a limb section along a path: radii at each point, colours per band
static void limbLoft(const std::vector<V3> &pts, const std::vector<double> &rad, const std::vector<Col> &cols, V3 hint, int seg, bool capA, bool capB) {
  std::vector<Ring> R; seg = std::max(5, (int)std::lround(seg * g_lod));
  for (size_t i = 0; i < pts.size(); i++) { V3 d = norm(pts[std::min(pts.size() - 1, i + 1)] - pts[i > 0 ? i - 1 : 0]); V3 u, v; across(d, hint, u, v);
    R.push_back({pts[i], u, v, rad[i], rad[i], 2, cols[std::min(i, cols.size() - 1)]}); }
  loft(R, seg, capA, capB);
}

static void drawNetGeo(int side) {
  // an NHL-style net: red posts and crossbar; a shallow white top shelf curving back from the crossbar; a deep
  // rounded base frame wrapped in thick white padding; ONE thick padded centre support from the back of the top
  // shelf down to the back of the base; the mesh runs right up to the posts and the crossbar
  const double gx = defendX(side), d = -tdir(side), cy = RK.cy, hw = RK.post, h = (PZ + .2) * VZ, dp = RK.netD * 1.25, r = .2;
  Col red = hex("#d42020"), white = hex("#eef2f7"), padC = hex("#e7ebf1"), mesh = rgba(236, 240, 246, .22), cord = hex("#eef2f7");
  objAt(gx + d * dp * .5, cy, 1.5);
  // the frame paths: the base sweeps well back (a rounded "D"), the top shelf is about half as deep
  const int N = 28; std::vector<V3> base, top, bn;
  // both frames are the same rounded "D" (a superellipse by angle): flat sides running straight back from the
  // posts, a rounded back. They start exactly at the posts, so the side mesh closes against them
  auto se = [](double v) { return (v < 0 ? -1 : 1) * std::pow(std::fabs(v), 2 / 3.2); };
  for (int i = 0; i <= N; i++) { double a = -PI / 2 + PI * i / N, cx = i == 0 || i == N ? 0 : se(std::cos(a)), sy = i == 0 ? -1 : i == N ? 1 : se(std::sin(a));
    base.push_back({gx + d * dp * cx, cy + sy * hw, .3}); top.push_back({gx + d * dp * .46 * cx, cy + sy * hw, h - .05}); }
  for (int i = 0; i <= N; i++) { V3 tg = base[std::min(N, i + 1)] - base[std::max(0, i - 1)]; V3 o = norm(cross(tg, {0, 0, 1})); if (dot(o, V3{d, 0, 0} + V3{0, base[i].y - cy, 0} * .2) < 0) o = o * -1; bn.push_back(o); }
  // the padded base: a soft white cushion following the frame on the ice
  { std::vector<Ring> R; for (int i = 0; i <= N; i++) R.push_back({base[i] + V3{0, 0, -.02}, bn[i], {0, 0, 1}, .36, .32, 2.6, padC}); loft(R, 8, true, true); }
  // the top shelf tube and the single centre support (thick and padded), leaning from the shelf's back to the base's back
  for (int i = 0; i < N; i++) tube(top[i], top[i + 1], r * .55, r * .55, white, 6, false);
  { V3 tc = top[N / 2], bc = base[N / 2] + V3{-d * .3, 0, .2}; tube(tc, bc, .3, .3, white, 8, false); blob(frameAt(tc.x, tc.y, tc.z, 0), {0, 0, 0}, {.3, .3, .3}, white, 4, 8); }
  // a water bottle on the top shelf
  { V3 wb = top[N / 2 - 6] + V3{-d * .4, 0, .25}; M3 m = frameAt(wb.x, wb.y, wb.z, PI / 2 + .3); rbox(m, {0, 0, 0}, {.5, .18, .18}, hex("#dc2626"), .9); rbox(m, {.52, 0, 0}, {.08, .1, .1}, white, .6); }
  // posts and crossbar (red, rounded), with white base plates where they meet the padding
  V3 pl = {gx, cy - hw, 0}, pr = {gx, cy + hw, 0};
  tube(pl, pl + V3{0, 0, h}, r, r, red, 10); tube(pr, pr + V3{0, 0, h}, r, r, red, 10); tube(pl + V3{0, 0, h}, pr + V3{0, 0, h}, r, r, red, 10, false);
  for (V3 p : {pl, pr}) blob(frameAt(p.x, p.y, .5, 0), {0, 0, 0}, {.3, .3, .1}, white, 3, 8);
  // the mesh: see-through panels with a fine grid of cords (thin flat strips, two triangles each)
  auto cordS = [&](V3 a, V3 b, V3 n) { V3 w = cross(b - a, n); double l = std::sqrt(dot(w, w)); if (l < 1e-6) return; w = w * (.034 / l); quad(a - w, b - w, b + w, a + w, cord, nullptr, 1, false); };
  V3 cb = {gx, cy, 0};
  for (int i = 0; i < N; i++) quad(base[i] + V3{0, 0, .3}, base[i + 1] + V3{0, 0, .3}, top[i + 1], top[i], mesh, nullptr, 1, false);
  auto cbar = [&](int i) { return V3{gx, top[i].y, h}; };   // the point on the crossbar straight in front of top[i]
  for (int i = 0; i < N; i++) quad(cbar(i), cbar(i + 1), top[i + 1], top[i], mesh, nullptr, 1, false);
  const int RW = 9;   // back wall: rows around, columns up
  for (int i = 0; i <= N; i++) cordS(base[i] + V3{0, 0, .3}, top[i], bn[i]);
  for (int k = 1; k <= RW; k++) { double z = (double)k / (RW + 1); for (int i = 0; i < N; i++) {
    V3 a = lerp3(base[i] + V3{0, 0, .3}, top[i], z), b = lerp3(base[i + 1] + V3{0, 0, .3}, top[i + 1], z); cordS(a, b, bn[i]); } }
  for (int i = 1; i < N; i++) cordS(cbar(i), top[i], {0, 0, 1});   // the roof
  for (int k = 1; k <= 3; k++) { double z = k / 4.0; for (int i = 0; i < N; i++) {
    V3 a = lerp3(cbar(i), top[i], z), b = lerp3(cbar(i + 1), top[i + 1], z); cordS(a, b, {0, 0, 1}); } }
  (void)cb;
}
// the net never changes: on the GPU path it's built once (every face kept) and copied in each frame
static void drawNet(int side) {
  const double gx = defendX(side), d = -tdir(side), cy = RK.cy, dp = RK.netD * 1.25;
  if (!g_gpu) drawNetGeo(side);
  else {
    static std::vector<V3c> C[2][3]; static std::vector<ATri> CA[2]; static bool built[2] = {false, false};
    if (!built[side]) { size_t b0 = GB[0].size(), b2 = GB[2].size(), ba = GA.size(); bool kr = g_refl; g_keep = true; g_refl = true; drawNetGeo(side); g_keep = false; g_refl = kr;
      C[side][0].assign(GB[0].begin() + b0, GB[0].end()); C[side][2].assign(GB[2].begin() + b2, GB[2].end()); CA[side].assign(GA.begin() + ba, GA.end());
      GB[0].resize(b0); GB[2].resize(b2); GA.resize(ba); built[side] = true; }
    appendClip(GB[0], C[side][0]); appendClip(GB[2], C[side][2]);
    double dd = dot(V3{gx + d * dp * .5, cy, 2} - C3.e, C3.f); for (ATri t : CA[side]) { t.d = (float)dd; GA.push_back(t); }
  }
  // a goal: the bulge
  const NetBulge &nb = SK->nb[side == 0 ? 0 : 1]; if (nb.on) { double k = std::max(0.0, 1 - nb.t / .6); blob(frameAt(gx + d * (dp + .5 * k), cy + nb.y, 1.6, 0), {0, 0, 0}, {.6 * k + .05, 1.3, 1.2}, rgba(240, 244, 250, .5)); }
}

// ---------------------------------------------------------------- people: NHL Hitz-style chunky players
static const double SCL = 1.6, GSCL = 1.75;
struct Kit { Col jersey, stripe, pants, helm, skin, sock, glove; };
static Kit kitOf(int team) { Team &T = SK->T[team]; Kit k; k.jersey = T.col; k.stripe = T.stripe; k.pants = shade(T.col, -.62); k.helm = shade(T.col, -.12);
  k.skin = hex("#e0a878"); k.sock = T.col; k.glove = shade(T.col, -.3); return k; }
static void skate(const M3 &base, V3 ankle, double s) {
  M3 f = base; f.O = ankle; rbox(f, {.18 * s, 0, -.14 * s}, {.34 * s, .13 * s, .15 * s}, hex("#1f2937"));
  rbox(f, {.2 * s, 0, -.33 * s}, {.38 * s, .03 * s, .04 * s}, hex("#cbd5e1"), .5);
}
// a skater: the pose comes from what he's doing (stride, lean, wind-up, poke, spin, falling, blocking)
static void drawSkater3(Skater *p) {
  Kit K = kitOf(p->team); K.skin = p->skin;
  double sp = hyp(p->vx, p->vy), st = std::sin(p->ph * 3) * std::min(1.0, sp / 12);
  double yaw = p->ang; if (p->spin > 0) yaw += (1 - p->spin / SPIN_T) * 2 * PI;
  // carving: he leans into a turn (how much of his speed is sideways to where he faces)
  double carve = clamp((-std::sin(p->ang) * p->vx + std::cos(p->ang) * p->vy) / 26, -.32, .32);
  double lean = .3 + (p->dash > 0 ? .3 : 0) + std::min(.12, sp / 200);
  M3 base = frameAt(p->x, p->y, 0, yaw); if (p->block <= 0 && p->stun <= 0 && p->spin <= 0) base = roll(base, -carve);
  objAt(p->x, p->y, 2);
  if (p->block > 0) base = roll(base, (std::cos(p->blkA) > 0 ? 1 : -1) * 1.35 * std::min(1.0, p->block / .25));
  else if (p->stun > 0) base = roll(base, (p->team ? 1 : -1) * (p->kd ? 1.35 : .45));
  double s = SCL; bool lh = p->sh != 'R'; double side = lh ? 1 : -1;   // a left shot carries the stick on his left
  // legs: thighs (pants) and shins (socks with a stripe), knees bent, hips swinging with the stride
  for (int k = -1; k <= 1; k += 2) {
    double sw = st * .55 * k;
    M3 hip = pitch(moveTo(base, {0, k * .36 * s, 2.15 * s}), sw);
    V3 H = hip.ap({0, 0, 0}), Kn = hip.ap({.38 * s, k * .06 * s, -.98 * s});
    M3 kf = pitch(moveTo(hip, {.38 * s, k * .06 * s, -.98 * s}), -std::fabs(sw) * .5 - .5);
    V3 A = kf.ap({0, 0, -.98 * s});
    tube(H, Kn, .32 * s, .25 * s, K.pants);
    tube(Kn, A, .22 * s, .15 * s, K.sock, 8, false);
    tube(Kn + (A - Kn) * .3, Kn + (A - Kn) * .45, .225 * s, .2 * s, K.stripe, 8, false);
    skate(base, A, s);
  }
  // body: breezers, a broad jersey with a stripe at the hem, big shoulder pads
  M3 tor = pitch(moveTo(base, {0, 0, 2.2 * s}), lean);
  // (athletic NHL proportions: narrower through the waist and shoulders than the old Hitz blocks)
  blob(tor, {0, 0, .2 * s}, {.46 * s, .6 * s, .44 * s}, K.pants);
  blob(tor, {0, 0, 1.05 * s}, {.44 * s, .66 * s, .74 * s}, K.jersey, 7, 12);
  blob(tor, {0, 0, .55 * s}, {.47 * s, .68 * s, .14 * s}, K.stripe, 3, 12);
  V3 shL = tor.ap({0, .6 * s, 1.55 * s}), shR = tor.ap({0, -.6 * s, 1.55 * s});
  ball(shL, .27 * s, K.jersey); ball(shR, .27 * s, K.jersey);
  if (p->star) blob(tor, {.5 * s, 0, 1.25 * s}, {.04 * s, .16 * s, .16 * s}, hex("#facc15"), 3, 6);
  // head: neck, the face, the helmet and its visor
  M3 neck = moveTo(tor, {0, 0, 1.78 * s});
  tube(neck.ap({0, 0, 0}), neck.ap({0, 0, .25 * s}), .15 * s, .15 * s, K.skin, 6, false);
  blob(neck, {.06 * s, 0, .5 * s}, {.3 * s, .26 * s, .3 * s}, K.skin, 5, 8);
  blob(neck, {-.04 * s, 0, .6 * s}, {.36 * s, .32 * s, .3 * s}, K.helm, 5, 10);
  rbox(neck, {.3 * s, 0, .55 * s}, {.04 * s, .24 * s, .07 * s}, hex("#334155"), .6);
  // the stick: hands low on his stick side, the blade on the ice ahead (raised on a wind-up, out on a poke)
  double wind = p->wind > 0 ? p->wind : 0, poke = p->pokeA > 0 ? std::sin(PI * (1 - p->pokeA / .28)) : 0;
  V3 fwd = base.X, lat = base.Y * side;
  V3 top = tor.ap({.25 * s, side * .55 * s, .95 * s}), hand = tor.ap({.65 * s, side * .25 * s, .35 * s});
  V3 blade = V3{p->x, p->y, 0} + fwd * ((2.6 + poke * 1.4) * s) + lat * (.9 * s); blade.z = .1;
  if (wind > 0) { blade = V3{p->x, p->y, 0} + fwd * (-1.2 * s) + lat * (1.6 * s); blade.z = 2.4 * wind * s; }
  if (p->block > 0 || (p->stun > 0 && p->kd)) blade = hand + fwd * 2 + V3{0, 0, -1};
  V3 sd = norm(blade - top), handLow = top + (blade - top) * .45;
  // arms: shoulder - elbow - glove, one hand at the top of the stick, the other halfway down
  auto arm = [&](V3 sh, V3 gl, double out) { V3 el = (sh + gl) * .5 + lat * (out * s) + V3{0, 0, -.15 * s};
    tube(sh, el, .24 * s, .2 * s, K.jersey, 7, false); tube(el, gl, .2 * s, .17 * s, K.jersey, 7, false);
    tube(el + (gl - el) * .5, el + (gl - el) * .66, .205 * s, .185 * s, K.stripe, 7, false); ball(gl, .25 * s, K.glove, 4, 8); };
  arm(lh ? shL : shR, top, .2); arm(lh ? shR : shL, handLow, -.25);
  tube(top, blade, .05 * s, .05 * s, hex("#1f2937"), 5, false);                                        // a carbon stick
  tube(top - sd * (.25 * s), top + sd * (.2 * s), .06 * s, .06 * s, hex("#e5e7eb"), 5, false);        // knob tape
  tube(blade - sd * (.9 * s), blade, .055 * s, .055 * s, hex("#111827"), 5, false);
  { V3 bd = norm(V3{fwd.x, fwd.y, 0}); M3 m = frameAt(blade.x, blade.y, std::max(.08, (double)blade.z), std::atan2(bd.y, bd.x) + side * .35); rbox(m, {.3 * s, 0, .03}, {.4 * s, .045 * s, .1 * s}, hex("#111827"), .5); }
}
static void shadow(double x, double y, double r) { iceDisc(x, y, r, rgba(15, 23, 42, .22), 12, .04); }
// ---------------------------------------------------------------- the goalie's body: one pose for the picture AND the physics
// Every joint of the goalie (pads, legs, torso, arms, trapper, blocker, stick) is worked out here once. drawGoalie3 draws
// it and skGoalieTouch tests the puck against the same shapes, so what you see is exactly what stops the puck: a gap you
// can see between the glove and the body, or between the pads, is a gap the puck can go through.
// The frame is mirrored (local +y is the goalie's LEFT: he catches left-handed, the glove on the same side the sim uses).
struct GBody {
  M3 base, base0; double s = GSCL, k = 1, low = 0, drop = 0, split = 0, flat = 0, lay = 0, aty = 0, atz = 0, side = 1; int sj = 1; bool aim = false, useHand = false, useG = true; Pose P = GP_NONE;
  V3 FX, UP; V3 ank[2], kn[2], hip[2], D[2], F[2], Wd[2], bot[2], top[2];
  V3 pel, neck, sp, SD, SF, SW, hc; V3 shL, shR, gH, bH, elG, elB; M3 gm, bm;
  V3 heel, S, Bd, Hh; double HL = 0, pl = 0, shEnd = 0;
};
static V3 elbowOf(const GBody &B, V3 sh, V3 hd, double sgn) {   // two-bone arm: fixed lengths, the elbow bends down and out
  const double U = 1.0 * B.s; V3 dv = hd - sh; double dl = std::max(1e-3, std::sqrt(dot(dv, dv))); V3 dn = dv * (1 / dl); dl = std::min(dl, 1.98 * U);
  V3 pole = B.UP * -1.0 + B.base.Y * (sgn * .7) - B.FX * .2, pp = pole - dn * dot(pole, dn); pp = dot(pp, pp) > 1e-6 ? norm(pp) : B.UP * -1.0;
  return sh + dn * (dl * .5) + pp * std::sqrt(std::max(0.0, U * U - dl * dl * .25));
}
static void gBody(Goalie &g, int ti, GBody &B) {
  const double s = GSCL, yaw = ti == 0 ? 0 : PI; B.s = s;
  M3 base = frameAt(g.x, g.y, 0, yaw); base.Y = base.Y * -1.0;                       // mirrored: +y is his glove (left) hand
  Pose P = g.hasAn ? g.an.p : GP_NONE; double side = g.hasAn ? g.an.s : 1; if (ti == 0) side = -side;   // the puck's side, in his frame
  double k = 1; if (g.hasAn) { double t = g.an.t; k = t < g.an.i ? t / g.an.i : t < g.an.i + g.an.h ? 1 : std::max(0.0, 1 - (t - g.an.i - g.an.h) / g.an.o); }
#ifdef HOST_BUILD
  if (const char *fp = getenv("CHL_GPOSE")) { P = fp[0] == 'l' ? GP_LO : fp[0] == 'p' ? GP_POKE : fp[0] == 'k' ? GP_KICK : GP_NONE; k = 1; }   // test shots
#endif
  // the save reaches for where he reads the puck going (aimY: offset from him, aimZ: height), within what a body can do:
  // an arm only reaches so far, so a low shot drops him to his knees (butterfly) and a low shot wide of him kicks that
  // pad out along the ice (half splits) with the glove or blocker down beside it; a shot wide and high leans him over
  M3 base0 = base;
  bool aim = g.hasAn && SK->gt - g.aimT < 1.2 && P != GP_POKE && P != GP_COVER && P != GP_LOOK && P != GP_NONE;
  double aty = 0, atz = 0; if (aim) { aty = dot(V3{0, g.aimWY - g.y, 0}, base.Y) / s; atz = g.aimZ / s; }
#ifdef HOST_BUILD
  if (const char *fa = getenv("CHL_GAIM")) { double oy = 0, hh = 0; if (sscanf(fa, "%lf,%lf", &oy, &hh) == 2) { aim = true; k = 1; if (P == GP_NONE) P = GP_HI; aty = oy / s; atz = (std::min(1.3, std::max(0.0, hh)) * PZ * .94 + .1) * 1.7 / s; } }   // test shots
#endif
  int sj = aty > 0 ? 1 : -1;
  double drop = aim ? clamp((2.15 - atz) / 1.15, 0, 1) * k : 0;
  double split = aim ? clamp((std::fabs(aty) - 1.2) / 1.2, 0, 1) * drop : 0;
  double low = std::max((P == GP_LO || P == GP_KICK) ? k : 0.0, drop);
#ifdef HOST_BUILD
  if (const char *e = getenv("CHL_GHUG")) { g.hugK = atof(e); g.hugS = 1; }   // test shots: sealing the post
#endif
  { double hug = aim ? 0 : g.hugK; if (hug > .01) { sj = dot(V3{0, g.hugS, 0}, base.Y) > 0 ? 1 : -1; low = std::max(low, .85 * hug); split = std::max(split, .7 * hug); }   // sealing the post
    low = std::max(low, .9 * g.slideK * (aim ? .5 : 1)); }                                                                                                  // a butterfly slide
  if (P == GP_DIVE) base = roll(base, -side * 1.15 * k);
  else if (aim) { double lean = clamp((std::fabs(aty) - 2.3) / 1.6, 0, 1) * (.45 - .25 * drop) * k; if (lean > 0) base = roll(base, -sj * lean); }
  double up = (P == GP_HI || P == GP_BODY) && !aim ? k : 0, gUp = side > 0 ? up : 0, bUp = side < 0 ? up : 0;
  auto L = [&](V3 p) { return base.ap(p * s); };
  auto J = [&](V3 a, V3 b) { return L(lerp3(a, b, low)); };
  V3 FX = base.X, UP = base.Z;
  B.base = base; B.base0 = base0; B.k = k; B.low = low; B.drop = drop; B.split = split; B.aty = aty; B.atz = atz; B.sj = sj; B.aim = aim; B.P = P; B.side = side; B.FX = FX; B.UP = UP;
  for (int li = 0; li < 2; li++) { int j = li ? 1 : -1;
    double sx = j == sj ? split : 0;   // this leg kicks out along the ice
    V3 ank = J({0, j * .8, .32}, {-.25 + .4 * sx, j * (1.85 + 1.05 * sx), .3}), kn = J({.55, j * .58, 1.5}, {.48 - .08 * sx, j * (.5 + .8 * sx), .5 - .08 * sx}), hip = J({-.28, j * .38, 2.45}, {-.12, j * .36, 1.3});
    V3 D = norm(kn - ank), F = norm(FX - D * dot(FX, D)), Wd = norm(cross(D, F)); if (dot(Wd, base.Y * (double)j) < 0) Wd = Wd * -1;
    B.ank[li] = ank; B.kn[li] = kn; B.hip[li] = hip; B.D[li] = D; B.F[li] = F; B.Wd[li] = Wd; B.bot[li] = ank - D * (.28 * s); B.top[li] = kn + D * (.75 * s); }
  V3 pel = J({-.3, 0, 2.55}, {-.12, 0, 1.4}), neck = J({.45, 0, 4.3}, {.22, 0, 3.15});
  V3 sp = neck - pel; V3 SD = norm(sp), SF = norm(FX - SD * dot(FX, SD)), SW = base.Y;
  B.pel = pel; B.neck = neck; B.sp = sp; B.SD = SD; B.SF = SF; B.SW = SW; B.hc = pel + sp * 1.0 + SD * (.48 * s) + SF * (.12 * s);
  V3 shL = pel + sp * .86 + SW * (.92 * s) - SF * (.05 * s), shR = pel + sp * .86 - SW * (.92 * s) - SF * (.05 * s);
  V3 gH = J({1.0, 1.35, 3.0 + gUp * 1.35}, {.95, 1.42, 2.15 + gUp * 1.3}), bH = J({.98, -1.15, 2.55 + bUp * 1.25}, {.92, -1.2, 1.75 + bUp * 1.2});
  // the stick goes flat (blocker hand down by the ice) to seal the five-hole, on a poke, or to play / pass the puck
  double flat = std::max({P == GP_LO ? k : 0.0, P == GP_POKE ? k : 0.0, g.fum > SK->gt ? std::min(1.0, (g.fum - SK->gt) / .25) : 0.0});
  // a low centred shot is the pads' and the stick's job: the paddle goes down to seal the five-hole
  bool useHand = aim && !(drop > .5 && std::fabs(aty) < .7), useG = aty > -.35;
  if (aim && (!useHand || useG)) flat = std::max(flat, drop);
  bH = lerp3(bH, L(lerp3(V3{1.15, -.95, .62}, V3{1.0, -1.05, .5}, low)), flat);
  if (useHand) {   // the reaching hand goes to the puck, no further than the arm allows
    V3 sh = useG ? shL : shR, tw = base0.ap(V3{1.2, aty, std::max(.3, atz)} * s), dv = tw - sh; double dl = std::sqrt(dot(dv, dv)), R = 1.92 * s;
    if (dl > R) tw = sh + dv * (R / dl);
    if (useG) gH = lerp3(gH, tw, k); else bH = lerp3(bH, tw, k); }
  B.shL = shL; B.shR = shR; B.gH = gH; B.bH = bH; B.flat = flat; B.useHand = useHand; B.useG = useG;
  B.elG = elbowOf(B, shL, gH, 1); B.elB = elbowOf(B, shR, bH, -1);
  { M3 gm = yawFrame(gH, yaw + .3); gm = pitch(gm, -.15); gm.Y = gm.Y * -1.0; B.gm = gm;
    M3 bm = yawFrame(bH, yaw - .22); bm = pitch(bm, -.1); bm.Y = bm.Y * -1.0; B.bm = bm; }
  // the stick: a real goalie stick has a fixed length. The blocker holds it right at the top of the paddle, the paddle
  // runs down to the heel, the shaft carries on well above the hand (to about the shoulder), and the long flat blade lies
  // on the ice pointing to the glove side. A low blocker save takes the stick down with it, paddle along the ice in
  // front of the pad; a high blocker lifts the blade off the ice
  { V3 hand = bH; const double HL = 2.8 * s;
    double bLow = useHand && !useG ? clamp((2.2 - dot(hand - base0.O, UP) / s) / 1.6, 0, 1) * k : 0;
    double lay = std::max(flat, bLow);
    V3 ideal = L(lerp3(lerp3(V3{1.5, -.12, 0}, V3{1.5, -.2, 0}, low), V3{2.1, .25, 0}, flat));
    if (g.stkOff > SK->gt) ideal = L(V3{1.2, -1.3, 0});   // caught with his stick out of position (a misread five-hole shot)
    { V3 hg = {hand.x, hand.y, 0}; V3 lowH = hg + norm(V3{FX.x, FX.y, 0}) * (1.1 * s) + norm(V3{base.Y.x, base.Y.y, 0}) * (.6 * s); ideal = lerp3(ideal, lowH, bLow); }
    V3 heel = hand + norm(ideal - hand) * HL;
    if (heel.z < .03 * s) { double hz = std::max(0.0, hand.z - .03 * s); V3 hd = {ideal.x - hand.x, ideal.y - hand.y, 0}; double hl = std::sqrt(dot(hd, hd));
      hd = hl > 1e-4 ? hd * (1 / hl) : norm(V3{FX.x, FX.y, 0}); heel = V3{hand.x, hand.y, .03 * s} + hd * std::sqrt(std::max(0.0, HL * HL - hz * hz)); }
    V3 S = norm(hand - heel), Bd = norm(base.Y * (1 - .4 * lay) + base.X * (.12 + .68 * lay));
    V3 hp = cross(UP, Bd); if (dot(hp, S) < 0) hp = hp * -1;
    B.heel = heel; B.S = S; B.Bd = Bd; B.Hh = norm(lerp3(UP, hp, lay)); B.lay = lay; B.HL = HL; B.pl = HL - .12 * s; B.shEnd = HL + 1.65 * s; }
}

// ---------------------------------------------------------------- the puck against the goalie (physics)
static bool capHit(V3 p, V3 a, V3 b, double rad, V3 &n) {
  V3 ab = b - a; double t = clamp(dot(p - a, ab) / std::max(1e-9, dot(ab, ab)), 0, 1); V3 d = p - (a + ab * t); double l2 = dot(d, d);
  if (l2 > rad * rad) return false; n = l2 > 1e-9 ? d * (1 / std::sqrt(l2)) : V3{1, 0, 0}; return true;
}
static bool boxHit(V3 p, V3 c, V3 ex, V3 ey, V3 ez, V3 h, double r, V3 &n) {
  V3 d = p - c; double a = dot(d, ex), b = dot(d, ey), e = dot(d, ez);
  if (std::fabs(a) > h.x + r || std::fabs(b) > h.y + r || std::fabs(e) > h.z + r) return false;
  double qa = std::fabs(a) / (h.x + r), qb = std::fabs(b) / (h.y + r), qe = std::fabs(e) / (h.z + r);
  n = qa >= qb && qa >= qe ? ex * (a < 0 ? -1.0 : 1.0) : qb >= qe ? ey * (b < 0 ? -1.0 : 1.0) : ez * (e < 0 ? -1.0 : 1.0); return true;
}
static bool ellHit(V3 p, const M3 &m, V3 c, V3 rr, double r, V3 &n) {
  V3 d = p - m.ap(c); double a = dot(d, m.X) / (rr.x + r), b = dot(d, m.Y) / (rr.y + r), e = dot(d, m.Z) / (rr.z + r);
  if (a * a + b * b + e * e > 1) return false; n = norm(m.X * (a / (rr.x + r)) + m.Y * (b / (rr.y + r)) + m.Z * (e / (rr.z + r))); return true;
}
// which part of him (if any) the puck at (x, y, height zp, radius r) is touching, and the surface normal there
// the body is worked out once per frame and shared by the physics and the picture
static const GBody &gBodyC(Goalie &g, int ti) {
  static GBody C[2]; static double ct[2] = {-1, -1}; static const Goalie *cg[2] = {nullptr, nullptr}; static const Game *cs[2] = {nullptr, nullptr};
  if (ct[ti] != SK->gt || cg[ti] != &g || cs[ti] != SK) { gBody(g, ti, C[ti]); ct[ti] = SK->gt; cg[ti] = &g; cs[ti] = SK; }
  return C[ti];
}
int skGoalieTouch(Goalie &g, double x, double y, double zp, double r, double *nrm, double *aux) {
  if (g.out) return -1;
  const GBody &B = gBodyC(g, g.team & 1); const double s = B.s; V3 p = {x, y, zp * VZ}, n = {0, 0, 1}; int part = -1;
  if (hyp(x - g.x, y - g.y) > 7.5 * s * .5 + 6) return -1;
  if (aux) *aux = 0;
  // the trapper: its big pocket and the cuff
  if (part < 0 && (ellHit(p, B.gm, {.28 * s, .12 * s, .22 * s}, {.26 * s, .46 * s, .56 * s}, r, n) || boxHit(p, B.gm.ap({-.05 * s, .02 * s, -.05 * s}), B.gm.X, B.gm.Y, B.gm.Z, {.32 * s, .2 * s, .16 * s}, r, n))) part = GT_GLOVE;
  // the blocker board and the hand behind it
  if (part < 0 && (boxHit(p, B.bm.ap({.14 * s, -.16 * s, .08 * s}), B.bm.X, B.bm.Y, B.bm.Z, {.08 * s, .36 * s, .5 * s}, r, n) || capHit(p, B.bH, B.elB, .24 * s + r, n))) part = GT_BLOCKER;
  // the stick: paddle and blade
  if (part < 0) { V3 by = norm(cross(B.Hh, B.Bd));
    if (capHit(p, B.heel + B.S * (.06 * s), B.heel + B.S * B.pl, .14 * s + r, n) || boxHit(p, B.heel + B.Bd * (.52 * s) + B.Hh * (.14 * s), B.Bd, by, B.Hh, {.6 * s, .05 * s, .15 * s}, r, n)) part = GT_STICK; }
  // the leg pads (the walls): face, depth and width along each shin, from the boot to the thigh rise
  for (int li = 0; li < 2 && part < 0; li++) { V3 a = B.bot[li], b = B.top[li], ax = b - a; double len = std::sqrt(dot(ax, ax)); V3 c = (a + b) * .5 + B.F[li] * (.24 * s);
    if (boxHit(p, c, B.F[li], B.Wd[li], ax * (1 / len), {.34 * s, .45 * s, len * .5 + .05 * s}, r, n)) { part = GT_PAD;
      if (aux) { V3 d = p - c; *aux = std::max(std::fabs(dot(d, B.Wd[li])) / (.45 * s), (dot(d, ax * (1 / len)) / (len * .5))); }   // near an edge: > .7
      if (dot(n, B.F[li]) < .5 && dot(n, B.FX) > -.2) n = norm(n + B.F[li]); } }
  if (part < 0 && capHit(p, B.hc, B.hc, .44 * s + r, n)) part = GT_HEAD;
  if (part < 0 && (capHit(p, B.shL, B.elG, .32 * s + r, n) || capHit(p, B.elG, B.gH, .28 * s + r, n) || capHit(p, B.shR, B.elB, .32 * s + r, n))) part = GT_ARM;
  if (part < 0) { double L2 = std::sqrt(dot(B.sp, B.sp)); V3 d = p - B.pel; double t = dot(d, B.SD); if (t > -.2 * L2 && t < .97 * L2) {
      V3 q = d - B.SD * t; double f = dot(q, B.SF), w = dot(q, B.SW), A = .6 * s + r, Bb = .88 * s + r; if ((f / A) * (f / A) + (w / Bb) * (w / Bb) <= 1) { part = GT_BODY; n = norm(B.SF * (f / (A * A)) + B.SW * (w / (Bb * Bb))); } } }
  for (int li = 0; li < 2 && part < 0; li++) if (capHit(p, B.hip[li], B.kn[li], .3 * s + r, n)) part = GT_LEG;
  if (part >= 0 && nrm) { nrm[0] = n.x; nrm[1] = n.y; nrm[2] = n.z / VZ; double l = std::sqrt(nrm[0] * nrm[0] + nrm[1] * nrm[1] + nrm[2] * nrm[2]); if (l > 1e-9) for (int i = 0; i < 3; i++) nrm[i] /= l; }
  return part;
}

// ---------------------------------------------------------------- the benches
// both benches on the far side, behind the boards either side of centre (home on the left), the players who are off
// the ice sitting on them: a little sway and fidget, leaning toward the play, and up on their feet with their arms in
// the air when their team scores
static void drawBench3() {
  double now = plat_now_ms() / 1000, yb = RK.Wd;
  Col wood = hex("#3b2f2a"), wall = hex("#1f2937"), floorC = hex("#111827");
  for (int ti = 0; ti < 2; ti++) {
    Team &T = SK->T[ti]; Kit K = kitOf(ti); double x0 = RK.L / 2 + (ti == 0 ? -40 : 10), len = 30;
    { // off screen (or behind the camera): skip it; on screen they're small, so low detail and no reflection
      V3 c = {x0 + len / 2, yb + 3, 3}; double dz = dot(c - C3.e, C3.f); if (dz < 2) continue;
      Pt a = sk3Proj(x0, yb + 3, 3), b = sk3Proj(x0 + len, yb + 3, 3); if (std::max(a.x, b.x) < -40 || std::min(a.x, b.x) > W + 40 || std::max(a.y, b.y) < -60 || std::min(a.y, b.y) > H + 60) continue; }
    g_lod = .5;
    objAt(x0 + len / 2, yb + 3, 2);
    quad({x0, yb + .4, .05}, {x0 + len, yb + .4, .05}, {x0 + len, yb + 6.5, .05}, {x0, yb + 6.5, .05}, floorC, nullptr);                  // the bench floor
    rbox(frameAt(x0 + len / 2, yb + 3.6, 0, 0), {0, 0, 1.25}, {len / 2, .9, 1.25}, wood, .4);                                                     // the seat
    rbox(frameAt(x0 + len / 2, yb + 5.4, 0, 0), {0, 0, 3.4}, {len / 2, .2, 3.4}, wall, .3);                                                     // the back wall
    rbox(frameAt(x0 + len / 2, yb + 5.2, 0, 0), {0, 0, 5.2}, {len / 2, .08, .45}, K.jersey, .3);                                              // a team-colour stripe
    int n = std::min(9, (int)T.bench.size()); bool cheer = SK->phase == PH_GOAL && SK->cel.team == ti;
    for (int k = 0; k < n; k++) {
      double ph = k * 1.93 + ti * .7, px = x0 + 2.2 + k * ((len - 4.4) / std::max(1, n - 1)), py = yb + 3.4;
      double bob = cheer ? std::fabs(std::sin(now * 7 + ph)) * .5 : 0, sway = std::sin(now * .9 + ph) * .12, lean = std::sin(now * .35 + ph * 2) * .1;
      double hz = (cheer ? 4.2 + bob : 2.6);                                   // the seat of the pants (standing up to cheer)
      M3 b = frameAt(px, py, 0, -PI / 2 + sway * .4); b = pitch(b, cheer ? -.05 : .25 + lean);
      V3 pel = {px, py, hz};
      // legs: seated (thighs forward to the boards, shins down) or standing
      for (int j = -1; j <= 1; j += 2) { V3 hip = pel + V3{j * .35, 0, 0}, kn = cheer ? hip + V3{0, -.1, -1.7} : hip + V3{j * .1, -1.5, -.1}, ft = cheer ? kn + V3{0, .1, -1.7} : kn + V3{0, -.2, -1.6};
        tube(hip, kn, .32, .28, K.pants, 5); tube(kn, ft, .26, .22, K.sock, 4, false); }
      M3 tor = frameAt(px, py, hz, -PI / 2 + sway * .4); tor = pitch(tor, cheer ? -.05 : .28 + lean);
      blob(tor, {0, 0, 1.1}, {.55, .75, .95}, K.jersey, 5, 9);
      V3 sh[2] = {tor.ap({0, .65, 1.75}), tor.ap({0, -.65, 1.75})}; V3 head = tor.ap({.05, 0, 2.55});
      ball(head, .42, K.helm);
      for (int j = 0; j < 2; j++) { V3 hand = cheer ? sh[j] + V3{(j ? -1 : 1) * .5, -.2, 1.8 + bob * .6} : tor.ap({.55, (j ? -.35 : .35), .9}) + V3{0, 0, std::sin(now * 1.7 + ph + j) * .05};
        tube(sh[j], hand, .22, .18, K.jersey, 4, false); }
    }
  }
}
// a goalie: the human model on the pose above (NHL Hitz colours): lofted pads, pants, jersey with hem and sleeve
// stripes, arms, the trapper and blocker, the mask with its cage, the stick
static void drawGoalie3(Goalie &g, int ti) {
  if (g.out) return; Kit K = kitOf(ti);
  const GBody &B = gBodyC(g, ti);
  const double s = GSCL, yaw = ti == 0 ? 0 : PI; objAt(g.x, g.y, 2);
  M3 base = B.base, base0 = B.base0; double k = B.k, low = B.low, flat = B.flat; V3 FX = B.FX, UP = B.UP; bool useHand = B.useHand, useG = B.useG; (void)base0; (void)useHand; (void)useG; (void)low; (void)flat; (void)k;
  Col pad = hex("#f4f6f9"), padS = shade(pad, -.12), dark = hex("#1f2937");
  Col acc = lum(K.jersey) > .82 ? K.stripe : K.jersey, acc2 = lum(K.stripe) > .82 ? shade(K.jersey, -.3) : K.stripe;
  Col pants = K.pants, sleeve2 = lum(K.stripe) > .8 ? hex("#f8fafc") : K.stripe;
  for (int li = 0; li < 2; li++) { int j = li ? 1 : -1;
    V3 ank = B.ank[li], kn = B.kn[li], hip = B.hip[li], D = B.D[li], F = B.F[li], Wd = B.Wd[li], bot = B.bot[li], top = B.top[li];
    // the thigh (pants) down to the knee
    limbLoft({hip, lerp3(hip, kn, .5), lerp3(hip, kn, .86)}, {.36 * s, .31 * s, .24 * s}, {pants, pants, pants}, FX, 10, true, false);
    // the skate under the pad
    { V3 d = norm(V3{FX.x, FX.y, 0}); M3 sk = frameAt(ank.x, ank.y, .0, std::atan2(d.y, d.x) - j * .25 * (1 - B.low)); if (B.low < .5) { rbox(sk, {.15 * s, 0, .2 * s}, {.38 * s, .16 * s, .18 * s}, dark); rbox(sk, {.18 * s, 0, .03 * s}, {.42 * s, .03 * s, .04 * s}, hex("#cbd5e1"), .5); } }
    // the pad: a contoured leg pad from the boot to the thigh rise, with its face stripes, outer roll and knee stack
    std::vector<Ring> R; const int NR = 9;
    for (int i = 0; i < NR; i++) { double t = (double)i / (NR - 1);
      double kb = std::exp(-std::pow((t - .66) / .12, 2));   // the knee block
      double w = (t > .78 ? .44 - (t - .78) * .4 : .44) * s, dpt = (.3 - .05 * t + .1 * kb) * s;
      // the leg is strapped behind the face: the pad's back sits just behind the shin/knee line, so the knee stays inside
      V3 c = lerp3(bot, top, t) + F * (dpt * .62 + .05 * s * (1 - t)); Col bc = std::fabs(t - .66) < .06 ? padS : pad;
      R.push_back({c, F, Wd, dpt, w, 4.5, bc}); }
    const int SEG = g_lod > .75 ? 16 : 12;
    loft(R, SEG, true, true, [&](int, int jj, Col c) { int a = jj > SEG / 2 ? SEG - jj : jj;   // 0 = the pad's face centre
      return a == 1 ? acc : a == 2 ? pad : a == 3 ? acc2 : c; });
    // the outer roll and the knee stack
    { V3 r0 = R[0].c + Wd * (.42 * s), r1 = R[NR - 1].c + Wd * (.32 * s); tube(r0, r1, .085 * s, .075 * s, pad, 7); }
    // the toe of the pad over the boot
    blob(frameAt(bot.x, bot.y, bot.z, yaw), {.28 * s, 0, .05 * s}, {.32 * s, .36 * s, .16 * s}, pad, 4, 9);
  }
  // pelvis / pants and the jersey torso, leaning into the crouch
  V3 pel = B.pel, sp = B.sp, SD = B.SD, SF = B.SF, SW = B.SW;
  struct TR { double t, a, b, n; Col c; };
  const TR tr[] = {{-.18, .48, .62, 2.6, pants}, {-.02, .54, .7, 2.6, pants}, {.1, .58, .8, 2.4, K.jersey}, {.16, .6, .83, 2.4, K.stripe}, {.2, .59, .82, 2.4, sleeve2},
    {.24, .58, .81, 2.4, K.stripe}, {.29, .56, .78, 2.4, K.jersey}, {.5, .58, .86, 2.4, K.jersey}, {.7, .58, .95, 2.6, K.jersey}, {.84, .52, .96, 2.6, K.jersey},
    {.95, .38, .7, 2.2, K.jersey}, {1.02, .2, .22, 2, K.skin}};
  { std::vector<Ring> R; for (auto &q : tr) R.push_back({pel + sp * q.t, SF, SW, q.a * s, q.b * s, q.n, q.c}); loft(R, g_lod > .75 ? 18 : 12, true, false); }
  // the collar: a V of the stripe colour at the neck
  { V3 c = pel + sp * .93 + SF * (.36 * s); tube(c + SW * (.22 * s) + SD * (.06 * s), c - SD * (.14 * s), .05 * s, .05 * s, K.stripe, 5, false); tube(c - SW * (.22 * s) + SD * (.06 * s), c - SD * (.14 * s), .05 * s, .05 * s, K.stripe, 5, false); }
  // arms: shoulder - elbow - wrist, sleeve stripes near the elbow
  V3 shL = B.shL, shR = B.shR, gH = B.gH, bH = B.bH;
  auto arm = [&](V3 sh, V3 el, V3 hd) {
    std::vector<V3> pts = {sh, lerp3(sh, el, .5), el, lerp3(el, hd, .25), lerp3(el, hd, .35), lerp3(el, hd, .45), lerp3(el, hd, .55), lerp3(el, hd, .8), hd};
    std::vector<double> rad = {.36 * s, .3 * s, .27 * s, .27 * s, .27 * s, .265 * s, .26 * s, .24 * s, .22 * s};
    std::vector<Col> cols = {K.jersey, K.jersey, K.jersey, K.stripe, sleeve2, K.stripe, K.jersey, K.jersey, K.jersey};
    limbLoft(pts, rad, cols, UP, 12, true, false); };
  arm(shL, B.elG, gH); arm(shR, B.elB, bH);
  // the trapper: a long cuff, the big rounded pocket facing the shooter, the T-trap web and the thumb
  { M3 gm = B.gm;
    rbox(gm, {-.05 * s, .02 * s, -.05 * s}, {.32 * s, .2 * s, .14 * s}, pad, .9);
    rbox(gm, {-.02 * s, .02 * s, -.18 * s}, {.3 * s, .21 * s, .03 * s}, acc, .5);
    blob(gm, {.28 * s, .12 * s, .22 * s}, {.2 * s, .4 * s, .5 * s}, pad, 7, 12);
    blob(gm, {.42 * s, .12 * s, .25 * s}, {.06 * s, .27 * s, .34 * s}, hex("#cbd5e1"), 4, 10);
    for (int c = -1; c <= 1; c++) tube(gm.ap({.47 * s, (.12 + c * .1) * s, .55 * s}), gm.ap({.47 * s, (.12 + c * .1) * s, .0}), .022 * s, .022 * s, hex("#94a3b8"), 3, false);
    tube(gm.ap({.4 * s, -.18 * s, -.05 * s}), gm.ap({.45 * s, -.2 * s, .35 * s}), .1 * s, .08 * s, pad, 6);
    blob(gm, {.3 * s, .5 * s, .25 * s}, {.08 * s, .06 * s, .4 * s}, acc, 3, 6); }
  // the blocker: the board facing the shooter, its stripe, the glove behind it
  { M3 bm = B.bm;
    blob(bm, {-.08 * s, 0, 0}, {.18 * s, .16 * s, .2 * s}, pad, 4, 8);
    rbox(bm, {.14 * s, -.16 * s, .08 * s}, {.06 * s, .34 * s, .48 * s}, pad, .85);
    rbox(bm, {.2 * s, -.16 * s, .08 * s}, {.015 * s, .3 * s, .08 * s}, acc, .5);
    rbox(bm, {.2 * s, -.42 * s, .08 * s}, {.015 * s, .05 * s, .44 * s}, acc2, .5); }
  // the stick: a real goalie stick has a fixed length. The blocker holds it right at the top of the paddle, the
  // paddle runs down to the heel, the shaft carries on well above the hand (to about the shoulder), and the blade
  // (long and flat) lies on the ice pointing to the glove side. When the blocker goes down for a low save the stick
  // goes down with it, paddle along the ice in front of the pad; when the blocker goes high the blade comes off the ice.
  { V3 heel = B.heel, S = B.S, Bd = B.Bd; double lay = B.lay, pl = B.pl, sh = B.shEnd;
    V3 Np = norm(lerp3(FX, UP, lay)), W = norm(cross(Np, S)); if (dot(W, Bd) < 0) W = W * -1;     // the paddle's width
    M3 st; st.X = W; st.Z = S; st.Y = cross(S, W); st.O = heel;
    Col stk = hex("#eef2f6"), tape = hex("#111827");
    rbox(st, {.03 * s, 0, pl / 2 + .06 * s}, {.125 * s, .045 * s, pl / 2 - .06 * s}, stk, .6);          // the paddle
    rbox(st, {.03 * s, .047 * s, pl * .62}, {.128 * s, .006 * s, .32 * s}, tape, .3);                    // its lettering band
    rbox(st, {0, 0, (pl + sh) / 2}, {.06 * s, .045 * s, (sh - pl) / 2}, stk, .6);                         // the shaft, through the hand
    rbox(st, {0, 0, sh - .15 * s}, {.065 * s, .05 * s, .15 * s}, tape, .6);                               // the knob
    rbox(st, {0, 0, pl * .3}, {.07 * s, .05 * s, .05 * s}, acc, .4);                                    // a colour band low on the paddle
    // the blade: from the heel toward the glove side, its bottom edge on the ice (or flat when the stick lies down)
    V3 Hh = B.Hh; M3 bl; bl.X = Bd; bl.Z = Hh; bl.Y = cross(Hh, Bd); bl.O = heel;
    rbox(bl, {.52 * s, 0, .14 * s}, {.6 * s, .035 * s, .13 * s}, stk, .5);
    rbox(bl, {.52 * s, 0, .05 * s}, {.6 * s, .037 * s, .04 * s}, tape, .4);
    rbox(bl, {-.02 * s, 0, .15 * s}, {.1 * s, .045 * s, .15 * s}, stk, .5); }
  // the head: a mask over a human face, the cage in front
  { V3 hc = pel + sp * 1.0 + SD * (.48 * s) + SF * (.12 * s); M3 hd = yawFrame(hc, yaw); hd = pitch(hd, -.1);
    blob(hd, {.12 * s, 0, -.05 * s}, {.27 * s, .25 * s, .32 * s}, K.skin, 6, 10);                  // face
    blob(hd, {.37 * s, 0, -.05 * s}, {.06 * s, .05 * s, .08 * s}, shade(K.skin, -.08), 3, 6);      // nose
    for (int e = -1; e <= 1; e += 2) blob(hd, {.33 * s, e * .1 * s, .06 * s}, {.03 * s, .045 * s, .025 * s}, hex("#1f2937"), 3, 6);
    blob(hd, {-.06 * s, 0, .1 * s}, {.4 * s, .38 * s, .4 * s}, hex("#f1f5f9"), 7, 12);              // the shell (back and top)
    blob(hd, {-.02 * s, 0, .36 * s}, {.34 * s, .1 * s, .14 * s}, acc, 4, 8);                         // a painted crest
    for (int e = -1; e <= 1; e += 2) blob(hd, {.18 * s, e * .3 * s, -.05 * s}, {.2 * s, .08 * s, .3 * s}, hex("#f1f5f9"), 4, 8);   // the jaw sides
    blob(hd, {.3 * s, 0, -.4 * s}, {.12 * s, .16 * s, .07 * s}, hex("#f1f5f9"), 3, 8);               // chin cup
    Col cage = hex("#1e293b");
    auto cp = [&](double y, double z) { return hd.ap({(.46 - y * y * 1.6 - z * z * .4) * s, y * s, z * s}); };   // the cage's curved face
    for (int r = 0; r < 5; r++) { double z = .2 - r * .13; for (int c = 0; c < 6; c++) { double y0 = -.27 + c * .09, y1 = y0 + .09; tube(cp(y0, z), cp(y1, z), .021 * s, .021 * s, cage, 3, false); } }
    for (int c = 0; c < 5; c++) { double y = -.18 + c * .09; for (int r = 0; r < 4; r++) { double z0 = .2 - r * .13, z1 = z0 - .13; tube(cp(y, z0), cp(y, z1), .021 * s, .021 * s, cage, 3, false); } } }
}
static void drawRef3() {
  const Ref &r = SK->ref; double s = SCL; M3 b = frameAt(r.x, r.y, 0, r.ang); objAt(r.x, r.y, 2);
  for (int k = -1; k <= 1; k += 2) { V3 H = b.ap({0, k * .3 * s, 2.35 * s}), A = b.ap({0, k * .3 * s, .35 * s}); tube(H, A, .26 * s, .17 * s, hex("#111827"), 7); skate(b, A, s); }
  M3 t = moveTo(b, {0, 0, 2.4 * s});
  for (int i = 0; i < 6; i++) blob(t, {0, 0, (.35 + i * .25) * s}, {.46 * s, .7 * s, .15 * s}, i % 2 ? hex("#111827") : hex("#f8fafc"), 3, 10);
  blob(moveTo(t, {0, 0, 1.95 * s}), {.06 * s, 0, .25 * s}, {.3 * s, .27 * s, .32 * s}, hex("#e0a878"), 5, 8);
  blob(moveTo(t, {0, 0, 1.95 * s}), {-.04 * s, 0, .4 * s}, {.34 * s, .3 * s, .24 * s}, hex("#111827"), 4, 8);
  double arm = r.arm > 0 ? r.arm : 0;
  for (int k = -1; k <= 1; k += 2) { V3 sh = t.ap({0, k * .72 * s, 1.55 * s}), hd = t.ap({.2 * s, k * .95 * s, (.6 + arm * 1.4) * s}); tube(sh, hd, .18 * s, .14 * s, hex("#f8fafc"), 6); }
}
static void drawPuck3() {
  Puck &P = SK->puck; double z = (P.bz > 0 ? P.bz : 0) * VZ;
  // a small puck (an NHL puck is 3 inches across, 1 thick), tilting as it flutters
  shadow(P.x, P.y, .38 + std::min(z, 6.0) * .05);
  objAt(P.x, P.y, z + .1); prism({P.x, P.y, z + .02}, PUCK_R * 1.15, .19, 12, hex("#0b0b0b"), hex("#2a2a2a"));
}

// ---------------------------------------------------------------- on the ice: rings and aids (drawn under the players)
static void ringOn(double x, double y, double r, double w, double f, Col c, Col rest) {
  if (f > 0) iceArc(x, y, r, r + w, -PI / 2, -PI / 2 + f * 2 * PI, c, std::max(3, (int)(16 * f)), .05);
  if (f < 1) iceArc(x, y, r, r + w, -PI / 2 + f * 2 * PI, 1.5 * PI, rest, std::max(3, (int)(16 * (1 - f))), .05);
}
static void drawIceAids() {
  Puck &P = SK->puck; Skater *u = SK->user;
  for (Skater *p : skAll()) shadow(p->x, p->y, 1.5);
  for (int ti = 0; ti < 2; ti++) if (!SK->T[ti].g.out) shadow(SK->T[ti].g.x, SK->T[ti].g.y, 2);
  if (SK->phase != PH_GOAL) for (Skater *p : skAll()) { double f = std::round(clamp(p->st / 100, 0, 1) * 16) / 16; bool low = f <= .25 && std::sin(now() / 170) > 0;
    ringOn(p->x, p->y, 1.9, .3, f, (p->tired || p->st <= 0) ? hex("#ef4444") : low ? rgba(239, 68, 68, .85) : rgba(34, 197, 94, .85), rgba(0, 0, 0, .35)); }
  if (u && onTeam(0, u)) ringOn(u->x, u->y, 2.3, .35, 1, hex("#ffd54a"), hex("#ffd54a"));
  if (P.owner && P.owner != u) ringOn(P.owner->x, P.owner->y, 2.3, .25, 1, P.owner->team == 0 ? hex("#93c5fd") : hex("#fca5a5"), hex("#fff"));
  if (skBenchOpen()) { BenchSpot B = skBench(); double k = .5 + .5 * std::sin(now() / 170); iceDisc(B.x, B.y, B.r, rgba(34, 197, 94, (float)(.15 + .12 * k)), 20, .03); ringOn(B.x, B.y, B.r - .3, .4, 1, hex("#22c55e"), hex("#22c55e")); }
}

// ---------------------------------------------------------------- the frame
void skDraw3D() {
  cam3Update(); g_gpu = plat_gpu3d(); g_half = norm(LIGHT - C3.f);
#ifdef HOST_BUILD
  static const bool prof = getenv("CHL_PROF") != nullptr; static double acc[9] = {0}; static int frames = 0, tri[4] = {0};
  auto T0 = std::chrono::steady_clock::now(); int st = 0;
  auto lap = [&]() { auto t = std::chrono::steady_clock::now(); acc[st++] += std::chrono::duration<double, std::milli>(t - T0).count(); T0 = t; };
#define LAP() if (prof) lap()
#else
#define LAP()
#endif
  drawArena(); LAP();
  drawIceAids(); LAP();
  g_refl = g_gpu;
  drawBoards(); if (SK) { drawBench3(); g_lod = 1; } LAP();
  drawNet(0); drawNet(1); LAP();
  for (int ti = 0; ti < 2; ti++) { g_lod = lodFor(SK->T[ti].g.x, SK->T[ti].g.y, 3); drawGoalie3(SK->T[ti].g, ti); } LAP();
  for (Skater *p : skAll()) { g_lod = lodFor(p->x, p->y, 3); drawSkater3(p); } LAP();
  if (SK->hasRef) { g_lod = lodFor(SK->ref.x, SK->ref.y, 3); drawRef3(); }
  g_lod = 1;
#ifdef HOST_BUILD
  if (prof) { tri[0] += (int)GB[0].size() / 3; tri[1] += (int)GB[1].size() / 3; tri[2] += (int)GB[2].size() / 3; tri[3] += (int)GA.size(); }
#endif
  // the shot target, standing in the net mouth where the held shot is going: a solid ring, so if the goalie's body is
  // in front of it you see him covering it (a likely save); out in the open net it's blue (a likely goal)
  { Skater *u = SK->user; Puck &P = SK->puck;
    if (u && P.owner == u && (SK->rs.dn || (QO.shotB && SK->rs.aim)) && SK->phase == PH_PLAY && skInZone(u)) { Pt T = skAimTarget(u); double o = skShotOpen(u, T.y);
      Col c = o > 0 ? hex("#3b5bff") : o == 0 ? hex("#ff5c7a") : hex("#94a3b8"); double z = .45 * PZ * VZ, r = .95, x = T.x - tdir(u->team) * .2; objAt(x, T.y, z);
      bool kk = g_keep; g_keep = true;
      for (int i = 0; i < 16; i++) { double a0 = i * PI / 8, a1 = (i + 1) * PI / 8; tube({x, T.y + std::cos(a0) * r, z + std::sin(a0) * r}, {x, T.y + std::cos(a1) * r, z + std::sin(a1) * r}, .11, .11, c, 4, false); }
      blob(frameAt(x, T.y, z, 0), {0, 0, 0}, {.18, .18, .18}, c, 3, 6); g_keep = kk; } }
  drawPuck3();
  g_refl = false;
  LAP();
  if (g_gpu) flushGPU(); else flushQ();
#ifdef HOST_BUILD
  LAP(); if (prof && ++frames % 300 == 0) { const char *nm[] = {"arena", "iceaids", "boards", "nets", "goalies", "skaters", "puck/aim", "flush"};
    fprintf(stderr, "PROF ms/frame:"); for (int i = 0; i < 8; i++) fprintf(stderr, " %s %.3f", nm[i], acc[i] / 300); fprintf(stderr, " | tris solid %d ice %d refl %d alpha %d\n", tri[0] / 300, tri[1] / 300, tri[2] / 300, tri[3] / 300);
    for (double &x : acc) x = 0; for (int &x : tri) x = 0; }
#endif
  // the NHL aim cone: from the puck to where the held shot is going, as wide as the shooter's accuracy allows,
  // BLUE where it would find open net, PINK where his body is in the way (traced against the goalie's real body)
  { Skater *u = SK->user; Puck &P = SK->puck;
    if (u && P.owner == u && (SK->rs.dn || (QO.shotB && SK->rs.aim)) && SK->phase == PH_PLAY) { Pt T = skAimTarget(u); bool zone = skInZone(u);
      double dx = T.x - P.x, dy = T.y - P.y, L = hyp(dx, dy);
      if (L > 2) { double nx = -dy / L, ny = dx / L, w = std::max(.6, L * std::tan(skAimSpread(u))); const int N = 14; Pt a = sk3Proj(P.x, P.y, .05);
        ctx.alpha(.45);
        for (int i = 0; i < N; i++) { double s0 = -1 + 2.0 * i / N, s1 = -1 + 2.0 * (i + 1) / N, ym = T.y + ny * w * (s0 + s1) / 2;
          double o = zone ? skShotOpen(u, ym) : 1; ctx.fill(!zone ? hex("#facc15") : o > 0 ? hex("#5b6cff") : o == 0 ? hex("#ff8fa3") : hex("#94a3b8"));
          Pt b = sk3Proj(T.x + nx * w * s0, T.y + ny * w * s0, .05), c = sk3Proj(T.x + nx * w * s1, T.y + ny * w * s1, .05); ctx.quad(a.x, a.y, b.x, b.y, c.x, c.y, c.x, c.y); }
        ctx.alpha(1); } } }
  // a goal: the red light over the net
  if (SK->phase == PH_GOAL && SK->hasNetIn) { double gx = SK->netIn.gx; Pt q = sk3Proj(gx < RK.L / 2 ? RK.gl - RK.netD * 1.3 : RK.L - RK.gl + RK.netD * 1.3, RK.cy, (PZ + .2) * VZ + 2.5); double k = .5 + .5 * std::sin(now() / 90), r = .012 * U;
    ctx.alpha(.3 + .35 * k); ctx.fill("#ff2d2d"); ctx.disc(q.x, q.y, r * (2.2 + k)); ctx.alpha(1); ctx.fill(k > .5 ? "#ff6b6b" : "#dc2626"); ctx.fillRect(q.x - r, q.y - r * .8, r * 2, r * 1.6); }
}
#ifdef HOST_BUILD
void skGoalieDbg(Goalie &g, char *buf, int n) {   // test builds: where his hands are (lateral offset from him, physics height)
  GBody B; gBody(g, g.team & 1, B);
  snprintf(buf, n, "glove %.2f,%.2f blocker %.2f,%.2f head %.2f,%.2f low %.2f drop %.2f useHand %d useG %d aty %.2f atz %.2f k %.2f",
    B.gH.y - g.y, B.gH.z / VZ, B.bH.y - g.y, B.bH.z / VZ, B.hc.y - g.y, B.hc.z / VZ, B.low, B.drop, (int)B.useHand, (int)B.useG, B.aty, B.atz, B.k);
  { V3 pc = B.gm.ap({.28 * B.s, .12 * B.s, .22 * B.s}); double d = g.team == 0 ? 1 : -1; int a1 = skGoalieTouch(g, pc.x, pc.y, pc.z / VZ, PUCK_R, nullptr, nullptr);
    int a2 = skGoalieTouch(g, g.x + d * 1.9, g.y + g.aimY, g.aimZ / 1.7, PUCK_R, nullptr, nullptr);
    double gx = (B.gH.x - g.x) * d; int L = (int)strlen(buf); snprintf(buf + L, n - L, " | probe pocket %d aim %d gloveX %.2f pocketX %.2f", a1, a2, gx, (pc.x - g.x) * d); }
}
#endif

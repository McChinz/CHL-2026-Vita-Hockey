// CHL 2026 native - the 3D view (first pass): a perspective broadcast camera behind the play, and the arena,
// nets, puck, skaters, goalies and the ref as low-poly lit models. Everything is projected here and drawn as
// flat-shaded triangles, back to front (no depth buffer on vita2d). The game itself is unchanged: same world
// (feet, x along the rink, y across, z up), same physics. SELECT switches between this and the classic view.
#include "game.h"
#include "sk_int.h"

bool g_view3d = true;

// ---------------------------------------------------------------- the camera
struct V3 { double x, y, z; };
static inline V3 operator+(V3 a, V3 b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
static inline V3 operator-(V3 a, V3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static inline V3 operator*(V3 a, double k) { return {a.x * k, a.y * k, a.z * k}; }
static inline double dot(V3 a, V3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static inline V3 cross(V3 a, V3 b) { return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
static inline V3 norm(V3 a) { double l = std::sqrt(dot(a, a)); return l > 1e-9 ? a * (1 / l) : V3{0, 0, 1}; }
static struct { V3 e, f, r, u; double F, sx, sy; } C3;
static const double NEARZ = 1.0;
static void cam3Update() {
  // our own follow: the puck (or whoever has it), a little ahead of it, smoothed; ends kept in view
  static double fx = RK.L / 2, fy = RK.cy; static const Game *last = nullptr;
  double tx = RK.L / 2, ty = RK.cy;
  if (SK) { const Puck &P = SK->puck; tx = P.x + (P.owner ? std::cos(P.owner->ang) * 6 : 0); ty = P.y; if (SK->phase == PH_PREVIEW || SK->phase == PH_INTRO) tx = RK.L / 2; }
  tx = clamp(tx - 6, 30, RK.L - 44); ty = RK.cy + (ty - RK.cy) * .3;
  if (last != SK) { fx = tx; fy = ty; last = SK; } else { fx += (tx - fx) * .09; fy += (ty - fy) * .06; }
  double cx = fx, cy = fy;
  C3.e = {cx - 66, cy, 50}; V3 t = {cx + 16, cy, 0};
  C3.f = norm(t - C3.e); C3.r = norm(cross({0, 0, 1}, C3.f)); C3.u = cross(C3.f, C3.r);
  C3.F = W * .9; C3.sx = W / 2; C3.sy = H * .5 + .05 * U;
}
static inline V3 toCam(V3 p) { V3 v = p - C3.e; return {dot(v, C3.r), dot(v, C3.u), dot(v, C3.f)}; }
static inline Pt camProj(V3 c) { return {C3.sx + c.x / c.z * C3.F, C3.sy - c.y / c.z * C3.F}; }
Pt sk3Proj(double x, double y, double z) { V3 c = toCam({x, y, z}); if (c.z < NEARZ) c.z = NEARZ; return camProj(c); }
double sk3Scale(double x, double y, double z) { V3 c = toCam({x, y, z}); return C3.F / std::max(NEARZ, c.z); }

// ---------------------------------------------------------------- the triangle queue
struct Tri3 { float x[3], y[3]; uint32_t c; float od, td; };
static std::vector<Tri3> Q;          // sorted (back to front)
static double g_objDepth = 0;         // the object being built: its triangles sort together
static const V3 LIGHT = norm({-.35, .45, 1});
static uint32_t litCol(Col c, V3 n, double a) {
  double k = .5 + .6 * std::max(0.0, dot(n, LIGHT)); k = std::min(1.12, k);
  Col o(std::min(255.0, c.r * k), std::min(255.0, c.g * k), std::min(255.0, c.b * k), c.a * a); return o.pack();
}
// GPU path (vitaGL): world-space triangles by pass; the see-through ones are sorted back to front
static bool g_gpu = false;
static std::vector<V3c> GB[3];                       // 0 solid, 1 painted on the ice, 2 reflections under the ice
static bool g_refl = false;                          // what's being built shows in the ice (GPU path)
struct ATri { V3c v[3]; float d; }; static std::vector<ATri> GA;
static inline V3c vc(V3 p, uint32_t c) { V3c o; o.x = (float)p.x; o.y = (float)p.y; o.z = (float)p.z; o.c = c; return o; }
// a convex polygon in world space: near-clipped, then either queued for the GPU or projected and fanned here.
// n: its outward normal (back faces skipped), or null for both sides; immediate: painted on the ice (drawn under
// everything standing on it)
static void poly(const V3 *p, int n, Col col, const V3 *nrm, double a = 1, bool lit = true, bool immediate = false) {
  if (n < 3) return;
  V3 cen = {0, 0, 0}; for (int i = 0; i < n; i++) cen = cen + p[i]; cen = cen * (1.0 / n);
  V3 N = nrm ? *nrm : norm(cross(p[1] - p[0], p[2] - p[0]));
  if (nrm && dot(N, cen - C3.e) >= 0) return;          // facing away
  if (!nrm && dot(N, cen - C3.e) > 0) N = N * -1;      // two-sided: light the side we see
  uint32_t c = lit ? litCol(col, N, a) : withA(col, (float)(col.a * a)).pack();
  // clip against the near plane (in front of the camera by NEARZ)
  V3 out[20]; int m = std::min(n, 16), k = 0;
  for (int i = 0; i < m; i++) { V3 A = p[i], B = p[(i + 1) % m]; double da = dot(A - C3.e, C3.f) - NEARZ, db = dot(B - C3.e, C3.f) - NEARZ;
    if (da >= 0) out[k++] = A; if ((da >= 0) != (db >= 0)) { double t = da / (da - db); out[k++] = A + (B - A) * t; } }
  if (k < 3) return;
  double td = dot(cen - C3.e, C3.f);
  if (g_gpu) {
    bool see = (c >> 24) < 250;
    for (int i = 1; i + 1 < k; i++) {
      if (immediate) { GB[1].push_back(vc(out[0], c)); GB[1].push_back(vc(out[i], c)); GB[1].push_back(vc(out[i + 1], c)); }
      else if (see) { ATri t; t.v[0] = vc(out[0], c); t.v[1] = vc(out[i], c); t.v[2] = vc(out[i + 1], c); t.d = (float)td; GA.push_back(t); }
      else { GB[0].push_back(vc(out[0], c)); GB[0].push_back(vc(out[i], c)); GB[0].push_back(vc(out[i + 1], c));
        if (g_refl) { Col rc((float)((c & 255) * .78 + 8), (float)(((c >> 8) & 255) * .78 + 12), (float)(((c >> 16) & 255) * .78 + 20)); uint32_t r = rc.pack();
          for (V3 q : {out[0], out[i], out[i + 1]}) { q.z = -q.z; GB[2].push_back(vc(q, r)); } } }
    }
    return;
  }
  Pt s[20]; double minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9;
  for (int i = 0; i < k; i++) { V3 cc = toCam(out[i]); if (cc.z < NEARZ) cc.z = NEARZ; s[i] = camProj(cc); minX = std::min(minX, s[i].x); maxX = std::max(maxX, s[i].x); minY = std::min(minY, s[i].y); maxY = std::max(maxY, s[i].y); }
  if (maxX < 0 || minX > W || maxY < 0 || minY > H) return;
  for (int i = 1; i + 1 < k; i++) {
    if (immediate) ctx.rawTri(s[0].x, s[0].y, s[i].x, s[i].y, s[i + 1].x, s[i + 1].y, c);
    else { Tri3 t; t.x[0] = s[0].x; t.y[0] = s[0].y; t.x[1] = s[i].x; t.y[1] = s[i].y; t.x[2] = s[i + 1].x; t.y[2] = s[i + 1].y; t.c = c; t.od = (float)g_objDepth; t.td = (float)td; Q.push_back(t); }
  }
}
// the GPU's clip matrix for this camera: the same projection the CPU path uses (near 1 ft, far 900 ft)
static void clipMatrix(float *m) {
  const double n = NEARZ, f = 900, A = 2 * C3.F / W, B = 2 * C3.sx / W - 1, Cc = 2 * C3.F / H, D = 1 - 2 * C3.sy / H, E = (f + n) / (f - n), G = -2 * f * n / (f - n);
  // rows of P * V, V = [r; u; fwd] with -dot(axis, eye)
  const V3 R = C3.r, Uu = C3.u, Fw = C3.f, e = C3.e;
  double rows[4][4] = {
    {A * R.x + B * Fw.x, A * R.y + B * Fw.y, A * R.z + B * Fw.z, -A * dot(R, e) - B * dot(Fw, e)},
    {Cc * Uu.x + D * Fw.x, Cc * Uu.y + D * Fw.y, Cc * Uu.z + D * Fw.z, -Cc * dot(Uu, e) - D * dot(Fw, e)},
    {E * Fw.x, E * Fw.y, E * Fw.z, -E * dot(Fw, e) + G},
    {Fw.x, Fw.y, Fw.z, -dot(Fw, e)}};
  for (int c = 0; c < 4; c++) for (int r = 0; r < 4; r++) m[c * 4 + r] = (float)rows[r][c];
}
static void flushGPU() {
  ctx.flush();   // the 2D drawn so far (the backdrop) goes first
  float M[16]; clipMatrix(M);
  if (!GB[2].empty()) plat_draw3d(M, GB[2].data(), (int)GB[2].size(), 0);   // the players, nets and boards mirrored under the ice
  if (!GB[0].empty()) plat_draw3d(M, GB[0].data(), (int)GB[0].size(), 0);
  if (!GB[1].empty()) plat_draw3d(M, GB[1].data(), (int)GB[1].size(), 1);
  if (!GA.empty()) { std::sort(GA.begin(), GA.end(), [](const ATri &a, const ATri &b) { return a.d > b.d; });
    std::vector<V3c> v; v.reserve(GA.size() * 3); for (auto &t : GA) for (int i = 0; i < 3; i++) v.push_back(t.v[i]); plat_draw3d(M, v.data(), (int)v.size(), 2); }
  GB[0].clear(); GB[1].clear(); GB[2].clear(); GA.clear();
}
static void quad(V3 a, V3 b, V3 c, V3 d, Col col, const V3 *n, double al = 1, bool lit = true, bool imm = false) { V3 p[4] = {a, b, c, d}; poly(p, 4, col, n, al, lit, imm); }
static void flushQ() {
  std::sort(Q.begin(), Q.end(), [](const Tri3 &a, const Tri3 &b) { if (a.od != b.od) return a.od > b.od; return a.td > b.td; });
  for (auto &t : Q) ctx.rawTri(t.x[0], t.y[0], t.x[1], t.y[1], t.x[2], t.y[2], t.c);
  Q.clear();
}
static void objAt(double x, double y, double z = 0) { g_objDepth = toCam({x, y, z}).z; }

// ---------------------------------------------------------------- models: boxes in a local frame
// local frame: x forward, y to the left, z up; M = rotation (3 columns) + origin
struct M3 { V3 X, Y, Z, O; V3 ap(V3 p) const { return O + X * p.x + Y * p.y + Z * p.z; } V3 dir(V3 p) const { return X * p.x + Y * p.y + Z * p.z; } };
static M3 frameAt(double x, double y, double z, double yaw) { M3 m; m.X = {std::cos(yaw), std::sin(yaw), 0}; m.Y = {-std::sin(yaw), std::cos(yaw), 0}; m.Z = {0, 0, 1}; m.O = {x, y, z}; return m; }
// rotate the frame about its own y (pitch: + tips the top forward), x (roll: + tips toward -y), z (yaw)
static M3 pitch(M3 m, double a) { double c = std::cos(a), s = std::sin(a); M3 o = m; o.X = m.X * c + m.Z * -s; o.Z = m.X * s + m.Z * c; return o; }
static M3 roll(M3 m, double a) { double c = std::cos(a), s = std::sin(a); M3 o = m; o.Y = m.Y * c + m.Z * s; o.Z = m.Y * -s + m.Z * c; return o; }
static M3 moveTo(M3 m, V3 p) { m.O = m.ap(p); return m; }
// a box: center c, half sizes h, in frame m
static void box(const M3 &m, V3 c, V3 h, Col col, double a = 1) {
  V3 P[8]; int i = 0; for (int sx = -1; sx <= 1; sx += 2) for (int sy = -1; sy <= 1; sy += 2) for (int sz = -1; sz <= 1; sz += 2) P[i++] = m.ap({c.x + sx * h.x, c.y + sy * h.y, c.z + sz * h.z});
  // index = (sx>0)*4 + (sy>0)*2 + (sz>0)
  static const int F[6][4] = {{4, 6, 7, 5}, {0, 1, 3, 2}, {2, 3, 7, 6}, {0, 4, 5, 1}, {1, 5, 7, 3}, {0, 2, 6, 4}};
  const V3 Ns[6] = {m.X, m.X * -1, m.Y, m.Y * -1, m.Z, m.Z * -1};
  for (int f = 0; f < 6; f++) quad(P[F[f][0]], P[F[f][1]], P[F[f][2]], P[F[f][3]], col, &Ns[f], a);
}
// a box hanging from a joint: from the joint down its own -z by len
static void limb(const M3 &m, double len, double hw, double hd, Col col) { box(m, {0, 0, -len / 2}, {hd, hw, len / 2}, col); }
// an n-sided prism standing on z (puck, posts)
static void prism(V3 c, double r, double h, int n, Col side, Col top) {
  std::vector<V3> b(n), t(n);
  for (int i = 0; i < n; i++) { double a = i * 2 * PI / n; b[i] = {c.x + std::cos(a) * r, c.y + std::sin(a) * r, c.z}; t[i] = b[i] + V3{0, 0, h}; }
  for (int i = 0; i < n; i++) { int j = (i + 1) % n; double a = (i + .5) * 2 * PI / n; V3 nn = {std::cos(a), std::sin(a), 0}; quad(b[i], b[j], t[j], t[i], side, &nn); }
  V3 up = {0, 0, 1}; poly(t.data(), std::min(n, 16), top, &up);
}
// a flat disc / ring on the ice, drawn now (under everything standing on it)
static void iceDisc(double x, double y, double r, Col c, int n = 12, double z = .03) {
  std::vector<V3> p(n); for (int i = 0; i < n; i++) { double a = i * 2 * PI / n; p[i] = {x + std::cos(a) * r, y + std::sin(a) * r, z}; } poly(p.data(), n, c, nullptr, 1, false, true);
}
static void iceArc(double x, double y, double r0, double r1, double a0, double a1, Col c, int n = 20, double z = .02) {
  for (int i = 0; i < n; i++) { double u0 = a0 + (a1 - a0) * i / n, u1 = a0 + (a1 - a0) * (i + 1) / n;
    quad({x + std::cos(u0) * r0, y + std::sin(u0) * r0, z}, {x + std::cos(u1) * r0, y + std::sin(u1) * r0, z}, {x + std::cos(u1) * r1, y + std::sin(u1) * r1, z}, {x + std::cos(u0) * r1, y + std::sin(u0) * r1, z}, c, nullptr, 1, false, true); }
}
static void iceRect(double x0, double y0, double x1, double y1, Col c, double z = .02) { quad({x0, y0, z}, {x1, y0, z}, {x1, y1, z}, {x0, y1, z}, c, nullptr, 1, false, true); }

// ---------------------------------------------------------------- the arena
// the rink's outline (rounded corners), counter-clockwise
static const std::vector<Pt> &rinkOutline() {
  static std::vector<Pt> o; if (!o.empty()) return o;
  const double L = RK.L, Wd = RK.Wd, r = RK.cr; const int n = 8;
  auto corner = [&](double cx, double cy, double a0) { for (int i = 0; i <= n; i++) { double a = a0 + i * (PI / 2) / n; o.push_back({cx + std::cos(a) * r, cy + std::sin(a) * r}); } };
  corner(L - r, r, -PI / 2); corner(L - r, Wd - r, 0); corner(r, Wd - r, PI / 2); corner(r, r, PI);
  // the long straight sides in pieces (so the boards sort well against the players)
  std::vector<Pt> f; for (size_t i = 0; i < o.size(); i++) { Pt a = o[i], b = o[(i + 1) % o.size()]; double d = hyp(b.x - a.x, b.y - a.y); int k = std::max(1, (int)std::ceil(d / 10));
    for (int j = 0; j < k; j++) f.push_back({a.x + (b.x - a.x) * j / k, a.y + (b.y - a.y) * j / k}); }
  o = f; return o;
}
static void drawCrowd() {
  // stands: rows rising away from the boards, a colour per seat block (fixed)
  static const char *shirts[12] = {"#ef4444", "#f8fafc", "#3b82f6", "#facc15", "#64748b", "#1e293b", "#f97316", "#22c55e", "#e2e8f0", "#7c3aed", "#dc2626", "#0ea5e9"};
  const auto &O = rinkOutline(); size_t n = O.size(); double cx = RK.L / 2, cy = RK.cy;
  for (size_t i = 0; i < n; i++) {
    Pt a = O[i], b = O[(i + 1) % n]; double ex = (a.x + b.x) / 2 - cx, ey = (a.y + b.y) / 2 - cy;
    double ox = b.y - a.y, oy = -(b.x - a.x), ol = hyp(ox, oy); ox /= ol; oy /= ol; if (ox * ex + oy * ey < 0) { ox = -ox; oy = -oy; }   // outward
    V3 on = {-ox, -oy, .9}; on = norm(on);
    objAt((a.x + b.x) / 2 + ox * 30, (a.y + b.y) / 2 + oy * 30, 20);
    for (int r = 0; r < 6; r++) {
      double d0 = 6 + r * 4.2, d1 = d0 + 4.2, z0 = 6 + r * 2.6, z1 = z0 + 2.6;
      SkRng R((int)(i * 31 + r * 7 + 3)); Col c = hex(R() < .5 ? shirts[(int)(R() * 12) % 12] : (r % 2 ? "#273449" : "#1f2a3d"));
      quad({a.x + ox * d0, a.y + oy * d0, z0}, {b.x + ox * d0, b.y + oy * d0, z0}, {b.x + ox * d1, b.y + oy * d1, z1}, {a.x + ox * d1, a.y + oy * d1, z1}, c, &on);
      V3 rn = {-ox, -oy, 0}; quad({a.x + ox * d1, a.y + oy * d1, z0}, {b.x + ox * d1, b.y + oy * d1, z0}, {b.x + ox * d1, b.y + oy * d1, z1}, {a.x + ox * d1, a.y + oy * d1, z1}, hex("#151c2b"), &rn);
    }
  }
}
static void drawIce() {
  const auto &O = rinkOutline(); std::vector<V3> p; for (auto &q : O) p.push_back({q.x, q.y, 0});
  // the ice as a fan (convex), drawn in slices so the near-plane clip stays small
  V3 c = {RK.L / 2, RK.cy, 0}; Col ice = hex("#e9f1f8");
  if (g_gpu) {   // polished ice: a floor well under it, the reflections in between, the ice itself a little see-through
    Col fl = hex("#cfdbe8"); quad({-40, -40, -16}, {RK.L + 40, -40, -16}, {RK.L + 40, RK.Wd + 40, -16}, {-40, RK.Wd + 40, -16}, fl, nullptr, 1, false);
    ice = withA(ice, .72f); }
  for (size_t i = 0; i < p.size(); i++) { V3 t[3] = {c, p[i], p[(i + 1) % p.size()]}; poly(t, 3, ice, nullptr, 1, false, true); }
  const double L = RK.L, Wd = RK.Wd, cy = RK.cy, gl = RK.gl;
  Col red = hex("#d43a3a"), blue = hex("#2f5fc4"), crease = hex("#8fb8f0");
  iceRect(L / 2 - .5, 0.6, L / 2 + .5, Wd - .6, red);
  for (double bx : {L / 2 - SK_BLUE / 2 - 0.0, L / 2 + SK_BLUE / 2}) iceRect(bx - .5, .6, bx + .5, Wd - .6, blue);
  for (double gx : {gl, L - gl}) iceRect(gx - .15, 3.5, gx + .15, Wd - 3.5, red);
  iceArc(L / 2, cy, 14.6, 15, 0, 2 * PI, blue, 32); iceDisc(L / 2, cy, .7, blue, 10);
  for (double fx : {gl + 20, L - gl - 20}) for (double fy : {cy - 22, cy + 22}) { iceArc(fx, fy, 14.6, 15, 0, 2 * PI, red, 28); iceDisc(fx, fy, 1, red, 10); }
  for (double fx : {L / 2 - SK_BLUE / 2 + 5, L / 2 + SK_BLUE / 2 - 5}) for (double fy : {cy - 22, cy + 22}) iceDisc(fx, fy, 1, red, 10);
  iceArc(gl, cy, 0, 6, -PI / 2, PI / 2, crease, 10); iceArc(L - gl, cy, 0, 6, PI / 2, PI * 1.5, crease, 10);
}
static void drawBoards() {
  const auto &O = rinkOutline(); size_t n = O.size(); double cx = RK.L / 2, cy = RK.cy;
  for (size_t i = 0; i < n; i++) {
    Pt a = O[i], b = O[(i + 1) % n]; double mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
    V3 in = norm({cx - mx, (cy - my) * 2.3, 0});
    objAt(mx, my, 1);
    quad({a.x, a.y, 0}, {b.x, b.y, 0}, {b.x, b.y, SK_BH}, {a.x, a.y, SK_BH}, hex("#f8fafc"), nullptr);            // the boards
    quad({a.x, a.y, 0}, {b.x, b.y, 0}, {b.x, b.y, .9}, {a.x, a.y, .9}, hex("#f2c230"), nullptr);                  // kick plate
    V3 o = in * -.5; V3 up = {0, 0, 1};
    quad({a.x, a.y, SK_BH}, {b.x, b.y, SK_BH}, V3{b.x, b.y, SK_BH} + o, V3{a.x, a.y, SK_BH} + o, hex("#d43a3a"), &up);   // the top rail
    quad({a.x, a.y, SK_BH}, {b.x, b.y, SK_BH}, {b.x, b.y, SK_BH + 5.5}, {a.x, a.y, SK_BH + 5.5}, rgba(200, 225, 245, .16), nullptr, 1, false);   // glass
  }
}
// the far end banners and the scoreboard lights (simple)
static void drawArena() {
  ctx.fill("#0e1422"); ctx.fillRect(0, 0, W, H);
  Grad g = gLin(0, 0, 0, H * .45); g.add(0, hex("#060a14")); g.add(1, hex("#18213a")); ctx.fill(g); ctx.fillRect(0, 0, W, H * .45);
  drawCrowd(); flushQ();
  drawIce();
}

// ---------------------------------------------------------------- nets
static void drawNet(int side) {   // side: the team that defends it
  double gx = defendX(side), d = -tdir(side), cy = RK.cy, hw = RK.post * .62, h = 4.2, dp = RK.netD;
  Col red = hex("#dc2626"), mesh = rgba(245, 248, 252, .38);
  objAt(gx + d * dp * .5, cy, 1.5);
  // the frame: posts, crossbar, the base hoop
  for (double s : {-1.0, 1.0}) box(frameAt(gx, cy + s * hw, 0, 0), {0, 0, h / 2}, {.18, .18, h / 2}, red);
  box(frameAt(gx, cy, h, 0), {0, 0, 0}, {.18, hw + .18, .18}, red);
  box(frameAt(gx + d * dp, cy, .1, 0), {0, 0, 0}, {.12, hw, .1}, hex("#e5e7eb"));
  for (double s : {-1.0, 1.0}) box(frameAt(gx + d * dp * .5, cy + s * hw, .1, 0), {0, 0, 0}, {dp * .5, .12, .1}, hex("#e5e7eb"));
  // the mesh: back, sides, roof (see-through)
  double bx = gx + d * dp;
  quad({bx, cy - hw, 0}, {bx, cy + hw, 0}, {gx + d * dp * .4, cy + hw, h}, {gx + d * dp * .4, cy - hw, h}, mesh, nullptr, 1, false);
  for (double s : {-1.0, 1.0}) quad({gx, cy + s * hw, 0}, {bx, cy + s * hw, 0}, {gx + d * dp * .4, cy + s * hw, h}, {gx, cy + s * hw, h}, mesh, nullptr, 1, false);
  quad({gx, cy - hw, h}, {gx, cy + hw, h}, {gx + d * dp * .4, cy + hw, h}, {gx + d * dp * .4, cy - hw, h}, mesh, nullptr, 1, false);
  // a goal: the bulge
  const NetBulge &nb = SK->nb[side == 0 ? 0 : 1]; if (nb.on) { double k = std::max(0.0, 1 - nb.t / .6); box(frameAt(bx + d * .6 * k, cy + nb.y, 1.2, 0), {0, 0, 0}, {.3 * k, .9, .9}, mesh); }
}

// ---------------------------------------------------------------- people
static const double SCL = 1.35;   // figures a little bigger than life, like the classic view
struct Kit { Col jersey, stripe, pants, helm, skin, sock; };
static Kit kitOf(int team) { Team &T = SK->T[team]; Kit k; k.jersey = T.col; k.stripe = T.stripe; k.pants = shade(T.col, -.6); k.helm = shade(T.col, -.15); k.skin = hex("#e0a878"); k.sock = T.col; return k; }
// a skater: the pose comes from what he's doing (stride, lean, wind-up, poke, spin, falling, blocking)
static void drawSkater3(Skater *p) {
  Kit K = kitOf(p->team); K.skin = p->skin;
  double sp = hyp(p->vx, p->vy), st = std::sin(p->ph * 3) * std::min(1.0, sp / 12);
  double yaw = p->ang; if (p->spin > 0) yaw += (1 - p->spin / SPIN_T) * 2 * PI;
  double lean = .22 + (p->dash > 0 ? .3 : 0) + std::min(.12, sp / 200);
  M3 base = frameAt(p->x, p->y, 0, yaw);
  objAt(p->x, p->y, 2);
  if (p->block > 0) base = roll(base, (std::cos(p->blkA) > 0 ? 1 : -1) * 1.35 * std::min(1.0, p->block / .25));
  else if (p->stun > 0) base = roll(base, (p->team ? 1 : -1) * (p->kd ? 1.35 : .45));
  double s = SCL; bool lh = p->sh != 'R'; double side = lh ? 1 : -1;   // the stick side: a left shot carries it on his left
  // legs: hips swing fore / aft with the stride
  for (int k = -1; k <= 1; k += 2) {
    double sw = st * .55 * k;
    M3 hip = pitch(moveTo(base, {0, k * .38 * s, 2.55 * s}), sw);
    limb(hip, 1.15 * s, .26 * s, .3 * s, K.pants);
    M3 knee = pitch(moveTo(hip, {0, 0, -1.15 * s}), -std::fabs(sw) * .6 - .25);
    limb(knee, 1.05 * s, .2 * s, .22 * s, K.sock);
    M3 ank = moveTo(knee, {0, 0, -1.05 * s});
    box(ank, {.2 * s, 0, -.2 * s}, {.55 * s, .14 * s, .16 * s}, hex("#111827"));
    box(ank, {.2 * s, 0, -.38 * s}, {.6 * s, .03 * s, .03 * s}, hex("#cbd5e1"));
  }
  // body
  M3 tor = pitch(moveTo(base, {0, 0, 2.55 * s}), lean);
  box(tor, {0, 0, .2 * s}, {.5 * s, .78 * s, .32 * s}, K.pants);
  box(tor, {0, 0, 1.05 * s}, {.48 * s, .82 * s, .62 * s}, K.jersey);
  box(tor, {0, 0, .95 * s}, {.5 * s, .84 * s, .09 * s}, K.stripe);
  if (p->star) box(tor, {.49 * s, 0, 1.3 * s}, {.02 * s, .2 * s, .2 * s}, hex("#facc15"));
  M3 neck = moveTo(tor, {0, 0, 1.7 * s});
  box(neck, {0, 0, .1 * s}, {.16 * s, .16 * s, .1 * s}, K.skin);
  box(neck, {.02 * s, 0, .45 * s}, {.36 * s, .32 * s, .3 * s}, K.helm);
  box(neck, {.34 * s, 0, .38 * s}, {.04 * s, .26 * s, .14 * s}, K.skin);
  box(neck, {.39 * s, 0, .46 * s}, {.02 * s, .22 * s, .03 * s}, hex("#cbd5e1"));
  // arms reach for the stick; the stick: hands near the hip on his stick side, blade on the ice ahead
  double wind = p->wind > 0 ? p->wind : 0, poke = p->pokeA > 0 ? std::sin(PI * (1 - p->pokeA / .28)) : 0;
  V3 hand = tor.ap({.55 * s, side * .45 * s, .65 * s}); V3 top = tor.ap({.15 * s, side * .7 * s, 1.0 * s});
  V3 fwd = base.X, lat = base.Y * side;
  V3 blade = {p->x, p->y, 0}; blade = blade + fwd * ((3.4 + poke * 1.6) * s) + lat * (1.1 * s);
  if (wind > 0) { blade = V3{p->x, p->y, 0} + fwd * (-1.5 * s) + lat * (1.9 * s); blade.z = 2.6 * wind * s; }
  if (p->block > 0 || (p->stun > 0 && p->kd)) blade = hand + fwd * 2 + V3{0, 0, -1};
  auto seg = [&](V3 a, V3 b, double r, Col c) {   // a stick / arm piece between two points
    V3 d = b - a; double len = std::sqrt(dot(d, d)); if (len < 1e-3) return; M3 m; m.Z = d * (1 / len); m.X = norm(cross(m.Z, V3{0, 0, 1}) * -1); if (dot(m.X, m.X) < .5) m.X = {1, 0, 0}; m.Y = cross(m.Z, m.X); m.O = a; box(m, {0, 0, len / 2}, {r, r, len / 2}, c); };
  V3 shL = tor.ap({0, .78 * s, 1.5 * s}), shR = tor.ap({0, -.78 * s, 1.5 * s});
  V3 handTop = top + (hand - top) * .1, handLow = top + (hand - top) * .9;
  seg(shL, lh ? handLow : handTop, .17 * s, K.jersey); seg(shR, lh ? handTop : handLow, .17 * s, K.jersey);
  seg(top, blade, .07 * s, hex("#3f2a14"));
  { V3 bd = norm(V3{fwd.x, fwd.y, 0}); V3 bl = blade + lat * (-.1); M3 m = frameAt(bl.x, bl.y, std::max(.05, bl.z), std::atan2(bd.y, bd.x) + side * .3); box(m, {.3 * s, 0, .05}, {.42 * s, .05, .1 * s}, hex("#111827")); }
  for (V3 h : {handTop, handLow}) { M3 m = frameAt(h.x, h.y, h.z, yaw); box(m, {0, 0, 0}, {.2 * s, .2 * s, .2 * s}, shade(K.jersey, -.35)); }
}
static void shadow(double x, double y, double r) { iceDisc(x, y, r, rgba(15, 23, 42, .22), 10, .04); }
static void drawGoalie3(Goalie &g, int ti) {
  if (g.out) return; Kit K = kitOf(ti);
  double yaw = ti == 0 ? 0 : PI, s = SCL; M3 base = frameAt(g.x, g.y, 0, yaw);
  objAt(g.x, g.y, 2);
  Pose P = g.hasAn ? g.an.p : GP_NONE; double side = g.hasAn ? g.an.s : 1; if (ti == 1) side = -side;
  double k = 1; if (g.hasAn) { double t = g.an.t; k = t < g.an.i ? t / g.an.i : t < g.an.i + g.an.h ? 1 : std::max(0.0, 1 - (t - g.an.i - g.an.h) / g.an.o); }
  bool fly = P == GP_LO || P == GP_KICK; double low = fly ? k : 0;
  if (P == GP_DIVE) base = roll(base, -side * 1.2 * k);
  Col pad = hex("#f8fafc"), padS = K.jersey;
  // pads: stance, or flared out on the ice in the butterfly
  for (int j = -1; j <= 1; j += 2) {
    double out = low * 1.0;
    M3 leg = roll(moveTo(base, {0, j * .55 * s, 2.0 * s * (1 - low * .6)}), -j * out * 1.25);
    box(leg, {.15 * s, 0, -1.0 * s}, {.42 * s, .38 * s, 1.0 * s}, pad);
    box(leg, {.58 * s, 0, -1.0 * s}, {.02 * s, .3 * s, .7 * s}, padS);
    box(leg, {.25 * s, 0, -2.02 * s}, {.5 * s, .2 * s, .08 * s}, hex("#111827"));
  }
  M3 tor = pitch(moveTo(base, {0, 0, 2.0 * s * (1 - low * .55)}), .25);
  box(tor, {0, 0, .9 * s}, {.6 * s, 1.0 * s, .9 * s}, K.jersey);
  box(tor, {0, 0, .55 * s}, {.62 * s, 1.02 * s, .09 * s}, K.stripe);
  box(tor, {.1 * s, 0, 2.15 * s}, {.38 * s, .36 * s, .38 * s}, hex("#f1f5f9"));
  box(tor, {.48 * s, 0, 2.05 * s}, {.03 * s, .24 * s, .2 * s}, hex("#334155"));
  double up = P == GP_HI || P == GP_BODY ? k : 0, gl = (side > 0 ? 1 : 0) * up, bl = (side < 0 ? 1 : 0) * up;
  // glove (his left) and blocker (his right)
  box(tor, {.75 * s, .95 * s, (.8 + gl * 1.1) * s}, {.32 * s, .14 * s, .34 * s}, K.stripe == hex("#ffffff") ? hex("#e2e8f0") : K.stripe);
  box(tor, {.75 * s, -.95 * s, (.75 + bl * 1.1) * s}, {.3 * s, .1 * s, .4 * s}, hex("#f8fafc"));
  // the stick: a paddle flat in front of the pads
  V3 bp = base.ap({1.2 * s, -.2 * s, .12}); M3 sm = frameAt(bp.x, bp.y, bp.z, yaw + PI / 2);
  box(sm, {0, 0, 0}, {.9 * s, .12 * s, .1 * s}, hex("#3f2a14"));
  box(tor, {.85 * s, -.95 * s, -.2 * s}, {.08 * s, .08 * s, .9 * s}, hex("#3f2a14"));
}
static void drawRef3() {
  const Ref &r = SK->ref; double s = SCL; M3 b = frameAt(r.x, r.y, 0, r.ang); objAt(r.x, r.y, 2);
  for (int k = -1; k <= 1; k += 2) { box(b, {0, k * .35 * s, 1.25 * s}, {.22 * s, .2 * s, 1.25 * s}, hex("#111827")); box(b, {.2 * s, k * .35 * s, .12 * s}, {.5 * s, .14 * s, .12 * s}, hex("#0b0b0b")); }
  for (int i = 0; i < 5; i++) box(b, {0, (-.6 + i * .3) * s, 3.35 * s}, {.42 * s, .15 * s, .85 * s}, i % 2 ? hex("#111827") : hex("#f8fafc"));
  box(b, {0, 0, 4.55 * s}, {.32 * s, .3 * s, .32 * s}, hex("#111827"));
  double arm = r.arm > 0 ? r.arm : 0; for (int k = -1; k <= 1; k += 2) box(b, {.1 * s, k * .95 * s, (3.4 + arm * .9) * s}, {.15 * s, .15 * s, .7 * s}, hex("#f8fafc"));
}
static void drawPuck3() {
  Puck &P = SK->puck; double z = P.bz > 0 ? P.bz : 0;
  shadow(P.x, P.y, .7 + std::min(z, 4.0) * .1);
  objAt(P.x, P.y, z + .1); prism({P.x, P.y, z + .02}, .62, .34, 8, hex("#0b0b0b"), hex("#262626"));
}

// ---------------------------------------------------------------- on the ice: rings and aids (drawn under the players)
static void ringOn(double x, double y, double r, double w, double f, Col c, Col rest) {
  if (f > 0) iceArc(x, y, r, r + w, -PI / 2, -PI / 2 + f * 2 * PI, c, std::max(3, (int)(16 * f)), .05);
  if (f < 1) iceArc(x, y, r, r + w, -PI / 2 + f * 2 * PI, 1.5 * PI, rest, std::max(3, (int)(16 * (1 - f))), .05);
}
static void drawIceAids() {
  Puck &P = SK->puck; Skater *u = SK->user;
  for (Skater *p : skAll()) shadow(p->x, p->y, 1.5);
  for (int ti = 0; ti < 2; ti++) if (!SK->T[ti].g.out) shadow(SK->T[ti].g.x, SK->T[ti].g.y, 2);
  if (SK->phase != PH_GOAL) for (Skater *p : skAll()) { double f = std::round(clamp(p->st / 100, 0, 1) * 16) / 16; bool low = f <= .25 && std::sin(now() / 170) > 0;
    ringOn(p->x, p->y, 1.9, .3, f, (p->tired || p->st <= 0) ? hex("#ef4444") : low ? rgba(239, 68, 68, .85) : rgba(34, 197, 94, .85), rgba(0, 0, 0, .35)); }
  if (u && onTeam(0, u)) ringOn(u->x, u->y, 2.3, .35, 1, hex("#ffd54a"), hex("#ffd54a"));
  if (P.owner && P.owner != u) ringOn(P.owner->x, P.owner->y, 2.3, .25, 1, P.owner->team == 0 ? hex("#93c5fd") : hex("#fca5a5"), hex("#fff"));
  if (skBenchOpen()) { BenchSpot B = skBench(); double k = .5 + .5 * std::sin(now() / 170); iceDisc(B.x, B.y, B.r, rgba(34, 197, 94, (float)(.15 + .12 * k)), 20, .03); ringOn(B.x, B.y, B.r - .3, .4, 1, hex("#22c55e"), hex("#22c55e")); }
  // the shooting aim: a dotted line to where it's going
  if (u && P.owner == u && skInZone(u)) { bool none; Pt T = skATarget(u, SK->lastMx, SK->lastMy, none); if (none) T = {attackX(0), RK.cy};
    double dx = T.x - u->x, dy = T.y - u->y, L = hyp(dx, dy), nx = -dy / std::max(1e-3, L), ny = dx / std::max(1e-3, L); int n = (int)std::floor(L / 2.2);
    for (int k = 1; k < n; k += 2) { double a = (double)k / n, b = (k + .6) / n; quad({u->x + dx * a + nx * .12, u->y + dy * a + ny * .12, .05}, {u->x + dx * b + nx * .12, u->y + dy * b + ny * .12, .05}, {u->x + dx * b - nx * .12, u->y + dy * b - ny * .12, .05}, {u->x + dx * a - nx * .12, u->y + dy * a - ny * .12, .05}, rgba(226, 232, 240, .7), nullptr, 1, false, true); }
    const Goalie &g = SK->T[1].g; double open = g.out ? 1 : clamp((std::fabs(T.y - g.y) - .7) / 2.6, 0, 1);
    iceArc(T.x, T.y, .9, 1.15, 0, 2 * PI, open > .6 ? hex("#22c55e") : open > .3 ? hex("#eab308") : hex("#ef4444"), 14, .06); }
}

// ---------------------------------------------------------------- the frame
void skDraw3D() {
  cam3Update(); g_gpu = plat_gpu3d();
  drawArena();
  drawIceAids();
  g_refl = g_gpu;
  drawBoards();
  drawNet(0); drawNet(1);
  for (int ti = 0; ti < 2; ti++) drawGoalie3(SK->T[ti].g, ti);
  for (Skater *p : skAll()) drawSkater3(p);
  if (SK->hasRef) drawRef3();
  drawPuck3();
  g_refl = false;
  if (g_gpu) flushGPU(); else flushQ();
  // a goal: the red light over the net
  if (SK->phase == PH_GOAL && SK->hasNetIn) { double gx = SK->netIn.gx; Pt q = sk3Proj(gx < RK.L / 2 ? RK.gl - RK.netD : RK.L - RK.gl + RK.netD, RK.cy, 9); double k = .5 + .5 * std::sin(now() / 90), r = .012 * U;
    ctx.alpha(.3 + .35 * k); ctx.fill("#ff2d2d"); ctx.disc(q.x, q.y, r * (2.2 + k)); ctx.alpha(1); ctx.fill(k > .5 ? "#ff6b6b" : "#dc2626"); ctx.fillRect(q.x - r, q.y - r * .8, r * 2, r * 1.6); }
}

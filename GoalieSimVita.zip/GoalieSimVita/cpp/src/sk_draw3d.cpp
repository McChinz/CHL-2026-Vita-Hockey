#include <chrono>
// CHL 2026 native - the 3D view (first pass): a perspective broadcast camera behind the play, and the arena,
// nets, puck, skaters, goalies and the ref as low-poly lit models. Everything is projected here and drawn as
// flat-shaded triangles, back to front (no depth buffer on vita2d). The game itself is unchanged: same world
// (feet, x along the rink, y across, z up), same physics. SELECT switches between this and the classic view.
#include "game.h"
#include "sk_int.h"
#include <functional>
#include <cstdlib>

#include "tex_uv.h"
#include "tex_player.h"
#include "tex_arena.h"
#include <zlib.h>
bool g_view3d = true;
bool g_texOn = true;      // TEXTURES (settings): off = the plain shaded look, in case a Vita shows them wrongly
bool g_camHigh = false;   // CAMERA HIGH: the overhead view (attack straight up the screen); LOW: the broadcast view

// ---------------------------------------------------------------- the camera
// single precision: the Vita's CPU does floats far faster than doubles, and every triangle goes through these
struct V3 { float x, y, z; V3() : x(0), y(0), z(0) {} V3(double a, double b, double c) : x((float)a), y((float)b), z((float)c) {} };
static inline V3 operator+(V3 a, V3 b) { V3 o; o.x = a.x + b.x; o.y = a.y + b.y; o.z = a.z + b.z; return o; }
static inline V3 operator-(V3 a, V3 b) { V3 o; o.x = a.x - b.x; o.y = a.y - b.y; o.z = a.z - b.z; return o; }
static inline V3 operator*(V3 a, double k) { float f = (float)k; V3 o; o.x = a.x * f; o.y = a.y * f; o.z = a.z * f; return o; }
static inline double dot(V3 a, V3 b) { return (double)(a.x * b.x + a.y * b.y + a.z * b.z); }
static inline V3 cross(V3 a, V3 b) { V3 o; o.x = a.y * b.z - a.z * b.y; o.y = a.z * b.x - a.x * b.z; o.z = a.x * b.y - a.y * b.x; return o; }
static inline V3 norm(V3 a) { float l = std::sqrt(dot(a, a)); return l > 1e-9f ? a * (1 / l) : V3{0, 0, 1}; }
static struct { V3 e, f, r, u; double F, sx, sy; } C3;
static const double NEARZ = 4.0;   // the camera never gets closer than this; a larger near plane keeps depth precise far away (no flicker)
static void cam3Update() {
  // our own follow: the puck (or whoever has it), a little ahead of it, smoothed; ends kept in view
  static double fx = RK.L / 2, fy = RK.cy; static const Game *last = nullptr;
  double tx = RK.L / 2, ty = RK.cy;
  if (SK) { const Puck &P = SK->puck; tx = P.x + (P.owner ? std::cos(P.owner->ang) * 6 : 0); ty = P.y; if (SK->phase == PH_PREVIEW || SK->phase == PH_INTRO) tx = RK.L / 2; }
  static bool lastHigh = false; bool hi = g_camHigh;
#ifdef HOST_BUILD
  if (getenv("CHL_CAMHI")) hi = true;
#endif
  // HIGH: straight down over the play, the full width of the ice (both benches) in view; it runs right to each end,
  // so in your own zone your net sits at the bottom of the screen and in theirs at the top.
  // LOW: the NHL low camera - up above the end, about 40 degrees down; in your own zone it backs up over the end
  // boards so your net is near the bottom of the screen, in theirs the net and end boards fill the top.
  if (hi) { tx = clamp(tx + 1, 21, RK.L - 21); ty = RK.cy + (ty - RK.cy) * .15; }
  else { tx = clamp(tx - 6, 12, RK.L - 32); ty = RK.cy + (ty - RK.cy) * .3; }
  if (last != SK || lastHigh != hi) { fx = tx; fy = ty; last = SK; lastHigh = hi; } else { fx += (tx - fx) * .09; fy += (ty - fy) * (hi ? .08 : .06); }
  double cx = fx, cy = fy;
  V3 t;
  if (hi) { C3.e = {cx - 13, cy, 84}; t = {cx, cy, 0}; }             // overhead, tipped just a little toward the attack
  else { C3.e = {cx - 56, cy, 50}; t = {cx + 8, cy, 0}; }
  // a goal: the camera comes down and in on the scorer while he celebrates, then eases back for the faceoff
  { static double gk = 0; static V3 ge, gt; bool on = false;
    if (SK && SK->phase == PH_GOAL && SK->hasCel && SK->cel.sc) { for (Skater *q : skAll()) if (q == SK->cel.sc) on = true; }
    if (on) { const Skater *q = SK->cel.sc; double sg = tdir(SK->cel.team), sy = q->y < RK.cy ? 1 : -1;
      V3 e2 = {clamp(q->x - sg * 19, 6.0, RK.L - 6.0), clamp(q->y + sy * 9, 5.0, RK.Wd - 5.0), 8.5}, t2 = {q->x, q->y, 3.6};
      if (gk <= 0) { ge = e2; gt = t2; } else { ge = ge + (e2 - ge) * .12; gt = gt + (t2 - gt) * .2; } }
    gk = clamp(gk + (on ? .05 : -.07), 0, 1);
    if (gk > 0) { double k = gk * gk * (3 - 2 * gk); C3.e = C3.e + (ge - C3.e) * k; t = t + (gt - t) * k; } }
#ifdef HOST_BUILD
  if (const char *cs = getenv("CHL_CAM")) { double v[6]; if (sscanf(cs, "%lf,%lf,%lf,%lf,%lf,%lf", &v[0], &v[1], &v[2], &v[3], &v[4], &v[5]) == 6) { C3.e = {v[0], v[1], v[2]}; t = {v[3], v[4], v[5]}; } }   // tests: a close-up camera
  if (const char *cs = getenv("CHL_CAMSK")) { int i = 0; double dx = 10, dy = -10, dz = 6; sscanf(cs, "%d,%lf,%lf,%lf", &i, &dx, &dy, &dz); auto all = skAll(); if (SK && i < (int)all.size()) { Skater *q = all[i]; C3.e = {q->x + dx, q->y + dy, dz}; t = {q->x, q->y, getenv("CHL_CAMSKZ") ? atof(getenv("CHL_CAMSKZ")) : 3.4}; } }   // tests: close on one skater
  if (const char *cs = getenv("CHL_CAMG")) { int ti = 1; double dx = -14, dy = 0, dz = 4.5, tz = 4; sscanf(cs, "%d,%lf,%lf,%lf,%lf", &ti, &dx, &dy, &dz, &tz); if (SK) { const Goalie &q = SK->T[ti & 1].g; C3.e = {q.x + dx, q.y + dy, dz}; t = {q.x, q.y, tz}; } }   // tests: on a goalie
  if (getenv("CHL_CAMNEAR") && SK) { const Puck &P = SK->puck; double ox = atof(getenv("CHL_CAMNEAR")); C3.e = {P.x + ox, P.y - 16, 8}; t = {P.x, P.y, 2.5}; }   // tests: close on the puck
#endif
  C3.f = norm(t - C3.e); C3.r = norm(cross({0, 0, 1}, C3.f)); C3.u = cross(C3.f, C3.r);
  C3.F = W * .9; C3.sx = W / 2; C3.sy = H * .5 + .05 * U;
#ifdef HOST_BUILD
  if (getenv("CHL_ZOOM")) C3.F *= atof(getenv("CHL_ZOOM"));   // tests: a long lens for close-ups
#endif
}
static inline V3 toCam(V3 p) { V3 v = p - C3.e; return {dot(v, C3.r), dot(v, C3.u), dot(v, C3.f)}; }
static inline Pt camProj(V3 c) { return {C3.sx + c.x / c.z * C3.F, C3.sy - c.y / c.z * C3.F}; }
Pt sk3Proj(double x, double y, double z) { V3 c = toCam({x, y, z}); if (c.z < NEARZ) c.z = NEARZ; return camProj(c); }
double sk3Scale(double x, double y, double z) { V3 c = toCam({x, y, z}); return C3.F / std::max(NEARZ, (double)c.z); }

// ---------------------------------------------------------------- the triangle queue
struct Tri3 { float x[3], y[3]; uint32_t c; float od, td; };
static std::vector<Tri3> Q;          // sorted (back to front)
static double g_objDepth = 0;         // the object being built: its triangles sort together
static const V3 LIGHT = norm({-.35, .45, 1});
static V3 g_half = {0, 0, 1};   // the sheen's half vector (set per frame)
static Col litColAvg(uint32_t a, uint32_t b, uint32_t c) {
  auto ch = [&](int sh) { return (float)((((a >> sh) & 255) + ((b >> sh) & 255) + ((c >> sh) & 255)) / 3.0); };
  return Col(ch(0), ch(8), ch(16), ch(24) / 255.f);
}
static uint32_t litCol(Col c, V3 n, double a) {
  // a key light from above, a fill from the camera's side (so faces toward us never go muddy), a touch of sheen
  double key = std::max(0.0, dot(n, LIGHT)), fill = std::max(0.0, -dot(n, C3.f)), k = .5 + .38 * key + .3 * fill;
  double hv = std::max(0.0, dot(n, g_half)), h2 = hv * hv, h4 = h2 * h2, h8 = h4 * h4, sh = h8 * h4 * .35;
  Col o(std::min(255.0, c.r * k + 255 * sh), std::min(255.0, c.g * k + 255 * sh), std::min(255.0, c.b * k + 255 * sh), c.a * a); return o.pack();
}
// GPU path (vitaGL): world-space triangles by pass; the see-through ones are sorted back to front
static bool g_gpu = false;
static std::vector<V3c> GB[6];                       // 0 solid (arena), 1 painted on the ice, 2 reflections under the ice, 3 solid (people: their own texture),
                                                     // 4 pictures on people (numbers, crests, faces: see-through round the edges, so drawn after the solids without writing depth)
static int g_buf = 0;                                // where solid shapes go: 0 the arena, 3 people
static bool g_tex = false;                           // textures are loaded and switched on this frame
static bool g_refl = false;                          // what's being built shows in the ice (GPU path)
static bool g_keep = false;                          // building cached geometry: keep every face (no culling)
struct ATri { V3c v[3]; float d; }; static std::vector<ATri> GA;
// every vertex carries a texture coordinate; plain shapes point at a white patch (the same spot in both atlases)
static const float WU = (TP_WHITE.u0 + TP_WHITE.u1) / 2, WV = (TP_WHITE.v0 + TP_WHITE.v1) / 2;
static inline V3c vc(V3 p, uint32_t c) { V3c o; o.x = (float)p.x; o.y = (float)p.y; o.z = (float)p.z; o.c = c; o.u = WU; o.v = WV; return o; }
static inline V3c vt(V3 p, uint32_t c, float u, float v) { V3c o; o.x = (float)p.x; o.y = (float)p.y; o.z = (float)p.z; o.c = c; o.u = u; o.v = v; return o; }
// the textures: two atlases drawn by tools/make_textures.py and built into the app (zlib). The arena's is used as it is;
// the people's is kept at three sizes and the one that suits how big the players are on screen is used each frame
// (hand-made mip levels: far players would shimmer with the full-size one)
static int g_plod = 0;
static void texInit() {
  static bool done = false; if (done) return; done = true;
  std::vector<unsigned char> a((size_t)TEXA_W * TEXA_H * 4); uLongf len = (uLongf)a.size();
  if (uncompress(a.data(), &len, TEXA_Z, TEXA_Z_LEN) != Z_OK) return;
  plat_tex(0, TEXA_W, TEXA_H, a.data());
  len = (uLongf)a.size(); if (uncompress(a.data(), &len, TEXP_Z, TEXP_Z_LEN) != Z_OK) return;
  int w = TEXP_W, h = TEXP_H; plat_tex(1, w, h, a.data());
  for (int lv = 2; lv <= 3; lv++) { int w2 = w / 2, h2 = h / 2; std::vector<unsigned char> b((size_t)w2 * h2 * 4);
    for (int y = 0; y < h2; y++) for (int x = 0; x < w2; x++) { float acc[4] = {0, 0, 0, 0};   // (colour weighted by alpha, so see-through edges don't go dark)
        for (int k = 0; k < 4; k++) { const unsigned char *q = &a[((size_t)(y * 2 + (k >> 1)) * w + x * 2 + (k & 1)) * 4]; float al = q[3]; acc[0] += q[0] * al; acc[1] += q[1] * al; acc[2] += q[2] * al; acc[3] += al; }
        unsigned char *o = &b[((size_t)y * w2 + x) * 4]; if (acc[3] > 0) { o[0] = (unsigned char)(acc[0] / acc[3]); o[1] = (unsigned char)(acc[1] / acc[3]); o[2] = (unsigned char)(acc[2] / acc[3]); } else { o[0] = o[1] = o[2] = 255; } o[3] = (unsigned char)(acc[3] / 4); }
    plat_tex(lv, w2, h2, b.data()); a.swap(b); w = w2; h = h2; }
}
// geometry built once and kept (ice, crowd, nets) still has to be cut at the camera's near plane every frame: the GPU
// does not do that reliably, and a triangle reaching behind the camera turns into a long smeared strip on screen
static void appendClip(std::vector<V3c> &dst, const std::vector<V3c> &src);
// part of a picture: a sub-rectangle (fractions) of a sheet
static inline TexR cell(const TexR &r, double x0, double y0, double x1, double y1) { TexR o; o.u0 = (float)(r.u0 + (r.u1 - r.u0) * x0); o.u1 = (float)(r.u0 + (r.u1 - r.u0) * x1); o.v0 = (float)(r.v0 + (r.v1 - r.v0) * y0); o.v1 = (float)(r.v0 + (r.v1 - r.v0) * y1); return o; }
static bool decalC(V3 bl, V3 br, V3 tr, V3 tl, const TexR &r, uint32_t c, V3 n, int buf, bool cull = true);
// a convex polygon in world space: near-clipped, then either queued for the GPU or projected and fanned here.
// n: its outward normal (back faces skipped), or null for both sides; immediate: painted on the ice (drawn under
// everything standing on it)
static void poly(const V3 *p, int n, Col col, const V3 *nrm, double a = 1, bool lit = true, bool immediate = false) {
  if (n < 3) return;
  V3 cen = {0, 0, 0}; for (int i = 0; i < n; i++) cen = cen + p[i]; cen = cen * (1.0 / n);
  V3 N = nrm ? *nrm : norm(cross(p[1] - p[0], p[2] - p[0]));
  if (nrm && !g_keep && dot(N, cen - C3.e) >= 0) return;          // facing away
  if (!nrm && dot(N, cen - C3.e) > 0) N = N * -1;      // two-sided: light the side we see
  uint32_t c = lit ? litCol(col, N, a) : withA(col, (float)(col.a * a)).pack();
  // clip against the near plane (in front of the camera by NEARZ)
  V3 out[20]; int m = std::min(n, 16), k = 0;
  if (g_keep && g_gpu) { for (int i = 0; i < m; i++) out[k++] = p[i]; }   // geometry built once and kept: the GPU clips it each frame
  else for (int i = 0; i < m; i++) { V3 A = p[i], B = p[(i + 1) % m]; double da = dot(A - C3.e, C3.f) - NEARZ, db = dot(B - C3.e, C3.f) - NEARZ;
    if (da >= 0) out[k++] = A; if ((da >= 0) != (db >= 0)) { double t = da / (da - db); out[k++] = A + (B - A) * t; } }
  if (k < 3) return;
  double td = dot(cen - C3.e, C3.f);
  if (g_gpu) {
    bool see = (c >> 24) < 250;
    for (int i = 1; i + 1 < k; i++) {
      if (immediate) { GB[1].push_back(vc(out[0], c)); GB[1].push_back(vc(out[i], c)); GB[1].push_back(vc(out[i + 1], c)); }
      else if (see) { ATri t; t.v[0] = vc(out[0], c); t.v[1] = vc(out[i], c); t.v[2] = vc(out[i + 1], c); t.d = (float)td; GA.push_back(t); }
      else { GB[0].push_back(vc(out[0], c)); GB[0].push_back(vc(out[i], c)); GB[0].push_back(vc(out[i + 1], c));
        if (g_refl) { Col rc((float)((c & 255) * .78 + 8), (float)(((c >> 8) & 255) * .78 + 12), (float)(((c >> 16) & 255) * .78 + 20)); uint32_t r = rc.pack();
          for (V3 q : {out[0], out[i], out[i + 1]}) { q.z = -q.z; GB[2].push_back(vc(q, r)); } } }
    }
    return;
  }
  Pt s[20]; double minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9;
  for (int i = 0; i < k; i++) { V3 cc = toCam(out[i]); if (cc.z < NEARZ) cc.z = NEARZ; s[i] = camProj(cc); minX = std::min(minX, s[i].x); maxX = std::max(maxX, s[i].x); minY = std::min(minY, s[i].y); maxY = std::max(maxY, s[i].y); }
  if (maxX < 0 || minX > W || maxY < 0 || minY > H) return;
  for (int i = 1; i + 1 < k; i++) {
    if (immediate) ctx.rawTri(s[0].x, s[0].y, s[i].x, s[i].y, s[i + 1].x, s[i + 1].y, c);
    else { Tri3 t; t.x[0] = s[0].x; t.y[0] = s[0].y; t.x[1] = s[i].x; t.y[1] = s[i].y; t.x[2] = s[i + 1].x; t.y[2] = s[i + 1].y; t.c = c; t.od = (float)g_objDepth; t.td = (float)td; Q.push_back(t); }
  }
}
// the GPU's clip matrix for this camera: the same projection the CPU path uses (near 4 ft, far 500 ft)
static void clipMatrix(float *m) {
  const double n = NEARZ, f = 500, A = 2 * C3.F / W, B = 2 * C3.sx / W - 1, Cc = 2 * C3.F / H, D = 1 - 2 * C3.sy / H, E = (f + n) / (f - n), G = -2 * f * n / (f - n);
  // rows of P * V, V = [r; u; fwd] with -dot(axis, eye)
  const V3 R = C3.r, Uu = C3.u, Fw = C3.f, e = C3.e;
  double rows[4][4] = {
    {A * R.x + B * Fw.x, A * R.y + B * Fw.y, A * R.z + B * Fw.z, -A * dot(R, e) - B * dot(Fw, e)},
    {Cc * Uu.x + D * Fw.x, Cc * Uu.y + D * Fw.y, Cc * Uu.z + D * Fw.z, -Cc * dot(Uu, e) - D * dot(Fw, e)},
    {E * Fw.x, E * Fw.y, E * Fw.z, -E * dot(Fw, e) + G},
    {Fw.x, Fw.y, Fw.z, -dot(Fw, e)}};
  for (int c = 0; c < 4; c++) for (int r = 0; r < 4; r++) m[c * 4 + r] = (float)rows[r][c];
}
static void flushGPU() {
  ctx.flush();   // the 2D drawn so far (the backdrop) goes first
  float M[16]; clipMatrix(M);
  int ta = g_tex ? 0 : -1, tp = g_tex ? 1 + g_plod : -1;
  if (!GB[2].empty()) plat_draw3d(M, GB[2].data(), (int)GB[2].size(), 0, ta);   // the players, nets and boards mirrored under the ice
  if (!GB[0].empty()) plat_draw3d(M, GB[0].data(), (int)GB[0].size(), 0, ta);
  if (!GB[3].empty()) plat_draw3d(M, GB[3].data(), (int)GB[3].size(), 0, tp);
  if (!GB[1].empty()) plat_draw3d(M, GB[1].data(), (int)GB[1].size(), 1, ta);
  if (!GB[5].empty()) plat_draw3d(M, GB[5].data(), (int)GB[5].size(), 3, -1);   // cast shadows, over the ice and its paint
  if (!GB[4].empty()) plat_draw3d(M, GB[4].data(), (int)GB[4].size(), 1, tp);
  if (!GA.empty()) { std::sort(GA.begin(), GA.end(), [](const ATri &a, const ATri &b) { return a.d > b.d; });
    std::vector<V3c> v; v.reserve(GA.size() * 3); for (auto &t : GA) for (int i = 0; i < 3; i++) v.push_back(t.v[i]); plat_draw3d(M, v.data(), (int)v.size(), 2, ta); }
  GB[0].clear(); GB[1].clear(); GB[2].clear(); GB[3].clear(); GB[4].clear(); GB[5].clear(); GA.clear();
}
static void quad(V3 a, V3 b, V3 c, V3 d, Col col, const V3 *n, double al = 1, bool lit = true, bool imm = false) { V3 p[4] = {a, b, c, d}; poly(p, 4, col, n, al, lit, imm); }
static void flushQ() {
  std::sort(Q.begin(), Q.end(), [](const Tri3 &a, const Tri3 &b) { if (a.od != b.od) return a.od > b.od; return a.td > b.td; });
  for (auto &t : Q) ctx.rawTri(t.x[0], t.y[0], t.x[1], t.y[1], t.x[2], t.y[2], t.c);
  Q.clear();
}
static void objAt(double x, double y, double z = 0) { g_objDepth = toCam({x, y, z}).z; }

// ---------------------------------------------------------------- models: boxes in a local frame
// local frame: x forward, y to the left, z up; M = rotation (3 columns) + origin
struct M3 { V3 X, Y, Z, O; V3 ap(V3 p) const { return O + X * p.x + Y * p.y + Z * p.z; } V3 dir(V3 p) const { return X * p.x + Y * p.y + Z * p.z; } };
static M3 frameAt(double x, double y, double z, double yaw) { M3 m; m.X = {std::cos(yaw), std::sin(yaw), 0}; m.Y = {-std::sin(yaw), std::cos(yaw), 0}; m.Z = {0, 0, 1}; m.O = {x, y, z}; return m; }
// rotate the frame about its own y (pitch: + tips the top forward), x (roll: + tips toward -y), z (yaw)
static M3 pitch(M3 m, double a) { double c = std::cos(a), s = std::sin(a); M3 o = m; o.X = m.X * c + m.Z * -s; o.Z = m.X * s + m.Z * c; return o; }
static M3 roll(M3 m, double a) { double c = std::cos(a), s = std::sin(a); M3 o = m; o.Y = m.Y * c + m.Z * s; o.Z = m.Y * -s + m.Z * c; return o; }
static M3 moveTo(M3 m, V3 p) { m.O = m.ap(p); return m; }
static M3 yawFrame(V3 p, double yaw) { return frameAt(p.x, p.y, p.z, yaw); }
// a box: center c, half sizes h, in frame m
// a box hanging from a joint: from the joint down its own -z by len
// an n-sided prism standing on z (puck, posts)
static void prism(V3 c, double r, double h, int n, Col side, Col top) {
  std::vector<V3> b(n), t(n);
  for (int i = 0; i < n; i++) { double a = i * 2 * PI / n; b[i] = {c.x + std::cos(a) * r, c.y + std::sin(a) * r, c.z}; t[i] = b[i] + V3{0, 0, h}; }
  for (int i = 0; i < n; i++) { int j = (i + 1) % n; double a = (i + .5) * 2 * PI / n; V3 nn = {std::cos(a), std::sin(a), 0}; quad(b[i], b[j], t[j], t[i], side, &nn); }
  V3 up = {0, 0, 1}; poly(t.data(), std::min(n, 16), top, &up);
}
// a flat disc / ring on the ice, drawn now (under everything standing on it)
static void iceDisc(double x, double y, double r, Col c, int n = 12, double z = .03) {
  std::vector<V3> p(n); for (int i = 0; i < n; i++) { double a = i * 2 * PI / n; p[i] = {x + std::cos(a) * r, y + std::sin(a) * r, z}; } poly(p.data(), n, c, nullptr, 1, false, true);
}
static void iceArc(double x, double y, double r0, double r1, double a0, double a1, Col c, int n = 20, double z = .02) {
  for (int i = 0; i < n; i++) { double u0 = a0 + (a1 - a0) * i / n, u1 = a0 + (a1 - a0) * (i + 1) / n;
    quad({x + std::cos(u0) * r0, y + std::sin(u0) * r0, z}, {x + std::cos(u1) * r0, y + std::sin(u1) * r0, z}, {x + std::cos(u1) * r1, y + std::sin(u1) * r1, z}, {x + std::cos(u0) * r1, y + std::sin(u0) * r1, z}, c, nullptr, 1, false, true); }
}
static void iceRect(double x0, double y0, double x1, double y1, Col c, double z = .02) { quad({x0, y0, z}, {x1, y0, z}, {x1, y1, z}, {x0, y1, z}, c, nullptr, 1, false, true); }

// ---------------------------------------------------------------- the arena
// the rink's outline (rounded corners), counter-clockwise
static const std::vector<Pt> &rinkOutline() {
  static std::vector<Pt> o; if (!o.empty()) return o;
  const double L = RK.L, Wd = RK.Wd, r = RK.cr; const int n = 8;
  auto corner = [&](double cx, double cy, double a0) { for (int i = 0; i <= n; i++) { double a = a0 + i * (PI / 2) / n; o.push_back({cx + std::cos(a) * r, cy + std::sin(a) * r}); } };
  corner(L - r, r, -PI / 2); corner(L - r, Wd - r, 0); corner(r, Wd - r, PI / 2); corner(r, r, PI);
  // the long straight sides in pieces (so the boards sort well against the players)
  std::vector<Pt> f; for (size_t i = 0; i < o.size(); i++) { Pt a = o[i], b = o[(i + 1) % o.size()]; double d = hyp(b.x - a.x, b.y - a.y); int k = std::max(1, (int)std::ceil(d / 10));
    for (int j = 0; j < k; j++) f.push_back({a.x + (b.x - a.x) * j / k, a.y + (b.y - a.y) * j / k}); }
  o = f; return o;
}
static void drawCrowd() {
  // stands: rows rising away from the boards, a colour per seat block (fixed)
  static const char *shirts[12] = {"#ef4444", "#f8fafc", "#3b82f6", "#facc15", "#64748b", "#1e293b", "#f97316", "#22c55e", "#e2e8f0", "#7c3aed", "#dc2626", "#0ea5e9"};
  const auto &O = rinkOutline(); size_t n = O.size(); double cx = RK.L / 2, cy = RK.cy;
  for (size_t i = 0; i < n; i++) {
    Pt a = O[i], b = O[(i + 1) % n]; double ex = (a.x + b.x) / 2 - cx, ey = (a.y + b.y) / 2 - cy;
    double ox = b.y - a.y, oy = -(b.x - a.x), ol = hyp(ox, oy); ox /= ol; oy /= ol; if (ox * ex + oy * ey < 0) { ox = -ox; oy = -oy; }   // outward
    V3 on = {-ox, -oy, .9}; on = norm(on);
    objAt((a.x + b.x) / 2 + ox * 30, (a.y + b.y) / 2 + oy * 30, 20);
    for (int r = 0; r < 6; r++) {
      double d0 = 6 + r * 4.2, d1 = d0 + 4.2, z0 = 6 + r * 2.6, z1 = z0 + 2.6;
      SkRng R((int)(i * 31 + r * 7 + 3)); Col c = hex(R() < .5 ? shirts[(int)(R() * 12) % 12] : (r % 2 ? "#273449" : "#1f2a3d"));
      quad({a.x + ox * d0, a.y + oy * d0, z0}, {b.x + ox * d0, b.y + oy * d0, z0}, {b.x + ox * d1, b.y + oy * d1, z1}, {a.x + ox * d1, a.y + oy * d1, z1}, c, &on);
      V3 rn = {-ox, -oy, 0}; quad({a.x + ox * d1, a.y + oy * d1, z0}, {b.x + ox * d1, b.y + oy * d1, z0}, {b.x + ox * d1, b.y + oy * d1, z1}, {a.x + ox * d1, a.y + oy * d1, z1}, hex("#151c2b"), &rn);
    }
  }
}
// the GPU crowd: tiered seating with rows of fans (a shirt and a head each, a good share in the home colours),
// built once per game and kept - depth-tested with everything else, and no CPU cost per frame
static void appendClip(std::vector<V3c> &dst, const std::vector<V3c> &src) {
  const float ex = (float)C3.e.x, ey = (float)C3.e.y, ez = (float)C3.e.z, fx = (float)C3.f.x, fy = (float)C3.f.y, fz = (float)C3.f.z, nz = (float)NEARZ;
  auto dep = [&](const V3c &v) { return (v.x - ex) * fx + (v.y - ey) * fy + (v.z - ez) * fz - nz; };
  auto mix = [](const V3c &a, const V3c &b, float t) { V3c o; o.x = a.x + (b.x - a.x) * t; o.y = a.y + (b.y - a.y) * t; o.z = a.z + (b.z - a.z) * t; uint32_t c = 0;
    for (int k = 0; k < 32; k += 8) { float ca = (a.c >> k) & 255, cb = (b.c >> k) & 255; c |= (uint32_t)(ca + (cb - ca) * t + .5f) << k; } o.c = c; o.u = a.u + (b.u - a.u) * t; o.v = a.v + (b.v - a.v) * t; return o; };
  dst.reserve(dst.size() + src.size());
  for (size_t i = 0; i + 2 < src.size(); i += 3) {
    const V3c *v = &src[i]; float d[3] = {dep(v[0]), dep(v[1]), dep(v[2])};
    if (d[0] >= 0 && d[1] >= 0 && d[2] >= 0) { dst.push_back(v[0]); dst.push_back(v[1]); dst.push_back(v[2]); continue; }
    if (d[0] < 0 && d[1] < 0 && d[2] < 0) continue;
    V3c out[4]; int k = 0;
    for (int j = 0; j < 3; j++) { int n = (j + 1) % 3; if (d[j] >= 0) out[k++] = v[j]; if ((d[j] >= 0) != (d[n] >= 0)) out[k++] = mix(v[j], v[n], d[j] / (d[j] - d[n])); }
    for (int j = 1; j + 1 < k; j++) { dst.push_back(out[0]); dst.push_back(out[j]); dst.push_back(out[j + 1]); }
  }
}
// The stands, full to the rafters: a lower bowl that starts right behind the glass (behind the benches where they
// are), a lit ribbon board round the arena, an upper bowl above it and a dark wall up to the roof. With textures the
// bowls are pictures of a packed crowd (a handful of triangles instead of thousands); without, rows of plain fans.
static void drawCrowdPlain();
static void drawCrowdGeo() {
  if (!g_tex) { drawCrowdPlain(); return; }
  const auto &O = rinkOutline(); size_t n = O.size(); double cx = RK.L / 2, cy = RK.cy; double cum = 0;
  uint32_t wh = Col(255, 255, 255, 1).pack(), dim = Col(205, 210, 222, 1).pack(), wall = hex("#0c111c").pack(), ledge = hex("#1a2130").pack(), conc = hex("#111723").pack();
  auto flat = [&](V3 a, V3 b, V3 c, V3 d, uint32_t col) { GB[0].push_back(vc(a, col)); GB[0].push_back(vc(b, col)); GB[0].push_back(vc(c, col)); GB[0].push_back(vc(a, col)); GB[0].push_back(vc(c, col)); GB[0].push_back(vc(d, col)); };
  // each outline point's own way out (the mitre of its two edges), so the stands meet at the corners with no gaps
  std::vector<Pt> EN(n), VN(n);
  for (size_t i = 0; i < n; i++) { Pt a = O[i], b = O[(i + 1) % n]; double ex = (a.x + b.x) / 2 - cx, ey = (a.y + b.y) / 2 - cy;
    double ox = b.y - a.y, oy = -(b.x - a.x), ol = hyp(ox, oy); ox /= ol; oy /= ol; if (ox * ex + oy * ey < 0) { ox = -ox; oy = -oy; } EN[i] = {ox, oy}; }
  for (size_t i = 0; i < n; i++) { Pt p = EN[(i + n - 1) % n], q = EN[i]; double mx = p.x + q.x, my = p.y + q.y, ml = hyp(mx, my); if (ml < 1e-6) { mx = q.x; my = q.y; ml = 1; } mx /= ml; my /= ml;
    double k = 1 / std::max(.5, mx * q.x + my * q.y); VN[i] = {mx * k, my * k}; }
  for (size_t i = 0; i < n; i++) {
    Pt a = O[i], b = O[(i + 1) % n]; double ox = EN[i].x, oy = EN[i].y; Pt na = VN[i], nb = VN[(i + 1) % n];
    double len = hyp(b.x - a.x, b.y - a.y); V3 fn = {-ox, -oy, 0};
    // behind the benches the first rows give way to the bench itself
    bool bench = oy > .9 && (a.x + b.x) / 2 > RK.L / 2 - 43 && (a.x + b.x) / 2 < RK.L / 2 + 43;
    double d0 = bench ? 7.2 : 1.3, z0 = bench ? 6.9 : SK_BH + .4, d1 = 27, z1 = 21.5, d2 = 52, z2 = 42;
    auto P = [&](const Pt &q, double d, double z) { Pt m = (&q == &a) ? na : nb; return V3{q.x + m.x * d, q.y + m.y * d, z}; };
    auto band = [&](double da, double za, double db, double zb, const TexR &r, double tile, double vTop, double vBot, uint32_t col) {
      double u0 = cum / tile; u0 -= std::floor(u0); double du = len / tile; if (u0 + du > 1) u0 = 1 - du;
      decalC(P(a, da, za), P(b, da, za), P(b, db, zb), P(a, db, zb), cell(r, u0, vTop, u0 + du, vBot), col, fn, 0, false); };
    if (!bench) flat(P(a, .45, SK_BH - .2), P(b, .45, SK_BH - .2), P(b, d0, z0), P(a, d0, z0), ledge);            // the ledge behind the glass
    else flat(P(a, 6.4, 0), P(b, 6.4, 0), P(b, d0, z0), P(a, d0, z0), wall);
    band(d0, z0, d1, z1, TA_CROWD, 58, bench ? .22 : 0, 1, wh);                                                   // the lower bowl
    band(d1, z1, d1, z1 + 2.6, TA_RIBBON, 62, 0, 1, wh);                                                           // the ribbon board
    band(d1, z1 + 2.6, d2, z2, TA_UPPER, 76, 0, 1, dim);                                                          // the upper bowl
    flat(P(a, d2, z2), P(b, d2, z2), P(b, d2, z2 + 30), P(a, d2, z2 + 30), wall);                                  // up to the roof
    flat(P(a, .45, -.5), P(b, .45, -.5), P(b, .45, SK_BH - .2), P(a, .45, SK_BH - .2), conc);                      // (behind the boards)
    cum += len;
  }
}
static void drawCrowdPlain() {
  static const char *shirts[10] = {"#f8fafc", "#1e293b", "#64748b", "#facc15", "#3b82f6", "#ef4444", "#22c55e", "#f97316", "#cbd5e1", "#7c3aed"};
  static const char *skins[4] = {"#f1c6a5", "#d9a47c", "#a8714f", "#6b4630"};
  Col home = SK ? SK->T[0].col : hex("#2563eb"), homeS = SK ? SK->T[0].stripe : hex("#f8fafc"), away = SK ? SK->T[1].col : hex("#dc2626");
  const auto &O = rinkOutline(); size_t n = O.size(); double cx = RK.L / 2, cy = RK.cy; V3 up = {0, 0, 1};
  for (size_t i = 0; i < n; i++) {
    Pt a = O[i], b = O[(i + 1) % n]; double ex = (a.x + b.x) / 2 - cx, ey = (a.y + b.y) / 2 - cy;
    double ox = b.y - a.y, oy = -(b.x - a.x), ol = hyp(ox, oy); ox /= ol; oy /= ol; if (ox * ex + oy * ey < 0) { ox = -ox; oy = -oy; }
    double sx = b.x - a.x, sy = b.y - a.y, sl = hyp(sx, sy); V3 fn = {-ox, -oy, 0};
    for (int r = 0; r < 6; r++) {
      double d0 = 6 + r * 3.6, d1 = d0 + 3.6, z0 = 5.5 + r * 2.4, z1 = z0 + 2.4;
      Col step = hex(r % 2 ? "#1b2333" : "#202a3c"), rise = hex("#121826");
      quad({a.x + ox * d0, a.y + oy * d0, z0}, {b.x + ox * d0, b.y + oy * d0, z0}, {b.x + ox * d1, b.y + oy * d1, z0}, {a.x + ox * d1, a.y + oy * d1, z0}, step, &up);
      quad({a.x + ox * d1, a.y + oy * d1, z0}, {b.x + ox * d1, b.y + oy * d1, z0}, {b.x + ox * d1, b.y + oy * d1, z1}, {a.x + ox * d1, a.y + oy * d1, z1}, rise, &fn);
      int m = std::max(1, (int)(sl / 2.3)); SkRng R((int)(i * 131 + r * 17 + 5));
      for (int k = 0; k < m; k++) { if (R() < .12) continue;   // an empty seat here and there
        double t = (k + .5 + (R() - .5) * .35) / m, px = a.x + sx * t + ox * (d0 + 1.6), py = a.y + sy * t + oy * (d0 + 1.6), w = .65, h = 1.5 + R() * .35;
        double q = R(); Col sh = q < .38 ? home : q < .46 ? homeS : q < .55 ? away : hex(shirts[(int)(R() * 10) % 10]);
        double tx = sx / sl * w, ty = sy / sl * w;
        quad({px - tx, py - ty, z0}, {px + tx, py + ty, z0}, {px + tx * .9, py + ty * .9, z0 + h}, {px - tx * .9, py - ty * .9, z0 + h}, sh, &fn);   // the shirt
        double hz = z0 + h, hs = .38; Col sk = hex(skins[(int)(R() * 4) % 4]);
        quad({px - tx * .55, py - ty * .55, hz}, {px + tx * .55, py + ty * .55, hz}, {px + tx * .55, py + ty * .55, hz + hs * 2}, {px - tx * .55, py - ty * .55, hz + hs * 2}, sk, &fn); } }
  }
}
static void drawCrowd3() {
  static std::vector<V3c> C; static const Game *cg = nullptr; static uint32_t ck = 0; uint32_t key = (SK ? SK->T[0].col.pack() * 7u ^ SK->T[1].col.pack() : 0) + (g_tex ? 1 : 0);
  if (cg != SK || ck != key || C.empty()) { size_t b0 = GB[0].size(); bool kk = g_keep, kr = g_refl; g_keep = true; g_refl = false; drawCrowdGeo(); g_keep = kk; g_refl = kr;
    C.assign(GB[0].begin() + b0, GB[0].end()); GB[0].resize(b0); cg = SK; ck = key; }
  appendClip(GB[0], C);
}
static void drawIceGeo() {
  const auto &O = rinkOutline(); std::vector<V3> p; for (auto &q : O) p.push_back({q.x, q.y, 0});
  // the ice as a fan (convex), drawn in slices so the near-plane clip stays small
  V3 c = {RK.L / 2, RK.cy, 0}; Col ice = hex("#e9f1f8");
  if (g_gpu) {   // polished ice: a floor well under it, the reflections in between, the ice itself a little see-through
    Col fl = hex("#cfdbe8"); quad({-40, -40, -16}, {RK.L + 40, -40, -16}, {RK.L + 40, RK.Wd + 40, -16}, {-40, RK.Wd + 40, -16}, fl, nullptr, 1, false);
    ice = withA(ice, .72f); }
  for (size_t i = 0; i < p.size(); i++) { V3 t[3] = {c, p[i], p[(i + 1) % p.size()]}; poly(t, 3, ice, nullptr, 1, false, true); }
  const double L = RK.L, Wd = RK.Wd, cy = RK.cy, gl = RK.gl;
  Col red = hex("#d43a3a"), blue = hex("#2f5fc4"), crease = hex("#8fb8f0");
  iceRect(L / 2 - .5, 0.6, L / 2 + .5, Wd - .6, red);
  for (double bx : {L / 2 - SK_BLUE / 2 - 0.0, L / 2 + SK_BLUE / 2}) iceRect(bx - .5, .6, bx + .5, Wd - .6, blue);
  for (double gx : {gl, L - gl}) iceRect(gx - .15, 3.5, gx + .15, Wd - 3.5, red);
  iceArc(L / 2, cy, 14.6, 15, 0, 2 * PI, blue, 32); iceDisc(L / 2, cy, .7, blue, 10);
  for (double fx : {gl + 20, L - gl - 20}) for (double fy : {cy - 22, cy + 22}) { iceArc(fx, fy, 14.6, 15, 0, 2 * PI, red, 28); iceDisc(fx, fy, 1, red, 10); }
  for (double fx : {L / 2 - SK_BLUE / 2 + 5, L / 2 + SK_BLUE / 2 - 5}) for (double fy : {cy - 22, cy + 22}) iceDisc(fx, fy, 1, red, 10);
  // the goal creases: filled light blue, edged in red, ending at the posts
  for (int e = 0; e < 2; e++) { double gx = e ? L - gl : gl, d = e ? -1 : 1, X[16], Y[16]; int n = creaseOutline(X, Y);
    for (int i = 0; i + 1 < n; i++) { V3 t[3] = {{gx, cy, .02}, {gx + d * X[i], cy + Y[i], .02}, {gx + d * X[i + 1], cy + Y[i + 1], .02}}; poly(t, 3, crease, nullptr, 1, false, true); }
    for (int i = 0; i + 1 < n; i++) { double ax = X[i], ay = Y[i], bx = X[i + 1], by = Y[i + 1], ex = bx - ax, ey = by - ay, l = std::max(1e-6, hyp(ex, ey)), nx = -ey / l * .25, ny = ex / l * .25;
      if (nx * ((ax + bx) / 2) + ny * ((ay + by) / 2) > 0) { nx = -nx; ny = -ny; }   // (the line's width goes in, toward the net)
      quad({gx + d * ax, cy + ay, .025}, {gx + d * bx, cy + by, .025}, {gx + d * (bx + nx), cy + by + ny, .025}, {gx + d * (ax + nx), cy + ay + ny, .025}, red, nullptr, 1, false, true); } }
  // the NHL details: the crease outline, hash marks and L's at the end-zone circles, the trapezoid behind each net,
  // the referee's crease, and the home team's logo disc at centre ice
  for (double fx : {gl + 20, L - gl - 20}) for (double fy : {cy - 22, cy + 22}) {
    for (double sx : {-1.0, 1.0}) for (double sy : {-1.0, 1.0}) {
      iceRect(fx + sx * 1.5 - .1, fy + sy * 15, fx + sx * 1.5 + .1, fy + sy * 17, red, .025);                 // hash marks
      double ax = fx + sx * 2, ay = fy + sy * .75;                                                             // the L's around the dot
      iceRect(std::min(ax, ax + sx * 4), ay - .1, std::max(ax, ax + sx * 4), ay + .1, red, .025);
      iceRect(ax - .1, std::min(ay, ay + sy * 3), ax + .1, std::max(ay, ay + sy * 3), red, .025); } }
  for (int e = 0; e < 2; e++) { double gx = e ? L - gl : gl, bk = e ? L - .8 : .8; for (double sy : {-1.0, 1.0}) {   // the trapezoid
      double y0 = cy + sy * 11, y1 = cy + sy * 14; V3 a = {gx, y0, .025}, b = {bk, y1, .025}, n = {0, sy * .1, 0};
      quad(a - n, b - n, b + n, a + n, red, nullptr, 1, false, true); } }
  iceArc(L / 2, .7, 9.6, 10, 0, PI, red, 14, .025);                                                            // the referee's crease
  if (g_tex) {
    // what the skates have done to the ice: a see-through layer of fine cuts (tiles; left off where a tile would poke past a corner)
    auto inside = [&](double x, double y) { double r = RK.cr, qx = std::max(0.0, std::max(r - x, x - (L - r))), qy = std::max(0.0, std::max(r - y, y - (Wd - r))); return qx * qx + qy * qy <= (r - .5) * (r - .5) && x > .5 && x < L - .5 && y > .5 && y < Wd - .5; };
    const int NX = 16, NY = 7; double tw = L / NX, th = Wd / NY; uint32_t wh = Col(255, 255, 255, .8f).pack(); V3 up = {0, 0, 1};
    for (int ix = 0; ix < NX; ix++) for (int iy = 0; iy < NY; iy++) { double x0 = ix * tw, y0 = iy * th, x1 = x0 + tw, y1 = y0 + th;
      if (!inside(x0, y0) || !inside(x1, y0) || !inside(x1, y1) || !inside(x0, y1)) continue;
      double u0 = (ix % 2) * .5, v0 = (iy % 2) * .5; decalC({x0, y0, .022}, {x0, y1, .022}, {x1, y1, .022}, {x1, y0, .022}, cell(TA_SCRATCH, v0, u0, v0 + .5, u0 + .5), wh, up, 1, false); }
    // sponsors painted under the ice (invented names), reading the way the cameras look: up the rink
    static const double AX[4] = {-52, -17.5, 17.5, 52}; uint32_t ad = Col(255, 255, 255, .5f).pack();
    for (int k = 0; k < 4; k++) { double ax = L / 2 + AX[k], hw = 13, hh = 1.9;
      decalC({ax - hh, cy - hw, .024}, {ax - hh, cy + hw, .024}, {ax + hh, cy + hw, .024}, {ax + hh, cy - hw, .024}, cell(TA_ICEADS, 0, k * .25, 1, k * .25 + .25), ad, up, 1, false); }
    // the league's emblem at centre ice
    { double r = 8.2; decalC({L / 2 - r, cy - r, .03}, {L / 2 - r, cy + r, .03}, {L / 2 + r, cy + r, .03}, {L / 2 + r, cy - r, .03}, TA_LOGO, Col(255, 255, 255, 1).pack(), up, 1, false); }
  } else
  if (SK) { const Team &H = SK->T[0]; Col hc = H.col, hs = H.stripe;   // (opaque: see-through decals would sort against the polished ice)
    iceArc(L / 2, cy, 2.2, 7.5, 0, 2 * PI, hc, 24, .028); iceArc(L / 2, cy, 6.2, 6.9, 0, 2 * PI, hs, 24, .029);
    iceArc(L / 2, cy, 1.4, 2.2, 0, 2 * PI, hs, 12, .029); iceArc(L / 2, cy, 0, 1.4, 0, 2 * PI, hc, 10, .029); }
}
// the ice and all its markings never change during a game: on the GPU it's built once and reused every frame
static void drawIce() {
  if (!g_gpu) { drawIceGeo(); return; }
#ifdef HOST_BUILD
  if (getenv("CHL_NOICECACHE")) { drawIceGeo(); return; }
#endif
  static std::vector<V3c> C0, C1; static const Game *cg = nullptr; static uint32_t ck = 0; uint32_t key = (SK ? SK->T[0].col.pack() ^ (SK->T[0].stripe.pack() * 31u) : 0) + (g_tex ? 1 : 0);
  if (cg != SK || ck != key || C1.empty()) { size_t b0 = GB[0].size(), b1 = GB[1].size(); bool kk = g_keep; g_keep = true; drawIceGeo(); g_keep = kk;
    C0.assign(GB[0].begin() + b0, GB[0].end()); C1.assign(GB[1].begin() + b1, GB[1].end()); GB[0].resize(b0); GB[1].resize(b1); cg = SK; ck = key;
#ifdef HOST_BUILD
    if (getenv("CHL_PROF")) fprintf(stderr, "ICE cache %zu %zu (GA %zu)\n", C0.size(), C1.size(), GA.size());
#endif
  }
  appendClip(GB[0], C0); appendClip(GB[1], C1);
}
// the arena lights reflected in the polished ice: each light in the roof shows up where the ice mirrors it toward the
// camera - soft white glows, stretched toward you, that slide across the ice as the camera moves (like the real thing)
static void drawIceLights() {
  static const double LX[4] = {.16, .39, .61, .84}, LY[2] = {.27, .73}; const double LZ = 70; V3 E = C3.e;
  for (double fx : LX) for (double fy : LY) {
    V3 Lp = {RK.L * fx, RK.Wd * fy, -LZ}; double t = E.z / (E.z + LZ); V3 P = E + (Lp - E) * t; P.z = .035;
    if (P.x < 4 || P.x > RK.L - 4 || P.y < 4 || P.y > RK.Wd - 4) continue;
    double dx = P.x - E.x, dy = P.y - E.y, dl = hyp(dx, dy); V3 ua = dl > 1 ? V3{dx / dl, dy / dl, 0} : V3{1, 0, 0}, ub = {-ua.y, ua.x, 0};
    double a = 4.5 + dl * .06, b = 2.6; const int N = 16;
    for (int layer = 0; layer < 3; layer++) { double k = 1 - layer * .3; Col c = rgba(255, 255, 255, .09 + layer * .04);
      for (int i = 0; i < N; i++) { double a0 = 2 * PI * i / N, a1 = 2 * PI * (i + 1) / N;
        V3 tri[3] = {P, P + ua * (std::cos(a0) * a * k) + ub * (std::sin(a0) * b * k), P + ua * (std::cos(a1) * a * k) + ub * (std::sin(a1) * b * k)};
        poly(tri, 3, c, nullptr, 1, false, true); } }
  }
}
static void drawBoards() {
  const auto &O = rinkOutline(); size_t n = O.size(); double cx = RK.L / 2, cy = RK.cy;
  for (size_t i = 0; i < n; i++) {
    Pt a = O[i], b = O[(i + 1) % n]; double mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
    V3 in = norm({cx - mx, (cy - my) * 2.3, 0});
    objAt(mx, my, 1);
    quad({a.x, a.y, 0}, {b.x, b.y, 0}, {b.x, b.y, SK_BH}, {a.x, a.y, SK_BH}, hex("#f8fafc"), nullptr);            // the boards
    { V3 k = norm(V3{in.x, in.y, 0}) * .06; V3 a0 = V3{a.x, a.y, 0} + k, b0 = V3{b.x, b.y, 0} + k;      // kick plate: a hair in front of the boards (the same plane flickered)
      quad(a0, b0, b0 + V3{0, 0, .9}, a0 + V3{0, 0, .9}, hex("#f2c230"), nullptr); }
    if (g_tex && hyp(b.x - a.x, b.y - a.y) > 8) { V3 k = norm(V3{in.x, in.y, 0}) * .07; int ad = (int)((i * 5 + 3) % 8);   // (seen from inside the rink: left to right)
      V3 pa = V3{a.x, a.y, 0} + k, pb = V3{b.x, b.y, 0} + k; bool flip = dot(cross(V3{b.x - a.x, b.y - a.y, 0}, V3{0, 0, 1}), in) > 0; if (flip) std::swap(pa, pb);
      decalC(pa + V3{0, 0, 1.0}, pb + V3{0, 0, 1.0}, pb + V3{0, 0, SK_BH - .2}, pa + V3{0, 0, SK_BH - .2}, cell(TA_ADS, (ad % 4) * .25, (ad / 4) * .5, (ad % 4) * .25 + .25, (ad / 4) * .5 + .5), Col(250, 250, 250, 1).pack(), k, 0, false); }
    V3 o = in * -.5; V3 up = {0, 0, 1};
    quad({a.x, a.y, SK_BH}, {b.x, b.y, SK_BH}, V3{b.x, b.y, SK_BH} + o, V3{a.x, a.y, SK_BH} + o, hex("#d43a3a"), &up);   // the top rail
    quad({a.x, a.y, SK_BH}, {b.x, b.y, SK_BH}, {b.x, b.y, SK_BH + 5.5}, {a.x, a.y, SK_BH + 5.5}, rgba(200, 225, 245, .16), nullptr, 1, false);   // glass
  }
}
// the far end banners and the scoreboard lights (simple)
static void drawArena() {
  ctx.fill("#0e1422"); ctx.fillRect(0, 0, W, H);
  Grad g = gLin(0, 0, 0, H * .45); g.add(0, hex("#060a14")); g.add(1, hex("#18213a")); ctx.fill(g); ctx.fillRect(0, 0, W, H * .45);
  if (g_gpu) drawCrowd3(); else { drawCrowd(); flushQ(); }
  drawIce();
  if (g_gpu) drawIceLights();
}

// ---------------------------------------------------------------- smooth shapes (Gouraud: a lit colour per corner)
// heights in the 3D view are drawn 1.7x the physics' (players, nets and the puck are NHL Hitz-sized; the puck's
// flight and the crossbar line up with what the game decides)
static const double VZ = 1.7;
// level of detail: 1 near the camera, down to about .45 far away (fewer sides on every round shape, no reflection)
static double g_lod = 1;
static double lodFor(double x, double y, double z) { double dpt = dot(V3{x, y, z} - C3.e, C3.f); return clamp(48 / std::max(1.0, dpt), .45, 1); }
// is something standing at (x, y) anywhere near the picture? (whole models are skipped when it isn't)
static bool nearView(double x, double y, double z, double r) {
  V3 c = toCam({x, y, z}); if (c.z < NEARZ - r) return false; double zz = std::max(NEARZ, (double)c.z), m = r * C3.F / zz; Pt q = camProj({c.x, c.y, (float)zz});
  return q.x > -m && q.x < W + m && q.y > -m && q.y < H + m;
}
// ---------------------------------------------------------------- shading: worked out once per VERTEX, not per corner
// A PS2-style light rig in vertex colours: a key light from the rafters, a soft fill from the camera, light bouncing up
// off the ice, a rim of light around every silhouette, and a highlight whose strength is the material's gloss
// (helmets and masks shine, cloth barely does). k scales the colour, s adds white.
struct Lt { float k, s; };
static float g_gloss = .3f;
static inline Lt lightAt(V3 n) {
  float key = std::max(0.f, (float)dot(n, LIGHT)), fc = (float)-dot(n, C3.f), fill = std::max(0.f, fc), hemi = .5f + .5f * n.z;
  float k = .36f + .16f * hemi + .40f * key + .22f * fill;
  float hv = std::max(0.f, (float)dot(n, g_half)), h2 = hv * hv, h4 = h2 * h2, h8 = h4 * h4, sh = h8 * h4 * g_gloss;
  float rm = 1 - std::min(1.f, std::fabs(fc)); rm = rm * rm * rm * (.07f + .13f * hemi);
  Lt o; o.k = k; o.s = sh + rm; return o;
}
static inline uint32_t litV(const Col &c, Lt l, float ao = 1) {
  float k = l.k * ao, s = 255 * l.s * ao; Col o(std::min(255.f, c.r * k + s), std::min(255.f, c.g * k + s), std::min(255.f, c.b * k + s), c.a); return o.pack();
}
// one shaded triangle whose corners are already lit; nn: its outward side (for culling); t: texture coordinates (or null)
static void striT(V3 a, V3 b, V3 c, uint32_t ca, uint32_t cb, uint32_t cc, V3 nn, const float *t) {
  if (!g_keep) { V3 cen = (a + b + c) * (1.0 / 3); if (dot(nn, cen - C3.e) > 0) return;    // facing away (convex shapes)
    if (dot(a - C3.e, C3.f) < NEARZ || dot(b - C3.e, C3.f) < NEARZ || dot(c - C3.e, C3.f) < NEARZ) return; }
  if (g_gpu) {
    std::vector<V3c> &B = GB[g_buf];
    if (t) { B.push_back(vt(a, ca, t[0], t[1])); B.push_back(vt(b, cb, t[2], t[3])); B.push_back(vt(c, cc, t[4], t[5])); }
    else { B.push_back(vc(a, ca)); B.push_back(vc(b, cb)); B.push_back(vc(c, cc)); }
    if (g_refl && g_lod > .72) for (int i = 0; i < 3; i++) { V3 q = i == 0 ? a : i == 1 ? b : c; uint32_t k = i == 0 ? ca : i == 1 ? cb : cc;
      Col rc((float)((k & 255) * .78 + 8), (float)(((k >> 8) & 255) * .78 + 12), (float)(((k >> 16) & 255) * .78 + 20), (k >> 24) / 255.f); q.z = -q.z;
      if (t && g_buf == 0) GB[2].push_back(vt(q, rc.pack(), t[i * 2], t[i * 2 + 1])); else if (!t || (k >> 24) > 250) GB[2].push_back(vc(q, rc.pack())); }
    return;
  }
  Pt s[3]; V3 P[3] = {a, b, c}; for (int i = 0; i < 3; i++) s[i] = camProj(toCam(P[i]));
  double minX = std::min({s[0].x, s[1].x, s[2].x}), maxX = std::max({s[0].x, s[1].x, s[2].x}); if (maxX < 0 || minX > W) return;
  Col avg = litColAvg(ca, cb, cc); V3 cen = (a + b + c) * (1.0 / 3);
  Tri3 tq; for (int i = 0; i < 3; i++) { tq.x[i] = (float)s[i].x; tq.y[i] = (float)s[i].y; } tq.c = avg.pack(); tq.od = (float)g_objDepth; tq.td = (float)dot(cen - C3.e, C3.f); Q.push_back(tq);
}
static inline void striV(V3 a, V3 b, V3 c, uint32_t ca, uint32_t cb, uint32_t cc, V3 nn) { striT(a, b, c, ca, cb, cc, nn, nullptr); }
// a picture from the atlas on a flat four-cornered patch (bottom-left, bottom-right, top-right, top-left), lit like
// the surface it lies on (n: the way it faces). Used for numbers, crests, faces, adverts. Clipped at the near plane.
// buf: 0 / 3 solid, 1 on the ice. False if textures are off (the caller draws its plain version instead).
static bool decalC(V3 bl, V3 br, V3 tr, V3 tl, const TexR &r, uint32_t c, V3 n, int buf, bool cull) {
  if (!g_tex) return false;
  V3 P[4] = {bl, br, tr, tl}; float U[4][2] = {{r.u0, r.v1}, {r.u1, r.v1}, {r.u1, r.v0}, {r.u0, r.v0}};
  if (cull && !g_keep && dot(n, (bl + tr) * .5 - C3.e) > 0) return true;
  V3 O[8]; float OU[8][2]; int k = 0;
  if (g_keep) { for (int i = 0; i < 4; i++) { O[k] = P[i]; OU[k][0] = U[i][0]; OU[k][1] = U[i][1]; k++; } }
  else for (int i = 0; i < 4; i++) { int j = (i + 1) % 4; double da = dot(P[i] - C3.e, C3.f) - NEARZ, db = dot(P[j] - C3.e, C3.f) - NEARZ;
    if (da >= 0) { O[k] = P[i]; OU[k][0] = U[i][0]; OU[k][1] = U[i][1]; k++; }
    if ((da >= 0) != (db >= 0)) { float t = (float)(da / (da - db)); O[k] = P[i] + (P[j] - P[i]) * t; OU[k][0] = U[i][0] + (U[j][0] - U[i][0]) * t; OU[k][1] = U[i][1] + (U[j][1] - U[i][1]) * t; k++; } }
  std::vector<V3c> &B = GB[buf];
  for (int i = 1; i + 1 < k; i++) { B.push_back(vt(O[0], c, OU[0][0], OU[0][1])); B.push_back(vt(O[i], c, OU[i][0], OU[i][1])); B.push_back(vt(O[i + 1], c, OU[i + 1][0], OU[i + 1][1]));
    if (buf == 0 && g_refl) { Col rc((float)((c & 255) * .78 + 8), (float)(((c >> 8) & 255) * .78 + 12), (float)(((c >> 16) & 255) * .78 + 20), (c >> 24) / 255.f); uint32_t rp = rc.pack();
      for (int q = 0; q < 3; q++) { int id = q == 0 ? 0 : i + q - 1; V3 m = O[id]; m.z = -m.z; GB[2].push_back(vt(m, rp, OU[id][0], OU[id][1])); } } }
  return true;
}
static bool decal(V3 bl, V3 br, V3 tr, V3 tl, const TexR &r, Col col, V3 n) { if (!g_tex) return false; return decalC(bl, br, tr, tl, r, litV(col, lightAt(n)), n, g_buf == 3 ? 4 : g_buf); }
// a flat, lit patch lying on a surface (numbers, crests, trim): n is the way it faces
static void patch(const V3 *p, int n, Col col, V3 nrm) {
  uint32_t c = litV(col, lightAt(nrm)); for (int i = 1; i + 1 < n; i++) striV(p[0], p[i], p[i + 1], c, c, c, nrm);
}
// a unit sphere, made once: rings of points with their normals
struct UnitSphere { int st, sl; std::vector<V3> p; };
static const UnitSphere &sphereT(int st, int sl) {
  static std::map<int, UnitSphere> M; int key = st * 100 + sl; auto it = M.find(key); if (it != M.end()) return it->second;
  UnitSphere S; S.st = st; S.sl = sl;
  for (int i = 0; i <= st; i++) { double v = PI * i / st, z = std::cos(v), r = std::sin(v); for (int j = 0; j <= sl; j++) { double u = 2 * PI * j / sl; S.p.push_back({r * std::cos(u), r * std::sin(u), z}); } }
  return M[key] = S;
}
// an ellipsoid: centre c in frame m, radii (along the frame's x, y, z); aoLow darkens its underside (0 = not at all)
static void blob(const M3 &m, V3 c, V3 r, Col col, int st = 5, int sl = 8, float aoLow = 0, const TexR *tr = nullptr) {
  st = std::max(3, (int)std::lround((st - 1) * (.4 + .6 * g_lod))); sl = std::max(5, (int)std::lround((sl - 2) * g_lod));
  const UnitSphere &S = sphereT(st, sl); V3 o = m.ap(c);
  static V3 P[256], N[256]; static uint32_t Cc[256]; int nv = (S.st + 1) * (S.sl + 1); if (nv > 256) return;
  V3 ax = m.X * r.x, ay = m.Y * r.y, az = m.Z * r.z, bx = m.X * (1 / r.x), by = m.Y * (1 / r.y), bz = m.Z * (1 / r.z);
  for (int i = 0; i < nv; i++) { const V3 &q = S.p[i]; P[i] = o + ax * q.x + ay * q.y + az * q.z; N[i] = norm(bx * q.x + by * q.y + bz * q.z);
    Cc[i] = litV(col, lightAt(N[i]), aoLow > 0 ? 1 - aoLow * std::max(0.f, -q.z) : 1); }
  for (int i = 0; i < S.st; i++) for (int j = 0; j < S.sl; j++) {
    int a = i * (S.sl + 1) + j, b = a + S.sl + 1, c2 = b + 1, d = a + 1;
    if (tr && g_tex) { float u0 = tr->u0 + (tr->u1 - tr->u0) * j / S.sl, u1 = tr->u0 + (tr->u1 - tr->u0) * (j + 1) / S.sl, v0 = tr->v0 + (tr->v1 - tr->v0) * i / S.st, v1 = tr->v0 + (tr->v1 - tr->v0) * (i + 1) / S.st;
      float t1[6] = {u0, v0, u1, v1, u0, v1}, t2[6] = {u0, v0, u1, v0, u1, v1};
      if (i > 0) striT(P[a], P[c2], P[b], Cc[a], Cc[c2], Cc[b], N[a] + N[c2] + N[b], t1);
      if (i < S.st - 1) striT(P[a], P[d], P[c2], Cc[a], Cc[d], Cc[c2], N[a] + N[d] + N[c2], t2); continue; }
    if (i > 0) striV(P[a], P[c2], P[b], Cc[a], Cc[c2], Cc[b], N[a] + N[c2] + N[b]);   // (wound so the normals face out)
    if (i < S.st - 1) striV(P[a], P[d], P[c2], Cc[a], Cc[d], Cc[c2], N[a] + N[d] + N[c2]);
  }
}
static void ball(V3 c, double r, Col col, int st = 4, int sl = 7) { M3 m = frameAt(c.x, c.y, c.z, 0); blob(m, {0, 0, 0}, {r, r, r}, col, st, sl); }
// a tapered tube from a (radius ra) to b (radius rb), with round ends
static void tube(V3 a, V3 b, double ra, double rb, Col col, int n = 7, bool caps = true) {
  n = std::max(3, (int)std::lround((n - 1) * g_lod)); if (n > 16) n = 16;
  V3 d = b - a; double L = std::sqrt(dot(d, d)); if (L < 1e-4) return; V3 z = d * (1 / L);
  V3 x = std::fabs(z.z) < .9 ? norm(cross(z, {0, 0, 1})) : norm(cross(z, {1, 0, 0})), y = cross(z, x);
  double sl = (ra - rb) / L;   // the side's slope: normals tilt toward the thin end
  static const struct Circ { float c[17][17], s[17][17]; Circ() { for (int k = 1; k <= 16; k++) for (int i = 0; i <= k; i++) { c[k][i] = (float)std::cos(2 * PI * i / k); s[k][i] = (float)std::sin(2 * PI * i / k); } } } T;
  V3 A[17], Bq[17], Nn[17]; uint32_t Cc[17];
  for (int i = 0; i <= n; i++) { V3 r0 = x * T.c[n][i] + y * T.s[n][i]; Nn[i] = norm(r0 + z * sl); A[i] = a + r0 * ra; Bq[i] = b + r0 * rb; Cc[i] = litV(col, lightAt(Nn[i])); }
  for (int i = 0; i < n; i++) { V3 nn = Nn[i] + Nn[i + 1]; striV(A[i], A[i + 1], Bq[i + 1], Cc[i], Cc[i + 1], Cc[i + 1], nn); striV(A[i], Bq[i + 1], Bq[i], Cc[i], Cc[i + 1], Cc[i], nn); }
  if (caps) { ball(a, ra, col, 4, n); ball(b, rb, col, 4, n); }   // (blob trims these to 3 x n-2)
}
// a box with its edges softened by the shading (pads, blockers, skates)
static void rbox(const M3 &m, V3 c, V3 h, Col col, double soft = .9) {
  static const int F[6][4] = {{4, 6, 7, 5}, {0, 1, 3, 2}, {2, 3, 7, 6}, {0, 4, 5, 1}, {1, 5, 7, 3}, {0, 2, 6, 4}};
  V3 P[8], Nc[8]; int i = 0;
  for (int sx = -1; sx <= 1; sx += 2) for (int sy = -1; sy <= 1; sy += 2) for (int sz = -1; sz <= 1; sz += 2) { P[i] = m.ap({c.x + sx * h.x, c.y + sy * h.y, c.z + sz * h.z}); Nc[i] = (m.X * sx + m.Y * sy + m.Z * sz) * (soft * .57735); i++; }
  const V3 Fn[6] = {m.X, m.X * -1, m.Y, m.Y * -1, m.Z, m.Z * -1};
  for (int f = 0; f < 6; f++) { if (!g_keep && dot(Fn[f], P[F[f][0]] - C3.e) > 0) continue;
    uint32_t cc[4]; for (int k = 0; k < 4; k++) cc[k] = litV(col, lightAt(norm(Fn[f] + Nc[F[f][k]])));
    striV(P[F[f][0]], P[F[f][1]], P[F[f][2]], cc[0], cc[1], cc[2], Fn[f]); striV(P[F[f][0]], P[F[f][2]], P[F[f][3]], cc[0], cc[2], cc[3], Fn[f]); }
}

// ---------------------------------------------------------------- lofted surfaces: rings swept along a path
// each ring: centre c, axes u (radius a) and v (radius b), a superellipse profile (n = 2 round, higher = boxier),
// the colour of the band from this ring to the next, and ao: how much light reaches it (creases, hems and the
// places where two parts meet are darkened - baked ambient occlusion). Smooth normals from the grid itself;
// every vertex is lit once.
struct Ring { V3 c, u, v; double a, b, n; Col col; float ao = 1, tv = 0; };   // tv: where this ring is down the texture (0 top .. 1 bottom)
template <class CF> static void loftF(const std::vector<Ring> &R, int seg, bool capA, bool capB, CF colf, const TexR *tr = nullptr, int urep = 1) {
  if (!g_tex) tr = nullptr;
  int nr = (int)R.size(); if (nr < 2) return;
  static std::vector<V3> P, N; static std::vector<Lt> Lv; P.resize(nr * seg); N.resize(nr * seg); Lv.resize(nr * seg);
  static std::map<int, std::vector<float>> tab;   // the superellipse profile (x, y per segment) made once per shape
  for (int i = 0; i < nr; i++) { int key = seg * 1000 + (int)std::lround(R[i].n * 100); auto it = tab.find(key);
    if (it == tab.end()) { std::vector<float> t2(seg * 2); double e = 2 / R[i].n;
      for (int j = 0; j < seg; j++) { double t = 2 * PI * j / seg, cs = std::cos(t), sn = std::sin(t); t2[j * 2] = (float)((cs < 0 ? -1 : 1) * std::pow(std::fabs(cs), e)); t2[j * 2 + 1] = (float)((sn < 0 ? -1 : 1) * std::pow(std::fabs(sn), e)); }
      it = tab.emplace(key, t2).first; }
    const float *pr = it->second.data(); V3 ua = R[i].u * R[i].a, vb = R[i].v * R[i].b;
    for (int j = 0; j < seg; j++) P[i * seg + j] = R[i].c + ua * pr[j * 2] + vb * pr[j * 2 + 1]; }
  for (int i = 0; i < nr; i++) for (int j = 0; j < seg; j++) {
    V3 tj = P[i * seg + (j + 1) % seg] - P[i * seg + (j + seg - 1) % seg], ti = P[std::min(nr - 1, i + 1) * seg + j] - P[std::max(0, i - 1) * seg + j];
    V3 n = norm(cross(tj, ti)); if (dot(n, P[i * seg + j] - R[i].c) < 0) n = n * -1; N[i * seg + j] = n; Lt l = lightAt(n); l.k *= R[i].ao; l.s *= R[i].ao; Lv[i * seg + j] = l; }
  for (int i = 0; i + 1 < nr; i++) for (int j = 0; j < seg; j++) {
    int a = i * seg + j, b = i * seg + (j + 1) % seg, c = (i + 1) * seg + (j + 1) % seg, d = (i + 1) * seg + j;
    Col col = colf(i, j, R[i].col); if (col.a <= 0) continue;   // (alpha 0: a hole in the surface)
    V3 nn = N[a] + N[b] + N[c] + N[d];
    if (!g_keep && dot(nn, P[a] - C3.e) > 0 && dot(nn, P[c] - C3.e) > 0) continue;
    uint32_t ca = litV(col, Lv[a]), cb = litV(col, Lv[b]), cc = litV(col, Lv[c]), cd = litV(col, Lv[d]);
    if (tr) { float fu = (float)j * urep / seg; fu -= std::floor(fu); float du = tr->u1 - tr->u0, dv = tr->v1 - tr->v0, u0 = tr->u0 + du * fu, u1 = tr->u0 + du * (fu + (float)urep / seg), v0 = tr->v0 + dv * R[i].tv, v1 = tr->v0 + dv * R[i + 1].tv;
      float t1[6] = {u0, v0, u1, v0, u1, v1}, t2[6] = {u0, v0, u1, v1, u0, v1}; striT(P[a], P[b], P[c], ca, cb, cc, nn, t1); striT(P[a], P[c], P[d], ca, cc, cd, nn, t2); continue; }
    striV(P[a], P[b], P[c], ca, cb, cc, nn); striV(P[a], P[c], P[d], ca, cc, cd, nn); }
  auto cap = [&](int i, double sgn) { V3 ax = norm(R[std::min(nr - 1, i + (sgn > 0 ? 0 : 1))].c - R[std::max(0, i - (sgn > 0 ? 1 : 0))].c) * sgn, ctr = R[i].c + ax * (std::min(R[i].a, R[i].b) * .35);
    uint32_t cx = litV(R[i].col, lightAt(ax), R[i].ao);
    for (int j = 0; j < seg; j++) { int a = i * seg + j, b = i * seg + (j + 1) % seg; striV(P[a], P[b], ctr, litV(R[i].col, Lv[a]), litV(R[i].col, Lv[b]), cx, N[a] + N[b] + ax); } };
  if (capA) cap(0, -1); if (capB) cap(nr - 1, 1);
}
static void loft(const std::vector<Ring> &R, int seg, bool capA, bool capB, const TexR *tr = nullptr, int urep = 1) { loftF(R, seg, capA, capB, [](int, int, Col c) { return c; }, tr, urep); }
static inline V3 lerp3(V3 a, V3 b, double t) { return a + (b - a) * t; }
// two axes across a direction (for round sections along it)
static void across(V3 d, V3 hint, V3 &u, V3 &v) { u = norm(hint - d * dot(hint, d)); if (dot(u, u) < .5) u = norm(cross(d, {0, 0, 1})); v = norm(cross(d, u)); }
// a limb along a path: at each point a radius, the colour of the band that starts there, and its ao
struct LP { V3 p; double r; Col c; float ao = 1; double n = 2, rb = 0; };   // rb: a different radius across (0 = round)
static const TexR *g_limbTex = nullptr;   // the cloth the next limbs are made of (their length runs down it)
static void limbN(const LP *L, int n, V3 hint, int seg, bool capA, bool capB) {
  static std::vector<Ring> R; R.clear(); seg = std::max(5, (int)std::lround(seg * g_lod));
  for (int i = 0; i < n; i++) { V3 d = norm(L[std::min(n - 1, i + 1)].p - L[i > 0 ? i - 1 : 0].p); V3 u, v; across(d, hint, u, v);
    Ring r; r.c = L[i].p; r.u = u; r.v = v; r.a = L[i].r; r.b = L[i].rb > 0 ? L[i].rb : L[i].r; r.n = L[i].n; r.col = L[i].c; r.ao = L[i].ao; r.tv = n > 1 ? (float)i / (n - 1) : 0; R.push_back(r); }
  loft(R, seg, capA, capB, g_limbTex);
}
static void limb(std::initializer_list<LP> L, V3 hint, int seg, bool capA, bool capB) { limbN(L.begin(), (int)L.size(), hint, seg, capA, capB); }
// a number painted on a surface: seven-segment digits, h tall, centred at c; right: the reader's right, up, n: facing
static void paintNum(int num, V3 c, V3 right, V3 up, V3 n, double h, Col col) {
  static const unsigned char SEGS[10] = {0x77, 0x24, 0x5d, 0x6d, 0x2e, 0x6b, 0x7b, 0x25, 0x7f, 0x6f};   // bits: top, upper-left, upper-right, middle, lower-left, lower-right, bottom
  int d[2] = {num / 10 % 10, num % 10}, nd = num >= 10 ? 2 : 1; double w = h * .5, t = h * .16, gap = h * .14, tot = nd * w + (nd - 1) * gap;
  for (int k = 0; k < nd; k++) { int dg = nd == 2 ? d[k] : d[1]; V3 o = c + right * (-tot / 2 + k * (w + gap) + w / 2); unsigned m = SEGS[dg];
    auto bar = [&](double x0, double y0, double x1, double y1) { V3 q[4] = {o + right * x0 + up * y0, o + right * x1 + up * y0, o + right * x1 + up * y1, o + right * x0 + up * y1}; patch(q, 4, col, n); };
    double hw = w / 2, hh = h / 2;
    if (m & 1) bar(-hw, hh - t, hw, hh); if (m & 2) bar(-hw, 0, -hw + t, hh); if (m & 4) bar(hw - t, 0, hw, hh); if (m & 8) bar(-hw, -t / 2, hw, t / 2);
    if (m & 16) bar(-hw, -hh, -hw + t, 0); if (m & 32) bar(hw - t, -hh, hw, 0); if (m & 64) bar(-hw, -hh, hw, -hh + t); }
}

// ---------------------------------------------------------------- nets: NHL shape (posts, crossbar, the rounded base hoop, mesh)
static void drawNetGeo(int side) {
  // an NHL-style net: red posts and crossbar; a shallow white top shelf curving back from the crossbar; a deep
  // rounded base frame wrapped in thick white padding; ONE thick padded centre support from the back of the top
  // shelf down to the back of the base; the mesh runs right up to the posts and the crossbar
  const double gx = defendX(side), d = -tdir(side), cy = RK.cy, hw = RK.post, h = (PZ + .2) * VZ, dp = RK.netD * 1.25, r = .2;
  Col red = hex("#d42020"), white = hex("#eef2f7"), padC = hex("#e7ebf1"), mesh = rgba(236, 240, 246, .22), cord = hex("#eef2f7");
  objAt(gx + d * dp * .5, cy, 1.5);
  // the frame paths: the base sweeps well back (a rounded "D"), the top shelf is about half as deep
  const int N = 28; std::vector<V3> base, top, bn;
  // both frames are the same rounded "D" (a superellipse by angle): flat sides running straight back from the
  // posts, a rounded back. They start exactly at the posts, so the side mesh closes against them
  auto se = [](double v) { return (v < 0 ? -1 : 1) * std::pow(std::fabs(v), 2 / 3.2); };
  for (int i = 0; i <= N; i++) { double a = -PI / 2 + PI * i / N, cx = i == 0 || i == N ? 0 : se(std::cos(a)), sy = i == 0 ? -1 : i == N ? 1 : se(std::sin(a));
    base.push_back({gx + d * dp * cx, cy + sy * hw, .3}); top.push_back({gx + d * dp * .46 * cx, cy + sy * hw, h - .05}); }
  for (int i = 0; i <= N; i++) { V3 tg = base[std::min(N, i + 1)] - base[std::max(0, i - 1)]; V3 o = norm(cross(tg, {0, 0, 1})); if (dot(o, V3{d, 0, 0} + V3{0, base[i].y - cy, 0} * .2) < 0) o = o * -1; bn.push_back(o); }
  // the padded base: a soft white cushion following the frame on the ice
  { std::vector<Ring> R; for (int i = 0; i <= N; i++) R.push_back({base[i] + V3{0, 0, -.02}, bn[i], {0, 0, 1}, .36, .32, 2.6, padC}); loft(R, 8, true, true); }
  // the top shelf tube and the single centre support (thick and padded), leaning from the shelf's back to the base's back
  for (int i = 0; i < N; i++) tube(top[i], top[i + 1], r * .55, r * .55, white, 6, false);
  { V3 tc = top[N / 2], bc = base[N / 2] + V3{-d * .3, 0, .2}; tube(tc, bc, .3, .3, white, 8, false); blob(frameAt(tc.x, tc.y, tc.z, 0), {0, 0, 0}, {.3, .3, .3}, white, 4, 8); }
  // a water bottle on the top shelf
  { V3 wb = top[N / 2 - 6] + V3{-d * .4, 0, .25}; M3 m = frameAt(wb.x, wb.y, wb.z, PI / 2 + .3); rbox(m, {0, 0, 0}, {.5, .18, .18}, hex("#dc2626"), .9); rbox(m, {.52, 0, 0}, {.08, .1, .1}, white, .6); }
  // posts and crossbar (red, rounded), with white base plates where they meet the padding
  V3 pl = {gx, cy - hw, 0}, pr = {gx, cy + hw, 0};
  tube(pl, pl + V3{0, 0, h}, r, r, red, 10); tube(pr, pr + V3{0, 0, h}, r, r, red, 10); tube(pl + V3{0, 0, h}, pr + V3{0, 0, h}, r, r, red, 10, false);
  for (V3 p : {pl, pr}) blob(frameAt(p.x, p.y, .5, 0), {0, 0, 0}, {.3, .3, .1}, white, 3, 8);
  // the mesh: see-through panels with a fine grid of cords (thin flat strips, two triangles each)
  auto cordS = [&](V3 a, V3 b, V3 n) { V3 w = cross(b - a, n); double l = std::sqrt(dot(w, w)); if (l < 1e-6) return; w = w * (.034 / l); quad(a - w, b - w, b + w, a + w, cord, nullptr, 1, false); };
  V3 cb = {gx, cy, 0};
  for (int i = 0; i < N; i++) quad(base[i] + V3{0, 0, .3}, base[i + 1] + V3{0, 0, .3}, top[i + 1], top[i], mesh, nullptr, 1, false);
  auto cbar = [&](int i) { return V3{gx, top[i].y, h}; };   // the point on the crossbar straight in front of top[i]
  for (int i = 0; i < N; i++) quad(cbar(i), cbar(i + 1), top[i + 1], top[i], mesh, nullptr, 1, false);
  const int RW = 9;   // back wall: rows around, columns up
  for (int i = 0; i <= N; i++) cordS(base[i] + V3{0, 0, .3}, top[i], bn[i]);
  for (int k = 1; k <= RW; k++) { double z = (double)k / (RW + 1); for (int i = 0; i < N; i++) {
    V3 a = lerp3(base[i] + V3{0, 0, .3}, top[i], z), b = lerp3(base[i + 1] + V3{0, 0, .3}, top[i + 1], z); cordS(a, b, bn[i]); } }
  for (int i = 1; i < N; i++) cordS(cbar(i), top[i], {0, 0, 1});   // the roof
  for (int k = 1; k <= 3; k++) { double z = k / 4.0; for (int i = 0; i < N; i++) {
    V3 a = lerp3(cbar(i), top[i], z), b = lerp3(cbar(i + 1), top[i + 1], z); cordS(a, b, {0, 0, 1}); } }
  (void)cb;
}
// the net never changes: on the GPU path it's built once (every face kept) and copied in each frame
static void drawNet(int side) {
  const double gx = defendX(side), d = -tdir(side), cy = RK.cy, dp = RK.netD * 1.25;
  if (!g_gpu) drawNetGeo(side);
  else {
    static std::vector<V3c> C[2][3]; static std::vector<ATri> CA[2]; static bool built[2] = {false, false};
    if (!built[side]) { size_t b0 = GB[0].size(), b2 = GB[2].size(), ba = GA.size(); bool kr = g_refl; g_keep = true; g_refl = true; drawNetGeo(side); g_keep = false; g_refl = kr;
      C[side][0].assign(GB[0].begin() + b0, GB[0].end()); C[side][2].assign(GB[2].begin() + b2, GB[2].end()); CA[side].assign(GA.begin() + ba, GA.end());
      GB[0].resize(b0); GB[2].resize(b2); GA.resize(ba); built[side] = true; }
    appendClip(GB[0], C[side][0]); appendClip(GB[2], C[side][2]);
    double dd = dot(V3{gx + d * dp * .5, cy, 2} - C3.e, C3.f); for (ATri t : CA[side]) { t.d = (float)dd; GA.push_back(t); }
  }
  // a goal: the bulge
  const NetBulge &nb = SK->nb[side == 0 ? 0 : 1]; if (nb.on) { double k = std::max(0.0, 1 - nb.t / .6); blob(frameAt(gx + d * (dp + .5 * k), cy + nb.y, 1.6, 0), {0, 0, 0}, {.6 * k + .05, 1.3, 1.2}, rgba(240, 244, 250, .5)); }
}

// ---------------------------------------------------------------- people: PS2-era sports-game players
// Built from lofted surfaces (smooth, with real silhouettes) instead of boxes and balls: hockey pants, socks with
// their stripes over shin pads, skates with a white holder and steel, a jersey with a hem band, sleeve bands, a
// shoulder yoke, a crest and his number on the back, big cuffed gloves, a helmet with a visor.
static const double SCL = 1.6, GSCL = 1.38, GHEAD = GSCL / 1.3 * 1.18;   // (a goalie: a little bigger than a skater - 6'2" and up, plus his gear)
// GHEAD: a goalie's head, scaled with his body (the mask is about a third of his shoulders' width)
struct Kit { Col jersey, stripe, trim, pants, helm, skin, sock, glove, num; };
static Kit kitOf(int team) { Team &T = SK->T[team]; Kit k; k.jersey = T.col; k.stripe = T.stripe; double lj = lum(T.col), ls = lum(T.stripe);
  k.trim = (lj > .78 || ls > .78) ? (lj < .3 || ls < .3 ? hex("#aab4c4") : hex("#1c2636")) : hex("#f4f6f9");   // the third colour of the kit
  k.pants = lj > .78 ? shade(T.stripe, -.45) : shade(T.col, -.62); k.helm = lj > .78 ? hex("#f1f4f8") : shade(T.col, -.12);
  k.skin = hex("#e0a878"); k.sock = T.col; k.glove = lj > .78 ? shade(T.stripe, -.3) : shade(T.col, -.3); k.num = lj > .6 ? hex("#16202e") : hex("#f8fafc"); return k; }
// a skate: boot, toe cap, tongue, the white holder and the steel
static void skate(const M3 &base, V3 ankle, double s) {
  M3 f = base; f.O = ankle; float g0 = g_gloss; g_gloss = .55f;
  rbox(f, {.02 * s, 0, -.06 * s}, {.2 * s, .125 * s, .17 * s}, hex("#171b22"));
  rbox(f, {.14 * s, 0, -.255 * s}, {.34 * s, .045 * s, .035 * s}, hex("#f1f5f9"), .5);
  if (g_lod > .6) {
    rbox(f, {.33 * s, 0, -.13 * s}, {.17 * s, .12 * s, .1 * s}, hex("#2c333f"));
    rbox(f, {.17 * s, 0, .03 * s}, {.09 * s, .085 * s, .1 * s}, hex("#d7dce3"), .7);
    rbox(f, {.15 * s, 0, -.29 * s}, {.38 * s, .016 * s, .028 * s}, hex("#9aa7b8"), .4); }
  else rbox(f, {.33 * s, 0, -.13 * s}, {.17 * s, .12 * s, .1 * s}, hex("#171b22"));
  g_gloss = g0;
}
// a soft shadow on the ice: dark under him, fading to nothing at its edge, pushed a little away from the lights
static void shadow(double x, double y, double r) {
  if (!g_gpu) { iceDisc(x, y, r, rgba(15, 23, 42, .22), 12, .04); return; }
  const int n = 12; uint32_t c0 = rgba(8, 16, 34, .36f).pack(), c1 = rgba(8, 16, 34, 0).pack(); V3 o = {x + .3, y - .38, .04};
  if (dot(o - C3.e, C3.f) < NEARZ + r * 1.3) return;
  for (int i = 0; i < n; i++) { double a0 = 2 * PI * i / n, a1 = 2 * PI * (i + 1) / n;
    GB[1].push_back(vc(o, c0)); GB[1].push_back(vc(o + V3{std::cos(a0) * r * 1.15, std::sin(a0) * r, 0}, c1)); GB[1].push_back(vc(o + V3{std::cos(a1) * r * 1.15, std::sin(a1) * r, 0}, c1)); }
}
// Cast shadows: every part of a body (a limb, the trunk, the head, the stick) throws a soft-edged shape onto the ice,
// away from the arena lights. They are drawn so each pixel keeps the darkest shadow over it (see plat_draw3d mode 3),
// which lets all those shapes overlap freely and still read as one shadow.
static bool g_shOn = false;
// (the shadows fall toward the camera's side of the rink and a little across it, where they can be seen at the players' feet)
static inline V3 shProj(V3 p) { double k = std::max(0.0, (double)p.z); return V3{p.x - .5 * k, p.y + .42 * k, .045}; }
static void shCap(V3 a, V3 b, double ra, double rb) {
  if (!g_shOn) return; V3 A = shProj(a), B = shProj(b);
  if (dot((A + B) * .5 - C3.e, C3.f) < NEARZ + 4) return;
  V3 d = B - A; double L = std::sqrt((double)dot(d, d)); d = L > 1e-3 ? d * (1 / L) : V3{1, 0, 0}; V3 n = {-d.y, d.x, 0};
  // a full-strength core with a soft rim (the colour also carries an alpha, used only where the darkest-wins blend isn't there)
  static const uint32_t c0 = rgba(112, 126, 160, .5f).pack(), c1 = rgba(255, 255, 255, 0).pack(); std::vector<V3c> &G = GB[5];
  const double IN = .8, OUT = 1.35;
  auto tri = [&](V3 p, uint32_t cp, V3 q, uint32_t cq, V3 r, uint32_t cr) { G.push_back(vc(p, cp)); G.push_back(vc(q, cq)); G.push_back(vc(r, cr)); };
  for (int sg = -1; sg <= 1; sg += 2) { V3 ia = A + n * (sg * ra * IN), ib = B + n * (sg * rb * IN), ea = A + n * (sg * ra * OUT), eb = B + n * (sg * rb * OUT);
    tri(A, c0, B, c0, ib, c0); tri(A, c0, ib, c0, ia, c0); tri(ia, c0, ib, c0, eb, c1); tri(ia, c0, eb, c1, ea, c1); }
  static const float CS[4] = {1, .5f, -.5f, -1}, SN[4] = {0, .866f, .866f, 0};
  for (int e = 0; e < 2; e++) { V3 o = e ? B : A, dd = e ? d : d * -1.0; double r = e ? rb : ra;
    for (int i = 0; i < 3; i++) { V3 u0 = n * CS[i] + dd * SN[i], u1 = n * CS[i + 1] + dd * SN[i + 1];
      tri(o, c0, o + u0 * (r * IN), c0, o + u1 * (r * IN), c0); tri(o + u0 * (r * IN), c0, o + u1 * (r * IN), c0, o + u1 * (r * OUT), c1); tri(o + u0 * (r * IN), c0, o + u1 * (r * OUT), c1, o + u0 * (r * OUT), c1); } }
}
// ---------------------------------------------------------------- heads: one human head for everyone
// A sculpted head (jaw, cheeks, brow, cranium, nose, ears) with one face wrapped right round it, on a neck. Skaters
// and officials wear a helmet that sits on the skull - shell, brim, ear guards, a chin strap, a clear visor for
// skaters; goalies wear a mask that wraps the whole head down past the chin, open at the face behind a wire cage.
static const double HEADH = .47 * 1.6;   // chin to crown, in feet (the same for every player)
// f: X forward, Y to his side, Z up, origin under the chin. kind: 0 skater, 1 goalie, 2 official
static void drawHead(const M3 &f, V3 neckBase, Col skin, int kind, Col helm, Col acc, Col acc2, double hk = 1) {
  const double H = HEADH * hk; const bool fine = g_lod > .62; float g0 = g_gloss; const TexR *lt0 = g_limbTex; g_limbTex = nullptr; g_gloss = .1f;
  Col tint = g_tex ? Col(std::min(255.f, skin.r / 242 * 255), std::min(255.f, skin.g / 199 * 255), std::min(255.f, skin.b / 155 * 255), 1) : skin;
  const int seg = g_lod > .8 ? 16 : 12;
  shCap(f.ap({-.02 * H, 0, .3 * H}), f.ap({-.02 * H, 0, .8 * H}), (kind == 1 ? .44 : .38) * H, (kind == 1 ? .4 : .36) * H);
  // the neck: from between the shoulders up into the skull, behind the jaw
  limb({{neckBase, .21 * H, skin, .8f}, {lerp3(neckBase, f.ap({-.08 * H, 0, .1 * H}), .6), .185 * H, skin, .9f}, {f.ap({-.07 * H, 0, .22 * H}), .18 * H, skin}}, f.X, 8, false, false);
  static std::vector<Ring> R; R.clear();
  auto ring = [&](double z, double cx, double a, double b, double n, Col c, float tv, float ao = 1) { Ring q; q.c = f.ap({cx * H, 0, z * H}); q.u = f.X * -1.0; q.v = f.Y; q.a = a * H; q.b = b * H; q.n = n; q.col = c; q.tv = tv; q.ao = ao; R.push_back(q); };
  // the head itself: chin, jaw, mouth, cheeks, brow, forehead, crown (the seam of the face picture is at the back)
  static const double HR[10][5] = {{0, .13, .09, .1, 2}, {.06, .1, .17, .17, 2}, {.16, .05, .25, .24, 2.1}, {.3, .02, .3, .285, 2.2}, {.45, 0, .335, .3, 2.2}, {.58, -.01, .355, .31, 2.2}, {.72, -.02, .36, .315, 2.2}, {.86, -.03, .32, .29, 2.1}, {.95, -.03, .22, .2, 2}, {1, -.03, .08, .07, 2}};
  for (auto &q : HR) ring(q[0], q[1], q[2], q[3], q[4], tint, (float)(1 - q[0]), q[0] < .1 ? .8f : 1);
  loftF(R, seg, true, true, [&](int i, int, Col c) { return g_tex || i < 6 ? c : hex("#3a2a20"); }, &TP_HEAD); R.clear();
  if (fine) {   // the nose, and his ears where a helmet leaves them showing
    V3 tip = f.ap({.415 * H, 0, .4 * H}), top = f.ap({.35 * H, 0, .53 * H}), bl = f.ap({.33 * H, .05 * H, .365 * H}), br = f.ap({.33 * H, -.05 * H, .365 * H}), bt = f.ap({.345 * H, 0, .35 * H});
    uint32_t cl = litV(skin, lightAt(norm(f.X + f.Y * .8))), cr = litV(skin, lightAt(norm(f.X - f.Y * .8))), cu = litV(shade(skin, -.22), lightAt(norm(f.X - f.Z)));
    striV(top, bl, tip, cl, cl, cl, f.X + f.Y); striV(top, tip, br, cr, cr, cr, f.X - f.Y); striV(tip, bl, bt, cu, cu, cu, f.X - f.Z); striV(tip, bt, br, cu, cu, cu, f.X - f.Z);
    if (kind != 1) for (int e = -1; e <= 1; e += 2) blob(f, {-.03 * H, e * .305 * H, .47 * H}, {.055 * H, .03 * H, .09 * H}, shade(skin, -.08), 3, 6); }
  g_gloss = .85f;
  if (kind != 1) {
    // a skater's helmet: down to just over the brows in front, over the ears at the sides, to the nape behind
    static const double HK[8][5] = {{.36, -.07, .375, .35, 2.3}, {.5, -.045, .4, .362, 2.3}, {.63, -.02, .417, .368, 2.3}, {.69, -.005, .434, .376, 2.4}, {.76, -.02, .42, .368, 2.3}, {.88, -.035, .375, .335, 2.2}, {.98, -.04, .27, .24, 2.1}, {1.06, -.04, .11, .09, 2}};
    for (auto &q : HK) ring(q[0], q[1], q[2], q[3], q[4], helm, (float)((1.08 - q[0]) / .74), q[0] < .4 ? .8f : 1);
    const double open = seg * (68 / 360.0);
    loftF(R, seg, false, true, [&](int i, int j, Col c) { return i < 2 && std::fabs(j + .5 - seg / 2.0) < open ? Col(0, 0, 0, 0) : c; }, &TP_HELM2); R.clear();
    if (fine) {
      g_gloss = .1f; Col strap = lum(helm) > .6 ? hex("#e8ebf0") : hex("#15181e"); V3 chin = f.ap({.13 * H, 0, -.015 * H});   // the chin strap, down from each ear guard to a cup under the chin
      for (int e = -1; e <= 1; e += 2) { V3 a = f.ap({.02 * H, e * .345 * H, .4 * H}), b = f.ap({.12 * H, e * .12 * H, -.01 * H}), w = f.X * (.035 * H); quad(a - w, a + w, b + w, b - w, strap, nullptr); }
      blob(f, {.13 * H, 0, -.01 * H}, {.07 * H, .1 * H, .03 * H}, strap, 3, 6); (void)chin;
      if (kind == 0) {   // the visor: clear, from the brim down to the tip of the nose, temple to temple
        Col vis = rgba(210, 234, 255, .3f), edge = rgba(235, 245, 255, .55f); V3 pv[7][2];
        for (int i = 0; i < 7; i++) { double a = (-66 + 22 * i) * PI / 180; pv[i][0] = f.ap({(-.01 + std::cos(a) * .425) * H, std::sin(a) * .372 * H, .34 * H}); pv[i][1] = f.ap({(-.01 + std::cos(a) * .436) * H, std::sin(a) * .378 * H, .645 * H}); }
        for (int i = 0; i < 6; i++) { quad(pv[i][0], pv[i + 1][0], pv[i + 1][1], pv[i][1], vis, nullptr, 1, false);
          V3 u = (pv[i][1] - pv[i][0]) * .06; quad(pv[i][0], pv[i + 1][0], pv[i + 1][0] + u, pv[i][0] + u, edge, nullptr, 1, false); } } }
  } else {
    // a goalie's mask: one shell round the whole head, from over the crown to below the chin, open at the face
    static const double MK[8][5] = {{-.22, .15, .15, .14, 2}, {-.1, .11, .3, .26, 2.2}, {.17, .03, .435, .385, 2.3}, {.42, -.01, .48, .425, 2.3}, {.68, -.025, .478, .425, 2.3}, {.86, -.035, .43, .38, 2.3}, {.98, -.04, .32, .285, 2.2}, {1.07, -.04, .16, .14, 2}};
    for (auto &q : MK) ring(q[0], q[1], q[2], q[3], q[4], helm, (float)((1.07 - q[0]) / 1.29), q[0] < -.15 ? .8f : 1);
    const double open = seg * (52 / 360.0);
    loftF(R, seg, true, true, [&](int i, int j, Col c) { if (i >= 2 && i <= 3 && std::fabs(j + .5 - seg / 2.0) < open) return Col(0, 0, 0, 0);
      return i >= 5 ? acc : i <= 0 ? acc2 : c; }, &TP_MASK); R.clear();
    // the cage: wire bowed out in front of the opening
    auto cg = [&](double a, double z) { double k = (z - .425) / .3; return f.ap({(-.01 + std::cos(a) * (.555 - .075 * k * k)) * H, std::sin(a) * .45 * H, z * H}); };
    const double A0 = -56 * PI / 180, A1 = 56 * PI / 180, Z0 = .13, Z1 = .72; Col wire = hex("#eef1f5");
    if (g_tex) { for (int c = 0; c < 4; c++) for (int r = 0; r < 3; r++) { double a0 = A0 + (A1 - A0) * c / 4, a1 = A0 + (A1 - A0) * (c + 1) / 4, z1 = Z1 - (Z1 - Z0) * r / 3, z0 = Z1 - (Z1 - Z0) * (r + 1) / 3, am = (a0 + a1) / 2;
        decal(cg(a0, z0), cg(a1, z0), cg(a1, z1), cg(a0, z1), cell(TP_CAGE, c / 4.0, r / 3.0, (c + 1) / 4.0, (r + 1) / 3.0), wire, f.X * std::cos(am) + f.Y * std::sin(am)); } }
    else { const double bw = .012;
      for (int r = 0; r < 5; r++) { double z = Z0 + (Z1 - Z0) * r / 4; for (int c = 0; c < 4; c++) { double a0 = A0 + (A1 - A0) * c / 4, a1 = A0 + (A1 - A0) * (c + 1) / 4; V3 q[4] = {cg(a0, z - bw), cg(a1, z - bw), cg(a1, z + bw), cg(a0, z + bw)}; patch(q, 4, wire, f.X); } }
      for (int c = 1; c < 4; c++) { double a = A0 + (A1 - A0) * c / 4; for (int r = 0; r < 2; r++) { double z0 = Z0 + (Z1 - Z0) * r / 2, z1 = z0 + (Z1 - Z0) / 2; V3 q[4] = {cg(a - .03, z0), cg(a + .03, z0), cg(a + .03, z1), cg(a - .03, z1)}; patch(q, 4, wire, f.X); } } }
  }
  g_gloss = g0; g_limbTex = lt0;
}
// an eight-sided crest on a surface
static void crest(V3 c, V3 right, V3 up, V3 n, double r, Col outer, Col inner) {
  V3 q[8]; for (int pass = 0; pass < 2; pass++) { double rr = pass ? r * .62 : r; V3 cc = c + n * (pass * .02);
    for (int i = 0; i < 8; i++) { double a = PI / 8 + i * PI / 4; q[i] = cc + right * (std::cos(a) * rr) + up * (std::sin(a) * rr * 1.12); } patch(q, 8, pass ? inner : outer, n); }
}
// a skater: the pose comes from what he's doing (stride, lean, wind-up, poke, spin, falling, blocking)
// two bones from a to b (lengths l1, l2): where the joint between them goes, bending toward pole
static V3 ik2(V3 a, V3 &b, double l1, double l2, V3 pole) {
  V3 d = b - a; double L = std::sqrt((double)dot(d, d)); if (L < 1e-4) return a; V3 dn = d * (1 / L); double mx = (l1 + l2) * .985;
  if (L > mx) { L = mx; b = a + dn * L; }
  double x = (l1 * l1 - l2 * l2 + L * L) / (2 * L), h = std::sqrt(std::max(0.0, l1 * l1 - x * x)); V3 pp = pole - dn * dot(pole, dn); pp = dot(pp, pp) > 1e-6 ? norm(pp) : V3{0, 0, -1};
  return a + dn * x + pp * h;
}
// his number: two digits from the sheet (or painted bars when textures are off); c: centre, right: the reader's right
static void number(int num, V3 c, V3 right, V3 up, V3 n, double h, Col col) {
  if (!g_tex) { paintNum(num, c, right, up, n, h, col); return; }
  int d[2] = {num / 10 % 10, num % 10}, nd = num >= 10 ? 2 : 1; double w = h * .72, step = w * .86, tot = w + (nd - 1) * step;
  for (int k = 0; k < nd; k++) { int dg = nd == 2 ? d[k] : d[1]; V3 o = c + right * (-tot / 2 + k * step + w / 2);
    decal(o - right * (w / 2) - up * (h / 2), o + right * (w / 2) - up * (h / 2), o + right * (w / 2) + up * (h / 2), o - right * (w / 2) + up * (h / 2), cell(TP_DIGITS, (dg * 80 + 4) / 800.0, 0, (dg * 80 + 76) / 800.0, 1), col, n); }
}
// his name across the shoulders, in capitals from the letter sheet (last name only; nothing without textures)
static void nameBar(const std::string &nm, V3 c, V3 right, V3 up, V3 n, double h, Col col, double maxW) {
  if (!g_tex) return; size_t sp = nm.find_last_of(' '); char t[12]; int k = 0;
  for (size_t i = sp == std::string::npos ? 0 : sp + 1; i < nm.size() && k < 11; i++) { char ch = nm[i]; if (ch >= 'a' && ch <= 'z') ch -= 32; if (ch >= 'A' && ch <= 'Z') t[k++] = ch; }
  if (k == 0) return; double w = h * .72, step = w * .74, tot = w + (k - 1) * step; if (tot > maxW) { double f = maxW / tot; w *= f; step *= f; h *= std::max(.8, f); tot = maxW; }
  for (int i = 0; i < k; i++) { int li = t[i] - 'A'; V3 o = c + right * (-tot / 2 + i * step + w / 2); double u0 = ((li % 13) * 76 + 2) / 988.0, v0 = (li / 13) * .5;
    decal(o - right * (w / 2) - up * (h / 2), o + right * (w / 2) - up * (h / 2), o + right * (w / 2) + up * (h / 2), o - right * (w / 2) + up * (h / 2), cell(TP_LETTERS, u0, v0, u0 + 72 / 988.0, v0 + .5), col, n); }
}
// a skater, with a real player's proportions: the pose comes from what he's doing (stride, lean, wind-up, poke, spin,
// falling, blocking)
static void drawSkater3(Skater *p) {
  if (!nearView(p->x, p->y, 3, 9)) return;
  Kit K = kitOf(p->team); K.skin = p->skin;
  // the stride, matched to broadcast skating: a slow, long cycle (about two strides a second at full speed, not a
  // fast pedal), each leg pushing OUT to the side and back until it's nearly straight, then the foot comes back in
  // under his hips just off the ice; knees deep, hips low and back, chest well over the knees
  double sp = hyp(p->vx, p->vy), m = clamp(sp / 14, 0, 1), st = std::sin(p->ph * 1.05) * m;
  double yaw = p->ang; if (p->spin > 0) yaw += (1 - p->spin / SPIN_T) * 2 * PI;
  // carving: he leans into a turn (how much of his speed is sideways to where he faces)
  double carve = clamp((-std::sin(p->ang) * p->vx + std::cos(p->ang) * p->vy) / 26, -.32, .32);
  bool upright = p->block > 0 || p->stun > 0 || p->spin > 0 || p->wind > 0;
  double lean = .36 + .4 * m + (p->dash > 0 ? .12 : 0); if (p->wind > 0) lean = .3;
  M3 base = frameAt(p->x, p->y, 0, yaw); if (p->block <= 0 && p->stun <= 0 && p->spin <= 0) base = roll(base, -carve);
  objAt(p->x, p->y, 2);
  if (p->block > 0) base = roll(base, (std::cos(p->blkA) > 0 ? 1 : -1) * 1.35 * std::min(1.0, p->block / .25));
  else if (p->stun > 0) base = roll(base, (p->team ? 1 : -1) * (p->kd ? 1.35 : .45));
  double s = SCL; bool lh = p->sh != 'R'; double side = lh ? 1 : -1;   // a left shot carries the stick on his left
  double hipZ = (1.94 - .2 * m - (p->dash > 0 ? .06 : 0)) * s, hipX = -.12 * s * (1 + m);
  const double LT = 1.0 * s, LS = 1.0 * s;   // thigh and shin
  const bool fine = g_lod > .62;              // close enough for the small things (bands, trim, face)
  g_gloss = .1f; g_limbTex = &TP_FABRIC;      // cloth
  for (int k = -1; k <= 1; k += 2) {
    double u = upright ? 0 : std::sin(p->ph * 1.05 + (k > 0 ? 0 : PI)) * m, e = std::max(0.0, u), r = std::max(0.0, -u);
    // push: out and back along the ice; recovery: back under him, lifted a touch
    V3 fl = e > 0 ? V3{-.12 * s - .95 * s * e, k * (.36 + .62 * e) * s, .3 * s} : V3{(-.12 + .32 * r) * s, k * (.36 - .05 * r) * s, (.3 + .32 * r) * s};
    V3 H = base.ap({hipX, k * .25 * s, hipZ}), A = base.ap(fl);
    V3 Kn = ik2(H, A, LT, LS, base.X * 1.0 + base.Y * (k * .22)), bend = norm(Kn - (H + A) * .5);
    // hockey pants: wide and short, ending above the knee (dark inside the leg opening)
    shCap(H, Kn, .3 * s, .23 * s); shCap(Kn, A, .21 * s, .13 * s); shCap(A, A + base.X * (.4 * s), .12 * s, .1 * s);
    limb({{H, .31 * s, K.pants, 1, 2.5}, {lerp3(H, Kn, .42), .315 * s, K.pants, 1, 2.5}, {lerp3(H, Kn, .72), .285 * s, K.pants, .72f, 2.5}}, base.X, 8, false, true);
    // the sock over the shin pad: the knee cap, the calf, down to the boot; two bands of the stripe colour
    V3 kc = Kn + bend * (.05 * s);
    if (fine) limb({{lerp3(H, Kn, .64), .2 * s, K.sock, .7f}, {lerp3(H, Kn, .88) + bend * (.03 * s), .215 * s, K.sock}, {kc, .225 * s, K.sock}, {lerp3(Kn, A, .14) + bend * (.02 * s), .205 * s, K.sock}, {lerp3(Kn, A, .3), .2 * s, K.stripe},
        {lerp3(Kn, A, .39), .195 * s, K.trim}, {lerp3(Kn, A, .45), .19 * s, K.stripe}, {lerp3(Kn, A, .55), .175 * s, K.sock}, {lerp3(Kn, A, .8), .14 * s, K.sock}, {A, .115 * s, K.sock, .8f}}, base.X, 8, false, false);
    else limb({{lerp3(H, Kn, .64), .2 * s, K.sock, .7f}, {kc, .225 * s, K.sock}, {lerp3(Kn, A, .3), .2 * s, K.stripe}, {lerp3(Kn, A, .52), .18 * s, K.sock}, {A, .115 * s, K.sock, .8f}}, base.X, 8, false, false);
    // the pushing skate turns its toe out
    double ta = k * (.12 + .5 * e), c = std::cos(ta), sn = std::sin(ta); M3 fb = base; fb.X = base.X * c + base.Y * sn; fb.Y = base.X * -sn + base.Y * c;
    g_limbTex = nullptr; skate(fb, A, s * .86); g_limbTex = &TP_FABRIC;
  }
  // the body, leaning over his knees
  M3 tor = pitch(moveTo(base, {hipX, 0, hipZ + .05 * s}), lean);
  if (!upright) tor = roll(tor, -st * .1);   // the shoulders rock a little with each push
  { static std::vector<Ring> R; R.clear(); double zl = 0, zh = 1;
    auto ring = [&](double z, double x, double a, double b, double n, Col c, float ao = 1) { Ring q; q.c = tor.ap({x * s, 0, z * s}); q.u = tor.X; q.v = tor.Y; q.a = a * s; q.b = b * s; q.n = n; q.col = c; q.ao = ao; q.tv = (float)(1 - (z - zl) / (zh - zl)); R.push_back(q); };
    // the seat of the pants
    zl = -.22; zh = .38; ring(-.22, 0, .26, .34, 2.4, K.pants, .68f); ring(0, 0, .36, .47, 2.6, K.pants); ring(.25, 0, .36, .465, 2.6, K.pants); ring(.38, 0, .34, .44, 2.6, K.pants);
    loft(R, std::max(8, (int)std::lround(12 * g_lod)), true, false, &TP_FABRIC); R.clear();
    // the jersey: hem band, body, the shoulder pads under it, the collar
    zl = .2; zh = 1.52; ring(.2, 0, .395, .505, 2.5, K.stripe, .7f);
    if (fine) { ring(.27, 0, .395, .505, 2.5, K.trim, .92f); ring(.32, 0, .395, .505, 2.5, K.stripe); }
    ring(.38, 0, .39, .5, 2.5, K.jersey); ring(.68, .01, .355, .465, 2.4, K.jersey); ring(.98, .03, .37, .52, 2.4, K.jersey);
    ring(1.16, .02, .36, .6, 2.7, K.jersey); ring(1.28, .01, .31, .6, 3.0, K.jersey); ring(1.36, 0, .2, .3, 2.3, K.jersey, .9f); ring(1.405, 0, .15, .19, 2.1, K.stripe, .9f); ring(1.43, 0, .13, .15, 2, K.skin, .8f); ring(1.52, 0, .12, .135, 2, K.skin, .8f);
    loft(R, std::max(8, (int)std::lround(14 * g_lod)), false, false, &TP_FABRIC); }
  // his number on the back, the crest on his chest
  if (fine) { number(skNum(p), tor.ap({-.405 * s, 0, .74 * s}), tor.Y, tor.Z, tor.X * -1.0, .42 * s, K.num);
    nameBar(p->nm, tor.ap({-.385 * s, 0, 1.08 * s}), tor.Y, tor.Z, tor.X * -1.0, .15 * s, K.num, .78 * s);
    V3 cc = tor.ap({.41 * s, 0, .8 * s}); double cr = .17 * s; Col cst = p->star ? hex("#facc15") : K.trim;
    if (!decal(cc + tor.Y * cr - tor.Z * cr, cc - tor.Y * cr - tor.Z * cr, cc - tor.Y * cr + tor.Z * cr, cc + tor.Y * cr + tor.Z * cr, p->team ? TP_CREST1 : TP_CREST0, cst, tor.X))
      crest(cc, tor.Y, tor.Z, tor.X, cr, K.stripe, cst); }
  V3 shL = tor.ap({0, .5 * s, 1.22 * s}), shR = tor.ap({0, -.5 * s, 1.22 * s});
  shCap(tor.ap({0, 0, .05 * s}), tor.ap({0, 0, 1.1 * s}), .42 * s, .5 * s);
  // head: on a neck, held up and looking at the play however far he leans
  { M3 hf = pitch(moveTo(tor, {.02 * s, 0, 1.5 * s}), -lean * .7); g_limbTex = nullptr;
    drawHead(hf, tor.ap({0, 0, 1.36 * s}), K.skin, 0, K.helm, K.stripe, K.trim); }
  g_gloss = .1f;
  // the stick: hands low on his stick side, the blade on the ice ahead (raised on a wind-up, out on a poke)
  double wind = p->wind > 0 ? p->wind : 0, poke = p->pokeA > 0 ? std::sin(PI * (1 - p->pokeA / .28)) : 0;
  V3 fwd = base.X, lat = base.Y * side;
  V3 top = tor.ap({.34 * s, side * .34 * s, .6 * s}), hand = tor.ap({.6 * s, side * .2 * s, .3 * s});
  V3 blade = V3{p->x, p->y, 0} + fwd * ((2.3 + poke * 1.4) * s) + lat * (.85 * s); blade.z = .1;
  if (wind > 0) { blade = V3{p->x, p->y, 0} + fwd * (-1.1 * s) + lat * (1.5 * s); blade.z = 2.2 * wind * s; }
  if (p->block > 0 || (p->stun > 0 && p->kd)) blade = hand + fwd * 2 + V3{0, 0, -1};
  V3 sd = norm(blade - top), handLow = top + (blade - top) * .42;
  // arms: the shoulder, the sleeve with its elbow bands, then the glove: a flared cuff and the fist on the stick
  g_limbTex = &TP_FABRIC;
  auto arm = [&](V3 sh, V3 gl, double out) { V3 el = ik2(sh, gl, .68 * s, .7 * s, V3{0, 0, -1} + lat * out - fwd * .45); V3 fd = norm(gl - el), wr = gl - fd * (.3 * s);
    shCap(sh, el, .22 * s, .18 * s); shCap(el, gl, .17 * s, .19 * s);
    if (fine) limb({{sh, .215 * s, K.jersey}, {lerp3(sh, el, .5), .185 * s, K.jersey}, {lerp3(sh, el, .86), .168 * s, K.jersey}, {el, .165 * s, K.stripe}, {lerp3(el, wr, .28), .158 * s, K.trim}, {lerp3(el, wr, .5), .15 * s, K.jersey}, {wr, .135 * s, K.jersey, .75f}}, base.Z, 8, true, false);
    else limb({{sh, .215 * s, K.jersey}, {lerp3(sh, el, .55), .18 * s, K.jersey}, {el, .165 * s, K.stripe}, {wr, .135 * s, K.jersey, .75f}}, base.Z, 8, true, false);
    g_limbTex = &TP_GLOVE; limb({{wr - fd * (.03 * s), .165 * s, K.stripe, 1, 3.2}, {lerp3(wr, gl, .3), .195 * s, K.glove, 1, 3.2}, {lerp3(wr, gl, .8), .19 * s, K.glove, 1, 3.2}}, base.Z, 7, true, true); g_limbTex = &TP_FABRIC;
    ball(gl, .185 * s, K.glove, 4, 8); };
  arm(lh ? shL : shR, top, .9); arm(lh ? shR : shL, handLow, -.9);
  g_limbTex = nullptr; g_gloss = .5f;
  shCap(top, blade, .05 * s, .06 * s);
  tube(top - sd * (.2 * s), blade, .042 * s, .038 * s, hex("#20252e"), 5, false);                                        // a carbon stick
  tube(top - sd * (.25 * s), top - sd * (.02 * s), .052 * s, .052 * s, hex("#e9edf2"), 5, false);                         // knob tape
  if (fine) tube(top + (blade - top) * .6, top + (blade - top) * .72, .045 * s, .044 * s, K.stripe, 5, false);            // the maker's band
  { V3 bd = norm(V3{fwd.x, fwd.y, 0}); double ba = std::atan2(bd.y, bd.x) + side * .35; M3 mb = frameAt(blade.x, blade.y, std::max(.08, (double)blade.z), ba);
    rbox(mb, {.16 * s, 0, .03}, {.21 * s, .034 * s, .09 * s}, hex("#14171d"), .5);
    M3 mt = frameAt(mb.ap({.35 * s, 0, 0}).x, mb.ap({.35 * s, 0, 0}).y, mb.O.z, ba - side * .28); rbox(mt, {.18 * s, 0, .035}, {.2 * s, .032 * s, .085 * s}, hex("#e9edf2"), .5); }   // the taped, curved toe
  g_gloss = .3f;
}
// ---------------------------------------------------------------- the goalie's body: one pose for the picture AND the physics
// Every joint of the goalie (pads, legs, torso, arms, trapper, blocker, stick) is worked out here once. drawGoalie3 draws
// it and skGoalieTouch tests the puck against the same shapes, so what you see is exactly what stops the puck: a gap you
// can see between the glove and the body, or between the pads, is a gap the puck can go through.
// The frame is mirrored (local +y is the goalie's LEFT: he catches left-handed, the glove on the same side the sim uses).
struct GBody {
  M3 base, base0; double s = GSCL, k = 1, low = 0, drop = 0, split = 0, flat = 0, lay = 0, aty = 0, atz = 0, side = 1; int sj = 1; bool aim = false, useHand = false, useG = true; Pose P = GP_NONE;
  V3 FX, UP; V3 ank[2], kn[2], hip[2], D[2], F[2], Wd[2], bot[2], top[2];
  V3 pel, neck, sp, SD, SF, SW, hc; V3 shL, shR, gH, bH, elG, elB; M3 gm, bm;
  V3 heel, S, Bd, Hh; double HL = 0, pl = 0, shEnd = 0;
};
static V3 elbowOf(const GBody &B, V3 sh, V3 hd, double sgn) {   // two-bone arm: fixed lengths, the elbow bends down and out
  const double U = 1.0 * B.s; V3 dv = hd - sh; double dl = std::max(1e-3, std::sqrt(dot(dv, dv))); V3 dn = dv * (1 / dl); dl = std::min(dl, 1.98 * U);
  V3 pole = B.UP * -1.0 + B.base.Y * (sgn * .7) - B.FX * .2, pp = pole - dn * dot(pole, dn); pp = dot(pp, pp) > 1e-6 ? norm(pp) : B.UP * -1.0;
  return sh + dn * (dl * .5) + pp * std::sqrt(std::max(0.0, U * U - dl * dl * .25));
}
static void gBody(Goalie &g, int ti, GBody &B) {
  const double s = GSCL, yaw = (ti == 0 ? 0 : PI) + g.face; B.s = s;   // (face: turned square to the shooter)
  M3 base = frameAt(g.x, g.y, 0, yaw); base.Y = base.Y * -1.0;                       // mirrored: +y is his glove (left) hand
  Pose P = g.hasAn ? g.an.p : GP_NONE; double side = g.hasAn ? g.an.s : 1; if (ti == 0) side = -side;   // the puck's side, in his frame
  double k = 1; if (g.hasAn) { double t = g.an.t; k = t < g.an.i ? t / g.an.i : t < g.an.i + g.an.h ? 1 : std::max(0.0, 1 - (t - g.an.i - g.an.h) / g.an.o); }
#ifdef HOST_BUILD
  if (const char *fp = getenv("CHL_GPOSE")) { P = fp[0] == 'l' ? GP_LO : fp[0] == 'p' ? GP_POKE : fp[0] == 'k' ? GP_KICK : GP_NONE; k = 1; }   // test shots
#endif
  // the save reaches for where he reads the puck going (aimY: offset from him, aimZ: height), within what a body can do:
  // an arm only reaches so far, so a low shot drops him to his knees (butterfly) and a low shot wide of him kicks that
  // pad out along the ice (half splits) with the glove or blocker down beside it; a shot wide and high leans him over
  M3 base0 = base;
  bool aim = g.hasAn && SK->gt - g.aimT < 1.2 && P != GP_POKE && P != GP_COVER && P != GP_LOOK && P != GP_NONE;
  double aty = 0, atz = 0; if (aim) { aty = -tdir(g.team) * (g.aimWY - g.y) / s;   // (the read is already measured across HIS body)
    atz = g.aimZ / s; }
#ifdef HOST_BUILD
  if (const char *fa = getenv("CHL_GAIM")) { double oy = 0, hh = 0; if (sscanf(fa, "%lf,%lf", &oy, &hh) == 2) { aim = true; k = 1; if (P == GP_NONE) P = GP_HI; aty = oy / s; atz = (std::min(1.3, std::max(0.0, hh)) * PZ * .94 + .1) * 1.7 / s; } }   // test shots
#endif
  int sj = aty > 0 ? 1 : -1;
  double drop = aim ? clamp((2.15 - atz) / 1.15, 0, 1) * k : 0;
  double split = aim ? clamp((std::fabs(aty) - 1.2) / 1.2, 0, 1) * drop : 0;
  double low = std::max((P == GP_LO || P == GP_KICK) ? k : 0.0, drop);
#ifdef HOST_BUILD
  if (const char *e = getenv("CHL_GHUG")) { g.hugK = atof(e); g.hugS = 1; }   // test shots: sealing the post
#endif
  { double hug = aim ? 0 : g.hugK; if (hug > .01) { sj = dot(V3{0, g.hugS, 0}, base.Y) > 0 ? 1 : -1; low = std::max(low, .85 * hug); split = std::max(split, .7 * hug); }   // sealing the post
    low = std::max(low, .9 * g.slideK * (aim ? .5 : 1)); }                                                                                                  // a butterfly slide
  if (P == GP_DIVE) base = roll(base, -side * 1.15 * k);
  else if (aim) { double lean = clamp((std::fabs(aty) - 2.3) / 1.6, 0, 1) * (.45 - .25 * drop) * k; if (lean > 0) base = roll(base, -sj * lean); }
  double up = (P == GP_HI || P == GP_BODY) && !aim ? k : 0, gUp = side > 0 ? up : 0, bUp = side < 0 ? up : 0;
  auto L = [&](V3 p) { return base.ap(p * s); };
  auto J = [&](V3 a, V3 b) { return L(lerp3(a, b, low)); };
  V3 FX = base.X, UP = base.Z;
  B.base = base; B.base0 = base0; B.k = k; B.low = low; B.drop = drop; B.split = split; B.aty = aty; B.atz = atz; B.sj = sj; B.aim = aim; B.P = P; B.side = side; B.FX = FX; B.UP = UP;
  // the ready stance: feet wide and knees in (the pads make a V), the glove out and open at his side, the blocker out
  // on the other with the stick across to the five-hole: {ankle y, knee y, glove y, glove z, blocker y, blocker z}
  static double ST[6] = {1.2, .66, 1.72, 3.05, 1.3, 2.45};
#ifdef HOST_BUILD
  static bool stInit = false; if (!stInit) { stInit = true; if (const char *e = getenv("CHL_GSTANCE")) sscanf(e, "%lf,%lf,%lf,%lf,%lf,%lf", &ST[0], &ST[1], &ST[2], &ST[3], &ST[4], &ST[5]); }
#endif
  for (int li = 0; li < 2; li++) { int j = li ? 1 : -1;
    double sx = j == sj ? split : 0;   // this leg kicks out along the ice
    V3 ank = J({.02, j * ST[0], .32}, {-.25 + .4 * sx, j * (1.85 + 1.05 * sx), .3}), kn = J({.6, j * ST[1], 1.48}, {.48 - .08 * sx, j * (.5 + .8 * sx), .5 - .08 * sx}), hip = J({-.28, j * .38, 2.45}, {-.12, j * .36, 1.3});
    V3 D = norm(kn - ank), F = norm(FX - D * dot(FX, D)), Wd = norm(cross(D, F)); if (dot(Wd, base.Y * (double)j) < 0) Wd = Wd * -1;
    B.ank[li] = ank; B.kn[li] = kn; B.hip[li] = hip; B.D[li] = D; B.F[li] = F; B.Wd[li] = Wd; B.bot[li] = ank - D * (.3 * s); B.top[li] = kn + D * (.98 * s); }
  V3 pel = J({-.3, 0, 2.55}, {-.12, 0, 1.4}), neck = J({.45, 0, 4.3}, {.22, 0, 3.15});
  V3 sp = neck - pel; V3 SD = norm(sp), SF = norm(FX - SD * dot(FX, SD)), SW = base.Y;
  B.pel = pel; B.neck = neck; B.sp = sp; B.SD = SD; B.SF = SF; B.SW = SW; B.hc = pel + sp * 1.0 + SD * (.03 * s + .42 * HEADH * GHEAD) + SF * (.1 * s);   // the middle of his mask
  V3 shL = pel + sp * .85 + SW * (.6 * s) - SF * (.05 * s), shR = pel + sp * .85 - SW * (.6 * s) - SF * (.05 * s);
  V3 gH = J({.85, ST[2], ST[3] + gUp * 1.35}, {.95, 1.42, 2.15 + gUp * 1.3}), bH = J({.9, -ST[4], ST[5] + bUp * 1.25}, {.92, -1.2, 1.75 + bUp * 1.2});
  // the stick goes flat (blocker hand down by the ice) to seal the five-hole, on a poke, or to play / pass the puck
  double flat = std::max({P == GP_LO ? k : 0.0, P == GP_POKE ? k : 0.0, g.fum > SK->gt ? std::min(1.0, (g.fum - SK->gt) / .25) : 0.0});
  // a low centred shot is the pads' and the stick's job: the paddle goes down to seal the five-hole
  bool useHand = aim && !(drop > .5 && std::fabs(aty) < .7), useG = aty > -.35;
  if (aim && (!useHand || useG)) flat = std::max(flat, drop);
  bH = lerp3(bH, L(lerp3(V3{1.15, -.95, .62}, V3{1.0, -1.05, .5}, low)), flat);
  if (useHand) {   // the reaching hand goes to the puck, no further than the arm allows
    V3 sh = useG ? shL : shR, tw = base0.ap(V3{1.2, aty, std::max(.3, atz)} * s), dv = tw - sh; double dl = std::sqrt(dot(dv, dv)), R = 1.92 * s;
    if (dl > R) tw = sh + dv * (R / dl);
    if (useG) gH = lerp3(gH, tw, k); else bH = lerp3(bH, tw, k); }
  B.shL = shL; B.shR = shR; B.gH = gH; B.bH = bH; B.flat = flat; B.useHand = useHand; B.useG = useG;
  B.elG = elbowOf(B, shL, gH, 1); B.elB = elbowOf(B, shR, bH, -1);
  { M3 gm = yawFrame(gH, yaw + .3); gm = pitch(gm, -.15); gm.Y = gm.Y * -1.0; B.gm = gm;
    M3 bm = yawFrame(bH, yaw - .22); bm = pitch(bm, -.1); bm.Y = bm.Y * -1.0; B.bm = bm; }
  // the stick: a real goalie stick has a fixed length. The blocker holds it right at the top of the paddle, the paddle
  // runs down to the heel, the shaft carries on well above the hand (to about the shoulder), and the long flat blade lies
  // on the ice pointing to the glove side. A low blocker save takes the stick down with it, paddle along the ice in
  // front of the pad; a high blocker lifts the blade off the ice
  { V3 hand = bH; const double HL = 2.8 * s;
    double bLow = useHand && !useG ? clamp((2.2 - dot(hand - base0.O, UP) / s) / 1.6, 0, 1) * k : 0;
    double lay = std::max(flat, bLow);
    V3 ideal = L(lerp3(lerp3(V3{1.5, -.12, 0}, V3{1.5, -.2, 0}, low), V3{2.1, .25, 0}, flat));
    if (g.stkOff > SK->gt) ideal = L(V3{1.2, -1.3, 0});   // caught with his stick out of position (a misread five-hole shot)
    { V3 hg = {hand.x, hand.y, 0}; V3 lowH = hg + norm(V3{FX.x, FX.y, 0}) * (1.1 * s) + norm(V3{base.Y.x, base.Y.y, 0}) * (.6 * s); ideal = lerp3(ideal, lowH, bLow); }
    V3 heel = hand + norm(ideal - hand) * HL;
    if (heel.z < .03 * s) { double hz = std::max(0.0, hand.z - .03 * s); V3 hd = {ideal.x - hand.x, ideal.y - hand.y, 0}; double hl = std::sqrt(dot(hd, hd));
      hd = hl > 1e-4 ? hd * (1 / hl) : norm(V3{FX.x, FX.y, 0}); heel = V3{hand.x, hand.y, .03 * s} + hd * std::sqrt(std::max(0.0, HL * HL - hz * hz)); }
    V3 S = norm(hand - heel), Bd = norm(base.Y * (1 - .4 * lay) + base.X * (.12 + .68 * lay));
    V3 hp = cross(UP, Bd); if (dot(hp, S) < 0) hp = hp * -1;
    B.heel = heel; B.S = S; B.Bd = Bd; B.Hh = norm(lerp3(UP, hp, lay)); B.lay = lay; B.HL = HL; B.pl = HL - .12 * s; B.shEnd = HL + 1.65 * s; }
}

// ---------------------------------------------------------------- the puck against the goalie (physics)
static bool capHit(V3 p, V3 a, V3 b, double rad, V3 &n) {
  V3 ab = b - a; double t = clamp(dot(p - a, ab) / std::max(1e-9, dot(ab, ab)), 0, 1); V3 d = p - (a + ab * t); double l2 = dot(d, d);
  if (l2 > rad * rad) return false; n = l2 > 1e-9 ? d * (1 / std::sqrt(l2)) : V3{1, 0, 0}; return true;
}
static bool boxHit(V3 p, V3 c, V3 ex, V3 ey, V3 ez, V3 h, double r, V3 &n) {
  V3 d = p - c; double a = dot(d, ex), b = dot(d, ey), e = dot(d, ez);
  if (std::fabs(a) > h.x + r || std::fabs(b) > h.y + r || std::fabs(e) > h.z + r) return false;
  double qa = std::fabs(a) / (h.x + r), qb = std::fabs(b) / (h.y + r), qe = std::fabs(e) / (h.z + r);
  n = qa >= qb && qa >= qe ? ex * (a < 0 ? -1.0 : 1.0) : qb >= qe ? ey * (b < 0 ? -1.0 : 1.0) : ez * (e < 0 ? -1.0 : 1.0); return true;
}
static bool ellHit(V3 p, const M3 &m, V3 c, V3 rr, double r, V3 &n) {
  V3 d = p - m.ap(c); double a = dot(d, m.X) / (rr.x + r), b = dot(d, m.Y) / (rr.y + r), e = dot(d, m.Z) / (rr.z + r);
  if (a * a + b * b + e * e > 1) return false; n = norm(m.X * (a / (rr.x + r)) + m.Y * (b / (rr.y + r)) + m.Z * (e / (rr.z + r))); return true;
}
// which part of him (if any) the puck at (x, y, height zp, radius r) is touching, and the surface normal there
// the body is worked out once per frame and shared by the physics and the picture
static const GBody &gBodyC(Goalie &g, int ti) {
  // keyed on the update count, not the game clock: the clock stands still before the opening faceoff, which left
  // his body drawn by the bench while he (and his shadow) skated to the net
  extern unsigned g_skTick;
  static GBody C[2]; static double ct[2] = {-1, -1}; static unsigned ck[2] = {~0u, ~0u}; static const Goalie *cg[2] = {nullptr, nullptr}; static const Game *cs[2] = {nullptr, nullptr};
  if (ct[ti] != SK->gt || ck[ti] != g_skTick || cg[ti] != &g || cs[ti] != SK) { gBody(g, ti, C[ti]); ct[ti] = SK->gt; ck[ti] = g_skTick; cg[ti] = &g; cs[ti] = SK; }
  return C[ti];
}
int skGoalieTouch(Goalie &g, double x, double y, double zp, double r, double *nrm, double *aux) {
  if (g.out) return -1;
  const GBody &B = gBodyC(g, g.team & 1); const double s = B.s; V3 p = {x, y, zp * VZ}, n = {0, 0, 1}; int part = -1;
  if (hyp(x - g.x, y - g.y) > 7.5 * s * .5 + 6) return -1;
  if (aux) *aux = 0;
  // the trapper: its big pocket and the cuff
  if (part < 0 && (ellHit(p, B.gm, {.28 * s, .12 * s, .22 * s}, {.26 * s, .46 * s, .56 * s}, r, n) || boxHit(p, B.gm.ap({-.05 * s, .02 * s, -.05 * s}), B.gm.X, B.gm.Y, B.gm.Z, {.32 * s, .2 * s, .16 * s}, r, n))) part = GT_GLOVE;
  // the blocker board and the hand behind it
  if (part < 0 && (boxHit(p, B.bm.ap({.14 * s, -.16 * s, .08 * s}), B.bm.X, B.bm.Y, B.bm.Z, {.08 * s, .36 * s, .5 * s}, r, n) || capHit(p, B.bH, B.elB, .24 * s + r, n))) part = GT_BLOCKER;
  // the stick: paddle and blade
  if (part < 0) { V3 by = norm(cross(B.Hh, B.Bd));
    if (capHit(p, B.heel + B.S * (.06 * s), B.heel + B.S * B.pl, .14 * s + r, n) || boxHit(p, B.heel + B.Bd * (.52 * s) + B.Hh * (.14 * s), B.Bd, by, B.Hh, {.6 * s, .05 * s, .15 * s}, r, n)) part = GT_STICK; }
  // the leg pads (the walls): face, depth and width along each shin, from the boot to the thigh rise
  for (int li = 0; li < 2 && part < 0; li++) { V3 a = B.bot[li], b = B.top[li], ax = b - a; double len = std::sqrt(dot(ax, ax)); V3 c = (a + b) * .5 + B.F[li] * (.24 * s);
    if (boxHit(p, c, B.F[li], B.Wd[li], ax * (1 / len), {.34 * s, .49 * s, len * .5 + .05 * s}, r, n)) { part = GT_PAD;
      if (aux) { V3 d = p - c; *aux = std::max(std::fabs(dot(d, B.Wd[li])) / (.49 * s), (dot(d, ax * (1 / len)) / (len * .5))); }   // near an edge: > .7
      if (dot(n, B.F[li]) < .5 && dot(n, B.FX) > -.2) n = norm(n + B.F[li]); } }
  if (part < 0 && capHit(p, B.hc, B.hc, .47 * HEADH * GHEAD + r, n)) part = GT_HEAD;
  if (part < 0 && (capHit(p, B.shL, B.elG, .3 * s + r, n) || capHit(p, B.elG, B.gH, .25 * s + r, n) || capHit(p, B.shR, B.elB, .3 * s + r, n))) part = GT_ARM;
  if (part < 0) { double L2 = std::sqrt(dot(B.sp, B.sp)); V3 d = p - B.pel; double t = dot(d, B.SD); if (t > -.2 * L2 && t < .97 * L2) {
      V3 q = d - B.SD * t; double f = dot(q, B.SF), w = dot(q, B.SW), A = .46 * s + r, Bb = .62 * s + r; if ((f / A) * (f / A) + (w / Bb) * (w / Bb) <= 1) { part = GT_BODY; n = norm(B.SF * (f / (A * A)) + B.SW * (w / (Bb * Bb))); } } }
  for (int li = 0; li < 2 && part < 0; li++) if (capHit(p, B.hip[li], B.kn[li], .3 * s + r, n)) part = GT_LEG;
  if (part >= 0 && nrm) { nrm[0] = n.x; nrm[1] = n.y; nrm[2] = n.z / VZ; double l = std::sqrt(nrm[0] * nrm[0] + nrm[1] * nrm[1] + nrm[2] * nrm[2]); if (l > 1e-9) for (int i = 0; i < 3; i++) nrm[i] /= l; }
  return part;
}

// ---------------------------------------------------------------- the benches
// both benches on the far side, behind the boards either side of centre (home on the left), the players who are off
// the ice sitting on them: a little sway and fidget, leaning toward the play, and up on their feet with their arms in
// the air when their team scores
static void drawBench3() {
  double now = plat_now_ms() / 1000, yb = RK.Wd;
  Col wood = hex("#3b2f2a"), wall = hex("#1f2937"), floorC = hex("#111827");
  for (int ti = 0; ti < 2; ti++) {
    Team &T = SK->T[ti]; Kit K = kitOf(ti); double x0 = RK.L / 2 + (ti == 0 ? -40 : 10), len = 30;
    { // off screen (or behind the camera): skip it; on screen they're small, so low detail and no reflection
      V3 c = {x0 + len / 2, yb + 3, 3}; double dz = dot(c - C3.e, C3.f); if (dz < 2) continue;
      Pt a = sk3Proj(x0, yb + 3, 3), b = sk3Proj(x0 + len, yb + 3, 3); if (std::max(a.x, b.x) < -40 || std::min(a.x, b.x) > W + 40 || std::max(a.y, b.y) < -60 || std::min(a.y, b.y) > H + 60) continue; }
    g_lod = .5;
    objAt(x0 + len / 2, yb + 3, 2);
    quad({x0, yb + .4, .05}, {x0 + len, yb + .4, .05}, {x0 + len, yb + 6.5, .05}, {x0, yb + 6.5, .05}, floorC, nullptr);                  // the bench floor
    rbox(frameAt(x0 + len / 2, yb + 3.6, 0, 0), {0, 0, 1.25}, {len / 2, .9, 1.25}, wood, .4);                                                     // the seat
    rbox(frameAt(x0 + len / 2, yb + 5.4, 0, 0), {0, 0, 3.4}, {len / 2, .2, 3.4}, wall, .3);                                                     // the back wall
    rbox(frameAt(x0 + len / 2, yb + 5.2, 0, 0), {0, 0, 5.2}, {len / 2, .08, .45}, K.jersey, .3);                                              // a team-colour stripe
    int n = std::min(9, (int)T.bench.size()); bool cheer = SK->phase == PH_GOAL && SK->cel.team == ti;
    for (int k = 0; k < n; k++) {
      double ph = k * 1.93 + ti * .7, px = x0 + 2.2 + k * ((len - 4.4) / std::max(1, n - 1)), py = yb + 3.4;
      double bob = cheer ? std::fabs(std::sin(now * 7 + ph)) * .5 : 0, sway = std::sin(now * .9 + ph) * .12, lean = std::sin(now * .35 + ph * 2) * .1;
      double hz = (cheer ? 4.2 + bob : 2.6);                                   // the seat of the pants (standing up to cheer)
      M3 b = frameAt(px, py, 0, -PI / 2 + sway * .4); b = pitch(b, cheer ? -.05 : .25 + lean);
      V3 pel = {px, py, hz};
      // legs: seated (thighs forward to the boards, shins down) or standing
      for (int j = -1; j <= 1; j += 2) { V3 hip = pel + V3{j * .35, 0, 0}, kn = cheer ? hip + V3{0, -.1, -1.7} : hip + V3{j * .1, -1.5, -.1}, ft = cheer ? kn + V3{0, .1, -1.7} : kn + V3{0, -.2, -1.6};
        tube(hip, kn, .32, .28, K.pants, 5); tube(kn, ft, .26, .22, K.sock, 4, false); }
      M3 tor = frameAt(px, py, hz, -PI / 2 + sway * .4); tor = pitch(tor, cheer ? -.05 : .28 + lean);
      blob(tor, {0, 0, 1.1}, {.55, .75, .95}, K.jersey, 5, 9);
      V3 sh[2] = {tor.ap({0, .65, 1.75}), tor.ap({0, -.65, 1.75})}; V3 head = tor.ap({.05, 0, 2.55});
      ball(head, .42, K.helm);
      for (int j = 0; j < 2; j++) { V3 hand = cheer ? sh[j] + V3{(j ? -1 : 1) * .5, -.2, 1.8 + bob * .6} : tor.ap({.55, (j ? -.35 : .35), .9}) + V3{0, 0, std::sin(now * 1.7 + ph + j) * .05};
        tube(sh[j], hand, .22, .18, K.jersey, 4, false); }
    }
  }
}
// a goalie: the human model on the pose above. Big flat-faced leg pads with their knee rolls, boot break, outer roll
// and thigh rise; baggy pants; a chest-protector-wide jersey with hem and sleeve bands and a crest; the trapper held
// open to the shooter and the blocker with its board; a painted mask with a cage and a throat guard; the stick.
static void drawGoalie3(Goalie &g, int ti) {
  if (g.out) return; if (!nearView(g.x, g.y, 3, 12)) return; Kit K = kitOf(ti);
  const GBody &B = gBodyC(g, ti);
  const double s = GSCL, yaw = (ti == 0 ? 0 : PI) + g.face; objAt(g.x, g.y, 2);
  M3 base = B.base; V3 FX = B.FX, UP = B.UP; (void)base;
  const bool fine = g_lod > .62;
  Col pad = hex("#f4f6f9"), padS = shade(pad, -.14), padD = hex("#5d6675"), dark = hex("#1f2937");
  Col acc = lum(K.jersey) > .82 ? K.stripe : K.jersey, acc2 = lum(K.stripe) > .82 ? shade(K.jersey, -.3) : K.stripe;
  Col pants = K.pants, sleeve2 = lum(K.stripe) > .8 ? hex("#f8fafc") : K.stripe;
  g_gloss = .22f;
  for (int li = 0; li < 2; li++) { int j = li ? 1 : -1;
    V3 ank = B.ank[li], kn = B.kn[li], hip = B.hip[li], F = B.F[li], Wd = B.Wd[li], bot = B.bot[li], top = B.top[li];
    // the thigh (pants) down to the knee
    shCap(hip, kn, .34 * s, .28 * s); shCap(bot, top, .48 * s, .48 * s);
    g_limbTex = &TP_FABRIC; limb({{hip, .38 * s, pants, 1, 2.5}, {lerp3(hip, kn, .5), .33 * s, pants, 1, 2.5}, {lerp3(hip, kn, .86), .25 * s, pants, .75f}}, FX, 10, true, false); g_limbTex = nullptr;
    // the skate under the pad
    { V3 d = norm(V3{FX.x, FX.y, 0}); M3 sk = frameAt(ank.x, ank.y, .0, std::atan2(d.y, d.x) - j * .25 * (1 - B.low)); if (B.low < .5) { rbox(sk, {.15 * s, 0, .2 * s}, {.38 * s, .16 * s, .18 * s}, dark); rbox(sk, {.18 * s, 0, .03 * s}, {.42 * s, .03 * s, .04 * s}, hex("#cbd5e1"), .5); } }
    // the pad: boot, shin, the knee rolls (creases across the face), the thigh rise; a flat face with square edges.
    // Its texture is the pad unwrapped: stitching, the rolls, the binding, the straps round the back
    static std::vector<Ring> R; R.clear();
    static const double PT[] = {0, .06, .15, .17, .33, .49, .51, .63, .65, .8, .93, 1.0}; const int NR = 12;
    for (int i = 0; i < NR; i++) { double t = PT[i]; bool cz = i == 2 || i == 3 || i == 5 || i == 6 || i == 7 || i == 8;
      double kb = std::exp(-std::pow((t - .6) / .13, 2));   // the knee block
      double w = (t > .8 ? .5 - (t - .8) * .5 : t < .06 ? .45 + t : .5) * s, dpt = (.3 - .05 * t + .09 * kb - (cz ? .018 : 0) - (i == NR - 1 ? .08 : 0)) * s;
      // the leg is strapped behind the face: the pad's back sits just behind the shin/knee line, so the knee stays inside
      V3 c = lerp3(bot, top, t) + F * (dpt * .62 + .05 * s * (1 - t));
      Ring q; q.c = c; q.u = F; q.v = Wd; q.a = dpt; q.b = w; q.n = 4.5; q.col = pad; q.ao = cz ? .86f : i == 0 ? .8f : 1; q.tv = (float)(1 - t); R.push_back(q); }
    const int SEG = g_lod > .75 ? 16 : 12; const bool tx = g_tex;
    loftF(R, SEG, true, true, [&](int i, int jj, Col c) {
      if (jj > SEG / 4 && jj < 3 * SEG / 4 - 1) return tx ? pad : padD;  // the leg channel behind
      if (!tx && (i == 2 || i == 5 || i == 7)) return padD;              // a crease runs right across
      if (jj == 1) return acc;                                           // the outer edge of the face
      if (jj == SEG - 2) return i >= 8 ? acc2 : pad;                     // the inner edge, up the thigh rise
      if (!tx && jj >= 2 && jj <= SEG / 4) return padS;                  // the outer side wall
      return c; }, &TP_PAD);
    // the outer roll
    { V3 r0 = R[0].c + Wd * (.48 * s) + F * (.08 * s), r1 = R[NR - 1].c + Wd * (.38 * s) + F * (.05 * s); tube(r0, r1, .09 * s, .075 * s, pad, 7); }
    // the toe of the pad over the boot
    blob(frameAt(bot.x, bot.y, bot.z, yaw), {.28 * s, 0, .05 * s}, {.32 * s, .38 * s, .16 * s}, pad, 4, 9, .3f);
  }
  // pelvis / pants and the jersey over the chest protector, leaning into the crouch
  V3 pel = B.pel, sp = B.sp, SD = B.SD, SF = B.SF, SW = B.SW;
  struct TR { double t, a, b, n; Col c; float ao; };
  const TR tr[] = {{-.2, .37, .46, 2.6, pants, .68f}, {-.02, .44, .57, 2.6, pants, 1}, {.1, .48, .625, 2.5, K.stripe, .72f}, {.15, .49, .635, 2.5, sleeve2 , .95f}, {.19, .48, .63, 2.5, K.stripe, 1},
    {.24, .46, .615, 2.5, K.jersey, 1}, {.5, .47, .635, 2.5, K.jersey, 1}, {.68, .48, .66, 2.7, K.jersey, 1}, {.8, .46, .68, 2.8, acc2, 1}, {.89, .4, .64, 2.6, acc2, 1},
    {.96, .29, .43, 2.3, acc2, .95f}, {1.01, .16, .18, 2, hex("#15181e"), .8f}};
  { static std::vector<Ring> R; R.clear(); for (auto &q : tr) { Ring r; r.c = pel + sp * q.t; r.u = SF; r.v = SW; r.a = q.a * s; r.b = q.b * s; r.n = q.n; r.col = q.c; r.ao = q.ao; r.tv = (float)(1 - (q.t + .2) / 1.22); R.push_back(r); } loft(R, g_lod > .75 ? 18 : 12, true, false, &TP_FABRIC, 2); }
  // the crest on his chest
  if (fine) { V3 cc = pel + sp * .52 + SF * (.51 * s); double cr = .27 * s; Col ci = lum(K.jersey) > .6 ? acc : hex("#f4f6f9");
    if (!decal(cc + SW * cr - SD * cr, cc - SW * cr - SD * cr, cc - SW * cr + SD * cr, cc + SW * cr + SD * cr, ti ? TP_CREST1 : TP_CREST0, ci, SF)) crest(cc, SW, SD, SF, cr, acc2, ci);
    number(ti ? 35 : 31, pel + sp * .52 - SF * (.505 * s), SW * -1.0, SD, SF * -1.0, .5 * s, K.num);
    nameBar(g.nm, pel + sp * .76 - SF * (.49 * s), SW * -1.0, SD, SF * -1.0, .17 * s, K.num, 1.05 * s); }
  // arms: shoulder - elbow - wrist, sleeve bands below the elbow
  V3 shL = B.shL, shR = B.shR, gH = B.gH, bH = B.bH;
  g_limbTex = &TP_FABRIC;
  shCap(pel, pel + sp * .85, .5 * s, .6 * s); shCap(gH, gH + UP * (.3 * s), .42 * s, .42 * s); shCap(bH, bH + UP * (.1 * s), .38 * s, .38 * s);
  auto arm = [&](V3 sh, V3 el, V3 hd) { shCap(sh, el, .33 * s, .29 * s); shCap(el, hd, .28 * s, .24 * s);
    limb({{sh, .29 * s, acc2}, {lerp3(sh, el, .5), .265 * s, K.jersey}, {el, .255 * s, K.jersey}, {lerp3(el, hd, .25), .25 * s, K.stripe}, {lerp3(el, hd, .38), .245 * s, sleeve2},
      {lerp3(el, hd, .5), .24 * s, K.stripe}, {lerp3(el, hd, .62), .23 * s, K.jersey}, {hd, .2 * s, K.jersey, .75f}}, UP, 12, true, false); };
  arm(shL, B.elG, gH); arm(shR, B.elB, bH); g_limbTex = nullptr;
  // the trapper, held open to the shooter: the mitt with its binding and the hand behind it; its face (the cuff, the
  // palm, the laced pocket and the T of the web) is a picture laid over the front
  { M3 gm = B.gm;
    blob(gm, {.22 * s, .12 * s, .22 * s}, {.15 * s, .47 * s, .58 * s}, acc, 5, 12);                       // the binding: a rim around the mitt
    blob(gm, {.28 * s, .12 * s, .22 * s}, {.2 * s, .42 * s, .52 * s}, pad, 7, 12, .25f);
    rbox(gm, {.3 * s, -.04 * s, -.2 * s}, {.08 * s, .3 * s, .19 * s}, pad, .8);                             // the cuff
    rbox(gm, {-.05 * s, .02 * s, -.05 * s}, {.3 * s, .19 * s, .14 * s}, padS, .9);                          // the hand behind it
    tube(gm.ap({.4 * s, -.2 * s, .0 * s}), gm.ap({.46 * s, -.24 * s, .38 * s}), .1 * s, .08 * s, pad, 6);   // the thumb
    double x = .505 * s;
    if (!decal(gm.ap({x, -.44 * s, -.44 * s}), gm.ap({x, .62 * s, -.44 * s}), gm.ap({x, .62 * s, .8 * s}), gm.ap({x, -.44 * s, .8 * s}), TP_TRAPPER, hex("#ffffff"), gm.X)) {
      blob(gm, {.43 * s, .14 * s, .3 * s}, {.07 * s, .27 * s, .34 * s}, shade(acc2, -.35), 4, 10);          // (plain: the pocket and the web)
      rbox(gm, {.39 * s, -.04 * s, -.2 * s}, {.012 * s, .26 * s, .06 * s}, acc, .4);
      if (fine) for (int c = -1; c <= 1; c++) { V3 q[4] = {gm.ap({.5 * s, (.14 + c * .1 - .012) * s, .08 * s}), gm.ap({.5 * s, (.14 + c * .1 + .012) * s, .08 * s}), gm.ap({.5 * s, (.14 + c * .1 + .012) * s, .56 * s}), gm.ap({.5 * s, (.14 + c * .1 - .012) * s, .56 * s})}; patch(q, 4, hex("#cfd6df"), gm.X); } } }
  // the blocker: the board facing the shooter (its face a picture: binding, panels, the maker's bars), the glove behind it
  { M3 bm = B.bm;
    blob(bm, {-.08 * s, 0, 0}, {.18 * s, .16 * s, .2 * s}, padS, 4, 8);
    rbox(bm, {.1 * s, -.16 * s, .08 * s}, {.035 * s, .375 * s, .515 * s}, acc, .5);                         // the binding shows as a border
    rbox(bm, {.14 * s, -.16 * s, .08 * s}, {.06 * s, .34 * s, .48 * s}, pad, .85);
    rbox(bm, {.05 * s, .2 * s, .0 * s}, {.12 * s, .04 * s, .3 * s}, padS, .7);                              // the side wall over his fingers
    double x = .207 * s;
    if (!decal(bm.ap({x, -.5 * s, -.4 * s}), bm.ap({x, .18 * s, -.4 * s}), bm.ap({x, .18 * s, .56 * s}), bm.ap({x, -.5 * s, .56 * s}), TP_BLOCKER, hex("#ffffff"), bm.X)) {
      rbox(bm, {.2 * s, -.16 * s, .2 * s}, {.015 * s, .3 * s, .07 * s}, acc, .5); rbox(bm, {.2 * s, -.16 * s, .04 * s}, {.015 * s, .3 * s, .03 * s}, acc2, .5); }
    else rbox(bm, {.2 * s, -.16 * s, .36 * s}, {.012 * s, .28 * s, .035 * s}, acc, .5); }                   // a band of his colour across the top
  // the stick: a real goalie stick has a fixed length. The blocker holds it right at the top of the paddle, the
  // paddle runs down to the heel, the shaft carries on well above the hand (to about the shoulder), and the blade
  // (long and flat) lies on the ice pointing to the glove side. When the blocker goes down for a low save the stick
  // goes down with it, paddle along the ice in front of the pad; when the blocker goes high the blade comes off the ice.
  { V3 heel = B.heel, S = B.S, Bd = B.Bd; double lay = B.lay, pl = B.pl, sh = B.shEnd;
    shCap(heel, heel + S * sh, .1 * s, .07 * s); shCap(heel, heel + Bd * (1.1 * s), .1 * s, .1 * s);
    V3 Np = norm(lerp3(FX, UP, lay)), W = norm(cross(Np, S)); if (dot(W, Bd) < 0) W = W * -1;     // the paddle's width
    M3 st; st.X = W; st.Z = S; st.Y = cross(S, W); st.O = heel;
    Col stk = hex("#eef2f6"), tape = hex("#111827"); g_gloss = .45f;
    rbox(st, {.03 * s, 0, pl / 2 + .06 * s}, {.125 * s, .045 * s, pl / 2 - .06 * s}, stk, .6);          // the paddle
    rbox(st, {.03 * s, .047 * s, pl * .62}, {.128 * s, .006 * s, .32 * s}, tape, .3);                    // its lettering band
    rbox(st, {0, 0, (pl + sh) / 2}, {.06 * s, .045 * s, (sh - pl) / 2}, stk, .6);                         // the shaft, through the hand
    rbox(st, {0, 0, sh - .15 * s}, {.065 * s, .05 * s, .15 * s}, tape, .6);                               // the knob
    rbox(st, {.03 * s, 0, pl * .3}, {.13 * s, .05 * s, .05 * s}, acc, .4);                              // a colour band low on the paddle
    // the blade: from the heel toward the glove side, its bottom edge on the ice (or flat when the stick lies down)
    V3 Hh = B.Hh; M3 bl; bl.X = Bd; bl.Z = Hh; bl.Y = cross(Hh, Bd); bl.O = heel;
    rbox(bl, {.52 * s, 0, .14 * s}, {.6 * s, .035 * s, .13 * s}, stk, .5);
    rbox(bl, {.62 * s, 0, .14 * s}, {.42 * s, .038 * s, .132 * s}, hex("#e2e6ec"), .4);                  // white tape on the blade
    rbox(bl, {.52 * s, 0, .03 * s}, {.6 * s, .037 * s, .03 * s}, tape, .4);
    rbox(bl, {-.02 * s, 0, .15 * s}, {.1 * s, .045 * s, .15 * s}, stk, .5); }
  // the head: the same human head as everyone, inside his mask
  { V3 nb = pel + sp * .93, hc = pel + sp * 1.0 + SD * (.03 * s) + SF * (.1 * s); M3 hd = yawFrame(hc, yaw); hd = pitch(hd, -.1); g_limbTex = nullptr;
    drawHead(hd, nb, K.skin, 1, hex("#f1f5f9"), acc, acc2, GHEAD); }
  g_gloss = .3f;
}
// the referee: black trousers and helmet, the striped sweater (the stripes are the jersey's own panels) with orange
// bands on the arms; one arm goes up when he signals
static void drawRef3() {
  const Ref &r = SK->ref; if (!nearView(r.x, r.y, 3, 9)) return;
  double s = SCL; M3 b = frameAt(r.x, r.y, 0, r.ang); objAt(r.x, r.y, 2);
  Col blk = hex("#14171d"), wht = hex("#f4f6f9"), org = hex("#f97316"), skin = hex("#e0a878");
  g_gloss = .1f; g_limbTex = &TP_FABRIC;
  double st = std::sin(r.ph * 1.05) * clamp(hyp(r.vx, r.vy) / 12, 0, 1), hipZ = 2.0 * s;
  for (int k = -1; k <= 1; k += 2) { double u = st * k; V3 H = b.ap({-.05 * s, k * .22 * s, hipZ}), A = b.ap({(-.1 - .5 * std::max(0.0, u)) * s, k * (.3 + .35 * std::max(0.0, u)) * s, .3 * s});
    V3 Kn = ik2(H, A, 1.0 * s, 1.0 * s, b.X + b.Y * (k * .2));
    shCap(H, Kn, .25 * s, .19 * s); shCap(Kn, A, .18 * s, .12 * s);
    limb({{H, .27 * s, blk}, {lerp3(H, Kn, .5), .24 * s, blk}, {Kn, .19 * s, blk}, {lerp3(Kn, A, .5), .165 * s, blk}, {A, .115 * s, blk, .8f}}, b.X, 8, false, false);
    g_limbTex = nullptr; skate(b, A, s * .86); g_limbTex = &TP_FABRIC; }
  M3 t = pitch(moveTo(b, {-.05 * s, 0, hipZ}), .16);
  { static std::vector<Ring> R; R.clear();
    auto ring = [&](double z, double a, double w, double n, float ao = 1) { Ring q; q.c = t.ap({0, 0, z * s}); q.u = t.X; q.v = t.Y; q.a = a * s; q.b = w * s; q.n = n; q.col = wht; q.ao = ao; q.tv = (float)(1 - z / 1.5); R.push_back(q); };
    ring(-.15, .28, .36, 2.4, .7f); ring(.1, .34, .44, 2.5); ring(.6, .33, .44, 2.4); ring(.98, .35, .5, 2.4); ring(1.18, .34, .56, 2.7); ring(1.3, .28, .52, 2.9); ring(1.38, .18, .26, 2.2, .9f); ring(1.45, .12, .14, 2, .8f);
    const int SEG = 16; loftF(R, SEG, true, false, [&](int i, int jj, Col c) { return i == 0 ? blk : i >= 6 ? (i == 6 ? blk : skin) : (jj % 2 ? blk : c); }, &TP_FABRIC); }
  double up = r.arm > 0 ? r.arm : 0; shCap(t.ap({0, 0, .05 * s}), t.ap({0, 0, 1.1 * s}), .38 * s, .46 * s);
  for (int k = -1; k <= 1; k += 2) { V3 sh = t.ap({0, k * .48 * s, 1.22 * s}), hd = k > 0 ? t.ap({.15 * s, k * .62 * s, (.25 + up * 1.9) * s}) : t.ap({.15 * s, k * .6 * s, .25 * s});
    V3 el = ik2(sh, hd, .68 * s, .66 * s, V3{0, 0, -1} + t.Y * (k * .8) - t.X * .4);
    shCap(sh, el, .19 * s, .16 * s); shCap(el, hd, .15 * s, .14 * s);
    limb({{sh, .2 * s, blk}, {lerp3(sh, el, .5), .175 * s, org}, {lerp3(sh, el, .75), .165 * s, wht}, {el, .16 * s, blk}, {lerp3(el, hd, .5), .145 * s, wht}, {hd, .13 * s, wht, .8f}}, b.Z, 8, true, false);
    g_limbTex = nullptr; ball(hd, .14 * s, skin, 4, 7); g_limbTex = &TP_FABRIC; }
  g_limbTex = nullptr;
  { M3 nk = pitch(moveTo(t, {.02 * s, 0, 1.5 * s}), -.12); drawHead(nk, t.ap({0, 0, 1.36 * s}), skin, 2, blk, blk, blk); }
  g_gloss = .3f;
}
static void drawPuck3() {
  Puck &P = SK->puck; double z = (P.bz > 0 ? P.bz : 0) * VZ;
  // a small puck (an NHL puck is 3 inches across, 1 thick), tilting as it flutters
  shadow(P.x, P.y, .38 + std::min(z, 6.0) * .05);
  objAt(P.x, P.y, z + .1); prism({P.x, P.y, z + .02}, PUCK_R * 1.15, .19, 12, hex("#0b0b0b"), hex("#2a2a2a"));
}

// ---------------------------------------------------------------- on the ice: rings and aids (drawn under the players)
static void ringOn(double x, double y, double r, double w, double f, Col c, Col rest) {
  if (f > 0) iceArc(x, y, r, r + w, -PI / 2, -PI / 2 + f * 2 * PI, c, std::max(3, (int)(16 * f)), .05);
  if (f < 1) iceArc(x, y, r, r + w, -PI / 2 + f * 2 * PI, 1.5 * PI, rest, std::max(3, (int)(16 * (1 - f))), .05);
}
static void drawIceAids() {
  Puck &P = SK->puck; Skater *u = SK->user;
  if (!g_shOn) { for (Skater *p : skAll()) shadow(p->x, p->y, 1.5);
    for (int ti = 0; ti < 2; ti++) if (!SK->T[ti].g.out) shadow(SK->T[ti].g.x, SK->T[ti].g.y, 2); }
  if (SK->phase != PH_GOAL) for (Skater *p : skAll()) { double f = std::round(clamp(p->st / 100, 0, 1) * 16) / 16; bool low = f <= .25 && std::sin(now() / 170) > 0;
    ringOn(p->x, p->y, 1.9, .3, f, (p->tired || p->st <= 0) ? hex("#ef4444") : low ? rgba(239, 68, 68, .85) : rgba(34, 197, 94, .85), rgba(0, 0, 0, .35)); }
  if (u && onTeam(0, u)) ringOn(u->x, u->y, 2.3, .35, 1, hex("#ffd54a"), hex("#ffd54a"));
  if (P.owner && P.owner != u) ringOn(P.owner->x, P.owner->y, 2.3, .25, 1, P.owner->team == 0 ? hex("#93c5fd") : hex("#fca5a5"), hex("#fff"));
  if (skBenchOpen()) { BenchSpot B = skBench(); double k = .5 + .5 * std::sin(now() / 170); iceDisc(B.x, B.y, B.r, rgba(34, 197, 94, (float)(.15 + .12 * k)), 20, .03); ringOn(B.x, B.y, B.r - .3, .4, 1, hex("#22c55e"), hex("#22c55e")); }
}

// ---------------------------------------------------------------- the frame
void skDraw3D() {
  cam3Update(); g_gpu = plat_gpu3d(); g_half = norm(LIGHT - C3.f);
  if (g_gpu && g_texOn) texInit();
  g_tex = g_gpu && g_texOn; g_buf = 0; g_shOn = g_gpu;
  { // which size of the people's textures: about 1.5 texels per screen pixel on a jersey
    V3 tc = C3.e + C3.f * 1.0; (void)tc; double dist = std::max(8.0, (double)(C3.e.z / std::max(.15, -(double)C3.f.z))), ppf = C3.F / dist;
    g_plod = ppf > 20 ? 0 : ppf > 13 ? 1 : 2; }
#ifdef HOST_BUILD
  static const bool prof = getenv("CHL_PROF") != nullptr; static double acc[9] = {0}; static int frames = 0, tri[4] = {0};
  auto T0 = std::chrono::steady_clock::now(); int st = 0;
  auto lap = [&]() { auto t = std::chrono::steady_clock::now(); acc[st++] += std::chrono::duration<double, std::milli>(t - T0).count(); T0 = t; };
#define LAP() if (prof) lap()
#else
#define LAP()
#endif
  drawArena(); LAP();
  drawIceAids(); LAP();
  g_refl = g_gpu;
  drawBoards(); if (SK) { g_buf = 3; drawBench3(); g_lod = 1; g_buf = 0; } LAP();
  drawNet(0); drawNet(1); LAP();
  g_buf = 3;
  for (int ti = 0; ti < 2; ti++) { g_lod = lodFor(SK->T[ti].g.x, SK->T[ti].g.y, 3); drawGoalie3(SK->T[ti].g, ti); } LAP();
  for (Skater *p : skAll()) { g_lod = lodFor(p->x, p->y, 3); drawSkater3(p); } LAP();
  if (SK->hasRef) { g_lod = lodFor(SK->ref.x, SK->ref.y, 3); drawRef3(); }
  g_lod = 1; g_buf = 0;
#ifdef HOST_BUILD
  if (prof) { tri[0] += (int)(GB[0].size() + GB[3].size()) / 3; tri[1] += (int)GB[1].size() / 3; tri[2] += (int)GB[2].size() / 3; tri[3] += (int)GA.size(); }
#endif
  // the shot target, standing in the net mouth where the held shot is going: a solid ring, so if the goalie's body is
  // in front of it you see him covering it (a likely save); out in the open net it's blue (a likely goal)
  { Skater *u = SK->user; Puck &P = SK->puck;
    if (u && P.owner == u && (SK->rs.dn || (QO.shotB && SK->rs.aim)) && SK->phase == PH_PLAY && skInZone(u)) { Pt T = skAimTarget(u); double o = skShotOpen(u, T.y);
      Col c = o > 0 ? hex("#3b5bff") : o == 0 ? hex("#ff5c7a") : hex("#94a3b8"); double z = .45 * PZ * VZ, r = .95, x = T.x - tdir(u->team) * .2; objAt(x, T.y, z);
      bool kk = g_keep; g_keep = true;
      for (int i = 0; i < 16; i++) { double a0 = i * PI / 8, a1 = (i + 1) * PI / 8; tube({x, T.y + std::cos(a0) * r, z + std::sin(a0) * r}, {x, T.y + std::cos(a1) * r, z + std::sin(a1) * r}, .11, .11, c, 4, false); }
      blob(frameAt(x, T.y, z, 0), {0, 0, 0}, {.18, .18, .18}, c, 3, 6); g_keep = kk; } }
  drawPuck3();
  g_refl = false;
  LAP();
  if (g_gpu) flushGPU(); else flushQ();
#ifdef HOST_BUILD
  LAP(); if (prof && ++frames % 300 == 0) { const char *nm[] = {"arena", "iceaids", "boards", "nets", "goalies", "skaters", "puck/aim", "flush"};
    fprintf(stderr, "PROF ms/frame:"); for (int i = 0; i < 8; i++) fprintf(stderr, " %s %.3f", nm[i], acc[i] / 300); fprintf(stderr, " | tris solid %d ice %d refl %d alpha %d\n", tri[0] / 300, tri[1] / 300, tri[2] / 300, tri[3] / 300);
    for (double &x : acc) x = 0; for (int &x : tri) x = 0; }
#endif
  // the NHL aim cone: from the puck to where the held shot is going, as wide as the shooter's accuracy allows,
  // BLUE where it would find open net, PINK where his body is in the way (traced against the goalie's real body)
  { Skater *u = SK->user; Puck &P = SK->puck;
    if (u && P.owner == u && (SK->rs.dn || (QO.shotB && SK->rs.aim)) && SK->phase == PH_PLAY) { Pt T = skAimTarget(u); bool zone = skInZone(u);
      double dx = T.x - P.x, dy = T.y - P.y, L = hyp(dx, dy);
      if (L > 2) { double nx = -dy / L, ny = dx / L, w = std::max(.6, L * std::tan(skAimSpread(u))); const int N = 14; Pt a = sk3Proj(P.x, P.y, .05);
        ctx.alpha(.45);
        for (int i = 0; i < N; i++) { double s0 = -1 + 2.0 * i / N, s1 = -1 + 2.0 * (i + 1) / N, ym = T.y + ny * w * (s0 + s1) / 2;
          double o = zone ? skShotOpen(u, ym) : 1; ctx.fill(!zone ? hex("#facc15") : o > 0 ? hex("#5b6cff") : o == 0 ? hex("#ff8fa3") : hex("#94a3b8"));
          Pt b = sk3Proj(T.x + nx * w * s0, T.y + ny * w * s0, .05), c = sk3Proj(T.x + nx * w * s1, T.y + ny * w * s1, .05); ctx.quad(a.x, a.y, b.x, b.y, c.x, c.y, c.x, c.y); }
        ctx.alpha(1); } } }
  // a goal: the red light over the net
  if (SK->phase == PH_GOAL && SK->hasNetIn) { double gx = SK->netIn.gx; Pt q = sk3Proj(gx < RK.L / 2 ? RK.gl - RK.netD * 1.3 : RK.L - RK.gl + RK.netD * 1.3, RK.cy, (PZ + .2) * VZ + 2.5); double k = .5 + .5 * std::sin(now() / 90), r = .012 * U;
    ctx.alpha(.3 + .35 * k); ctx.fill("#ff2d2d"); ctx.disc(q.x, q.y, r * (2.2 + k)); ctx.alpha(1); ctx.fill(k > .5 ? "#ff6b6b" : "#dc2626"); ctx.fillRect(q.x - r, q.y - r * .8, r * 2, r * 1.6); }
}
#ifdef HOST_BUILD
void skGoalieDbg(Goalie &g, char *buf, int n) {   // test builds: where his hands are (lateral offset from him, physics height)
  GBody B; gBody(g, g.team & 1, B);
  snprintf(buf, n, "glove %.2f,%.2f blocker %.2f,%.2f head %.2f,%.2f low %.2f drop %.2f useHand %d useG %d aty %.2f atz %.2f k %.2f",
    B.gH.y - g.y, B.gH.z / VZ, B.bH.y - g.y, B.bH.z / VZ, B.hc.y - g.y, B.hc.z / VZ, B.low, B.drop, (int)B.useHand, (int)B.useG, B.aty, B.atz, B.k);
  { V3 pc = B.gm.ap({.28 * B.s, .12 * B.s, .22 * B.s}); double d = g.team == 0 ? 1 : -1; int a1 = skGoalieTouch(g, pc.x, pc.y, pc.z / VZ, PUCK_R, nullptr, nullptr);
    int a2 = skGoalieTouch(g, g.x + d * 1.9, g.y + g.aimY, g.aimZ / 1.7, PUCK_R, nullptr, nullptr);
    double gx = (B.gH.x - g.x) * d; int L = (int)strlen(buf); snprintf(buf + L, n - L, " | probe pocket %d aim %d gloveX %.2f pocketX %.2f", a1, a2, gx, (pc.x - g.x) * d); }
}
#endif

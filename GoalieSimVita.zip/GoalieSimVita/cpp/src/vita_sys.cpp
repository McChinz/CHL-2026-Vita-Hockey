// CHL 2026 native - PS Vita system layer shared by both renderers (platform_vitagl.cpp, platform_vita.cpp):
// clocks, the pad and the touch screen, the audio thread, files, and the steady 30 FPS pacing.
#include "platform.h"
#include "audio.h"
#include "vita_sys.h"
#include <psp2/kernel/processmgr.h>
#include <psp2/kernel/threadmgr.h>
#include <psp2/ctrl.h>
#include <psp2/touch.h>
#include <psp2/power.h>
#include <psp2/display.h>
#include <psp2/io/stat.h>
#include <psp2/audioout.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>

static volatile int g_au_run = 1;
static SceUID g_au_thread = -1;
static unsigned g_lastV = 0;

// ---- audio: the mixer runs on its own thread, one 512-sample grain at a time
static int au_thread(SceSize, void *) {
  au_synth_all();
  int port = sceAudioOutOpenPort(SCE_AUDIO_OUT_PORT_TYPE_MAIN, 512, 48000, SCE_AUDIO_OUT_MODE_MONO);
  if (port < 0) return 0;
  int vols[2] = {SCE_AUDIO_VOLUME_0DB, SCE_AUDIO_VOLUME_0DB};
  sceAudioOutSetVolume(port, (SceAudioOutChannelFlag)(SCE_AUDIO_VOLUME_FLAG_L_CH | SCE_AUDIO_VOLUME_FLAG_R_CH), vols);
  static int16_t out[2][512]; int b = 0;
  while (g_au_run) { au_mix(out[b], 512, 48000); sceAudioOutOutput(port, out[b]); b ^= 1; }
  sceAudioOutReleasePort(port);
  return 0;
}
int snd_play(int id, float vol, float rate, bool loop) { return au_play(id, vol, rate, loop); }
void snd_set(int v, float vol) { au_set(v, vol); }
void snd_stop(int v) { au_stop(v); }

void vita_sys_init() {
  scePowerSetArmClockFrequency(444);
  scePowerSetBusClockFrequency(222);
  scePowerSetGpuClockFrequency(222);
  scePowerSetGpuXbarClockFrequency(166);
  sceIoMkdir(DATA_DIR, 0777);
  sceTouchSetSamplingState(SCE_TOUCH_PORT_FRONT, SCE_TOUCH_SAMPLING_STATE_START);
  sceCtrlSetSamplingMode(SCE_CTRL_MODE_ANALOG);
  g_au_thread = sceKernelCreateThread("chl_audio", au_thread, 0x10000100, 0x10000, 0, 0, NULL);
  if (g_au_thread >= 0) sceKernelStartThread(g_au_thread, 0, NULL);
  g_lastV = sceDisplayGetVcount();
}
void vita_sys_fini() {
  g_au_run = 0;
  if (g_au_thread >= 0) { sceKernelWaitThreadEnd(g_au_thread, NULL, NULL); sceKernelDeleteThread(g_au_thread); }
}
// a steady 30 FPS: every frame shows for exactly two refreshes, so motion stays even
void vita_pace() { while ((int)(sceDisplayGetVcount() - g_lastV) < 2) sceDisplayWaitVblankStart(); }
void vita_paced() { g_lastV = sceDisplayGetVcount(); }
bool plat_running() { return true; }
double plat_now_ms() { return (double)sceKernelGetProcessTimeWide() / 1000.0; }
void plat_input(Pad &pad, Touch &touch) {
  SceCtrlData c; memset(&c, 0, sizeof c); sceCtrlPeekBufferPositive(0, &c, 1);
  SceTouchData tf; memset(&tf, 0, sizeof tf); sceTouchPeek(SCE_TOUCH_PORT_FRONT, &tf, 1);
  uint32_t b = 0;
  if (c.buttons & SCE_CTRL_LTRIGGER) b |= B_L;
  if (c.buttons & SCE_CTRL_RTRIGGER) b |= B_R;
  if (c.buttons & SCE_CTRL_START) b |= B_START;
  if (c.buttons & SCE_CTRL_SELECT) b |= B_SELECT;
  if (c.buttons & SCE_CTRL_CROSS) b |= B_CROSS;
  if (c.buttons & SCE_CTRL_CIRCLE) b |= B_CIRCLE;
  if (c.buttons & SCE_CTRL_SQUARE) b |= B_SQUARE;
  if (c.buttons & SCE_CTRL_TRIANGLE) b |= B_TRIANGLE;
  if (c.buttons & SCE_CTRL_UP) b |= B_UP;
  if (c.buttons & SCE_CTRL_DOWN) b |= B_DOWN;
  if (c.buttons & SCE_CTRL_LEFT) b |= B_LEFT;
  if (c.buttons & SCE_CTRL_RIGHT) b |= B_RIGHT;
  pad.btn = b; pad.lx = c.lx; pad.ly = c.ly; pad.rx = c.rx; pad.ry = c.ry;
  touch.n = 0;
  for (unsigned i = 0; i < tf.reportNum && touch.n < 6; i++)
    touch.p[touch.n++] = {(int)tf.report[i].id, tf.report[i].x * 960.f / 1920.f, tf.report[i].y * 544.f / 1088.f};
}
void plat_log(const std::string &s) { FILE *f = fopen(DATA_DIR "/log.txt", "a"); if (f) { fputs(s.c_str(), f); fputc('\n', f); fclose(f); } }
bool plat_read_file(const std::string &path, std::string &out) {
  FILE *f = fopen(path.c_str(), "rb"); if (!f) return false;
  fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
  out.resize(n > 0 ? n : 0); size_t got = n > 0 ? fread(&out[0], 1, n, f) : 0; fclose(f); out.resize(got); return true;
}
bool plat_write_file(const std::string &path, const std::string &data) {
  std::string tmp = path + ".tmp"; FILE *f = fopen(tmp.c_str(), "wb"); if (!f) return false;
  bool ok = fwrite(data.data(), 1, data.size(), f) == data.size(); fclose(f);
  if (ok) { remove(path.c_str()); ok = rename(tmp.c_str(), path.c_str()) == 0; }
  return ok;
}
std::string plat_data_dir() { return DATA_DIR "/"; }
std::string plat_legacy_dir() { return "ux0:data/GoalieSim/"; }

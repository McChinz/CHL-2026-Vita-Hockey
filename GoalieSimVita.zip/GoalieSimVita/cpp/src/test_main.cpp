#include "hockeymon.h"
#include <ctime>
// CHL 2026 native - desktop test driver (HOST_BUILD only, never in the Vita build).
//   chl_host games N [ovr]       play N full games with the CPU driving your skater, print the averages
//   chl_host shots DIR f1 f2 ... start from the menu, play (CPU-driven), save frames f1, f2 ... as PPM
//   chl_host bench N             time the update + draw of N frames of play
#include "game.h"
#include "sk_int.h"
#include "menu.h"
#include "emblem.h"
#include "ut_int.h"
#include "pro.h"
#include "apt.h"
#include "music.h"
#include "audio.h"
#include <chrono>
#include <unistd.h>
#include <cstring>
#include <map>
#include <cstdlib>
#include <functional>

void frameStep(bool draw);
void appInit();
void host_shot(const char *path);
extern std::function<void(Pad &, Touch &)> g_hostInput;
extern long g_hostTris, g_hostGlyphs, g_hostCalls;
extern int g_hostSnd[S_COUNT];
extern int g_pulls;
extern bool g_hostRaster;

int main(int argc, char **argv) { setvbuf(stdout, nullptr, _IOLBF, 0);
  plat_init(); appInit();
  std::string mode = argc > 1 ? argv[1] : "games";
  if (mode == "games") {
    int n = argc > 2 ? atoi(argv[2]) : 10; int ovArg = argc > 3 ? atoi(argv[3]) : 50; for (auto k : FKEYS) g_stats[k] = ovArg; mode = "quick";
    g_rng.s = 12345;
    g_autoplay = true; if (getenv("CHL_NOOFF")) g_rOff = false; if (getenv("CHL_NOICE")) g_rIce = false; if (getenv("CHL_NOPEN")) g_rPen = false;
    std::vector<int> perH, perA; long goals[2] = {0, 0}, sog[2] = {0, 0}, hits[2] = {0, 0}, pens = 0, fo = 0, frames = 0, ot = 0; int wins = 0, maxF = 0;
    for (int gi = 0; gi < n; gi++) {
      skStart(); state = ST_PLAY; long f = 0; if (getenv("CHL_PURE_AI")) SK->user->user = false;
      while (state == ST_PLAY && f < 200000) {
        Game *G = SK;
        // keep the last numbers before the game object goes away
        static int lg[2], ls[2], lh[2], lp, lf, lper;
        if (G) { for (int t = 0; t < 2; t++) { lg[t] = G->T[t].score; ls[t] = G->T[t].sog; lh[t] = G->T[t].hits; } lp = G->T[0].pen + G->T[1].pen; lf = G->T[0].fow + G->T[1].fow; lper = G->per; }
        frameStep(false); plat_end_frame(); f++;
        if (state != ST_PLAY) { for (int t = 0; t < 2; t++) { goals[t] += RS.valid ? (t ? RS.as : RS.hs) : lg[t]; sog[t] += ls[t]; hits[t] += lh[t]; } pens += lp; fo += lf; if (lper > 3) ot++; if (RS.hs > RS.as) wins++; perH.push_back(RS.valid ? RS.hs : lg[0]); perA.push_back(RS.valid ? RS.as : lg[1]); }
      }
      frames += f; maxF = std::max(maxF, (int)f);
    }
    printf("games %d (you %d OVR): goals/game %.2f (home %.2f away %.2f)  sog %.1f / %.1f  hits %.1f / %.1f  penalties %.2f  faceoffs %.1f  OT %ld  home wins %d  frames/game %ld\n",
      n, ovArg, (goals[0] + goals[1]) / (double)n, goals[0] / (double)n, goals[1] / (double)n, sog[0] / (double)n, sog[1] / (double)n, hits[0] / (double)n, hits[1] / (double)n, pens / (double)n, fo / (double)n, ot, wins, frames / n);
    { int h[12] = {0}, z = 0, six = 0, mn = 99, mx = 0; for (size_t i = 0; i < perH.size(); i++) { int t = perH[i] + perA[i]; h[std::min(11, t)]++; mn = std::min(mn, t); mx = std::max(mx, t);
        for (int v : {perH[i], perA[i]}) { if (v == 0) z++; if (v >= 6) six++; } }
      printf("totals:"); for (int i = 0; i < 12; i++) printf(" %d%s:%d", i, i == 11 ? "+" : "", h[i]); printf("  min %d max %d | a team scores 0: %.0f%%  a team scores 6+: %.1f%%\n", mn, mx, 100.0 * z / (2 * perH.size()), 100.0 * six / (2 * perH.size())); }
    { extern long g_offN; printf("offsides %ld  goalie pulls %d\n", g_offN, g_pulls); } printf("sounds:"); for (int i = 0; i < S_COUNT; i++) printf(" %d", g_hostSnd[i]); printf("\n");
    return 0;
  }
  if (mode == "pro") {   // chl_host pro SEASONS [LIVE_EVERY]: a whole simulated career (live CPU-played games every N days), checks each season
    int seasons = argc > 2 ? atoi(argv[2]) : 3, live = argc > 3 ? atoi(argv[3]) : 0; g_rng.s = argc > 4 ? atoi(argv[4]) : 777; ::mode = "pro";
    proNew(0, "TEST GUY", 19, 1); CR->draftDone = true; g_autoplay = true; int lastSeason = 0, liveN = 0; long steps = 0;
    while (CR && CR->phase != "retired" && CR->season <= seasons && steps++ < 200000) {
      Career &C = *CR;
      if (C.season != lastSeason) { lastSeason = C.season; }
      if (C.hasTrade) { printf("  [%s] age %d day %d %s -> %s (ovr %d ready %d): %s\n", C.trade.title.c_str(), C.age, C.day, C.L[C.trade.from].ab.c_str(), C.L[C.trade.to].ab.c_str(), proOvr(), readiness(), C.trade.why.c_str()); C.hasTrade = false; C.showTrade = false; }
      if (C.need) { negStart(true); negPush(); negAccept(); continue; }
      // spend XP on the lowest rating
      { std::string lo; int lv = 999; for (auto k : FKEYS) { int v = g_stats(k).i(50); if (v < lv) { lv = v; lo = k; } } int m; int c = proCostN(lo, 1, &m); if (m && C.xp >= c) proUpgrade(lo, 1); }
      if (C.phase == "over") {
        PP *Y = youMe(); PTeam &L = C.L[C.me];
        printf("  coach %.1f line %d cen %d offer %d fo %.0f/%.0f | ", C.coach, C.line + 1, (int)C.cen, C.cOffer, C.cFoW, C.cFoT);
        printf("SEASON %d  age %d  %s %s %d-%d  you %dG %dA  OVR %d  ready %d bar %d  xp %d cash %d  champ %s (other %s)  titles %d calder %d  NHL %dGP %dG %dA  AHL %dGP %dG %dA  players %zu  cap %.1f pay %.1f\n", C.season, C.age, proLg() ? "AHL" : "NHL", L.ab.c_str(), L.w, L.l, Y->gl, Y->as, proOvr(), readiness(), callBar(), C.xp, C.money, C.champ >= 0 ? C.L[C.champ].ab.c_str() : "-", C.ochamp >= 0 ? C.L[C.ochamp].ab.c_str() : "-", C.titles, C.calder, C.cGP, C.cG, C.cA, C.aGP, C.aG, C.aA, C.P.size(), capOf(), payroll(orgOf(C.me)));
        { int avN = 0, avA = 0, nN = 0, nA = 0; for (auto &q : C.P) if (!q->g && !q->me && q->t >= 0) { if (q->t < NA) { avN += ovQ(q.get()); nN++; } else { avA += ovQ(q.get()); nA++; } } int bs = 0, bmin = 99; for (int t = 0; t < 32; t++) { int m = 99; for (PP *q : teamS(t, false, true)) if (!q->me) m = std::min(m, ovQ(q)); bs += m; bmin = std::min(bmin, m); } printf("   avg skater OVR: NHL %d  AHL %d   weakest NHL regular: avg %d min %d\n", avN / std::max(1, nN), avA / std::max(1, nA), bs / 32, bmin); }
        int bad = 0; for (int t = 0; t < (int)C.L.size(); t++) { int s = (int)teamS(t, false, true).size(), g = (int)teamG(t).size(); if (s != 9 || g != 2) { bad++; printf("   roster %s: %d skaters %d goalies\n", C.L[t].ab.c_str(), s, g); } }
        std::vector<PP *> top; for (auto &q : C.P) if (!q->g && q->t >= 0) top.push_back(q.get()); std::sort(top.begin(), top.end(), [](PP *a, PP *b) { return a->gl + a->as > b->gl + b->as; });
        printf("   scoring leader %s %dG %dA | log: %s\n", top[0]->nm().c_str(), top[0]->gl, top[0]->as, C.log.empty() ? "" : C.log[0].s.c_str());
        proSave(); size_t n0 = C.P.size(); proLoadSlot(0); printf("   save/load: %zu -> %zu players, ovr %d\n", n0, CR ? CR->P.size() : 0, CR ? proOvr() : -1);
        { auto t0 = std::chrono::steady_clock::now(); proNextSeason(); printf("   offseason %.0f ms\n", std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count()); } continue; }
      if (userHurt()) { proSimHealthy(); continue; }
      if (offDay()) { if (C.money >= trainCost() && (C.ci % 2)) proDoTrain(C.ci % 4); else proSkipDay(); continue; }
      if (live > 0 && (C.day % live) == 0 && C.phase == "reg" && proCanPlay()) {
        startGame(); long f = 0;
        if (SK) { double a0 = 0, a1 = 0; for (Src *q : SK->T[0].allSk) a0 += ovSk(q); for (auto &L : SK->T[1].lines) for (Src *q : L) a1 += ovSk(q); int n1 = 0; for (auto &L : SK->T[1].lines) n1 += L.size();
          if (getenv("CHL_PRODBG")) printf("    start: home %s g %.0f (%zu sk avg %.0f) away %s g %.0f (%d sk avg %.0f) adj %.2f\n", SK->T[0].name.c_str(), SK->T[0].g.gs.ovr, SK->T[0].allSk.size(), a0 / std::max<size_t>(1, SK->T[0].allSk.size()), SK->T[1].name.c_str(), SK->T[1].g.gs.ovr, n1, a1 / std::max(1, n1), g_leagueAdj ? g_leagueAdj() : 0); } while (state == ST_PLAY && f < 200000) { frameStep(false); plat_end_frame(); f++; }
        liveN++; if (liveN <= 3 || liveN % 10 == 0 || getenv("CHL_PRODBG")) printf("  live game %d: %d-%d  you %dG %dA %dSOG  +%d XP +$%d  %s\n", liveN, rs.hs, rs.as, rs.f.g, rs.f.a, rs.f.sog, rs.xp, rs.cash, rs.note.c_str());
        state = ST_MENU; screen = "main"; if (C.day == 0 && C.phase == "reg") C.day = C.day; continue; }
      { auto t0 = std::chrono::steady_clock::now(); proSimGames(1); static double mx = 0; double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count(); if (ms > mx) { mx = ms; printf("   slowest sim day %.1f ms\n", ms); } }
    }
    if (CR && CR->phase == "retired") printf("RETIRED (%s) at %d, %d titles, career %dG %dA in %d GP\n", CR->retWhy.c_str(), CR->age, CR->titles, CR->cG, CR->cA, CR->cGP);
    return 0;
  }
  if (mode == "proload") {   // chl_host proload SLOT GAMES: load a saved career (old saves get the AHL added) and sim on
    int slot = argc > 2 ? atoi(argv[2]) : 0, n = argc > 3 ? atoi(argv[3]) : 20; ::mode = "pro"; proLoadSlot(slot);
    if (!CR) { printf("load failed\n"); return 1; }
    printf("loaded: %zu teams, %zu players, you %s (%s) age %d OVR %d debut %d\n", CR->L.size(), CR->P.size(), CR->L[CR->me].n.c_str(), proLg() ? "AHL" : "NHL", CR->age, proOvr(), CR->debut);
    for (int i = 0; i < n && CR->phase == "reg"; i++) { if (CR->need) { negStart(true); negAccept(); } while (offDay()) proSkipDay(); proSimGames(1); }
    int bad = 0; for (int t = 0; t < (int)CR->L.size(); t++) if (teamS(t, false, true).size() < 7 || teamG(t).size() != 2) bad++;
    printf("after %d games: day %d, %s %d-%d, rosters off %d, players %zu\n", n, CR->day, CR->L[CR->me].ab.c_str(), CR->L[CR->me].w, CR->L[CR->me].l, bad, CR->P.size());
    proSave(); proLoadSlot(slot); printf("save/load again: %zu teams %zu players\n", CR ? CR->L.size() : 0, CR ? CR->P.size() : 0); return 0; }
  if (mode == "probench") {   // a Be a Pro game: how the lines rotate, time on the bench, a sim to the next shift
    g_rng.s = 31; ::mode = "pro"; proNew(1, "BENCH TEST", 9, 1); CR->draftDone = true; while (offDay()) proSkipDay(); g_autoplay = true; startGame();
    long f = 0; double onT = 0, benchT = 0, li1 = 0, li2 = 0, aw[3] = {0, 0, 0}; int sims = 0, lastLi = -1, changes = 0;
    while (state == ST_PLAY && f < 200000) { frameStep(false); plat_end_frame(); f++; if (!SK || SK->phase != PH_PLAY) continue;
      double dt = 1 / 30.0; if (SK->uBench) benchT += dt; else onT += dt; if (SK->T[0].li == 1) li1 += dt; if (SK->T[0].li == 2) li2 += dt; aw[SK->T[1].li % 3] += dt;
      if (SK->T[0].li != lastLi) { changes++; lastLi = SK->T[0].li; }
      if (SK->uBench && getenv("SIMSHIFT") && f % 7 == 0) { int a = SK->T[0].score, b = SK->T[1].score; double c = SK->clock; skSimShift(); sims++; printf("  sim shift: clock %.0f -> %.0f, score %d-%d -> %d-%d, user on %d\n", c, SK ? SK->clock : 0, a, b, SK ? SK->T[0].score : 0, SK ? SK->T[1].score : 0, SK ? (int)!SK->uBench : -1); } }
    printf("you on ice %.0fs, bench %.0fs (line2 %.0f line3 %.0f), home line changes %d, away lines %.0f/%.0f/%.0f, sims %d, final %d-%d\n", onT, benchT, li1, li2, changes, aw[0], aw[1], aw[2], sims, rs.hs, rs.as);
    proDelete(1); return 0; }
  if (mode == "benchrun") {   // D-pad RIGHT when tired: the CPU skates you to the bench; quick play and Be a Pro
    for (int pm = 0; pm < 2; pm++) { g_rng.s = 7; if (pm) { ::mode = "pro"; proNew(1, "RUN TEST", 9, 1); CR->draftDone = true; while (offDay()) proSkipDay(); } else ::mode = "quick";
      startGame(); long f = 0; uint32_t btn = 0; g_hostInput = [&](Pad &p, Touch &) { p.btn = btn; };
      while (SK && SK->phase != PH_PLAY && f < 3000) { frameStep(false); plat_end_frame(); f++; if (SK && SK->phase == PH_PREVIEW) { btn = B_CROSS; } else btn = 0; }
      for (int i = 0; i < 200; i++) { frameStep(false); plat_end_frame(); }
      Skater *u = SK->user; u->st = 15; u->tired = true; if (SK->puck.owner == u) SK->puck.owner = nullptr;
      btn = B_RIGHT; frameStep(false); plat_end_frame(); btn = 0; printf("%s: benchRun %d open %d\n", pm ? "pro" : "quick", (int)SK->benchRun, (int)skBenchOpen());
      int t = 0; for (; t < 1200 && SK && SK->benchRun; t++) { frameStep(false); plat_end_frame(); if (SK->phase != PH_PLAY) break; }
      printf("   after %d frames: benchRun %d uBench %d st %.0f li %d phase %d onIce %d\n", t, (int)SK->benchRun, (int)SK->uBench, SK->user->st, SK->T[0].li, (int)SK->phase, (int)onTeam(0, SK->user));
      skQuit(); state = ST_MENU; if (pm) proDelete(1); }
    return 0; }
  if (mode == "gshots") {   // chl_host gshots DIR: the faceoff ring, play, the line-change reminder, the run to the bench, the pause settings, the career bench
    std::string dir = argc > 2 ? argv[2] : "."; g_rng.s = 11; ::mode = "quick";
    auto F = [](int n, bool d = false) { for (int i = 0; i < n; i++) { frameStep(d); plat_end_frame(); } };
    auto SH = [&](const char *nm) { g_hostRaster = true; frameStep(true); plat_end_frame(); g_hostRaster = false; host_shot((dir + "/" + nm + ".ppm").c_str()); printf("shot %s phase %d\n", nm, SK ? (int)SK->phase : -1); };
    uint32_t btn = 0; g_hostInput = [&](Pad &p, Touch &) { p.btn = btn; };
    startGame(); for (int i = 0; i < 4000 && SK && SK->phase != PH_FACEOFF; i++) { btn = (i % 20 == 0) ? B_CROSS : 0; F(1); } btn = 0;
    for (int i = 0; i < 600 && SK && !(SK->phase == PH_FACEOFF && SK->fo.t > SK->fo.show + .35); i++) F(1, true); SH("g1_faceoff");
    g_autoplay = true; F(900, true); SH("g2_play"); g_autoplay = false;
    for (int i = 0; i < 3000 && SK && SK->phase != PH_PLAY; i++) F(1, true);
    SK->user->st = 15; SK->user->tired = true; if (SK->puck.owner == SK->user) SK->puck.owner = nullptr; F(2, true); SH("g3_tired");
    btn = B_RIGHT; F(1, true); btn = 0; F(40, true); SH("g4_tobench");
    paused = true; pauseTab = 3; F(3, true); SH("g5_settings"); paused = false; skQuit(); state = ST_MENU;
    ::mode = "pro"; proNew(1, "BENCH SHOT", 9, 1); CR->draftDone = true; while (offDay()) proSkipDay(); g_autoplay = true; startGame();
    for (int i = 0; i < 6000 && SK && !SK->uBench; i++) { if (SK->phase == PH_PLAY && i > 600) { SK->user->st = 10; SK->user->tired = true; SK->benchRun = true; if (SK->puck.owner == SK->user) SK->puck.owner = nullptr; } F(1, i % 4 == 0); }
    F(60, true); SH("g6_bench"); skQuit(); proDelete(1); return 0; }
  if (mode == "proflow") {   // the menu flow by button ids: new career in file 3, draft, hub, a game, quit (sim the rest), continue
    auto F = [](int n) { for (int i = 0; i < n; i++) { frameStep(true); plat_end_frame(); } };
    auto P = [&](const char *id) { uiTap(id); F(40); printf("%-12s -> state %d mode %s screen %s%s\n", id, (int)state, ::mode.c_str(), screen.c_str(), CR ? (" | " + CR->L[CR->me].ab + " day " + istr(CR->day)).c_str() : ""); };
    F(5); P("mode:pro"); proDelete(2); P("pslot:2"); P("key:j"); P("key:o"); P("key:_"); P("key:^"); P("key:^"); P("key:d"); P("key:o"); P("namego"); P("ppos:L"); P("psh:R"); P("pnum:10"); P("pdiff:2"); P("pgo"); F(300); P("draftdone");
    while (offDay()) P("skipday"); P("play"); F(200); { uiTap("resume"); paused = true; uiTap("quit"); paused = false; F(5); printf("after quit: screen %s xp %d note %s\n", screen.c_str(), rs.xp, rs.note.c_str()); }
    P("nav:main"); P("sim1"); P("nav:modes"); P("cont"); P("nav:upg"); P("nav:main"); P("nav:office"); P("nav:main");
    printf("career %s #%d diff %d pos %c sh %c line %d coach %.1f\n", CR->nm.c_str(), CR->num, CR->diff, CR->pos, CR->sh, CR->line, CR->coach); proDelete(2); return 0; }
  if (mode == "sfx") {   // chl_host sfx DIR: the synthesized sounds as WAVs
    std::string dir = argc > 2 ? argv[2] : "."; au_synth_all(); extern bool au_dump(int id, const char *path);
    const char *nm[] = {"slap", "wrist", "pass", "save", "skate", "stop", "grunt1", "grunt2", "grunt3", "hit", "post", "amb", "cheer", "boo", "horn"};
    for (int i = 0; i < S_COUNT; i++) au_dump(i, (dir + "/" + nm[i] + ".wav").c_str()); return 0; }
  if (mode == "music") {   // chl_host music OUT.wav: the soundtrack through the real mixer (CHL_ASSETS points at the assets)
    std::string outp = argc > 2 ? argv[2] : "music.wav"; au_synth_all(); mus_init(); { int u = 0, n = mus_tracks(&u); printf("tracks %d (your own %d)\n", n, u); }
    if (getenv("CHL_MUSUSER")) { int u = 0, n = mus_tracks(&u); for (int i = 0; i < 40 && u; i++) { g_nowMs += 50; mus_frame(true); mus_pump(); MusNow m = mus_now(); if (m.idx >= n - u) { printf("user track up: %s - %s\n", m.artist.c_str(), m.title.c_str()); break; } mus_skip(); for (int k = 0; k < 20; k++) mus_pump(); } }
    std::vector<int16_t> all; int16_t buf[1024]; double t = 0; int lastIdx = -2; std::string lastErr;
    auto run = [&](double secs, bool want) { for (double e = 0; e < secs; e += 512.0 / 48000) { g_nowMs = t * 1000; mus_frame(want); mus_pump(); au_mix(buf, 512, 48000); all.insert(all.end(), buf, buf + 1024); t += 512.0 / 48000;
        MusNow m = mus_now(); if (m.idx != lastIdx) { lastIdx = m.idx; printf("%6.2fs now playing: %s - %s (%d)\n", t, m.artist.c_str(), m.title.c_str(), m.idx); }
        if (m.err != lastErr) { lastErr = m.err; if (!m.err.empty()) printf("%6.2fs error: %s\n", t, m.err.c_str()); } } };
    run(9, true); printf("-- skip\n"); mus_skip(); run(2, true); printf("-- a game starts\n"); run(1.5, false); printf("-- back to the menus\n"); run(9, true);
    FILE *f = fopen(outp.c_str(), "wb"); uint32_t n = (uint32_t)all.size() * 2, v; fwrite("RIFF", 1, 4, f); v = 36 + n; fwrite(&v, 4, 1, f); fwrite("WAVEfmt ", 1, 8, f); v = 16; fwrite(&v, 4, 1, f);
    uint16_t a = 1, c = 2, b = 16, ba = 4; fwrite(&a, 2, 1, f); fwrite(&c, 2, 1, f); v = 48000; fwrite(&v, 4, 1, f); v = 48000 * 4; fwrite(&v, 4, 1, f); fwrite(&ba, 2, 1, f); fwrite(&b, 2, 1, f); fwrite("data", 1, 4, f); fwrite(&n, 4, 1, f); fwrite(all.data(), 2, all.size(), f); fclose(f);
    for (int s = 0; s < (int)(all.size() / 96000); s++) { double e = 0; for (int i = 0; i < 96000; i++) e += (double)all[(size_t)s * 96000 + i] * all[(size_t)s * 96000 + i]; printf("%d:%.0f ", s, std::sqrt(e / 96000)); } printf("\n");
    // the popup over the main menu and in the apartment (frames advance the clock; the mixer runs between them)
    if (argc > 3) { std::string dir = argv[3]; ::mode = "quick"; state = ST_MENU; screen = "modes"; mus_skip();
      auto step = [&](int n) { for (int i = 0; i < n; i++) { frameStep(true); plat_end_frame(); for (int k = 0; k < 3; k++) { mus_pump(); au_mix(buf, 512, 48000); } } };
      auto shot = [&](const std::string &nm) { g_hostRaster = true; frameStep(true); plat_end_frame(); g_hostRaster = false; host_shot((dir + "/" + nm + ".ppm").c_str()); };
      step(40); shot("m0_menu_popup"); settings.music = false; step(30); settings.music = true; step(25); shot("m1_menu_rising"); step(200); shot("m2_menu_gone"); screen = "settings"; step(20); shot("m3_settings"); }
    return 0; }
  if (mode == "mech") {   // chl_host mech DIR: the rebound sprawl and a ragdolled skater, posed and rendered
    std::string dir = argc > 2 ? argv[2] : "."; ::mode = "quick"; g_rng.s = 5; skStart(); state = ST_PLAY; g_autoplay = true;
    auto F = [](int n) { for (int i = 0; i < n; i++) { frameStep(true); plat_end_frame(); } };
    while (SK && SK->phase != PH_PLAY) F(1);
    F(30); Game &G = *SK; Goalie &g = G.T[1].g; Puck &P = G.puck; double d = tdir(1), gx = defendX(1); printf("gx %.1f d %.0f cy %.1f\n", gx, d, RK.cy);
    P.owner = nullptr; P.x = gx + d * 12; P.y = RK.cy + 5; P.vx = d * 3; P.vy = 0; P.hasShot = false;
    Skater *a = G.T[0].on[0]; a->x = gx + d * 13; a->y = RK.cy + 3; a->vx = a->vy = 0;
    g.x = gx + d * 1.5; g.y = RK.cy; extern void skSprawlTest(Goalie &g); skSprawlTest(g);
    Skater *b = G.T[0].on.size() > 1 ? G.T[0].on[1] : a; b->x = gx + d * 16; b->y = RK.cy - 6; b->stun = 1.6; b->kd = true; b->rgA = 1.2; b->rgT = .6; b->rgSp = .5;
    for (int k = 0; k < 3; k++) { if (SK) { SK->cam = gx + d * 14; SK->camY = RK.cy; } g_hostRaster = true; frameStep(true); plat_end_frame(); g_hostRaster = false; host_shot((dir + "/mech" + istr(k) + ".ppm").c_str()); printf("shot mech%d: spr %.2f an %d p %d k-time %.2f phase %d\n", k, g.spr, (int)g.hasAn, (int)g.an.p, g.an.t, (int)G.phase); for (int i = 0; i < 6; i++) { if (SK) { SK->cam = gx + d * 14; SK->camY = RK.cy; } frameStep(false); plat_end_frame(); } if (!SK) break; }
    return 0; }
  if (mode == "menushots") {   // chl_host menushots DIR: the main menu (with each kind of 3D hero), the UT hub, settings
    std::string dir = argv[2]; auto F = [](int n) { for (int i = 0; i < n; i++) { frameStep(true); plat_end_frame(); } };
    auto shot = [&](const std::string &nm) { F(6); g_hostRaster = true; F(1); g_hostRaster = false; host_shot((dir + "/" + nm + ".ppm").c_str()); printf("shot %s screen %s\n", nm.c_str(), screen.c_str()); };
    state = ST_MENU; ::mode = "quick"; screen = "modes"; shot("m0_fresh");
    { HeroSpec h; h.nm = "Sam Quick"; h.j = hex("#1e88e5"); h.s = hex("#ffffff"); h.num = 44; h.tag = "SAM QUICK  |  71 OVR  |  QUICK PLAY"; setQuickHero(h); } shot("m1_quick");
    ::mode = "pro"; proEnter(); proNew(1, "Alex Ryan", 19, 1, 'C', 'R'); CR->draftDone = true; proSave(); setLast("pro", 1); ::mode = "quick"; screen = "modes"; shot("m2_pro"); { extern int g_heroPose; for (int k = 0; k < 5; k++) { g_heroPose = k; shot("hp_sk" + istr(k)); } g_heroPose = -1; }
    utNew(2, "TEST CLUB"); setLast("ut", 2); ::mode = "quick"; screen = "modes"; shot("m3_ut"); { extern int g_heroPose; for (int k = 0; k < 4; k++) { g_heroPose = k; shot("hp_g" + istr(k)); } g_heroPose = -1; }
    ::mode = "ut"; screen = "main"; shot("u0_hub");
    ::mode = "quick"; screen = "settings"; shot("s0_settings");
    proDelete(1); return 0; }
  if (mode == "uishots") {   // chl_host uishots DIR: every menu screen - Ultimate Franchise, the Be a Pro phone and its apps, quick play, practice, the pause menu
    std::string dir = argc > 2 ? argv[2] : "."; g_rng.s = 77;
    uint32_t btn = 0, prs = 0; Pad pd; pd.btn = 0; pd.lx = pd.ly = pd.rx = pd.ry = 128;
    g_hostInput = [&](Pad &p, Touch &t) { p = pd; p.btn = btn | prs; prs = 0; t.n = 0; };
    auto F = [](int n) { for (int i = 0; i < n; i++) { frameStep(true); plat_end_frame(); } };
    auto shot = [&](const std::string &nm) { F(16); g_hostRaster = true; F(1); g_hostRaster = false; host_shot((dir + "/" + nm + ".ppm").c_str()); printf("shot %-20s mode %-8s screen %s\n", nm.c_str(), ::mode.c_str(), screen.c_str()); };
    auto press = [&](uint32_t b) { prs = b; F(2); };
    state = ST_MENU; ::mode = "quick"; screen = "modes"; F(5); mPadUsed = true; mFocus = "mode:ut"; shot("m_focus_ut");
    mFocus = "cont"; F(3); press(B_LEFT); F(3); printf("left off the panel -> %s (want mode:pro)\n", mFocus.c_str()); mPadUsed = false;
    state = ST_MENU; ::mode = "ut"; screen = "utslots"; shot("u00_slots");
    utNew(2, "TEST CLUB"); UT->coins = 4200; UT->inv = {0, 1, 3}; state = ST_MENU; ::mode = "ut"; screen = "main"; shot("u01_hub");
    mPadUsed = true; mFocus = "ut:roster"; shot("u01b_hub_focus"); mPadUsed = false;
    for (auto sc : {"utpacks", "utinv", "utroster", "utopp", "utcamp", "utcup"}) { screen = sc; shot(std::string("u_") + sc); }
    { screen = "utroster"; F(3); uiTap("ur:0"); F(3); mPadUsed = true; printf("card menu nav:"); for (int k = 0; k < 6; k++) { press(B_DOWN); F(2); printf(" %s", mFocus.c_str()); } printf("\n");
      press(B_UP); F(2); press(B_UP); F(2); printf("  up x2: %s\n", mFocus.c_str()); uiTap("um:x"); F(3);
      mFocus = "ur:0"; F(2); press(B_TRIANGLE); F(20); press(B_TRIANGLE); F(4); printf("triangle twice: menu %d focus %s ->", (int)utMenuOn(), mFocus.c_str()); for (int k = 0; k < 5; k++) { press(B_DOWN); F(2); printf(" %s", mFocus.c_str()); } printf("\n");
      uiTap("um:x"); F(3); mPadUsed = false; screen = "main"; }
    ::mode = "quick"; screen = "main"; shot("q01_quick"); screen = "name"; nameFor = "ut"; pname = "BEARS"; shot("q02_name");
    ::mode = "practice"; screen = "main"; shot("q03_practice");
    ::mode = "quick"; screen = "main"; startGame(); F(30); g_autoplay = true; for (int i = 0; i < 300; i++) { frameStep(false); plat_end_frame(); } g_autoplay = false;
    press(B_START); shot("g0_pause"); press(B_R); shot("g1_pause"); press(B_R); press(B_R); shot("g3_pause"); press(B_START); skQuit(); F(60); state = ST_MENU;
    ::mode = "pro"; screen = "proslots"; shot("p00_slots");
    proEnter(); proNew(1, "ALEX RYAN", 19, 1); CR->draftDone = true; CR->money = 40000; proSimGames(12); printf("after 12 sims: +/- %d coach %.1f line %d msg [%s]\n", CR->st.pm, CR->coach, CR->line, CR->coachMsg.c_str()); proSimGames(20); printf("texts %d unread %d\n", (int)CR->texts.size(), proUnreadTexts()); for (int i = 0; i + 1 < (int)CR->texts.size(); i++) proAnswerText(i, i % 3); { proSave(); size_t n0 = CR->texts.size(); double c0 = proTeamChem(); proLoadSlot(1); printf("reload: texts %d/%d unread %d chem %.2f/%.2f\n", (int)CR->texts.size(), (int)n0, proUnreadTexts(), proTeamChem(), c0); } proSave(); screen = "main"; aptReset(); F(40);
    press(B_START); shot("p01_phone"); mFocus = "app:3"; shot("p01b_phone_focus");
    for (int i = 0; i < 14; i++) { uiTap("app:" + istr(i)); shot("p_app" + istr(i)); uiTap("ph:close"); F(3); }
    CR->phase = "retired"; CR->retWhy = "age"; screen = "retired"; shot("p_retired");
    proDelete(1);
    return 0; }
  if (mode == "utperf") {   // chl_host utperf: what each Ultimate Franchise screen costs a frame
    auto F = [](int n) { for (int i = 0; i < n; i++) { frameStep(true); plat_end_frame(); } };
    { extern bool g_hostRaster; g_hostRaster = false; } utNew(2, "TEST CLUB"); UT->coins = 4200; { size_t n0 = UT->cards.size(); for (int i = 0; i < 30; i++) { UCard c; c.u = 1000 + i; c.p = UT->cards[(size_t)i % n0].p; c.r = i % 7; UT->cards.push_back(c); } }
    state = ST_MENU; ::mode = "ut";
    for (auto sc : {"main", "utroster", "utinv", "utpacks"}) { screen = sc; F(8); g_hostTris = g_hostGlyphs = g_hostCalls = 0; F(1);
      g_hostTris = g_hostGlyphs = g_hostCalls = 0; auto tcpu = [] { timespec q; clock_gettime(CLOCK_THREAD_CPUTIME_ID, &q); return q.tv_sec * 1000.0 + q.tv_nsec / 1e6; }; int nf = 200; double t0 = tcpu(); for (int i = 0; i < nf; i++) frameStep(true); double ms = (tcpu() - t0) / nf;
      if (std::string(sc) == "utroster" && getenv("CHL_SHOT")) { g_hostRaster = true; frameStep(true); plat_end_frame(); g_hostRaster = false; host_shot(getenv("CHL_SHOT")); }
      printf("%-10s per frame: tris %6ld glyphs %5ld calls %5ld  cache %zu  cpu %.2f ms\n", sc, g_hostTris / nf, g_hostGlyphs / nf, g_hostCalls / nf, ctx.cacheSize(), ms); }
    return 0; }
  if (mode == "glovezoom") {   // chl_host glovezoom OUT.ppm [dx dy turn]: the goalie's trapper, close up (menu portrait)
    double dx = argc > 3 ? atof(argv[3]) : 0, dy = argc > 4 ? atof(argv[4]) : 0; float tn = argc > 5 ? (float)atof(argv[5]) : .3f;
    state = ST_MENU; ::mode = "quick"; screen = "blank";
    HeroSpec h; h.nm = "Zoom"; h.j = hex("#c8102e"); h.s = hex("#111111"); h.goalie = true;
    g_hostRaster = true; plat_begin_frame(0xff201208); ctx.fill("#335"); ctx.fillRect(0, 0, W, H);
    model3D(W / 2 + dx * W, H * 3.4 + dy * H, H * 4.2, h, 0, tn); ctx.frame(); plat_end_frame(); host_shot(argv[2]); return 0; }
  if (mode == "hmsheet") {   // chl_host hmsheet DIR: all 60 Hockeymon cards (two sheets), the packs, and pack-value odds
    std::string dir = argc > 2 ? argv[2] : ".";
    for (int sh = 0; sh < 2; sh++) { g_hostRaster = true; plat_begin_frame(0xff201208); ctx.fill("#0b1220"); ctx.fillRect(0, 0, W, H);
      double cw = W / 10.0 - 6, ch = cw * 1.4;
      for (int i = 0; i < 30; i++) { int id = sh * 30 + i; hmDrawCard(3 + (i % 10) * (cw + 6), 4 + (i / 10) * (ch + 6), cw, ch, id, id % 11 == 5 ? 1 : id % 17 == 9 ? 2 : 0); }
      ctx.frame(); plat_end_frame(); host_shot((dir + "/hm" + std::to_string(sh) + ".ppm").c_str()); }
    { g_hostRaster = true; plat_begin_frame(0xff201208); ctx.fill("#0b1220"); ctx.fillRect(0, 0, W, H); for (int k = 0; k < 3; k++) hmDrawPack(40 + k * 300, 40, 220, 330, k);
      for (int i = 0; i < 6; i++) hmDrawMon(i * 9, 60 + i * 150, 460, 120); ctx.frame(); plat_end_frame(); host_shot((dir + "/hmpacks.ppm").c_str()); }
    for (int k = 0; k < 3; k++) { int N = 20000; double sum = 0; int be = 0, big = 0; for (int n = 0; n < N; n++) { int v = 0; for (auto &c : hmRoll(k)) v += hmValue(c.id, c.v); sum += v; if (v >= hmPack(k).price * 100) be++; if (v >= hmPack(k).price * 1000) big++; }
      printf("%-14s $%d: average %s (%.0f%%)  break even %.1f%%  10x %.2f%%\n", hmPack(k).n, hmPack(k).price, hmCash((int)(sum / N)).c_str(), sum / N / hmPack(k).price, 100.0 * be / N, 100.0 * big / N); }
    return 0; }
  if (mode == "hmshots") {   // chl_host hmshots DIR: Be a Pro's Hockeymon app (shop, the door, opening, collection, a card) and Pong on the console
    std::string dir = argc > 2 ? argv[2] : "."; g_rng.s = 99;
    uint32_t prs = 0; Pad pd; pd.btn = 0; pd.lx = pd.ly = pd.rx = pd.ry = 128;
    g_hostInput = [&](Pad &p, Touch &t) { p = pd; p.btn |= prs; prs = 0; t.n = 0; };
    auto F = [](int n) { for (int i = 0; i < n; i++) { frameStep(true); plat_end_frame(); } };
    auto shot = [&](const std::string &nm) { F(10); g_hostRaster = true; F(1); g_hostRaster = false; host_shot((dir + "/" + nm + ".ppm").c_str()); printf("shot %s\n", nm.c_str()); };
    state = ST_MENU; proEnter(); proNew(1, "ALEX RYAN", 19, 1); CR->draftDone = true; CR->money = 900; proSave(); screen = "main"; aptReset(); F(40);
    prs = B_START; F(3); uiTap("app:13"); shot("h0_shop");
    uiTap("hm:buy:0"); uiTap("hm:buy:0"); uiTap("hm:buy:1"); uiTap("hm:buy:2"); printf("money after buying %d, pending %d %d %d\n", CR->money, CR->hmPend[0], CR->hmPend[1], CR->hmPend[2]);
    uiTap("ph:close"); F(3); prs = B_START; F(3); proSimGames(1); printf("after a game: door %d %d %d arrived %d\n", CR->hmDoor[0], CR->hmDoor[1], CR->hmDoor[2], CR->hmArrived);
    screen = "main"; F(20); prs = B_START; F(3); uiTap("app:13"); shot("h1_door");
    uiTap("hm:open:2"); uiTap("hm:rev"); uiTap("hm:rev"); uiTap("hm:rev"); shot("h2_opening"); uiTap("hm:revall"); shot("h3_opened"); uiTap("hm:done");
    uiTap("hm:open:0"); uiTap("hm:revall"); uiTap("hm:done"); uiTap("hm:open:0"); uiTap("hm:revall"); uiTap("hm:done"); uiTap("hm:open:1"); uiTap("hm:revall"); uiTap("hm:done");
    uiTap("hm:tab:2"); shot("h4_collection"); printf("owned %d/60 value %s opened %d dups %s\n", proHmOwned(), hmCash(proHmValue()).c_str(), CR->hmOpened, hmCash(proHmDupValue()).c_str());
    { int id = -1; for (int i = 0; i < HM_N; i++) if (CR->hmCnt[i][0] + CR->hmCnt[i][1] + CR->hmCnt[i][2]) { id = i; break; } uiTap("hm:mon:" + istr(id)); shot("h5_card"); int m0 = CR->money; uiTap("hm:sell:" + istr(id) + ":" + istr(CR->hmCnt[id][0] ? 0 : 1)); printf("sold: money %d -> %d cents %d\n", m0, CR->money, CR->hmCents); uiTap("hm:back"); }
    uiTap("ph:close"); F(3); prs = B_START; F(3); screen = "main";
    HOME.sel[HS_CONSOLE] = 1; HOME.own[HS_CONSOLE] = 3; aptDirty(); F(20); aptView(4.4, 8.6, 3.14159, -.85); F(3); printf("look at console: %d (want %d)\n", aptLook(), APT_CONSOLE); shot("h6_console");
    prs = B_CROSS; F(2); pd.btn = B_UP; F(30); pd.btn = 0; F(60); shot("h7_pong"); prs = B_CIRCLE; F(3); printf("after O: look %d\n", aptLook());
    proDelete(1); return 0; }
  if (mode == "volslide") {   // chl_host volslide: the SFX / MUSIC sliders under the pad
    ::mode = "quick"; state = ST_MENU; screen = "settings"; setVolume(false, 50, false); setVolume(true, 50, false);
    uint32_t btn = 0, prs = 0; Pad pd; pd.btn = 0; pd.lx = pd.ly = pd.rx = pd.ry = 128;
    g_hostInput = [&](Pad &p, Touch &t) { p = pd; p.btn = btn | prs; prs = 0; t.n = 0; };
    auto F = [](int n) { for (int i = 0; i < n; i++) { frameStep(true); plat_end_frame(); usleep(33000); } };
    F(10); mPadUsed = true; mFocus = "set:sfx"; F(2);
    prs = B_RIGHT; F(1); F(5); printf("dpad tap right: sfx %d (want 51)\n", settings.sfxV);
    prs = 2; F(3); printf("R: sfx %d (want 61)\n", settings.sfxV); prs = 1; F(3); printf("L: sfx %d (want 51)\n", settings.sfxV);
    btn = B_LEFT; F(9); printf("held left .3s: sfx %d\n", settings.sfxV); F(15); printf("held left .8s: sfx %d\n", settings.sfxV); F(30); printf("held left 1.8s: sfx %d\n", settings.sfxV); btn = 0; F(3);
    printf("focus still %s\n", mFocus.c_str());
    mFocus = "set:music"; F(2); pd.lx = 250; F(2); pd.lx = 128; F(3); printf("stick nudge: music %d (want 51)\n", settings.musV);
    pd.lx = 250; F(45); pd.lx = 128; F(3); printf("stick held 1.5s: music %d  focus %s\n", settings.musV, mFocus.c_str());
    prs = B_CROSS; F(3); printf("X: music %d (muted)\n", settings.musV); prs = B_CROSS; F(3); printf("X again: music %d\n", settings.musV);
    prs = B_DOWN; F(3); printf("down: focus %s\n", mFocus.c_str());
    return 0; }
  if (mode == "proexit") {   // chl_host proexit: the phone's EXIT BE A PRO app lands on the main menu
    g_rng.s = 3; ::mode = "pro"; state = ST_MENU; proEnter(); proNew(1, "EXIT TEST", 9, 1); CR->draftDone = true; proSave(); screen = "main";
    auto F = [](int n) { for (int i = 0; i < n; i++) { frameStep(true); plat_end_frame(); } }; F(60);
    printf("before: mode %s screen %s world %d\n", ::mode.c_str(), screen.c_str(), (int)proAptWorld());
    uiTap("app:15"); F(90); printf("after: mode %s screen %s state %d world %d apt %d\n", ::mode.c_str(), screen.c_str(), (int)state, (int)proAptWorld(), (int)aptReady());
    proDelete(1); return 0; }
  if (mode == "aptv") {   // chl_host aptv DIR LVL ALL "x y yaw pitch name" ...: quick views of an apartment (ALL 1: every upgrade at its best)
    std::string dir = argv[2]; g_rng.s = 99; ::mode = "pro"; state = ST_MENU; proEnter(); proNew(1, "ALEX RYAN", 19, 1); CR->draftDone = true; CR->money = 900000; screen = "main"; aptReset();
    int lvl = atoi(argv[3]); for (int l = 1; l <= lvl; l++) homeMove(l); if (atoi(argv[4])) { for (int sl = 0; sl < HOME_NS; sl++) { if (sl >= HS_PAINT && sl < HS_PAINT + HOME_NR) continue; homeBuy(sl, (int)HSLOT[sl].o.size() - 1); } for (int sl = HS_PAINT; sl < HS_PAINT + HOME_NR; sl++) homeBuy(sl, 1); for (int b = 0; b < APT_NJUNK; b++) aptThrow(b); }
    for (int i = 0; i < APT_NHD; i++) aptDoor(i);
    auto F = [](int n, bool d = true) { for (int i = 0; i < n; i++) { frameStep(d); plat_end_frame(); } }; F(60);
    for (int a = 5; a < argc; a++) { double x, y, yaw, pit; char nm[64]; if (sscanf(argv[a], "%lf %lf %lf %lf %63s", &x, &y, &yaw, &pit, nm) != 5) continue; aptView(x, y, yaw, pit); F(3); g_hostRaster = true; F(1); g_hostRaster = false; host_shot((dir + "/" + nm + ".ppm").c_str()); }
    printf("lvl %d tris %d\n", HOME.lvl, aptTris()); proDelete(1); return 0; }
  if (mode == "apt") {   // chl_host apt DIR: the apartment hub - views, build mode, the phone and its apps, the stores, the door, calls, the post-game
    std::string dir = argc > 2 ? argv[2] : "."; g_rng.s = 99; ::mode = "pro"; state = ST_MENU; proEnter();
    proNew(1, "ALEX RYAN", 19, 1); CR->draftDone = true; CR->money = 40000; proSave(); screen = "main"; aptReset();
    uint32_t btn = 0, prs = 0; Pad pd; pd.btn = 0; pd.lx = pd.ly = pd.rx = pd.ry = 128;
    g_hostInput = [&](Pad &p, Touch &t) { p = pd; p.btn = btn | prs; prs = 0; t.n = 0; };
    auto F = [](int n, bool d = true) { for (int i = 0; i < n; i++) { frameStep(d); plat_end_frame(); } };
    auto shot = [&](const std::string &nm) { F(14); g_hostRaster = true; F(1); g_hostRaster = false; host_shot((dir + "/" + nm + ".ppm").c_str()); printf("shot %-26s screen %-8s look %d\n", nm.c_str(), screen.c_str(), aptLook()); };
    auto press = [&](uint32_t b) { prs = b; F(2); };
    auto V = [&](double x, double y, double yaw, double pit, const char *nm) { aptView(x, y, yaw, pit); shot(nm); };
    F(40); printf("loaded: screen %s ready %d tris %d\n", screen.c_str(), (int)aptReady(), aptTris());
    V(3.5, 2.6, .85, -.05, "a00_spawn"); V(13.5, 12.0, -2.4, -.12, "a01_living"); V(16.0, 3.0, 0.0, -.1, "a03_kitchen"); V(10.0, 20.0, 2.6, -.2, "a06_bedroom"); V(24.0, 19.0, .4, -.15, "a07_office");
    V(3.5, 5.5, -1.5708, -.12, "a09_jersey"); V(17.0, 20.0, 3.14159, -.05, "a05_hall_door");
    // build mode: the couch store, then walls (drywall -> paint) and floors in a couple of rooms, the counter
    aptView(6.5, 7.0, 0, -.25); press(B_LEFT); F(4); shot("a10_build_couch"); press(B_CROSS); shot("a11_store_couch"); uiTap("hb:0:2"); uiTap("hcol:2"); shot("a11b_pick_couch"); uiTap("hpick:ok"); printf("couch sel %d col %d\n", HOME.sel[0], HOME.col[0]); uiTap("ph:close"); F(4);
    aptView(6.0, 4.0, -1.5708, 0); F(2); printf("wall look %d (drywall living = %d)\n", aptLook(), APT_SLOT + HS_WALL); press(B_CROSS); shot("a12_store_drywall"); uiTap("hb:" + istr(HS_WALL) + ":1"); uiTap("ph:close"); F(4);
    printf("wall look now %d (paint living = %d)\n", aptLook(), APT_SLOT + HS_PAINT); press(B_CROSS); shot("a13_store_paint"); uiTap("hb:" + istr(HS_PAINT) + ":2"); uiTap("hcol:9"); shot("a13b_pick_paint"); uiTap("hpick:ok"); uiTap("ph:close"); F(4);
    aptView(9, 7, 3.14159, -.7); F(2); printf("floor look %d\n", aptLook()); uiTap("hb:" + istr(HS_FLOOR) + ":2"); uiTap("hcol:1"); uiTap("hpick:ok"); homeBuy(HS_TV, 3); homeBuy(HS_ENT, 3);
    homeBuy(HS_WALL + 1, 1); homeBuy(HS_PAINT + 1, 1); homeBuy(HS_FLOOR + 1, 3);
    V(13.5, 12.0, -2.4, -.12, "a14_living_upgraded"); V(16.0, 3.0, 0.0, -.1, "a15_kitchen_upgraded");
    aptView(29.0, 5.0, 0, -.35); F(2); printf("counter look %d\n", aptLook()); press(B_CROSS); for (int i : {2, 3, 6, 7, 0}) { uiTap("hc:" + istr(i)); uiTap("hcol:" + istr(i % 5)); uiTap("hpick:ok"); } shot("a16_store_counter"); uiTap("ph:close"); F(4);
    V(29.5, 5.5, 0.15, -.3, "a17_counter_items"); press(B_LEFT);
    // junk: the laundry (with its confirm)
    aptView(16.5, 5.0, 2.23, -1.0); F(2); printf("junk look %d\n", aptLook()); press(B_CROSS); F(4); uiTap("mdl:yes"); F(4); printf("junk bits %d\n", HOME.junk);
    // the computer: move to the corner unit, put in a recliner and an island
    aptView(29.0, 21.0, 1.35, -.25); F(2); printf("pc look %d\n", aptLook()); press(B_CROSS); shot("a20_computer"); uiTap("pc:1"); F(40);
    printf("moved: lvl %d money %d ready %d tris %d | kept: couch %d/%d floor %d/%d paint %d/%d junk %d counter %d %d\n", HOME.lvl, CR->money, (int)aptReady(), aptTris(), HOME.sel[0], HOME.col[0], HOME.sel[HS_FLOOR], HOME.col[HS_FLOOR], HOME.sel[HS_PAINT], HOME.col[HS_PAINT], HOME.junk, HOME.ctr[0], HOME.ctr[1]);
    homeBuy(HS_RECL, 2); homeBuy(HS_ISLE, 2); V(15.5, 3.0, 2.3, -.15, "a21_corner_living"); V(22.0, 2.0, .5, -.25, "a22_corner_kitchen"); V(10.0, 24.0, 2.6, -.2, "a23_corner_bedroom");
    printf("home bonus: fstam %.2f pass %.2f edge %.2f sacc %.2f  (gearPts fstam %.2f)\n", homePts("fstam"), homePts("pass"), homePts("edge"), homePts("sacc"), gearPts("fstam"));
    // the bathroom, the office chair, the radio
    V(17.0, 22.0, 1.5708, -.1, "a24_corner_bath_door"); aptDoor(2); F(40); V(17.0, 21.5, 1.5708, -.25, "a25_corner_bath"); V(18.6, 26.2, -2.6, -.3, "a26_bath_inside");
    V(37.0, 25.5, 1.2, -.3, "a27_office_chair");
    aptView(3.0, 4.0, -2.2, -.3); F(2); printf("radio look %d (want %d)\n", aptLook(), APT_RADIO); { MusNow m0 = mus_now(); press(B_CROSS); F(4); printf("radio: music %d idx %d -> %d\n", (int)settings.music, m0.idx, mus_now().idx); } shot("a28_radio");
    aptView(5.7, 2.6, -1.5708, -.25); F(2); printf("switch look %d (want %d)\n", aptLook(), APT_LIGHT); press(B_CROSS); F(3); printf("living lights on %d\n", (int)aptLightOn(0)); V(9.0, 9.0, -2.0, -.1, "a29_lights_off"); press(B_CROSS); F(2); aptLight(0); F(2);
    // the penthouse: everything in it
    CR->money += 300000; aptView(37.0, 25.5, 1.3, -.25); F(2); printf("pc look %d\n", aptLook()); press(B_CROSS); shot("a30_computer3"); uiTap("pc:2"); F(40);
    printf("penthouse: lvl %d money %d ready %d tris %d | kept: couch %d/%d floor %d/%d paint %d/%d recl %d isle %d\n", HOME.lvl, CR->money, (int)aptReady(), aptTris(), HOME.sel[0], HOME.col[0], HOME.sel[HS_FLOOR], HOME.col[HS_FLOOR], HOME.sel[HS_PAINT], HOME.col[HS_PAINT], HOME.sel[HS_RECL], HOME.sel[HS_ISLE]);
    for (int sl : {HS_ISLE, HS_BAR, HS_GAME, HS_CAVE, HS_BED, HS_RECL, HS_COUCH}) homeBuy(sl, 3);
    V(20.0, 2.0, .35, -.2, "a31_pent_kitchen"); V(46.0, 20.0, -.9, -.15, "a32_cave_bar"); V(46.0, 9.0, 1.2, -.2, "a33_cave_pool"); V(51.0, 10.5, 1.5708, -.05, "a34_cave_seats");
    V(51.0, 12.0, -1.5708, .15, "a35_cave_banner"); V(9.0, 22.5, 2.3, -.3, "a36_pent_bed"); aptDoor(2); F(40); V(17.0, 27.5, 1.5708, -.3, "a37_pent_bath");
    homeBuy(HS_BAR, 2); homeBuy(HS_GAME, 2); homeBuy(HS_CAVE, 1); V(46.0, 20.0, -.9, -.15, "a38_cave_v2"); homeBuy(HS_GAME, 1); homeBuy(HS_CAVE, 2); V(46.0, 9.0, 1.2, -.2, "a39_cave_v2b");
    for (int sl : {HS_BAR, HS_GAME, HS_CAVE}) homeBuy(sl, 3);
    // walk: through the office into the cave (collision sanity)
    aptView(30.0, 20.0, 0, 0); for (int i = 0; i < 200; i++) { pd.ly = 0; F(1); } pd.ly = 128; { double x, y; aptPos(x, y); printf("walked to %.1f %.1f (cave starts at 44)\n", x, y); }
    // the phone: every app
    aptReset(); F(4); press(B_START); F(20); shot("b00_phone");
    for (int i = 0; i < 14; i++) { uiTap("app:" + istr(i)); shot("b1" + std::string(i < 10 ? "0" : "") + istr(i) + "_app"); press(B_CIRCLE); F(4); if (screen != "main") printf("  app %d: O left screen %s\n", i, screen.c_str()); }
    press(B_START); F(4); printf("phone closed: world %d\n", (int)proAptWorld());
    // an incoming call (contract talks)
    CR->need = true; F(10); shot("b20_call"); press(B_CROSS); F(6); shot("b21_call_answered"); printf("after answering: screen %s\n", screen.c_str()); CR->need = false; press(B_START); F(4);
    // the door: play a game, then the post-game screens and the couch
    aptView(3.5, 3.4, -1.5708, -.1); F(2); press(B_CROSS); shot("b30_door"); press(B_CIRCLE); F(4); printf("after O at the door: world %d\n", (int)proAptWorld());
    startGame(); printf("game started: apartment ready %d\n", (int)aptReady());
    g_autoplay = true; double t0 = plat_now_ms(); int fr = 0; while (state == ST_PLAY && fr < 60000) { frameStep(false); plat_end_frame(); fr++; } g_autoplay = false; (void)t0;
    printf("game over after %d frames: state %d screen %s  score %d-%d  you %dG %dA %d shots %d pass %d blk %.0fs toi\n", fr, (int)state, screen.c_str(), rs.hs, rs.as, rs.f.g, rs.f.a, rs.f.shots, rs.f.pass, rs.f.blk, rs.f.toi);
    printf("by period: %d %d %d %d | %d %d %d %d  shots %d %d %d | %d %d %d\n", rs.pg[0][0], rs.pg[0][1], rs.pg[0][2], rs.pg[0][3], rs.pg[1][0], rs.pg[1][1], rs.pg[1][2], rs.pg[1][3], rs.ps[0][0], rs.ps[0][1], rs.ps[0][2], rs.ps[1][0], rs.ps[1][1], rs.ps[1][2]);
    CR->cOffer = 1; CR->coachMsg = "You're winning draws. Want to take the middle?"; shot("c00_result"); uiTap("pres:next"); F(30); shot("c01_skills"); uiTap("pres:next"); F(45); shot("c01b_goals"); uiTap("pres:next"); F(60); shot("c02_couch"); printf("sitting %d\n", (int)aptSitting()); press(B_CROSS); F(10); printf("stood: sitting %d world %d\n", (int)aptSitting(), (int)proAptWorld());
    printf("season: gp %d g %d a %d sh %d pass %d blk %d toi %.1f  | yearly goals %d\n", CR->st.gp, CR->st.g, CR->st.a, CR->st.sh, CR->st.pass, CR->st.blk, CR->st.toi, (int)CR->yr.goals.size());
    proDelete(1); return 0; }
  if (mode == "skate4") {   // chl_host skate4: four live Be a Pro games (CPU-played) - how fast do skating / edges / the coach move
    g_rng.s = 77; ::mode = "pro"; proNew(1, "SKATE TEST", 9, 1, getenv("CHL_POS") ? getenv("CHL_POS")[0] : (char)67); CR->draftDone = true; if (getenv("CHL_LINE")) CR->line = atoi(getenv("CHL_LINE")); int ng = argc > 2 ? atoi(argv[2]) : 4;
    for (int gi = 0; gi < ng; gi++) { while (offDay()) proSkipDay(); startGame(); g_autoplay = true; int fr = 0; while (state == ST_PLAY && fr < 60000) { frameStep(false); plat_end_frame(); fr++; }
      g_autoplay = false; if (getenv("CHL_LINE")) CR->line = atoi(getenv("CHL_LINE")); uiTap("pres:skip"); for (int i = 0; i < 5; i++) { frameStep(false); plat_end_frame(); }
      printf("game %d: skate %d (%.2f) edge %d  toi %.0fs  coach %.1f line %d  pm %d ozt %.0f tk %d fo %d/%d\n", gi + 1, (int)g_stats("skate").i(), CR->sxp["skate"], (int)g_stats("edge").i(), rs.f.toi, CR->coach, CR->line + 1, rs.f.pm, rs.f.ozt, rs.f.tk, rs.f.fow, rs.f.fot);
      state = ST_MENU; screen = "main"; }
    proDelete(1); return 0; }
  if (mode == "hstop") {   // chl_host hstop: hard stops - rolling the stick around vs snapping it back; a check called off with X
    g_rng.s = 5; ::mode = "quick"; auto F = [](int n) { for (int i = 0; i < n; i++) { frameStep(true); plat_end_frame(); } };
    Pad pd; pd.btn = 0; pd.lx = pd.ly = pd.rx = pd.ry = 128; uint32_t prs = 0; g_hostInput = [&](Pad &p, Touch &t) { p = pd; t.n = 0; (void)prs; };
    startGame(); for (int i = 0; i < 4000 && SK && SK->phase != PH_PLAY; i++) { pd.btn = (i % 20 == 0) ? B_CROSS : 0; F(1); } pd.btn = 0;
    auto stick = [&](double a, double m) { pd.lx = (unsigned char)clamp(128 + std::cos(a) * m * 127, 0, 255); pd.ly = (unsigned char)clamp(128 + std::sin(a) * m * 127, 0, 255); };
    Skater *u = SK->user; int stops = 0; double lastHs = 0;
    auto count = [&] { if (SK->user != u) { printf("  user switched!\n"); u = SK->user; } if (u->hs > lastHs + .1) stops++; lastHs = u->hs; };
    auto reset = [&] { u = SK->user; SK->phase = PH_PLAY; u->x = RK.L * .3; u->y = RK.cy; u->vx = u->vy = 0; u->st = 100; u->hsCd = 0; SK->puck.owner = nullptr; SK->puck.x = 5; SK->puck.y = 5; };
    // 1: skate, then roll the stick around in circles (fast and slow), 6 s
    reset(); stick(-PI / 2, 1); for (int i = 0; i < 30; i++) { F(1); if (i % 10 == 0) printf("  f%d ph %d spd %.1f x %.1f stun %.2f lx %d g_pad.lx %d\n", i, (int)SK->phase, hyp(u->vx, u->vy), u->x, u->stun, pd.lx, (int)g_pad.lx); } stops = 0;
    int ph0 = 0; for (int i = 0; i < 360; i++) { SK->clock = 600; ph0 += SK->phase == PH_PLAY; stick(i * (i < 180 ? .2 : .35), 1); F(1); count(); }
    printf("rolling the stick: %d hard stops (%d/360 frames in play)\n", stops, ph0);
    // 2: skate one way, snap it back through the middle, 5 times
    int snaps = 0; for (int k = 0; k < 5; k++) { reset(); stick(-PI / 2, 1); F(40); stops = 0; if (k<2) printf("  speed %.1f phase %d user %p same %d stun %.2f\n", hyp(u->vx, u->vy), (int)SK->phase, (void*)SK->user, (int)(SK->user==u), u->stun); stick(-PI / 2, .1); F(1); stick(PI / 2, 1); for (int i = 0; i < 10; i++) { F(1); count(); } snaps += stops > 0; }
    printf("snapping it back: %d of 5 hard stops\n", snaps);
    // 3: a quick flip around the rim (no centre) in 4 frames
    int flips = 0; for (int k = 0; k < 5; k++) { reset(); stick(-PI / 2, 1); F(40); stops = 0; for (int i = 1; i <= 4; i++) { stick(-PI / 2 + PI * i / 4, 1); F(1); count(); } for (int i = 0; i < 8; i++) { F(1); count(); } flips += stops > 0; }
    printf("fast flip around the rim: %d of 5 hard stops\n", flips);
    // 5: right stick already pushed (e.g. from stick-checking), then a pass arrives: no shot until the stick comes back through centre
    auto give = [&] { SK->puck.owner = u; SK->puck.x = u->x; SK->puck.y = u->y; SK->puck.hasShot = false; u->gotT = SK->gt; u->gotPass = true; };
    int fired = 0; for (int k = 0; k < 5; k++) { reset(); stick(0, 0); pd.rx = 128 + (k % 2 ? 120 : -120); pd.ry = 128 + (k * 30 - 60); F(20); give(); for (int i = 0; i < 40; i++) { F(1); if (SK->puck.owner != u || SK->puck.hasShot) { fired++; break; } } }
    printf("pass arrives with the right stick already held: %d of 5 shot\n", fired);
    int flick = 0; for (int k = 0; k < 5; k++) { reset(); stick(0, 0); pd.rx = pd.ry = 128; F(5); give(); F(10); for (int i = 0; i < 6; i++) { pd.ry = (unsigned char)(128 + i * 25); F(1); } for (int i = 0; i < 6; i++) { pd.ry = (unsigned char)(255 - i * 40); F(1); } pd.ry = 0; F(2); pd.ry = 128; F(10); flick += SK->puck.owner != u || SK->puck.hasShot; }
    printf("fresh right-stick shot after the catch: %d of 5 shot\n", flick);
    pd.rx = pd.ry = 128;
    // 4: load a check (hold O), tap X: called off, no dash, stamina kept
    reset(); stick(0, 0); F(5); double st0 = u->st; pd.btn = B_CIRCLE; F(20); printf("  loading: ck.dn %d t %.2f owner team %d\n", (int)SK->ck.dn, SK->ck.t, SK->puck.owner ? SK->puck.owner->team : -1); pd.btn = B_CIRCLE | B_CROSS; F(1); pd.btn = B_CIRCLE; F(5); pd.btn = 0; F(10);
    printf("check called off: dash %.2f  stamina %.0f -> %.0f  ck.dn %d\n", u->dash, st0, u->st, (int)SK->ck.dn);
    reset(); st0 = u->st; pd.btn = B_CIRCLE; F(20); pd.btn = 0; F(2); printf("check let go: dash %.2f stamina %.0f -> %.0f\n", u->dash, st0, u->st);
    skQuit(); return 0; }
  if (mode == "v08") { extern bool BJS_active(); extern int slRollT(); extern int slPayT(const int *); extern bool g_camHigh;   // chl_host v08 DIR: a road game (white sweaters, emblems), the casino, the settings, the phone
    std::string dir = argc > 2 ? argv[2] : "."; g_rng.s = 31;
    auto F = [](int n, bool d = true) { for (int i = 0; i < n; i++) { frameStep(d); plat_end_frame(); } };
    auto SH = [&](const std::string &nm) { F(2); g_hostRaster = true; frameStep(true); plat_end_frame(); g_hostRaster = false; host_shot((dir + "/" + nm + ".ppm").c_str()); printf("shot %s screen %s\n", nm.c_str(), screen.c_str()); };
    ::mode = "pro"; proNew(1, "ROAD TEST", 9, 1); CR->draftDone = true; while (offDay()) proSkipDay();
    for (int k = 0; k < 30 && !proAway(); k++) { proSimGames(1); while (offDay()) proSkipDay(); }
    printf("away %d vs %s\n", (int)proAway(), CR->L[CR->opp].ab.c_str());
    state = ST_MENU; screen = "main"; startGame(); F(30); SH("r0_preview");
    for (int i = 0; i < 3000 && SK && SK->phase != PH_FACEOFF; i++) { if (SK->phase == PH_PREVIEW) SK->tap = true; F(1); }
    for (int i = 0; i < 600 && SK && !(SK->phase == PH_FACEOFF && SK->fo.t > SK->fo.show + .35); i++) F(1); SH("r1_faceoff");
    g_camHigh = true; F(4); SH("r2_high"); g_camHigh = false;
    printf("homeTi %d T0 %s away %d T1 %s away %d\n", SK->homeTi, SK->T[0].ab.c_str(), (int)SK->T[0].awayKit, SK->T[1].ab.c_str(), (int)SK->T[1].awayKit);
    paused = true; pauseTab = 0; F(3); SH("r3_pause"); paused = false; skQuit(); state = ST_MENU; F(10);
    screen = "main"; uiTap("app:14"); F(5); CR->money = 5000; uiTap("cas:bet:2"); uiTap("cas:deal"); F(10); SH("c1_blackjack");
    for (int k = 0; k < 6 && BJS_active(); k++) uiTap("cas:hit"); if (BJS_active()) uiTap("cas:stand"); F(4); SH("c2_bj_done");
    uiTap("cas:tab:1"); uiTap("cas:spin"); F(8); SH("c3_spinning"); F(90); SH("c4_slots");
    { long tot = 0; int n = 20000; for (int k = 0; k < n; k++) { int r[3]; for (int i = 0; i < 3; i++) r[i] = slRollT(); tot += slPayT(r); } printf("slots RTP %.3f\n", tot / (double)n); }
    uiTap("app:0"); screen = "main"; F(5); ::mode = "pro";
    state = ST_MENU; ::mode = "quick"; screen = "settings"; F(5); SH("s1_settings");
    ::mode = "pro"; screen = "main"; proDelete(1); return 0; }
  if (mode == "emblems") {   // chl_host emblems DIR: every NHL emblem on a grid
    std::string dir = argc > 2 ? argv[2] : "."; state = ST_MENU; screen = "modes";
    for (int i = 0; i < 2; i++) { frameStep(true); plat_end_frame(); }
    g_hostRaster = true; plat_begin_frame(0xff3b291e); ctx.fill(hex("#1e293b")); ctx.fillRect(0, 0, W, H);
    for (int i = 0; i < NT; i++) { std::string row = TD[i]; std::vector<std::string> f; size_t p = 0; while (true) { size_t q = row.find('|', p); f.push_back(row.substr(p, q - p)); if (q == std::string::npos) break; p = q + 1; }
      double cx = 60 + (i % 8) * 115, cy = 70 + (i / 8) * 130; drawEmblem(f[0], cx, cy, 46, hex(f[4].c_str()), hex(f[5].c_str())); ctx.fill("#fff"); ctx.font(14); ctx.textMid(); ctx.fillText(f[0], cx, cy + 60); }
    ctx.flush(); plat_end_frame(); g_hostRaster = false; host_shot((dir + "/emblems.ppm").c_str()); return 0; }
  if (mode == "hair") {   // chl_host hair DIR: every hair style, front and side, on the creator's bust
    std::string dir = argc > 2 ? argv[2] : "."; ::mode = "pro"; state = ST_MENU; extern double g_creatorYaw;
    pname = "Hair Test"; nameFor = "pro"; screen = "pronew";
    auto shot = [&](const std::string &nm) { for (int i = 0; i < 3; i++) { frameStep(true); plat_end_frame(); } { frameStep(false); plat_end_frame(); } g_hostRaster = true; { frameStep(true); plat_end_frame(); } g_hostRaster = false; host_shot((dir + "/" + nm + ".ppm").c_str()); };
    for (int k = 0; k < 4; k++) uiTap("look:skin:1");
    for (int st = 0; st < NHAIR; st++) { for (int y = 0; y < 3; y++) { g_creatorYaw = y == 0 ? .35 : y == 1 ? 1.6 : 2.9; shot("h" + istr(st) + "_" + istr(y)); } uiTap("look:hair:1"); }
    return 0; }
  if (mode == "v07") {   // chl_host v07 DIR: the creator, team goals, messages, the back button
    std::string dir = argc > 2 ? argv[2] : "."; g_rng.s = 777; ::mode = "pro"; state = ST_MENU;
    uint32_t prs = 0; Pad pd; pd.btn = 0; pd.lx = pd.ly = pd.rx = pd.ry = 128; g_hostInput = [&](Pad &p, Touch &t) { p = pd; p.btn = prs; prs = 0; t.n = 0; };
    auto press = [&](uint32_t b) { prs = b; for (int i = 0; i < 2; i++) { frameStep(true); plat_end_frame(); } };
    auto shot = [&](const std::string &scr, const std::string &nm) { if (!scr.empty()) screen = scr; for (int i = 0; i < 16; i++) { frameStep(true); plat_end_frame(); } { frameStep(false); plat_end_frame(); } g_hostRaster = true; { frameStep(true); plat_end_frame(); } g_hostRaster = false; host_shot((dir + "/" + nm + ".ppm").c_str()); printf("shot %s (%s)\n", nm.c_str(), screen.c_str()); };
    pname = "Alex Ryan"; nameFor = "pro"; shot("pronew", "c00_new");
    uiTap("look:skin:1"); uiTap("look:skin:1"); uiTap("look:skin:1"); uiTap("look:skin:1"); uiTap("look:hair:1"); uiTap("look:hair:1"); uiTap("look:hair:1"); uiTap("look:hair:1"); shot("pronew", "c01_dark_curly");
    uiTap("look:face:1"); uiTap("look:face:1"); uiTap("look:face:1"); uiTap("look:hair:-1"); uiTap("look:skin:-1"); uiTap("look:skin:-1"); uiTap("look:skin:-1"); uiTap("look:skin:-1"); uiTap("look:hairc:1"); uiTap("look:hairc:1"); uiTap("look:hairc:1"); shot("pronew", "c02_beard_flow");
    uiTap("look:face:-1"); uiTap("look:hair:1"); uiTap("look:hair:1"); uiTap("look:hairc:1"); uiTap("look:hairc:1"); shot("pronew", "c03_long_red");
    uiTap("look:hair:-1"); uiTap("look:hair:-1"); uiTap("look:hair:-1"); shot("pronew", "c04_bald");
    uiTap("pgo"); printf("career look: skin %d face %d hair %d hc %d  lookOf %d\n", CR->look.skin, CR->look.face, CR->look.hair, CR->look.hairC, lookOf(CR->nm).hair);
    { Look n = lookOf("Darnell Nurse"), m = lookOf("Connor McDavid"); printf("Nurse skin %d hair %d | McDavid skin %d hair %d face %d\n", n.skin, n.hair, m.skin, m.hair, m.face);
      int cnt[NSKIN] = {}, hc[NHAIR] = {}; for (int i = 0; i < 2000; i++) { Look q = lookOf(genName()); cnt[q.skin]++; hc[q.hair]++; } printf("skin spread:"); for (int k : cnt) printf(" %d", k); printf("  hair:"); for (int k : hc) printf(" %d", k); printf("\n"); }
    CR->draftDone = true; screen = "main"; proSimGames(3);
    // a challenge text, taken on, then played out over sims
    for (int k = 0; k < 40 && CR->tgoals.size() < 2; k++) { proSimGames(1); for (int i = (int)CR->texts.size() - 1; i >= 0; i--) if (CR->texts[(size_t)i].gk >= 0 && CR->texts[(size_t)i].ans == -1) { proAnswerText(i, k % 2 ? 2 : 0); break; } }
    printf("team goals: %d (on %d)  texts %d unread %d\n", (int)CR->tgoals.size(), proTeamGoalsOn(), (int)CR->texts.size(), proUnreadTexts());
    for (auto &g : CR->tgoals) printf("  %s: %s  pr %d/%d left %d st %d xp %d $%d\n", g.from.c_str(), tgoalText(g).c_str(), g.pr, g.tg, g.left, g.st, g.xp, g.cash);
    { PText t; t.from = CR->tgoals.empty() ? "Mathieu Joseph" : CR->tgoals[0].from; t.kind = 3; t.day = CR->day; t.season = CR->season; t.gk = 2; t.gt = 9; t.gn = 3; t.body = "The goalie coach says you never shoot. Prove him wrong: 9 shots on goal in 3 games.";
      t.opt[0] = "You're on."; t.opt[1] = "Not this time."; t.opt[2] = "Easy. Make it worth my while."; CR->texts.push_back(t); }
    { TGoal g; g.from = "Leon Draisaitl"; g.k = 0; g.tg = 2; g.pr = 1; g.games = 3; g.left = 2; CR->tgoals.push_back(g); TGoal d = g; d.from = "Zach Hyman"; d.k = 3; d.tg = 6; d.pr = 7; d.st = 1; CR->tgoals.push_back(d); TGoal f = g; f.from = "Evan Bouchard"; f.k = 6; f.tg = 3; f.pr = 1; f.st = 2; CR->tgoals.push_back(f); }
    screen = "main"; uiTap("app:10"); shot("", "c05_msgs");
    press(B_CIRCLE); for (int i = 0; i < 4; i++) { frameStep(true); plat_end_frame(); } printf("after O in Messages: screen %s inPhoneApp %d\n", screen.c_str(), (int)proInPhone());
    uiTap("app:12"); for (int i = 0; i < 4; i++) { frameStep(true); plat_end_frame(); } printf("My Team: screen %s\n", screen.c_str());
    press(B_CIRCLE); for (int i = 0; i < 4; i++) { frameStep(true); plat_end_frame(); } printf("after O in My Team: screen %s inPhoneApp %d\n", screen.c_str(), (int)proInPhone());
    uiTap("app:9"); shot("", "c06_goals");
    proSave(); proDelete(0); return 0; }
  if (mode == "proshots") {   // chl_host proshots DIR: render every Be a Pro / practice screen to DIR/*.ppm
    std::string dir = argc > 2 ? argv[2] : "."; g_rng.s = 4242; ::mode = "pro"; state = ST_MENU;
    auto shot = [&](const std::string &scr, const std::string &nm) { screen = scr; for (int i = 0; i < 16; i++) { frameStep(true); plat_end_frame(); } { frameStep(false); plat_end_frame(); } g_hostRaster = true; { frameStep(true); plat_end_frame(); } g_hostRaster = false; host_shot((dir + "/" + nm + ".ppm").c_str()); printf("shot %s (%s)\n", nm.c_str(), screen.c_str()); };
    screen = "proslots"; shot("proslots", "p00_slots_empty");
    { extern std::string pFirst, pLast; extern int pField; pFirst = "Alex"; pLast = "Ry"; pField = 1; nameFor = "pro"; shot("name", "p00b_name"); }
    pname = "Alex Ryan"; nameFor = "pro"; shot("pronew", "p01_new");
    proNew(0, "ALEX RYAN", 19, 1); setLast("pro", 0); { extern double proBusyT; (void)proBusyT; }
    for (int i = 0; i < 3; i++) { frameStep(false); plat_end_frame(); }
    uiTap("pslot:0"); for (int i = 0; i < 30; i++) { { frameStep(false); plat_end_frame(); } } shot("draft", "p02_draft");
    CR->draftDone = true; proSimGames(10); for (int i = 0; i < 30 && !offDay(); i++) proSimGames(1);
    shot("main", "p03_hub"); CR->xp = 5000; CR->money = 3000; shot("upg", "p04_upgrades"); uiTap("utab:1"); shot("upg", "p05_perks"); uiTap("utab:0");
    shot("train", "p06_train"); shot("shop", "p07_shop"); uiTap("gcat:3"); shot("shop", "p07b_shop_helm"); uiTap("gcat:5"); shot("shop", "p07c_shop_chest"); uiTap("gcat:0"); shot("office", "p08_office"); uiTap("off:neg"); shot("neg", "p09_neg"); shot("ntc", "p10_ntc"); uiTap("nav:treq"); uiTap("tq:3"); uiTap("tq:7"); shot("treq", "p11_treq");
    shot("toff", "p12_offers"); uiTap("nav:sched"); shot("sched", "p13_sched");
    for (int t = 0; t < 9; t++) { uiTap("stab:" + istr(t)); shot("stand", "p14_stand" + istr(t)); }
    uiTap("slg:1"); for (int t : {3, 4, 7}) { uiTap("stab:" + istr(t)); shot("stand", "p14_ahl" + istr(t)); } uiTap("slg:0");
    CR->hasTrade = true; CR->trade.from = CR->me; CR->trade.to = orgOf(CR->me); CR->trade.title = "CALLED UP"; CR->trade.why = "12 points in 20 games forced the " + CR->L[orgOf(CR->me)].n + "' hand. Welcome to the NHL!"; CR->trade.ret.clear(); shot("trade", "p15_callup"); CR->hasTrade = false;
    CR->hasTrade = true; CR->trade.from = CR->me; CR->trade.to = (CR->me + 5) % 32; CR->trade.why = "The team made an offer your club could not refuse."; CR->trade.ret = {"Some Guy", "Other Guy"}; CR->trade.title = "TRADE ALERT"; shot("trade", "p15_trade"); CR->hasTrade = false;
    ::mode = "pro"; while (offDay()) proSkipDay(); startGame(); printf("game started %d\n", SK != nullptr); for (int i = 0; i < 400; i++) { frameStep(false); plat_end_frame(); } g_autoplay = true; for (int i = 0; i < 1500; i++) { frameStep(false); plat_end_frame(); } g_hostRaster = true; { frameStep(true); plat_end_frame(); } g_hostRaster = false; host_shot((dir + "/p20_game.ppm").c_str());
    skQuit(); for (int i = 0; i < 5; i++) { frameStep(false); plat_end_frame(); } g_hostRaster = true; { frameStep(true); plat_end_frame(); } g_hostRaster = false; host_shot((dir + "/p21_result.ppm").c_str()); printf("result %s\n", screen.c_str());
    proSimGames(80); proSimGames(10); proSimGames(10); proSimGames(10); proSimGames(10); shot("main", "p16_hub_po"); uiTap("nav:stand"); shot("stand", "p17_bracket"); uiTap("slg:0"); shot("stand", "p17_bracket_nhl"); uiTap("slg:1");
    for (int i = 0; i < 20 && CR->phase == "po"; i++) proSimGames(5); shot("main", "p18_hub_over");
    ::mode = "quick"; shot("modes", "p19_mainmenu");
    CR->phase = "retired"; CR->retWhy = "age"; shot("retired", "p22_retired");
    ::mode = "practice"; g_autoplay = false; shot("main", "q00_practice");
    for (int k = 0; k < 3; k++) { pracKind = k; startGame(); g_autoplay = true; for (int i = 0; i < 260; i++) { frameStep(false); plat_end_frame(); } g_hostRaster = true; { frameStep(true); plat_end_frame(); } g_hostRaster = false; host_shot((dir + "/q0" + istr(k + 1) + "_drill.ppm").c_str()); skQuit(); state = ST_MENU; }
    return 0;
  }
  if (mode == "script") {   // chl_host script DIR "tokens": wN wait, X O SQ TR U D L R LB RB ST press, tX,Y tap, hX,Y,N hold, sNAME shot, auto, menu (wait for the menus), focus
    std::string dir = argc > 2 ? argv[2] : "."; std::string sc = argc > 3 ? argv[3] : ""; g_rng.s = 99;
    std::vector<std::string> tk; { std::string cur; for (char ch : sc) { if (ch == ' ') { if (!cur.empty()) tk.push_back(cur); cur.clear(); } else cur += ch; } if (!cur.empty()) tk.push_back(cur); }
    uint32_t hold = 0; int stickX = 128, stickY = 128, rX = 128, rY = 128; float tx_ = -1, ty_ = -1; int tn = 0; g_hostRaster = false;
    g_hostInput = [&](Pad &p, Touch &t) { p.btn = hold; p.lx = stickX; p.ly = stickY; p.rx = rX; p.ry = rY; if (tn > 0) { t.n = 1; t.p[0] = {7, tx_, ty_}; tn--; } };
    auto step = [&](int n) { for (int i = 0; i < n; i++) frameStep(true); };
    std::map<std::string, uint32_t> B = {{"X", B_CROSS}, {"O", B_CIRCLE}, {"SQ", B_SQUARE}, {"TR", B_TRIANGLE}, {"U", B_UP}, {"D", B_DOWN}, {"L", B_LEFT}, {"R", B_RIGHT}, {"LB", B_L}, {"RB", B_R}, {"ST", B_START}};
    step(5);
    for (auto &s : tk) {
      if (s[0] == 'w' && isdigit(s[1])) step(atoi(s.c_str() + 1));
      else if (B.count(s)) { hold = B[s]; step(1); hold = 0; step(2); }
      else if (s[0] == 't' && isdigit(s[1])) { tx_ = atof(s.c_str() + 1); ty_ = atof(strchr(s.c_str(), ',') + 1); tn = 2; step(3); }
      else if (s[0] == 'h' && isdigit(s[1])) { const char *c1 = strchr(s.c_str(), ','); tx_ = atof(s.c_str() + 1); ty_ = atof(c1 + 1); tn = atoi(strchr(c1 + 1, ',') + 1); step(tn + 2); }
      else if (s == "qsprint") printf("sprint %d puck %d\n", SK && SK->user ? (int)SK->user->sprint : -1, SK && SK->user ? (int)(SK->puck.owner == SK->user) : -1);
      else if (s[0] == 's') { g_hostRaster = true; step(1); g_hostRaster = false; std::string p = dir + "/" + s.substr(1) + ".ppm"; host_shot(p.c_str()); printf("shot %s  state %d mode %s screen %s focus %s coins %.0f\n", s.c_str() + 1, (int)state, ::mode.c_str(), screen.c_str(), mFocus.c_str(), UT ? UT->coins : -1.0); }
      else if (s.rfind("rs", 0) == 0 && s.size() > 2 && isdigit(s[2])) { rX = atoi(s.c_str() + 2); rY = atoi(strchr(s.c_str(), ',') + 1); step(1); }   // rsX,Y: hold the right stick there
      else if (s.rfind("ls", 0) == 0 && s.size() > 2 && isdigit(s[2])) { stickX = atoi(s.c_str() + 2); stickY = atoi(strchr(s.c_str(), ',') + 1); step(1); }
      else if (s == "auto") g_autoplay = true;
      else if (s == "noauto") g_autoplay = false;
      else if (s == "Lon") hold |= B_L; else if (s == "Loff") hold &= ~B_L;
      else if (s == "Ron") hold |= B_R; else if (s == "Roff") hold &= ~B_R;
      else if (s == "Xon") hold |= B_CROSS; else if (s == "Xoff") hold &= ~B_CROSS;
      else if (s == "waitgtop") { long n = 0; g_autoplay = true;   // until the away goalie is out at the top of his crease, set, with the puck coming at him
        while (SK && n++ < 60000) { const Goalie &q = SK->T[1].g; double d = std::fabs(q.x - SK->puck.x); if (SK->phase == PH_PLAY && std::fabs(q.x - (RK.L - RK.gl)) > RK.crD - .9 && d > 28 && d < 50 && std::fabs(q.mv) < 1 && !q.hasAn && !q.hasRq && SK->puck.owner && SK->puck.owner->team == 0) break; step(1); }
        printf("goalie top after %ld frames depth %.1f\n", n, SK ? std::fabs(SK->T[1].g.x - (RK.L - RK.gl)) : 0); }
      else if (s == "gdbg") { extern void skGoalieDbg(Goalie &, char *, int); char b[300]; if (SK) { skGoalieDbg(SK->T[1].g, b, sizeof b); printf("%s\n", b); } }
      else if (s.rfind("waitdist", 0) == 0) { double lim = atof(s.c_str() + 8); long n = 0; g_autoplay = true;   // until the puck is carried in on the away net, closer than N ft
        while (SK && n++ < 60000) { double gx = RK.L - RK.gl, dd = hyp(SK->puck.x - gx, SK->puck.y - RK.cy); if (SK->phase == PH_PLAY && SK->puck.owner && SK->puck.owner->team == 0 && SK->puck.x < gx && dd < lim) break; step(1); }
        printf("dist<%g after %ld frames, goalie %.1f ft out\n", lim, n, SK ? (RK.L - RK.gl) - SK->T[1].g.x : 0); }
      else if (s.rfind("waitside", 0) == 0) { int sg = s[8] == 'L' ? 1 : -1; long n = 0; g_autoplay = true;   // until the puck is carried on one side of the away net, 20-40 ft out
        while (SK && n++ < 80000) { double gx = RK.L - RK.gl, ex = gx - SK->puck.x, ey = (SK->puck.y - RK.cy) * sg, dd = hyp(ex, ey); const Goalie &q = SK->T[1].g;
          if (SK->phase == PH_PLAY && SK->puck.owner && SK->puck.owner->team == 0 && ex > 6 && ey > 12 && dd < 40 && dd > 18 && !q.hasAn && !q.hasRq && std::fabs(q.mv) < 1.5) break; step(1); }
        if (SK) printf("side %c after %ld frames: goalie y %+.1f face %.0f deg\n", s[8], n, SK->T[1].g.y - RK.cy, SK->T[1].g.face * 57.3); }
      else if (s == "waitgoal") { long n = 0; g_autoplay = true; while (SK && n++ < 60000 && SK->phase != PH_GOAL) step(1); printf("goal after %ld frames\n", n); }
      else if (s == "waitpuck") { long n = 0; g_autoplay = true; while (SK && n++ < 20000 && !(SK->phase == PH_PLAY && SK->puck.owner == SK->user && skInZone(SK->user))) step(1); g_autoplay = false; printf("puck after %ld frames\n", n); }
      else if (s.rfind("press", 0) == 0) { uint32_t keep = hold; hold |= B[s.substr(5)]; step(1); hold = keep; step(1); }
      else if (s == "rot") { for (int i = 0; i <= 12; i++) { double a = i / 12.0 * 2 * PI; stickX = 128 + (int)(120 * std::cos(a)); stickY = 128 + (int)(120 * std::sin(a)); step(1); } stickX = stickY = 128; step(1); }
      else if (s == "who") { if (SK) printf("  puck owner %s  spin %.2f  feed:", SK->puck.owner ? SK->puck.owner->nm.c_str() : "-", SK->user ? SK->user->spin : -1); for (auto &f : feed) printf(" [%s]", f.txt.c_str()); printf("\n"); }
      else if (s.rfind("cstat", 0) == 0) { int N = atoi(s.c_str() + 5), own = 0, call = 0; bool shot = false; g_autoplay = true;
        for (int i = 0; i < N && SK; i++) { frameStep(i % 50 == 0 && !shot); plat_end_frame(); if (SK && SK->puck.owner == SK->user) { own++; bool any = false; for (Skater *q : SK->T[0].on) if (q->call > 0) any = true; if (any) { call++; if (!shot && call == 30) { shot = true; g_hostRaster = true; frameStep(true); g_hostRaster = false; host_shot((dir + "/call.ppm").c_str()); } } } }
        printf("owned %d frames, a teammate calling in %d\n", own, call); }
      else if (s == "calls") { if (SK) for (Skater *q : SK->T[0].on) printf("  %s role %d call %.2f mate0 %d\n", q->nm.c_str(), (int)q->role, q->call, skMateFor(0) == q); }
      else if (s == "menu") { long n = 0; while (state == ST_PLAY && n++ < 200000) { frameStep(false); plat_end_frame(); } step(30); printf("game over after %ld frames: screen %s  rs %d-%d cash %d\n", n, screen.c_str(), rs.hs, rs.as, rs.cash); }
      else if (s == "focus") { printf("focus %s  btns", mFocus.c_str()); for (auto &b : btns) printf(" %s", b.id.c_str()); printf("\n"); }
    }
    return 0;
  }
  if (mode == "utview") {   // chl_host utview DIR: the 3D card viewer at several tilts, rarities and both sides
    std::string dir = argc > 2 ? argv[2] : "."; utNew(2, "TEST CLUB"); UTX &X = *UT; state = ST_MENU; ::mode = "ut"; screen = "utroster";
    const UTPDef *star = nullptr; for (auto *P : UT_CUR) if (P->pos == 'F' && (!star || P->ov > star->ov)) star = P;
    auto shot = [&](int r, int rx, int ry, double base, const std::string &nm) {
      X.cards.push_back({X.n++, star->k, r}); utExOpen(X.cards.back().u, 40, 60, 80); utEx.t0 = now() - 2000;
      g_pad.rx = rx; g_pad.ry = ry; double a = (rx - 128) / 127.0, b = (ry - 128) / 127.0; auto dz = [](double v) { return std::fabs(v) < .16 ? 0.0 : (v - (v > 0 ? .16 : -.16)) / .84; };
      utEx.yaw = -dz(a) * .6; utEx.pitch = dz(b) * .42; utEx.base = utEx.baseT = base; utEx.latch = true;
      for (int i = 0; i < 3; i++) { utEx.lt = now(); frameStep(true); plat_end_frame(); }
      utEx.lt = now(); g_hostRaster = true; frameStep(true); plat_end_frame(); g_hostRaster = false; host_shot((dir + "/" + nm + ".ppm").c_str()); printf("shot %s\n", nm.c_str()); utExOnF = false; };
    { extern void utTestSheet(const std::string &k, int r0, int r1); for (int pass = 0; pass < 2; pass++) { g_hostRaster = true; plat_begin_frame(0); utTestSheet(star->k, pass ? 3 : 0, pass ? 4 : 2); ctx.frame(); plat_end_frame(); g_hostRaster = false; host_shot((dir + "/sheet" + istr(pass) + ".ppm").c_str()); } }
    shot(0, 128, 128, 0, "v0_worn_flat"); shot(3, 40, 90, 0, "v1_rare_tilt"); shot(4, 220, 160, 0, "v2_epic_tilt"); shot(5, 60, 200, 0, "v3_leg_tilt");
    shot(6, 30, 60, 0, "v4_secret_tilt"); shot(6, 200, 128, 0, "v5_secret_tilt2"); shot(5, 128, 128, 1.3, "v6_flipping"); shot(5, 90, 150, PI, "v7_back");
    return 0; }
  if (mode == "utopen") {   // chl_host utopen DIR: frames of the pack opening (by pack and best rarity) and the foil shop
    std::string dir = argc > 2 ? argv[2] : "."; utNew(2, "TEST CLUB"); UTX &X = *UT; X.coins = 99999; state = ST_MENU; ::mode = "ut";
    auto shotAt = [&](double tt, const std::string &nm) { screen = "utopen"; utOpenOn = true; for (int i = 0; i < 3; i++) { utOpen.t0 = now() - tt * 1000; frameStep(true); plat_end_frame(); }
      utOpen.t0 = now() - tt * 1000; g_hostRaster = true; frameStep(true); plat_end_frame(); g_hostRaster = false; host_shot((dir + "/" + nm + ".ppm").c_str()); printf("shot %s\n", nm.c_str()); };
    for (int t : {1, 3, 4}) { X.inv.push_back(t); utInvOpen(t); utOpen.all = false; utOpen.done = false;
      if (t == 3) for (auto &o : utOpen.cards) o.c.r = std::min(o.c.r, 3);   // a modest Elite pack
      for (double tt : {.5, 1.0, 1.25, 1.55, 1.8, 1.95, 2.15, 4.0}) shotAt(tt, "o" + istr(t) + "_" + istr((int)(tt * 100))); }
    X.inv.push_back(1); utInvOpen(1); for (auto &o : utOpen.cards) o.c.r = 6; for (double tt : {1.3, 1.6}) shotAt(tt, "osecret_" + istr((int)(tt * 100)));
    utOpenOn = false; screen = "utpacks"; for (int i = 0; i < 17; i++) { frameStep(true); plat_end_frame(); } g_hostRaster = true; frameStep(true); plat_end_frame(); g_hostRaster = false; host_shot((dir + "/shop.ppm").c_str());
    X.inv = {0, 1, 2, 3, 4, 5}; screen = "utinv"; for (int i = 0; i < 17; i++) { frameStep(true); plat_end_frame(); } g_hostRaster = true; frameStep(true); plat_end_frame(); g_hostRaster = false; host_shot((dir + "/inv.ppm").c_str());
    return 0; }
  if (mode == "utsim") {   // chl_host utsim: a new file's OVR, pack odds (AHL / NHL / NHL stars) and a training camp run
    utNew(2, "TEST CLUB"); UTX &X = *UT; printf("new file: team OVR %d, cards:", utTeamOv(X)); for (auto &c : X.cards) printf(" %s(%d)", c.p.c_str(), utOv(c)); printf("\n");
    for (int t = 0; t < 6; t++) { int n = 0, nhl = 0, star = 0, ahl = 0, leg = 0, maxSt = 0, ahlTop = 0; double ov = 0;
      for (int k = 0; k < 6000; k++) { size_t c0 = X.cards.size(); X.inv.push_back(t); utInvOpen(t); utOpenOn = false; int st = 0;
        for (size_t i = c0; i < X.cards.size(); i++) { const UTPDef *P = UTM(X.cards[i].p); n++; ov += utOv(X.cards[i]); if (P->leg) leg++; else if (P->ahl) { ahl++; if (P->ov >= 67) ahlTop++; } else { nhl++; if (P->ov >= 85) { star++; st++; } } }
        maxSt = std::max(maxSt, st); X.cards.resize(c0); }
      printf("%-9s cards %5d  AHL %5.1f%% (AHL stars 67+ %4.1f%%)  NHL %5.1f%%  NHL stars %5.2f%% (max %d/pack)  legends %4.1f%%  avg card OVR %.1f\n", UT_PACKS[t].n, n, 100.0 * ahl / n, 100.0 * ahlTop / n, 100.0 * nhl / n, 100.0 * star / n, maxSt, 100.0 * leg / n, ov / n); }
    // camp: send the 2nd-best forward, play 3 games
    for (auto *P : UT_AHL) if (P->pos == 'F' && P->ov == 64) { X.cards.push_back({X.n++, P->k, 0}); break; }   // a spare forward
    UCard c0 = X.cards[0]; int before = utOv(c0); std::string why; printf("camp ok: %d %s\n", utCampOk(c0, &why), why.c_str());
    utCampStart(c0.u, 1); printf("camp started: left %d, in lineup %d, full %d\n", X.campLeft, (int)(std::find(X.ro.begin(), X.ro.end(), c0.u) != X.ro.end()), utFull(X));
    for (int g = 0; g < 3; g++) { utPickSet(X.opp[1]); utAfter(true, false); }
    printf("after 3 games: left %d, OVR %d -> %d, trained bits %d, again ok %d (%s)\n", X.campLeft, before, utOv(c0), X.tm[c0.p], utCampOk(c0, &why), why.c_str());
    if (argc > 2) { std::string dir = argv[2]; state = ST_MENU; ::mode = "ut";
      auto shot = [&](const std::string &scr, const std::string &nm) { screen = scr; for (int i = 0; i < 16; i++) { frameStep(true); plat_end_frame(); } { frameStep(false); plat_end_frame(); } g_hostRaster = true; { frameStep(true); plat_end_frame(); } g_hostRaster = false; host_shot((dir + "/" + nm + ".ppm").c_str()); printf("shot %s (%s)\n", nm.c_str(), screen.c_str()); };
      shot("main", "u00_hub"); shot("utpacks", "u01_shop"); utCampSel = X.cards[1].u; shot("utcamp", "u02_camp_pick"); utCampStart(X.cards[1].u, 0); shot("utcamp", "u03_camp_on");
      utMenuOnF = true; utMenu = UMenu(); utMenu.u = X.cards[2].u; utMenu.x = W * .1; utMenu.y = H * .2; utMenu.w = .3 * U; shot("utroster", "u04_menu"); utMenuOnF = false;
      X.inv.push_back(5); X.inv.push_back(1); shot("utinv", "u05_inv"); utInvOpen(5); utOpen.all = true; utOpen.t0 = 0; shot("utopen", "u06_cup_pack"); }
    utSave(); return 0; }
  if (mode == "utcheck") {   // card ratings, salaries, perks and CPU team OVRs, to compare with the legacy build
    std::vector<std::string> keys; for (size_t i = 0; i < UTP.size(); i += 7) keys.push_back(UTP[i].k);
    for (auto &k : keys) for (int r : {0, 3, 6}) { UCard c{1, k, r}; const URat &R = utRat(c); std::string s = k + " r" + istr(r) + " ovr " + istr(R.ovr) + " ar " + R.ar + " sal " + fixed(utSal(c), 1) + " |";
      if (R.goalie) for (auto q : UT_GK) s += " " + istr(R.get(q)); else { for (auto q : UT_SK) s += " " + istr(R.get(q)); s += " " + istr(R.rt.bhp) + " " + istr(R.rt.bha); }
      s += " pk"; for (auto &e : pkCard(c)) s += std::string(" ") + PERKS[e.id].id + istr(e.t); printf("%s\n", s.c_str()); }
    for (int cap : {24, 40, 1000}) { UTX X; X.hasCap = true; X.cap = cap; for (size_t i = 0, u = 1; i < UTP.size(); i += 11, u++) if (!UTP[i].dr) X.cards.push_back({(int)u, UTP[i].k, (int)(i % 7)});
      utAuto(X); std::string s = "auto " + istr(cap) + ":"; for (int u : X.ro) s += " " + istr(u); printf("%s  team %d pay %.1f\n", s.c_str(), utTeamOv(X), utPay(X)); }
    for (int i = 0; i < 40; i++) { UOpp o; o.ov = 50 + i; o.seed = 1000003.0 * i + 17; printf("opp %d %.0f %d\n", o.ov, o.seed, utOppOv(o)); }
    return 0;
  }
  if (mode == "shots") {
    std::string dir = argc > 2 ? argv[2] : "."; std::vector<int> want; for (int i = 3; i < argc; i++) want.push_back(atoi(argv[i]));
    g_rng.s = 777; long fr = 0;
    // menu: wait, then X to start; then the CPU plays your skater (the screens are what you'd see)
    g_hostInput = [&](Pad &p, Touch &) { if (fr == 20 || fr == 21) p.btn = 0; if (fr == 22) p.btn = B_CROSS; if (fr > (getenv("CHL_LATE") ? 140 : 60)) g_autoplay = true; };
    int maxf = want.empty() ? 0 : *std::max_element(want.begin(), want.end());
    for (fr = 0; fr <= maxf; fr++) {
      g_hostRaster = std::find(want.begin(), want.end(), (int)fr) != want.end();
      frameStep(true);
      for (int w : want) if (w == fr) { std::string p = dir + "/f" + istr(fr) + ".ppm"; host_shot(p.c_str());
        printf("frame %ld: state %d phase %d  tris %ld glyphs %ld calls %ld  cache %zu (%.1f MB)\n", fr, (int)state, SK ? (int)SK->phase : -1, g_hostTris, g_hostGlyphs, g_hostCalls, ctx.cacheSize(), ctx.cacheBytes() / 1048576.0); }
      g_hostTris = g_hostGlyphs = g_hostCalls = 0;
    }
    return 0;
  }
  if (mode == "human") {   // a scripted player on the pad: faceoffs on time, stick shots, slap shots, dekes, passes, checks
    int n = argc > 2 ? atoi(argv[2]) : 5; g_rng.s = 4242; long tot[6] = {0};
    int phase = 0; long fr = 0;
    g_hostInput = [&](Pad &p, Touch &) {
      if (!SK || state != ST_PLAY) return;
      Game &G = *SK; Skater *u = G.user; if (!u) return;
      auto stick = [&](double wx, double wy, int &sx, int &sy) { double m = hyp(wx, wy); if (m < 1e-6) { sx = sy = 128; return; } wx /= m; wy /= m; sx = 128 + (int)(wy * 127); sy = 128 - (int)(wx * 127); };   // world -> stick (screen up = +x)
      if (G.phase == PH_PREVIEW || G.phase == PH_INTRO) { if (fr % 20 == 0) p.btn = B_CROSS; return; }
      if (G.phase == PH_FACEOFF) { double drop = G.fo.show + G.fo.close; if (std::fabs(G.fo.t - drop) < .03) p.btn = B_CROSS; return; }
      Puck &P = G.puck; bool mine = P.owner == u;
      if (mine) {
        double ax = attackX(0), dn = hyp(ax - u->x, RK.cy - u->y);
        stick(ax - 12 - u->x, RK.cy - u->y, p.lx, p.ly);
        if (dn > 60) p.btn |= B_R;
        // shooting stick: push up (wrist) or pull back (slap), slide it sideways to aim, let go to shoot
        if (dn < 38) { phase++; int k = phase % 30; bool sl = (phase / 30) % 3 == 2; if (k >= 3 && k < (sl ? 20 : 10)) { p.ry = sl ? 230 : 25; p.rx = 128 + ((phase / 30) % 2 ? 80 : -80) * (k > 5); } }
        else phase = 0;
        if (fr % 97 == 0) p.btn |= B_SQUARE;
        if (fr % 151 == 0) p.btn |= B_TRIANGLE;
        if (fr % 173 == 0) p.btn |= B_CROSS;
      } else {
        stick(P.x - u->x, P.y - u->y, p.lx, p.ly);
        if (hyp(P.x - u->x, P.y - u->y) > 25) p.btn |= B_R;
        if (P.owner && P.owner->team == 1 && hyp(P.owner->x - u->x, P.owner->y - u->y) < 6) { if ((fr / 8) % 3 == 0) p.btn |= B_CIRCLE; if (fr % 11 == 0) p.btn |= B_CROSS; }
        if (fr % 301 == 0) p.btn |= B_L;
        if (G.hasBat && G.bat.user) p.lx = (fr / 3) % 2 ? 255 : 0;
      }
    };
    for (int gi = 0; gi < n; gi++) { skStart(); state = ST_PLAY; long f = 0;
      while (state == ST_PLAY && f < 200000) { if (SK) { tot[3] = SK->me.shots; } frameStep(false); plat_end_frame(); f++; fr++; }
      tot[0] += RS.f.g; tot[1] += RS.f.a; tot[2] += RS.f.sog; tot[4] += RS.f.hits; tot[5] += RS.f.fow; printf("game %d: %d-%d  you %dG %dA %d SOG %d hits  faceoffs %d/%d\n", gi, RS.hs, RS.as, RS.f.g, RS.f.a, RS.f.sog, RS.f.hits, RS.f.fow, RS.f.fot); }
    return 0;
  }
  if (mode == "pause") {   // a game, then START and the pause tabs
    std::string dir = argc > 2 ? argv[2] : "."; long fr = 0; g_rng.s = 99;
    g_hostInput = [&](Pad &p, Touch &) { if (fr == 22) p.btn = B_CROSS; if (fr > 60) g_autoplay = true; if (fr == 700) p.btn = B_START; if (fr == 720) p.btn = B_R; if (fr == 740) p.btn = B_R; };
    for (fr = 0; fr <= 760; fr++) { g_hostRaster = fr == 710 || fr == 730 || fr == 750; frameStep(true); if (fr == 710 || fr == 730 || fr == 750) { std::string p = dir + "/p" + istr(fr) + ".ppm"; host_shot(p.c_str()); } }
    return 0;
  }
  if (mode == "bench") {
    int n = argc > 2 ? atoi(argv[2]) : 600; g_rng.s = 5; g_autoplay = true; skStart(); state = ST_PLAY;
    for (int i = 0; i < 400; i++) { frameStep(false); plat_end_frame(); }   // past the preview and the intro into play
    auto t0 = std::chrono::steady_clock::now(); long tris = 0;
    g_hostRaster = getenv("CHL_RASTER") != nullptr;
    for (int i = 0; i < n && state == ST_PLAY; i++) { frameStep(true); tris += g_hostTris; g_hostTris = 0; }
    double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    extern long g_host3d; printf("%d frames, %.2f ms/frame on this PC (incl. the software rasterizer), %ld tris/frame (+%ld GPU 3D), cache %zu blocks %.1f MB\n", n, ms / n, tris / n, g_host3d / n, ctx.cacheSize(), ctx.cacheBytes() / 1048576.0);
    return 0;
  }
  return 0;
}

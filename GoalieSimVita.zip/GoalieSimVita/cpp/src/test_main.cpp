// CHL 2026 native - desktop test driver (HOST_BUILD only, never in the Vita build).
//   chl_host games N [ovr]       play N full games with the CPU driving your skater, print the averages
//   chl_host shots DIR f1 f2 ... start from the menu, play (CPU-driven), save frames f1, f2 ... as PPM
//   chl_host bench N             time the update + draw of N frames of play
#include "game.h"
#include "sk_int.h"
#include "menu.h"
#include "ut_int.h"
#include <chrono>
#include <cstring>
#include <map>
#include <cstdlib>
#include <functional>

void frameStep(bool draw);
void appInit();
void host_shot(const char *path);
extern std::function<void(Pad &, Touch &)> g_hostInput;
extern long g_hostTris, g_hostGlyphs, g_hostCalls;
extern int g_hostSnd[S_COUNT];
extern int g_pulls;
extern bool g_hostRaster;

int main(int argc, char **argv) {
  plat_init(); appInit();
  std::string mode = argc > 1 ? argv[1] : "games";
  if (mode == "games") {
    int n = argc > 2 ? atoi(argv[2]) : 10; int ovArg = argc > 3 ? atoi(argv[3]) : 50; for (auto k : FKEYS) g_stats[k] = ovArg; mode = "quick";
    g_rng.s = 12345;
    g_autoplay = true;
    long goals[2] = {0, 0}, sog[2] = {0, 0}, hits[2] = {0, 0}, pens = 0, fo = 0, frames = 0, ot = 0; int wins = 0, maxF = 0;
    for (int gi = 0; gi < n; gi++) {
      skStart(); state = ST_PLAY; long f = 0; if (getenv("CHL_PURE_AI")) SK->user->user = false;
      while (state == ST_PLAY && f < 200000) {
        Game *G = SK;
        // keep the last numbers before the game object goes away
        static int lg[2], ls[2], lh[2], lp, lf, lper;
        if (G) { for (int t = 0; t < 2; t++) { lg[t] = G->T[t].score; ls[t] = G->T[t].sog; lh[t] = G->T[t].hits; } lp = G->T[0].pen + G->T[1].pen; lf = G->T[0].fow + G->T[1].fow; lper = G->per; }
        frameStep(false); plat_end_frame(); f++;
        if (state != ST_PLAY) { for (int t = 0; t < 2; t++) { goals[t] += RS.valid ? (t ? RS.as : RS.hs) : lg[t]; sog[t] += ls[t]; hits[t] += lh[t]; } pens += lp; fo += lf; if (lper > 3) ot++; if (RS.hs > RS.as) wins++; }
      }
      frames += f; maxF = std::max(maxF, (int)f);
    }
    printf("games %d (you %d OVR): goals/game %.2f (home %.2f away %.2f)  sog %.1f / %.1f  hits %.1f / %.1f  penalties %.2f  faceoffs %.1f  OT %ld  home wins %d  frames/game %ld\n",
      n, ovArg, (goals[0] + goals[1]) / (double)n, goals[0] / (double)n, goals[1] / (double)n, sog[0] / (double)n, sog[1] / (double)n, hits[0] / (double)n, hits[1] / (double)n, pens / (double)n, fo / (double)n, ot, wins, frames / n);
    printf("goalie pulls %d\n", g_pulls); printf("sounds:"); for (int i = 0; i < S_COUNT; i++) printf(" %d", g_hostSnd[i]); printf("\n");
    return 0;
  }
  if (mode == "script") {   // chl_host script DIR "tokens": wN wait, X O SQ TR U D L R LB RB ST press, tX,Y tap, hX,Y,N hold, sNAME shot, auto, menu (wait for the menus), focus
    std::string dir = argc > 2 ? argv[2] : "."; std::string sc = argc > 3 ? argv[3] : ""; g_rng.s = 99;
    std::vector<std::string> tk; { std::string cur; for (char ch : sc) { if (ch == ' ') { if (!cur.empty()) tk.push_back(cur); cur.clear(); } else cur += ch; } if (!cur.empty()) tk.push_back(cur); }
    uint32_t hold = 0; int stickX = 128, stickY = 128; float tx_ = -1, ty_ = -1; int tn = 0; g_hostRaster = false;
    g_hostInput = [&](Pad &p, Touch &t) { p.btn = hold; p.lx = stickX; p.ly = stickY; if (tn > 0) { t.n = 1; t.p[0] = {7, tx_, ty_}; tn--; } };
    auto step = [&](int n) { for (int i = 0; i < n; i++) frameStep(true); };
    std::map<std::string, uint32_t> B = {{"X", B_CROSS}, {"O", B_CIRCLE}, {"SQ", B_SQUARE}, {"TR", B_TRIANGLE}, {"U", B_UP}, {"D", B_DOWN}, {"L", B_LEFT}, {"R", B_RIGHT}, {"LB", B_L}, {"RB", B_R}, {"ST", B_START}};
    step(5);
    for (auto &s : tk) {
      if (s[0] == 'w' && isdigit(s[1])) step(atoi(s.c_str() + 1));
      else if (B.count(s)) { hold = B[s]; step(1); hold = 0; step(2); }
      else if (s[0] == 't' && isdigit(s[1])) { tx_ = atof(s.c_str() + 1); ty_ = atof(strchr(s.c_str(), ',') + 1); tn = 2; step(3); }
      else if (s[0] == 'h' && isdigit(s[1])) { const char *c1 = strchr(s.c_str(), ','); tx_ = atof(s.c_str() + 1); ty_ = atof(c1 + 1); tn = atoi(strchr(c1 + 1, ',') + 1); step(tn + 2); }
      else if (s[0] == 's') { g_hostRaster = true; step(1); g_hostRaster = false; std::string p = dir + "/" + s.substr(1) + ".ppm"; host_shot(p.c_str()); printf("shot %s  state %d mode %s screen %s focus %s coins %.0f\n", s.c_str() + 1, (int)state, ::mode.c_str(), screen.c_str(), mFocus.c_str(), UT ? UT->coins : -1.0); }
      else if (s == "auto") g_autoplay = true;
      else if (s == "noauto") g_autoplay = false;
      else if (s == "Lon") hold |= B_L; else if (s == "Loff") hold &= ~B_L;
      else if (s == "waitpuck") { long n = 0; g_autoplay = true; while (SK && n++ < 20000 && !(SK->phase == PH_PLAY && SK->puck.owner == SK->user && skInZone(SK->user))) step(1); g_autoplay = false; printf("puck after %ld frames\n", n); }
      else if (s.rfind("press", 0) == 0) { uint32_t keep = hold; hold |= B[s.substr(5)]; step(1); hold = keep; step(1); }
      else if (s == "rot") { for (int i = 0; i <= 12; i++) { double a = i / 12.0 * 2 * PI; stickX = 128 + (int)(120 * std::cos(a)); stickY = 128 + (int)(120 * std::sin(a)); step(1); } stickX = stickY = 128; step(1); }
      else if (s == "who") { if (SK) printf("  puck owner %s  spin %.2f  feed:", SK->puck.owner ? SK->puck.owner->nm.c_str() : "-", SK->user ? SK->user->spin : -1); for (auto &f : feed) printf(" [%s]", f.txt.c_str()); printf("\n"); }
      else if (s.rfind("cstat", 0) == 0) { int N = atoi(s.c_str() + 5), own = 0, call = 0; bool shot = false; g_autoplay = true;
        for (int i = 0; i < N && SK; i++) { frameStep(i % 50 == 0 && !shot); plat_end_frame(); if (SK && SK->puck.owner == SK->user) { own++; bool any = false; for (Skater *q : SK->T[0].on) if (q->call > 0) any = true; if (any) { call++; if (!shot && call == 30) { shot = true; g_hostRaster = true; frameStep(true); g_hostRaster = false; host_shot((dir + "/call.ppm").c_str()); } } } }
        printf("owned %d frames, a teammate calling in %d\n", own, call); }
      else if (s == "calls") { if (SK) for (Skater *q : SK->T[0].on) printf("  %s role %d call %.2f mate0 %d\n", q->nm.c_str(), (int)q->role, q->call, skMateFor(0) == q); }
      else if (s == "menu") { long n = 0; while (state == ST_PLAY && n++ < 200000) { frameStep(false); plat_end_frame(); } step(30); printf("game over after %ld frames: screen %s  rs %d-%d cash %d\n", n, screen.c_str(), rs.hs, rs.as, rs.cash); }
      else if (s == "focus") { printf("focus %s  btns", mFocus.c_str()); for (auto &b : btns) printf(" %s", b.id.c_str()); printf("\n"); }
    }
    return 0;
  }
  if (mode == "utcheck") {   // card ratings, salaries, perks and CPU team OVRs, to compare with the legacy build
    std::vector<std::string> keys; for (size_t i = 0; i < UTP.size(); i += 7) keys.push_back(UTP[i].k);
    for (auto &k : keys) for (int r : {0, 3, 6}) { UCard c{1, k, r}; const URat &R = utRat(c); std::string s = k + " r" + istr(r) + " ovr " + istr(R.ovr) + " ar " + R.ar + " sal " + fixed(utSal(c), 1) + " |";
      if (R.goalie) for (auto q : UT_GK) s += " " + istr(R.get(q)); else { for (auto q : UT_SK) s += " " + istr(R.get(q)); s += " " + istr(R.rt.bhp) + " " + istr(R.rt.bha); }
      s += " pk"; for (auto &e : pkCard(c)) s += std::string(" ") + PERKS[e.id].id + istr(e.t); printf("%s\n", s.c_str()); }
    for (int cap : {24, 40, 1000}) { UTX X; X.hasCap = true; X.cap = cap; for (size_t i = 0, u = 1; i < UTP.size(); i += 11, u++) if (!UTP[i].dr) X.cards.push_back({(int)u, UTP[i].k, (int)(i % 7)});
      utAuto(X); std::string s = "auto " + istr(cap) + ":"; for (int u : X.ro) s += " " + istr(u); printf("%s  team %d pay %.1f\n", s.c_str(), utTeamOv(X), utPay(X)); }
    for (int i = 0; i < 40; i++) { UOpp o; o.ov = 50 + i; o.seed = 1000003.0 * i + 17; printf("opp %d %.0f %d\n", o.ov, o.seed, utOppOv(o)); }
    return 0;
  }
  if (mode == "shots") {
    std::string dir = argc > 2 ? argv[2] : "."; std::vector<int> want; for (int i = 3; i < argc; i++) want.push_back(atoi(argv[i]));
    g_rng.s = 777; long fr = 0;
    // menu: wait, then X to start; then the CPU plays your skater (the screens are what you'd see)
    g_hostInput = [&](Pad &p, Touch &) { if (fr == 20 || fr == 21) p.btn = 0; if (fr == 22) p.btn = B_CROSS; if (fr > (getenv("CHL_LATE") ? 140 : 60)) g_autoplay = true; };
    int maxf = want.empty() ? 0 : *std::max_element(want.begin(), want.end());
    for (fr = 0; fr <= maxf; fr++) {
      g_hostRaster = std::find(want.begin(), want.end(), (int)fr) != want.end();
      frameStep(true);
      for (int w : want) if (w == fr) { std::string p = dir + "/f" + istr(fr) + ".ppm"; host_shot(p.c_str());
        printf("frame %ld: state %d phase %d  tris %ld glyphs %ld calls %ld  cache %zu (%.1f MB)\n", fr, (int)state, SK ? (int)SK->phase : -1, g_hostTris, g_hostGlyphs, g_hostCalls, ctx.cacheSize(), ctx.cacheBytes() / 1048576.0); }
      g_hostTris = g_hostGlyphs = g_hostCalls = 0;
    }
    return 0;
  }
  if (mode == "human") {   // a scripted player on the pad: faceoffs on time, stick shots, slap shots, dekes, passes, checks
    int n = argc > 2 ? atoi(argv[2]) : 5; g_rng.s = 4242; long tot[6] = {0};
    int phase = 0; long fr = 0;
    g_hostInput = [&](Pad &p, Touch &) {
      if (!SK || state != ST_PLAY) return;
      Game &G = *SK; Skater *u = G.user; if (!u) return;
      auto stick = [&](double wx, double wy, int &sx, int &sy) { double m = hyp(wx, wy); if (m < 1e-6) { sx = sy = 128; return; } wx /= m; wy /= m; sx = 128 + (int)(wy * 127); sy = 128 - (int)(wx * 127); };   // world -> stick (screen up = +x)
      if (G.phase == PH_PREVIEW || G.phase == PH_INTRO) { if (fr % 20 == 0) p.btn = B_CROSS; return; }
      if (G.phase == PH_FACEOFF) { double drop = G.fo.show + G.fo.close; if (std::fabs(G.fo.t - drop) < .03) p.btn = B_CROSS; return; }
      Puck &P = G.puck; bool mine = P.owner == u;
      if (mine) {
        double ax = attackX(0), dn = hyp(ax - u->x, RK.cy - u->y);
        stick(ax - 12 - u->x, RK.cy - u->y, p.lx, p.ly);
        if (dn > 60) p.btn |= B_R;
        // shooting stick: rest, then flick up (wrist) - or pull down a while then push up (slap)
        if (dn < 38) { phase++; int k = phase % 30; if (k < 3) { } else if (k < 4) p.ry = 0; else if ((phase / 30) % 3 == 2) { if (k < 18) p.ry = 255; else p.ry = 0; } else p.ry = 0; }
        else phase = 0;
        if (fr % 97 == 0) p.btn |= B_SQUARE;
        if (fr % 151 == 0) p.btn |= B_TRIANGLE;
        if (fr % 173 == 0) p.btn |= B_CROSS;
      } else {
        stick(P.x - u->x, P.y - u->y, p.lx, p.ly);
        if (hyp(P.x - u->x, P.y - u->y) > 25) p.btn |= B_R;
        if (P.owner && P.owner->team == 1 && hyp(P.owner->x - u->x, P.owner->y - u->y) < 6) { if ((fr / 8) % 3 == 0) p.btn |= B_CIRCLE; if (fr % 11 == 0) p.btn |= B_CROSS; }
        if (fr % 301 == 0) p.btn |= B_L;
        if (G.hasBat && G.bat.user) p.lx = (fr / 3) % 2 ? 255 : 0;
      }
    };
    for (int gi = 0; gi < n; gi++) { skStart(); state = ST_PLAY; long f = 0;
      while (state == ST_PLAY && f < 200000) { if (SK) { tot[3] = SK->me.shots; } frameStep(false); plat_end_frame(); f++; fr++; }
      tot[0] += RS.f.g; tot[1] += RS.f.a; tot[2] += RS.f.sog; tot[4] += RS.f.hits; tot[5] += RS.f.fow; printf("game %d: %d-%d  you %dG %dA %d SOG %d hits  faceoffs %d/%d\n", gi, RS.hs, RS.as, RS.f.g, RS.f.a, RS.f.sog, RS.f.hits, RS.f.fow, RS.f.fot); }
    return 0;
  }
  if (mode == "pause") {   // a game, then START and the pause tabs
    std::string dir = argc > 2 ? argv[2] : "."; long fr = 0; g_rng.s = 99;
    g_hostInput = [&](Pad &p, Touch &) { if (fr == 22) p.btn = B_CROSS; if (fr > 60) g_autoplay = true; if (fr == 700) p.btn = B_START; if (fr == 720) p.btn = B_R; if (fr == 740) p.btn = B_R; };
    for (fr = 0; fr <= 760; fr++) { g_hostRaster = fr == 710 || fr == 730 || fr == 750; frameStep(true); if (fr == 710 || fr == 730 || fr == 750) { std::string p = dir + "/p" + istr(fr) + ".ppm"; host_shot(p.c_str()); } }
    return 0;
  }
  if (mode == "bench") {
    int n = argc > 2 ? atoi(argv[2]) : 600; g_rng.s = 5; g_autoplay = true; skStart(); state = ST_PLAY;
    for (int i = 0; i < 400; i++) { frameStep(false); plat_end_frame(); }   // past the preview and the intro into play
    auto t0 = std::chrono::steady_clock::now(); long tris = 0;
    g_hostRaster = getenv("CHL_RASTER") != nullptr;
    for (int i = 0; i < n && state == ST_PLAY; i++) { frameStep(true); tris += g_hostTris; g_hostTris = 0; }
    double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    printf("%d frames, %.2f ms/frame on this PC (incl. the software rasterizer), %ld tris/frame, cache %zu blocks %.1f MB\n", n, ms / n, tris / n, ctx.cacheSize(), ctx.cacheBytes() / 1048576.0);
    return 0;
  }
  return 0;
}

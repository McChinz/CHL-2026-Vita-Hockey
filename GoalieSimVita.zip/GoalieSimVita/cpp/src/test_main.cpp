// CHL 2026 native - desktop test driver (HOST_BUILD only, never in the Vita build).
//   chl_host games N [ovr]       play N full games with the CPU driving your skater, print the averages
//   chl_host shots DIR f1 f2 ... start from the menu, play (CPU-driven), save frames f1, f2 ... as PPM
//   chl_host bench N             time the update + draw of N frames of play
#include "game.h"
#include "sk_int.h"
#include "menu.h"
#include "ut_int.h"
#include "pro.h"
#include <chrono>
#include <unistd.h>
#include <cstring>
#include <map>
#include <cstdlib>
#include <functional>

void frameStep(bool draw);
void appInit();
void host_shot(const char *path);
extern std::function<void(Pad &, Touch &)> g_hostInput;
extern long g_hostTris, g_hostGlyphs, g_hostCalls;
extern int g_hostSnd[S_COUNT];
extern int g_pulls;
extern bool g_hostRaster;

int main(int argc, char **argv) { setvbuf(stdout, nullptr, _IOLBF, 0);
  plat_init(); appInit();
  std::string mode = argc > 1 ? argv[1] : "games";
  if (mode == "games") {
    int n = argc > 2 ? atoi(argv[2]) : 10; int ovArg = argc > 3 ? atoi(argv[3]) : 50; for (auto k : FKEYS) g_stats[k] = ovArg; mode = "quick";
    g_rng.s = 12345;
    g_autoplay = true;
    std::vector<int> perH, perA; long goals[2] = {0, 0}, sog[2] = {0, 0}, hits[2] = {0, 0}, pens = 0, fo = 0, frames = 0, ot = 0; int wins = 0, maxF = 0;
    for (int gi = 0; gi < n; gi++) {
      skStart(); state = ST_PLAY; long f = 0; if (getenv("CHL_PURE_AI")) SK->user->user = false;
      while (state == ST_PLAY && f < 200000) {
        Game *G = SK;
        // keep the last numbers before the game object goes away
        static int lg[2], ls[2], lh[2], lp, lf, lper;
        if (G) { for (int t = 0; t < 2; t++) { lg[t] = G->T[t].score; ls[t] = G->T[t].sog; lh[t] = G->T[t].hits; } lp = G->T[0].pen + G->T[1].pen; lf = G->T[0].fow + G->T[1].fow; lper = G->per; }
        frameStep(false); plat_end_frame(); f++;
        if (state != ST_PLAY) { for (int t = 0; t < 2; t++) { goals[t] += RS.valid ? (t ? RS.as : RS.hs) : lg[t]; sog[t] += ls[t]; hits[t] += lh[t]; } pens += lp; fo += lf; if (lper > 3) ot++; if (RS.hs > RS.as) wins++; perH.push_back(RS.valid ? RS.hs : lg[0]); perA.push_back(RS.valid ? RS.as : lg[1]); }
      }
      frames += f; maxF = std::max(maxF, (int)f);
    }
    printf("games %d (you %d OVR): goals/game %.2f (home %.2f away %.2f)  sog %.1f / %.1f  hits %.1f / %.1f  penalties %.2f  faceoffs %.1f  OT %ld  home wins %d  frames/game %ld\n",
      n, ovArg, (goals[0] + goals[1]) / (double)n, goals[0] / (double)n, goals[1] / (double)n, sog[0] / (double)n, sog[1] / (double)n, hits[0] / (double)n, hits[1] / (double)n, pens / (double)n, fo / (double)n, ot, wins, frames / n);
    { int h[12] = {0}, z = 0, six = 0, mn = 99, mx = 0; for (size_t i = 0; i < perH.size(); i++) { int t = perH[i] + perA[i]; h[std::min(11, t)]++; mn = std::min(mn, t); mx = std::max(mx, t);
        for (int v : {perH[i], perA[i]}) { if (v == 0) z++; if (v >= 6) six++; } }
      printf("totals:"); for (int i = 0; i < 12; i++) printf(" %d%s:%d", i, i == 11 ? "+" : "", h[i]); printf("  min %d max %d | a team scores 0: %.0f%%  a team scores 6+: %.1f%%\n", mn, mx, 100.0 * z / (2 * perH.size()), 100.0 * six / (2 * perH.size())); }
    printf("goalie pulls %d\n", g_pulls); printf("sounds:"); for (int i = 0; i < S_COUNT; i++) printf(" %d", g_hostSnd[i]); printf("\n");
    return 0;
  }
  if (mode == "pro") {   // chl_host pro SEASONS [LIVE_EVERY]: a whole simulated career (live CPU-played games every N days), checks each season
    int seasons = argc > 2 ? atoi(argv[2]) : 3, live = argc > 3 ? atoi(argv[3]) : 0; g_rng.s = argc > 4 ? atoi(argv[4]) : 777; ::mode = "pro";
    proNew(0, "TEST GUY", 19, 1); CR->draftDone = true; g_autoplay = true; int lastSeason = 0, liveN = 0; long steps = 0;
    while (CR && CR->phase != "retired" && CR->season <= seasons && steps++ < 200000) {
      Career &C = *CR;
      if (C.season != lastSeason) { lastSeason = C.season; }
      if (C.hasTrade) { printf("  [%s] age %d day %d %s -> %s (ovr %d ready %d): %s\n", C.trade.title.c_str(), C.age, C.day, C.L[C.trade.from].ab.c_str(), C.L[C.trade.to].ab.c_str(), proOvr(), readiness(), C.trade.why.c_str()); C.hasTrade = false; C.showTrade = false; }
      if (C.need) { negStart(true); negPush(); negAccept(); continue; }
      // spend XP on the lowest rating
      { std::string lo; int lv = 999; for (auto k : FKEYS) { int v = g_stats(k).i(50); if (v < lv) { lv = v; lo = k; } } int m; int c = proCostN(lo, 1, &m); if (m && C.xp >= c) proUpgrade(lo, 1); }
      if (C.phase == "over") {
        PP *Y = youMe(); PTeam &L = C.L[C.me];
        printf("SEASON %d  age %d  %s %s %d-%d  you %dG %dA  OVR %d  ready %d bar %d  xp %d cash %d  champ %s (other %s)  titles %d calder %d  NHL %dGP %dG %dA  AHL %dGP %dG %dA  players %zu  cap %.1f pay %.1f\n", C.season, C.age, proLg() ? "AHL" : "NHL", L.ab.c_str(), L.w, L.l, Y->gl, Y->as, proOvr(), readiness(), callBar(), C.xp, C.money, C.champ >= 0 ? C.L[C.champ].ab.c_str() : "-", C.ochamp >= 0 ? C.L[C.ochamp].ab.c_str() : "-", C.titles, C.calder, C.cGP, C.cG, C.cA, C.aGP, C.aG, C.aA, C.P.size(), capOf(), payroll(orgOf(C.me)));
        { int avN = 0, avA = 0, nN = 0, nA = 0; for (auto &q : C.P) if (!q->g && !q->me && q->t >= 0) { if (q->t < NA) { avN += ovQ(q.get()); nN++; } else { avA += ovQ(q.get()); nA++; } } int bs = 0, bmin = 99; for (int t = 0; t < 32; t++) { int m = 99; for (PP *q : teamS(t, false, true)) if (!q->me) m = std::min(m, ovQ(q)); bs += m; bmin = std::min(bmin, m); } printf("   avg skater OVR: NHL %d  AHL %d   weakest NHL regular: avg %d min %d\n", avN / std::max(1, nN), avA / std::max(1, nA), bs / 32, bmin); }
        int bad = 0; for (int t = 0; t < (int)C.L.size(); t++) { int s = (int)teamS(t, false, true).size(), g = (int)teamG(t).size(); if (s != 9 || g != 2) { bad++; printf("   roster %s: %d skaters %d goalies\n", C.L[t].ab.c_str(), s, g); } }
        std::vector<PP *> top; for (auto &q : C.P) if (!q->g && q->t >= 0) top.push_back(q.get()); std::sort(top.begin(), top.end(), [](PP *a, PP *b) { return a->gl + a->as > b->gl + b->as; });
        printf("   scoring leader %s %dG %dA | log: %s\n", top[0]->nm().c_str(), top[0]->gl, top[0]->as, C.log.empty() ? "" : C.log[0].s.c_str());
        proSave(); size_t n0 = C.P.size(); proLoadSlot(0); printf("   save/load: %zu -> %zu players, ovr %d\n", n0, CR ? CR->P.size() : 0, CR ? proOvr() : -1);
        { auto t0 = std::chrono::steady_clock::now(); proNextSeason(); printf("   offseason %.0f ms\n", std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count()); } continue; }
      if (userHurt()) { proSimHealthy(); continue; }
      if (offDay()) { if (C.money >= trainCost() && (C.ci % 2)) proDoTrain(C.ci % 4); else proSkipDay(); continue; }
      if (live > 0 && (C.day % live) == 0 && C.phase == "reg" && proCanPlay()) {
        startGame(); long f = 0;
        if (SK) { double a0 = 0, a1 = 0; for (Src *q : SK->T[0].allSk) a0 += ovSk(q); for (auto &L : SK->T[1].lines) for (Src *q : L) a1 += ovSk(q); int n1 = 0; for (auto &L : SK->T[1].lines) n1 += L.size();
          if (getenv("CHL_PRODBG")) printf("    start: home %s g %.0f (%zu sk avg %.0f) away %s g %.0f (%d sk avg %.0f) adj %.2f\n", SK->T[0].name.c_str(), SK->T[0].g.gs.ovr, SK->T[0].allSk.size(), a0 / std::max<size_t>(1, SK->T[0].allSk.size()), SK->T[1].name.c_str(), SK->T[1].g.gs.ovr, n1, a1 / std::max(1, n1), g_leagueAdj ? g_leagueAdj() : 0); } while (state == ST_PLAY && f < 200000) { frameStep(false); plat_end_frame(); f++; }
        liveN++; if (liveN <= 3 || liveN % 10 == 0 || getenv("CHL_PRODBG")) printf("  live game %d: %d-%d  you %dG %dA %dSOG  +%d XP +$%d  %s\n", liveN, rs.hs, rs.as, rs.f.g, rs.f.a, rs.f.sog, rs.xp, rs.cash, rs.note.c_str());
        state = ST_MENU; screen = "main"; if (C.day == 0 && C.phase == "reg") C.day = C.day; continue; }
      { auto t0 = std::chrono::steady_clock::now(); proSimGames(1); static double mx = 0; double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count(); if (ms > mx) { mx = ms; printf("   slowest sim day %.1f ms\n", ms); } }
    }
    if (CR && CR->phase == "retired") printf("RETIRED (%s) at %d, %d titles, career %dG %dA in %d GP\n", CR->retWhy.c_str(), CR->age, CR->titles, CR->cG, CR->cA, CR->cGP);
    return 0;
  }
  if (mode == "proload") {   // chl_host proload SLOT GAMES: load a saved career (old saves get the AHL added) and sim on
    int slot = argc > 2 ? atoi(argv[2]) : 0, n = argc > 3 ? atoi(argv[3]) : 20; ::mode = "pro"; proLoadSlot(slot);
    if (!CR) { printf("load failed\n"); return 1; }
    printf("loaded: %zu teams, %zu players, you %s (%s) age %d OVR %d debut %d\n", CR->L.size(), CR->P.size(), CR->L[CR->me].n.c_str(), proLg() ? "AHL" : "NHL", CR->age, proOvr(), CR->debut);
    for (int i = 0; i < n && CR->phase == "reg"; i++) { if (CR->need) { negStart(true); negAccept(); } while (offDay()) proSkipDay(); proSimGames(1); }
    int bad = 0; for (int t = 0; t < (int)CR->L.size(); t++) if (teamS(t, false, true).size() < 7 || teamG(t).size() != 2) bad++;
    printf("after %d games: day %d, %s %d-%d, rosters off %d, players %zu\n", n, CR->day, CR->L[CR->me].ab.c_str(), CR->L[CR->me].w, CR->L[CR->me].l, bad, CR->P.size());
    proSave(); proLoadSlot(slot); printf("save/load again: %zu teams %zu players\n", CR ? CR->L.size() : 0, CR ? CR->P.size() : 0); return 0; }
  if (mode == "probench") {   // a Be a Pro game: how the lines rotate, time on the bench, a sim to the next shift
    g_rng.s = 31; ::mode = "pro"; proNew(1, "BENCH TEST", 9, 1); CR->draftDone = true; while (offDay()) proSkipDay(); g_autoplay = true; startGame();
    long f = 0; double onT = 0, benchT = 0, li1 = 0, li2 = 0, aw[3] = {0, 0, 0}; int sims = 0, lastLi = -1, changes = 0;
    while (state == ST_PLAY && f < 200000) { frameStep(false); plat_end_frame(); f++; if (!SK || SK->phase != PH_PLAY) continue;
      double dt = 1 / 30.0; if (SK->uBench) benchT += dt; else onT += dt; if (SK->T[0].li == 1) li1 += dt; if (SK->T[0].li == 2) li2 += dt; aw[SK->T[1].li % 3] += dt;
      if (SK->T[0].li != lastLi) { changes++; lastLi = SK->T[0].li; }
      if (SK->uBench && getenv("SIMSHIFT") && f % 7 == 0) { int a = SK->T[0].score, b = SK->T[1].score; double c = SK->clock; skSimShift(); sims++; printf("  sim shift: clock %.0f -> %.0f, score %d-%d -> %d-%d, user on %d\n", c, SK ? SK->clock : 0, a, b, SK ? SK->T[0].score : 0, SK ? SK->T[1].score : 0, SK ? (int)!SK->uBench : -1); } }
    printf("you on ice %.0fs, bench %.0fs (line2 %.0f line3 %.0f), home line changes %d, away lines %.0f/%.0f/%.0f, sims %d, final %d-%d\n", onT, benchT, li1, li2, changes, aw[0], aw[1], aw[2], sims, rs.hs, rs.as);
    proDelete(1); return 0; }
  if (mode == "benchrun") {   // D-pad RIGHT when tired: the CPU skates you to the bench; quick play and Be a Pro
    for (int pm = 0; pm < 2; pm++) { g_rng.s = 7; if (pm) { ::mode = "pro"; proNew(1, "RUN TEST", 9, 1); CR->draftDone = true; while (offDay()) proSkipDay(); } else ::mode = "quick";
      startGame(); long f = 0; uint32_t btn = 0; g_hostInput = [&](Pad &p, Touch &) { p.btn = btn; };
      while (SK && SK->phase != PH_PLAY && f < 3000) { frameStep(false); plat_end_frame(); f++; if (SK && SK->phase == PH_PREVIEW) { btn = B_CROSS; } else btn = 0; }
      for (int i = 0; i < 200; i++) { frameStep(false); plat_end_frame(); }
      Skater *u = SK->user; u->st = 15; u->tired = true; if (SK->puck.owner == u) SK->puck.owner = nullptr;
      btn = B_RIGHT; frameStep(false); plat_end_frame(); btn = 0; printf("%s: benchRun %d open %d\n", pm ? "pro" : "quick", (int)SK->benchRun, (int)skBenchOpen());
      int t = 0; for (; t < 1200 && SK && SK->benchRun; t++) { frameStep(false); plat_end_frame(); if (SK->phase != PH_PLAY) break; }
      printf("   after %d frames: benchRun %d uBench %d st %.0f li %d phase %d onIce %d\n", t, (int)SK->benchRun, (int)SK->uBench, SK->user->st, SK->T[0].li, (int)SK->phase, (int)onTeam(0, SK->user));
      skQuit(); state = ST_MENU; if (pm) proDelete(1); }
    return 0; }
  if (mode == "gshots") {   // chl_host gshots DIR: the faceoff ring, play, the line-change reminder, the run to the bench, the pause settings, the career bench
    std::string dir = argc > 2 ? argv[2] : "."; g_rng.s = 11; ::mode = "quick";
    auto F = [](int n, bool d = false) { for (int i = 0; i < n; i++) { frameStep(d); plat_end_frame(); } };
    auto SH = [&](const char *nm) { g_hostRaster = true; frameStep(true); plat_end_frame(); g_hostRaster = false; host_shot((dir + "/" + nm + ".ppm").c_str()); printf("shot %s phase %d\n", nm, SK ? (int)SK->phase : -1); };
    uint32_t btn = 0; g_hostInput = [&](Pad &p, Touch &) { p.btn = btn; };
    startGame(); for (int i = 0; i < 4000 && SK && SK->phase != PH_FACEOFF; i++) { btn = (i % 20 == 0) ? B_CROSS : 0; F(1); } btn = 0;
    for (int i = 0; i < 600 && SK && !(SK->phase == PH_FACEOFF && SK->fo.t > SK->fo.show + .35); i++) F(1, true); SH("g1_faceoff");
    g_autoplay = true; F(900, true); SH("g2_play"); g_autoplay = false;
    for (int i = 0; i < 3000 && SK && SK->phase != PH_PLAY; i++) F(1, true);
    SK->user->st = 15; SK->user->tired = true; if (SK->puck.owner == SK->user) SK->puck.owner = nullptr; F(2, true); SH("g3_tired");
    btn = B_RIGHT; F(1, true); btn = 0; F(40, true); SH("g4_tobench");
    paused = true; pauseTab = 3; F(3, true); SH("g5_settings"); paused = false; skQuit(); state = ST_MENU;
    ::mode = "pro"; proNew(1, "BENCH SHOT", 9, 1); CR->draftDone = true; while (offDay()) proSkipDay(); g_autoplay = true; startGame();
    for (int i = 0; i < 6000 && SK && !SK->uBench; i++) { if (SK->phase == PH_PLAY && i > 600) { SK->user->st = 10; SK->user->tired = true; SK->benchRun = true; if (SK->puck.owner == SK->user) SK->puck.owner = nullptr; } F(1, i % 4 == 0); }
    F(60, true); SH("g6_bench"); skQuit(); proDelete(1); return 0; }
  if (mode == "proflow") {   // the menu flow by button ids: new career in file 3, draft, hub, a game, quit (sim the rest), continue
    auto F = [](int n) { for (int i = 0; i < n; i++) { frameStep(true); plat_end_frame(); } };
    auto P = [&](const char *id) { uiTap(id); F(40); printf("%-12s -> state %d mode %s screen %s%s\n", id, (int)state, ::mode.c_str(), screen.c_str(), CR ? (" | " + CR->L[CR->me].ab + " day " + istr(CR->day)).c_str() : ""); };
    F(5); P("mode:pro"); P("pslot:2"); P("key:J"); P("key:O"); P("namego"); P("pnum:10"); P("pdiff:2"); P("pgo"); F(300); P("draftdone");
    while (offDay()) P("skipday"); P("play"); F(200); { uiTap("resume"); paused = true; uiTap("quit"); paused = false; F(5); printf("after quit: screen %s xp %d note %s\n", screen.c_str(), rs.xp, rs.note.c_str()); }
    P("nav:main"); P("sim1"); P("nav:modes"); P("cont"); P("nav:upg"); P("nav:main"); P("nav:office"); P("nav:main");
    printf("career %s #%d diff %d\n", CR->nm.c_str(), CR->num, CR->diff); proDelete(2); return 0; }
  if (mode == "proshots") {   // chl_host proshots DIR: render every Be a Pro / practice screen to DIR/*.ppm
    std::string dir = argc > 2 ? argv[2] : "."; g_rng.s = 4242; ::mode = "pro"; state = ST_MENU;
    auto shot = [&](const std::string &scr, const std::string &nm) { screen = scr; for (int i = 0; i < 16; i++) { frameStep(true); plat_end_frame(); } { frameStep(false); plat_end_frame(); } g_hostRaster = true; { frameStep(true); plat_end_frame(); } g_hostRaster = false; host_shot((dir + "/" + nm + ".ppm").c_str()); printf("shot %s (%s)\n", nm.c_str(), screen.c_str()); };
    screen = "proslots"; shot("proslots", "p00_slots_empty");
    pname = "ALEX RYAN"; nameFor = "pro"; shot("pronew", "p01_new");
    proNew(0, "ALEX RYAN", 19, 1); setLast("pro", 0); { extern double proBusyT; (void)proBusyT; }
    for (int i = 0; i < 3; i++) { frameStep(false); plat_end_frame(); }
    uiTap("pslot:0"); for (int i = 0; i < 30; i++) { { frameStep(false); plat_end_frame(); } } shot("draft", "p02_draft");
    CR->draftDone = true; proSimGames(10); for (int i = 0; i < 30 && !offDay(); i++) proSimGames(1);
    shot("main", "p03_hub"); CR->xp = 5000; CR->money = 3000; shot("upg", "p04_upgrades"); uiTap("utab:1"); shot("upg", "p05_perks"); uiTap("utab:0");
    shot("train", "p06_train"); shot("shop", "p07_shop"); shot("office", "p08_office"); uiTap("off:neg"); shot("neg", "p09_neg"); shot("ntc", "p10_ntc"); uiTap("nav:treq"); uiTap("tq:3"); uiTap("tq:7"); shot("treq", "p11_treq");
    shot("toff", "p12_offers"); uiTap("nav:sched"); shot("sched", "p13_sched");
    for (int t = 0; t < 9; t++) { uiTap("stab:" + istr(t)); shot("stand", "p14_stand" + istr(t)); }
    uiTap("slg:1"); for (int t : {3, 4, 7}) { uiTap("stab:" + istr(t)); shot("stand", "p14_ahl" + istr(t)); } uiTap("slg:0");
    CR->hasTrade = true; CR->trade.from = CR->me; CR->trade.to = orgOf(CR->me); CR->trade.title = "CALLED UP"; CR->trade.why = "12 points in 20 games forced the " + CR->L[orgOf(CR->me)].n + "' hand. Welcome to the NHL!"; CR->trade.ret.clear(); shot("trade", "p15_callup"); CR->hasTrade = false;
    CR->hasTrade = true; CR->trade.from = CR->me; CR->trade.to = (CR->me + 5) % 32; CR->trade.why = "The team made an offer your club could not refuse."; CR->trade.ret = {"Some Guy", "Other Guy"}; CR->trade.title = "TRADE ALERT"; shot("trade", "p15_trade"); CR->hasTrade = false;
    ::mode = "pro"; while (offDay()) proSkipDay(); startGame(); printf("game started %d\n", SK != nullptr); for (int i = 0; i < 400; i++) { frameStep(false); plat_end_frame(); } g_autoplay = true; for (int i = 0; i < 1500; i++) { frameStep(false); plat_end_frame(); } g_hostRaster = true; { frameStep(true); plat_end_frame(); } g_hostRaster = false; host_shot((dir + "/p20_game.ppm").c_str());
    skQuit(); for (int i = 0; i < 5; i++) { frameStep(false); plat_end_frame(); } g_hostRaster = true; { frameStep(true); plat_end_frame(); } g_hostRaster = false; host_shot((dir + "/p21_result.ppm").c_str()); printf("result %s\n", screen.c_str());
    proSimGames(80); proSimGames(10); proSimGames(10); proSimGames(10); proSimGames(10); shot("main", "p16_hub_po"); uiTap("nav:stand"); shot("stand", "p17_bracket"); uiTap("slg:0"); shot("stand", "p17_bracket_nhl"); uiTap("slg:1");
    for (int i = 0; i < 20 && CR->phase == "po"; i++) proSimGames(5); shot("main", "p18_hub_over");
    ::mode = "quick"; shot("modes", "p19_mainmenu");
    CR->phase = "retired"; CR->retWhy = "age"; shot("retired", "p22_retired");
    ::mode = "practice"; g_autoplay = false; shot("main", "q00_practice");
    for (int k = 0; k < 3; k++) { pracKind = k; startGame(); g_autoplay = true; for (int i = 0; i < 260; i++) { frameStep(false); plat_end_frame(); } g_hostRaster = true; { frameStep(true); plat_end_frame(); } g_hostRaster = false; host_shot((dir + "/q0" + istr(k + 1) + "_drill.ppm").c_str()); skQuit(); state = ST_MENU; }
    return 0;
  }
  if (mode == "script") {   // chl_host script DIR "tokens": wN wait, X O SQ TR U D L R LB RB ST press, tX,Y tap, hX,Y,N hold, sNAME shot, auto, menu (wait for the menus), focus
    std::string dir = argc > 2 ? argv[2] : "."; std::string sc = argc > 3 ? argv[3] : ""; g_rng.s = 99;
    std::vector<std::string> tk; { std::string cur; for (char ch : sc) { if (ch == ' ') { if (!cur.empty()) tk.push_back(cur); cur.clear(); } else cur += ch; } if (!cur.empty()) tk.push_back(cur); }
    uint32_t hold = 0; int stickX = 128, stickY = 128, rX = 128, rY = 128; float tx_ = -1, ty_ = -1; int tn = 0; g_hostRaster = false;
    g_hostInput = [&](Pad &p, Touch &t) { p.btn = hold; p.lx = stickX; p.ly = stickY; p.rx = rX; p.ry = rY; if (tn > 0) { t.n = 1; t.p[0] = {7, tx_, ty_}; tn--; } };
    auto step = [&](int n) { for (int i = 0; i < n; i++) frameStep(true); };
    std::map<std::string, uint32_t> B = {{"X", B_CROSS}, {"O", B_CIRCLE}, {"SQ", B_SQUARE}, {"TR", B_TRIANGLE}, {"U", B_UP}, {"D", B_DOWN}, {"L", B_LEFT}, {"R", B_RIGHT}, {"LB", B_L}, {"RB", B_R}, {"ST", B_START}};
    step(5);
    for (auto &s : tk) {
      if (s[0] == 'w' && isdigit(s[1])) step(atoi(s.c_str() + 1));
      else if (B.count(s)) { hold = B[s]; step(1); hold = 0; step(2); }
      else if (s[0] == 't' && isdigit(s[1])) { tx_ = atof(s.c_str() + 1); ty_ = atof(strchr(s.c_str(), ',') + 1); tn = 2; step(3); }
      else if (s[0] == 'h' && isdigit(s[1])) { const char *c1 = strchr(s.c_str(), ','); tx_ = atof(s.c_str() + 1); ty_ = atof(c1 + 1); tn = atoi(strchr(c1 + 1, ',') + 1); step(tn + 2); }
      else if (s == "qsprint") printf("sprint %d puck %d\n", SK && SK->user ? (int)SK->user->sprint : -1, SK && SK->user ? (int)(SK->puck.owner == SK->user) : -1);
      else if (s[0] == 's') { g_hostRaster = true; step(1); g_hostRaster = false; std::string p = dir + "/" + s.substr(1) + ".ppm"; host_shot(p.c_str()); printf("shot %s  state %d mode %s screen %s focus %s coins %.0f\n", s.c_str() + 1, (int)state, ::mode.c_str(), screen.c_str(), mFocus.c_str(), UT ? UT->coins : -1.0); }
      else if (s.rfind("rs", 0) == 0 && s.size() > 2 && isdigit(s[2])) { rX = atoi(s.c_str() + 2); rY = atoi(strchr(s.c_str(), ',') + 1); step(1); }   // rsX,Y: hold the right stick there
      else if (s.rfind("ls", 0) == 0 && s.size() > 2 && isdigit(s[2])) { stickX = atoi(s.c_str() + 2); stickY = atoi(strchr(s.c_str(), ',') + 1); step(1); }
      else if (s == "auto") g_autoplay = true;
      else if (s == "noauto") g_autoplay = false;
      else if (s == "Lon") hold |= B_L; else if (s == "Loff") hold &= ~B_L;
      else if (s == "Ron") hold |= B_R; else if (s == "Roff") hold &= ~B_R;
      else if (s == "Xon") hold |= B_CROSS; else if (s == "Xoff") hold &= ~B_CROSS;
      else if (s == "waitgtop") { long n = 0; g_autoplay = true;   // until the away goalie is out at the top of his crease, set, with the puck coming at him
        while (SK && n++ < 60000) { const Goalie &q = SK->T[1].g; double d = std::fabs(q.x - SK->puck.x); if (SK->phase == PH_PLAY && std::fabs(q.x - (RK.L - RK.gl)) > RK.crD - .9 && d > 28 && d < 50 && std::fabs(q.mv) < 1 && !q.hasAn && !q.hasRq && SK->puck.owner && SK->puck.owner->team == 0) break; step(1); }
        printf("goalie top after %ld frames depth %.1f\n", n, SK ? std::fabs(SK->T[1].g.x - (RK.L - RK.gl)) : 0); }
      else if (s == "gdbg") { extern void skGoalieDbg(Goalie &, char *, int); char b[300]; if (SK) { skGoalieDbg(SK->T[1].g, b, sizeof b); printf("%s\n", b); } }
      else if (s.rfind("waitdist", 0) == 0) { double lim = atof(s.c_str() + 8); long n = 0; g_autoplay = true;   // until the puck is carried in on the away net, closer than N ft
        while (SK && n++ < 60000) { double gx = RK.L - RK.gl, dd = hyp(SK->puck.x - gx, SK->puck.y - RK.cy); if (SK->phase == PH_PLAY && SK->puck.owner && SK->puck.owner->team == 0 && SK->puck.x < gx && dd < lim) break; step(1); }
        printf("dist<%g after %ld frames, goalie %.1f ft out\n", lim, n, SK ? (RK.L - RK.gl) - SK->T[1].g.x : 0); }
      else if (s.rfind("waitside", 0) == 0) { int sg = s[8] == 'L' ? 1 : -1; long n = 0; g_autoplay = true;   // until the puck is carried on one side of the away net, 20-40 ft out
        while (SK && n++ < 80000) { double gx = RK.L - RK.gl, ex = gx - SK->puck.x, ey = (SK->puck.y - RK.cy) * sg, dd = hyp(ex, ey); const Goalie &q = SK->T[1].g;
          if (SK->phase == PH_PLAY && SK->puck.owner && SK->puck.owner->team == 0 && ex > 6 && ey > 12 && dd < 40 && dd > 18 && !q.hasAn && !q.hasRq && std::fabs(q.mv) < 1.5) break; step(1); }
        if (SK) printf("side %c after %ld frames: goalie y %+.1f face %.0f deg\n", s[8], n, SK->T[1].g.y - RK.cy, SK->T[1].g.face * 57.3); }
      else if (s == "waitgoal") { long n = 0; g_autoplay = true; while (SK && n++ < 60000 && SK->phase != PH_GOAL) step(1); printf("goal after %ld frames\n", n); }
      else if (s == "waitpuck") { long n = 0; g_autoplay = true; while (SK && n++ < 20000 && !(SK->phase == PH_PLAY && SK->puck.owner == SK->user && skInZone(SK->user))) step(1); g_autoplay = false; printf("puck after %ld frames\n", n); }
      else if (s.rfind("press", 0) == 0) { uint32_t keep = hold; hold |= B[s.substr(5)]; step(1); hold = keep; step(1); }
      else if (s == "rot") { for (int i = 0; i <= 12; i++) { double a = i / 12.0 * 2 * PI; stickX = 128 + (int)(120 * std::cos(a)); stickY = 128 + (int)(120 * std::sin(a)); step(1); } stickX = stickY = 128; step(1); }
      else if (s == "who") { if (SK) printf("  puck owner %s  spin %.2f  feed:", SK->puck.owner ? SK->puck.owner->nm.c_str() : "-", SK->user ? SK->user->spin : -1); for (auto &f : feed) printf(" [%s]", f.txt.c_str()); printf("\n"); }
      else if (s.rfind("cstat", 0) == 0) { int N = atoi(s.c_str() + 5), own = 0, call = 0; bool shot = false; g_autoplay = true;
        for (int i = 0; i < N && SK; i++) { frameStep(i % 50 == 0 && !shot); plat_end_frame(); if (SK && SK->puck.owner == SK->user) { own++; bool any = false; for (Skater *q : SK->T[0].on) if (q->call > 0) any = true; if (any) { call++; if (!shot && call == 30) { shot = true; g_hostRaster = true; frameStep(true); g_hostRaster = false; host_shot((dir + "/call.ppm").c_str()); } } } }
        printf("owned %d frames, a teammate calling in %d\n", own, call); }
      else if (s == "calls") { if (SK) for (Skater *q : SK->T[0].on) printf("  %s role %d call %.2f mate0 %d\n", q->nm.c_str(), (int)q->role, q->call, skMateFor(0) == q); }
      else if (s == "menu") { long n = 0; while (state == ST_PLAY && n++ < 200000) { frameStep(false); plat_end_frame(); } step(30); printf("game over after %ld frames: screen %s  rs %d-%d cash %d\n", n, screen.c_str(), rs.hs, rs.as, rs.cash); }
      else if (s == "focus") { printf("focus %s  btns", mFocus.c_str()); for (auto &b : btns) printf(" %s", b.id.c_str()); printf("\n"); }
    }
    return 0;
  }
  if (mode == "utopen") {   // chl_host utopen DIR: frames of the pack opening (by pack and best rarity) and the foil shop
    std::string dir = argc > 2 ? argv[2] : "."; utNew(2, "TEST CLUB"); UTX &X = *UT; X.coins = 99999; state = ST_MENU; ::mode = "ut";
    auto shotAt = [&](double tt, const std::string &nm) { screen = "utopen"; utOpenOn = true; for (int i = 0; i < 3; i++) { utOpen.t0 = now() - tt * 1000; frameStep(true); plat_end_frame(); }
      utOpen.t0 = now() - tt * 1000; g_hostRaster = true; frameStep(true); plat_end_frame(); g_hostRaster = false; host_shot((dir + "/" + nm + ".ppm").c_str()); printf("shot %s\n", nm.c_str()); };
    for (int t : {1, 3, 4}) { X.inv.push_back(t); utInvOpen(t); utOpen.all = false; utOpen.done = false;
      if (t == 3) for (auto &o : utOpen.cards) o.c.r = std::min(o.c.r, 3);   // a modest Elite pack
      for (double tt : {.5, 1.0, 1.25, 1.55, 1.8, 1.95, 2.15, 4.0}) shotAt(tt, "o" + istr(t) + "_" + istr((int)(tt * 100))); }
    X.inv.push_back(1); utInvOpen(1); for (auto &o : utOpen.cards) o.c.r = 6; for (double tt : {1.3, 1.6}) shotAt(tt, "osecret_" + istr((int)(tt * 100)));
    utOpenOn = false; screen = "utpacks"; for (int i = 0; i < 17; i++) { frameStep(true); plat_end_frame(); } g_hostRaster = true; frameStep(true); plat_end_frame(); g_hostRaster = false; host_shot((dir + "/shop.ppm").c_str());
    X.inv = {0, 1, 2, 3, 4, 5}; screen = "utinv"; for (int i = 0; i < 17; i++) { frameStep(true); plat_end_frame(); } g_hostRaster = true; frameStep(true); plat_end_frame(); g_hostRaster = false; host_shot((dir + "/inv.ppm").c_str());
    return 0; }
  if (mode == "utsim") {   // chl_host utsim: a new file's OVR, pack odds (AHL / NHL / NHL stars) and a training camp run
    utNew(2, "TEST CLUB"); UTX &X = *UT; printf("new file: team OVR %d, cards:", utTeamOv(X)); for (auto &c : X.cards) printf(" %s(%d)", c.p.c_str(), utOv(c)); printf("\n");
    for (int t = 0; t < 6; t++) { int n = 0, nhl = 0, star = 0, ahl = 0, leg = 0, maxSt = 0, ahlTop = 0; double ov = 0;
      for (int k = 0; k < 6000; k++) { size_t c0 = X.cards.size(); X.inv.push_back(t); utInvOpen(t); utOpenOn = false; int st = 0;
        for (size_t i = c0; i < X.cards.size(); i++) { const UTPDef *P = UTM(X.cards[i].p); n++; ov += utOv(X.cards[i]); if (P->leg) leg++; else if (P->ahl) { ahl++; if (P->ov >= 67) ahlTop++; } else { nhl++; if (P->ov >= 85) { star++; st++; } } }
        maxSt = std::max(maxSt, st); X.cards.resize(c0); }
      printf("%-9s cards %5d  AHL %5.1f%% (AHL stars 67+ %4.1f%%)  NHL %5.1f%%  NHL stars %5.2f%% (max %d/pack)  legends %4.1f%%  avg card OVR %.1f\n", UT_PACKS[t].n, n, 100.0 * ahl / n, 100.0 * ahlTop / n, 100.0 * nhl / n, 100.0 * star / n, maxSt, 100.0 * leg / n, ov / n); }
    // camp: send the 2nd-best forward, play 3 games
    for (auto *P : UT_AHL) if (P->pos == 'F' && P->ov == 64) { X.cards.push_back({X.n++, P->k, 0}); break; }   // a spare forward
    UCard c0 = X.cards[0]; int before = utOv(c0); std::string why; printf("camp ok: %d %s\n", utCampOk(c0, &why), why.c_str());
    utCampStart(c0.u, 1); printf("camp started: left %d, in lineup %d, full %d\n", X.campLeft, (int)(std::find(X.ro.begin(), X.ro.end(), c0.u) != X.ro.end()), utFull(X));
    for (int g = 0; g < 3; g++) { utPickSet(X.opp[1]); utAfter(true, false); }
    printf("after 3 games: left %d, OVR %d -> %d, trained bits %d, again ok %d (%s)\n", X.campLeft, before, utOv(c0), X.tm[c0.p], utCampOk(c0, &why), why.c_str());
    if (argc > 2) { std::string dir = argv[2]; state = ST_MENU; ::mode = "ut";
      auto shot = [&](const std::string &scr, const std::string &nm) { screen = scr; for (int i = 0; i < 16; i++) { frameStep(true); plat_end_frame(); } { frameStep(false); plat_end_frame(); } g_hostRaster = true; { frameStep(true); plat_end_frame(); } g_hostRaster = false; host_shot((dir + "/" + nm + ".ppm").c_str()); printf("shot %s (%s)\n", nm.c_str(), screen.c_str()); };
      shot("main", "u00_hub"); shot("utpacks", "u01_shop"); utCampSel = X.cards[1].u; shot("utcamp", "u02_camp_pick"); utCampStart(X.cards[1].u, 0); shot("utcamp", "u03_camp_on");
      utMenuOnF = true; utMenu = UMenu(); utMenu.u = X.cards[2].u; utMenu.x = W * .1; utMenu.y = H * .2; utMenu.w = .3 * U; shot("utroster", "u04_menu"); utMenuOnF = false;
      X.inv.push_back(5); X.inv.push_back(1); shot("utinv", "u05_inv"); utInvOpen(5); utOpen.all = true; utOpen.t0 = 0; shot("utopen", "u06_cup_pack"); }
    utSave(); return 0; }
  if (mode == "utcheck") {   // card ratings, salaries, perks and CPU team OVRs, to compare with the legacy build
    std::vector<std::string> keys; for (size_t i = 0; i < UTP.size(); i += 7) keys.push_back(UTP[i].k);
    for (auto &k : keys) for (int r : {0, 3, 6}) { UCard c{1, k, r}; const URat &R = utRat(c); std::string s = k + " r" + istr(r) + " ovr " + istr(R.ovr) + " ar " + R.ar + " sal " + fixed(utSal(c), 1) + " |";
      if (R.goalie) for (auto q : UT_GK) s += " " + istr(R.get(q)); else { for (auto q : UT_SK) s += " " + istr(R.get(q)); s += " " + istr(R.rt.bhp) + " " + istr(R.rt.bha); }
      s += " pk"; for (auto &e : pkCard(c)) s += std::string(" ") + PERKS[e.id].id + istr(e.t); printf("%s\n", s.c_str()); }
    for (int cap : {24, 40, 1000}) { UTX X; X.hasCap = true; X.cap = cap; for (size_t i = 0, u = 1; i < UTP.size(); i += 11, u++) if (!UTP[i].dr) X.cards.push_back({(int)u, UTP[i].k, (int)(i % 7)});
      utAuto(X); std::string s = "auto " + istr(cap) + ":"; for (int u : X.ro) s += " " + istr(u); printf("%s  team %d pay %.1f\n", s.c_str(), utTeamOv(X), utPay(X)); }
    for (int i = 0; i < 40; i++) { UOpp o; o.ov = 50 + i; o.seed = 1000003.0 * i + 17; printf("opp %d %.0f %d\n", o.ov, o.seed, utOppOv(o)); }
    return 0;
  }
  if (mode == "shots") {
    std::string dir = argc > 2 ? argv[2] : "."; std::vector<int> want; for (int i = 3; i < argc; i++) want.push_back(atoi(argv[i]));
    g_rng.s = 777; long fr = 0;
    // menu: wait, then X to start; then the CPU plays your skater (the screens are what you'd see)
    g_hostInput = [&](Pad &p, Touch &) { if (fr == 20 || fr == 21) p.btn = 0; if (fr == 22) p.btn = B_CROSS; if (fr > (getenv("CHL_LATE") ? 140 : 60)) g_autoplay = true; };
    int maxf = want.empty() ? 0 : *std::max_element(want.begin(), want.end());
    for (fr = 0; fr <= maxf; fr++) {
      g_hostRaster = std::find(want.begin(), want.end(), (int)fr) != want.end();
      frameStep(true);
      for (int w : want) if (w == fr) { std::string p = dir + "/f" + istr(fr) + ".ppm"; host_shot(p.c_str());
        printf("frame %ld: state %d phase %d  tris %ld glyphs %ld calls %ld  cache %zu (%.1f MB)\n", fr, (int)state, SK ? (int)SK->phase : -1, g_hostTris, g_hostGlyphs, g_hostCalls, ctx.cacheSize(), ctx.cacheBytes() / 1048576.0); }
      g_hostTris = g_hostGlyphs = g_hostCalls = 0;
    }
    return 0;
  }
  if (mode == "human") {   // a scripted player on the pad: faceoffs on time, stick shots, slap shots, dekes, passes, checks
    int n = argc > 2 ? atoi(argv[2]) : 5; g_rng.s = 4242; long tot[6] = {0};
    int phase = 0; long fr = 0;
    g_hostInput = [&](Pad &p, Touch &) {
      if (!SK || state != ST_PLAY) return;
      Game &G = *SK; Skater *u = G.user; if (!u) return;
      auto stick = [&](double wx, double wy, int &sx, int &sy) { double m = hyp(wx, wy); if (m < 1e-6) { sx = sy = 128; return; } wx /= m; wy /= m; sx = 128 + (int)(wy * 127); sy = 128 - (int)(wx * 127); };   // world -> stick (screen up = +x)
      if (G.phase == PH_PREVIEW || G.phase == PH_INTRO) { if (fr % 20 == 0) p.btn = B_CROSS; return; }
      if (G.phase == PH_FACEOFF) { double drop = G.fo.show + G.fo.close; if (std::fabs(G.fo.t - drop) < .03) p.btn = B_CROSS; return; }
      Puck &P = G.puck; bool mine = P.owner == u;
      if (mine) {
        double ax = attackX(0), dn = hyp(ax - u->x, RK.cy - u->y);
        stick(ax - 12 - u->x, RK.cy - u->y, p.lx, p.ly);
        if (dn > 60) p.btn |= B_R;
        // shooting stick: push up (wrist) or pull back (slap), slide it sideways to aim, let go to shoot
        if (dn < 38) { phase++; int k = phase % 30; bool sl = (phase / 30) % 3 == 2; if (k >= 3 && k < (sl ? 20 : 10)) { p.ry = sl ? 230 : 25; p.rx = 128 + ((phase / 30) % 2 ? 80 : -80) * (k > 5); } }
        else phase = 0;
        if (fr % 97 == 0) p.btn |= B_SQUARE;
        if (fr % 151 == 0) p.btn |= B_TRIANGLE;
        if (fr % 173 == 0) p.btn |= B_CROSS;
      } else {
        stick(P.x - u->x, P.y - u->y, p.lx, p.ly);
        if (hyp(P.x - u->x, P.y - u->y) > 25) p.btn |= B_R;
        if (P.owner && P.owner->team == 1 && hyp(P.owner->x - u->x, P.owner->y - u->y) < 6) { if ((fr / 8) % 3 == 0) p.btn |= B_CIRCLE; if (fr % 11 == 0) p.btn |= B_CROSS; }
        if (fr % 301 == 0) p.btn |= B_L;
        if (G.hasBat && G.bat.user) p.lx = (fr / 3) % 2 ? 255 : 0;
      }
    };
    for (int gi = 0; gi < n; gi++) { skStart(); state = ST_PLAY; long f = 0;
      while (state == ST_PLAY && f < 200000) { if (SK) { tot[3] = SK->me.shots; } frameStep(false); plat_end_frame(); f++; fr++; }
      tot[0] += RS.f.g; tot[1] += RS.f.a; tot[2] += RS.f.sog; tot[4] += RS.f.hits; tot[5] += RS.f.fow; printf("game %d: %d-%d  you %dG %dA %d SOG %d hits  faceoffs %d/%d\n", gi, RS.hs, RS.as, RS.f.g, RS.f.a, RS.f.sog, RS.f.hits, RS.f.fow, RS.f.fot); }
    return 0;
  }
  if (mode == "pause") {   // a game, then START and the pause tabs
    std::string dir = argc > 2 ? argv[2] : "."; long fr = 0; g_rng.s = 99;
    g_hostInput = [&](Pad &p, Touch &) { if (fr == 22) p.btn = B_CROSS; if (fr > 60) g_autoplay = true; if (fr == 700) p.btn = B_START; if (fr == 720) p.btn = B_R; if (fr == 740) p.btn = B_R; };
    for (fr = 0; fr <= 760; fr++) { g_hostRaster = fr == 710 || fr == 730 || fr == 750; frameStep(true); if (fr == 710 || fr == 730 || fr == 750) { std::string p = dir + "/p" + istr(fr) + ".ppm"; host_shot(p.c_str()); } }
    return 0;
  }
  if (mode == "bench") {
    int n = argc > 2 ? atoi(argv[2]) : 600; g_rng.s = 5; g_autoplay = true; skStart(); state = ST_PLAY;
    for (int i = 0; i < 400; i++) { frameStep(false); plat_end_frame(); }   // past the preview and the intro into play
    auto t0 = std::chrono::steady_clock::now(); long tris = 0;
    g_hostRaster = getenv("CHL_RASTER") != nullptr;
    for (int i = 0; i < n && state == ST_PLAY; i++) { frameStep(true); tris += g_hostTris; g_hostTris = 0; }
    double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    extern long g_host3d; printf("%d frames, %.2f ms/frame on this PC (incl. the software rasterizer), %ld tris/frame (+%ld GPU 3D), cache %zu blocks %.1f MB\n", n, ms / n, tris / n, g_host3d / n, ctx.cacheSize(), ctx.cacheBytes() / 1048576.0);
    return 0;
  }
  return 0;
}

// CHL 2026 native - PS Vita platform layer: vita2d drawing, pad + touch, the audio thread, files.
// Everything the game draws arrives here as coloured triangles (plat_tris) or font glyphs (plat_glyphs),
// so moving to vitaGL later only means rewriting this file.
#include "platform.h"
#include "audio.h"
#include "canvas.h"
#include <psp2/kernel/processmgr.h>
#include <psp2/kernel/threadmgr.h>
#include <psp2/ctrl.h>
#include <psp2/touch.h>
#include <psp2/power.h>
#include <psp2/display.h>
#include <psp2/io/stat.h>
#include <psp2/audioout.h>
#include <vita2d.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>

extern "C" {
int _newlib_heap_size_user = 192 * 1024 * 1024;
unsigned int sceUserMainThreadStackSize = 1 * 1024 * 1024;
// vita2d references the shared-framebuffer API (only used as a system overlay); these satisfy the linker
int sceSharedFbOpen(int index) { (void)index; return -1; }
int sceSharedFbClose(int fb) { (void)fb; return 0; }
int sceSharedFbBegin(int fb, void *info) { (void)fb; (void)info; return -1; }
int sceSharedFbEnd(int fb) { (void)fb; return 0; }
int sceSharedFbGetInfo(int fb, void *info) { (void)fb; (void)info; return -1; }
}

#define DATA_DIR "ux0:data/GoalieSimNative"
static vita2d_texture *g_font = nullptr;
static unsigned g_lastV = 0;
static volatile int g_au_run = 1;
static SceUID g_au_thread = -1;

// ---- drawing
void plat_tris(const float *p, const uint32_t *c, int n, float ox, float oy, float k) {
  n -= n % 3; if (n <= 0) return;
  vita2d_color_vertex *v = (vita2d_color_vertex *)vita2d_pool_memalign(n * sizeof(vita2d_color_vertex), sizeof(vita2d_color_vertex));
  if (!v) return;   // the frame's vertex pool is full: skip rather than crash
  for (int i = 0; i < n; i++) { v[i].x = p[i * 2] * k + ox; v[i].y = p[i * 2 + 1] * k + oy; v[i].z = .5f; v[i].color = c[i]; }
  vita2d_draw_array(SCE_GXM_PRIMITIVE_TRIANGLES, v, n);
}
void plat_glyphs(const float *g, int n, uint32_t col, float ox, float oy, float k) {
  if (!g_font) return;
  for (int i = 0; i < n; i++, g += 7)
    vita2d_draw_texture_tint_part_scale(g_font, g[0] * k + ox, g[1] * k + oy, g[2], g[3], g[4], g[5], g[6] * k, g[6] * k, col);
}

// ---- audio: the mixer runs on its own thread, one 512-sample grain at a time
static int au_thread(SceSize, void *) {
  au_synth_all();
  int port = sceAudioOutOpenPort(SCE_AUDIO_OUT_PORT_TYPE_MAIN, 512, 48000, SCE_AUDIO_OUT_MODE_MONO);
  if (port < 0) return 0;
  int vols[2] = {SCE_AUDIO_VOLUME_0DB, SCE_AUDIO_VOLUME_0DB};
  sceAudioOutSetVolume(port, (SceAudioOutChannelFlag)(SCE_AUDIO_VOLUME_FLAG_L_CH | SCE_AUDIO_VOLUME_FLAG_R_CH), vols);
  static int16_t out[2][512]; int b = 0;
  while (g_au_run) { au_mix(out[b], 512, 48000); sceAudioOutOutput(port, out[b]); b ^= 1; }
  sceAudioOutReleasePort(port);
  return 0;
}
int snd_play(int id, float vol, float rate, bool loop) { return au_play(id, vol, rate, loop); }
void snd_set(int v, float vol) { au_set(v, vol); }
void snd_stop(int v) { au_stop(v); }

// ---- lifecycle
bool plat_init() {
  scePowerSetArmClockFrequency(444);
  scePowerSetBusClockFrequency(222);
  scePowerSetGpuClockFrequency(222);
  scePowerSetGpuXbarClockFrequency(166);
  sceIoMkdir(DATA_DIR, 0777);
  vita2d_init_advanced(8 * 1024 * 1024);
  vita2d_set_clear_color(RGBA8(11, 18, 32, 255));
  vita2d_set_vblank_wait(0);
  g_font = vita2d_load_PNG_file("app0:font.png");
  if (g_font) vita2d_texture_set_filters(g_font, SCE_GXM_TEXTURE_FILTER_LINEAR, SCE_GXM_TEXTURE_FILTER_LINEAR);
  sceTouchSetSamplingState(SCE_TOUCH_PORT_FRONT, SCE_TOUCH_SAMPLING_STATE_START);
  sceCtrlSetSamplingMode(SCE_CTRL_MODE_ANALOG);
  g_au_thread = sceKernelCreateThread("chl_audio", au_thread, 0x10000100, 0x10000, 0, 0, NULL);
  if (g_au_thread >= 0) sceKernelStartThread(g_au_thread, 0, NULL);
  g_lastV = sceDisplayGetVcount();
  return true;
}
void plat_shutdown() {
  g_au_run = 0;
  if (g_au_thread >= 0) { sceKernelWaitThreadEnd(g_au_thread, NULL, NULL); sceKernelDeleteThread(g_au_thread); }
  vita2d_wait_rendering_done();
  if (g_font) vita2d_free_texture(g_font);
  vita2d_fini();
  sceKernelExitProcess(0);
}
bool plat_running() { return true; }
void plat_begin_frame(uint32_t clear) { vita2d_set_clear_color(clear); vita2d_start_drawing(); vita2d_clear_screen(); }
void plat_end_frame() {
  vita2d_end_drawing();
  // a steady 30 FPS: every frame shows for exactly two refreshes, so motion stays even
  while ((int)(sceDisplayGetVcount() - g_lastV) < 2) sceDisplayWaitVblankStart();
  vita2d_swap_buffers();
  g_lastV = sceDisplayGetVcount();
}
double plat_now_ms() { return (double)sceKernelGetProcessTimeWide() / 1000.0; }
void plat_input(Pad &pad, Touch &touch) {
  SceCtrlData c; memset(&c, 0, sizeof c); sceCtrlPeekBufferPositive(0, &c, 1);
  SceTouchData tf; memset(&tf, 0, sizeof tf); sceTouchPeek(SCE_TOUCH_PORT_FRONT, &tf, 1);
  uint32_t b = 0;
  if (c.buttons & SCE_CTRL_LTRIGGER) b |= B_L;
  if (c.buttons & SCE_CTRL_RTRIGGER) b |= B_R;
  if (c.buttons & SCE_CTRL_START) b |= B_START;
  if (c.buttons & SCE_CTRL_SELECT) b |= B_SELECT;
  if (c.buttons & SCE_CTRL_CROSS) b |= B_CROSS;
  if (c.buttons & SCE_CTRL_CIRCLE) b |= B_CIRCLE;
  if (c.buttons & SCE_CTRL_SQUARE) b |= B_SQUARE;
  if (c.buttons & SCE_CTRL_TRIANGLE) b |= B_TRIANGLE;
  if (c.buttons & SCE_CTRL_UP) b |= B_UP;
  if (c.buttons & SCE_CTRL_DOWN) b |= B_DOWN;
  if (c.buttons & SCE_CTRL_LEFT) b |= B_LEFT;
  if (c.buttons & SCE_CTRL_RIGHT) b |= B_RIGHT;
  pad.btn = b; pad.lx = c.lx; pad.ly = c.ly; pad.rx = c.rx; pad.ry = c.ry;
  touch.n = 0;
  for (unsigned i = 0; i < tf.reportNum && touch.n < 6; i++)
    touch.p[touch.n++] = {(int)tf.report[i].id, tf.report[i].x * 960.f / 1920.f, tf.report[i].y * 544.f / 1088.f};
}
void plat_log(const std::string &s) { FILE *f = fopen(DATA_DIR "/log.txt", "a"); if (f) { fputs(s.c_str(), f); fputc('\n', f); fclose(f); } }
bool plat_read_file(const std::string &path, std::string &out) {
  FILE *f = fopen(path.c_str(), "rb"); if (!f) return false;
  fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
  out.resize(n > 0 ? n : 0); size_t got = n > 0 ? fread(&out[0], 1, n, f) : 0; fclose(f); out.resize(got); return true;
}
bool plat_write_file(const std::string &path, const std::string &data) {
  std::string tmp = path + ".tmp"; FILE *f = fopen(tmp.c_str(), "wb"); if (!f) return false;
  bool ok = fwrite(data.data(), 1, data.size(), f) == data.size(); fclose(f);
  if (ok) { remove(path.c_str()); ok = rename(tmp.c_str(), path.c_str()) == 0; }
  return ok;
}
std::string plat_data_dir() { return DATA_DIR "/"; }

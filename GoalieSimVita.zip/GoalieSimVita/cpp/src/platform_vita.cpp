// CHL 2026 native - the vita2d renderer (the fallback build; the main one is platform_vitagl.cpp).
// Everything the game draws arrives here as coloured triangles (plat_tris) or font glyphs (plat_glyphs).
#include "platform.h"
#include "audio.h"
#include "canvas.h"
#include "vita_sys.h"
#include <psp2/kernel/processmgr.h>
#include <psp2/kernel/threadmgr.h>
#include <psp2/ctrl.h>
#include <psp2/touch.h>
#include <psp2/power.h>
#include <psp2/display.h>
#include <psp2/io/stat.h>
#include <psp2/audioout.h>
#include <vita2d.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>

extern "C" {
int _newlib_heap_size_user = 192 * 1024 * 1024;
unsigned int sceUserMainThreadStackSize = 1 * 1024 * 1024;
// vita2d references the shared-framebuffer API (only used as a system overlay); these satisfy the linker
int sceSharedFbOpen(int index) { (void)index; return -1; }
int sceSharedFbClose(int fb) { (void)fb; return 0; }
int sceSharedFbBegin(int fb, void *info) { (void)fb; (void)info; return -1; }
int sceSharedFbEnd(int fb) { (void)fb; return 0; }
int sceSharedFbGetInfo(int fb, void *info) { (void)fb; (void)info; return -1; }
}

static vita2d_texture *g_font = nullptr;

// ---- drawing
void plat_tris(const float *p, const uint32_t *c, int n, float ox, float oy, float k) {
  n -= n % 3; if (n <= 0) return;
  vita2d_color_vertex *v = (vita2d_color_vertex *)vita2d_pool_memalign(n * sizeof(vita2d_color_vertex), sizeof(vita2d_color_vertex));
  if (!v) return;   // the frame's vertex pool is full: skip rather than crash
  for (int i = 0; i < n; i++) { v[i].x = p[i * 2] * k + ox; v[i].y = p[i * 2 + 1] * k + oy; v[i].z = .5f; v[i].color = c[i]; }
  vita2d_draw_array(SCE_GXM_PRIMITIVE_TRIANGLES, v, n);
}
void plat_glyphs(const float *g, int n, uint32_t col, float ox, float oy, float k) {
  if (!g_font) return;
  for (int i = 0; i < n; i++, g += 7)
    vita2d_draw_texture_tint_part_scale(g_font, g[0] * k + ox, g[1] * k + oy, g[2], g[3], g[4], g[5], g[6] * k, g[6] * k, col);
}

bool plat_gpu3d() { return false; }
void plat_draw3d(const float *, const V3c *, int, int) {}

// ---- lifecycle
bool plat_init() {
  vita_sys_init();
  vita2d_init_advanced(8 * 1024 * 1024);
  vita2d_set_clear_color(RGBA8(11, 18, 32, 255));
  vita2d_set_vblank_wait(0);
  g_font = vita2d_load_PNG_file("app0:font.png");
  if (g_font) vita2d_texture_set_filters(g_font, SCE_GXM_TEXTURE_FILTER_LINEAR, SCE_GXM_TEXTURE_FILTER_LINEAR);
  return true;
}
void plat_shutdown() {
  vita_sys_fini();
  vita2d_wait_rendering_done();
  if (g_font) vita2d_free_texture(g_font);
  vita2d_fini();
  sceKernelExitProcess(0);
}
void plat_begin_frame(uint32_t clear) { vita2d_set_clear_color(clear); vita2d_start_drawing(); vita2d_clear_screen(); }
void plat_end_frame() { vita2d_end_drawing(); vita_pace(); vita2d_swap_buffers(); vita_paced(); }

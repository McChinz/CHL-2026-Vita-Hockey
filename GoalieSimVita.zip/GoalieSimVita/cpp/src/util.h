// CHL 2026 native - small shared helpers: math, random numbers, colours, cache keys, text formatting
#pragma once
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <cctype>

constexpr double PI = 3.14159265358979323846;

inline double clamp(double v, double a, double b) { return std::max(a, std::min(b, v)); }
inline double hyp(double x, double y) { return std::sqrt(x * x + y * y); }
inline double sgn(double v) { return v > 0 ? 1 : v < 0 ? -1 : 0; }
// -PI..PI without a loop (a bad angle comes back as 0 instead of spinning forever)
inline double wrapA(double a) { if (!std::isfinite(a)) return 0; const double T = 2 * PI; return a - T * std::round(a / T); }

// ---- random numbers: one fast generator stands in for Math.random()
struct Rng {
  uint64_t s = 0x9E3779B97F4A7C15ull;
  double next() { s ^= s << 13; s ^= s >> 7; s ^= s << 17; return (double)(s >> 11) * (1.0 / 9007199254740992.0); }
};
extern Rng g_rng;
inline double rnd() { return g_rng.next(); }
inline double rand(double a, double b) { return a + rnd() * (b - a); }
inline int rint(int a, int b) { return a + (int)std::floor(rnd() * (b - a + 1)); }
// the deterministic one the web build uses for crowds and fixed layouts (same sequence)
struct SkRng {
  int32_t s;
  explicit SkRng(int seed) : s(seed) {}
  double operator()() { s = (int32_t)(((int64_t)s * 1103515245 + 12345) & 0x7fffffff); return s / (double)0x7fffffff; }
};
// the same string hash as the web build (player looks, numbers, handedness all hang off it)
inline int skHash(const std::string &t) {
  int32_t h = 7;
  for (unsigned char c : t) h = (int32_t)((uint32_t)h * 31u + c);
  return h < 0 ? (h == INT32_MIN ? INT32_MAX : -h) : h;
}
inline int poisson(double l) { double e = std::exp(-l); int k = 0; double p = 1; do { k++; p *= rnd(); } while (p > e && k < 60); return k - 1; }

// ---- colours (straight alpha, 0..255 channels, 0..1 alpha)
struct Col {
  float r = 0, g = 0, b = 0, a = 1;
  Col() {}
  Col(float r_, float g_, float b_, float a_ = 1) : r(r_), g(g_), b(b_), a(a_) {}
  uint32_t pack(float alpha = 1) const {   // ABGR, the layout vita2d wants
    float A = std::max(0.f, std::min(1.f, a * alpha));
    return ((uint32_t)(A * 255 + .5f) << 24) | ((uint32_t)b & 255) << 16 | ((uint32_t)g & 255) << 8 | ((uint32_t)r & 255);
  }
  uint32_t key() const { return pack(); }
  bool operator==(const Col &o) const { return r == o.r && g == o.g && b == o.b && a == o.a; }
  bool operator!=(const Col &o) const { return !(*this == o); }
};
inline int hexv(char c) { return c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : 0; }
// "#rgb", "#rrggbb", "#rrggbbaa", "rgba(r,g,b,a)", "rgb(r,g,b)"
inline Col hex(const char *s) {
  if (!s) return Col(255, 0, 255);
  if (s[0] == '#') {
    size_t n = strlen(s + 1);
    if (n == 3) return Col(hexv(s[1]) * 17, hexv(s[2]) * 17, hexv(s[3]) * 17);
    Col c(hexv(s[1]) * 16 + hexv(s[2]), hexv(s[3]) * 16 + hexv(s[4]), hexv(s[5]) * 16 + hexv(s[6]));
    if (n >= 8) c.a = (hexv(s[7]) * 16 + hexv(s[8])) / 255.f;
    return c;
  }
  if (!strncmp(s, "rgb", 3)) {
    const char *p = strchr(s, '('); float v[4] = {0, 0, 0, 1}; int k = 0;
    while (p && k < 4) { v[k++] = (float)atof(p + 1); p = strchr(p + 1, ','); }
    return Col((float)(int)v[0], (float)(int)v[1], (float)(int)v[2], v[3]);
  }
  if (!strcmp(s, "white")) return Col(255, 255, 255);
  if (!strcmp(s, "black")) return Col(0, 0, 0);
  return Col(255, 0, 255);
}
inline Col hex(const std::string &s) { return hex(s.c_str()); }
inline Col rgba(float r, float g, float b, float a) { return Col(r, g, b, a); }
inline Col withA(Col c, float a) { c.a = a; return c; }
// lighten (f > 0) toward white or darken (f < 0) toward black, like skShade
inline Col shade(Col c, double f) {
  float t = f < 0 ? 0 : 255, a = (float)std::fabs(f);
  return Col(std::round(c.r + (t - c.r) * a), std::round(c.g + (t - c.g) * a), std::round(c.b + (t - c.b) * a), c.a);
}
inline double lum(Col c) { return (c.r * .299 + c.g * .587 + c.b * .114) / 255.0; }
inline double colDist(Col a, Col b) { return std::sqrt((a.r - b.r) * (a.r - b.r) + (a.g - b.g) * (a.g - b.g) + (a.b - b.b) * (a.b - b.b)); }

// ---- cache keys: hashes mixed from whatever describes a drawing (replaces the web build's key strings)
struct Key {
  uint64_t h = 1469598103934665603ull;
  Key() {}
  explicit Key(const char *s) { add(s); }
  Key &add(uint64_t v) { for (int i = 0; i < 8; i++) { h ^= (v >> (i * 8)) & 255; h *= 1099511628211ull; } return *this; }
  Key &add(const char *s) { while (*s) { h ^= (unsigned char)*s++; h *= 1099511628211ull; } h ^= 0xff; h *= 1099511628211ull; return *this; }
  Key &add(const std::string &s) { return add(s.c_str()); }
  Key &add(double v) { int64_t q = (int64_t)std::llround(v * 10000.0); return add((uint64_t)q); }
  Key &add(float v) { return add((double)v); }
  Key &add(int v) { return add((uint64_t)(int64_t)v); }
  Key &add(bool v) { return add((uint64_t)(v ? 1 : 0)); }
  Key &add(Col c) { return add((uint64_t)c.key()); }
  template <class T> Key &operator<<(const T &v) { return add(v); }
};

// ---- text
inline std::string fmt(const char *f, ...) __attribute__((format(printf, 1, 2)));
#include <cstdarg>
inline std::string fmt(const char *f, ...) {
  char b[512]; va_list ap; va_start(ap, f); vsnprintf(b, sizeof b, f, ap); va_end(ap); return b;
}
// whole numbers to text (std::to_string is patchy on some embedded C libraries)
template <class T> inline std::string istr(T v) { char b[32]; snprintf(b, sizeof b, "%lld", (long long)v); return b; }
inline std::string upper(std::string s) { for (auto &c : s) if (c >= 'a' && c <= 'z') c -= 32; return s; }
inline std::string mmss(double t) { int s = (int)std::max(0.0, std::round(t)); return fmt("%02d:%02d", s / 60, s % 60); }
// ".912" style save percentage
inline std::string svp(double sv, double sa) {
  if (sa <= 0) return "-";
  std::string s = fmt("%.3f", sv / sa);
  if (s[0] == '0') s = s.substr(1);
  return s;
}
inline std::string pct(double a, double b) { return b > 0 ? fmt("%.1f%%", a / b * 100) : "-"; }
inline std::string lastWord(const std::string &s) { size_t i = s.rfind(' '); return i == std::string::npos ? s : s.substr(i + 1); }

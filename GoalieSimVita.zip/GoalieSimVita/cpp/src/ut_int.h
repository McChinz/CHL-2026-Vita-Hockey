// CHL 2026 native - Ultimate Franchise internals shared by ut.cpp (logic, saves) and ut_draw.cpp (screens).
#pragma once
#include "ut.h"
#include "data.h"

struct RarDef { const char *n; int b; const char *c, *d; int v; };
extern const RarDef RAR[7];
struct PackDef { const char *n; int c, k; const char *col; double w[7]; int g; double sk; int top; bool leg; };
extern const PackDef UT_PACKS[5];
struct OppDef { const char *n; int d, c; const char *col; };
extern const OppDef UT_OPP[3];
extern const char *UT_CITY[16], *UT_NICK[16], *UT_POS[3];
extern const char *CUP_RN[3];
constexpr int CUP_N = 20, UT_CAP0 = 24, UT_CAPSTEP = 2;

// a card's player before rarity: his traits, fixed per player
struct UBase { bool g = false; Src q; GSrc gs; Ratings rt; GS grt; };
const UBase &utBase(const std::string &k);
UCard *utCard(int u);
UCard *utCardIn(UTX &X, int u);
int utVal(const UCard &c);
Src *utSrc(const UCard &c);
GSrc *utGSrc(const UCard &c);
std::vector<PerkE> pkCard(const UCard &c);
double utPay(const UTX &X, const std::vector<int> *ro = nullptr);
double utCapCheck(UTX &X);
int utCapCost(const UTX &X);
std::string utSlotName(int i);
std::vector<UCard *> utDupesOf(const UCard &c);
std::vector<UCard *> utList();
int cupLockOv(const std::vector<ULock> &L);
bool cupOppPick(UTX &X, UOpp &o);
int cupPts(const CupTeam &t);
std::vector<int> cupStand(const Cup &C2, int div);
void cupNew(UTX &X);
void utAuto(UTX &X);
int utOppOv(const UOpp &o);
void utGenOpp(UTX &X);
void utBuy(int t);
void utOpenPack(int t, bool free);
void utInvOpen(int t);
void utAskUp(int u, double x, double y, double w);
void utSellOne(int u);
void utSellDupes();
void utBuyCap(UTX &X);
bool utAssign(int si, int u);
std::pair<std::string, std::string> utOddsTxt(const PackDef &pk);
void utFlash(const std::string &s);
bool utPickSet(const UOpp &o);
void utNameStart(int i);

// screen state
struct UOpenCard { UCard c; bool isNew; };
struct UOpen { int t = 0; std::vector<UOpenCard> cards; double t0 = 0; bool all = false, free = false, done = false; };
extern bool utOpenOn; extern UOpen utOpen;
struct UMenu { int u = 0; double x = 0, y = 0, w = 0; bool slot = false; int si = 0; };
extern bool utMenuOnF; extern UMenu utMenu;
struct UEx { UCard c; int u = 0; double fx = 0, fy = 0, fw = 0, t0 = 0; bool closing = false; std::string focus; };
extern bool utExOnF; extern UEx utEx;
extern int utSel, utPage, utSwap; extern bool utSell, utSwapFocus;
void utExOpen(int u, double x, double y, double w);
void utExClose();

// CHL 2026 native - room for vita-elf-create. It appends the module's SCE data (module info, imports, a few KB) right
// after the code segment, and the data segment starts at the next 64 KB boundary: if the code happens to end just
// short of a boundary there's no room and the build fails ("segment 1 overlaps"). The build links once to measure
// (this pad at 4 bytes), and if the room is short, links again with this pad grown just past the boundary
// (tools/sce_pad.cmake writes the size). Read-only data, so it sits in the code segment; nothing uses it.
#ifndef SCE_PAD_BYTES
#define SCE_PAD_BYTES 4
#endif
extern "C" { __attribute__((used)) const volatile unsigned char g_scePad[SCE_PAD_BYTES] = {1}; }

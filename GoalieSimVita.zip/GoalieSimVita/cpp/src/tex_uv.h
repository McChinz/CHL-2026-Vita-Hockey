// made by tools/make_textures.py - do not edit: where each picture sits in its atlas (u0, v0, u1, v1)
#pragma once
struct TexR { float u0, v0, u1, v1; };
static const TexR TP_BLOCKER = {0.585938f, 0.146484f, 0.710938f, 0.333984f};
static const TexR TP_CAGE = {0.724609f, 0.380859f, 0.849609f, 0.505859f};
static const TexR TP_CREST0 = {0.007812f, 0.273438f, 0.132812f, 0.398438f};
static const TexR TP_CREST1 = {0.146484f, 0.273438f, 0.271484f, 0.398438f};
static const TexR TP_DIGITS = {0.007812f, 0.521484f, 0.789062f, 0.619141f};
static const TexR TP_FABRIC = {0.058594f, 0.007812f, 0.308594f, 0.257812f};
static const TexR TP_FACE = {0.585938f, 0.380859f, 0.710938f, 0.505859f};
static const TexR TP_GLOVE = {0.849609f, 0.007812f, 0.912109f, 0.070312f};
static const TexR TP_HEAD = {0.007812f, 0.787109f, 0.476562f, 0.982422f};
static const TexR TP_HELM2 = {0.748047f, 0.787109f, 0.982422f, 0.982422f};
static const TexR TP_HELMET = {0.585938f, 0.007812f, 0.835938f, 0.132812f};
static const TexR TP_LETTERS = {0.007812f, 0.634766f, 0.682617f, 0.771484f};
static const TexR TP_MASK = {0.490234f, 0.787109f, 0.734375f, 0.982422f};
static const TexR TP_PAD = {0.322266f, 0.007812f, 0.572266f, 0.507812f};
static const TexR TP_TRAPPER = {0.724609f, 0.146484f, 0.912109f, 0.365234f};
static const TexR TP_WHITE = {0.019531f, 0.019531f, 0.027344f, 0.027344f};
static const TexR TA_ADS = {0.007812f, 0.404297f, 0.500000f, 0.486328f};
static const TexR TA_CROWD = {0.007812f, 0.058594f, 0.507812f, 0.246094f};
static const TexR TA_ICEADS = {0.007812f, 0.500000f, 0.445312f, 0.750000f};
static const TexR TA_LOGO = {0.527344f, 0.322266f, 0.777344f, 0.572266f};
static const TexR TA_RIBBON = {0.007812f, 0.367188f, 0.507812f, 0.390625f};
static const TexR TA_SCRATCH = {0.527344f, 0.058594f, 0.777344f, 0.308594f};
static const TexR TA_UPPER = {0.007812f, 0.259766f, 0.507812f, 0.353516f};
static const TexR TA_WHITE = {0.019531f, 0.019531f, 0.027344f, 0.027344f};

// CHL 2026 native - the in-game HUD (broadcast score bug, banners, power play, stamina, perks, hints, the event
// feed) and the matchup screen before the opening skate.
#include "game.h"
#include "sk_int.h"
#include "ut.h"

static std::string abbr(const std::string &n) { std::string o; for (char c : n) if (isalpha((unsigned char)c)) o += (char)toupper(c); return o.size() > 3 ? o.substr(0, 3) : o.empty() ? "---" : o; }
static void pkBadge(int id, int t, double bx, double by, double r) {
  const PerkDef &q = PERKS[id];
  ctx.fill(rgba(2, 6, 23, .8)); ctx.disc(bx, by, r * 1.28);
  ctx.fill(TIERC[t]); ctx.disc(bx, by, r * 1.16);
  ctx.fill(q.col); ctx.disc(bx, by, r * .92);
  ctx.fill("#0b1220"); ctx.textMid(); double px = r * .9; ctx.font(px); double w = ctx.measure(q.ab); if (w > r * 1.5) ctx.font(px * r * 1.5 / w); ctx.fillText(q.ab, bx, by + 1);
}
static int pkLeftAny(const Skater *p, int id) { return pkLeftS(p, id); }

void skHUD(const Layout &lay) {
  (void)lay;
  Team &T0 = SK->T[0], &T1 = SK->T[1];
  int tl = (int)std::ceil(SK->clock); std::string ts = fmt("%d:%02d", tl / 60, tl % 60), pl = SK->per > 3 ? "OT" : SK->per == 1 ? "1ST" : SK->per == 2 ? "2ND" : "3RD";
  double bx = 8, by = safeTop + 6, lw = .095 * U, tw = .165 * U, cw = .13 * U, h1 = .06 * U, h2 = .034 * U, h3 = .026 * U, bw = lw + 2 * tw + cw, bh = h1 + h2 + h3;
  std::string sv0 = svp(T1.sog - T1.score, T1.sog), sv1 = svp(T0.sog - T0.score, T0.sog);
  cached(Key("skbug2") << T0.score << T1.score << T0.sog << T1.sog << pl << safeTop << U << T0.col << T1.col << T0.name << T1.name << sv0 << sv1, [&] {
    ctx.baseline(BL_MIDDLE);
    ctx.fill("#f8fafc"); ctx.fillRect(bx, by, lw, bh);
    ctx.align(AL_CENTER); ctx.font(.038 * U); ctx.fill("#c8102e"); ctx.fillText("CHL", bx + lw / 2, by + bh * .42);
    ctx.font(.016 * U); ctx.fill("#0b1d3a"); ctx.fillText("2026", bx + lw / 2, by + bh * .78);
    auto cell = [&](double x, int ti, int sc) { Col col = SK->T[ti].col; bool lt = lum(col) > .62; ctx.fill(col); ctx.fillRect(x, by, tw, h1);
      ctx.fill(rgba(0, 0, 0, .18)); ctx.fillRect(x + tw * .62, by, tw * .38, h1);
      ctx.align(AL_LEFT); ctx.font(.03 * U); ctx.fill(lt ? hex("#0b1d3a") : hex("#ffffff")); ctx.fillText(abbr(SK->T[ti].name), x + .012 * U, by + h1 / 2);
      ctx.align(AL_CENTER); ctx.font(.042 * U); ctx.fillText(istr(sc), x + tw * .81, by + h1 / 2); };
    cell(bx + lw, 0, T0.score); cell(bx + lw + tw, 1, T1.score);
    ctx.fill("#f8fafc"); ctx.fillRect(bx + lw + 2 * tw, by, cw, h1);
    double x0 = bx + lw, y2 = by + h1;
    ctx.fill("#f1f5f9"); ctx.fillRect(x0, y2, 2 * tw + cw, h2);
    ctx.font(.022 * U); ctx.fill("#0b1d3a"); ctx.fillText(istr(T0.sog), x0 + tw * .25, y2 + h2 / 2); ctx.fillText(istr(T1.sog), x0 + tw * 1.75, y2 + h2 / 2);
    ctx.font(.018 * U); ctx.fill("#334155"); ctx.fillText("SHOTS", x0 + tw, y2 + h2 / 2);
    ctx.font(.02 * U); ctx.fill("#0b1d3a"); ctx.fillText(pl, x0 + 2 * tw + cw / 2, y2 + h2 / 2);
    double y3 = y2 + h2;
    ctx.fill("#cbd5e1"); ctx.fillRect(x0, y3, 2 * tw + cw, h3);
    ctx.font(.0175 * U); ctx.fill("#0b1d3a"); ctx.fillText(sv0, x0 + tw * .25, y3 + h3 / 2); ctx.fillText(sv1, x0 + tw * 1.75, y3 + h3 / 2);
    ctx.font(.0155 * U); ctx.fill("#334155"); ctx.fillText("SV%", x0 + tw, y3 + h3 / 2);
    ctx.fill(rgba(15, 23, 42, .35)); ctx.fillRect(x0, y2, 2 * tw + cw, 1); ctx.fillRect(x0, y3, 2 * tw + cw, 1);
  });
  cached(Key("skclk") << ts << safeTop << U, [&] { ctx.textMid(); ctx.font(.034 * U); ctx.fill("#0b1d3a"); ctx.fillText(ts, bx + lw + 2 * tw + cw / 2, by + h1 / 2); });
  SK->bugB = {bx, by, bw, bh};
  { std::string t = fmt("YOU  G %d  A %d  SOG %d  HITS %d", SK->me.g, SK->me.a, SK->me.sog, SK->me.hits);
    cached(Key("skme") << t << safeTop << U, [&] { ctx.font(.019 * U); double w = ctx.measure(t) + .03 * U; ctx.fill(rgba(8, 12, 24, .7)); ctx.rr(bx, by + bh + 4, w, .034 * U, .008 * U); ctx.fillPath();
      ctx.textMid(AL_LEFT); ctx.fill("#ffd54a"); ctx.fillText(t, bx + .015 * U, by + bh + 4 + .017 * U); }); }
  // banner
  if (SK->banner.t > 0) {
    ctx.alpha(std::ceil(std::min(1.0, SK->banner.t * 2) * 5) / 5);
    double yb = SK->phase == PH_GOAL ? H * .74 : H * .5; Banner &B = SK->banner;
    ctx.save(); ctx.translate(std::round(W / 2), std::round(yb));
    cached(Key("skbn") << B.txt << B.col << B.sub << U, [&] { ctx.textMid();
      double px = .1 * U; ctx.font(px); double w = ctx.measure(B.txt); if (w > W * .94) ctx.font(px * W * .94 / w);
      ctx.lineWidth(.012 * U); ctx.stroke(rgba(0, 0, 0, .6)); ctx.strokeText(B.txt, 0, 0); ctx.fill(B.col); ctx.fillText(B.txt, 0, 0);
      if (!B.sub.empty()) { double p2 = .032 * U; ctx.font(p2); double sw = ctx.measure(B.sub); if (sw > W * .92) { p2 *= W * .92 / sw; ctx.font(p2); }
        double bw2 = std::min(W * .96, (double)ctx.measure(B.sub) + .04 * U); ctx.fill(rgba(8, 12, 24, .55)); ctx.rr(-bw2 / 2, .075 * U - .025 * U, bw2, .05 * U, .025 * U); ctx.fillPath(); ctx.fill("#fff"); ctx.fillText(B.sub, 0, .075 * U); } });
    ctx.restore(); ctx.alpha(1);
  }
  // power play / penalty kill / you in the box
  { auto &b0 = T0.box, &b1 = T1.box; const Box *inBox = nullptr; for (auto &b : b0) if (b.p == SK->user) inBox = &b;
    std::string txt; Col col = hex("#fff");
    if (inBox) { txt = (inBox->ob ? std::string("OVER THE BOARDS  ") : std::string("YOU ARE IN THE BOX  ")) + istr((int)std::ceil(inBox->t)) + "s"; col = hex("#ffb300"); }
    else if (b1.size() > b0.size()) { bool ko = false; for (auto &b : b1) if (b.ko) ko = true; txt = (ko ? std::string("3 ON 2  ") : std::string("POWER PLAY  ")) + istr((int)std::ceil(b1[0].t)) + "s"; col = hex("#7CFC9A"); }
    else if (b0.size() > b1.size()) { bool ko = false; for (auto &b : b0) if (b.ob) ko = true; txt = (ko ? std::string("MAN DOWN  ") : std::string("PENALTY KILL  ")) + istr((int)std::ceil(b0[0].t)) + "s"; col = hex("#ff7a7a"); }
    if (!txt.empty()) { double yy = SK->bugB.y + SK->bugB.h + 4 + .04 * U + .019 * U, bxx = SK->bugB.x;
      cached(Key("skpp") << txt << col << bxx << std::round(yy) << U, [&] { ctx.font(.022 * U); ctx.textMid(AL_LEFT);
        double tw2 = ctx.measure(txt) + .03 * U; ctx.fill(rgba(8, 12, 24, .8)); ctx.rr(bxx, yy - .018 * U, tw2, .036 * U, .008 * U); ctx.fillPath(); ctx.fill(col); ctx.fillText(txt, bxx + .015 * U, yy); }); } }
  // stamina bar along the bottom, your perks beside it
  { Skater *me = SK->user; double bw2 = std::min(W * .5, .9 * U), bh2 = .03 * U, bx2 = (W - bw2) / 2, by2 = H - bh2 - .035 * U, f = me->st / 100;
    double fq = std::round(clamp(f, 0, 1) * 60) / 60; Col col = me->tired ? hex("#ff5252") : me->sprint ? hex("#ff9800") : f < .25 ? hex("#ff5252") : hex("#38bdf8");
    std::string lab = skBenchOpen() ? "LOW ENERGY - SKATE TO THE GREEN CIRCLE TO CHANGE" : me->tired ? "EXHAUSTED - RECOVERING" : me->sprint ? "SPRINTING" : f < .12 ? "GASSED - NO CHECKS" : (QO.shotB && SK->puck.owner == me ? "STAMINA  HOLD X: SPRINT" : "STAMINA  R: SPRINT");
    cached(Key("skst") << fq << col << lab << W << H, [&] { ctx.fill(rgba(8, 12, 24, .8)); ctx.rr(bx2, by2, bw2, bh2, bh2 / 2); ctx.fillPath();
      ctx.fill(col); if (fq > 0) { ctx.rr(bx2, by2, std::max(bh2, bw2 * fq), bh2, bh2 / 2); ctx.fillPath(); }
      ctx.font(.0216 * U); ctx.textMid(AL_LEFT); ctx.fill("#fff"); ctx.fillText(lab, bx2 + bh2 * .6, by2 + bh2 / 2 + .5); });
    if (!me->pks.empty()) { Key key("skpkh"); for (auto &e : me->pks) key << e.id << e.t << pkLeftAny(me, e.id);
      cached(key << W << H, [&] { double cx = bx2 + bw2 + .03 * U, r = .017 * U, cy = by2 + bh2 / 2;
        ctx.font(.019 * U); double step = r * 2.4 + ctx.measure("x5") + .012 * U; ctx.fill(rgba(8, 12, 24, .8)); ctx.rr(cx - r * 1.6, cy - r * 1.5, step * me->pks.size() + r * .6, r * 3, r * 1.5); ctx.fillPath();
        for (auto &e : me->pks) { const PerkDef &q = PERKS[e.id]; int left = pkLeftAny(me, e.id); bool out = q.kind == PKK_USE && left <= 0; ctx.alpha(out ? .35 : 1); pkBadge(e.id, e.t, cx, cy, r);
          ctx.font(.019 * U); ctx.textMid(AL_LEFT); ctx.fill(out ? "#64748b" : "#fff"); ctx.fillText(q.kind == PKK_PAS ? "ON" : "x" + istr(left), cx + r * 1.45, cy + 1); ctx.alpha(1); cx += step; } }); }
    if (SK->xh.on && SK->xh.t > .22 && SK->puck.owner == me) { double wy = by2 - .05 * U, w = std::min(1.0, (SK->xh.t - .22) / .4);
      ctx.fill(rgba(8, 12, 24, .8)); ctx.rr(bx2 + bw2 * .25, wy, bw2 * .5, bh2, bh2 / 2); ctx.fillPath();
      ctx.fill("#93c5fd"); ctx.rr(bx2 + bw2 * .25, wy, std::max(bh2, bw2 * .5 * w), bh2, bh2 / 2); ctx.fillPath(); ctx.font(.0216 * U); ctx.textMid(); ctx.fill("#fff"); ctx.fillText("POWER PASS", W / 2, wy + bh2 / 2 + .5); } }
  if (SK->phase == PH_FACEOFF) { Faceoff &F = SK->fo; Skater *c0 = nullptr; for (Skater *q : T0.on) if (q->role == R_C) { c0 = q; break; } bool mine = c0 == SK->user && !g_autoplay;
    double ty = H - .2 * U; std::string msg = mine ? (F.t < F.show ? "FACE OFF - GET READY" : "PRESS X WHEN THE RING HITS THE DOT") : "FACE OFF";
    cached(Key("skfo") << msg << W << H, [&] { ctx.textMid(); ctx.font(.032 * U); ctx.fill(rgba(8, 12, 24, .75));
      double tw2 = ctx.measure(msg) + .04 * U; ctx.rr(W / 2 - tw2 / 2, ty - .03 * U, tw2, .06 * U, .03 * U); ctx.fillPath(); ctx.fill(mine ? "#ffd54a" : "#fff"); ctx.fillText(msg, W / 2, ty); }); }
  // controls hint early in the game
  if (skHint > SK_PER - 12) {
    ctx.alpha(.9);
    static const char *linesA[2] = {"RIGHT STICK: HOLD UP = WRIST, HOLD BACK = SLAP, SIDEWAYS AIMS, LET GO = SHOOT   SQUARE: DEKE (HOLD: TOE DRAG)   CIRCLE: BUMP (HOLD: HIT)", "X: PASS / CALL / POKE   HOLD L: PASS TO SQUARE / TRIANGLE / CIRCLE   R: SPRINT   L (NO PUCK): BLOCK   LEFT STICK 360: SPIN"};
    static const char *linesB[2] = {"RIGHT STICK: AIM   TAP R: WRIST SHOT   HOLD R: SLAP SHOT (LET GO TO FIRE)   SQUARE: DEKE (HOLD: TOE DRAG)   CIRCLE: BUMP (HOLD: HIT)", "X (PUCK): TAP = PASS, HOLD = SPRINT   X: CALL / POKE   R (NO PUCK): SPRINT   HOLD L: PASS TO SQUARE / TRIANGLE / CIRCLE   LEFT STICK 360: SPIN"};
    const char *const *lines = QO.shotB ? linesB : linesA;
    cached(Key("skhint") << lines[0] << W << H, [&] { ctx.textMid();
      for (int i = 0; i < 2; i++) { double yy = H - .135 * U + i * .035 * U; ctx.fill(rgba(8, 12, 24, .7)); ctx.fillRect(0, yy - .017 * U, W, .034 * U); ctx.fill("#fff");
        ctx.fitPx(lines[i], .024 * U, W - .04 * U); ctx.fillText(lines[i], W / 2, yy); } });
    ctx.alpha(1);
  }
  // the line that just came out
  if (SK->lineNote.t > 0) { auto &L = T0.lines[SK->lineNote.li]; double w = .27 * U, h = .045 * U + L.size() * .032 * U, x = W - w - .02 * U, y = H * .36;
    ctx.alpha(std::min(1.0, SK->lineNote.t * 2)); ctx.fill(rgba(8, 12, 24, .82)); ctx.rr(x, y, w, h, .012 * U); ctx.fillPath(); ctx.fill(hex("#f26b5b")); ctx.fillRect(x, y, .008 * U, h);
    tx("LINE " + istr(SK->lineNote.li + 1) + " OUT", x + .02 * U, y + .022 * U, .019, hex("#fff"));
    for (size_t i = 0; i < L.size(); i++) { TXL = x; TXR = x + w - .01 * U; tx(upper(L[i]->nm), x + .02 * U, y + .05 * U + i * .032 * U, .017, hex("#cbd5e1")); TXL = 0; TXR = 1e4; }
    ctx.alpha(1); }
  // event feed: newest at the bottom, older ones stacked above
  for (size_t i = 0; i < feed.size(); i++) { Feed &f = feed[i]; double a = f.t / 2.6, ty = H * .5 - (feed.size() - 1 - i) * .04 * U - a * .03 * U;
    f.y = f.y < 0 ? ty : f.y + (ty - f.y) * .3; double al = a < .15 ? a / .15 : a > .7 ? (1 - a) / .3 : 1;
    ctx.alpha(std::ceil(clamp(al, 0, 1) * 5) / 5); ctx.save(); ctx.translate(W - 10, std::round(f.y));
    cached(Key("skfd") << f.txt << f.col << U, [&] { ctx.textMid(AL_RIGHT); ctx.font(.028 * U); ctx.lineWidth(.007 * U); ctx.stroke(rgba(0, 0, 0, .7)); ctx.strokeText(f.txt, 0, 0); ctx.fill(f.col); ctx.fillText(f.txt, 0, 0); });
    ctx.restore(); }
  ctx.alpha(1);
}

// ---------------------------------------------------------------- the matchup screen
void skDrawPreview() {
  if (!SK->T[0].on.empty()) skWarm(skLayout(), 4);
  double t = SK->pv.t; auto e = [](double k) { return 1 - std::pow(1 - clamp(k, 0, 1), 3); }; double m = .03 * U;
  ctx.fill("#060a16"); ctx.fillRect(0, 0, W, H);
  Col ACC = hex("#f26b5b");
  tx("TONIGHT'S MATCHUP", W / 2, safeTop + .045 * U, .028, ACC, AL_CENTER); tx(SK->ut ? utPreviewSub() : std::string("QUICK PLAY"), W / 2, safeTop + .085 * U, .02, hex("#94a3b8"), AL_CENTER);
  double pw = (W - 2 * m - .12 * U) / 2, rh = std::min(.085 * U, (H - safeTop - .5 * U) / 4), ph = .29 * U + 4 * rh, top = std::max(safeTop + .12 * U, (H - ph) / 2);
  for (int i = 0; i < 2; i++) { PvTeam &o = SK->pv.T[i];
    double sl = (1 - e(t / .4)) * W * .5 * (i ? 1 : -1), x0 = m + i * (pw + .12 * U) + sl;
    ctx.fill(rgba(15, 23, 42, .95)); ctx.fillRect(x0, top, pw, ph);
    ctx.fill(o.col); ctx.fillRect(x0, top, pw, .15 * U); ctx.fill(o.stripe); ctx.fillRect(x0, top + .15 * U, pw, .006 * U);
    TXL = x0; TXR = x0 + pw - .02 * U;
    bool lt = lum(o.col) > .6; Col hc = lt ? hex("#0f172a") : hex("#fff");
    tx(upper(o.name), x0 + .025 * U, top + .06 * U, .045, lt ? hex("#0f172a") : (lum(o.stripe) > .25 ? o.stripe : hex("#fff")), AL_LEFT, true);
    tx(o.recL + "  " + o.rec, x0 + .025 * U, top + .115 * U, .024, hc);
    tx("STARTING LINEUP", x0 + .025 * U, top + .2 * U, .019, hex("#94a3b8"));
    for (size_t k = 0; k < o.sk.size(); k++) { auto &q = o.sk[k]; double y = top + .26 * U + k * rh + rh / 2 - .03 * U;
      ctx.fill(k % 2 ? rgba(30, 41, 59, .5) : rgba(30, 41, 59, .85)); ctx.fillRect(x0 + .015 * U, y - rh * .45, pw - .03 * U, rh * .9);
      tx(q.pos, x0 + .03 * U, y, .02, hex("#7aa7ff")); TXR = x0 + pw * .7; tx(upper(q.nm), x0 + .1 * U, y, .024, hex("#fff")); TXR = x0 + pw - .02 * U;
      for (size_t j = 0; j < q.pk.size(); j++) pkBadge(q.pk[j].id, q.pk[j].t, x0 + pw * .72 + .016 * U + j * .016 * U * 2.6, y, .016 * U);
      tx(istr(q.g) + " G", x0 + pw - .03 * U, y, .024, hex("#fbbf24"), AL_RIGHT); }
    if (o.hasG) { double y = top + .26 * U + 3 * rh + rh / 2 - .03 * U; ctx.fill(rgba(30, 41, 59, .85)); ctx.fillRect(x0 + .015 * U, y - rh * .45, pw - .03 * U, rh * .9);
      tx("G", x0 + .03 * U, y, .02, hex("#93c5fd")); TXR = x0 + pw * .5; tx(upper(o.gk.nm), x0 + .1 * U, y, .024, hex("#fff")); TXR = x0 + pw - .02 * U;
      for (size_t j = 0; j < o.gk.pk.size(); j++) pkBadge(o.gk.pk[j].id, o.gk.pk[j].t, x0 + pw * .52 + .016 * U + j * .016 * U * 2.6, y, .016 * U);
      tx(o.gsv + "  |  " + o.gsub, x0 + pw - .03 * U, y, .021, hex("#7CFC9A"), AL_RIGHT); }
    TXL = 0; TXR = 1e4;
  }
  ctx.alpha(e((t - .25) / .3)); tx("VS", W / 2, top + ph * .45, .06, hex("#fff"), AL_CENTER, true); ctx.alpha(1);
  if (t > .7) tx("X: CONTINUE", W / 2, H - .05 * U, .022, hex("#94a3b8"), AL_CENTER);
}

// CHL 2026 native - the drawing context (see canvas.h). A line-for-line port of vita_shim.js.
#include "canvas.h"
#include "font_metrics.h"

Rng g_rng;

Col Grad::at(float x, float y) const {
  float t;
  if (kind == 0) { float dx = a[2] - a[0], dy = a[3] - a[1], L = dx * dx + dy * dy; if (L == 0) L = 1; t = ((x - a[0]) * dx + (y - a[1]) * dy) / L; }
  else { float d = std::sqrt((x - a[3]) * (x - a[3]) + (y - a[4]) * (y - a[4])), den = a[5] - a[2]; t = (d - a[2]) / (den != 0 ? den : 1); }
  if (stops.empty()) return Col(0, 0, 0, 0);
  if (t <= stops[0].o) return stops[0].c;
  for (size_t i = 1; i < stops.size(); i++) if (t <= stops[i].o) {
    const Stop &p = stops[i - 1], &q = stops[i]; float den = q.o - p.o, f = (t - p.o) / (den != 0 ? den : 1);
    return Col(p.c.r + (q.c.r - p.c.r) * f, p.c.g + (q.c.g - p.c.g) * f, p.c.b + (q.c.b - p.c.b) * f, p.c.a + (q.c.a - p.c.a) * f);
  }
  return stops.back().c;
}

uint32_t Canvas::colorAt(const Style &st, float x, float y, float alpha) const {
  if (st.isG) { Col c = st.g.at(x, y); c.r = (float)(int)c.r; c.g = (float)(int)c.g; c.b = (float)(int)c.b; return c.pack(alpha); }
  return st.c.pack(alpha);
}

static int segsFor(float r, double sweep) { int n = (int)std::ceil(std::fabs(sweep) * std::max(1.0f, r) / 13); return n < 5 ? 5 : n > 30 ? 30 : n; }
static double normSweep(double a0, double a1, bool ccw) {
  const double T = PI * 2; double sw = a1 - a0;
  if (!std::isfinite(sw)) return 0;
  if (!ccw) { if (sw >= T) sw = T; else if (sw < 0) sw -= T * std::floor(sw / T); }
  else { if (sw <= -T) sw = -T; else if (sw > 0) sw -= T * std::ceil(sw / T); }
  return sw;
}
void Canvas::ellipsePts(double x, double y, double rx, double ry, double rot, double a0, double a1, bool ccw) {
  double sw = normSweep(a0, a1, ccw); int n = segsFor((float)(std::max(rx, ry) * scaleOf()), sw);
  double cr = std::cos(rot), sr = std::sin(rot);
  for (int i = 0; i <= n; i++) { double t = a0 + sw * i / n, px = rx * std::cos(t), py = ry * std::sin(t); addPt(x + px * cr - py * sr, y + px * sr + py * cr); }
}
void Canvas::arcTo(double x1, double y1, double x2, double y2, double r) {
  if (cur < 0) newSub(x1, y1);
  double x0 = lastX, y0 = lastY, v1x = x0 - x1, v1y = y0 - y1, v2x = x2 - x1, v2y = y2 - y1;
  double l1 = hyp(v1x, v1y), l2 = hyp(v2x, v2y);
  if (l1 < 1e-6 || l2 < 1e-6 || r <= 0) { addPt(x1, y1); return; }
  v1x /= l1; v1y /= l1; v2x /= l2; v2y /= l2;
  double cross = v1x * v2y - v1y * v2x, dot = v1x * v2x + v1y * v2y;
  if (std::fabs(cross) < 1e-6) { addPt(x1, y1); return; }
  double th = std::acos(clamp(dot, -1, 1)), d = r / std::tan(th / 2);
  double t1x = x1 + v1x * d, t1y = y1 + v1y * d, t2x = x1 + v2x * d, t2y = y1 + v2y * d;
  double bx = v1x + v2x, by = v1y + v2y, bl = hyp(bx, by), h = r / std::sin(th / 2);
  double cx = x1 + bx / bl * h, cy = y1 + by / bl * h;
  addPt(t1x, t1y);
  ellipsePts(cx, cy, r, r, 0, std::atan2(t1y - cy, t1x - cx), std::atan2(t2y - cy, t2x - cx), cross > 0);
}
void Canvas::rr(double x, double y, double w, double h, double r) {
  r = std::min(r, std::min(w / 2, h / 2)); double a = r * .29, b = r * .04;
  beginPath();
  moveTo(x + r, y); lineTo(x + w - r, y); lineTo(x + w - a, y + b); lineTo(x + w - b, y + a); lineTo(x + w, y + r); lineTo(x + w, y + h - r); lineTo(x + w - b, y + h - a); lineTo(x + w - a, y + h - b); lineTo(x + w - r, y + h);
  lineTo(x + r, y + h); lineTo(x + a, y + h - b); lineTo(x + b, y + h - a); lineTo(x, y + h - r); lineTo(x, y + r); lineTo(x + b, y + a); lineTo(x + a, y + b); closePath();
}

void Canvas::fillSubs(const Style &st) {
  float ga = S.alpha; bool isG = st.isG; uint32_t cc = isG ? 0 : colorAt(st, 0, 0, ga);
  const float A = S.a, B = S.b, Cm = S.c, D = S.d, E = S.e, Fm = S.f;
  for (const Sub &sb : subs) {
    int n = sb.n; if (n < 3) continue; const float *u = &pts[sb.s];
    float cx = 0, cy = 0; for (int i = 0; i < n; i++) { cx += u[i * 2]; cy += u[i * 2 + 1]; } cx /= n; cy /= n;
    float Cx = A * cx + Cm * cy + E, Cy = B * cx + D * cy + Fm; uint32_t Cc = isG ? colorAt(st, cx, cy, ga) : cc;
    float ux = u[(n - 1) * 2], uy = u[(n - 1) * 2 + 1];
    float px = A * ux + Cm * uy + E, py = B * ux + D * uy + Fm; uint32_t pc = isG ? colorAt(st, ux, uy, ga) : cc;
    for (int j = 0; j < n; j++) {
      ux = u[j * 2]; uy = u[j * 2 + 1];
      float qx = A * ux + Cm * uy + E, qy = B * ux + D * uy + Fm; uint32_t qc = isG ? colorAt(st, ux, uy, ga) : cc;
      tri(Cx, Cy, Cc, px, py, pc, qx, qy, qc);
      px = qx; py = qy; pc = qc;
    }
  }
}
void Canvas::discTri(float x, float y, float r, uint32_t c) {
  int n = std::max(8, std::min(24, (int)std::ceil(r))); float px = x + r, py = y;
  for (int i = 1; i <= n; i++) { float t = i / (float)n * (float)PI * 2, qx = x + r * std::cos(t), qy = y + r * std::sin(t); tri(x, y, c, px, py, c, qx, qy, c); px = qx; py = qy; }
}
void Canvas::strokeSubs(const Style &st) {
  float ga = S.alpha; uint32_t c = st.isG ? Col(255, 255, 255).pack(ga) : colorAt(st, 0, 0, ga);
  float hw = std::max(.5f, S.lw * scaleOf() / 2); bool round = S.cap == CAP_ROUND;
  const float A = S.a, B = S.b, Cm = S.c, D = S.d, E = S.e, Fm = S.f;
  for (const Sub &sb : subs) {
    int n = sb.n; if (n < 2) continue; const float *u = &pts[sb.s];
    bool closedFlag = sb.closed; int segN = closedFlag ? n : n - 1;
    float fx = A * u[0] + Cm * u[1] + E, fy = B * u[0] + D * u[1] + Fm;
    float lx = A * u[(n - 1) * 2] + Cm * u[(n - 1) * 2 + 1] + E, ly = B * u[(n - 1) * 2] + D * u[(n - 1) * 2 + 1] + Fm;
    bool closed = closedFlag || (n > 2 && std::fabs(fx - lx) + std::fabs(fy - ly) < .7f);
    float ax = fx, ay = fy;
    for (int k = 0; k < segN; k++) {
      int j = (k + 1) % n; float bx = A * u[j * 2] + Cm * u[j * 2 + 1] + E, by = B * u[j * 2] + D * u[j * 2 + 1] + Fm;
      float dx = bx - ax, dy = by - ay, L = std::sqrt(dx * dx + dy * dy);
      if (L > 1e-4f) {
        float nx = -dy / L * hw, ny = dx / L * hw, ex = dx / L * hw * .5f, ey = dy / L * hw * .5f;
        float sx = (k > 0 || closed) ? ax - ex : ax, sy = (k > 0 || closed) ? ay - ey : ay, tx = bx + ex, ty = by + ey;
        tri(sx + nx, sy + ny, c, tx + nx, ty + ny, c, tx - nx, ty - ny, c);
        tri(sx + nx, sy + ny, c, tx - nx, ty - ny, c, sx - nx, sy - ny, c);
      }
      ax = bx; ay = by;
    }
    if (round && !closed) { discTri(fx, fy, hw, c); discTri(ax, ay, hw, c); }
  }
}
void Canvas::fillRect(double x, double y, double w, double h) {
  const Style &st = S.fill; float ga = S.alpha; bool isG = st.isG;
  uint32_t c0 = colorAt(st, x, y, ga), c1 = isG ? colorAt(st, x + w, y, ga) : c0, c2 = isG ? colorAt(st, x + w, y + h, ga) : c0, c3 = isG ? colorAt(st, x, y + h, ga) : c0;
  auto T = [&](double px, double py, float &ox, float &oy) { ox = S.a * px + S.c * py + S.e; oy = S.b * px + S.d * py + S.f; };
  float x0, y0, x1, y1, x2, y2, x3, y3; T(x, y, x0, y0); T(x + w, y, x1, y1); T(x + w, y + h, x2, y2); T(x, y + h, x3, y3);
  tri(x0, y0, c0, x1, y1, c1, x2, y2, c2); tri(x0, y0, c0, x2, y2, c2, x3, y3, c3);
}
void Canvas::strokeRect(double x, double y, double w, double h) {
  auto sp = pts; auto ss = subs; int sc = cur;
  beginPath(); rect(x, y, w, h); strokePath();
  pts = sp; subs = ss; cur = sc;
}

// ---- text
static const fontm::G *glyphOf(uint32_t cp) {
  static const fontm::G *tab[128] = {nullptr}; static bool init = false;
  if (!init) { for (int i = 0; i < fontm::NGLYPHS; i++) if (fontm::GLYPHS[i].cp < 128) tab[fontm::GLYPHS[i].cp] = &fontm::GLYPHS[i]; init = true; }
  if (cp < 128 && tab[cp]) return tab[cp];
  for (int i = 0; i < fontm::NGLYPHS; i++) if ((uint32_t)fontm::GLYPHS[i].cp == cp) return &fontm::GLYPHS[i];
  return tab['?'];
}
static uint32_t nextCp(const std::string &s, size_t &i) {   // UTF-8
  unsigned char c = s[i++]; if (c < 0x80) return c;
  int n = c >= 0xF0 ? 3 : c >= 0xE0 ? 2 : 1; uint32_t cp = c & (0x3F >> n);
  while (n-- && i < s.size()) cp = (cp << 6) | (s[i++] & 0x3F);
  return cp;
}
float Canvas::measurePx(const std::string &t, float px) const {
  float w = 0; for (size_t i = 0; i < t.size();) w += glyphOf(nextCp(t, i))->adv; return w * px / fontm::SIZE;
}
void Canvas::drawText(const std::string &str, float x, float y, const Style &st, const float (*offs)[2], int no) {
  if (str.empty()) return;
  flush();
  float px = S.px, w = measurePx(str, px);
  if (S.align == AL_CENTER) x -= w / 2; else if (S.align == AL_RIGHT) x -= w;
  float k = px / fontm::SIZE;
  if (S.base == BL_MIDDLE) y += (fontm::ASC - fontm::DESC) / 2 * k; else if (S.base == BL_TOP) y += fontm::ASC * k; else if (S.base == BL_BOTTOM) y -= fontm::DESC * k;
  float pX = S.a * x + S.c * y + S.e, pY = S.b * x + S.d * y + S.f, sc = std::sqrt(S.a * S.a + S.b * S.b); if (sc == 0) sc = 1;
  float gs = k * sc;
  uint32_t col = st.isG ? Col(255, 255, 255).pack(S.alpha) : colorAt(st, 0, 0, S.alpha);
  static const float zero[1][2] = {{0, 0}};
  if (!offs) { offs = zero; no = 1; }
  static float GB[7 * 256];
  for (int q = 0; q < no; q++) {
    float pen = pX + offs[q][0]; int n = 0;
    for (size_t i = 0; i < str.size();) {
      uint32_t cp = nextCp(str, i); const fontm::G *g = glyphOf(cp);
      if (cp != ' ') {
        if (n >= 256) { glyphOut(GB, n, col); n = 0; }
        float *o = GB + n * 7; o[0] = pen + g->ox * gs; o[1] = pY + offs[q][1] + g->oy * gs; o[2] = g->x; o[3] = g->y; o[4] = g->w; o[5] = g->h; o[6] = gs; n++;
      }
      pen += g->adv * gs;
    }
    if (n) glyphOut(GB, n, col);
  }
}
void Canvas::strokeText(const std::string &t, double x, double y) {
  float r = std::max(1.f, S.lw / 2), d = r * .7071f;
  const float o[4][2] = {{-r, -d * .6f}, {r, -d * .6f}, {-r * .8f, d}, {r * .8f, d}};
  drawText(t, (float)x, (float)y, S.stroke, o, 4);
}

// ---- batches and the cache
void Canvas::flush() {
  if (!vn) return;
  if (rec) {
    Cmd *L = rec->empty() ? nullptr : &rec->back();
    if (L && L->t == 0 && L->n + vn <= MAXV) {
      L->p.insert(L->p.end(), VP.begin(), VP.begin() + vn * 2); L->c.insert(L->c.end(), VC.begin(), VC.begin() + vn); L->n += vn;
    } else {
      Cmd c; c.t = 0; c.p.assign(VP.begin(), VP.begin() + vn * 2); c.c.assign(VC.begin(), VC.begin() + vn); c.n = vn; c.col = 0; rec->push_back(std::move(c));
    }
  }
  if (!recQuiet) plat_tris(VP.data(), VC.data(), vn, 0, 0, 1);
  vn = 0;
}
void Canvas::glyphOut(const float *buf, int n, uint32_t col) {
  if (rec) {
    Cmd *L = rec->empty() ? nullptr : &rec->back();
    if (L && L->t == 1 && L->col == col) { L->p.insert(L->p.end(), buf, buf + n * 7); L->n += n; }
    else { Cmd c; c.t = 1; c.p.assign(buf, buf + n * 7); c.n = n; c.col = col; rec->push_back(std::move(c)); }
  }
  if (!recQuiet) plat_glyphs(buf, n, col, 0, 0, 1);
}
uint64_t Canvas::fullKey(const Key &k) const { Key q = k; q << S.a << S.b << S.c << S.d << S.alpha; return q.h; }
void Canvas::replay(const Block &b, float k) {
  float dx = S.e - b.e * k, dy = S.f - b.f * k;
  for (const Cmd &m : b.cmds) { if (m.t) plat_glyphs(m.p.data(), m.n, m.col, dx, dy, k); else plat_tris(m.p.data(), m.c.data(), m.n, dx, dy, k); }
}
static const size_t CACHE_MAX = 3000;
void Canvas::trim() {
  const uint32_t ages[4] = {900, 150, 30, 0};
  for (int a = 0; a < 4 && cache.size() > CACHE_MAX * 8 / 10; a++) {
    uint32_t lim = frameNo > ages[a] ? frameNo - ages[a] : 0;
    for (auto it = cache.begin(); it != cache.end();) { if (it->second.u < lim) it = cache.erase(it); else ++it; }
  }
}
void Canvas::cacheBlock(const Key &key, const std::function<void()> &fn) {
  if (rec) { fn(); return; }   // nested blocks are recorded as part of the outer one
  uint64_t tk = fullKey(key);
  auto it = cache.find(tk);
  if (it != cache.end()) {
    it->second.u = frameNo; flush();
    float dx = S.e - it->second.e, dy = S.f - it->second.f;
    for (const Cmd &m : it->second.cmds) { if (m.t) plat_glyphs(m.p.data(), m.n, m.col, dx, dy, 1); else plat_tris(m.p.data(), m.c.data(), m.n, dx, dy, 1); }
    return;
  }
  flush();
  std::vector<Cmd> r; rec = &r;
  float e0 = S.e, f0 = S.f;
  fn();
  flush();
  rec = nullptr;
  if (cache.size() >= CACHE_MAX) trim();
  Block &b = cache[tk]; b.cmds = std::move(r); b.e = e0; b.f = f0; b.u = frameNo;
}
void Canvas::cacheBlockScaled(const Key &key, float k, const std::function<void()> &fn) {
  if (rec) { save(); scale(k, k); fn(); restore(); return; }
  uint64_t tk = fullKey(key);
  auto it = cache.find(tk);
  if (it == cache.end()) {
    flush();
    std::vector<Cmd> r; rec = &r; recQuiet = true;
    float e0 = S.e, f0 = S.f;
    fn();
    flush();
    recQuiet = false; rec = nullptr;
    if (cache.size() >= CACHE_MAX) trim();
    Block &b = cache[tk]; b.cmds = std::move(r); b.e = e0; b.f = f0;
    it = cache.find(tk);
  } else flush();
  it->second.u = frameNo;
  replay(it->second, k);
}
size_t Canvas::cacheBytes() const {
  size_t b = 0; for (auto &kv : cache) for (auto &m : kv.second.cmds) b += m.p.size() * 4 + m.c.size() * 4; return b;
}

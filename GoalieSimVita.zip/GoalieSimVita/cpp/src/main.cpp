// CHL 2026 native - the main loop: input, update, draw, a steady 30 FPS. No JavaScript, no browser layer.
#include "game.h"
#include "sk_int.h"
#include "menu.h"

Canvas ctx;
float W = 960, H = 544, U = 544, safeTop = 0;
double g_nowMs = 0;

// the crowd's murmur under every game: a little louder when the home team is pressing, quiet when paused
static void sndAmbTick(double dt) {
  static int voice = -1; static double v = 0, lastSet = 0;
  double tg = 0;
  if (state == ST_PLAY && QO.sfx && SK) { tg = paused ? .05 : .2;
    if (!paused && SK->phase == PH_PLAY) { Puck &P = SK->puck; if (std::fabs(P.x - attackX(0)) < 55) tg += .09; if (P.hasShot && P.shot.team == 0) tg += .05; }
    if (!paused && SK->phase == PH_GOAL && SK->hasCel && SK->cel.team == 0) tg += .12; }
  v += (tg - v) * std::min(1.0, dt * 1.8);
  if (v > .006) { if (voice < 0) voice = snd_play(S_AMB, (float)(v * SND_GAIN[S_AMB]), 1, true); else if (now() - lastSet > 90) { lastSet = now(); snd_set(voice, (float)(v * SND_GAIN[S_AMB])); } }
  else if (voice >= 0 && tg == 0) { snd_stop(voice); voice = -1; }
}

// start-up: the league, your stats, the save files (legacy saves are imported the first time)
void appInit() { leagueInit(); statsDefaults(g_stats); saveInit(); state = ST_MENU; mode = "quick"; screen = "modes"; }
static uint32_t prevBtn = 0;
static double lastT = 0;
// one frame of the game: read the pad, move everything on, draw it
// the performance read-out (pause screen: SHOW FPS): frames per second and where each frame's time goes
bool g_showFps = false;
static double pfUpd = 0, pfDraw = 0, pfEnd = 0, pfInt = 33;
void frameStep(bool draw) {
  double pf0 = plat_now_ms();
  g_nowMs = plat_now_ms();
  double rawMs = g_nowMs - lastT, dt = std::min(.05, std::max(0.0, (g_nowMs - lastT) / 1000)); lastT = g_nowMs;
  Pad pad; Touch touch; plat_input(pad, touch);
  uint32_t press = pad.btn & ~prevBtn; prevBtn = pad.btn;
  g_touch = touch;
  if (state == ST_PLAY && SK) {
    pausePad(press, pad, touch);
    // SELECT: the 3D view or the classic one (START + SELECT still quits)
    if ((press & B_SELECT) && !(pad.btn & B_START) && !paused) { extern bool g_view3d; g_view3d = !g_view3d; settings.view3d = g_view3d; saveSettings(); pushFeed(g_view3d ? "3D VIEW" : "CLASSIC VIEW", "#93c5fd"); }
    if (!paused && SK) { g_pad = pad; g_press = press & ~B_START; skUpdate(dt, pad, press); }
  } else menuPad(press, pad, touch);
  sndAmbTick(dt);
  if (!draw) { trTick(); return; }
  double pf1 = plat_now_ms();
  plat_begin_frame(0xff201208);
  if (state == ST_PLAY && SK) {
    if (SK->phase == PH_PREVIEW) skDrawPreview(); else skDraw();
    if (paused && SK) { drawPause(); drawFocus(); }
  } else drawMenu();
  drawTrans();
  if (g_showFps) { char b[96]; snprintf(b, sizeof b, "%.0f FPS  game %.1f  draw %.1f  gpu/wait %.1f ms", 1000 / std::max(1.0, pfInt), pfUpd, pfDraw, pfEnd);
    ctx.fill(rgba(0, 0, 0, .6)); ctx.fillRect(W - .62 * U, H - .05 * U, .62 * U, .05 * U); ctx.fill("#7CFC9A"); ctx.font(.026 * U); ctx.textMid(); ctx.fillText(b, W - .31 * U, H - .025 * U); }
  ctx.frame();
  double pf2 = plat_now_ms();
  plat_end_frame();
  double pf3 = plat_now_ms(), a = .1;
  pfUpd += ((pf1 - pf0) - pfUpd) * a; pfDraw += ((pf2 - pf1) - pfDraw) * a; pfEnd += ((pf3 - pf2) - pfEnd) * a; pfInt += (std::min(250.0, std::max(1.0, rawMs)) - pfInt) * a;
}

#ifndef HOST_BUILD
int main() {
  if (!plat_init()) return 0;
  g_rng.s ^= (uint64_t)(plat_now_ms() * 1000) | 1;
  appInit();
  lastT = plat_now_ms();
  for (;;) {
    Pad p; Touch t; plat_input(p, t);
    if ((p.btn & B_START) && (p.btn & B_SELECT)) break;   // hold START + SELECT to quit
    frameStep(true);
  }
  plat_shutdown();
  return 0;
}
#endif

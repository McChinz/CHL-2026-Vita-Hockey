// CHL 2026 native - the main loop: input, update, draw, a steady 30 FPS. No JavaScript, no browser layer.
#include "game.h"
#include "sk_int.h"

Canvas ctx;
float W = 960, H = 544, U = 544, safeTop = 0;
double g_nowMs = 0;

// the crowd's murmur under every game: a little louder when the home team is pressing, quiet when paused
static void sndAmbTick(double dt) {
  static int voice = -1; static double v = 0, lastSet = 0;
  double tg = 0;
  if (state == ST_PLAY && QO.sfx && SK) { tg = paused ? .05 : .2;
    if (!paused && SK->phase == PH_PLAY) { Puck &P = SK->puck; if (std::fabs(P.x - attackX(0)) < 55) tg += .09; if (P.hasShot && P.shot.team == 0) tg += .05; }
    if (!paused && SK->phase == PH_GOAL && SK->hasCel && SK->cel.team == 0) tg += .12; }
  v += (tg - v) * std::min(1.0, dt * 1.8);
  if (v > .006) { if (voice < 0) voice = snd_play(S_AMB, (float)(v * SND_GAIN[S_AMB]), 1, true); else if (now() - lastSet > 90) { lastSet = now(); snd_set(voice, (float)(v * SND_GAIN[S_AMB])); } }
  else if (voice >= 0 && tg == 0) { snd_stop(voice); voice = -1; }
}

static uint32_t prevBtn = 0;
static double lastT = 0;
// one frame of the game: read the pad, move everything on, draw it
void frameStep(bool draw) {
  g_nowMs = plat_now_ms();
  double dt = std::min(.05, std::max(0.0, (g_nowMs - lastT) / 1000)); lastT = g_nowMs;
  Pad pad; Touch touch; plat_input(pad, touch);
  uint32_t press = pad.btn & ~prevBtn; prevBtn = pad.btn;
  g_touch = touch;
  if (state == ST_PLAY && SK) {
    pausePad(press);
    if (!paused && SK) { g_pad = pad; g_press = press & ~B_START; skUpdate(dt, pad, press); }
  } else if (!trActive()) menuPad(press);
  sndAmbTick(dt);
  if (!draw) { trTick(); return; }
  plat_begin_frame(0xff201208);
  if (state == ST_PLAY && SK) {
    if (SK->phase == PH_PREVIEW) skDrawPreview(); else skDraw();
    if (paused && SK) drawPause();
  } else drawMenu();
  drawTrans();
  ctx.frame();
  plat_end_frame();
}

#ifndef HOST_BUILD
int main() {
  if (!plat_init()) return 0;
  g_rng.s ^= (uint64_t)(plat_now_ms() * 1000) | 1;
  lastT = plat_now_ms();
  for (;;) {
    Pad p; Touch t; plat_input(p, t);
    if ((p.btn & B_START) && (p.btn & B_SELECT)) break;   // hold START + SELECT to quit
    frameStep(true);
  }
  plat_shutdown();
  return 0;
}
#endif

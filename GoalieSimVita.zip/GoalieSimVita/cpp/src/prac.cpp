// CHL 2026 native - PRACTICE (skaters), ported from the legacy drills: a skating slalom through gates (best time),
// a shooting drill against a goalie (goals / shots) and aim training (hit all four corners in the fewest shots),
// each with a 50 / 70 / 99 OVR skater. Goalie drills come with goalie mode.
#include "pro.h"
#include "sk_int.h"
#include "platform.h"

int pracKind = 0, pracOv = 70;
static std::map<std::string, std::string> pracBest; static bool bestLoaded = false;
extern bool g_view3d; Pt sk3Proj(double x, double y, double z); double sk3Scale(double x, double y, double z);
static const char *PK_N3[3] = {"SKATING GATES", "SHOOTING", "AIM TRAINING"};
static const char *PK_D3[3] = {"A slalom up the ice: pass every gate in order. Clip a cone and you lose speed. Best time counts.",
  "You and a goalie. Score as many as you can - every shot counts against your percentage.",
  "Four targets in the corners of an empty net. Hit all four in as few shots as you can."};
static std::string bestKey(int k, int ov) { static const char *K[3] = {"skate", "shoot", "aim"}; return std::string(K[k]) + istr(ov); }
static void loadBest() {
  if (bestLoaded) return; bestLoaded = true; std::string s; bool ok = false;
  if (plat_read_file(plat_data_dir() + "chl_prac.json", s)) { J o = J::parse(s, &ok); if (ok && o.isObj()) for (size_t i = 0; i < o.k.size(); i++) pracBest[o.k[i]] = o.a[i].str(); }
}
static void saveBest() { J o = J::obj(); for (auto &e : pracBest) o[e.first] = e.second; plat_write_file(plat_data_dir() + "chl_prac.json", o.dump()); }

// ---------------------------------------------------------------- the drill on the ice
struct Gate { double x, y, w; };
static struct Drill { int k = 0; double t = 0, wait = 0, idle = 0; bool run = false, inStop = false; int gi = 0, shots = 0, goals = 0, seenShots = 0; std::vector<Gate> gates; std::vector<Pt> cones; struct Tg { int s; bool hi, hit; }; std::vector<Tg> tg; } D;
static void pracReset() {
  Skater *u = SK->user; Puck &P = SK->puck; double ax = attackX(0), d = tdir(0);
  P.vx = P.vy = 0; P.hasShot = false; P.passTo = nullptr; P.bz = 0; P.bvz = 0; P.wob = 0; P.ice = -1; P.lastPasser = nullptr;
  u->vx = u->vy = 0; u->stun = 0; u->dash = 0; u->st = 100; u->tired = false; u->ang = d > 0 ? 0 : PI; u->hasDk = false; u->wind = 0;
  if (D.k == 0) { u->x = 24; u->y = RK.cy; D.gi = 0; D.run = false; D.t = 0; }
  else if (D.k == 1) { u->x = RK.L / 2; u->y = RK.cy; Goalie &g = SK->T[1].g; g.x = defendX(1) + tdir(1) * 2; g.y = RK.cy; g.vx = g.vy = 0; g.hasAn = false; g.cd = 0; g.hasBite = false; }
  else { u->x = ax - d * 24; u->y = RK.cy + rand(-6, 6); }
  P.owner = u; P.x = u->x; P.y = u->y; P.last = u; SK->phase = PH_PLAY; SK->hold.on = false; D.inStop = false; D.idle = 0; D.seenShots = SK->me.shots;
}
void pracSetup() {
  SK->drill = true; D = Drill(); D.k = pracKind; SK->hasRef = false;
  Skater *u = SK->user; double v = rt2at(pracOv);
  Attr &a = u->at; a.spd = a.agl = a.deke = a.pass = a.wacc = a.wpow = a.lacc = a.spow = a.chk = a.hand = a.stam = a.fo = a.poise = a.bhp = a.bha = v; u->pks.clear();
  for (int ti = 0; ti < 2; ti++) { Team &T = SK->T[ti]; T.on.clear(); T.lines.clear(); T.bench.clear(); T.allSk.clear(); T.box.clear(); }
  SK->T[0].on.push_back(u); SK->T[0].name = "PRACTICE"; SK->T[1].name = D.k == 0 ? "GATES" : D.k == 2 ? "TARGETS" : "GOALIE";
  SK->T[0].g.out = true; SK->T[1].g.out = D.k != 1;
  if (D.k == 0) { for (int i = 0; i < 8; i++) D.gates.push_back({40.0 + i * 16, RK.cy + (i % 2 ? 13 : -13), 7}); D.gates.push_back({178, RK.cy, 9});
    for (int i = 0; i < 7; i++) D.cones.push_back({48.0 + i * 16, RK.cy + (i % 2 ? -4 : 4)}); }
  if (D.k == 2) for (int s : {-1, 1}) for (bool hi : {false, true}) D.tg.push_back({s, hi, false});
  SK->clock = SK_PER; pracReset();
}
static void finish(const std::string &txt, Col c, double wait) { SK->banner = {wait, txt, "", c}; SK->phase = PH_STOP; D.inStop = true; D.wait = wait; }
bool pracUpdate(double dt) {
  if (!SK->drill) return false;
  if (SK->phase == PH_PREVIEW || SK->phase == PH_INTRO || SK->phase == PH_FACEOFF || SK->phase == PH_TRANS) pracReset();
  if (SK->phase != PH_PLAY) {   // a whistle (save frozen, icing, a goal): go again after a beat
    if (!D.inStop) { D.inStop = true; D.wait = SK->phase == PH_HOLD ? .9 : .7; }
    D.wait -= dt; SK->gt += dt; for (auto &f : feed) f.t += dt; if (SK->banner.t > 0) SK->banner.t -= dt;
    if (D.wait <= 0) pracReset(); return true;
  }
  Skater *u = SK->user; Puck &P = SK->puck;
  if (SK->me.shots != D.seenShots) { D.shots += SK->me.shots - D.seenShots; D.seenShots = SK->me.shots; }
  if (D.k == 0) {
    if (!D.run && u->x > 30) { D.run = true; D.t = 0; }
    if (D.run) D.t += dt;
    for (auto &c : D.cones) { double dx = u->x - c.x, dy = u->y - c.y, dd = hyp(dx, dy); if (dd < 1.6 && dd > 0) { u->x = c.x + dx / dd * 1.6; u->y = c.y + dy / dd * 1.6; u->vx *= .55; u->vy *= .55; } }
    if (D.gi < (int)D.gates.size()) { const Gate &G = D.gates[D.gi];
      if (std::fabs(u->x - G.x) < 1.5 && std::fabs(u->y - G.y) < G.w / 2) { D.gi++; sfx(S_PASS, .5, 1.3);
        if (D.gi >= (int)D.gates.size()) { std::string k = bestKey(0, pracOv), t = fixed(D.t, 2) + "s"; auto it = pracBest.find(k);
          bool nb = it == pracBest.end() || atof(t.c_str()) < atof(it->second.c_str()); if (nb) { pracBest[k] = t; saveBest(); }
          finish((nb ? "NEW BEST  " : "FINISHED  ") + t, hex("#7CFC9A"), 2.2); } } }
  } else {
    if (!P.owner && !P.hasShot && hyp(P.vx, P.vy) < 3) { D.idle += dt; if (D.idle > 1.4) pracReset(); } else D.idle = 0;   // a dead puck: go again
    if (P.hasShot && std::fabs(P.x - RK.L / 2) > RK.L / 2 - 4) pracReset();
  }
  return false;
}
// a puck in the net during a drill
void pracGoal(int team) {
  (void)team; Puck &P = SK->puck; double z = P.bz;
  if (D.k == 2) {
    bool hi = z > PZ * .5, lo = z < PZ * .42; int side = P.y < RK.cy ? -1 : 1; bool corner = std::fabs(std::fabs(P.y - RK.cy) - (RK.post - 1.3)) < 1.6;
    Drill::Tg *T = nullptr; for (auto &t : D.tg) if (!t.hit && t.s == side && ((t.hi && hi) || (!t.hi && lo))) { T = &t; break; }
    if (T && corner) { T->hit = true; sfx(S_POST, .6, 1.2); bool all = true; for (auto &t : D.tg) if (!t.hit) all = false;
      if (all) { std::string k = bestKey(2, pracOv); auto it = pracBest.find(k); bool nb = it == pracBest.end() || D.shots < atoi(it->second.c_str()); if (nb) { pracBest[k] = istr(D.shots) + " shots"; saveBest(); }
        finish(std::string(nb ? "NEW BEST!  " : "ALL FOUR!  ") + istr(D.shots) + " SHOTS", hex("#7CFC9A"), 2); for (auto &t : D.tg) t.hit = false; D.shots = 0; return; }
      finish("TARGET!", hex("#fbbf24"), .6); }
    else finish("MISSED THE TARGET", hex("#94a3b8"), .7);
  } else { D.goals++; sfx(S_CHEER, .5, 1.05); { std::string k = bestKey(1, pracOv); auto it = pracBest.find(k); if (it == pracBest.end() || D.goals >= atoi(it->second.c_str())) { pracBest[k] = istr(D.goals) + " / " + istr(std::max(D.goals, D.shots)); saveBest(); } }
    finish("GOAL!  " + istr(D.goals) + " / " + istr(std::max(D.goals, D.shots)), hex("#7CFC9A"), 1.2); }
}
static Pt pj(const Layout &lay, double x, double y, double z) { return g_view3d ? sk3Proj(x, y, z) : skW2S(lay, x, y, z); }
static double ps(const Layout &lay, double x, double y) { return g_view3d ? sk3Scale(x, y, 0) : lay.s; }
static void cone(const Layout &lay, double x, double y, double h, double r, Col c) {
  Pt b = pj(lay, x, y, 0), t = pj(lay, x, y, h); double rr = r * ps(lay, x, y);
  ctx.fill(c); ctx.beginPath(); ctx.moveTo(t.x, t.y); ctx.lineTo(b.x + rr, b.y); ctx.lineTo(b.x - rr, b.y); ctx.closePath(); ctx.fillPath();
  ctx.fill(rgba(255, 255, 255, .7)); ctx.fillRect(b.x - rr * .55, (b.y + t.y) / 2 - 1, rr * 1.1, 2);
}
void pracDraw(const Layout &lay) {
  if (!SK->drill) return;
  if (D.k == 0) {
    for (size_t i = 0; i < D.gates.size(); i++) { const Gate &G = D.gates[i]; Col c = (int)i < D.gi ? rgba(34, 197, 94, .45) : (int)i == D.gi ? hex("#f97316") : rgba(249, 115, 22, .55);
      if ((int)i == D.gi) { Pt a = pj(lay, G.x, G.y - G.w / 2, 0), b = pj(lay, G.x, G.y + G.w / 2, 0); ctx.stroke(rgba(249, 115, 22, .7)); ctx.lineWidth(3); ctx.line(a.x, a.y, b.x, b.y); }
      for (int s : {-1, 1}) cone(lay, G.x, G.y + s * G.w / 2, 2.4, .55, c); }
    for (auto &c : D.cones) cone(lay, c.x, c.y, 1.8, .6, hex("#ef4444"));
  }
  if (D.k == 2) { double ax = attackX(0);
    for (auto &T : D.tg) { if (T.hit) continue; Pt q = pj(lay, ax, RK.cy + T.s * (RK.post - 1.3), T.hi ? PZ * .75 : PZ * .2); double r = std::max(5.0, .9 * ps(lay, ax, RK.cy));
      ctx.fill(rgba(251, 191, 36, .9)); ctx.disc(q.x, q.y, r); ctx.fill("#b91c1c"); ctx.disc(q.x, q.y, r * .55); ctx.fill("#fff"); ctx.disc(q.x, q.y, r * .22); } }
  int hit = 0; for (auto &t : D.tg) hit += t.hit;
  std::string t = D.k == 0 ? "GATE " + istr(std::min(D.gi + 1, (int)D.gates.size())) + " / " + istr(D.gates.size()) + "    " + fixed(D.t, 2) + "s"
    : D.k == 2 ? "TARGETS " + istr(hit) + " / 4    SHOTS " + istr(D.shots) : "GOALS " + istr(D.goals) + " / " + istr(std::max(D.goals, D.shots));
  auto it = pracBest.find(bestKey(D.k, pracOv)); t += "    |    " + istr(pracOv) + " OVR" + (it != pracBest.end() ? "    |    BEST " + it->second : "");
  ctx.font(.026 * U); double tw = ctx.measure(t) + .04 * U; ctx.fill(rgba(8, 12, 24, .78)); ctx.rr(W / 2 - tw / 2, safeTop + .02 * U, tw, .05 * U, .025 * U); ctx.fillPath();
  ctx.fill("#fff"); ctx.textMid(); ctx.fillText(t, W / 2, safeTop + .045 * U);
}

// ---------------------------------------------------------------- the menu
void drawPractice() {
  loadBest();
  double w = std::min(W - 24.0, 1.7 * U), x = (W - w) / 2, y = safeTop + .02 * U;
  tx("PRACTICE", W / 2, y + .05 * U, .075, hex("#fff"), AL_CENTER, true);
  tx("Skater drills  |  goalie drills come with goalie mode", W / 2, y + .11 * U, .026, "#94a3b8", AL_CENTER, 700);
  double cw = (w - .04 * U) / 3, ch = .3 * U, cy = y + .15 * U;
  for (int k = 0; k < 3; k++) { double cx = x + k * (cw + .02 * U); bool on = pracKind == k;
    if (on) glassTop(cx, cy, cw, ch, hex("#ea580c"), .85); else glass(cx, cy, cw, ch, .6);
    tx(PK_N3[k], cx + cw / 2, cy + .05 * U, .03, hex(on ? "#fff" : "#cbd5e1"), AL_CENTER, true);
    txWrap(PK_D3[k], cx + cw / 2, cy + .12 * U, .017, cw - .04 * U, hex("#94a3b8"), AL_CENTER, 700, 3);
    double by = cy + .2 * U; tx("BEST", cx + cw / 2, by, .015, "#64748b", AL_CENTER, 800);
    std::string b; for (int ov : {50, 70, 99}) { auto it = pracBest.find(bestKey(k, ov)); b += (b.empty() ? "" : "   ") + istr(ov) + ": " + (it == pracBest.end() ? "-" : it->second); }
    tx(b, cx + cw / 2, by + .03 * U, .016, "#ffd54a", AL_CENTER, 800);
    pushBtn("pk:" + istr(k), cx, cy, cw, ch, PK_N3[k]); }
  double oy = cy + ch + .03 * U, ow = .2 * U; tx("SKATER", x, oy + .03 * U, .024, "#cbd5e1", AL_LEFT, 800);
  int k = 0; for (int ov : {50, 70, 99}) { ui("pov:" + istr(ov), x + .14 * U + k * (ow + .015 * U), oy, ow, .06 * U, istr(ov) + " OVR", pracOv == ov ? "#ea580c" : "#334155", true, .026); k++; }
  double by = oy + .1 * U, bw = std::min(.5 * U, w / 2 - .02 * U);
  ui("pstart", W / 2 - bw - .01 * U, by, bw, .09 * U, "START DRILL", "#16a34a", true, .04);
  ui("nav:modes", W / 2 + .01 * U, by, bw, .09 * U, "MAIN MENU", "#475569", true, .04);
  footHints({{"D-PAD", "MOVE"}, {"X", "SELECT"}, {"START", "PAUSE / QUIT A DRILL"}});
}
bool pracTap(const std::string &id) {
  if (mode != "practice") return false;
  if (id.rfind("pk:", 0) == 0) { pracKind = atoi(id.c_str() + 3); return true; }
  if (id.rfind("pov:", 0) == 0) { pracOv = atoi(id.c_str() + 4); return true; }
  if (id == "pstart") { startGame(); return true; }
  return false;
}

// emblem.cpp - original team emblems built from triangles (see emblem.h). Nothing here copies a real club's logo:
// each NHL team gets a badge and symbol chosen to stay clear of its real one.
#include "emblem.h"
#include <cmath>
#include <map>

extern Canvas ctx;
namespace {
const double PI_ = 3.14159265358979;
enum Sym { S_STAR, S_COMPASS, S_SUN, S_SNOW, S_PEAKS, S_WAVES, S_CROWN, S_FLAME, S_ARROW, S_STICKS, S_GEM, S_TOWER, S_TRIDENT, S_MOON, S_PUCK, S_CLAW, S_SAIL, S_COMET, S_CHEV, S_NSYM };
enum Bdg { B_CIRCLE, B_SHIELD, B_HEX, B_DIAMOND, B_SQUARE, B_NBDG };
struct Def { const char *ab; int sym, bdg; };
// the NHL: picked so that no club gets anything like its real mark
const Def NHL[] = {{"ANA", S_SUN, B_CIRCLE}, {"BOS", S_SAIL, B_SHIELD}, {"BUF", S_COMPASS, B_CIRCLE}, {"CGY", S_PEAKS, B_HEX}, {"CAR", S_COMET, B_DIAMOND},
  {"CHI", S_TOWER, B_SQUARE}, {"COL", S_SNOW, B_HEX}, {"CBJ", S_STICKS, B_SHIELD}, {"DAL", S_GEM, B_CIRCLE}, {"DET", S_CHEV, B_SQUARE}, {"EDM", S_CROWN, B_SHIELD},
  {"FLA", S_WAVES, B_CIRCLE}, {"LAK", S_MOON, B_DIAMOND}, {"MIN", S_CLAW, B_SQUARE}, {"MTL", S_STAR, B_SHIELD}, {"NSH", S_FLAME, B_CIRCLE}, {"NJD", S_TRIDENT, B_HEX},
  {"NYI", S_WAVES, B_DIAMOND}, {"NYR", S_ARROW, B_CIRCLE}, {"OTT", S_TOWER, B_HEX}, {"PHI", S_SUN, B_DIAMOND}, {"PIT", S_PUCK, B_HEX}, {"SJS", S_SAIL, B_CIRCLE},
  {"SEA", S_COMET, B_HEX}, {"STL", S_CHEV, B_CIRCLE}, {"TBL", S_STAR, B_HEX}, {"TOR", S_ARROW, B_SHIELD}, {"UTA", S_SNOW, B_DIAMOND}, {"VAN", S_TRIDENT, B_CIRCLE},
  {"VGK", S_GEM, B_HEX}, {"WSH", S_COMPASS, B_SQUARE}, {"WPG", S_MOON, B_HEX}};

struct B { std::vector<ETri> t; unsigned char c = 2;
  void tri(double x0, double y0, double x1, double y1, double x2, double y2) { ETri e; e.x[0] = (float)x0; e.y[0] = (float)y0; e.x[1] = (float)x1; e.y[1] = (float)y1; e.x[2] = (float)x2; e.y[2] = (float)y2; e.c = c; t.push_back(e); }
  void quad(double x0, double y0, double x1, double y1, double x2, double y2, double x3, double y3) { tri(x0, y0, x1, y1, x2, y2); tri(x0, y0, x2, y2, x3, y3); }
  // a polygon that every point of can see (cx, cy): a fan
  void fan(const std::vector<double> &p, double cx, double cy) { size_t n = p.size() / 2; for (size_t i = 0; i < n; i++) { size_t j = (i + 1) % n; tri(cx, cy, p[i * 2], p[i * 2 + 1], p[j * 2], p[j * 2 + 1]); } }
  void disc(double cx, double cy, double rx, double ry, int n = 20) { std::vector<double> p; for (int i = 0; i < n; i++) { double a = 2 * PI_ * i / n; p.push_back(cx + rx * std::cos(a)); p.push_back(cy + ry * std::sin(a)); } fan(p, cx, cy); }
  // a bar from (x0,y0) to (x1,y1), w wide
  void bar(double x0, double y0, double x1, double y1, double w) { double dx = x1 - x0, dy = y1 - y0, L = std::sqrt(dx * dx + dy * dy); if (L < 1e-6) return; double nx = -dy / L * w / 2, ny = dx / L * w / 2;
    quad(x0 + nx, y0 + ny, x1 + nx, y1 + ny, x1 - nx, y1 - ny, x0 - nx, y0 - ny); }
  void star(double cx, double cy, double ro, double ri, int k, double rot) { std::vector<double> p; for (int i = 0; i < 2 * k; i++) { double a = rot + PI_ * i / k, r = i % 2 ? ri : ro; p.push_back(cx + r * std::sin(a)); p.push_back(cy + r * std::cos(a)); } fan(p, cx, cy); }
};
// the badge's outline, scaled by s
std::vector<double> badgePts(int bdg, double s) {
  std::vector<double> p; auto P = [&](double x, double y) { p.push_back(x * s); p.push_back(y * s); };
  switch (bdg) {
    case B_SHIELD: P(-.84, .86); P(-.3, .94); P(0, .82); P(.3, .94); P(.84, .86); P(.84, .1);
      for (int i = 1; i <= 10; i++) { double a = i / 10.0 * PI_ / 2; P(.84 * std::cos(a), .1 - 1.1 * std::sin(a)); }
      for (int i = 9; i >= 0; i--) { double a = i / 10.0 * PI_ / 2; P(-.84 * std::cos(a), .1 - 1.1 * std::sin(a)); } break;
    case B_HEX: for (int i = 0; i < 6; i++) { double a = PI_ / 6 + PI_ / 3 * i; P(std::cos(a), std::sin(a)); } break;
    case B_DIAMOND: P(0, 1.02); P(.9, 0); P(0, -1.02); P(-.9, 0); break;
    case B_SQUARE: { double r = .2; for (int q = 0; q < 4; q++) { double cx = q == 0 || q == 3 ? .85 - r : -.85 + r, cy = q < 2 ? .85 - r : -.85 + r; double a0 = q * PI_ / 2;
        for (int i = 0; i <= 3; i++) { double a = a0 + PI_ / 2 * i / 3; P(cx + r * std::cos(a), cy + r * std::sin(a)); } } break; }
    default: for (int i = 0; i < 28; i++) { double a = 2 * PI_ * i / 28; P(std::cos(a), std::sin(a)); }
  }
  return p;
}
void symbol(B &b, int s) {
  b.c = 2;
  switch (s) {
    case S_STAR: b.star(0, .02, .56, .23, 5, 0); break;
    case S_COMPASS: b.star(0, 0, .6, .13, 4, 0); b.c = 1; b.star(0, 0, .34, .1, 4, PI_ / 4); b.c = 3; b.disc(0, 0, .07, .07, 10); break;
    case S_SUN: b.disc(0, 0, .27, .27); for (int i = 0; i < 12; i++) { double a = 2 * PI_ * i / 12, a1 = a + .13, a2 = a - .13; b.tri(.34 * std::cos(a1), .34 * std::sin(a1), .6 * std::cos(a), .6 * std::sin(a), .34 * std::cos(a2), .34 * std::sin(a2)); } break;
    case S_SNOW: for (int i = 0; i < 6; i++) { double a = PI_ / 2 + PI_ / 3 * i, c = std::cos(a), sn = std::sin(a); b.bar(0, 0, .6 * c, .6 * sn, .09);
        for (int sd = -1; sd <= 1; sd += 2) { double ab = a + sd * .75; b.bar(.36 * c, .36 * sn, .36 * c + .17 * std::cos(ab), .36 * sn + .17 * std::sin(ab), .07); } } b.disc(0, 0, .1, .1, 12); break;
    case S_PEAKS: b.tri(-.66, -.42, -.22, .32, .2, -.42); b.tri(-.12, -.42, .25, .52, .66, -.42); b.c = 1; b.tri(.25, .52, .13, .22, .37, .22); b.tri(-.22, .32, -.32, .15, -.12, .15); b.c = 2; b.quad(-.66, -.42, .66, -.42, .66, -.5, -.66, -.5); break;
    case S_WAVES: for (int k = 0; k < 3; k++) { double y0 = .3 - k * .3; b.c = k == 1 ? 1 : 2; int n = 14;
        for (int i = 0; i < n; i++) { double x0 = -.62 + 1.24 * i / n, x1 = -.62 + 1.24 * (i + 1) / n, w0 = .08 * std::sin(x0 * 7.5), w1 = .08 * std::sin(x1 * 7.5);
          b.quad(x0, y0 + w0 + .07, x1, y0 + w1 + .07, x1, y0 + w1 - .07, x0, y0 + w0 - .07); } } break;
    case S_CROWN: b.quad(-.52, -.38, .52, -.38, .52, -.16, -.52, -.16); b.tri(-.52, -.16, -.58, .4, -.2, -.16); b.tri(-.26, -.16, 0, .5, .26, -.16); b.tri(.2, -.16, .58, .4, .52, -.16);
      b.c = 1; b.disc(-.58, .44, .07, .07, 10); b.disc(0, .55, .07, .07, 10); b.disc(.58, .44, .07, .07, 10); b.c = 3; b.disc(0, -.27, .07, .06, 10); break;
    case S_FLAME: { const double F[] = {0, -.56, .34, -.46, .48, -.16, .44, .16, .3, .4, .3, .12, .16, .24, .1, .64, -.08, .34, -.18, .5, -.3, .2, -.46, -.04, -.4, -.38};
      std::vector<double> p(F, F + 26); b.fan(p, 0, -.18); b.c = 1; std::vector<double> q; for (size_t i = 0; i < p.size(); i += 2) { q.push_back(p[i] * .52); q.push_back(-.3 + (p[i + 1] + .18) * .55); } b.fan(q, 0, -.3); } break;
    case S_ARROW: { double c = std::cos(PI_ / 4), sn = std::sin(PI_ / 4); auto R = [&](double x, double y, double &ox, double &oy) { ox = x * c - y * sn; oy = x * sn + y * c; };
      double ax[8], ay[8]; double px[8] = {-.62, .3, .3, .62, .3, .3, -.62, 0}, py[8] = {.05, .05, .2, 0, -.2, -.05, -.05, 0}; for (int i = 0; i < 7; i++) R(px[i], py[i], ax[i], ay[i]);
      b.quad(ax[0], ay[0], ax[1], ay[1], ax[5], ay[5], ax[6], ay[6]); b.tri(ax[2], ay[2], ax[3], ay[3], ax[4], ay[4]);
      b.c = 1; for (int k = 0; k < 2; k++) { double x0 = -.6 + k * .14, f[8]; R(x0, .05, f[0], f[1]); R(x0 + .12, .05, f[2], f[3]); R(x0 + .02, .22, f[4], f[5]); R(x0 - .1, .22, f[6], f[7]); b.quad(f[0], f[1], f[2], f[3], f[4], f[5], f[6], f[7]);
        R(x0, -.05, f[0], f[1]); R(x0 + .12, -.05, f[2], f[3]); R(x0 + .02, -.22, f[4], f[5]); R(x0 - .1, -.22, f[6], f[7]); b.quad(f[0], f[1], f[2], f[3], f[4], f[5], f[6], f[7]); } } break;
    case S_STICKS: b.bar(-.5, .6, .32, -.42, .1); b.bar(.32, -.42, .1, -.52, .12); b.bar(.5, .6, -.32, -.42, .1); b.bar(-.32, -.42, -.1, -.52, .12); b.c = 3; b.disc(0, -.55, .16, .06, 14); break;
    case S_GEM: b.quad(-.32, .32, .32, .32, .58, .08, -.58, .08); b.tri(-.58, .08, .58, .08, 0, -.58); b.c = 1; b.tri(-.32, .32, 0, .08, -.58, .08); b.tri(.32, .32, .58, .08, 0, .08);
      b.c = 3; b.tri(0, .08, .58, .08, 0, -.58); break;
    case S_TOWER: b.quad(-.36, -.55, .36, -.55, .3, .25, -.3, .25); b.quad(-.42, .25, .42, .25, .42, .38, -.42, .38);
      for (int i = 0; i < 4; i++) { double x = -.42 + i * .28; b.quad(x, .38, x + .14, .38, x + .14, .52, x, .52); }
      b.c = 3; b.quad(-.11, -.55, .11, -.55, .11, -.25, -.11, -.25); b.disc(0, -.25, .11, .08, 10); b.quad(-.06, .02, .06, .02, .06, .14, -.06, .14); break;
    case S_TRIDENT: b.bar(0, -.62, 0, .3, .09); b.quad(-.42, .14, .42, .14, .42, .24, -.42, .24); b.bar(-.38, .2, -.38, .5, .08); b.bar(.38, .2, .38, .5, .08); b.tri(-.46, .5, -.38, .64, -.3, .5); b.tri(.3, .5, .38, .64, .46, .5);
      b.tri(-.09, .3, 0, .66, .09, .3); break;
    case S_MOON: b.disc(0, 0, .56, .56, 24); b.c = 0; b.disc(.24, .14, .47, .47, 24); b.c = 1; b.star(.34, .3, .15, .06, 4, 0); break;
    case S_PUCK: b.c = 3; b.disc(0, -.18, .55, .2); b.quad(-.55, -.18, .55, -.18, .55, .08, -.55, .08); b.c = 2; b.disc(0, .08, .55, .2); b.c = 1; b.quad(-.55, -.08, .55, -.08, .55, -.02, -.55, -.02); break;
    case S_CLAW: for (int k = -1; k <= 1; k++) { double x = k * .26; int n = 6; for (int i = 0; i < n; i++) { double t0 = (double)i / n, t1 = (double)(i + 1) / n;
        auto C = [&](double t, double &cx, double &cy, double &w) { cx = x - .2 + .4 * t + .08 * std::sin(t * PI_); cy = .58 - 1.16 * t; w = .12 * std::sin(t * PI_) + .015; };
        double ax, ay, aw, bx, by, bw; C(t0, ax, ay, aw); C(t1, bx, by, bw); b.quad(ax - aw / 2, ay, ax + aw / 2, ay, bx + bw / 2, by, bx - bw / 2, by); } } break;
    case S_SAIL: b.tri(-.05, .6, -.05, -.2, -.55, -.2); b.c = 1; b.tri(.05, .5, .05, -.2, .48, -.2); b.c = 2; b.quad(-.6, -.28, .6, -.28, .42, -.48, -.42, -.48); b.bar(0, .62, 0, -.28, .05); break;
    case S_COMET: b.star(.26, .26, .3, .12, 5, .3); b.c = 1; for (int k = 0; k < 3; k++) { double o = (k - 1) * .12; b.tri(.12 + o * .5, .3 + o, .3 + o * .5, .12 + o, -.6 + o * .4, -.55 + o * .6); } break;
    case S_CHEV: for (int k = 0; k < 2; k++) { double y = .3 - k * .42; b.c = k ? 1 : 2; b.quad(-.6, y, 0, y - .32, 0, y - .14, -.6, y + .18); b.quad(0, y - .32, .6, y, .6, y + .18, 0, y - .14); } break;
  }
}
std::map<std::string, std::vector<ETri>> &cache() { static std::map<std::string, std::vector<ETri>> m; return m; }
}

const std::vector<ETri> &emblemTris(const std::string &key) {
  auto it = cache().find(key); if (it != cache().end()) return it->second;
  int sym = -1, bdg = 0; for (auto &d : NHL) if (key == d.ab) { sym = d.sym; bdg = d.bdg; break; }
  if (sym < 0) { unsigned h = 2166136261u; for (unsigned char c : key) h = (h ^ c) * 16777619u; sym = (int)(h % S_NSYM); bdg = (int)(h / S_NSYM % B_NBDG); }
  B b; b.c = 3; b.fan(badgePts(bdg, 1), 0, bdg == B_SHIELD ? .1 : 0);       // the rim
  b.c = 1; b.fan(badgePts(bdg, .9), 0, bdg == B_SHIELD ? .1 : 0);          // the second colour's band
  b.c = 0; b.fan(badgePts(bdg, .78), 0, bdg == B_SHIELD ? .1 : 0);         // the field
  B s; symbol(s, sym); double k = bdg == B_DIAMOND ? .78 : bdg == B_SHIELD ? .82 : .9, oy = bdg == B_SHIELD ? .06 : 0;
  for (auto &t : s.t) { ETri e = t; for (int i = 0; i < 3; i++) { e.x[i] = (float)(t.x[i] * k); e.y[i] = (float)(t.y[i] * k + oy); } b.t.push_back(e); }
  return cache().emplace(key, b.t).first->second;
}
void emblemCols(Col prim, Col sec, Col out[4]) {
  double lp = lum(prim), ls = lum(sec);
  out[0] = prim; out[1] = std::fabs(lp - ls) < .12 ? (lp > .5 ? shade(prim, -.45) : hex("#e5e7eb")) : sec;
  out[2] = lp > .62 ? hex("#111827") : hex("#f8fafc"); out[3] = lp < .15 ? hex("#cbd5e1") : shade(prim, -.55);
  if (lp > .62 && ls > .62) out[1] = shade(prim, -.4);
}
void drawEmblem(const std::string &key, double cx, double cy, double r, Col prim, Col sec, double alpha) {
  Col C[4]; emblemCols(prim, sec, C); uint32_t pc[4]; for (int i = 0; i < 4; i++) pc[i] = C[i].pack((float)alpha);
  for (auto &t : emblemTris(key)) ctx.rawTri((float)(cx + t.x[0] * r), (float)(cy - t.y[0] * r), (float)(cx + t.x[1] * r), (float)(cy - t.y[1] * r), (float)(cx + t.x[2] * r), (float)(cy - t.y[2] * r), pc[t.c]);
}

// CHL 2026 native - the menu system, ported from the legacy build: the broadcast look (buttons, menu items,
// headings, hint bars, key art), D-pad / stick navigation with the focus marker, the YES / NO modal and the
// screen router. Ultimate Franchise (ut.cpp) and the other modes draw their screens with these.
#pragma once
#include "game.h"

extern const Col ACC;
// a button this frame (tap / pad target). np: not reachable with the D-pad (full-screen taps, tab rows)
struct Btn { std::string id; double x, y, w, h; std::string lb; bool dis = false, np = false; };
extern std::vector<Btn> btns;
extern std::string mFocus; extern bool mPadUsed;
void pushBtn(const std::string &id, double x, double y, double w, double h, const std::string &lb = "", bool np = false);

// where you are: mode "quick" / "ut" / "pro" / "practice", screen "modes" / "main" / "settings" / "name" / "result" / "ut..."
extern std::string mode, screen;
extern std::string pname;      // the name being typed on the name screen
extern std::string nameFor;    // "pro" or "ut"
extern int nameTarget;

// settings (saved): goalie assist, auto aim, sound; the difficulty is per mode
struct Settings { bool autoPad = false, gAssist = true, autoAim = true, sfx = true, view3d = true; };
extern Settings settings;

// the YES / NO box
struct Modal { bool on = false; std::string t, s; std::function<void()> yes; };
extern Modal modal;
void askModal(const std::string &t, const std::string &s, std::function<void()> yes);
void drawModal();

// drawing helpers (legacy names and sizes; sizes are fractions of U)
void ui(const std::string &id, double x, double y, double w, double h, const std::string &label, Col col, bool on = true, double fs = .04);
inline void ui(const std::string &id, double x, double y, double w, double h, const std::string &label, const char *col, bool on = true, double fs = .04) { ui(id, x, y, w, h, label, hex(col), on, fs); }
void menuItem(const std::string &id, const std::string &label, double x, double y, double w, double h, bool big, bool on);
void tx(const std::string &t, double x, double y, double sz, const char *c, Align al = AL_LEFT, int wt = 800, bool it = false);
void txWrap(const std::string &t, double x, double y, double sz, double maxW, Col c, Align al = AL_LEFT, int wt = 800, int maxL = 2);
void txFit(const std::string &t, double x, double y, double sz, double maxW, Col c, Align al = AL_LEFT);
double utFitTx(const std::string &t, double x, double y, double px, double maxW, Align al = AL_LEFT);
std::vector<std::string> wrapText(const std::string &t, double maxW);
double wordmarkW(double s);
void wordmarkC(double cx, double y, double s);
void heroArt(double x, double y, double w, double h, Col col, Col stripe, bool goalie, int seed);
void footHints(const std::vector<std::pair<std::string, std::string>> &h);
void menuBG();
void menuSnow();
void drawFocus();
void rrPath(double x, double y, double w, double h, double r);
std::string fmtN(double n);
std::string fmtM(double v);
std::string fixed(double v, int d);
std::string svp3(double a, double b);   // ".912", ".000" with no shots

// the screens
void uiTap(const std::string &id);
void startGame();             // the game for the current mode
void afterGame(bool won, bool quit);   // a game finished (or was quit): results, rewards, back to the menus
extern bool g_lastQuit;
struct RSum { std::string hn, an; int hs = 0, as = 0, hsh = 0, ash = 0, cash = 0; bool so = false, hasF = false; MeStats f; };
extern RSum rs; extern double lockUntil;

// saves (save.cpp)
void saveInit();               // load settings, Ultimate Franchise files, last played (imports legacy files once)
void saveSettings();
J &lastSave();                 // {m, i}
void setLast(const std::string &m, int i);

// CHL 2026 native - the Vita system layer (vita_sys.cpp) as the two renderers see it
#pragma once
#define DATA_DIR "ux0:data/GoalieSimNative"
void vita_sys_init();
void vita_sys_fini();
void vita_pace();    // wait for the frame's second refresh
void vita_paced();   // the frame was shown

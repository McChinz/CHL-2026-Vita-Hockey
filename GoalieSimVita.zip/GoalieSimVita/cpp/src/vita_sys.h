// CHL 2026 native - the Vita system layer (vita_sys.cpp) as the two renderers see it
#pragma once
#define DATA_DIR "ux0:data/GoalieSimNative"
void vita_sys_init();
void vita_sys_fini();
void vita_pace(int n = 2);    // wait until n refreshes have passed since the last frame was shown
void vita_paced();   // the frame was shown

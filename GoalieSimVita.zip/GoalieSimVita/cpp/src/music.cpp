// CHL 2026 native - the soundtrack (see music.h). Three threads touch it:
//   main:    mus_frame - wants music or not, picks songs (asks for one by bumping g_req)
//   decoder: mus_pump  - opens what was asked for once the mixer has faded out, decodes into the ring
//   audio:   mus_mix   - reads the ring at the song's rate, fades in and out
// They only share the atomics below: one writer each, so no locks.
#include "music.h"
#include "game.h"
#include "canvas.h"
#include "menu.h"
#include <atomic>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <cstdlib>

namespace {
static int g_user = 0;   // how many of the songs are your own
struct Track { std::string file, artist, title; int secs = 0; std::string path; };   // path: a song of your own (the data folder), else in DIR
std::vector<Track> TR;
std::string DIR;
const int RN = 1 << 16, RM = RN - 1;   // ring: 65536 stereo frames, about 1.5 s
int16_t RING[RN * 2];
std::atomic<uint32_t> g_wr{0}, g_rd{0};        // frames written (decoder) and read (mixer), ever
std::atomic<int> g_reqTrack{-1};               // what the main thread wants (-1 = silence)
std::atomic<uint32_t> g_req{0};                // bumped by the main thread for every change
std::atomic<uint32_t> g_mixSeq{0};             // the request the mixer has faded out for (and flushed)
std::atomic<uint32_t> g_pumpSeq{0};            // the request the decoder has opened
std::atomic<uint32_t> g_start{0};              // where in the ring that request's sound begins
std::atomic<uint32_t> g_endSeq{0xffffffffu};   // the request whose song ran out
std::atomic<int> g_rate{44100};
std::atomic<uint32_t> g_played{0};             // frames of the current song that have been heard
std::atomic<int> g_live{-1};                   // the track being heard (-1 = none)
std::atomic<uint32_t> g_liveSeq{0xffffffffu};
std::string g_err; std::atomic<int> g_errSeq{0};   // decoder trouble, for the popup
MDec *g_dec = nullptr; std::atomic<int> g_decTrack{-1};
// main thread
bool g_inited = false, g_want = false; int g_cur = -1, g_last = -1; std::vector<int> g_bag; uint32_t g_shownSeq = 0xffffffffu; double g_started = -1;
int g_errSeen = 0, g_fails = 0; std::string g_errShow; double g_errT = -1e9;
uint32_t g_rs = 12345; int rnd(int n) { g_rs = g_rs * 1103515245u + 12345u; return (int)((g_rs >> 8) % (uint32_t)n); }
}

void mus_init() {
  if (g_inited) return; g_inited = true; DIR = plat_asset_dir() + "music/soundtrack/";
  std::string s; if (!plat_read_file(DIR + "tracks.txt", s)) s.clear();
  size_t a = 0; while (a < s.size()) { size_t e = s.find('\n', a); if (e == std::string::npos) e = s.size(); std::string l = s.substr(a, e - a); a = e + 1;
    if (!l.empty() && l.back() == '\r') l.pop_back(); if (l.empty() || l[0] == '#') continue;
    Track t; size_t p1 = l.find('|'), p2 = p1 == std::string::npos ? p1 : l.find('|', p1 + 1), p3 = p2 == std::string::npos ? p2 : l.find('|', p2 + 1);
    t.file = l.substr(0, p1); if (p1 != std::string::npos) t.artist = l.substr(p1 + 1, p2 - p1 - 1); if (p2 != std::string::npos) t.title = l.substr(p2 + 1, p3 - p2 - 1); if (p3 != std::string::npos) t.secs = atoi(l.c_str() + p3 + 1);
    if (t.title.empty()) t.title = t.file; TR.push_back(t); }
  // your own songs: any MP3 dropped into the save folder's music folder on the memory card (ux0:data/GoalieSimNative/music
  // on the Vita) joins the shuffle - no rebuild. "Artist - Title.mp3" names them.
  { std::string ud = plat_data_dir() + "music/"; auto fs = plat_list_dir(ud); std::sort(fs.begin(), fs.end());
    for (auto &f : fs) { if (f.size() < 5) continue; std::string ext = f.substr(f.size() - 4); for (auto &c : ext) c = (char)std::tolower(c); if (ext != ".mp3") continue;
      Track t; t.file = f; t.path = ud + f; std::string b = f.substr(0, f.size() - 4); size_t d = b.find(" - ");
      if (d != std::string::npos) { t.artist = b.substr(0, d); t.title = b.substr(d + 3); } else { t.title = b; t.artist = "YOUR MUSIC"; }
      TR.push_back(t); g_user++; } }
  g_rs ^= (uint32_t)plat_now_ms() * 2654435761u;
}
static int nextTrack() {   // a shuffled bag: every song once before any repeats, never the same twice in a row
  if (TR.empty()) return -1;
  if (g_bag.empty()) { for (int i = 0; i < (int)TR.size(); i++) g_bag.push_back(i); for (int i = (int)g_bag.size() - 1; i > 0; i--) std::swap(g_bag[(size_t)i], g_bag[(size_t)rnd(i + 1)]);
    if (g_bag.size() > 1 && g_bag.back() == g_last) std::swap(g_bag.front(), g_bag.back()); }
  int t = g_bag.back(); g_bag.pop_back(); g_last = t; return t;
}
static void request(int t) { g_cur = t; g_reqTrack = t; g_req.fetch_add(1); }
int mus_tracks(int *user) { if (!g_inited) mus_init(); if (user) *user = g_user; return (int)TR.size(); }
void mus_skip() { if (g_want) request(nextTrack()); }
void mus_frame(bool want) {
  if (!g_inited) mus_init();
  if (want != g_want) { g_want = want; request(want ? nextTrack() : -1); }
  // the song ran out: on to the next one
  if (g_want && g_cur >= 0 && g_fails < (int)TR.size() && g_endSeq.load() == g_req.load() && g_mixSeq.load() == g_req.load() && g_rd.load() + 2 >= g_wr.load()) request(nextTrack());
  // a song started for real: that's when the popup rises
  uint32_t ls = g_liveSeq.load(); if (ls != g_shownSeq && g_live.load() >= 0) { g_shownSeq = ls; g_started = now(); }
  // trouble: show it, and give up after every song has failed in a row (the next one is picked when it "ends")
  int es = g_errSeq.load(); if (es != g_errSeen) { g_errSeen = es; g_errShow = g_err; g_errT = now(); if (++g_fails >= (int)std::max<size_t>(1, TR.size())) { g_want = false; request(-1); } }
  if (g_live.load() >= 0 && g_played.load() > (uint32_t)g_rate.load() * 5) g_fails = 0;
}
MusNow mus_now() {
  MusNow m; int t = g_live.load(); m.started = g_started; if (now() - g_errT < 6000) m.err = g_errShow;
  if (t >= 0 && t < (int)TR.size()) { m.on = true; m.idx = t; m.title = TR[(size_t)t].title; m.artist = TR[(size_t)t].artist; m.len = TR[(size_t)t].secs; m.pos = (double)g_played.load() / std::max(1, g_rate.load()); }
  return m;
}

// ---------------------------------------------------------------- decoder thread
void mus_pump() {
  uint32_t ms = g_mixSeq.load();
  if (ms != g_pumpSeq.load()) {   // the mixer has faded out and flushed: switch songs
    if (g_dec) { mdec_close(g_dec); g_dec = nullptr; } g_decTrack = -1;
    int t = g_reqTrack.load();
    if (t >= 0 && t < (int)TR.size()) { int rate = 44100; std::string err; g_dec = mdec_open(TR[(size_t)t].path.empty() ? DIR + TR[(size_t)t].file : TR[(size_t)t].path, &rate, &err);
      if (g_dec) { g_decTrack = t; g_rate = rate; } else { g_err = err.empty() ? "CAN'T OPEN " + TR[(size_t)t].file : err; g_errSeq.fetch_add(1); g_endSeq = ms; } }
    g_start = g_wr.load(); g_pumpSeq = ms; return;
  }
  if (!g_dec) return;
  for (int k = 0; k < 8; k++) {   // up to 8 decodes a call, while there's room for a whole MP3 frame
    uint32_t w = g_wr.load(), r = g_rd.load(); if (RN - (int)(w - r) < 2400) return;
    static int16_t tmp[1152 * 2]; int n = mdec_read(g_dec, tmp, 1152);
    if (n <= 0) { if (n < 0) { g_err = "MUSIC DECODE ERROR"; g_errSeq.fetch_add(1); } mdec_close(g_dec); g_dec = nullptr; g_endSeq = ms; return; }
    if (g_mixSeq.load() != ms) return;   // the request changed while decoding: drop it
    for (int i = 0; i < n; i++) { uint32_t j = (w + (uint32_t)i) & RM; RING[j * 2] = tmp[i * 2]; RING[j * 2 + 1] = tmp[i * 2 + 1]; }
    g_wr.store(w + (uint32_t)n);
  }
}

// ---------------------------------------------------------------- audio thread
void mus_mix(float *L, float *R, int n, int outRate) {
  static float gain = 0; static double frac = 0; static bool live = false; const float VOL = .62f;
  uint32_t req = g_req.load(), ms = g_mixSeq.load();
  const float fadeStep = 1.f / (.35f * outRate);   // a third of a second each way
  bool leaving = req != ms;
  if (leaving && (gain <= 0 || !live)) {   // faded out: flush and hand over to the decoder
    gain = 0; live = false; frac = 0; g_live = -1; g_mixSeq = req; return;
  }
  if (!leaving && !live) {   // waiting for the decoder to open the song
    if (g_pumpSeq.load() != ms) return;
    g_rd = g_start.load(); g_played = 0; live = true; gain = 0;
    int t = g_reqTrack.load(); g_live = g_decTrack >= 0 ? t : -1; g_liveSeq = ms;
  }
  if (!live) return;
  const double st = (double)g_rate.load() / outRate; uint32_t rd = g_rd.load(), wr = g_wr.load(), used = 0;
  for (int i = 0; i < n; i++) {
    if (leaving) { gain -= fadeStep; if (gain <= 0) { gain = 0; break; } } else if (gain < 1) gain = std::min(1.f, gain + fadeStep);
    if (wr - rd < 2) { if (leaving) continue; break; }   // nothing decoded yet, or the song ended: silence
    uint32_t a = rd & RM, b = (rd + 1) & RM; float f = (float)frac, g = gain * VOL;
    L[i] += (RING[a * 2] + (RING[b * 2] - RING[a * 2]) * f) * g; R[i] += (RING[a * 2 + 1] + (RING[b * 2 + 1] - RING[a * 2 + 1]) * f) * g;
    frac += st; int adv = (int)frac; frac -= adv; rd += (uint32_t)adv; used += (uint32_t)adv;
  }
  g_rd = rd; g_played.fetch_add(used);
}

// ---------------------------------------------------------------- the now-playing popup
void drawMusicPopup() {
  MusNow m = mus_now(); double t = now();
  bool err = !m.err.empty(); if (!err && (!m.on || m.started < 0)) return;
  double age = err ? 0 : t - m.started, hold = 5200, slide = 420;
  if (!err && age > hold + slide) return;
  double k = err ? 1 : age < slide ? age / slide : age > hold ? 1 - (age - hold) / slide : 1; k = std::max(0.0, std::min(1.0, k)); k = 1 - std::pow(1 - k, 3);
  double w = std::min(.78 * U, W * .5), h = .118 * U, x = .03 * U, y = H - (h + .03 * U) * k;
  ctx.fill(rgba(0, 0, 0, .35)); ctx.rr(x + 3, y + 5, w, h, .02 * U); ctx.fillPath();
  ctx.fill(rgba(10, 14, 28, .94)); ctx.rr(x, y, w, h, .02 * U); ctx.fillPath();
  ctx.fill(rgba(255, 255, 255, .08)); ctx.fillRect(x + .02 * U, y, w - .04 * U, 1.5f);
  // the cover: an equaliser dancing on the accent colour
  double c = h - .024 * U, cx = x + .012 * U, cy = y + .012 * U; Col ac = hex("#f26b5b");
  { Grad g = gLin(0, (float)cy, 0, (float)(cy + c)); g.add(0, ac); g.add(1, hex("#7c2d12")); ctx.fill(g); ctx.rr(cx, cy, c, c, .012 * U); ctx.fillPath(); }
  ctx.fill(rgba(255, 255, 255, .92));
  for (int i = 0; i < 5; i++) { double ph = t / 1000 * (3.1 + i * 1.7) + i * 1.3, hh = c * (.18 + .5 * (.5 + .5 * std::sin(ph)) * (.6 + .4 * std::sin(ph * .37 + i)));
    ctx.fillRect(cx + c * (.17 + i * .14), cy + c * .82 - hh, c * .09, hh); }
  double tx0 = cx + c + .016 * U, tw = x + w - tx0 - .016 * U;
  if (err) { tx("MUSIC", tx0, y + h * .3, .016, hex("#94a3b8"), AL_LEFT, true); txFit(m.err, tx0, y + h * .6, .02, tw, hex("#fca5a5"), AL_LEFT); return; }
  tx("NOW PLAYING", tx0, y + h * .22, .0135, hex("#f26b5b"), AL_LEFT, true);
  txFit(m.title, tx0, y + h * .45, .026, tw, hex("#ffffff"), AL_LEFT);
  txFit(m.artist, tx0, y + h * .68, .017, tw, hex("#cbd5e1"), AL_LEFT);
  double by = y + h * .87, frac = m.len > 0 ? std::min(1.0, m.pos / m.len) : 0;
  ctx.fill(rgba(255, 255, 255, .15)); ctx.fillRect(tx0, by, tw * .78, 3); ctx.fill(ac); ctx.fillRect(tx0, by, tw * .78 * frac, 3);
  auto mmss = [](double s) { int v = (int)s; char b[16]; snprintf(b, sizeof b, "%d:%02d", v / 60, v % 60); return std::string(b); };
  tx(m.len > 0 ? mmss(m.pos) + " / " + mmss(m.len) : mmss(m.pos), tx0 + tw, by + 1.5, .0115, hex("#94a3b8"), AL_RIGHT, false);
}

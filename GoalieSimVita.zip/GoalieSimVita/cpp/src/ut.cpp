// CHL 2026 native - Ultimate Franchise: cards, ratings, packs, the roster and salary cap, CPU opponents, Road to
// the Cup, the game hooks and the save files. Ported line by line from the legacy build (same formulas, same
// random-number order, same save format). The screens are in ut_draw.cpp.
#include "ut_int.h"
#include "sk_int.h"
#include <set>

// WORN (-4), five rarities and the full-art SECRET cards. b = attribute boost, v = quick-sell value.
const RarDef RAR[7] = {{"WORN", -4, "#a08a6c", "#3b2f22", 10}, {"COMMON", 0, "#a8b3c4", "#3b4656", 25}, {"UNCOMMON", 1, "#5ee08a", "#14532d", 60}, {"RARE", 2, "#6aa8ff", "#1e3a8a", 150},
  {"EPIC", 4, "#c99bff", "#4c1d95", 400}, {"LEGENDARY", 6, "#ffd04a", "#7a3a06", 1200}, {"SECRET", 10, "#ff7ac8", "#2a0b3e", 3000}};
const PackDef UT_PACKS[5] = {
  {"ENTRY", 400, 5, "#78716c", {64, 28, 7, 1, 0, 0, 0}, 0, 2.6, 3, false},       // tops out at RARE
  {"STANDARD", 1000, 5, "#64748b", {34, 38, 19, 6.5, 2, .4, .1}, 0, 4.5, -1, false},
  {"PREMIUM", 2500, 4, "#2563eb", {0, 24, 40, 26, 8, 1.7, .3}, 3, 6, -1, false},
  {"ELITE", 6000, 3, "#9333ea", {0, 0, 22, 46, 23, 7.5, 1.5}, 4, 10, -1, false},
  {"LEGENDS", 14000, 1, "#d97706", {0, 0, 0, 0, 70, 25, 5}, 4, 99, -1, true}};
const OppDef UT_OPP[3] = {{"EASY", -4, 120, "#16a34a"}, {"EVEN", 0, 185, "#2563eb"}, {"HARD", 4, 305, "#dc2626"}};
const char *UT_CITY[16] = {"Harbor City", "Northfield", "Iron Range", "Lakeshore", "Bay Point", "Pine Ridge", "Red Rock", "Silver Lake", "Kingsport", "Frost Valley", "Granite Falls", "Cedar Bluff", "Port Royal", "Stonebridge", "Westwind", "Blackwater"};
const char *UT_NICK[16] = {"Wolves", "Storm", "Barons", "Rockets", "Blades", "Kodiaks", "Lynx", "Comets", "Vipers", "Monarchs", "Hammers", "Owls", "Mustangs", "Pilots", "Stingers", "Grizzlies"};
const char *UT_COLS[12][2] = {{"#0b3d91", "#ffffff"}, {"#b91c1c", "#fde68a"}, {"#065f46", "#ecfdf5"}, {"#4c1d95", "#fbbf24"}, {"#111827", "#f97316"}, {"#0e7490", "#e0f2fe"},
  {"#7f1d1d", "#e5e7eb"}, {"#1f2937", "#a3e635"}, {"#9a3412", "#111827"}, {"#be185d", "#fdf2f8"}, {"#1e3a8a", "#facc15"}, {"#334155", "#38bdf8"}};
const char *UT_POS[3] = {"LW", "C", "RW"};
const char *CUP_RN[3] = {"QUARTERFINAL", "SEMIFINAL", "CUP FINAL"};

std::unique_ptr<UTX> utSlots[3];
UTX *UT = nullptr; int utSlot = -1;
static bool g_hasPick = false; static UOpp utPick;
std::string utRet;
bool utHasPick() { return g_hasPick; }
std::string utPreviewSub() {
  if (UT && g_hasPick && utPick.cup && UT->cup) { Cup &C2 = *UT->cup; return C2.phase == "po" ? std::string("ROAD TO THE CUP  |  ") + CUP_RN[std::min(C2.rd, 2)] : "ROAD TO THE CUP  |  GAME " + istr(C2.g + 1) + " / " + istr(CUP_N); }
  return "ULTIMATE FRANCHISE";
}
bool utPickSet(const UOpp &o) { utPick = o; g_hasPick = true; return true; }

UTX &UTX::operator=(const UTX &o) {
  if (this == &o) return *this;
  v = o.v; pv = o.pv; nm = o.nm; col = o.col; coins = o.coins; cards = o.cards; ro = o.ro; n = o.n; w = o.w; l = o.l; gp = o.gp; packs = o.packs;
  opp = o.opp; hasOpp = o.hasOpp; oppFor = o.oppFor; hasCap = o.hasCap; cap = o.cap; capN = o.capN; inv = o.inv;
  cup.reset(o.cup ? new Cup(*o.cup) : nullptr); st = o.st; cs = o.cs; return *this;
}
static std::string lastWordOf(const std::string &s) { size_t p = s.rfind(' '); return p == std::string::npos ? s : s.substr(p + 1); }
std::string utLast(const std::string &nm) { size_t p = nm.find(' '); return p == std::string::npos ? nm : nm.substr(p + 1); }

// ---------------------------------------------------------------- cards
UCard *utCardIn(UTX &X, int u) { if (!u) return nullptr; for (auto &c : X.cards) if (c.u == u) return &c; return nullptr; }
UCard *utCard(int u) { return UT ? utCardIn(*UT, u) : nullptr; }
static std::map<std::string, UBase> UTB;
static const UTPDef DUMMY_P = [] { UTPDef p; p.nm = "?"; p.pos = 'F'; p.ov = 60; p.t = -1; return p; }();
const UBase &utBase(const std::string &k) {
  auto it = UTB.find(k); if (it != UTB.end()) return it->second;
  const UTPDef *P = UTM(k); if (!P) P = &DUMMY_P;
  UBase o;
  withSeed(skHash("base|" + k), [&] {
    if (P->pos == 'G') { o.g = true; o.gs.nm = P->nm; o.gs.r = clamp((P->ov - 32) / 7.0, .5, 9.9); ensureGTraits(o.gs); fitG(o.gs, P->ov); o.grt = gStats(&o.gs); }
    else { o.q.nm = P->nm; o.q.p = 5; o.q.a = 5; ensureTraits(o.q); fitS(o.q, P->ov); o.rt = skRatings(&o.q); }
  });
  return UTB[k] = o;
}
int URat::get(const std::string &k) const { return goalie ? (k == "ovr" ? ovr : (int)g.get(k)) : rt.get(k); }
static std::map<std::string, URat> UTRT;
const URat &utRat(const UCard &c) {
  std::string key = c.p + "|" + istr(c.r); auto it = UTRT.find(key); if (it != UTRT.end()) return it->second;
  const UTPDef *P = UTM(c.p); bool G = P && P->pos == 'G'; const UBase &B = utBase(c.p);
  int b0 = RAR[c.r].b, b = P && P->leg && b0 > 0 ? (int)jround(b0 * .3) : b0;
  URat o; o.goalie = G;
  auto base = [&](const std::string &k) -> double { return G ? B.grt.get(k) : B.rt.get(k); };
  int nk = G ? 8 : 13; const char *const *ks = G ? UT_GK : UT_SK;
  double mean = 0; for (int i = 0; i < nk; i++) mean += base(ks[i]); mean /= nk; double amp = std::max(0, b0) / 22.0;
  int sum = 0;
  for (int i = 0; i < nk; i++) { int v = (int)jround(clamp(mean + (base(ks[i]) - mean) * (1 + amp) + b, 40, 99)); sum += v;
    if (G) { std::string k = ks[i]; if (k == "agi") o.g.agi = v; else if (k == "glv") o.g.glv = v; else if (k == "blk") o.g.blk = v; else if (k == "pad") o.g.pad = v;
      else if (k == "chs") o.g.chs = v; else if (k == "sta") o.g.sta = v; else if (k == "rec") o.g.rec = v; else o.g.rd = v; }
    else o.rt.set(ks[i], v); }
  o.ovr = (int)jround((double)sum / nk);
  if (G) o.g.ovr = o.ovr;
  else for (auto k : BHKEYS) o.rt.set(k, (int)jround(clamp(mean + (B.rt.get(k) - mean) * (1 + amp) + b, 40, 99)));   // backhands: shown, not in overall
  o.ar = G ? (B.gs.gar.empty() ? "HYBRID" : B.gs.gar) : ARN[B.q.ar];
  return UTRT[key] = o;
}
int utOv(const UCard &c) { return UTM(c.p) ? utRat(c).ovr : 50; }
int utVal(const UCard &c) { const UTPDef *P = UTM(c.p); return RAR[c.r].v * (P && P->leg ? 2 : 1); }
std::vector<PerkE> pkCard(const UCard &c) {
  const UTPDef *P = UTM(c.p); if (!P) return {}; const URat &R = utRat(c);
  return pkAuto([&](const std::string &k) { return R.get(k); }, R.ovr, P->pos == 'G', P->nm + "|" + istr(c.r));
}
// a card as a player the game engine understands (fixed per player + rarity, so he always plays the same)
static std::map<std::string, std::unique_ptr<Src>> UTS; static std::map<std::string, std::unique_ptr<GSrc>> UTSG;
Src *utSrc(const UCard &c) {
  std::string key = c.p + "|" + istr(c.r); auto it = UTS.find(key); if (it != UTS.end()) return it->second.get();
  const URat &R = utRat(c); const UBase &B = utBase(c.p); const UTPDef *P = UTM(c.p);
  std::string sd = (P ? P->nm : std::string("?")) + "|" + istr(c.r);
  Src t = B.q; t.hasRt = false; fitS(t, R.ovr);
  auto *s = new Src(B.q); s->p = t.p; s->a = t.a; s->hasRt = true; s->rt = R.rt; s->star = R.ovr >= 88; s->utk = c.p; s->pkSeed = sd; s->tend = TD_NONE;
  UTS[key].reset(s); return s;
}
GSrc *utGSrc(const UCard &c) {
  std::string key = c.p + "|" + istr(c.r); auto it = UTSG.find(key); if (it != UTSG.end()) return it->second.get();
  const URat &R = utRat(c); const UBase &B = utBase(c.p); const UTPDef *P = UTM(c.p);
  auto *s = new GSrc(B.gs); s->hasGst = true; s->gst = R.g; s->r = clamp((R.ovr - 32) / 7.0, .5, 9.9); s->utk = c.p; s->pkSeed = (P ? P->nm : std::string("?")) + "|" + istr(c.r);
  UTSG[key].reset(s); return s;
}

// ---------------------------------------------------------------- the roster: ro[0..8] = line 1 LW C RW, line 2, line 3; ro[9], ro[10] = goalies
// SALARY CAP: every card has a salary (higher OVR and rarity cost a lot more); your 11-man lineup has to fit
// under your cap. Coins buy more cap space, each raise dearer than the last.
double utSal(const UCard &c) { if (!UTM(c.p)) return 0; int o = utOv(c), b = std::max(0, RAR[c.r].b); return jround((.5 + std::pow(std::max(0, o - 64), 1.9) * .018 + b * .1) * 10) / 10; }
double utPay(const UTX &X, const std::vector<int> *ro) {
  double a = 0; for (int u : ro ? *ro : X.ro) { for (auto &c : X.cards) if (u && c.u == u) { a += utSal(c); break; } }
  return jround(a * 10) / 10;
}
int utCapCost(const UTX &X) { return (int)jround(1500 * std::pow(1.35, X.capN) / 50) * 50; }
double utCapCheck(UTX &X) { if (!X.hasCap) { X.cap = std::max((double)UT_CAP0, std::ceil(utPay(X))); X.capN = 0; X.hasCap = true; } return X.cap; }
void utBuyCap(UTX &X) {
  int c = utCapCost(X); if (X.coins < c) { utFlash("NOT ENOUGH COINS - " + fmtN(c) + " FOR THE NEXT RAISE"); return; }
  UTX *px = &X;
  askModal("RAISE THE SALARY CAP?", "+" + fmtM(UT_CAPSTEP) + " of cap space (to " + fmtM(X.cap + UT_CAPSTEP) + ") for " + fmtN(c) + " coins. The next raise costs more.",
    [px, c] { px->coins -= c; px->cap += UT_CAPSTEP; px->capN++; utSave(); utFlash("SALARY CAP RAISED TO " + fmtM(px->cap)); });
}
static int ovOrW(const UTX &X, int u) { for (auto &c : X.cards) if (u && c.u == u) return utOv(c); return 50; }
int utTeamOv(const UTX &X) {
  double sk = 0; for (int i = 0; i < 9; i++) sk += ovOrW(X, i < (int)X.ro.size() ? X.ro[i] : 0); sk /= 9;
  return (int)jround(.78 * sk + .22 * ovOrW(X, X.ro.size() > 9 ? X.ro[9] : 0));
}
bool utFull(const UTX &X) { if (X.ro.size() < 11) return false; for (int u : X.ro) { bool ok = false; if (u) for (auto &c : X.cards) if (c.u == u) { ok = true; break; } if (!ok) return false; } return true; }
void utAuto(UTX &X) {
  double cap = X.hasCap ? X.cap : 1e9;
  auto by = [&](char pos) { std::vector<UCard *> v; for (auto &c : X.cards) { const UTPDef *P = UTM(c.p); if (P && P->pos == pos) v.push_back(&c); }
    std::stable_sort(v.begin(), v.end(), [](UCard *a, UCard *b) { int d = utOv(*b) - utOv(*a); if (d) return d < 0; return utSal(*a) < utSal(*b); }); return v; };
  std::vector<UCard *> poolF = by('F'), poolG = by('G'); const int order[11] = {9, 1, 0, 2, 4, 3, 5, 10, 7, 6, 8};
  std::vector<int> ro(11, 0); std::set<int> used; std::set<std::string> usedP;
  auto freeOf = [&](char pos) { std::vector<UCard *> o; for (UCard *c : pos == 'G' ? poolG : poolF) if (!used.count(c->u) && !usedP.count(c->p)) o.push_back(c); return o; };
  auto bySal = [](std::vector<UCard *> v) { std::stable_sort(v.begin(), v.end(), [](UCard *a, UCard *b) { return utSal(*a) < utSal(*b); }); return v; };
  // the cheapest way to fill the slots still to come (so an early pick never leaves the rest unaffordable)
  auto reserve = [&](int k) { double t = 0; std::set<int> tkU[2]; std::set<std::string> tkP[2];
    for (int j = k; j < 11; j++) { int pi = order[j] >= 9 ? 1 : 0; std::vector<UCard *> f; for (UCard *q : freeOf(pi ? 'G' : 'F')) if (!tkU[pi].count(q->u) && !tkP[pi].count(q->p)) f.push_back(q);
      f = bySal(f); if (!f.empty()) { t += utSal(*f[0]); tkU[pi].insert(f[0]->u); tkP[pi].insert(f[0]->p); } }
    return t; };
  double left = cap;
  for (int k = 0; k < 11; k++) { int si = order[k]; char pos = si >= 9 ? 'G' : 'F'; double room = left - reserve(k + 1);
    std::vector<UCard *> f = freeOf(pos); UCard *c = nullptr; for (UCard *q : f) if (utSal(*q) <= room + 1e-6) { c = q; break; }
    if (!c) { f = bySal(f); if (!f.empty()) c = f[0]; }
    if (c) { ro[si] = c->u; used.insert(c->u); usedP.insert(c->p); left -= utSal(*c); } }
  X.ro = ro;
}

// ---------------------------------------------------------------- CPU teams
// built near the target OVR from league players (and made-up ones below the league's floor)
struct ORoster { std::vector<std::unique_ptr<Src>> sk; std::unique_ptr<GSrc> g1, g2; };
static void utOppRoster(const UOpp &o, ORoster &R) {
  R.sk.clear();
  withSeed((int)o.seed, [&] {
    std::set<std::string> used;
    auto pickNm = [&](char pos, int d) { std::vector<const UTPDef *> c; for (auto *p : UT_CUR) if (p->pos == pos && !p->dr && std::abs(p->ov - d) <= 3 && !used.count(p->nm)) c.push_back(p);
      std::string nm = !c.empty() && rnd() < .75 ? c[(int)std::floor(rnd() * c.size())]->nm : genName(); if (used.count(nm)) nm = genName(); used.insert(nm); return nm; };
    for (int i = 0; i < 9; i++) { int d = (int)clamp(jround(o.ov + 1 + rand(-2.5, 2.5) - i * .25), 45, 99); auto *q = new Src(); q->nm = pickNm('F', d); q->p = 5; q->a = 5; q->star = d >= 88;
      ensureTraits(*q); fitS(*q, d); R.sk.emplace_back(q); }
    std::stable_sort(R.sk.begin(), R.sk.end(), [](const std::unique_ptr<Src> &a, const std::unique_ptr<Src> &b) { return ovSk(b.get()) < ovSk(a.get()); });
    for (int i = 0; i < 2; i++) { int d = (int)clamp(jround(o.ov + rand(-2, 2) - i * 3), 45, 99); auto *g = new GSrc(); g->nm = pickNm('G', d); g->r = clamp((d - 32) / 7.0, .5, 9.9);
      ensureGTraits(*g); fitG(*g, d); (i ? R.g2 : R.g1).reset(g); }
  });
}
int utOppOv(const UOpp &o) {
  ORoster R; utOppRoster(o, R); double s = 0; for (auto &q : R.sk) s += ovSk(q.get());
  return (int)jround(.78 * s / R.sk.size() + .22 * gStats(R.g1.get()).ovr);
}
static std::string utTeamName(std::set<std::string> &used, int tries) {
  std::string nm; int n = 0;
  do { nm = std::string(UT_CITY[(int)std::floor(rnd() * 16)]) + " " + UT_NICK[(int)std::floor(rnd() * 16)]; } while (used.count(lastWordOf(nm)) && n++ < tries);
  used.insert(lastWordOf(nm)); return nm;
}
// EASY is never better than you, EVEN is within 2, HARD is always better (by a little or a lot).
// The OVR shown is the generated roster's real OVR, worked out the same way as yours.
void utGenOpp(UTX &X) {
  int my = utTeamOv(X); std::set<std::string> used; X.oppFor = my;
  int w0 = my - rint(0, 6), w1 = my + rint(-2, 2); int w2 = my + (rnd() < .5 ? rint(1, 3) : rint(5, 10));
  int want[3] = {(int)clamp(w0, 50, 99), (int)clamp(w1, 50, 99), (int)clamp(w2, 50, 99)};
  auto okFor = [&](int k, int v) { return k == 0 ? v <= my : k == 1 ? std::abs(v - my) <= 2 : (v > my || (my >= 99 && v >= 99)); };
  X.opp.clear();
  for (int k = 0; k < 3; k++) {
    UOpp o; o.nm = utTeamName(used, 20); int col; do { col = (int)std::floor(rnd() * 12); } while (col == X.col);
    o.col = col; o.ov = want[k]; o.seed = std::floor(rnd() * 1e9); o.k = k; int act = utOppOv(o);
    for (int i = 0; i < 14 && (act != want[k] || !okFor(k, act)); i++) {
      if (i >= 6 && okFor(k, act)) break;                                   // close enough, and inside the rule
      int st = want[k] - act; if (!st) st = k == 0 ? -1 : 1; int sg = st > 0 ? 1 : -1;
      o.ov = (int)clamp(o.ov + (okFor(k, act) ? st : st + sg), 45, 105); act = utOppOv(o); }
    o.tov = act; X.opp.push_back(o);
  }
  X.hasOpp = true;
}
// the lineup Ultimate Franchise sends out (cup games: the locked one)
void utGameRosters(Rosters &R) {
  UTX &X = *UT; const UOpp &o = utPick; bool cupL = o.cup && X.cup && X.cup->hasLock;
  std::vector<ULock> lk; if (cupL) lk = X.cup->lock; else for (int u : X.ro) { ULock l; UCard *c = utCard(u); if (c) { l.on = true; l.p = c->p; l.r = c->r; } lk.push_back(l); }
  auto card = [&](int i) { UCard c; c.p = lk[i].p; c.r = lk[i].r; return c; };
  R.ut = true;
  for (int l = 0; l < 3; l++) { std::vector<Src *> L; for (int i : {l * 3 + 1, l * 3, l * 3 + 2}) L.push_back(utSrc(card(i))); R.hl.push_back(L); }   // [C, LW, RW]: you take the center
  for (auto &L : R.hl) R.home.insert(R.home.end(), L.begin(), L.end());
  GSrc *g1 = utGSrc(card(9)), *g2 = utGSrc(card(10));
  ORoster O; utOppRoster(o, O);
  for (int l = 0; l < 3; l++) { std::vector<Src *> L; for (int i = 0; i < 3; i++) L.push_back(O.sk[l * 3 + i].get()); R.al.push_back(L); }
  for (auto &L : R.al) R.away.insert(R.away.end(), L.begin(), L.end());
  const char *const *hc = UT_COLS[X.col % 12], *const *ac = UT_COLS[o.col % 12];
  R.hg = g1->r; R.ag = O.g1->r; R.hn = X.nm; R.an = o.nm; R.hc = hex(hc[0]); R.ac = hex(ac[0]); R.hs = hex(hc[1]); R.as = hex(ac[1]);
  R.hgn = g1->nm; R.agn = O.g1->nm; R.hgs = gStats(g1); R.ags = gStats(O.g1.get()); R.hbk = g2; R.abk = O.g2.get(); R.hgo = g1; R.ago = O.g1.get();
  for (auto &q : O.sk) R.own.push_back(std::move(q)); R.gown.push_back(std::move(O.g1)); R.gown.push_back(std::move(O.g2));
}
// the lineup card before the puck drops: your card players' numbers with you, the other side's season so far
void skPvFake(PvTeam &o, const std::vector<Skater *> &on, const Goalie &G, int seed, double ovd);
bool utPreview(int ti, PvTeam &o, const std::vector<Skater *> &on, const Goalie &G) {
  if (!UT || !g_hasPick) return false;
  const UOpp &P = utPick; bool cup = P.cup && UT->cup;
  if (ti == 0) { auto &st = cup ? UT->cup->st : UT->st; auto S = [&](const std::string &k) { auto it = st.find(k); return it == st.end() ? UStat() : it->second; };
    o.rec = cup ? istr(UT->cup->T[0].w) + "-" + istr(UT->cup->T[0].l) : istr(UT->w) + "-" + istr(UT->l); o.recL = cup ? "CUP RECORD" : "RECORD";
    o.sk.clear(); for (Skater *p : on) o.sk.push_back({roleName(p->role), p->nm, S(p->src ? p->src->utk : "").g, p->pks});
    UStat q = S(G.src ? G.src->utk : ""); o.hasG = true; o.gk = {"G", G.nm, 0, G.pks}; o.gsv = svp(q.sv, q.sa); o.gsub = istr(q.w) + "-" + istr(q.l); }
  else if (cup && P.ci >= 0) {
    const CupTeam &t = UT->cup->T[P.ci]; int gp = t.w + t.l; o.rec = istr(t.w) + "-" + istr(t.l); o.recL = "CUP RECORD";
    withSeed((int)t.seed + 11, [&] { double wts[9], sum = 0; for (int i = 0; i < 9; i++) { wts[i] = (1.6 - i * .12) * rand(.6, 1.4); sum += wts[i]; }
      o.sk.clear(); for (size_t i = 0; i < on.size(); i++) o.sk.push_back({roleName(on[i]->role), on[i]->nm, (int)std::floor(t.gf * wts[i] / sum), on[i]->pks}); });
    int sa = gp * 30; o.hasG = true; o.gk = {"G", G.nm, 0, G.pks}; o.gsv = svp(sa - t.ga, sa); o.gsub = istr(t.w) + "-" + istr(t.l); }
  else { skPvFake(o, on, G, (int)P.seed + 7, (P.tov ? P.tov : 70) - utTeamOv(*UT)); }
  return true;
}

// ---------------------------------------------------------------- files
void utNew(int i, const std::string &nm) {
  auto low = [](char pos) { std::vector<const UTPDef *> v; for (auto *p : UT_CUR) if (p->pos == pos && !p->dr) v.push_back(p);
    std::stable_sort(v.begin(), v.end(), [](const UTPDef *a, const UTPDef *b) { if (a->ov != b->ov) return a->ov < b->ov; return a->k < b->k; }); return v; };
  auto *X = new UTX(); X->nm = nm; X->col = (int)std::floor(rnd() * 12); X->coins = 500; X->n = 1; X->hasCap = true; X->cap = UT_CAP0; X->capN = 0;
  auto F = low('F'), G = low('G');
  for (int k = 0; k < 9 && k < (int)F.size(); k++) X->cards.push_back({X->n++, F[k]->k, 0});   // the benchwarmers: all WORN
  for (int k = 0; k < 2 && k < (int)G.size(); k++) X->cards.push_back({X->n++, G[k]->k, 0});
  utAuto(*X); utGenOpp(*X);
  utSlots[i].reset(X); utLoad(i); utFlash("YOUR WORN BENCHWARMERS ARE READY - 500 COINS TO START");
}
void utLoad(int i) {
  utSlot = i; UT = utSlots[i].get(); if (!UT) return; utCapCheck(*UT); if (!UT->hasOpp || UT->opp.size() < 3) utGenOpp(*UT);
  mode = "ut"; screen = "main"; utSel = 0; utPage = 0; utSell = false; utOpenOn = false; setLast("ut", i); utSave();
}
void utAskDel(int i) {
  if (!utSlots[i]) return;
  askModal("DELETE FILE " + istr(i + 1) + "?", "ARE YOU SURE? " + utSlots[i]->nm + " and every card will be gone.", [i] { utSlots[i].reset(); if (utSlot == i) { utSlot = -1; UT = nullptr; } utSave(); mFocus = "uslot:" + istr(i); });
}
void utLeave() { utSave(); utMenuOnF = false; utExOnF = false; goMode("MAIN MENU", [] { mode = "quick"; screen = "modes"; }, hex("#475569"), false); }

// ---------------------------------------------------------------- after a game
// coins: the win reward (a quarter of it for a loss) plus 8 a goal; goals against take goal coins back. Quitting pays nothing.
static std::string cupAfter(UTX &X, bool won, int gf, int ga);
int utAfter(bool won, bool quit) {
  if (!UT || !g_hasPick) return 0; UOpp o = utPick; UTX &X = *UT;
  int hs = SK ? SK->T[0].score : 0, ga = SK ? SK->T[1].score : 0;
  int c = quit ? 0 : (won ? UT_OPP[o.k].c : (int)jround(UT_OPP[o.k].c * .25)) + std::max(0, 8 * hs - 8 * ga);
  X.coins += c; X.gp++; if (won) X.w++; else X.l++;
  // your players' stats: per card player, the season of the run (cup) or all-time (everything else)
  if (!quit && SK) {
    bool cupL = o.cup && X.cup && X.cup->hasLock; std::vector<ULock> lk; if (cupL) lk = X.cup->lock; else for (int u : X.ro) { ULock l; UCard *cc = utCard(u); if (cc) { l.on = true; l.p = cc->p; l.r = cc->r; } lk.push_back(l); }
    auto &st = o.cup && X.cup ? X.cup->st : X.st;
    for (int i = 0; i < 9 && i < (int)lk.size(); i++) if (lk[i].on) st[lk[i].p].gp++;
    for (auto &e : SK->utG) st[e.first].g += e.second; for (auto &e : SK->utA) st[e.first].a += e.second;
    int sa = SK->T[1].sog;
    if (lk.size() > 9 && lk[9].on) { UStat &q = st[lk[9].p]; q.gp++; q.sa += sa; q.sv += std::max(0, sa - ga); if (won) q.w++; else q.l++; }
    // the card's own line: kept for as long as you own the player (upgrades share it), reset when he's sold
    for (int i = 0; i < 9 && i < (int)lk.size(); i++) if (lk[i].on) X.cs[lk[i].p].gp++;
    for (auto &e : SK->utG) X.cs[e.first].g += e.second; for (auto &e : SK->utA) X.cs[e.first].a += e.second; for (auto &e : SK->utPM) X.cs[e.first].pm += e.second;
    if (lk.size() > 9 && lk[9].on) { UCStat &q = X.cs[lk[9].p]; q.gp++; q.sa += sa; q.ga += ga; q.sv += std::max(0, sa - ga); if (won) q.w++; else q.l++; if (ga == 0) q.so++; }
  }
  std::string cl = o.cup ? cupAfter(X, won && !quit, hs, quit ? std::max(ga, hs + 1) : ga) : "";
  utGenOpp(X); g_hasPick = false; utSave();
  utFlash(cl.rfind("CUP CHAMP", 0) == 0 ? cl : (quit ? std::string("MATCH QUIT - NO COINS") : std::string(won ? "WIN" : "LOSS") + "  +" + istr(c) + " COINS") + (cl.empty() ? "" : "   |   " + cl));
  return c;
}

// ---------------------------------------------------------------- ROAD TO THE CUP
// 16 teams in two divisions of 8, a 20-game season, the top 4 of each division play single-game knockout
// rounds. Win the Cup: 3 Standard packs go to your INVENTORY.
static std::pair<int, int> cupSimScore(int a, int b) {
  double p = 1 / (1 + std::exp(-(a - b) / 5.0)); int sa = poisson(2.2 + 1.6 * p), sb = poisson(2.2 + 1.6 * (1 - p));
  if (sa == sb) { if (rnd() < p) sa++; else sb++; } return {sa, sb};
}
// the lineup is locked for the whole run: a copy of the cards (player + rarity) taken at the start
int cupLockOv(const std::vector<ULock> &L) {
  auto ov = [&](int i) { if (i >= (int)L.size() || !L[i].on) return 50; UCard c; c.p = L[i].p; c.r = L[i].r; return utOv(c); };
  double s = 0; for (int i = 0; i < 9; i++) s += ov(i); return (int)jround(.78 * s / 9 + .22 * ov(9));
}
void cupNew(UTX &X) {
  auto *C2 = new Cup(); C2->hasLock = true;
  for (int u : X.ro) { ULock l; UCard *c = utCardIn(X, u); if (c) { l.on = true; l.p = c->p; l.r = c->r; } C2->lock.push_back(l); }
  int my = cupLockOv(C2->lock); std::set<std::string> used = {lastWordOf(X.nm)};
  CupTeam me; me.nm = X.nm; me.col = X.col; me.tov = my; me.me = true; C2->T.push_back(me);
  for (int i = 1; i < 16; i++) { CupTeam o; o.nm = utTeamName(used, 40); o.col = (int)std::floor(rnd() * 12); o.ov = (int)clamp(my + rint(-6, 7), 45, 99); o.seed = std::floor(rnd() * 1e9); o.div = i < 8 ? 0 : 1;
    UOpp q; q.ov = o.ov; q.seed = o.seed; o.tov = utOppOv(q); C2->T.push_back(o); }
  std::vector<int> other = {8, 9, 10, 11, 12, 13, 14, 15}; shuffle(other); other.resize(6);
  std::vector<int> sched = {1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7}; sched.insert(sched.end(), other.begin(), other.end()); shuffle(sched);
  C2->sched = sched; X.cup.reset(C2); utSave();
}
static void cupLog(Cup &C2, int a, int b, int sa, int sb) { CupTeam &A = C2.T[a], &B = C2.T[b]; A.gf += sa; A.ga += sb; B.gf += sb; B.ga += sa; if (sa > sb) { A.w++; B.l++; } else { B.w++; A.l++; } }
int cupPts(const CupTeam &t) { return t.w * 2; }
std::vector<int> cupStand(const Cup &C2, int div) {
  std::vector<int> o; for (int i = 0; i < (int)C2.T.size(); i++) if (C2.T[i].div == div) o.push_back(i);
  std::stable_sort(o.begin(), o.end(), [&](int a, int b) { const CupTeam &A = C2.T[a], &B = C2.T[b];
    if (cupPts(A) != cupPts(B)) return cupPts(A) > cupPts(B); int da = A.gf - A.ga, db = B.gf - B.ga; if (da != db) return da > db; return A.gf > B.gf; });
  return o;
}
// one round of the season: your game is already logged; everyone else is paired up and simmed
static void cupSimRound(Cup &C2, std::vector<int> skip) {
  std::vector<int> fr; for (int i = 0; i < (int)C2.T.size(); i++) if (std::find(skip.begin(), skip.end(), i) == skip.end()) fr.push_back(i); shuffle(fr);
  for (size_t i = 0; i + 1 < fr.size(); i += 2) { auto s = cupSimScore(C2.T[fr[i]].tov, C2.T[fr[i + 1]].tov); cupLog(C2, fr[i], fr[i + 1], s.first, s.second); }
}
static void cupFinishSim(Cup &C2);
static void cupStartPO(Cup &C2) {
  auto d0 = cupStand(C2, 0), d1 = cupStand(C2, 1); auto m = [](int a, int b) { CupMatch x; x.a = a; x.b = b; return x; };
  C2.br = {{m(d0[0], d0[3]), m(d0[1], d0[2]), m(d1[0], d1[3]), m(d1[1], d1[2])}, {}, {}}; C2.hasBr = true; C2.rd = 0; C2.phase = "po";
  bool in = false; for (auto &x : C2.br[0]) if (x.a == 0 || x.b == 0) in = true;
  if (!in) { C2.out = "MISSED THE PLAYOFFS"; cupFinishSim(C2); }
}
static CupMatch *cupMyMatch(Cup &C2) { if (C2.phase != "po" || C2.rd >= (int)C2.br.size()) return nullptr; for (auto &x : C2.br[C2.rd]) if ((x.a == 0 || x.b == 0) && x.w < 0) return &x; return nullptr; }
static void cupDecide(CupMatch &x, int sa, int sb) { x.sa = sa; x.sb = sb; x.w = sa > sb ? x.a : x.b; }
static void cupNextRound(Cup &C2) {
  auto &R = C2.br[C2.rd]; for (auto &x : R) if (x.w < 0) { auto s = cupSimScore(C2.T[x.a].tov, C2.T[x.b].tov); cupDecide(x, s.first, s.second); }
  if (C2.rd == 2) { C2.champ = R[0].w; C2.phase = "done"; return; }
  std::vector<CupMatch> nx; for (size_t i = 0; i + 1 < R.size(); i += 2) { CupMatch x; x.a = R[i].w; x.b = R[i + 1].w; nx.push_back(x); }
  C2.rd++; C2.br[C2.rd] = nx;
}
static void cupFinishSim(Cup &C2) { while (C2.phase == "po") cupNextRound(C2); }
// your game result (from utAfter). Returns a line for the result toast.
static std::string cupAfter(UTX &X, bool won, int gf, int ga) {
  if (!X.cup) return ""; Cup &C2 = *X.cup;
  if (C2.phase == "reg") {
    int o = C2.sched[C2.g]; cupLog(C2, 0, o, gf, ga); cupSimRound(C2, {0, o}); C2.g++;
    if (C2.g >= CUP_N) { cupStartPO(C2); return !C2.out.empty() ? "SEASON OVER - " + C2.out : std::string("PLAYOFFS! ") + CUP_RN[0] + " NEXT"; }
    return "GAME " + istr(C2.g) + " / " + istr(CUP_N);
  }
  if (C2.phase == "po") {
    CupMatch *x = cupMyMatch(C2); if (!x) return ""; bool mineA = x->a == 0; cupDecide(*x, mineA ? gf : ga, mineA ? ga : gf);
    std::string rn = CUP_RN[C2.rd];
    if (!won) { C2.out = "OUT IN THE " + rn; cupFinishSim(C2); return "ELIMINATED IN THE " + rn; }
    cupNextRound(C2);
    if (C2.phase == "done" && C2.champ == 0) { for (int k = 0; k < 3; k++) X.inv.push_back(1); return "CUP CHAMPIONS! 3 STANDARD PACKS IN YOUR INVENTORY"; }
    return std::string("ON TO THE ") + CUP_RN[C2.rd];
  }
  return "";
}
bool cupOppPick(UTX &X, UOpp &op) {
  if (!X.cup) return false; Cup &C2 = *X.cup; int oi = -1;
  if (C2.phase == "reg") oi = C2.g < (int)C2.sched.size() ? C2.sched[C2.g] : -1; else { CupMatch *x = cupMyMatch(C2); if (x) oi = x->a == 0 ? x->b : x->a; }
  if (oi < 0) return false; const CupTeam &t = C2.T[oi];
  op = UOpp(); op.nm = t.nm; op.col = t.col; op.ov = t.ov; op.tov = t.tov; op.seed = t.seed; op.k = 1; op.cup = true; op.ci = oi; return true;
}

// ---------------------------------------------------------------- packs
static int utRoll(const PackDef &pk, int minR) {
  double w[7], tot = 0; for (int i = 0; i < 7; i++) { w[i] = i < minR ? 0 : pk.w[i]; tot += w[i]; }
  double r = rnd() * tot; for (int i = 0; i < 7; i++) { r -= w[i]; if (r < 0) return i; }
  return 5;
}
// legends only show up at EPIC and above (always in the Legends pack); higher packs make the stars easier to find
static const UTPDef *utPickPlayer(const PackDef &pk, int r) {
  const auto &pool = pk.leg || (r >= 4 && rnd() < (r == 6 ? .25 : r == 5 ? .15 : .06)) ? UT_LEGP : UT_CUR;
  std::vector<double> w(pool.size()); double tot = 0; for (size_t i = 0; i < pool.size(); i++) { w[i] = std::exp(-(pool[i]->ov - 72) / pk.sk); tot += w[i]; }
  double x = rnd() * tot; for (size_t i = 0; i < pool.size(); i++) { x -= w[i]; if (x < 0) return pool[i]; } return pool.back();
}
// the shop only sells: a bought pack goes to the INVENTORY, where it's opened
void utBuy(int t) {
  if (!UT || t < 0 || t > 4) return; const PackDef &pk = UT_PACKS[t]; if (UT->coins < pk.c) return;
  UT->coins -= pk.c; UT->inv.push_back(t); utSave();
  int n = 0; for (int q : UT->inv) if (q == t) n++; utFlash(std::string(pk.n) + " PACK ADDED TO YOUR INVENTORY  (" + istr(n) + " OWNED)");
}
void utOpenPack(int t, bool free) {
  if (!UT || t < 0 || t > 4) return; const PackDef &pk = UT_PACKS[t]; if (!free && UT->coins < pk.c) return;
  if (!free) UT->coins -= pk.c; UT->packs++;
  std::vector<UOpenCard> out;
  for (int i = 0; i < pk.k; i++) { int r = utRoll(pk, i == 0 ? pk.g : 0); const UTPDef *P = utPickPlayer(pk, r);
    bool isNew = true; for (auto &c : UT->cards) if (c.p == P->k && c.r == r) isNew = false; for (auto &o : out) if (o.c.p == P->k && o.c.r == r) isNew = false;
    UCard c{UT->n++, P->k, r}; out.push_back({c, isNew}); }
  std::stable_sort(out.begin(), out.end(), [](const UOpenCard &a, const UOpenCard &b) { if (a.c.r != b.c.r) return a.c.r < b.c.r; return utOv(a.c) < utOv(b.c); });   // the best card is flipped last
  for (auto &o : out) UT->cards.push_back(o.c);
  utSave();
  utOpen = UOpen(); utOpen.t = t; utOpen.cards = out; utOpen.t0 = now(); utOpen.free = free; utOpenOn = true; screen = "utopen"; mFocus.clear();
}
void utInvOpen(int t) { if (!UT) return; auto it = std::find(UT->inv.begin(), UT->inv.end(), t); if (it == UT->inv.end()) return; UT->inv.erase(it); utOpenPack(t, true); }
static std::string pctS(double v) { return v >= 10 ? istr((long long)jround(v)) + "%" : v >= 1 ? fixed(v, 1) + "%" : fixed(v, 2) + "%"; }
std::pair<std::string, std::string> utOddsTxt(const PackDef &pk) {
  double tot = 0; for (double v : pk.w) tot += v; auto pc = [&](int i) { double s = 0; for (int k = i; k < 7; k++) s += pk.w[k]; return s / tot * 100; };
  if (pk.leg) return {"A RETIRED LEGEND", "EPIC+ GUARANTEED"};
  if (pk.top >= 0) return {"WORN " + pctS(pk.w[0] / tot * 100) + "   RARE " + pctS(pc(3)), std::string("NOTHING ABOVE ") + RAR[pk.top].n};
  int k = std::max(4, pk.g + 1); auto nm = [](int i) { return i == 6 ? std::string("SECRET ") : i == 5 ? std::string("LEGEND+ ") : std::string(RAR[std::min(i, 6)].n) + "+ "; };
  return {pk.g ? std::string(RAR[pk.g].n) + "+ GUARANTEED" : "WORN " + pctS(pk.w[0] / tot * 100) + "   RARE+ " + pctS(pc(3)), nm(k) + pctS(pc(k)) + "   " + nm(k + 1) + pctS(pc(k + 1))};
}

// ---------------------------------------------------------------- roster editing
std::string utSlotName(int i) { return i >= 9 ? (i == 9 ? "G1" : "G2") : "L" + istr(i / 3 + 1) + " " + UT_POS[i % 3]; }
bool utAssign(int si, int u) {
  UTX &X = *UT; UCard *c = utCard(u); if (!c || !UTM(c->p)) return false;
  if ((UTM(c->p)->pos == 'G') != (si >= 9)) return false;
  std::vector<int> ro = X.ro; int cur = -1; for (int i = 0; i < (int)ro.size(); i++) if (ro[i] == u) cur = i;
  if (cur == si) return false;
  if (cur >= 0) { ro[cur] = ro[si]; ro[si] = u; }
  else { int dup = -1; for (int i = 0; i < (int)ro.size(); i++) { if (i == si || !ro[i]) continue; UCard *q = utCard(ro[i]); if (q && q->p == c->p) { dup = i; break; } } if (dup >= 0) ro[dup] = ro[si]; ro[si] = u; }
  double pay = utPay(X, &ro), cap = utCapCheck(X);
  if (pay > cap + 1e-6 && pay > utPay(X)) { utFlash("OVER THE SALARY CAP BY " + fmtM(pay - cap) + " - PICK A CHEAPER CARD OR RAISE THE CAP IN THE SHOP"); return false; }
  X.ro = ro; utSave(); return true;
}
static bool inRo(int u) { if (!UT || !u) return false; return std::find(UT->ro.begin(), UT->ro.end(), u) != UT->ro.end(); }
// three spare copies of the same player at the same rarity raise this card one rarity (it keeps its lineup spot)
std::vector<UCard *> utDupesOf(const UCard &c) { std::vector<UCard *> o; for (auto &q : UT->cards) if (q.p == c.p && q.r == c.r && q.u != c.u && !inRo(q.u)) o.push_back(&q); return o; }
void utAskUp(int u, double x, double y, double w) {
  UCard *c = utCard(u); if (!c || c->r >= 6) return; auto d = utDupesOf(*c);
  if (d.size() < 3) { utFlash(std::string("NEED 3 SPARE ") + RAR[c->r].n + " COPIES OF " + upper(UTM(c->p)->nm)); return; }
  askModal(std::string("UPGRADE TO ") + RAR[std::min(6, c->r + 1)].n + "?", std::string("Uses 3 spare ") + RAR[c->r].n + " copies of " + UTM(c->p)->nm + ".", [u, x, y, w] {
    UCard *c = utCard(u); if (!c) return; auto d = utDupesOf(*c); if (d.size() < 3) return; std::vector<int> gone; for (int i = 0; i < 3; i++) gone.push_back(d[i]->u);
    UT->cards.erase(std::remove_if(UT->cards.begin(), UT->cards.end(), [&](const UCard &q) { return std::find(gone.begin(), gone.end(), q.u) != gone.end(); }), UT->cards.end());
    c = utCard(u); c->r++; utSave(); utMenuOnF = false;
    utFlash(upper(UTM(c->p)->nm) + " IS NOW " + RAR[c->r].n + "  (OVR " + istr(utOv(*c)) + ")"); utExOpen(u, x, y, w); });
}
void utSellOne(int u) {
  UTX &X = *UT; UCard *c = utCard(u); if (!c) return; int ri = -1; for (int i = 0; i < (int)X.ro.size(); i++) if (X.ro[i] == u) ri = i;
  std::string emp = ri >= 0 ? " " + utSlotName(ri) + " will be left empty." : ""; std::string nm = UTM(c->p) ? UTM(c->p)->nm : "?";
  askModal("QUICK SELL?", (c->r >= 4 ? std::string(RAR[c->r].n) + " " + nm + " for " + istr(utVal(*c)) + " coins. This can't be undone." : nm + " (" + RAR[c->r].n + ") for " + istr(utVal(*c)) + " coins.") + emp, [u] {
    UTX &X = *UT; UCard *c = utCard(u); if (!c) return; UCard cc = *c; int v = utVal(cc);
    for (int k = 0; k < (int)X.ro.size(); k++) if (X.ro[k] == u) { X.ro[k] = 0; utSel = k; utPage = 0; }
    X.cards.erase(std::remove_if(X.cards.begin(), X.cards.end(), [u](const UCard &q) { return q.u == u; }), X.cards.end()); X.coins += v;
    bool any = false; for (auto &q : X.cards) if (q.p == cc.p) any = true; if (!any) X.cs.erase(cc.p);
    utMenuOnF = false; utSave(); utFlash("SOLD  +" + istr(v) + " COINS"); });
}
// keep the copy in the lineup, otherwise the best one; everything else of the same player goes
static std::vector<int> utDupes(UTX &X) {
  struct K { UCard *c; bool ir; }; std::map<std::string, K> keep;
  for (auto &c : X.cards) { bool ir = inRo(c.u); auto it = keep.find(c.p); if (it == keep.end() || (ir && !it->second.ir) || (!it->second.ir && !ir && c.r > it->second.c->r)) keep[c.p] = {&c, ir}; }
  std::vector<int> o; for (auto &c : X.cards) if (keep[c.p].c != &c && !inRo(c.u)) o.push_back(c.u); return o;
}
void utSellDupes() {
  UTX &X = *UT; auto d = utDupes(X); if (d.empty()) { utFlash("NO DUPLICATES TO SELL"); return; }
  int v = 0; for (int u : d) v += utVal(*utCard(u));
  askModal("SELL DUPLICATES?", istr(d.size()) + " extra copies of players you already have, for " + istr(v) + " coins.", [d, v] {
    UTX &X = *UT; X.cards.erase(std::remove_if(X.cards.begin(), X.cards.end(), [&](const UCard &q) { return std::find(d.begin(), d.end(), q.u) != d.end(); }), X.cards.end());
    X.coins += v; utSave(); utFlash("SOLD " + istr(d.size()) + " CARDS  +" + istr(v) + " COINS"); });
}
std::vector<UCard *> utList() {
  bool g = utSel >= 9; std::vector<UCard *> o; for (auto &c : UT->cards) { const UTPDef *P = UTM(c.p); if (P && (P->pos == 'G') == g) o.push_back(&c); }
  std::stable_sort(o.begin(), o.end(), [](UCard *a, UCard *b) { int d = utOv(*b) - utOv(*a); if (d) return d < 0; if (a->r != b->r) return a->r > b->r; return a->p < b->p; });
  return o;
}

// ---------------------------------------------------------------- input
bool utTap(const std::string &id) {
  if (id == "ut:quit") { utLeave(); return true; }
  if (id.rfind("uslot:", 0) == 0) { int i = atoi(id.c_str() + 6); if (utSlots[i]) utLoad(i); else utNameStart(i); return true; }
  if (id.rfind("udel:", 0) == 0) { utAskDel(atoi(id.c_str() + 5)); return true; }
  if (!UT) return false; UTX &X = *UT;
  if (id == "ut:cap") { utBuyCap(X); return true; }
  if (id == "ut:play") { if (!utFull(X)) { utFlash("FILL ALL 11 ROSTER SLOTS FIRST"); screen = "utroster"; return true; }
    if (utPay(X) > utCapCheck(X) + 1e-6) { utFlash("YOUR LINEUP IS OVER THE SALARY CAP (" + fmtM(utPay(X)) + " / " + fmtM(X.cap) + ")"); screen = "utroster"; return true; }
    if (!X.hasOpp || X.oppFor != utTeamOv(X)) utGenOpp(X); utSave(); screen = "utopp"; return true; }
  if (id.rfind("uo:", 0) == 0) { int i = atoi(id.c_str() + 3); if (i >= 0 && i < (int)X.opp.size()) { utPickSet(X.opp[i]); startGame(); } return true; }
  if (id == "ue:close") { utExClose(); return true; }
  if (utExOnF) return true;
  if (id == "um:add") { int u = utMenuOnF ? utMenu.u : 0; utMenuOnF = false; if (u) { utAssign(utSel, u); mFocus = "uc:" + istr(u); } return true; }
  if (id == "um:ex") { if (utMenuOnF) utExOpen(utMenu.u, utMenu.x, utMenu.y, utMenu.w); return true; }
  if (id == "um:up") { if (utMenuOnF) utAskUp(utMenu.u, utMenu.x, utMenu.y, utMenu.w); return true; }
  if (id == "um:sell") { if (utMenuOnF) utSellOne(utMenu.u); return true; }
  if (id == "um:swap") { if (utMenuOnF) { utSwap = utMenu.si; utSel = utSwap; utPage = 0; utMenuOnF = false; mFocus.clear(); utSwapFocus = true; } return true; }
  if (id == "um:x") { if (utMenuOnF) mFocus = utMenu.slot ? "ur:" + istr(utMenu.si) : "uc:" + istr(utMenu.u); utMenuOnF = false; return true; }
  if (utMenuOnF) return true;
  auto findB = [&](const std::string &bid) -> const Btn * { for (auto &b : btns) if (b.id == bid) return &b; return nullptr; };
  if (id.rfind("ur:", 0) == 0) { int i = atoi(id.c_str() + 3); const Btn *b = findB(id); utSwap = -1;
    if (i != utSel) { utSel = i; utPage = 0; }
    if (i < (int)X.ro.size() && X.ro[i] && b) { utMenu = UMenu(); utMenu.u = X.ro[i]; utMenu.x = b->x; utMenu.y = b->y; utMenu.w = b->w; utMenu.slot = true; utMenu.si = i; utMenuOnF = true; mFocus.clear(); }   // a filled slot: its menu
    else { utSwap = i; utSwapFocus = true; }   // an empty slot: straight to the cards that fit it
    return true; }
  if (id.rfind("uc:", 0) == 0) { int u = atoi(id.c_str() + 3); const Btn *b = findB(id);
    if (utSwap >= 0 && !utSell) { int si = utSwap; utSwap = -1; if (X.ro[si] == u) { mFocus = "ur:" + istr(si); return true; }
      UCard *was = utCard(X.ro[si]); std::string wasNm = was ? upper(UTM(was->p)->nm) : ""; if (!utAssign(si, u)) { mFocus = "ur:" + istr(si); return true; }
      mFocus = "ur:" + istr(si); utFlash(upper(UTM(utCard(u)->p)->nm) + (!wasNm.empty() ? " REPLACES " + wasNm : " INTO " + utSlotName(si))); return true; }
    if (utSell) utSellOne(u); else if (b) { utMenu = UMenu(); utMenu.u = u; utMenu.x = b->x; utMenu.y = b->y; utMenu.w = b->w; utMenuOnF = true; mFocus.clear(); } return true; }
  if (id == "ut:prev") { utPage = std::max(0, utPage - 1); return true; }
  if (id == "ut:next") { utPage++; return true; }
  if (id == "ut:auto") { utAuto(X); utSave(); utFlash("BEST LINEUP SET"); return true; }
  if (id == "ut:sellm") { utSell = !utSell; utSwap = -1; return true; }
  if (id == "ut:dupes") { utSellDupes(); return true; }
  if (id.rfind("ubuy:", 0) == 0) { utBuy(atoi(id.c_str() + 5)); return true; }
  if (id == "ut:reveal") { if (utOpenOn) utOpen.all = true; return true; }
  if (id == "ut:again") { if (utOpenOn) utInvOpen(utOpen.t); return true; }
  if (id == "ut:done") { utOpenOn = false; screen = !X.inv.empty() ? "utinv" : "main"; return true; }
  if (id.rfind("inv:", 0) == 0) { utInvOpen(atoi(id.c_str() + 4)); return true; }
  if (id == "ut:inv") { screen = "utinv"; return true; }
  if (id == "ut:cup") { screen = "utcup"; return true; }
  if (id == "cup:new") { if (utFull(X)) { cupNew(X); utFlash("NEW RUN - 20 GAMES, TOP 4 IN EACH DIVISION MAKE THE PLAYOFFS"); } return true; }
  if (id == "cup:play") { UOpp o; if (cupOppPick(X, o) && X.cup->hasLock) { bool all = true; for (auto &l : X.cup->lock) if (!l.on) all = false;
      if (all) { utPickSet(o); utRet = "utcup"; startGame(); } } return true; }
  if (id == "cup:quit") { askModal("ABANDON THIS RUN?", "Your Road to the Cup season ends here.", [] { if (UT) { UT->cup.reset(); utSave(); } }); return true; }
  if (id == "ut:roster") { screen = "utroster"; utSell = false; utSwap = -1; return true; }
  if (id == "ut:packs") { screen = "utpacks"; return true; }
  if (id == "ut:hub") { if (utSwap >= 0 && screen == "utroster") { mFocus = "ur:" + istr(utSwap); utSwap = -1; return true; } screen = "main"; utMenuOnF = false; utExOnF = false; return true; }
  return false;
}

// ---------------------------------------------------------------- saves (chl_ut.json: {slots:[...]} in the legacy shape)
static J lockJ(const ULock &l) { if (!l.on) return J(); J o = J::obj(); o["p"] = l.p; o["r"] = l.r; return o; }
static ULock lockOf(const J &j) { ULock l; if (j.isObj()) { l.on = true; l.p = j("p").str(); l.r = j("r").i(); } return l; }
static J statJ(const UStat &s) { J o = J::obj(); o["gp"] = s.gp; o["g"] = s.g; o["a"] = s.a; o["sa"] = s.sa; o["sv"] = s.sv; o["w"] = s.w; o["l"] = s.l; return o; }
static UStat statOf(const J &j) { UStat s; s.gp = j("gp").i(); s.g = j("g").i(); s.a = j("a").i(); s.sa = j("sa").i(); s.sv = j("sv").i(); s.w = j("w").i(); s.l = j("l").i(); return s; }
static J oppJ(const UOpp &o) { J j = J::obj(); j["nm"] = o.nm; j["col"] = o.col; j["ov"] = o.ov; j["seed"] = o.seed; j["k"] = o.k; j["tov"] = o.tov; return j; }
static UOpp oppOf(const J &j) { UOpp o; o.nm = j("nm").str(); o.col = j("col").i(); o.ov = j("ov").i(60); o.seed = j("seed").num(); o.k = clamp(j("k").i(1), 0, 2); o.tov = j("tov").i(); return o; }
static J utToJ(const UTX &X) {
  J o = J::obj(); o["v"] = X.v; o["pv"] = X.pv; o["nm"] = X.nm; o["col"] = X.col; o["coins"] = X.coins;
  J cs = J::arr(); for (auto &c : X.cards) { J q = J::obj(); q["u"] = c.u; q["p"] = c.p; q["r"] = c.r; cs.push(q); } o["cards"] = cs;
  J ro = J::arr(); for (int u : X.ro) ro.push(u ? J(u) : J()); o["ro"] = ro;
  o["n"] = X.n; o["w"] = X.w; o["l"] = X.l; o["gp"] = X.gp; o["packs"] = X.packs;
  if (X.hasOpp) { J op = J::arr(); for (auto &q : X.opp) op.push(oppJ(q)); o["opp"] = op; } else o["opp"] = J();
  o["cap"] = X.cap; o["capN"] = X.capN; if (X.oppFor >= 0) o["oppFor"] = X.oppFor;
  J inv = J::arr(); for (int t : X.inv) inv.push(t); o["inv"] = inv;
  if (X.cup) { const Cup &C2 = *X.cup; J c = J::obj(); c["v"] = C2.v;
    J T = J::arr(); for (auto &t : C2.T) { J q = J::obj(); q["nm"] = t.nm; q["col"] = t.col; q["tov"] = t.tov; if (t.me) q["me"] = true; else { q["ov"] = t.ov; q["seed"] = t.seed; } q["div"] = t.div; q["w"] = t.w; q["l"] = t.l; q["gf"] = t.gf; q["ga"] = t.ga; T.push(q); } c["T"] = T;
    J sc = J::arr(); for (int s : C2.sched) sc.push(s); c["sched"] = sc; c["g"] = C2.g; c["phase"] = C2.phase;
    if (C2.hasBr) { J br = J::arr(); for (auto &R : C2.br) { J r = J::arr(); for (auto &x : R) { J m = J::obj(); m["a"] = x.a; m["b"] = x.b; m["w"] = x.w; m["sa"] = x.sa; m["sb"] = x.sb; r.push(m); } br.push(r); } c["br"] = br; } else c["br"] = J();
    c["rd"] = C2.rd; c["champ"] = C2.champ; c["out"] = C2.out.empty() ? J() : J(C2.out); c["res"] = J::arr();
    J lk = J::arr(); for (auto &l : C2.lock) lk.push(lockJ(l)); c["lock"] = lk;
    if (!C2.st.empty()) { J st = J::obj(); for (auto &e : C2.st) st[e.first] = statJ(e.second); c["st"] = st; }
    o["cup"] = c; }
  if (!X.st.empty()) { J st = J::obj(); for (auto &e : X.st) st[e.first] = statJ(e.second); o["st"] = st; }
  if (!X.cs.empty()) { J cs2 = J::obj(); for (auto &e : X.cs) { const UCStat &s = e.second; J q = J::obj(); q["gp"] = s.gp; q["g"] = s.g; q["a"] = s.a; q["pm"] = s.pm; q["sa"] = s.sa; q["sv"] = s.sv; q["ga"] = s.ga; q["w"] = s.w; q["l"] = s.l; q["so"] = s.so; cs2[e.first] = q; } o["cs"] = cs2; }
  return o;
}
static UTX *utOfJ(const J &x) {
  if (!x.isObj() || !x("cards").isArr()) return nullptr;
  auto *X = new UTX(); X->v = x("v").i(1); X->pv = x("pv").i(0); X->nm = x("nm").str(); X->col = clamp(x("col").i(), 0, 11); X->coins = x("coins").num(500);
  for (auto &c : x("cards").a) { UCard q; q.u = c("u").i(); q.p = c("p").str(); q.r = clamp(c("r").i(), 0, 6); X->cards.push_back(q); }
  if (X->v == 1) { for (auto &c : X->cards) c.r = std::min(6, c.r + 1); X->v = 2; }   // v1 saves had no WORN tier
  for (auto &u : x("ro").a) X->ro.push_back(u.i(0)); X->ro.resize(11, 0);
  X->n = x("n").i(1); X->w = x("w").i(); X->l = x("l").i(); X->gp = x("gp").i(); X->packs = x("packs").i();
  for (auto &c : X->cards) X->n = std::max(X->n, c.u + 1);
  if (x("opp").isArr() && x("opp").size() >= 3) { for (auto &q : x("opp").a) X->opp.push_back(oppOf(q)); X->hasOpp = true; }
  X->oppFor = x.has("oppFor") ? x("oppFor").i(-1) : -1;
  if (x.has("cap") && x("cap").isNum()) { X->hasCap = true; X->cap = x("cap").num(); X->capN = x("capN").i(); }
  for (auto &t : x("inv").a) X->inv.push_back(t.i());
  if (X->v == 2 && !X->pv) { for (auto &t : X->inv) t++; X->pv = 2; }
  for (auto &t : X->inv) t = clamp(t, 0, 4);
  if (x("cup").isObj()) { const J &c = x("cup"); auto *C2 = new Cup(); C2->v = c("v").i(1);
    for (auto &q : c("T").a) { CupTeam t; t.nm = q("nm").str(); t.col = q("col").i(); t.tov = q("tov").i(); t.me = q("me").truthy(); t.ov = q("ov").i(); t.seed = q("seed").num(); t.div = q("div").i(); t.w = q("w").i(); t.l = q("l").i(); t.gf = q("gf").i(); t.ga = q("ga").i(); C2->T.push_back(t); }
    for (auto &s : c("sched").a) C2->sched.push_back(s.i()); C2->g = c("g").i(); C2->phase = c("phase").str().empty() ? "reg" : c("phase").str();
    if (c("br").isArr()) { C2->hasBr = true; for (auto &R : c("br").a) { std::vector<CupMatch> r; for (auto &m : R.a) { CupMatch q; q.a = m("a").i(); q.b = m("b").i(); q.w = m("w").i(-1); q.sa = m("sa").i(); q.sb = m("sb").i(); r.push_back(q); } C2->br.push_back(r); } while (C2->br.size() < 3) C2->br.push_back({}); }
    C2->rd = c("rd").i(); C2->champ = c("champ").i(-1); C2->out = c("out").str();
    if (c("lock").isArr()) { C2->hasLock = true; for (auto &l : c("lock").a) C2->lock.push_back(lockOf(l)); }
    else if (C2->phase != "done") { C2->hasLock = true; for (int u : X->ro) { ULock l; UCard *cc = utCardIn(*X, u); if (cc) { l.on = true; l.p = cc->p; l.r = cc->r; } C2->lock.push_back(l); } }
    if (c("st").isObj()) for (size_t i = 0; i < c("st").k.size(); i++) C2->st[c("st").k[i]] = statOf(c("st").a[i]);
    if (C2->T.size() == 16 && C2->sched.size() >= (size_t)CUP_N) X->cup.reset(C2); else delete C2; }
  if (x("st").isObj()) for (size_t i = 0; i < x("st").k.size(); i++) X->st[x("st").k[i]] = statOf(x("st").a[i]);
  if (x("cs").isObj()) for (size_t i = 0; i < x("cs").k.size(); i++) { const J &q = x("cs").a[i]; UCStat s; s.gp = q("gp").i(); s.g = q("g").i(); s.a = q("a").i(); s.pm = q("pm").i(); s.sa = q("sa").i(); s.sv = q("sv").i(); s.ga = q("ga").i(); s.w = q("w").i(); s.l = q("l").i(); s.so = q("so").i(); X->cs[x("cs").k[i]] = s; }
  // cards whose player is no longer in the pool are kept (they show as "?") - but never in the lineup
  if (X->v != 2) { delete X; return nullptr; }
  return X;
}
void utLoadAll(const std::string &json) {
  bool ok = false; J d = J::parse(json, &ok); if (!ok || !d("slots").isArr()) return;
  for (int i = 0; i < 3; i++) utSlots[i].reset(i < (int)d("slots").size() ? utOfJ(d("slots")[i]) : nullptr);
}
void utSave() {
  if (utSlot >= 0 && UT && utSlots[utSlot].get() != UT) utSlots[utSlot].reset(new UTX(*UT));
  J d = J::obj(); J s = J::arr(); for (int i = 0; i < 3; i++) s.push(utSlots[i] ? utToJ(*utSlots[i]) : J()); d["slots"] = s;
  plat_write_file(plat_data_dir() + "chl_ut.json", d.dump());
}

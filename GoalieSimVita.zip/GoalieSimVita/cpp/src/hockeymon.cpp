// CHL 2026 native - Hockeymon: the 60 monsters, their cards, the packs and the art (all drawn from shapes, no images)
#include "hockeymon.h"
#include "game.h"
#include "canvas.h"
#include "util.h"
#include <functional>
#include <cmath>
#include <algorithm>

// ---------------------------------------------------------------- the monsters: 18 families of three, then six specials
struct Line { const char *n[3]; int type, shape, ears; };
// shape: 0 round, 1 egg, 2 wide, 3 bird, 4 serpent, 5 four legs, 6 puck, 7 ghost
// ears: 0 none, 1 cat, 2 flame tuft, 3 tall ears, 4 leaf, 5 fin, 6 spikes, 7 antenna, 8 crest, 9 horns
static const Line LINES[18] = {
  {{"FROSTPUP", "FROSTWOLF", "BLIZZARDFANG"}, HMT_ICE, 5, 1},   {{"EMBERCUB", "BLAZEBOAR", "INFERNOX"}, HMT_FIRE, 0, 2},
  {{"PUCKLING", "DISCORB", "VULCANIZER"}, HMT_STEEL, 6, 0},     {{"ZAPKIT", "VOLTFERRET", "THUNDERSTOAT"}, HMT_SPARK, 5, 3},
  {{"SPROUTLE", "BRAMBLEKIN", "THORNWARDEN"}, HMT_LEAF, 1, 4},  {{"PUDDLEFIN", "TIDECREST", "MAELSTRUM"}, HMT_WATER, 4, 5},
  {{"PEBBLET", "BOULDRUM", "GRANITUSK"}, HMT_STONE, 2, 9},      {{"GLOOMWISP", "DUSKMOTH", "NOCTURNOX"}, HMT_SHADE, 7, 7},
  {{"SLUSHIE", "ICICLAW", "GLACIRUN"}, HMT_ICE, 2, 6},          {{"BLADEBUG", "EDGEHOPPER", "ZAMBONIX"}, HMT_STEEL, 0, 7},
  {{"GUSTLING", "GALEHAWK", "TEMPESTRIKE"}, HMT_WIND, 3, 8},    {{"SPARKFLY", "CINDERWING", "PHOENETTO"}, HMT_FIRE, 3, 2},
  {{"BUBBLOT", "SPLASHRAM", "KRAKENET"}, HMT_WATER, 0, 9},      {{"MOSSNOOK", "FERNFAWN", "ELDEROOT"}, HMT_LEAF, 5, 4},
  {{"AMPULE", "JOLTJAW", "MEGAVOLT"}, HMT_SPARK, 1, 7},         {{"RINKROCK", "CRAGCRAWLER", "MONOLITH"}, HMT_STONE, 2, 6},
  {{"PENALTOAD", "SINBINDER", "HEXECUTOR"}, HMT_SHADE, 2, 9},   {{"FLURRBY", "DRIFTER", "SQUALLORD"}, HMT_WIND, 7, 8}};
struct Spec { const char *n; int type, tier, shape, ears; };
static const Spec SPECS[6] = {{"HATTRIKK", HMT_FIRE, 3, 5, 9}, {"CROSSBARR", HMT_STEEL, 3, 3, 8}, {"GLOVESNAG", HMT_SHADE, 3, 7, 1},
  {"ZAMBOSS", HMT_ICE, 3, 2, 6}, {"CHAMPIONYX", HMT_STEEL, 4, 5, 8}, {"AURORINK", HMT_ICE, 4, 4, 5}};
static HmMon MON[HM_N]; static int SHAPE[HM_N], EARS[HM_N];
static bool monInit = [] { for (int l = 0; l < 18; l++) for (int s = 0; s < 3; s++) { int id = l * 3 + s; MON[id] = {LINES[l].n[s], LINES[l].type, s, l, s}; SHAPE[id] = LINES[l].shape; EARS[id] = LINES[l].ears; }
  for (int i = 0; i < 6; i++) { int id = 54 + i; MON[id] = {SPECS[i].n, SPECS[i].type, SPECS[i].tier, 18 + i, 2}; SHAPE[id] = SPECS[i].shape; EARS[id] = SPECS[i].ears; } return true; }();
const HmMon &hmMon(int id) { (void)monInit; return MON[std::max(0, std::min(HM_N - 1, id))]; }
static const char *TYN[HMT_N] = {"ICE", "FIRE", "STEEL", "SPARK", "LEAF", "WATER", "STONE", "SHADE", "WIND"};
static const char *TYC[HMT_N][3] = {{"#7dd3fc", "#e0f2fe", "#0369a1"}, {"#f97316", "#fde68a", "#9a3412"}, {"#94a3b8", "#e2e8f0", "#334155"}, {"#facc15", "#fef9c3", "#a16207"},
  {"#4ade80", "#dcfce7", "#166534"}, {"#3b82f6", "#bfdbfe", "#1e3a8a"}, {"#a8a29e", "#e7e5e4", "#57534e"}, {"#8b5cf6", "#ddd6fe", "#3b0764"}, {"#5eead4", "#f0fdfa", "#115e59"}};
const char *hmTypeName(int t) { return TYN[std::max(0, std::min(HMT_N - 1, t))]; }
const char *hmTierName(int t) { static const char *N[5] = {"COMMON", "UNCOMMON", "RARE", "ULTRA RARE", "LEGEND"}; return N[std::max(0, std::min(4, t))]; }
const char *hmVarName(int v) { return v == 1 ? "HOLO" : v == 2 ? "GOLD" : ""; }

// ---------------------------------------------------------------- values and packs
// base values by tier (cents); a holo is worth 6x, a gold 20x (golds only come in rare and up). The packs were tuned by
// simulation: they're worth about 70-77% of their price on average, roughly one in six or seven breaks even, and about
// one in 200 is a 10x hit (a gold ultra or a legend)
int hmValue(int id, int v) { static const int B[5] = {15, 50, 200, 1500, 5000}; int b = B[hmMon(id).tier]; return v == 2 ? b * 20 : v == 1 ? b * 6 : b; }
static const HmPack PACKS[HM_NP] = {{"BOOSTER PACK", "5 cards. One rare or better in every pack.", 8, 5, "#2563eb", "#93c5fd"},
  {"PREMIUM PACK", "5 cards. Better odds of a holo, ultra rare or legend.", 25, 5, "#7c3aed", "#f0abfc"},
  {"COLLECTOR BOX", "12 cards. Two hit slots with the best odds.", 100, 12, "#b45309", "#fde68a"}};
const HmPack &hmPack(int k) { return PACKS[std::max(0, std::min(HM_NP - 1, k))]; }
static int pickTier(std::initializer_list<double> p) { double r = rnd(), a = 0; int i = 0; for (double q : p) { a += q; if (r < a) return i; i++; } return i - 1; }
static int pickOfTier(int t) { int ids[HM_N], n = 0; for (int i = 0; i < HM_N; i++) if (hmMon(i).tier == t) ids[n++] = i; return n ? ids[std::min(n - 1, (int)(rnd() * n))] : 0; }
static HmCard roll(std::initializer_list<double> tiers, double holo, double gold) { int t = pickTier(tiers); HmCard c{pickOfTier(t), 0};
  if (t >= 2 && rnd() < gold) c.v = 2; else if (rnd() < holo) c.v = 1; return c; }
std::vector<HmCard> hmRoll(int k) {
  std::vector<HmCard> v;
  if (k == 0) { for (int i = 0; i < 3; i++) v.push_back(roll({.75, .25}, .04, 0)); v.push_back(roll({0, .85, .15}, .05, 0)); v.push_back(roll({0, 0, .955, .04, .005}, .1, .005)); }
  else if (k == 1) { for (int i = 0; i < 3; i++) v.push_back(roll({.5, .5}, .06, 0)); v.push_back(roll({0, .3, .7}, .1, 0)); v.push_back(roll({0, 0, .78, .18, .04}, .2, .02)); }
  else { for (int i = 0; i < 8; i++) v.push_back(roll({.55, .45}, .08, 0)); for (int i = 0; i < 2; i++) v.push_back(roll({0, .3, .7}, .15, 0)); for (int i = 0; i < 2; i++) v.push_back(roll({0, 0, .6, .32, .08}, .3, .035)); }
  std::stable_sort(v.begin(), v.end(), [](const HmCard &a, const HmCard &b) { return hmValue(a.id, a.v) < hmValue(b.id, b.v); });   // the best one last
  return v;
}
std::string hmCash(int c) { std::string d = std::to_string(c / 100); for (int i = (int)d.size() - 3; i > 0; i -= 3) d.insert((size_t)i, ",");
  char b[8]; snprintf(b, sizeof b, ".%02d", c % 100); return "$" + d + b; }

// ---------------------------------------------------------------- the art: cute, chunky, outlined
static Col shadeC(Col c, double k) { return k < 0 ? Col((float)(c.r * (1 + k)), (float)(c.g * (1 + k)), (float)(c.b * (1 + k))) : Col((float)(c.r + (255 - c.r) * k), (float)(c.g + (255 - c.g) * k), (float)(c.b + (255 - c.b) * k)); }
void hmDrawMon(int id, double cx, double cy, double sz) {
  const HmMon &m = hmMon(id); int sh = SHAPE[id], ea = EARS[id], st = m.stage, ty = m.type; unsigned h = (unsigned)id * 2654435761u;
  double k = (m.tier >= 3 ? 1.0 : (.66 + .15 * st)) * sz * .5;   // later stages are bigger
  Col main = hex(TYC[ty][0]), lite = hex(TYC[ty][1]), dark = hex(TYC[ty][2]);
  { double hv = ((h >> 8) % 100) / 100.0 - .5; main = shadeC(main, hv * .25); }   // each family its own shade of its type
  if (m.tier == 4) { main = shadeC(main, .15); }
  Col ol = shadeC(dark, -.45), body = main, belly = lite;
  auto X = [&](double x) { return cx + x * k; }; auto Y = [&](double y) { return cy + y * k; };
  auto OV = [&](double x, double y, double rx, double ry, Col c, double rot = 0, bool line = true) {
    if (line) { ctx.fill(ol); ctx.oval(X(x), Y(y), rx * k + sz * .02, ry * k + sz * .02, rot); } ctx.fill(c); ctx.oval(X(x), Y(y), rx * k, ry * k, rot); };
  auto TRI = [&](double x0, double y0, double x1, double y1, double x2, double y2, Col c, bool line = true) {
    if (line) { ctx.stroke(ol); ctx.lineWidth(sz * .035); ctx.beginPath(); ctx.moveTo(X(x0), Y(y0)); ctx.lineTo(X(x1), Y(y1)); ctx.lineTo(X(x2), Y(y2)); ctx.closePath(); ctx.strokePath(); }
    ctx.fill(c); ctx.beginPath(); ctx.moveTo(X(x0), Y(y0)); ctx.lineTo(X(x1), Y(y1)); ctx.lineTo(X(x2), Y(y2)); ctx.closePath(); ctx.fillPath(); };
  double fx = 0, fy = -.05, hr = .55;   // the face: where, and the head's size
  if (sh == 5) { fx = -.4; fy = -.25; hr = .42; } else if (sh == 4) { fx = .12; fy = -.42; hr = .45; } else if (sh == 2) { fy = .1; } else if (sh == 6) { fy = .05; }
  // an aura behind the rarest
  if (m.tier >= 2 && st == 2) { ctx.alpha(m.tier >= 3 ? .35f : .2f); ctx.fill(lite); ctx.disc(cx, cy, sz * .48); ctx.alpha(1); }
  // behind the body: ears / horns / crests / wings / tails
  double es = st == 0 ? .8 : st == 1 ? 1.0 : 1.25;
  auto earsBehind = [&]() {
    double ex = fx, ey = fy - hr * .7;
    if (ea == 1) { TRI(ex - .32, ey + .1, ex - .5 * es, ey - .55 * es, ex - .05, ey - .05, body); TRI(ex + .32, ey + .1, ex + .5 * es, ey - .55 * es, ex + .05, ey - .05, body);
      TRI(ex - .3, ey + .02, ex - .42 * es, ey - .38 * es, ex - .14, ey - .02, belly, false); TRI(ex + .3, ey + .02, ex + .42 * es, ey - .38 * es, ex + .14, ey - .02, belly, false); }
    else if (ea == 3) { OV(ex - .25, ey - .4 * es, .1, .38 * es, body, -.25); OV(ex + .25, ey - .4 * es, .1, .38 * es, body, .25); }
    else if (ea == 6) for (int i = -2; i <= 2; i++) TRI(ex + i * .16 - .1, ey + .1, ex + i * .2, ey - (.35 + .12 * (2 - std::abs(i))) * es, ex + i * .16 + .1, ey + .1, lite);
    else if (ea == 8) { TRI(ex - .12, ey + .1, ex - .05, ey - .7 * es, ex + .12, ey + .1, dark); TRI(ex + .05, ey + .1, ex + .3, ey - .5 * es, ex + .2, ey + .12, main); }
    else if (ea == 9) { TRI(ex - .32, ey + .1, ex - .62 * es, ey - .45 * es, ex - .16, ey, lite); TRI(ex + .32, ey + .1, ex + .62 * es, ey - .45 * es, ex + .16, ey, lite); } };
  // tails and wings first
  if (sh == 3) { TRI(-.35, .0, -1.0, -.35 * es, -.75, .45, shadeC(body, -.12)); TRI(.35, .0, 1.0, -.35 * es, .75, .45, shadeC(body, -.12)); }
  if (sh == 5 || sh == 0 || sh == 2) {
    if (ty == HMT_FIRE) { TRI(.45, .4, 1.0, -.1 * es, .7, .55, hex("#fb923c")); TRI(.6, .45, .95, .1, .75, .55, hex("#fde047"), false); }
    else if (ty == HMT_SPARK) { ctx.stroke(dark); ctx.lineWidth(sz * .05); ctx.beginPath(); ctx.moveTo(X(.5), Y(.45)); ctx.lineTo(X(.75), Y(.2)); ctx.lineTo(X(.65), Y(.1)); ctx.lineTo(X(.95), Y(-.2)); ctx.strokePath(); }
    else if (sh == 5) { ctx.stroke(ol); ctx.lineWidth(sz * .06); ctx.beginPath(); ctx.moveTo(X(.55), Y(.2)); ctx.lineTo(X(.8), Y(-.05)); ctx.lineTo(X(.85), Y(-.25)); ctx.strokePath(); ctx.stroke(body); ctx.lineWidth(sz * .035); ctx.strokePath(); } }
  earsBehind();
  // the body
  switch (sh) {
    case 0: OV(0, .18, .62, .58, body); OV(0, .32, .38, .36, belly, 0, false); break;
    case 1: OV(0, .12, .5, .7, body); OV(0, .3, .3, .42, belly, 0, false); break;
    case 2: OV(0, .32, .82, .5, body); OV(0, .42, .5, .3, belly, 0, false); break;
    case 3: OV(0, .15, .5, .58, body); OV(0, .3, .3, .36, belly, 0, false); TRI(-.12, .7, -.25, .9, 0, .74, hex("#f59e0b")); TRI(.12, .7, .25, .9, 0, .74, hex("#f59e0b")); break;
    case 4: { double px = 0, py = .85; for (int i = 0; i < 7; i++) { double t = i / 6.0, x = std::sin(t * 4.2) * .35 * (1 - t * .5), y = .85 - t * 1.05; ctx.fill(ol); ctx.disc(X(x), Y(y), (.27 - t * .06) * k + sz * .02); px = x; py = y; }
      for (int i = 0; i < 7; i++) { double t = i / 6.0, x = std::sin(t * 4.2) * .35 * (1 - t * .5), y = .85 - t * 1.05; ctx.fill(i % 2 ? body : shadeC(body, .08)); ctx.disc(X(x), Y(y), (.27 - t * .06) * k); }
      (void)px; (void)py; OV(fx, fy, hr, hr * .88, body); break; }
    case 5: { for (int s2 = -1; s2 <= 1; s2 += 2) for (int f = 0; f < 2; f++) { double lx = (f ? .38 : -.05) + s2 * .06; ctx.fill(ol); ctx.rr(X(lx - .1) - sz * .01, Y(.4), .2 * k + sz * .02, .42 * k, .06 * k); ctx.fillPath(); ctx.fill(shadeC(body, -.1)); ctx.rr(X(lx - .1), Y(.4), .2 * k, .4 * k, .06 * k); ctx.fillPath(); }
      OV(.12, .25, .62, .38, body); OV(.12, .36, .36, .2, belly, 0, false); OV(fx, fy, hr, hr * .9, body); OV(fx - .12, fy + .2, .22, .15, belly, 0, false); break; }
    case 6: { ctx.fill(ol); ctx.rr(X(-.72) - sz * .02, Y(-.1) - sz * .02, 1.44 * k + sz * .04, .75 * k + sz * .04, .3 * k); ctx.fillPath(); ctx.fill(shadeC(body, -.25)); ctx.rr(X(-.72), Y(-.1), 1.44 * k, .75 * k, .3 * k); ctx.fillPath();
      OV(0, -.1, .72, .3, body, 0, false); OV(0, -.14, .5, .18, shadeC(body, .25), 0, false); fy = .25; break; }
    default: { OV(0, .05, .56, .62, body); for (int i = -1; i <= 1; i++) { ctx.fill(ol); ctx.disc(X(i * .36), Y(.62), .2 * k + sz * .02); } for (int i = -1; i <= 1; i++) { ctx.fill(body); ctx.disc(X(i * .36), Y(.6), .2 * k); } OV(0, .2, .34, .32, belly, 0, false); break; } }
  // in front: leaf / fin / flame / antenna on the head
  { double ex = fx, ey = fy - hr * .78;
    if (ea == 2) { TRI(ex - .2, ey + .15, ex - .05, ey - .5 * es, ex + .1, ey + .15, hex("#fb923c")); TRI(ex - .05, ey + .15, ex + .12, ey - .62 * es, ex + .25, ey + .15, hex("#f97316")); TRI(ex - .08, ey + .15, ex + .05, ey - .3 * es, ex + .15, ey + .15, hex("#fde047"), false); }
    else if (ea == 4) { OV(ex - .12, ey - .2 * es, .1, .26 * es, hex("#22c55e"), -.6); OV(ex + .12, ey - .24 * es, .1, .3 * es, hex("#16a34a"), .6); ctx.stroke(hex("#14532d")); ctx.lineWidth(sz * .025); ctx.beginPath(); ctx.moveTo(X(ex), Y(ey + .1)); ctx.lineTo(X(ex), Y(ey - .1)); ctx.strokePath(); }
    else if (ea == 5) TRI(ex - .25, ey + .15, ex + .05, ey - .55 * es, ex + .25, ey + .15, lite);
    else if (ea == 7) { ctx.stroke(ol); ctx.lineWidth(sz * .03); for (int s2 = -1; s2 <= 1; s2 += 2) { ctx.beginPath(); ctx.moveTo(X(ex + s2 * .12), Y(ey + .1)); ctx.lineTo(X(ex + s2 * .3), Y(ey - .45 * es)); ctx.strokePath(); ctx.fill(ty == HMT_SPARK ? hex("#fde047") : lite); ctx.disc(X(ex + s2 * .3), Y(ey - .45 * es), .08 * k); } } }
  // the type's touch on the body
  if (ty == HMT_ICE && st >= 1) for (int i = 0; i < 3; i++) TRI(-.4 + i * .3, -.05 + (sh == 2 ? .2 : 0), -.3 + i * .3, -.32 + (sh == 2 ? .2 : 0), -.2 + i * .3, -.05 + (sh == 2 ? .2 : 0), hex("#f0f9ff"));
  if (ty == HMT_STONE && st >= 1) { ctx.fill(shadeC(body, -.2)); ctx.quad(X(-.5), Y(.2), X(-.25), Y(.05), X(-.15), Y(.3), X(-.4), Y(.42)); ctx.quad(X(.3), Y(.15), X(.55), Y(.2), X(.5), Y(.45), X(.25), Y(.4)); }
  if (ty == HMT_STEEL && sh != 6) { ctx.alpha(.35f); ctx.fill("#ffffff"); ctx.oval(X(-.2), Y(-.05), .12 * k, .3 * k, -.5); ctx.alpha(1); }
  if (ty == HMT_WIND) { ctx.stroke(lite); ctx.lineWidth(sz * .025); ctx.beginPath(); ctx.arc(X(-.75), Y(.5), .14 * k, 0, 4.7); ctx.strokePath(); ctx.beginPath(); ctx.arc(X(.78), Y(.35), .1 * k, 3, 7.5); ctx.strokePath(); }
  if (m.tier >= 2 && st >= 1 && (h >> 4) % 2) { ctx.fill(shadeC(body, -.18)); for (int i = 0; i < 3; i++) ctx.disc(X(.28 + i * .12 - (sh == 5 ? -.1 : 0)), Y(.1 + (i % 2) * .1), .045 * k); }   // spots
  // the face
  int es2 = (int)((h >> 12) % 4); if (ty == HMT_SHADE) es2 = 3 - (st == 0); if (m.tier >= 3) es2 = 2;
  Col eyeW = ty == HMT_SHADE ? hex("#f5d0fe") : Col(255, 255, 255), pup = ty == HMT_SHADE ? hex("#a21caf") : hex("#111827");
  double er = .12 * (st == 0 ? 1.15 : 1.0) * (hr / .55), sp = .19 * (hr / .55);
  auto eye = [&](double x, double y, double r) { ctx.fill(ol); ctx.disc(X(x), Y(y), r * k + sz * .012); ctx.fill(eyeW); ctx.disc(X(x), Y(y), r * k); ctx.fill(pup); ctx.disc(X(x + r * .15), Y(y + r * .1), r * .6 * k); ctx.fill("#ffffff"); ctx.disc(X(x - r * .2), Y(y - r * .3), r * .25 * k); };
  if (es2 == 3) eye(fx, fy, er * 1.6);
  else { eye(fx - sp, fy, er); eye(fx + sp, fy, er);
    if (es2 == 1) { ctx.fill(body); ctx.rr(X(fx - sp - er * 1.2), Y(fy - er * 1.3), er * 2.4 * k, er * 1.1 * k, 1); ctx.fillPath(); ctx.rr(X(fx + sp - er * 1.2), Y(fy - er * 1.3), er * 2.4 * k, er * 1.1 * k, 1); ctx.fillPath(); }
    if (es2 == 2) { ctx.stroke(ol); ctx.lineWidth(sz * .03); ctx.beginPath(); ctx.moveTo(X(fx - sp - er), Y(fy - er * 1.5)); ctx.lineTo(X(fx - sp + er), Y(fy - er * .9)); ctx.strokePath(); ctx.beginPath(); ctx.moveTo(X(fx + sp + er), Y(fy - er * 1.5)); ctx.lineTo(X(fx + sp - er), Y(fy - er * .9)); ctx.strokePath(); } }
  // cheeks and mouth
  if (st == 0) { ctx.alpha(.45f); ctx.fill("#fb7185"); ctx.oval(X(fx - sp * 1.6), Y(fy + .14), .07 * k, .045 * k); ctx.oval(X(fx + sp * 1.6), Y(fy + .14), .07 * k, .045 * k); ctx.alpha(1); }
  ctx.stroke(ol); ctx.lineWidth(sz * .025); ctx.beginPath();
  if ((h >> 16) % 3 == 0 || m.tier >= 3) { ctx.moveTo(X(fx - .1), Y(fy + .18)); ctx.lineTo(X(fx), Y(fy + .24)); ctx.lineTo(X(fx + .1), Y(fy + .18)); ctx.strokePath();
    ctx.fill("#ffffff"); ctx.quad(X(fx - .07), Y(fy + .2), X(fx - .03), Y(fy + .22), X(fx - .05), Y(fy + .3), X(fx - .06), Y(fy + .3)); }   // a fang
  else { ctx.arc(X(fx), Y(fy + .12), .09 * k, .3, 2.84); ctx.strokePath(); }
}

// ---------------------------------------------------------------- a card
void hmDrawCard(double x, double y, double w, double h, int id, int v, bool owned) {
  const HmMon &m = hmMon(id); Col tc = hex(TYC[m.type][0]), tl = hex(TYC[m.type][1]), td = hex(TYC[m.type][2]); double r = w * .06;
  if (!owned) { ctx.fill(rgba(255, 255, 255, .05)); ctx.rr(x, y, w, h, r); ctx.fillPath(); ctx.stroke(rgba(255, 255, 255, .14)); ctx.lineWidth(1); ctx.rr(x + .5, y + .5, w - 1, h - 1, r); ctx.strokePath();
    ctx.fill(rgba(148, 163, 184, .7)); ctx.font(w * .1); ctx.textMid(); ctx.fillText("No. " + std::string(id < 9 ? "0" : "") + std::to_string(id + 1), x + w / 2, y + h * .45); ctx.font(w * .2); ctx.fillText("?", x + w / 2, y + h * .65); return; }
  ctx.save(); ctx.translate(std::round(x), std::round(y));
  cached(Key("hmc") << id << v << (int)w << (int)h, [&] {
    double X0 = 0, Y0 = 0;
    Col frame = v == 2 ? hex("#e7b416") : hex("#f8d34a"); if (v == 0 && m.tier < 2) frame = hex("#e5e7eb");
    ctx.fill(shadeC(frame, -.35)); ctx.rr(X0, Y0, w, h, r); ctx.fillPath(); ctx.fill(frame); ctx.rr(X0 + w * .02, Y0 + w * .02, w * .96, h - w * .04, r * .8); ctx.fillPath();
    { Grad g = gLin(0, 0, 0, h); g.add(0, tl); g.add(1, tc); ctx.fill(g); ctx.rr(X0 + w * .06, Y0 + w * .06, w * .88, h - w * .12, r * .6); ctx.fillPath(); }
    // the name bar, the art window, the info box
    ctx.fill(shadeC(tl, .3)); ctx.rr(w * .09, h * .045, w * .82, h * .09, h * .02); ctx.fillPath();
    auto fitF = [&](const std::string &t, double px, double mw) { ctx.font(px); double tw = ctx.measure(t); if (tw > mw) ctx.font(px * mw / tw); };
    ctx.textMid(AL_RIGHT); ctx.font(h * .04); ctx.fill(td); double tyw = ctx.measure(hmTypeName(m.type)); ctx.fillText(hmTypeName(m.type), w * .88, h * .092);
    ctx.fill("#111827"); fitF(m.n, h * .062, w * .74 - tyw - w * .04); ctx.textMid(AL_LEFT); ctx.fillText(m.n, w * .12, h * .092);
    double ax = w * .1, ay = h * .15, aw = w * .8, ah = h * .46;
    { Grad g = gLin(0, ay, 0, ay + ah); g.add(0, shadeC(tl, .5)); g.add(1, shadeC(tc, .2)); ctx.fill(g); ctx.fillRect(ax, ay, aw, ah); }
    ctx.fill(rgba(0, 0, 0, .12)); ctx.oval(ax + aw / 2, ay + ah * .88, aw * .32, ah * .07);
    ctx.stroke(shadeC(frame, -.3)); ctx.lineWidth(std::max(1.0, w * .012)); ctx.strokeRect(ax, ay, aw, ah);
    hmDrawMon(id, ax + aw / 2, ay + ah * .52, std::min(aw, ah) * .92);
    ctx.fill(rgba(255, 255, 255, .55)); ctx.rr(w * .1, h * .64, w * .8, h * .2, h * .02); ctx.fillPath();
    ctx.fill("#1f2937"); ctx.font(h * .042); ctx.textMid(AL_LEFT); ctx.fillText(std::string("No. ") + (id < 9 ? "0" : "") + std::to_string(id + 1) + "   " + hmTierName(m.tier), w * .13, h * .69);
    { static const char *FL[HMT_N] = {"Its breath frosts the boards.", "Warms the bench on cold nights.", "Hard as a frozen puck.", "Crackles before a big hit.", "Grows faster near the penalty box.", "Leaves puddles at centre ice.", "Sits in front of the net. Immovable.", "Only seen after the lights go out.", "Rides the draft from the zamboni door."};
      ctx.fill("#374151"); fitF(FL[m.type], h * .036, w * .74); ctx.fillText(FL[m.type], w * .13, h * .745); }
    ctx.font(h * .04); ctx.fill("#111827"); ctx.fillText(m.stage == 0 && m.tier < 3 ? "BASIC" : m.tier >= 3 ? "SPECIAL" : m.stage == 1 ? "STAGE 1" : "STAGE 2", w * .13, h * .8);
    // the value along the bottom, the variant tag
    ctx.fill(shadeC(frame, -.45)); ctx.font(h * .05); ctx.textMid(AL_RIGHT); ctx.fillText(hmCash(hmValue(id, v)), w * .9, h * .915);
    if (v) { ctx.fill(v == 2 ? hex("#78350f") : hex("#1e3a8a")); ctx.rr(w * .1, h * .885, w * .3, h * .06, h * .03); ctx.fillPath(); ctx.fill("#ffffff"); ctx.font(h * .04); ctx.textMid(); ctx.fillText(hmVarName(v), w * .25, h * .916); }
    for (int i = 0; i <= std::min(4, m.tier); i++) { ctx.fill(i == 4 ? hex("#f59e0b") : shadeC(frame, -.5)); ctx.disc(w * .48 + i * h * .035, h * .915, h * .011); }
  }); ctx.restore();
  // holo: a rainbow sheen sliding across the art; gold: glints
  if (v == 1) { double t = std::fmod(now() / 2200.0, 1.0), ax = x + w * .1, ay = y + h * .15, aw = w * .8, ah = h * .46, bx = ax - aw * .4 + t * aw * 1.4;
    static const char *RB[5] = {"#f472b6", "#facc15", "#4ade80", "#38bdf8", "#a78bfa"};
    for (int i = 0; i < 5; i++) { double x0 = std::max(ax, bx + i * aw * .06), x1 = std::min(ax + aw, bx + (i + 1) * aw * .06 + aw * .05); if (x1 <= x0) continue; ctx.alpha(.22f); ctx.fill(RB[i]); ctx.fillRect(x0, ay, x1 - x0, ah); } ctx.alpha(1); }
  if (v == 2) { double t = now() / 1000; for (int i = 0; i < 6; i++) { double a = .5 + .5 * std::sin(t * 3 + i * 1.7); if (a < .55) continue; double px = x + w * (.15 + .7 * std::fmod(i * .618, 1.0)), py = y + h * (.18 + .4 * std::fmod(i * .37, 1.0)), rr = w * .03 * a;
      ctx.alpha((float)a); ctx.fill("#fff7cc"); ctx.quad(px, py - rr * 2, px + rr * .5, py, px, py + rr * 2, px - rr * .5, py); ctx.quad(px - rr * 2, py, px, py - rr * .5, px + rr * 2, py, px, py + rr * .5); } ctx.alpha(1); }
}

// ---------------------------------------------------------------- a pack
void hmDrawPack(double x, double y, double w, double h, int k) {
  const HmPack &p = hmPack(k);
  ctx.save(); ctx.translate(std::round(x), std::round(y));
  cached(Key("hmp") << k << (int)w << (int)h, [&] {
    Col c1 = hex(p.c1), c2 = hex(p.c2);
    { Grad g = gLin(0, 0, w, h); g.add(0, c1); g.add(1, shadeC(c1, -.35)); ctx.fill(g); ctx.rr(0, h * .04, w, h * .92, w * .06); ctx.fillPath(); }
    ctx.fill(shadeC(c1, -.45)); for (int i = 0; i < 9; i++) { double xx = w * (i + .5) / 9; ctx.quad(xx - w * .05, h * .04, xx, 0, xx + w * .05, h * .04, xx, h * .06); ctx.quad(xx - w * .05, h * .96, xx, h * .94, xx + w * .05, h * .96, xx, h); }   // the crimped ends
    ctx.alpha(.25f); ctx.fill(c2); ctx.quad(0, h * .3, w, h * .12, w, h * .2, 0, h * .38); ctx.alpha(1);
    ctx.fill("#ffffff"); ctx.font(w * .14); { double tw = ctx.measure("HOCKEYMON"); if (tw > w * .84) ctx.font(w * .14 * w * .84 / tw); } ctx.textMid(); ctx.fillText("HOCKEYMON", w / 2, h * .18);
    hmDrawMon(k == 0 ? 0 : k == 1 ? 34 : 58, w / 2, h * .52, w * .62);
    ctx.fill(rgba(0, 0, 0, .35)); ctx.rr(w * .08, h * .78, w * .84, h * .12, h * .03); ctx.fillPath(); ctx.fill(c2); ctx.font(w * .09); ctx.fillText(p.n, w / 2, h * .84);
  }); ctx.restore();
}

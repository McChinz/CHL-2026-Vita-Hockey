// CHL 2026 native - forward game engine, part 2: your controls (pad + touch), the CPU skaters, the goalies,
// the main update, the puck, goals, whistles, line changes and the end of the game. Ported from the web build.
#include "game.h"
#include "sk_int.h"

bool g_autoplay = false;

// ---------------------------------------------------------------- touch: on the ice it only skips the matchup card (the pad does everything else)
void skTouchFrame() {
  static Touch prev; const Touch &T = g_touch;
  for (int i = 0; i < T.n; i++) { bool was = false; for (int j = 0; j < prev.n; j++) if (prev.p[j].id == T.p[i].id) was = true; if (!was && SK->phase == PH_PREVIEW) SK->tap = true; }
  prev = T;
}
bool skTouchOn(int, double &, double &, double &, double &) { return false; }

// ---------------------------------------------------------------- the L passes: who is under which button
// SQUARE = your left winger, TRIANGLE = the center, CIRCLE = your right winger (by where they line up);
// whoever is left over (an extra attacker, a man who swapped spots) takes a free button
Skater *skMateFor(int btn) {
  if (!SK || !SK->user) return nullptr; Team &T = SK->T[SK->user->team];
  Skater *m[3] = {nullptr, nullptr, nullptr}; std::vector<Skater *> rest;
  for (Skater *q : T.on) { if (q == SK->user) continue; int k = q->role == R_LW ? 0 : q->role == R_C ? 1 : q->role == R_RW ? 2 : -1; if (k >= 0 && !m[k]) m[k] = q; else rest.push_back(q); }
  for (Skater *q : rest) for (int k : {1, 0, 2}) if (!m[k]) { m[k] = q; break; }
  return btn >= 0 && btn < 3 ? m[btn] : nullptr;
}
// a quick full turn of the left stick: the spin-o-rama
static bool skStick360(double lx, double ly) {
  static double last = 0, acc = 0, t0 = 0; static bool on = false;
  double m = hyp(lx, ly), t = now() / 1000;
  if (m < .6) { on = false; acc = 0; return false; }
  double a = std::atan2(ly, lx);
  if (!on) { on = true; last = a; acc = 0; t0 = t; return false; }
  double d = wrapA(a - last); last = a;
  if (acc * d < 0) { acc = 0; t0 = t; }            // changed direction: start over
  acc += d;
  if (t - t0 > .6) { acc = d; t0 = t; }             // too slow: only quick turns count
  if (std::fabs(acc) >= PI * 1.8) { acc = 0; t0 = t; return true; }
  return false;
}
Input skInput() {
  Input I; const Pad &pad = g_pad; uint32_t press = g_press;
  auto toW = [](double sx, double sy, double &wx, double &wy) { wx = -sy; wy = sx; };   // screen up = up the ice
  auto n = [](int v) { return (v - 128) / 127.0; };
  double lx = n(pad.lx), ly = n(pad.ly), rx = n(pad.rx), ry = n(pad.ry);
  if (hyp(lx, ly) > .18) toW(lx, ly, I.mx, I.my);
  if (hyp(rx, ry) > .2) { toW(rx, ry, I.ax, I.ay); I.am = hyp(rx, ry); }
  I.rsx = rx; I.rsy = ry; I.rsm = hyp(rx, ry); I.rb = pad.btn & B_R; I.lb = pad.btn & B_L;
  bool mine = SK->user && SK->puck.owner == SK->user;
  I.lHold = (pad.btn & B_L) && mine;
  if (I.lHold) {
    // L held with the puck: the face buttons pick who gets the pass (and do nothing else)
    if (press & B_SQUARE) I.lpass = 0; else if (press & B_TRIANGLE) I.lpass = 1; else if (press & B_CIRCLE) I.lpass = 2;
  } else {
    if (press & B_TRIANGLE) I.tri = true;
    if (press & B_CIRCLE) I.check = true;
    if (pad.btn & B_CIRCLE) I.chkDown = true;
    if (pad.btn & B_SQUARE) I.dk = true;
    if (press & B_SQUARE) I.dkP = true;
  }
  if (press & B_CROSS) I.pass = true;
  if (pad.btn & B_CROSS) I.xdown = true;
  if (pad.btn & B_R) { if (QO.shotB && mine) I.rDown = true; else I.sprint = true; }
  if (QO.shotB && mine) {   // type B: R is the shot, so with the puck X does double duty: tap = pass, hold = sprint
    static double xt = 0; I.pass = false; I.xdown = false;
    if (pad.btn & B_CROSS) { xt += 1.0 / 60; if (xt > .18) I.sprint = true; }
    else { if (xt > 0 && xt <= .18) I.pass = true; xt = 0; } }
  if ((press & B_L) && !mine) I.block = true;
  if (skStick360(lx, ly)) I.spin = true;
  if (SK->tap) { I.pass = true; SK->tap = false; }
  return I;
}
// teammates call for the puck when they have the better look: an open net, or a clear shot that beats yours
void skCallsUpdate(double dt) {
  Skater *u = SK ? SK->user : nullptr; bool live = u && SK->phase == PH_PLAY && SK->puck.owner == u && onTeam(0, u);
  for (Skater *q : SK->T[0].on) {
    if (q == u) continue;
    bool want = false;
    if (live && skInZone(q) && !q->stun && !(q->block > 0)) {
      double mq = skShotQ(0, q->x, q->y), uq = skShotQ(0, u->x, u->y), lane = skLaneOpen(u->x, u->y, q->x, q->y, 0);
      bool en = SK->T[1].g.out;
      want = lane > 2.5 && ((en && mq > .25) || mq > .42 || (mq > .28 && mq > uq + .08));
    }
    if (want) q->call = std::max(q->call, .7); else q->call = std::max(0.0, q->call - dt);
  }
}

// ---------------------------------------------------------------- the goalies
Pose poseOf(const char *s) { std::string q = s; return q == "lo" ? GP_LO : q == "kick" ? GP_KICK : q == "hi" ? GP_HI : q == "body" ? GP_BODY : q == "dive" ? GP_DIVE : q == "poke" ? GP_POKE : q == "cover" ? GP_COVER : q == "look" ? GP_LOOK : GP_NONE; }
void skGoalieAnimStart(Goalie &g, Pose pose, double side, double hold) {
  if (g.hasAn && g.an.p == pose && g.an.s == side && g.an.t < g.an.i + g.an.h) return;
  g.hasAn = true; g.an = GAnim(); g.an.p = pose; g.an.s = side ? side : 1; g.an.t = 0; g.an.i = pose == GP_DIVE ? .14 : .09;
  g.an.h = hold > 0 ? hold : (pose == GP_DIVE ? .4 : .38); g.an.o = pose == GP_DIVE ? .35 : .22;
}
// the save animation reaches for where the puck will be: lateral offset from the goalie and the shot's height
// (the spot is kept on the ice, not relative to him: he keeps sliding while the puck comes, and the glove goes to the spot)
static void skGoalieAim(Goalie &g, double off, double hh) { g.aimY = off; g.aimWY = g.y + off; g.aimZ = (clamp(hh, 0, 1.3) * PZ * .94 + .1) * 1.7; g.aimT = SK->gt; }
void skGoalieReact(Goalie &g, double px, double py, double pvx, double pvy, double h) {
  if (g.out || g.user) return;
  double d = tdir(g.team), vx = pvx * -d; if (vx <= 5) return;
  double tt = std::max(.02, ((px - g.x) * d) / vx), yAt = py + pvy * tt, off = yAt - g.y;
  if (std::fabs(yAt - RK.cy) > RK.post + 3.5) { if (rnd() < .5) { g.hasRq = true; g.rq = {std::min(.12, tt * .5), GP_LOOK, off > 0 ? 1.0 : -1.0}; } return; }
  // THE READ. Which save this shot asks for: high or low (by its height) on his glove side, his blocker side, or into
  // his body. That save's rating (glove high / glove low / blocker high / blocker low / chest / pads), with his
  // reflexes, fatigue, the shot's speed and the usual perks, decides whether he reads it. A read shot gets the glove,
  // blocker or pad right where it's going; a misread puts it somewhere else (short of it, the wrong height, or late).
  // Then the puck is a real object: it goes in only if it actually finds a hole in him (skGoalieSave).
  Puck &P = SK->puck; const Shot *S = P.hasShot ? &P.shot : nullptr; const GS &gs = g.gs;
  bool high = h >= .5, gSide = g.team == 0 ? off < 0 : off > 0, centre = std::fabs(off) < .8;
  int zone = centre ? (high ? 1 : 0) : gSide ? (high ? 2 : 4) : (high ? 3 : 5);   // 0 pads / five-hole, 1 chest, 2 glove high, 3 blocker high, 4 glove low, 5 blocker low
  double st = zone == 0 ? gs.pad : zone == 1 ? gs.chs : zone == 2 ? gs.gh : zone == 3 ? gs.bh : zone == 4 ? gs.gl : gs.bl;
  double spd = hyp(pvx, pvy), reach = (1.6 + ((gs.agi - 50) / 49) * .6) * 1.65 * (g.broke ? .82 : 1);
  const SkD &D = SKD(); double gk = g.team == 1 ? D.gk : -D.gk * .5, sq = clamp(1 - std::fabs(off) / reach, 0, 1);
  static const double RS4[4] = {1, .6, .3, 0}, IM[4] = {1, .8, .65, .5}, SP4[4] = {0, .03, .05, .08}, PL4[4] = {0, .02, .035, .05}, FL4[4] = {0, .03, .045, .06};
  double fat = (1 - g.ast / 100) * .16, quick = SK->gt - g.lastSv < 1.3 ? (1 - (gs.rec - 50) / 49) * .12 * RS4[pkTg(&g, PK_RESET)] : 0;
  g.faced++; g.ast = std::max(0.0, g.ast - (11.5 - (gs.sta - 50) / 49 * 3.5) * IM[pkTg(&g, PK_IRONMAN)]);
  // HOT GOALIES: tonight's form plus the confidence he's built: a hot goalie reads almost everything, reacts sooner and
  // holds his angle; a cold one is a step behind
  double hotK = clamp(g.form + g.conf, -1, 1.3);
  double ps = clamp(.47 + (hotK > 0 ? .24 : .14) * hotK + std::max(0.0, 68 - st) * .0055 + (SK->T[g.team].score < SK->T[1 - g.team].score - 1 ? .035 * skTilt(g.team) : 0) - fat - quick - (g.broke ? .1 : 0)
    + ((st - 50) / 49) * .42 + ((gs.agi - 50) / 49) * .06 - (std::min(spd, S && S->otk ? 140.0 : 999.0) - 75) / 230 + gk + sq * .14 + (zone == 1 ? SP4[pkTg(&g, PK_STPAUL)] : 0) + (zone == 0 ? PL4[pkTg(&g, PK_PADLOCK)] : 0)
    - (S && S->flk ? FL4[S->flk] : 0) - (S && (S->tip || S->defl) ? .15 : 0) - (S && S->dk ? .04 + (S->by ? S->by->at.hand : 5) * .004 : 0)
    - (S && S->t < .35 && P.lastPasser && now() - P.passT < 900 ? .06 : 0) - (S && S->dk && S->by ? (S->by->at.deke - 5) * .008 : 0), .2, .97);
  // distance: from out there he sees it all the way (and he's out at the top of his crease); in tight he has no time
  ps = clamp(ps + clamp(((px - g.x) * d - 22) * .007, -.1, .2), .15, .97);
  Skater *shooter = S ? S->by : nullptr; if (shooter && shooter->user) ps = std::min(.97, ps + .03);
  if (g.cd > SK->gt) ps *= 1 - (.5 - .3 * clamp((gs.rec - 40) / 59, 0, 1)) * RS4[pkTg(&g, PK_RESET)];
  int pl = pkTg(&g, PK_PADLOCK);
  bool five = S && h < .25 && centre && shooter && shooter->user && !(pl && rnd() < (pl == 1 ? .5 : pl == 2 ? .75 : 1));
  if (five) ps = std::max(.2, ps - .12);
  double roll = rnd(); int fz = -1;
  if (roll >= ps) { int t; if ((zone == 2 || zone == 4) && (t = pkCanG(&g, PK_LEATHER)) && rnd() < (t == 1 ? .4 : t == 2 ? .55 : .7)) fz = PK_LEATHER; else if ((t = pkCanG(&g, PK_ROBBER)) && rnd() < (t == 1 ? .35 : t == 2 ? .5 : .65)) fz = PK_ROBBER; if (fz >= 0) { roll = 0; pkSpendG(&g, fz); } }
  bool read = roll < ps; g.read = read; g.rid = P.id; g.fz = fz;
#ifdef HOST_BUILD
  if (getenv("CHL_SVDBG")) fprintf(stderr, "READ %d zone %d ps %.2f dist %.0f on %d off %.2f h %.2f\n", (int)read, zone, ps, (px - g.x) * d, (int)(std::fabs(yAt - RK.cy) < RK.post - .25 && h < 1.0), off, h);
#endif
  // he meets the puck out in front of him (pads about a foot out, the glove and blocker further): aim where it will be there
  // (ice friction slows the puck - e^-.42t - so it gets there later, and lower, than distance / speed says)
  auto tArr = [&](double dx) { dx = std::max(0.0, dx); double q = 1 - .42 * dx / vx; return q > .05 ? -std::log(q) / .42 : dx / vx * 1.6; };
  double xr = 2.0, ttR = std::max(.02, tArr((px - g.x) * d - xr)), dR = (1 - std::exp(-.42 * ttR)) / .42, offR = py + pvy * dR - g.y;
  { double zR = P.bz + P.bvz * ttR - .5 * PG * ttR * ttR; if (P.bz > .1 || P.bvz > 0) h = clamp((std::max(0.0, zR) - .1) / (PZ * .94), 0, 1.3); }   // its height when it gets to him
  double ay = offR, ah = h, rt = clamp((.1 - ((gs.agi - 50) / 49) * .06 + (g.broke ? .06 : 0)) * (1 - .25 * hotK), .02, .18), lead = .55;
  if (read) { ay += rand(-.12, .12); ah = clamp(ah + rand(-.05, .05), 0, 1.3); }
  else if (centre && !high) { ah = rand(.6, .8); ay = offR + rand(-.25, .25); g.stkOff = SK->gt + 1.2; }   // he stays up, stick out of position: the five-hole is open
  else { double m = rnd();
    if (m < .5) ay = offR - sgn(offR ? offR : 1) * rand(1.5, 2.3);                                            // short of it: the gap is where the puck goes
    else if (m < .8) { ah = high ? std::max(0.0, h - rand(.45, .65)) : h + rand(.5, .7); ay = offR - sgn(offR ? offR : 1) * rand(.3, .8); }   // the wrong height
    else { rt += rand(.12, .25); lead = .97; } }                                                         // late
  Pose pose = fz == PK_ROBBER ? GP_DIVE : std::fabs(ay) > reach * 1.3 && tt < .35 && ah < .5 ? GP_DIVE : ah < .4 ? (std::fabs(ay) > 1.1 ? GP_KICK : GP_LO) : (std::fabs(ay) < .55 ? GP_BODY : GP_HI);
  g.hasRq = true; g.rq = {std::min(rt, tt * lead), pose, ay > 0 ? 1.0 : -1.0}; skGoalieAim(g, ay, ah);
  if (fz >= 0) { g.rq.t = std::min(g.rq.t, .03); if (fz == PK_ROBBER) { g.aimY = offR; g.aimWY = g.y + offR; } }
  g.rqH = std::max(.38, tt - g.rq.t + .25);   // hold the save until the puck has got there
}
static void skGoalieAnim(Goalie &g, double dt, Puck &P, double gx, double d) {
  if (g.hasRq) { g.rq.t -= dt; if (g.rq.t <= 0) { g.hasRq = false; skGoalieAnimStart(g, g.rq.p, g.rq.s, g.rq.p == GP_LOOK ? .2 : g.rqH); g.rqH = -1; } }
  if (g.hasAn) { g.an.t += dt; if (g.an.t > g.an.i + g.an.h + g.an.o) g.hasAn = false; }
  g.set = SK->phase == PH_PLAY && (P.x - gx) * d > 0 && (P.x - gx) * d < 70 ? 1 : 0;
  Skater *c = P.owner;
  if (c && c->team != g.team && !g.hasAn && SK->phase == PH_PLAY) {
    double dd = hyp(c->x - g.x, c->y - g.y);
    if (dd < 6 && (c->x - g.x) * d > .5 && rnd() < dt * 2.4) { skGoalieAnimStart(g, GP_POKE, c->y > g.y ? 1 : -1, .18); g.pk = c; }
  }
  if (g.hasAn && g.an.p == GP_POKE && g.pk && g.an.t >= g.an.i && !g.an.done) { g.an.done = true; Skater *c2 = g.pk; g.pk = nullptr;
    if (P.owner == c2 && hyp(c2->x - g.x, c2->y - g.y) < 4.6 && rnd() < clamp(.32 + ((g.gs.agi - 50) / 49) * .15 - (c2->at.hand - 5) * .03, .12, .5) * (c2->user ? .6 : 1)) {
      skRelease(c2); c2->cool = .5; double a = std::atan2(P.y - g.y, (P.x - g.x)) + rand(-.6, .6); P.vx = std::fabs(std::cos(a)) * d * rand(22, 32); P.vy = std::sin(a) * rand(18, 28); P.last = c2; P.hasShot = false; P.passTo = nullptr; P.ice = -1;
      if (c2->user) pushFeed("POKED BY THE GOALIE", "#ff7a7a"); } }
}
void skGoalie(Goalie &g, double dt) {
  if (g.out) return;
  g.sv = std::max(0.0, g.sv - dt);
  { Puck &P0 = SK->puck; bool away = SK->phase != PH_PLAY || (P0.x - defendX(g.team)) * tdir(g.team) > RK.L / 2; double sa = (g.gs.sta - 50) / 49;
    g.ast = std::min(100.0, g.ast + (away ? 8 + sa * 6 : .6 + sa * 1.2) * dt);
    if (g.ast <= .5 && !g.broke) { g.broke = true; if (g.team == 1) pushFeed("THEIR GOALIE IS RATTLED!", "#ff7a7a"); } else if (g.broke && g.ast > 35) g.broke = false; }
  Puck &P = SK->puck; double gx = defendX(g.team), d = tdir(g.team); bool front = (P.x - gx) * d > 0;
  skGoalieAnim(g, dt, P, gx, d);
  // the NHL-style positional game: with the puck down low at a sharp angle (or behind the net) he seals the post
  // (reverse-VH: the post-side pad flat on the ice along the goal line); moving fast across the crease he slides in
  // his butterfly. Both are his real body, so they really cover the ice they look like they cover
  { double fx = (P.x - gx) * d, dy = P.y - RK.cy;
    bool hugW = SK->phase == PH_PLAY && !g.hasAn && fx < 5 && fx > -14 && std::fabs(dy) > 3 && std::fabs(dy) < 22;
    g.hugK += ((hugW ? 1.0 : 0.0) - g.hugK) * std::min(1.0, dt * 6); if (hugW) g.hugS = dy > 0 ? 1 : -1;
    bool slW = SK->phase == PH_PLAY && std::fabs(g.mv) > 6.5 && fx > 0 && fx < 28;
    g.slideK += ((slW ? 1.0 : 0.0) - g.slideK) * std::min(1.0, dt * 8); }
  if (g.hasBite) { g.bite.t -= dt; if (g.bite.t <= 0) g.hasBite = false; }
  // THE ANGLE GAME. He stands on the line from the puck to the middle of his net. Against a shooter far out he skates
  // up to the top of his crease (a step past it from the point) and takes the angle away - long shots see almost no
  // net; as a skater comes in he skates backward into his net to stay square and not get walked around. At a sharp
  // angle he stays near his post. How well he keeps that line is his SHOT READ: a poor reader drifts off it (and a
  // quick pass across leaves anyone behind the play), and that's net you can see in the aim cone.
  double ty, tx;
  if (front) {
    double ex = P.x - gx, ey = P.y - RK.cy, dist = std::max(1.0, hyp(ex, ey)), ux = ex / dist, uy = ey / dist;
    // out to the top of the crease against shooters in his zone; with the play up the ice (or a faceoff) he sits back
    // in his crease
    double depth = clamp(1.4 + (dist - 10) * .2, 1.4, 6.2) * clamp(std::fabs(ux) * 1.5, .35, 1);
    if (dist > 50) depth = std::max(2.4, depth - (dist - 50) * .12);
    if (SK->phase != PH_PLAY) depth = std::min(depth, 2.4);
    double pe = (1 - clamp((g.gs.rd - 45) / 50, 0, 1)) * clamp(1 - .7 * (g.form + g.conf), .2, 1.8);   // a hot goalie holds his angle
    g.pEt -= dt; if (g.pEt <= 0) { g.pEt = rand(.8, 1.8); g.pE = rand(-1, 1); }
    g.pEv += (g.pE - g.pEv) * std::min(1.0, dt * 1.5);
    tx = gx + ux * depth * (1 - .25 * pe * std::fabs(g.pEv)); ty = RK.cy + uy * depth + g.pEv * pe * 1.7;
  } else { tx = gx + d; ty = RK.cy + (P.y < RK.cy ? -2.4 : 2.4); }
  ty = clamp(ty, RK.cy - (RK.post - .8), RK.cy + (RK.post - .8));
  double ag = (g.gs.agi - 50) / 49, sp = (8 + ag * 10) * dt * (g.broke ? .5 : 1), dx = tx - g.x, dy = ty - g.y, dd = hyp(dx, dy);
  if (dx * d < 0) sp *= .85;   // skating backward into the net is a touch slower than pushing out
  if (g.hasBite) { g.y = clamp(g.y + g.bite.s * 7 * dt, RK.cy - RK.post, RK.cy + RK.post); g.mv = g.bite.s * 7; return; }
  // once he's reacting to a shot he's committed: no more sliding over to wherever the puck is now (the save is the glove,
  // blocker or pads going to where he read it)
  if (g.hasRq || (g.hasAn && g.an.p != GP_LOOK && g.an.p != GP_POKE && SK->gt - g.aimT < 1.2)) { g.mv = 0; return; }
  double oy = g.y; if (dd > sp) { g.x += dx / dd * sp; g.y += dy / dd * sp; } else { g.x = tx; g.y = ty; }
  g.mv = dt > 0 ? (g.y - oy) / dt : 0;
}
static void skFreeze(Goalie &g) {
  Puck &P = SK->puck; P.vx = P.vy = 0; P.owner = nullptr; P.hasShot = false;
  SK->phase = PH_STOP; SK->stopT = .9;
  double d = tdir(g.team), gx = defendX(g.team);
  SK->hasNextFo = true; SK->nextFo = {gx + d * 20, P.y < RK.cy ? RK.cy - 22 : RK.cy + 22};
  SK->banner = {.9, "SAVE", "", hex("#cbd5e1")};
}
static void skHoldAI(Goalie &g) {
  Puck &P = SK->puck; double d = tdir(g.team); P.vx = P.vy = 0; P.owner = nullptr; P.hasShot = false; P.passTo = nullptr; P.x = g.x + d * 1.2; P.y = g.y; P.pl = false; P.ice = -1; P.id++;
  SK->phase = PH_HOLD; SK->hold.on = true; SK->hold.t = 3; SK->hold.g = &g; SK->hold.dec = rand(.45, 1.3);
}
static void skUserFree(Skater *p, double dt);
void skHoldUpdate(double dt) {
  Goalie &g = *SK->hold.g; int t = g.team; double d = tdir(t); Puck &P = SK->puck;
  SK->hold.t -= dt; P.x = g.x + d * 1.2; P.y = g.y; P.vx = P.vy = 0;
  double gx = defendX(t); Pt tg[3] = {{gx + d * 24, RK.cy - 26}, {gx + d * 24, RK.cy + 26}, {gx + d * 48, RK.cy}};
  auto steer = [&](Skater *p, double tx, double ty, double sp) { double dx = tx - p->x, dy = ty - p->y, dd = hyp(dx, dy), wv = dd > 1 ? std::min(sp, dd * 2) : 0;
    p->vx += ((dd > 1 ? dx / dd * wv : 0) - p->vx) * std::min(1.0, dt * 3); p->vy += ((dd > 1 ? dy / dd * wv : 0) - p->vy) * std::min(1.0, dt * 3); p->x += p->vx * dt; p->y += p->vy * dt; skBoardsP(p, 1.3, .2); };
  auto &mine = SK->T[t].on; Skater *me = SK->user; int k = 0;
  for (Skater *p : mine) { if (p == me && !g_autoplay) skUserFree(p, dt); else { steer(p, tg[k % 3].x, tg[k % 3].y, 24); k++; } }
  { int i = 0; for (Skater *p : SK->T[1 - t].on) { if (p == me && !g_autoplay) skUserFree(p, dt); else steer(p, defendX(t) + d * (38 + i * 9), RK.cy + (i - 1) * 22, 14); i++; } }
  auto open = [&](Skater *p) { double m = 99; for (Skater *q : SK->T[1 - t].on) m = std::min(m, hyp(q->x - p->x, q->y - p->y)); return m; };
  bool pass = false, cover = false;
  SK->hold.dec -= dt;
  if (SK->hold.dec <= 0) { SK->hold.dec = 9; Skater *best = nullptr; double bo = -1; for (Skater *p : mine) if (p->stun <= 0) { double o = open(p); if (o > bo) { bo = o; best = p; } }
    if (best && open(best) > 11 && rnd() < .7) pass = true; else cover = true; }
  if (pass && !mine.empty()) {
    Skater *to = nullptr; double bs = -1; for (Skater *p : mine) { double o = open(p); if (o > bs) { bs = o; to = p; } }
    double spd = 62, dist = hyp(to->x - P.x, to->y - P.y), tt = dist / spd, lx = to->x + to->vx * tt * .8, ly = to->y + to->vy * tt * .8, a = std::atan2(ly - P.y, lx - P.x) + (rnd() - .5) * .1;
    P.x = g.x + d * 2; P.vx = std::cos(a) * spd; P.vy = std::sin(a) * spd; P.passTo = to; P.lastPasser = nullptr; P.passT = now(); P.last = nullptr; P.hasShot = false; P.id++; P.pl = true; P.clearThru(); P.clearTips(); P.pp = 0; P.ice = -1; P.saucer = false;
    SK->hold.on = false; SK->phase = PH_PLAY; g.sv = 0;
    if (to == me) pushFeed("OUTLET PASS TO YOU", "#93c5fd");
    return;
  }
  if (cover || SK->hold.t <= 0) { SK->hold.on = false; SK->phase = PH_PLAY; skFreeze(g); }
}
bool skGoalieSave(Goalie &g) {
  // THE PUCK IS A REAL OBJECT and the goalie's body is solid (the same shapes the 3D view draws): every step the puck
  // is tested against his pads, glove, blocker, stick, arms, body and mask. Touch him and it's a save, and what
  // happens next depends on what it hit; miss him (through the five-hole, over a shoulder, past a glove that went to
  // the wrong spot) and it carries on to the goal line like any other puck.
  Puck &P = SK->puck; if (g.out || P.owner || g.user) return false;
  const GS &gs = g.gs; double d = tdir(g.team), spd = hyp(P.vx, P.vy), dist = hyp(P.x - g.x, P.y - g.y);
  if (dist < 2.6 && spd < 14 && !(g.fum > SK->gt) && (P.x - g.x) * d > -.8) { skHoldAI(g); return true; }   // loose at his feet: he covers it
  if (dist > 9 || SK->gt < g.hitT) return false;
  double n[3] = {0, 0, 1}, edge = 0; int part = skGoalieTouch(g, P.x, P.y, P.bz, PUCK_R, n, &edge);
#ifdef HOST_BUILD
  if (getenv("CHL_SVDBG2") && std::fabs(P.x - g.x) < 5 && P.hasShot) fprintf(stderr, "STEP t %.3f rx %.2f ry %.2f z %.2f part %d an %.2f gt %.3f hitT %.3f\n", SK->gt, (P.x - g.x) * d, P.y - g.y, P.bz, part, g.hasAn ? g.an.t : -1, SK->gt, g.hitT);
#endif
  if (part < 0) return false;
  g.hitT = SK->gt + .12;
#ifdef HOST_BUILD
  if (getenv("CHL_SVDBG")) fprintf(stderr, "HIT part %d read %d spd %.0f z %.2f shot %d\n", part, (int)(g.rid == P.id ? g.read : -1), hyp(P.vx, P.vy), P.bz, (int)(P.hasShot && P.shot.team != g.team));
#endif
  const Shot *S = P.hasShot ? &P.shot : nullptr; Skater *shooter = S ? S->by : nullptr;
  auto sk = [](double v) { return clamp((v - 50) / 49, 0, 1); };
  bool high = P.bz > 2.1, shotOn = S && S->team != g.team && spd > 18;
  double hn = hyp(n[0], n[1]); if (hn > 1e-6) { P.x += n[0] / hn * .3; P.y += n[1] / hn * .3; }   // back out of him
  auto away = [&](double a, double v) { P.vx = d * std::cos(a) * v; P.vy = std::sin(a) * v; };       // a = angle off straight out
  if (!shotOn) {   // a pass or a slow puck just bounces off him
    double vn = P.vx * n[0] + P.vy * n[1]; if (vn < 0) { P.vx -= 1.4 * vn * n[0]; P.vy -= 1.4 * vn * n[1]; } P.vx *= .5; P.vy *= .5; P.bvz = std::max(0.0, P.bvz) * .3;
    P.passTo = nullptr; return true; }
  // a save: the old bookkeeping (shots on goal, sound, the save pose, the recovery clock)
  P.ice = -1; g.sv = .45; g.svSide = P.y > g.y ? 1 : -1; g.lastSv = SK->gt; sfx(S_SAVE, sndAt(g.x, g.y) * std::min(1.0, .4 + spd / 140), rand(.92, 1.08));
  { double rk = clamp((gs.rec - 40) / 59, 0, 1); bool dv = g.hasAn && g.an.p == GP_DIVE; g.cd = SK->gt + (.55 - .4 * rk) * (dv ? 1.9 - .8 * rk : 1); }
  if (g.fz >= 0 && g.rid == P.id && shooter && shooter->team == 0) pushFeed(g.fz == PK_ROBBER ? "ROBBED!" : "FLASH OF LEATHER!", "#ff7a7a");
  if (shooter) { SK->T[shooter->team].sog++; if (shooter->user) { SK->me.sog++; pushFeed(skShotName(P) + " ON NET", "#cbd5e1"); } }
  { double c0 = g.conf; g.conf = std::min(.35, g.conf + .03); g.svRun++;   // confidence: every save builds it
    if (g.team == 1 && ((c0 < .2 && g.conf >= .2) || g.svRun == 12)) pushFeed(g.form > .5 ? "THEIR GOALIE IS ON FIRE TONIGHT" : "THEIR GOALIE IS FEELING IT", "#ff7a7a");
    if (g.team == 0 && c0 < .2 && g.conf >= .2) pushFeed("YOUR GOALIE IS LOCKED IN", "#7CFC9A"); }
  int blkSide = g.team == 0 ? 1 : -1;   // the blocker side of the rink (the glove is the other way)
  auto loose = [&](double v0, double v1, double spread) { away(rand(-spread, spread), rand(v0, v1)); };
  auto done = [&](const char *msg) { P.hasShot = false; P.passTo = nullptr; P.lastPasser = nullptr; g.fum = SK->gt + .5; skPuckJolt(spd, 1.1); if (msg && shooter && shooter->team == 0) pushFeed(msg, "#ffd54a"); return true; };
  // his own perks still work: a held glove (Flash of Leather) or a smothered chest save (St. Paul)
  int tl = part == GT_GLOVE ? pkTg(&g, PK_LEATHER) : 0, ts = (part == GT_BODY || part == GT_LEG) ? pkTg(&g, PK_STPAUL) : 0;
  if ((tl && rnd() < (tl == 1 ? .6 : tl == 2 ? .8 : 1)) || (ts && rnd() < (ts == 1 ? .7 : ts == 2 ? .85 : 1))) { skHoldAI(g); return true; }
  // the shooter's King of the Rebound: the puck comes off him right to a teammate
  if (S && S->otk && shooter && part != GT_GLOVE && rnd() < (S->otk == 1 ? .4 : S->otk == 2 ? .7 : 1)) {
    Skater *al = nullptr; double bd = 1e9; for (Skater *q : SK->T[shooter->team].on) if (q != shooter && q->stun <= 0) { double dd = hyp(q->x - g.x, q->y - g.y); if (dd < bd) { bd = dd; al = q; } }
    if (al) { Pt st2 = stickPt(al); double dx = st2.x - P.x, dy = st2.y - P.y, dd = hyp(dx, dy); if (!dd) dd = 1; double v = clamp(dd * 1.6, 18, 46);
      P.vx = dx / dd * v; P.vy = dy / dd * v; P.bz = 0; P.bvz = 0; P.hasShot = false; P.passTo = al; P.lastPasser = nullptr; P.pl = false; P.mag = 6; g.fum = SK->gt + .8; skPkFire(shooter, PK_OTKING);
      if (shooter->team == 0) pushFeed("REBOUND RIGHT TO " + upper(al->nm), "#ffd54a"); return true; } }
  if (part == GT_GLOVE) {
    // THE GLOVE catches: a good glove (high or low, wherever this one was) holds it - no rebound, a faceoff
    double q = sk(high ? gs.gh : gs.gl), c = clamp(.3 + .64 * q - std::max(0.0, spd - 95) / 320 - (1 - g.ast / 100) * .1 + .1 * (g.form + g.conf), .15, .98);
    if (rnd() < c || spd < 32) { if (shooter && shooter->user) pushFeed(high ? "GLOVE SAVE" : "LOW GLOVE SAVE", "#cbd5e1"); skHoldAI(g); return true; }
    loose(3, 9, .9); P.bvz = rand(1.5, 3.5); P.wob = 1; return done("BOBBLED IT!");
  }
  if (part == GT_BLOCKER) {
    // THE BLOCKER steers it away: a good one puts it in the corner or onto a teammate's stick; a bad one leaves a
    // rebound in the slot - and now and then it squeaks off the blocker and behind him
    double q = sk(high ? gs.bh : gs.bl);
    if (rnd() < .3 + .65 * q) {
      Skater *mate = nullptr; double md = 1e9;
      if (rnd() < .3 + .35 * q) for (Skater *m : SK->T[g.team].on) { if (m->stun > 0) continue; double fx = (m->x - g.x) * d, dd = hyp(m->x - g.x, m->y - g.y); if (fx > 4 && dd < 48 && (m->y - g.y) * blkSide > -6 && dd < md) { md = dd; mate = m; } }
      if (mate) { Pt st2 = stickPt(mate); double dx = st2.x - P.x, dy = st2.y - P.y, dd = std::max(1.0, hyp(dx, dy)), v = clamp(dd * 1.5, 20, 40); P.vx = dx / dd * v; P.vy = dy / dd * v; P.bvz = 0;
        P.hasShot = false; P.passTo = mate; P.lastPasser = nullptr; P.mag = 3; g.fum = SK->gt + .5; skPuckJolt(spd, .6); return true; }
      double cx = defendX(g.team) + d * rand(2, 14), cyy = RK.cy + blkSide * (RK.Wd / 2 - 2), dx = cx - P.x, dy = cyy - P.y, dd = std::max(1.0, hyp(dx, dy)), v = rand(26, 40);
      P.vx = dx / dd * v; P.vy = dy / dd * v; P.bvz = rand(0, 2); return done(nullptr); }
    if (rnd() < .14 * (1 - q)) { P.vx = -d * rand(5, 11); P.vy = (RK.cy - P.y) * rand(.5, 1.2); P.bz = 0; P.bvz = 0; P.wob = .8; return done(nullptr); }   // off the blocker and in behind him
    loose(14, 28, .5); P.bvz = rand(0, 3); return done("REBOUND!");
  }
  if (part == GT_PAD || part == GT_STICK) {
    // THE PADS (and the stick): kick it to the side with good pads, spit it out front with bad ones; a soft one off the
    // edge of a pad can keep trickling toward the line
    double q = sk(gs.pad);
    if (spd < 34) { loose(1.5, 4, 1.2); P.bvz = 0; return done(nullptr); }
    if (edge > .72 && rnd() < .18 * (1 - q)) { P.vx *= .13; P.vy *= .2; P.bz = 0; P.bvz = 0; P.wob = .9; P.x -= n[0] / std::max(1e-6, hn) * .3; P.y -= n[1] / std::max(1e-6, hn) * .3; return done(nullptr); }   // a trickler
    if (rnd() < .22 + .55 * q) { double sd = std::fabs(n[1]) > .2 ? sgn(n[1]) : (rnd() < .5 ? -1 : 1); P.vx = d * rand(.25, .6) * 30; P.vy = sd * rand(18, 30); P.bvz = rand(0, 1.5); return done(nullptr); }
    loose(10, 22, .85); P.bvz = rand(0, 2); return done("REBOUND!");
  }
  if (part == GT_HEAD) { loose(6, 13, .9); P.bvz = rand(5, 8); P.wob = 1; return done("OFF THE MASK!"); }
  // the chest, the arms, the legs: a good chest smothers it, otherwise it drops in front of him
  { double q = sk(gs.chs); if (spd < 40 || rnd() < .3 + .5 * q) { skHoldAI(g); return true; }
    loose(3, 9, 1.0); P.bvz = rand(0, 2); return done("REBOUND!"); }
}

// ---------------------------------------------------------------- your skater
static Pt skStickTarget(const Skater *p, double rx, double &h) {
  double ax = attackX(p->team), d = tdir(p->team);
  if (skInZone(p)) { double ty = RK.cy + rx * (RK.post + 3.2); if (QO.autoAim) { ty = clamp(ty, RK.cy - RK.post + .6, RK.cy + RK.post - .6); h = std::min(h, .95); } return {ax, ty}; }
  double vx = d, vy = clamp(rx, -1, 1) * 1.4, l = hyp(vx, vy); h = std::min(h, .35); return {p->x + vx / l * 60, p->y + vy / l * 60};
}
static void skShotFake(Skater *p, double rx, double hIn) {
  Goalie &g = SK->T[1 - p->team].g;
  if (g.out || g.user) return;
  double dn = hyp(attackX(p->team) - p->x, RK.cy - p->y); if (dn > 55) return;
  double rd = g.gs.rd, h = hIn; Pt T = skStickTarget(p, rx, h);
  double bite = clamp(.88 - (rd - 40) / 59 * .9, .04, .85) * (dn < 30 ? 1.1 : .85);
  if (rnd() < bite) {
    double side = T.y > g.y ? 1 : -1; Pose pose = rd < 60 && rnd() < .5 ? GP_DIVE : hIn > .45 ? GP_HI : GP_KICK;
    skGoalieAnimStart(g, pose, side, .35); skGoalieAim(g, T.y - g.y, hIn); g.hasBite = true; g.bite = {.5, side}; g.cd = SK->gt + .45 + (70 - clamp(g.gs.rec, 40, 99)) * .008;
    pushFeed("HE BIT ON THE FAKE!", "#7CFC9A");
  } else pushFeed("HE DIDN'T BUY IT", "#94a3b8");
}
Pt skATarget(const Skater *p, double mx, double my, bool &none) {
  double m = hyp(mx, my), ax = attackX(p->team), d = tdir(p->team); none = false;
  if (m < .3) { if (skInZone(p) && QO.autoAim) { none = true; return {0, 0}; } return {p->x + std::cos(p->ang) * 60, p->y + std::sin(p->ang) * 60}; }
  if (skInZone(p) && mx * d > .05) { double ty = p->y + my / mx * (ax - p->x); if (QO.autoAim) ty = clamp(ty, RK.cy - RK.post + .6, RK.cy + RK.post - .6); return {ax, ty}; }
  return {p->x + mx / m * 60, p->y + my / m * 60};
}
static double skAutoHeight(const Skater *p, ShotKind kind, bool hasT, Pt T) {
  double acc = kind == SH_SLAP ? p->at.lacc : p->at.wacc; Goalie &g = SK->T[1 - p->team].g;
  if (rnd() < clamp(.25 + acc * .07, .25, .95)) { double side = hasT ? (T.y > g.y ? 1 : -1) : 1; bool glove = g.team == 0 ? side < 0 : side > 0; double hi = glove ? g.gs.gh : g.gs.bh, lo = std::min(glove ? g.gs.gl : g.gs.bl, g.gs.pad + 4);
    return rnd() < clamp(.5 + (lo - hi) * .02, .2, .8) ? rand(.72, .92) : rand(.04, .18); }
  return rand(.35, .6);
}
// THE SHOOTING STICK (NHL style). Push the right stick UP to prime a wrist shot, PULL it BACK to wind up a slap shot;
// let go (back to centre) to shoot. Once it's primed the whole half circle counts: slide the stick left / right while
// holding to aim across the net (you keep skating). A loaded slap shot pushed all the way up is a fake.
Pt skAimTarget(const Skater *p) {   // where the held shot is aimed (SK->rs.rx: -1 left .. 1 right across the net)
  double ax = attackX(p->team), d = tdir(p->team), a = SK->rs.rx;
  if (skInZone(p)) { double ty = RK.cy + a * (RK.post + .6) * d; if (QO.autoAim) ty = clamp(ty, RK.cy - RK.post + .6, RK.cy + RK.post - .6); return {ax, ty}; }
  double ang = std::atan2(RK.cy - p->y, ax - p->x) + a * .6 * d; return {p->x + std::cos(ang) * 60, p->y + std::sin(ang) * 60};
}
double skShotOpen(const Skater *u, double ty) {
  // trace the shot from the puck to that spot on the goal line (rising to about mid-net) against the goalie's real body
  double ax = attackX(u->team); if (std::fabs(ty - RK.cy) > RK.post - .2) return -1;
  Goalie &g = SK->T[1 - u->team].g; if (g.out) return 1;
  const Puck &P = SK->puck; double z1 = .45 * PZ;
  double gt0 = ax == P.x ? 0 : clamp((g.x - 9 - P.x) / (ax - P.x), 0, 1), gt1 = ax == P.x ? 1 : clamp((g.x + 9 - P.x) / (ax - P.x), 0, 1);   // only near him
  if (gt0 > gt1) std::swap(gt0, gt1);
  for (int i = 0; i <= 10; i++) { double t = gt0 + (gt1 - gt0) * i / 10.0, x = P.x + (ax - P.x) * t, y = P.y + (ty - P.y) * t, z = .1 + (z1 - .1) * std::min(1.0, t * 3);
    if (skGoalieTouch(g, x, y, z, PUCK_R, nullptr, nullptr) >= 0) return 0; }
  return 1;
}
double skAimSpread(const Skater *u) { bool sl = SK->rs.kind == 1; double acc = sl ? u->at.lacc : u->at.wacc; return ((11 - acc) * (sl ? 1.1 : .82) + 1.2) * PI / 180; }
static void skStickA(Skater *p, const Input &I, double dt, double mx, double my) {
  (void)mx; (void)my;
  auto &RS = SK->rs; double rx = I.rsx, ry = I.rsy, m = I.rsm; bool mine = SK->puck.owner == p;
  if (QO.shotB) {   // SHOT TYPE B: the right stick only aims; tap R = wrist shot, hold R = slap wind-up, let go = fire
    if (!mine) { RS.dn = false; RS.aim = false; p->wind = 0; return; }
    RS.aim = m > .25; if (RS.aim && !RS.dn) RS.rx = clamp(rx * 1.3, -1, 1);   // tilting the stick to aim shows the cone
    if (I.rDown) { if (!RS.dn) { RS.dn = true; RS.kind = 0; RS.t = 0; } RS.t += dt; if (RS.t > .2) RS.kind = 1;
      RS.rx = m > .2 ? clamp(rx * 1.3, -1, 1) : 0; p->wind = RS.kind ? std::min(1.0, (RS.t - .2) / .32) : 0; return; }
    if (!RS.dn) return;
    RS.dn = false; p->wind = 0; RS.rx = m > .2 ? clamp(rx * 1.3, -1, 1) : RS.rx;
    ShotKind K = RS.kind ? SH_SLAP : SH_WRIST; double ch = RS.kind ? clamp((RS.t - .35) / .75, 0, 1) : clamp(.25 + p->at.wpow * .075, 0, 1);
    Pt T = skAimTarget(p); double h = skAutoHeight(p, K, true, T); skShoot(p, T.x - p->x, T.y - p->y, ch, K, skInZone(p) ? h : .1); return; }
  if (!RS.dn) {
    if (!mine || m < .45) return;
    if (ry < -.3) { RS.dn = true; RS.kind = 0; } else if (ry > .3) { RS.dn = true; RS.kind = 1; } else return;
    RS.t = 0; RS.rx = 0; }
  if (!mine) { RS.dn = false; p->wind = 0; return; }
  if (m >= .25) {   // still held (anywhere in the half circle): aim and load
    RS.t += dt; RS.rx = clamp(rx * 1.3, -1, 1);
    p->wind = RS.kind ? std::min(1.0, RS.t / .32) : std::min(.3, RS.t / .25);
    if (RS.kind == 1 && ry < -.75 && RS.t > .15) { skShotFake(p, RS.rx * tdir(p->team), .5); RS.dn = false; p->wind = 0; }
    return; }
  // let go: the shot
  RS.dn = false; p->wind = 0;
  ShotKind K = RS.kind ? SH_SLAP : SH_WRIST;
  double ch = RS.kind ? clamp((RS.t - .15) / .75, 0, 1) : clamp(.25 + p->at.wpow * .075, 0, 1);
  Pt T = skAimTarget(p); double h = skAutoHeight(p, K, true, T);
  skShoot(p, T.x - p->x, T.y - p->y, ch, K, skInZone(p) ? h : .1);
}
Want skUserControl(Skater *p, Input &I, double dt) {
  Puck &P = SK->puck; bool mine = P.owner == p, teamHas = P.owner && P.owner->team == p->team;
  double mx = I.mx, my = I.my, m = hyp(mx, my); if (m > 1) { mx /= m; my /= m; }
  auto &RS = SK->rs; if (m > .3) { SK->lastMx = mx; SK->lastMy = my; }
  if (mine && RS.dn) { I.spin = false; I.sprint = false; }
  { double cs = hyp(p->vx, p->vy), dot = cs > 1 && m > .2 ? (mx * p->vx + my * p->vy) / (cs * std::min(1.0, m)) : 1;
    if (dot > -.1) SK->dimeOk = SK->gt;
    if (cs > 12 && m > .7 && dot < -.7 && SK->gt - SK->dimeOk < .14 && !(p->hs > 0) && !(p->hsCd > SK->gt) && p->dash <= 0) {
      double sk = clamp((p->at.agl - 3.5) / 6.5, 0, 1); p->hs = .32; p->hsCd = SK->gt + .7; p->st = std::max(0.0, p->st - (20 - sk * 10)); p->stT = std::max(p->stT, 1.0); } }
  bool busy = mine && (RS.on || RS.dn);
  if (busy) { I.spin = false; I.sprint = false; }
  if (mine && I.spin) skSpin(p);
  if (mine && I.lpass >= 0 && !RS.dn) { Skater *to = skMateFor(I.lpass); if (to) { skPass(p, to); SK->xh.on = false; } }
  if (p->spin > 0) { p->wind = 0; double ms = skMaxSpd(p); return {mx * ms, my * ms}; }
  if (mine) {
    if (I.dkP && !RS.dn) skDeke(p, skDekeSide(p, mx, my));
    p->dkHeld = I.dk;
    skStickA(p, I, dt, mx, my);
    if (I.tri && P.owner == p && !RS.dn) { skPass(p, skBestPassTarget(p, I.mx, I.my), 0, true); SK->xh.on = false; }
    auto &X = SK->xh;
    if (I.pass && I.xdown && !X.on) { X.on = true; X.t = 0; }
    else if (I.pass && !X.on) skPass(p, skBestPassTarget(p, I.mx, I.my));
    if (X.on) { if (I.xdown) X.t += dt; else { double pw = X.t < .22 ? 0 : std::min(1.0, (X.t - .22) / .4); X.on = false; X.t = 0; if (P.owner == p) skPass(p, skBestPassTarget(p, I.mx, I.my), pw); } }
    if (I.ppass && P.owner == p) skPass(p, skBestPassTarget(p, I.mx, I.my), 1);
  } else {
    p->wind = 0; p->wl = 0; RS.on = false; SK->xh.on = false;
    if (I.block) skBlock(p);
    bool cv = false; double cvx = 0, cvy = 0, pw = 1;
    { auto &C = SK->ck;
      if (I.chkDown && !teamHas) { if (!C.dn) { C.dn = true; C.t = 0; } C.t = std::min(.9, C.t + dt); }
      else if (C.dn) { C.dn = false; pw = C.t < .22 ? .5 : .85 + std::min(1.0, (C.t - .22) / .6) * .6; cv = true; }
      if (cv) { if (m > .3) { cvx = mx; cvy = my; }
        else { Skater *tg = nullptr; if (P.owner && P.owner->team != p->team) tg = P.owner;
          else { double bd = 1e9; for (Skater *o : SK->T[1 - p->team].on) { double dd = hyp(o->x - p->x, o->y - p->y); if (dd < bd) { bd = dd; tg = o; } } }
          if (tg) { cvx = tg->x - p->x; cvy = tg->y - p->y; } else { cvx = std::cos(p->ang); cvy = std::sin(p->ang); } } } }
    if (I.hasRel && !teamHas) { cv = true; cvx = I.relx; cvy = I.rely; pw = 1; }
    if (cv) skStartCheck(p, cvx, cvy, pw);
    if (I.pass) {
      if (teamHas) SK->callPass = .9;
      else if (p->poke <= 0) { p->poke = .45; if (skPoke(p, P.owner, .42)) { SK->me.tk++; pushFeed("POKE CHECK!", "#7CFC9A"); } }
    }
  }
  double ms = skMaxSpd(p);
  if (p->dash > 0) return {p->dx * ms * 1.45, p->dy * ms * 1.45};
  if (mine && RS.dn) return {mx * ms * (RS.kind ? .55 : .85), my * ms * (RS.kind ? .55 : .85)};   // you keep skating while you aim (slower winding up a slapper)
  if (p->wind > 0 || p->wl > 0 || RS.on) return {mx * ms * .72, my * ms * .72};
  return {mx * ms, my * ms};
}
static void skUserFree(Skater *p, double dt) {
  Input I = skInput(); Want w = skUserControl(p, I, dt);
  p->vx += (w.vx - p->vx) * std::min(1.0, dt * 4); p->vy += (w.vy - p->vy) * std::min(1.0, dt * 4); p->x += p->vx * dt; p->y += p->vy * dt; skBoardsP(p, 1.3, .2);
}

// ---------------------------------------------------------------- the CPU skaters
Want skAI(Skater *p, double dt) {
  Puck &P = SK->puck; Team &T = SK->T[p->team], &O = SK->T[1 - p->team]; double d = tdir(p->team); Skater *car = P.owner; double ms = skMaxSpd(p); const SkD &D = SKD();
  double tx = p->x, ty = p->y;
  p->dec -= dt;
  double ax = attackX(p->team), ownX = defendX(p->team);
  p->wantSprint = false; if (car != p && p->windT > 0) { p->windT = 0; p->wind = 0; }
  Skater *user = SK->user;
  if (car == p && p->windT > 0) {
    p->windT -= dt; p->wind = std::min(1.0, 1 - p->windT / .42);
    if (p->windT <= 0) { p->aiCh = p->windAim.ch; skShoot(p, p->windAim.x - p->x, p->windAim.y - p->y, 0, SH_SLAP, p->windAim.h); p->aiCh = -1; }
    return {p->vx * .85, p->vy * .85};
  }
  auto anyO = [&](auto f) { for (Skater *o : O.on) if (f(o)) return true; return false; };
  if (car == p) {
    p->wantSprint = p->st > 30 && !anyO([&](Skater *o) { return (o->x - p->x) * d > 0 && hyp(o->x - p->x, o->y - p->y) < 16; }) && hyp(ax - p->x, RK.cy - p->y) > 28;
    double gy = RK.cy + (p->lane ? p->lane : (p->y < RK.cy ? -1 : 1)) * 11;
    tx = ax - d * 16; ty = gy;
    double dn = hyp(ax - p->x, RK.cy - p->y);
    if (dn < 30) { tx = ax - d * 9; ty = RK.cy + (p->y < RK.cy ? -5 : 5); }
    for (Skater *o : O.on) { double dx = o->x - p->x, dy = o->y - p->y, dd = hyp(dx, dy); if (dd < 10 && dx * d > 0) ty += (dy > 0 ? -1 : 1) * 9; }
    if (dn < 40) { double a = skShotQ(p->team, p->x + d * 3, p->y - 4), b = skShotQ(p->team, p->x + d * 3, p->y + 4); if (std::fabs(a - b) > .08) ty += (a > b ? -1 : 1) * 5; }
    if (!(p->spin > 0) && p->st > 90 && !p->spinCd && (ax - p->x) * d > 60 && anyO([&](Skater *o) { return (o->x - p->x) * d > 0 && hyp(o->x - p->x, o->y - p->y) < 4.5; }) && rnd() < dt * .15) skSpin(p);
    if (!p->hasDk && !(p->spin > 0) && p->at.hand >= 5.5 && anyO([&](Skater *o) { return (o->x - p->x) * d > 0 && hyp(o->x - p->x, o->y - p->y) < 5; }) && rnd() < dt * (.25 + (p->at.hand - 5) * .12)) skDeke(p, skDekeSide(p, 0, 0));
    if (p->dec <= 0 && !(p->spin > 0)) {
      p->dec = .22 + rnd() * .15;
      bool front = (ax - p->x) * d > 4;
      bool userOpen = p->team == 0 && user && user != p && user->stun <= 0;
      if (p->team == 0 && SK->callPass > 0 && userOpen) { skPass(p, user); SK->callPass = 0; return {p->vx, p->vy}; }
      if (skShort(p->team)) { bool brk = !anyO([&](Skater *o) { return !((o->x - p->x) * d < 0); }) && (p->x - RK.L / 2) * d > -10;
        if (!brk && (p->x - RK.L / 2) * d < 25) { double ty2 = RK.cy + (p->y < RK.cy ? -1 : 1) * rand(18, 30); skShoot(p, ax + d * 4 - p->x, ty2 - p->y, .9, SH_WRIST, .1); return {p->vx, p->vy}; } }
      double nearO = 99; for (Skater *o : O.on) if (o->stun <= 0) nearO = std::min(nearO, hyp(o->x - p->x, o->y - p->y));
      double ai = D.ai, sk = (p->at.wacc + p->at.lacc) / 20; auto noise = [&] { return 1 + (rnd() - .5) * (p->team == 1 ? .5 / ai : .3); };
      double sq = skShotQ(p->team, p->x, p->y) * (.7 + .5 * sk) * noise() * (1 + .15 * skTilt(p->team));
      if (SK->gt - p->gotT < .35) sq *= 1.25;
      Skater *best = nullptr; double bv = -1, bq = 0;
      for (Skater *q : T.on) { if (q == p || q->stun > 0) continue;
        double lx = q->x + q->vx * .3, ly = q->y + q->vy * .3, dl = hyp(lx - p->x, ly - p->y); if (dl < 6 || dl > 95) continue;
        double lane = skLaneOpen(p->x, p->y, lx, ly, p->team); if (lane < 1.4) continue;
        double rcv = 99; for (Skater *o : O.on) if (o->stun <= 0) rcv = std::min(rcv, hyp(o->x - lx, o->y - ly)); if (rcv < 2.5) continue;
        bool ownZone = (p->x - ownX) * d < 45, cross = (p->y - RK.cy) * (ly - RK.cy) < 0;
        if (ownZone && cross && lane < 5) continue;
        double qq = skShotQ(p->team, lx, ly) * (.7 + .5 * (q->at.wacc + q->at.lacc) / 20);
        double v = qq * 1.5 + std::min(lane, 8.0) * .045 + std::min(rcv, 12.0) * .03 + clamp((lx - p->x) * d, -30, 40) * .006 - (dl > 60 ? (dl - 60) * .012 : 0) + (q->user ? .02 : 0);
        if (v > bv) { bv = v; best = q; bq = qq; } }
      if (p->team == 0 && SK->callPass > 0 && userOpen && skLaneOpen(p->x, p->y, user->x, user->y, 0) > .8) { skPass(p, user); SK->callPass = 0; return {p->vx, p->vy}; }
      bool oneT = SK->gt - p->gotT < .35 && sq > .26;
      bool shootNow = front && (p->st > 8 || dn < 20) && (oneT || sq > .5 || (sq > .3 && nearO < 6) || (sq > .22 && nearO < 3.5)) && !(!oneT && best && bq > sq * 1.35 + .12 && nearO > 3);
      if (shootNow && rnd() < clamp(.55 + .45 * ai, .5, 1)) {
        bool slap = p->src && dn > 22 && nearO > 9 && rnd() < fqSl(p->src) / (fqSl(p->src) + fqWr(p->src)) * .9;
        skAIShot(p, slap ? SH_SLAP : SH_WRIST); if (slap) return {p->vx * .85, p->vy * .85}; return {p->vx, p->vy};
      }
      if (best && ((bq > sq + .12 && bv > .35) || (nearO < 5 && bv > .15) || (nearO < 8 && sq < .15 && bv > .25 && rnd() < .5))) { skPass(p, best); return {p->vx, p->vy}; }
      if (userOpen && user->x * d > p->x * d + 5 && best == user && rnd() < .35) { skPass(p, user); return {p->vx, p->vy}; }
    }
  } else if (car && car->team == p->team) {
    bool deep = (car->x - RK.L / 2) * d > 10;
    if (P.passTo == p) { tx = P.x; ty = P.y; }
    else if (p->lane == 0) { tx = deep ? ax - d * 15 : car->x + d * (car->role == R_C ? 14 : 6); ty = RK.cy + (std::fabs(car->y - RK.cy) < 6 ? (car->y < RK.cy ? 9 : -9) : 0); }
    else { tx = deep ? ax - d * 30 : car->x - d * (car->role == R_C ? 10 : 2); ty = RK.cy + p->lane * (deep ? 20 : 17); }
  } else if (car) {
    int job = skDefJobPub(p, T, car, ownX);
    if (car->windT > 0 && !(p->block > 0) && p->st > 40) { double sx = ownX - car->x, sy = RK.cy - car->y, sl = hyp(sx, sy); if (!sl) sl = 1; double qx = p->x - car->x, qy = p->y - car->y, al = (qx * sx + qy * sy) / sl, ac = std::fabs(-qx * sy + qy * sx) / sl;
      if (al > 3 && al < 16 && ac < 3.5 && rnd() < dt * 1.4 * (car->team == 0 ? D.ai * .7 : 1)) skBlock(p); }
    if (job == 0) {
      tx = car->x + car->vx * .25 - d * (car->team == 0 ? D.gap : 1.5); ty = car->y + car->vy * .25;
      if (std::fabs(car->x - ownX) < 75 && (car->x - ownX) * d > -2) {
        p->step = std::max(0.0, p->step - dt);
        if (p->step <= 0 && rnd() < dt * (car->user ? .35 * D.ai : .6)) p->step = .7;
        if (p->step <= 0) { double nx = ownX + d * 3 - car->x, ny = RK.cy - car->y, nl = hyp(nx, ny); if (!nl) nl = 1; double gp = car->team == 0 ? D.gap + 2 : 3;
          tx = car->x + nx / nl * std::min(gp, nl * .6); ty = car->y + ny / nl * std::min(gp, nl * .6); }
      }
      double dd = hyp(car->x - p->x, car->y - p->y), uk = car->user ? D.poke : 1;
      p->wantSprint = dd > 10 && p->st > 35;
      if (dd < 3.6 && p->poke <= 0) { p->poke = 1.0 / std::min(1.0, D.ai); if (skPoke(p, car, .16 * uk) && car->user) pushFeed("POKED AWAY", "#ff7a7a"); }
      if (dd < 4 && p->dcd <= 0 && hyp(p->vx, p->vy) > 10 && rnd() < dt * (.15 + p->at.chk * .07) * D.ai * (car->user ? D.hit : 1)) { if (skStartCheck(p, car->x - p->x, car->y - p->y)) { p->dash = .28; p->dcd = 1.6; } }
    } else if (job == 2) { tx = ownX + d * 6; ty = RK.cy + clamp((car->y - RK.cy) * .25, -2.5, 2.5); }
    else if (job == 3) { tx = ownX + d * 15; ty = RK.cy + (car->y < RK.cy ? 5 : -5); }
    else {
      Skater *mk = nullptr; double bd = 1e9; for (Skater *q : O.on) if (q != car) { double dd = hyp(q->x - p->x, q->y - p->y); if (dd < bd) { bd = dd; mk = q; } }
      double tight = p->tend == TD_CRASH ? .16 : .38;
      if (mk) { tx = mk->x + (ownX - mk->x) * tight; ty = mk->y + (RK.cy - mk->y) * tight; } else { tx = ownX + d * 18; ty = RK.cy; }
    }
  } else {
    bool shotAt = P.hasShot && P.shot.team != p->team, ourShot = P.hasShot && P.shot.team == p->team;
    double px = P.x + P.vx * .35, py = P.y + P.vy * .35, dOwn = std::fabs(P.x - ownX);
    if (shotAt) {
      if (p->tend == TD_NET || p->tend == TD_USER) { tx = ownX + d * 7; ty = RK.cy; }
      else if (p->tend == TD_REB) { tx = ownX + d * 6; ty = RK.cy + (P.y < RK.cy ? 6.5 : -6.5); }
      else { Skater *o = nullptr; double bd = 1e9; for (Skater *q : O.on) if (q != P.shot.by) { double v = std::fabs(q->x - ownX); if (v < bd) { bd = v; o = q; } }
        if (o) { tx = o->x + (ownX - o->x) * .15; ty = o->y + (RK.cy - o->y) * .15; } else { tx = ownX + d * 10; ty = RK.cy; } }
    } else if (ourShot && P.shot.by != p) {
      if (p->tend == TD_CRASH) { tx = ax - d * 5; ty = RK.cy + (p->y < RK.cy ? -2.5 : 2.5); }
      else if (p->tend == TD_REB) { tx = ax - d * 9; ty = RK.cy + (p->y < RK.cy ? -7 : 7); }
      else { tx = ax - d * 30; ty = RK.cy + p->lane * 14; }
    } else {
      std::vector<Skater *> ch; for (Skater *q : T.on) if (!q->user || g_autoplay) ch.push_back(q);
      std::stable_sort(ch.begin(), ch.end(), [&](Skater *a, Skater *b) { return hyp(a->x - px, a->y - py) < hyp(b->x - px, b->y - py); });
      int ci = alIndex(ch, p); double nearD = hyp(px - p->x, py - p->y);
      bool userCloser = p->team == 0 && user && !g_autoplay && onTeam(0, user) && hyp(user->x - px, user->y - py) < nearD - 4;
      if (P.passTo == p || (ci == 0 && !userCloser) || (ci == 1 && p->tend == TD_CRASH && nearD < 22)) { tx = px; ty = py; p->wantSprint = p->st > 40 && nearD > 12; }
      else if (dOwn < 70 && (p->tend == TD_NET || p->tend == TD_REB)) { tx = ownX + d * (p->tend == TD_NET ? 7 : 14); ty = RK.cy + (p->tend == TD_REB ? (py < RK.cy ? 5 : -5) : 0); }
      else if (p->lane == 0) { tx = px - d * 4; ty = RK.cy; }
      else { tx = px - d * 12; ty = RK.cy + p->lane * 16; }
    }
  }
  tx = clamp(tx, 3, RK.L - 3); ty = clamp(ty, 3, RK.Wd - 3);
  if (p->dash > 0) return {p->dx * ms * 1.4, p->dy * ms * 1.4};
  double dx = tx - p->x, dy = ty - p->y, dd = hyp(dx, dy);
  if (dd < .5) return {0, 0};
  double sp = ms * std::min(1.0, dd / 4);
  return {dx / dd * sp, dy / dd * sp};
}

// CHL 2026 native - forward game engine, part 2: your controls (pad + touch), the CPU skaters, the goalies,
// the main update, the puck, goals, whistles, line changes and the end of the game. Ported from the web build.
#include "game.h"
#include "sk_int.h"

bool g_autoplay = false;

// ---------------------------------------------------------------- touch: on the ice it only skips the matchup card (the pad does everything else)
void skTouchFrame() {
  static Touch prev; const Touch &T = g_touch;
  for (int i = 0; i < T.n; i++) { bool was = false; for (int j = 0; j < prev.n; j++) if (prev.p[j].id == T.p[i].id) was = true; if (!was && SK->phase == PH_PREVIEW) SK->tap = true; }
  prev = T;
}
bool skTouchOn(int, double &, double &, double &, double &) { return false; }

// ---------------------------------------------------------------- the L passes: who is under which button
// SQUARE = your left winger, TRIANGLE = the center, CIRCLE = your right winger (by where they line up);
// whoever is left over (an extra attacker, a man who swapped spots) takes a free button
Skater *skMateFor(int btn) {
  if (!SK || !SK->user) return nullptr; Team &T = SK->T[SK->user->team];
  Skater *m[3] = {nullptr, nullptr, nullptr}; std::vector<Skater *> rest;
  for (Skater *q : T.on) { if (q == SK->user) continue; int k = q->role == R_LW ? 0 : q->role == R_C ? 1 : q->role == R_RW ? 2 : -1; if (k >= 0 && !m[k]) m[k] = q; else rest.push_back(q); }
  for (Skater *q : rest) for (int k : {1, 0, 2}) if (!m[k]) { m[k] = q; break; }
  return btn >= 0 && btn < 3 ? m[btn] : nullptr;
}
// a quick full turn of the left stick: the spin-o-rama
static bool skStick360(double lx, double ly) {
  static double last = 0, acc = 0, t0 = 0; static bool on = false;
  double m = hyp(lx, ly), t = now() / 1000;
  if (m < .6) { on = false; acc = 0; return false; }
  double a = std::atan2(ly, lx);
  if (!on) { on = true; last = a; acc = 0; t0 = t; return false; }
  double d = wrapA(a - last); last = a;
  if (acc * d < 0) { acc = 0; t0 = t; }            // changed direction: start over
  acc += d;
  if (t - t0 > .6) { acc = d; t0 = t; }             // too slow: only quick turns count
  if (std::fabs(acc) >= PI * 1.8) { acc = 0; t0 = t; return true; }
  return false;
}
Input skInput() {
  Input I; const Pad &pad = g_pad; uint32_t press = g_press;
  auto toW = [](double sx, double sy, double &wx, double &wy) { wx = -sy; wy = sx; };   // screen up = up the ice
  auto n = [](int v) { return (v - 128) / 127.0; };
  double lx = n(pad.lx), ly = n(pad.ly), rx = n(pad.rx), ry = n(pad.ry);
  if (hyp(lx, ly) > .18) toW(lx, ly, I.mx, I.my);
  if (hyp(rx, ry) > .2) { toW(rx, ry, I.ax, I.ay); I.am = hyp(rx, ry); }
  I.rsx = rx; I.rsy = ry; I.rsm = hyp(rx, ry); I.rb = pad.btn & B_R; I.lb = pad.btn & B_L;
  bool mine = SK->user && SK->puck.owner == SK->user;
  I.lHold = (pad.btn & B_L) && mine;
  if (I.lHold) {
    // L held with the puck: the face buttons pick who gets the pass (and do nothing else)
    if (press & B_SQUARE) I.lpass = 0; else if (press & B_TRIANGLE) I.lpass = 1; else if (press & B_CIRCLE) I.lpass = 2;
  } else {
    if (press & B_TRIANGLE) I.tri = true;
    if (press & B_CIRCLE) I.check = true;
    if (pad.btn & B_CIRCLE) I.chkDown = true;
    if (pad.btn & B_SQUARE) I.dk = true;
    if (press & B_SQUARE) I.dkP = true;
  }
  if (press & B_CROSS) I.pass = true;
  if (pad.btn & B_CROSS) I.xdown = true;
  if (pad.btn & B_R) I.sprint = true;
  if ((press & B_L) && !mine) I.block = true;
  if (skStick360(lx, ly)) I.spin = true;
  if (SK->tap) { I.pass = true; SK->tap = false; }
  return I;
}
// teammates call for the puck when they have the better look: an open net, or a clear shot that beats yours
void skCallsUpdate(double dt) {
  Skater *u = SK ? SK->user : nullptr; bool live = u && SK->phase == PH_PLAY && SK->puck.owner == u && onTeam(0, u);
  for (Skater *q : SK->T[0].on) {
    if (q == u) continue;
    bool want = false;
    if (live && skInZone(q) && !q->stun && !(q->block > 0)) {
      double mq = skShotQ(0, q->x, q->y), uq = skShotQ(0, u->x, u->y), lane = skLaneOpen(u->x, u->y, q->x, q->y, 0);
      bool en = SK->T[1].g.out;
      want = lane > 2.5 && ((en && mq > .25) || mq > .42 || (mq > .28 && mq > uq + .08));
    }
    if (want) q->call = std::max(q->call, .7); else q->call = std::max(0.0, q->call - dt);
  }
}

// ---------------------------------------------------------------- the goalies
Pose poseOf(const char *s) { std::string q = s; return q == "lo" ? GP_LO : q == "kick" ? GP_KICK : q == "hi" ? GP_HI : q == "body" ? GP_BODY : q == "dive" ? GP_DIVE : q == "poke" ? GP_POKE : q == "cover" ? GP_COVER : q == "look" ? GP_LOOK : GP_NONE; }
void skGoalieAnimStart(Goalie &g, Pose pose, double side, double hold) {
  if (g.hasAn && g.an.p == pose && g.an.s == side && g.an.t < g.an.i + g.an.h) return;
  g.hasAn = true; g.an = GAnim(); g.an.p = pose; g.an.s = side ? side : 1; g.an.t = 0; g.an.i = pose == GP_DIVE ? .14 : .09;
  g.an.h = hold > 0 ? hold : (pose == GP_DIVE ? .4 : .38); g.an.o = pose == GP_DIVE ? .35 : .22;
}
void skGoalieReact(Goalie &g, double px, double py, double pvx, double pvy, double h) {
  if (g.out || g.user) return;
  double d = tdir(g.team), vx = pvx * -d; if (vx <= 5) return;
  double tt = std::max(.02, ((px - g.x) * d) / vx), yAt = py + pvy * tt, off = yAt - g.y;
  if (std::fabs(yAt - RK.cy) > RK.post + 3.5) { if (rnd() < .5) { g.hasRq = true; g.rq = {std::min(.12, tt * .5), GP_LOOK, off > 0 ? 1.0 : -1.0}; } return; }
  double reach = (1.6 + ((g.gs.agi - 50) / 49) * .6) * 1.65, side = off > 0 ? 1 : -1, a = std::fabs(off);
  Pose pose = a > reach * 1.3 && tt < .35 ? GP_DIVE : h < .4 ? (a > 1.1 ? GP_KICK : GP_LO) : (a < .55 ? GP_BODY : GP_HI);
  double rt = clamp(.1 - ((g.gs.agi - 50) / 49) * .06 + (g.broke ? .06 : 0), .03, .16);
  g.hasRq = true; g.rq = {std::min(rt, tt * .55), pose, side};
}
static void skGoalieAnim(Goalie &g, double dt, Puck &P, double gx, double d) {
  if (g.hasRq) { g.rq.t -= dt; if (g.rq.t <= 0) { g.hasRq = false; skGoalieAnimStart(g, g.rq.p, g.rq.s, g.rq.p == GP_LOOK ? .2 : -1); } }
  if (g.hasAn) { g.an.t += dt; if (g.an.t > g.an.i + g.an.h + g.an.o) g.hasAn = false; }
  g.set = SK->phase == PH_PLAY && (P.x - gx) * d > 0 && (P.x - gx) * d < 70 ? 1 : 0;
  Skater *c = P.owner;
  if (c && c->team != g.team && !g.hasAn && SK->phase == PH_PLAY) {
    double dd = hyp(c->x - g.x, c->y - g.y);
    if (dd < 6 && (c->x - g.x) * d > .5 && rnd() < dt * 2.4) { skGoalieAnimStart(g, GP_POKE, c->y > g.y ? 1 : -1, .18); g.pk = c; }
  }
  if (g.hasAn && g.an.p == GP_POKE && g.pk && g.an.t >= g.an.i && !g.an.done) { g.an.done = true; Skater *c2 = g.pk; g.pk = nullptr;
    if (P.owner == c2 && hyp(c2->x - g.x, c2->y - g.y) < 4.6 && rnd() < clamp(.32 + ((g.gs.agi - 50) / 49) * .15 - (c2->at.hand - 5) * .03, .12, .5) * (c2->user ? .6 : 1)) {
      skRelease(c2); c2->cool = .5; double a = std::atan2(P.y - g.y, (P.x - g.x)) + rand(-.6, .6); P.vx = std::fabs(std::cos(a)) * d * rand(22, 32); P.vy = std::sin(a) * rand(18, 28); P.last = c2; P.hasShot = false; P.passTo = nullptr; P.ice = -1;
      if (c2->user) pushFeed("POKED BY THE GOALIE", "#ff7a7a"); } }
}
void skGoalie(Goalie &g, double dt) {
  if (g.out) return;
  g.sv = std::max(0.0, g.sv - dt);
  { Puck &P0 = SK->puck; bool away = SK->phase != PH_PLAY || (P0.x - defendX(g.team)) * tdir(g.team) > RK.L / 2; double sa = (g.gs.sta - 50) / 49;
    g.ast = std::min(100.0, g.ast + (away ? 8 + sa * 6 : .6 + sa * 1.2) * dt);
    if (g.ast <= .5 && !g.broke) { g.broke = true; if (g.team == 1) pushFeed("THEIR GOALIE IS RATTLED!", "#ff7a7a"); } else if (g.broke && g.ast > 35) g.broke = false; }
  Puck &P = SK->puck; double gx = defendX(g.team), d = tdir(g.team); bool front = (P.x - gx) * d > 0;
  skGoalieAnim(g, dt, P, gx, d);
  if (g.hasBite) { g.bite.t -= dt; if (g.bite.t <= 0) g.hasBite = false; }
  double ty = front ? RK.cy + (P.y - RK.cy) * clamp(6 / std::max(6.0, std::fabs(P.x - gx)), .15, .55) : RK.cy + (P.y < RK.cy ? -2.4 : 2.4);
  ty = clamp(ty, RK.cy - (RK.post - 1.6), RK.cy + (RK.post - 1.6));
  double tx = gx + d * (front ? clamp(1.2 + std::fabs(P.x - gx) * .05, 1.2, 4) : 1);
  double ag = (g.gs.agi - 50) / 49, sp = (8 + ag * 10) * dt * (g.broke ? .5 : 1), dx = tx - g.x, dy = ty - g.y, dd = hyp(dx, dy);
  if (g.hasBite) { g.y = clamp(g.y + g.bite.s * 7 * dt, RK.cy - RK.post, RK.cy + RK.post); g.mv = g.bite.s * 7; return; }
  double oy = g.y; if (dd > sp) { g.x += dx / dd * sp; g.y += dy / dd * sp; } else { g.x = tx; g.y = ty; }
  g.mv = dt > 0 ? (g.y - oy) / dt : 0;
}
static void skFreeze(Goalie &g) {
  Puck &P = SK->puck; P.vx = P.vy = 0; P.owner = nullptr; P.hasShot = false;
  SK->phase = PH_STOP; SK->stopT = .9;
  double d = tdir(g.team), gx = defendX(g.team);
  SK->hasNextFo = true; SK->nextFo = {gx + d * 20, P.y < RK.cy ? RK.cy - 22 : RK.cy + 22};
  SK->banner = {.9, "SAVE", "", hex("#cbd5e1")};
}
static void skHoldAI(Goalie &g) {
  Puck &P = SK->puck; double d = tdir(g.team); P.vx = P.vy = 0; P.owner = nullptr; P.hasShot = false; P.passTo = nullptr; P.x = g.x + d * 1.2; P.y = g.y; P.pl = false; P.ice = -1; P.id++;
  SK->phase = PH_HOLD; SK->hold.on = true; SK->hold.t = 3; SK->hold.g = &g; SK->hold.dec = rand(.45, 1.3);
}
static void skUserFree(Skater *p, double dt);
void skHoldUpdate(double dt) {
  Goalie &g = *SK->hold.g; int t = g.team; double d = tdir(t); Puck &P = SK->puck;
  SK->hold.t -= dt; P.x = g.x + d * 1.2; P.y = g.y; P.vx = P.vy = 0;
  double gx = defendX(t); Pt tg[3] = {{gx + d * 24, RK.cy - 26}, {gx + d * 24, RK.cy + 26}, {gx + d * 48, RK.cy}};
  auto steer = [&](Skater *p, double tx, double ty, double sp) { double dx = tx - p->x, dy = ty - p->y, dd = hyp(dx, dy), wv = dd > 1 ? std::min(sp, dd * 2) : 0;
    p->vx += ((dd > 1 ? dx / dd * wv : 0) - p->vx) * std::min(1.0, dt * 3); p->vy += ((dd > 1 ? dy / dd * wv : 0) - p->vy) * std::min(1.0, dt * 3); p->x += p->vx * dt; p->y += p->vy * dt; skBoardsP(p, 1.3, .2); };
  auto &mine = SK->T[t].on; Skater *me = SK->user; int k = 0;
  for (Skater *p : mine) { if (p == me && !g_autoplay) skUserFree(p, dt); else { steer(p, tg[k % 3].x, tg[k % 3].y, 24); k++; } }
  { int i = 0; for (Skater *p : SK->T[1 - t].on) { if (p == me && !g_autoplay) skUserFree(p, dt); else steer(p, defendX(t) + d * (38 + i * 9), RK.cy + (i - 1) * 22, 14); i++; } }
  auto open = [&](Skater *p) { double m = 99; for (Skater *q : SK->T[1 - t].on) m = std::min(m, hyp(q->x - p->x, q->y - p->y)); return m; };
  bool pass = false, cover = false;
  SK->hold.dec -= dt;
  if (SK->hold.dec <= 0) { SK->hold.dec = 9; Skater *best = nullptr; double bo = -1; for (Skater *p : mine) if (p->stun <= 0) { double o = open(p); if (o > bo) { bo = o; best = p; } }
    if (best && open(best) > 11 && rnd() < .7) pass = true; else cover = true; }
  if (pass && !mine.empty()) {
    Skater *to = nullptr; double bs = -1; for (Skater *p : mine) { double o = open(p); if (o > bs) { bs = o; to = p; } }
    double spd = 62, dist = hyp(to->x - P.x, to->y - P.y), tt = dist / spd, lx = to->x + to->vx * tt * .8, ly = to->y + to->vy * tt * .8, a = std::atan2(ly - P.y, lx - P.x) + (rnd() - .5) * .1;
    P.x = g.x + d * 2; P.vx = std::cos(a) * spd; P.vy = std::sin(a) * spd; P.passTo = to; P.lastPasser = nullptr; P.passT = now(); P.last = nullptr; P.hasShot = false; P.id++; P.pl = true; P.clearThru(); P.clearTips(); P.pp = 0; P.ice = -1; P.saucer = false;
    SK->hold.on = false; SK->phase = PH_PLAY; g.sv = 0;
    if (to == me) pushFeed("OUTLET PASS TO YOU", "#93c5fd");
    return;
  }
  if (cover || SK->hold.t <= 0) { SK->hold.on = false; SK->phase = PH_PLAY; skFreeze(g); }
}
bool skGoalieSave(Goalie &g) {
  Puck &P = SK->puck; if (g.out || P.owner || g.user) return false;
  const GS &gs = g.gs;
  double d = tdir(g.team), toward = -P.vx * d, spd = hyp(P.vx, P.vy), dist = hyp(P.x - g.x, P.y - g.y);
  double reach = (1.6 + ((gs.agi - 50) / 49) * .6) * 1.65 * (g.broke ? .82 : 1);
  if (dist < 2.6 && spd < 14 && !(g.fum > SK->gt)) { skHoldAI(g); return true; }
  if (dist > reach || toward <= 5 || P.chk == (long)P.id * 10 + g.team) return false;
  P.chk = (long)P.id * 10 + g.team;
  double off = P.y - g.y; bool gloveSide = g.team == 0 ? off < 0 : off > 0; double h = P.hasShot ? P.shot.h : .3;
  int zone = h < .42 ? 0 : std::fabs(off) < .5 ? 1 : gloveSide ? 2 : 3;   // 0 pad, 1 body, 2 glove, 3 blocker
  double st = (zone == 0 ? gs.pad : zone == 2 ? gs.glv : zone == 3 ? gs.blk : gs.chs);
  const SkD &D = SKD(); double gk = g.team == 1 ? D.gk : -D.gk * .5;
  double sq = clamp(1 - std::fabs(off) / reach, 0, 1);
  static const double RS4[4] = {1, .6, .3, 0}, IM[4] = {1, .8, .65, .5};
  double fat = (1 - g.ast / 100) * .16, quick = SK->gt - g.lastSv < 1.3 ? (1 - (gs.rec - 50) / 49) * .12 * RS4[pkTg(&g, PK_RESET)] : 0;
  g.faced++; g.ast = std::max(0.0, g.ast - (11.5 - (gs.sta - 50) / 49 * 3.5) * IM[pkTg(&g, PK_IRONMAN)]);
  if (g.hot < 0) g.hot = rnd() < .08 ? .045 : 0;
  static const double SP4[4] = {0, .03, .05, .08}, PL4[4] = {0, .02, .035, .05}, FL4[4] = {0, .03, .045, .06};
  const Shot *S = P.hasShot ? &P.shot : nullptr;
  double ps = clamp(.725 + g.hot + std::max(0.0, 68 - st) * .0055 + (SK->T[g.team].score < SK->T[1 - g.team].score - 1 ? .035 * skTilt(g.team) : 0) - fat - quick - (g.broke ? .1 : 0)
    + ((st - 50) / 49) * .42 - (std::min(spd, S && S->otk ? 140.0 : 999.0) - 75) / 230 + gk + sq * .14 + (zone == 1 ? SP4[pkTg(&g, PK_STPAUL)] : 0) + (zone == 0 ? PL4[pkTg(&g, PK_PADLOCK)] : 0)
    - (S && S->flk ? FL4[S->flk] : 0) - (S && (S->tip || S->defl) ? .15 : 0) - (S && S->dk ? .04 + (S->by ? S->by->at.hand : 5) * .004 : 0)
    - (S && S->t < .35 && P.lastPasser && now() - P.passT < 900 ? .06 : 0), .2, .96);
  Skater *shooter = S ? S->by : nullptr; if (shooter && shooter->user) ps = std::min(.96, ps + .03);
  if (g.cd > SK->gt) ps *= 1 - (.5 - .3 * clamp((gs.rec - 40) / 59, 0, 1)) * RS4[pkTg(&g, PK_RESET)];
  int pl = pkTg(&g, PK_PADLOCK);
  bool five = S && h < .25 && std::fabs(off) < .65 && shooter && shooter->user && !(pl && rnd() < (pl == 1 ? .5 : pl == 2 ? .75 : 1));
  if (five) ps = std::max(.2, ps - .12);
  double roll = rnd(); int fz = -1;
  if (roll >= ps) { int t; if (zone == 2 && (t = pkCanG(&g, PK_LEATHER)) && rnd() < (t == 1 ? .4 : t == 2 ? .55 : .7)) fz = PK_LEATHER; else if ((t = pkCanG(&g, PK_ROBBER)) && rnd() < (t == 1 ? .35 : t == 2 ? .5 : .65)) fz = PK_ROBBER; if (fz >= 0) { roll = 0; pkSpendG(&g, fz); } }
  if (five && shooter && shooter->user && roll >= ps) { pushFeed("FIVE HOLE!", "#ffd54a"); return false; }
  if (roll < ps) {
    P.ice = -1; g.sv = .45; g.svSide = P.y > g.y ? 1 : -1; g.lastSv = SK->gt; sfx(S_SAVE, sndAt(g.x, g.y) * std::min(1.0, .4 + spd / 140), rand(.92, 1.08));
    { double rk = clamp((gs.rec - 40) / 59, 0, 1); bool dv = g.hasAn && g.an.p == GP_DIVE; g.cd = SK->gt + (.55 - .4 * rk) * (dv ? 1.9 - .8 * rk : 1); }
    { Pose want = fz == PK_ROBBER ? GP_DIVE : zone == 0 ? (std::fabs(off) > 1.1 ? GP_KICK : GP_LO) : zone == 1 ? GP_BODY : GP_HI; if (!g.hasAn || (g.an.p != want && g.an.p != GP_DIVE)) skGoalieAnimStart(g, want, g.svSide); }
    if (fz >= 0 && shooter && shooter->team == 0) pushFeed(fz == PK_ROBBER ? "ROBBED!" : "FLASH OF LEATHER!", "#ff7a7a");
    if (shooter) { SK->T[shooter->team].sog++; if (shooter->user) { SK->me.sog++; pushFeed(skShotName(P) + " ON NET", "#cbd5e1"); } }
    auto sk = [&](double v) { return clamp((v - 50) / 49, 0, 1); };
    { int tl = zone == 2 ? pkTg(&g, PK_LEATHER) : 0, ts = zone == 1 ? pkTg(&g, PK_STPAUL) : 0;
      if ((tl && rnd() < (tl == 1 ? .6 : tl == 2 ? .8 : 1)) || (ts && rnd() < (ts == 1 ? .7 : ts == 2 ? .85 : 1))) { skHoldAI(g); return true; } }
    if (S && S->otk && shooter && rnd() < (S->otk == 1 ? .4 : S->otk == 2 ? .7 : 1)) {
      Skater *al = nullptr; double bd = 1e9; for (Skater *q : SK->T[shooter->team].on) if (q != shooter && q->stun <= 0) { double dd = hyp(q->x - g.x, q->y - g.y); if (dd < bd) { bd = dd; al = q; } }
      if (al) { Pt st2 = stickPt(al); P.x = g.x + d * 1.4; double dx = st2.x - P.x, dy = st2.y - P.y, dd = hyp(dx, dy); if (!dd) dd = 1; double v = clamp(dd * 1.6, 18, 46);
        P.vx = dx / dd * v; P.vy = dy / dd * v; P.bz = 0; P.bvz = 0; P.hasShot = false; P.passTo = al; P.lastPasser = nullptr; P.pl = false; P.mag = 6; g.fum = SK->gt + .8; skPkFire(shooter, PK_OTKING);
        if (shooter->team == 0) pushFeed("REBOUND RIGHT TO " + upper(al->nm), "#ffd54a"); return true; } }
    if (spd < 50 || rnd() < (zone == 2 ? .55 + .35 * sk(gs.glv) : zone == 1 ? .3 + .5 * sk(gs.chs) : .15 + .15 * sk(gs.pad)) * (.6 + .4 * (g.ast / 100))) { skHoldAI(g); return true; }
    double ctl = sk(zone == 3 ? gs.blk : zone == 1 ? gs.chs : gs.pad);
    if (rnd() < .07 + (1 - ctl) * .09 + fat * .9 + (zone == 0 ? .04 : 0)) {
      P.x = g.x + d * 1.4; P.vx = d * rand(4, 10) * (1.15 - ctl * .3); P.vy = rand(-6, 6); P.hasShot = false; P.passTo = nullptr; g.fum = SK->gt + .55; P.bvz = rand(2.5, 5.5); P.wob = 1;
      if (shooter && shooter->team == 0) pushFeed("REBOUND!", "#ffd54a"); return true; }
    skPuckJolt(spd, 1.1);
    if (rnd() < .08 + ctl * .55) { double side = std::fabs(P.y - g.y) > .35 ? sgn(P.y - g.y) : (rnd() < .5 ? -1 : 1), v = rand(22, 34); P.vx = d * v * rand(.12, .38); P.vy = side * v; }
    else { double a = std::atan2(P.y - g.y, (P.x - g.x)) + rand(-.9, .9); P.vx = std::fabs(std::cos(a)) * d * rand(16, 30) * (1.15 - .4 * ctl); P.vy = std::sin(a) * rand(16, 30) * (.6 + .7 * ctl); }
    P.hasShot = false; P.passTo = nullptr;
    return true;
  }
  return false;
}

// ---------------------------------------------------------------- your skater
static Pt skStickTarget(const Skater *p, double rx, double &h) {
  double ax = attackX(p->team), d = tdir(p->team);
  if (skInZone(p)) { double ty = RK.cy + rx * (RK.post + 3.2); if (QO.autoAim) { ty = clamp(ty, RK.cy - RK.post + .6, RK.cy + RK.post - .6); h = std::min(h, .95); } return {ax, ty}; }
  double vx = d, vy = clamp(rx, -1, 1) * 1.4, l = hyp(vx, vy); h = std::min(h, .35); return {p->x + vx / l * 60, p->y + vy / l * 60};
}
static void skShotFake(Skater *p, double rx, double hIn) {
  Goalie &g = SK->T[1 - p->team].g;
  if (g.out || g.user) return;
  double dn = hyp(attackX(p->team) - p->x, RK.cy - p->y); if (dn > 55) return;
  double rd = g.gs.rd, h = hIn; Pt T = skStickTarget(p, rx, h);
  double bite = clamp(.88 - (rd - 40) / 59 * .9, .04, .85) * (dn < 30 ? 1.1 : .85);
  if (rnd() < bite) {
    double side = T.y > g.y ? 1 : -1; Pose pose = rd < 60 && rnd() < .5 ? GP_DIVE : hIn > .45 ? GP_HI : GP_KICK;
    skGoalieAnimStart(g, pose, side, .35); g.hasBite = true; g.bite = {.5, side}; g.cd = SK->gt + .45 + (70 - clamp(g.gs.rec, 40, 99)) * .008;
    pushFeed("HE BIT ON THE FAKE!", "#7CFC9A");
  } else pushFeed("HE DIDN'T BUY IT", "#94a3b8");
}
Pt skATarget(const Skater *p, double mx, double my, bool &none) {
  double m = hyp(mx, my), ax = attackX(p->team), d = tdir(p->team); none = false;
  if (m < .3) { if (skInZone(p) && QO.autoAim) { none = true; return {0, 0}; } return {p->x + std::cos(p->ang) * 60, p->y + std::sin(p->ang) * 60}; }
  if (skInZone(p) && mx * d > .05) { double ty = p->y + my / mx * (ax - p->x); if (QO.autoAim) ty = clamp(ty, RK.cy - RK.post + .6, RK.cy + RK.post - .6); return {ax, ty}; }
  return {p->x + mx / m * 60, p->y + my / m * 60};
}
static double skAutoHeight(const Skater *p, ShotKind kind, bool hasT, Pt T) {
  double acc = kind == SH_SLAP ? p->at.lacc : p->at.wacc; Goalie &g = SK->T[1 - p->team].g;
  if (rnd() < clamp(.25 + acc * .07, .25, .95)) { double side = hasT ? (T.y > g.y ? 1 : -1) : 1; bool glove = g.team == 0 ? side < 0 : side > 0; double hand = glove ? g.gs.glv : g.gs.blk;
    return rnd() < clamp(.5 + (g.gs.pad - hand) * .02, .2, .8) ? rand(.72, .92) : rand(.04, .18); }
  return rand(.35, .6);
}
// the shooting stick: from rest, a quick flick UP is a wrist shot; pull it DOWN to load a slap shot and push UP to fire
// (ease back to centre = a fake). The left stick aims.
static void skStickA(Skater *p, const Input &I, double dt, double mx, double my) {
  auto &RS = SK->rs; double ry = I.rsy, m = I.rsm;
  if (m < .3) { if (RS.dn) { RS.back += dt; if (RS.back > .3) { skShotFake(p, SK->lastMx, .5); RS.dn = false; p->wind = 0; } } else RS.rest = 0; return; }
  RS.rest += dt;
  if (ry > .55) { if (!RS.dn) { RS.dn = true; RS.t = 0; } RS.t += dt; RS.back = 0; p->wind = std::min(1.0, RS.t / .32); return; }
  if (ry < -.6) {
    int kind = RS.dn ? 1 : RS.rest < .16 ? 0 : -1; if (kind < 0) return;
    ShotKind K = kind ? SH_SLAP : SH_WRIST;
    double ch = kind ? clamp((RS.t - .15) / .75, 0, 1) : clamp(.25 + p->at.wpow * .075, 0, 1);
    RS.dn = false; p->wind = 0; RS.rest = 9;
    if (SK->puck.owner != p) return;
    bool none; Pt T = skATarget(p, mx, my, none); double h = skAutoHeight(p, K, !none, T);
    if (none) { skAutoShot(p, K, ch); return; }
    skShoot(p, T.x - p->x, T.y - p->y, ch, K, skInZone(p) ? h : .1);
  }
}
Want skUserControl(Skater *p, Input &I, double dt) {
  Puck &P = SK->puck; bool mine = P.owner == p, teamHas = P.owner && P.owner->team == p->team;
  double mx = I.mx, my = I.my, m = hyp(mx, my); if (m > 1) { mx /= m; my /= m; }
  auto &RS = SK->rs; if (m > .3) { SK->lastMx = mx; SK->lastMy = my; }
  if (mine && RS.dn) { I.spin = false; I.sprint = false; }
  { double cs = hyp(p->vx, p->vy), dot = cs > 1 && m > .2 ? (mx * p->vx + my * p->vy) / (cs * std::min(1.0, m)) : 1;
    if (dot > -.1) SK->dimeOk = SK->gt;
    if (cs > 12 && m > .7 && dot < -.7 && SK->gt - SK->dimeOk < .14 && !(p->hs > 0) && !(p->hsCd > SK->gt) && p->dash <= 0) {
      double sk = clamp((p->at.agl - 3.5) / 6.5, 0, 1); p->hs = .32; p->hsCd = SK->gt + .7; p->st = std::max(0.0, p->st - (20 - sk * 10)); p->stT = std::max(p->stT, 1.0); } }
  bool busy = mine && (RS.on || RS.dn);
  if (busy) { I.spin = false; I.sprint = false; }
  if (mine && I.spin) skSpin(p);
  if (mine && I.lpass >= 0 && !RS.dn) { Skater *to = skMateFor(I.lpass); if (to) { skPass(p, to); SK->xh.on = false; } }
  if (p->spin > 0) { p->wind = 0; double ms = skMaxSpd(p); return {mx * ms, my * ms}; }
  if (mine) {
    if (I.dkP && !RS.dn) skDeke(p, skDekeSide(p, mx, my));
    p->dkHeld = I.dk;
    skStickA(p, I, dt, mx, my);
    if (I.tri && P.owner == p && !RS.dn) { skPass(p, skBestPassTarget(p, I.mx, I.my), 0, true); SK->xh.on = false; }
    auto &X = SK->xh;
    if (I.pass && I.xdown && !X.on) { X.on = true; X.t = 0; }
    else if (I.pass && !X.on) skPass(p, skBestPassTarget(p, I.mx, I.my));
    if (X.on) { if (I.xdown) X.t += dt; else { double pw = X.t < .22 ? 0 : std::min(1.0, (X.t - .22) / .4); X.on = false; X.t = 0; if (P.owner == p) skPass(p, skBestPassTarget(p, I.mx, I.my), pw); } }
    if (I.ppass && P.owner == p) skPass(p, skBestPassTarget(p, I.mx, I.my), 1);
  } else {
    p->wind = 0; p->wl = 0; RS.on = false; SK->xh.on = false;
    if (I.block) skBlock(p);
    bool cv = false; double cvx = 0, cvy = 0, pw = 1;
    { auto &C = SK->ck;
      if (I.chkDown && !teamHas) { if (!C.dn) { C.dn = true; C.t = 0; } C.t = std::min(.9, C.t + dt); }
      else if (C.dn) { C.dn = false; pw = C.t < .22 ? .5 : .85 + std::min(1.0, (C.t - .22) / .6) * .6; cv = true; }
      if (cv) { if (m > .3) { cvx = mx; cvy = my; }
        else { Skater *tg = nullptr; if (P.owner && P.owner->team != p->team) tg = P.owner;
          else { double bd = 1e9; for (Skater *o : SK->T[1 - p->team].on) { double dd = hyp(o->x - p->x, o->y - p->y); if (dd < bd) { bd = dd; tg = o; } } }
          if (tg) { cvx = tg->x - p->x; cvy = tg->y - p->y; } else { cvx = std::cos(p->ang); cvy = std::sin(p->ang); } } } }
    if (I.hasRel && !teamHas) { cv = true; cvx = I.relx; cvy = I.rely; pw = 1; }
    if (cv) skStartCheck(p, cvx, cvy, pw);
    if (I.pass) {
      if (teamHas) SK->callPass = .9;
      else if (p->poke <= 0) { p->poke = .45; if (skPoke(p, P.owner, .42)) { SK->me.tk++; pushFeed("POKE CHECK!", "#7CFC9A"); } }
    }
  }
  double ms = skMaxSpd(p);
  if (p->dash > 0) return {p->dx * ms * 1.45, p->dy * ms * 1.45};
  if (mine && RS.dn) return {p->vx, p->vy, true};
  if (p->wind > 0 || p->wl > 0 || RS.on) return {mx * ms * .72, my * ms * .72};
  return {mx * ms, my * ms};
}
static void skUserFree(Skater *p, double dt) {
  Input I = skInput(); Want w = skUserControl(p, I, dt);
  p->vx += (w.vx - p->vx) * std::min(1.0, dt * 4); p->vy += (w.vy - p->vy) * std::min(1.0, dt * 4); p->x += p->vx * dt; p->y += p->vy * dt; skBoardsP(p, 1.3, .2);
}

// ---------------------------------------------------------------- the CPU skaters
Want skAI(Skater *p, double dt) {
  Puck &P = SK->puck; Team &T = SK->T[p->team], &O = SK->T[1 - p->team]; double d = tdir(p->team); Skater *car = P.owner; double ms = skMaxSpd(p); const SkD &D = SKD();
  double tx = p->x, ty = p->y;
  p->dec -= dt;
  double ax = attackX(p->team), ownX = defendX(p->team);
  p->wantSprint = false; if (car != p && p->windT > 0) { p->windT = 0; p->wind = 0; }
  Skater *user = SK->user;
  if (car == p && p->windT > 0) {
    p->windT -= dt; p->wind = std::min(1.0, 1 - p->windT / .42);
    if (p->windT <= 0) { p->aiCh = p->windAim.ch; skShoot(p, p->windAim.x - p->x, p->windAim.y - p->y, 0, SH_SLAP, p->windAim.h); p->aiCh = -1; }
    return {p->vx * .85, p->vy * .85};
  }
  auto anyO = [&](auto f) { for (Skater *o : O.on) if (f(o)) return true; return false; };
  if (car == p) {
    p->wantSprint = p->st > 30 && !anyO([&](Skater *o) { return (o->x - p->x) * d > 0 && hyp(o->x - p->x, o->y - p->y) < 16; }) && hyp(ax - p->x, RK.cy - p->y) > 28;
    double gy = RK.cy + (p->lane ? p->lane : (p->y < RK.cy ? -1 : 1)) * 11;
    tx = ax - d * 16; ty = gy;
    double dn = hyp(ax - p->x, RK.cy - p->y);
    if (dn < 30) { tx = ax - d * 9; ty = RK.cy + (p->y < RK.cy ? -5 : 5); }
    for (Skater *o : O.on) { double dx = o->x - p->x, dy = o->y - p->y, dd = hyp(dx, dy); if (dd < 10 && dx * d > 0) ty += (dy > 0 ? -1 : 1) * 9; }
    if (dn < 40) { double a = skShotQ(p->team, p->x + d * 3, p->y - 4), b = skShotQ(p->team, p->x + d * 3, p->y + 4); if (std::fabs(a - b) > .08) ty += (a > b ? -1 : 1) * 5; }
    if (!(p->spin > 0) && p->st > 90 && !p->spinCd && (ax - p->x) * d > 60 && anyO([&](Skater *o) { return (o->x - p->x) * d > 0 && hyp(o->x - p->x, o->y - p->y) < 4.5; }) && rnd() < dt * .15) skSpin(p);
    if (!p->hasDk && !(p->spin > 0) && p->at.hand >= 5.5 && anyO([&](Skater *o) { return (o->x - p->x) * d > 0 && hyp(o->x - p->x, o->y - p->y) < 5; }) && rnd() < dt * (.25 + (p->at.hand - 5) * .12)) skDeke(p, skDekeSide(p, 0, 0));
    if (p->dec <= 0 && !(p->spin > 0)) {
      p->dec = .22 + rnd() * .15;
      bool front = (ax - p->x) * d > 4;
      bool userOpen = p->team == 0 && user && user != p && user->stun <= 0;
      if (p->team == 0 && SK->callPass > 0 && userOpen) { skPass(p, user); SK->callPass = 0; return {p->vx, p->vy}; }
      if (skShort(p->team)) { bool brk = !anyO([&](Skater *o) { return !((o->x - p->x) * d < 0); }) && (p->x - RK.L / 2) * d > -10;
        if (!brk && (p->x - RK.L / 2) * d < 25) { double ty2 = RK.cy + (p->y < RK.cy ? -1 : 1) * rand(18, 30); skShoot(p, ax + d * 4 - p->x, ty2 - p->y, .9, SH_WRIST, .1); return {p->vx, p->vy}; } }
      double nearO = 99; for (Skater *o : O.on) if (o->stun <= 0) nearO = std::min(nearO, hyp(o->x - p->x, o->y - p->y));
      double ai = D.ai, sk = (p->at.wacc + p->at.lacc) / 20; auto noise = [&] { return 1 + (rnd() - .5) * (p->team == 1 ? .5 / ai : .3); };
      double sq = skShotQ(p->team, p->x, p->y) * (.7 + .5 * sk) * noise() * (1 + .15 * skTilt(p->team));
      if (SK->gt - p->gotT < .35) sq *= 1.25;
      Skater *best = nullptr; double bv = -1, bq = 0;
      for (Skater *q : T.on) { if (q == p || q->stun > 0) continue;
        double lx = q->x + q->vx * .3, ly = q->y + q->vy * .3, dl = hyp(lx - p->x, ly - p->y); if (dl < 6 || dl > 95) continue;
        double lane = skLaneOpen(p->x, p->y, lx, ly, p->team); if (lane < 1.4) continue;
        double rcv = 99; for (Skater *o : O.on) if (o->stun <= 0) rcv = std::min(rcv, hyp(o->x - lx, o->y - ly)); if (rcv < 2.5) continue;
        bool ownZone = (p->x - ownX) * d < 45, cross = (p->y - RK.cy) * (ly - RK.cy) < 0;
        if (ownZone && cross && lane < 5) continue;
        double qq = skShotQ(p->team, lx, ly) * (.7 + .5 * (q->at.wacc + q->at.lacc) / 20);
        double v = qq * 1.5 + std::min(lane, 8.0) * .045 + std::min(rcv, 12.0) * .03 + clamp((lx - p->x) * d, -30, 40) * .006 - (dl > 60 ? (dl - 60) * .012 : 0) + (q->user ? .02 : 0);
        if (v > bv) { bv = v; best = q; bq = qq; } }
      if (p->team == 0 && SK->callPass > 0 && userOpen && skLaneOpen(p->x, p->y, user->x, user->y, 0) > .8) { skPass(p, user); SK->callPass = 0; return {p->vx, p->vy}; }
      bool oneT = SK->gt - p->gotT < .35 && sq > .26;
      bool shootNow = front && (p->st > 8 || dn < 20) && (oneT || sq > .5 || (sq > .3 && nearO < 6) || (sq > .22 && nearO < 3.5)) && !(!oneT && best && bq > sq * 1.35 + .12 && nearO > 3);
      if (shootNow && rnd() < clamp(.55 + .45 * ai, .5, 1)) {
        bool slap = p->src && dn > 22 && nearO > 9 && rnd() < fqSl(p->src) / (fqSl(p->src) + fqWr(p->src)) * .9;
        skAIShot(p, slap ? SH_SLAP : SH_WRIST); if (slap) return {p->vx * .85, p->vy * .85}; return {p->vx, p->vy};
      }
      if (best && ((bq > sq + .12 && bv > .35) || (nearO < 5 && bv > .15) || (nearO < 8 && sq < .15 && bv > .25 && rnd() < .5))) { skPass(p, best); return {p->vx, p->vy}; }
      if (userOpen && user->x * d > p->x * d + 5 && best == user && rnd() < .35) { skPass(p, user); return {p->vx, p->vy}; }
    }
  } else if (car && car->team == p->team) {
    bool deep = (car->x - RK.L / 2) * d > 10;
    if (P.passTo == p) { tx = P.x; ty = P.y; }
    else if (p->lane == 0) { tx = deep ? ax - d * 15 : car->x + d * (car->role == R_C ? 14 : 6); ty = RK.cy + (std::fabs(car->y - RK.cy) < 6 ? (car->y < RK.cy ? 9 : -9) : 0); }
    else { tx = deep ? ax - d * 30 : car->x - d * (car->role == R_C ? 10 : 2); ty = RK.cy + p->lane * (deep ? 20 : 17); }
  } else if (car) {
    int job = skDefJobPub(p, T, car, ownX);
    if (car->windT > 0 && !(p->block > 0) && p->st > 40) { double sx = ownX - car->x, sy = RK.cy - car->y, sl = hyp(sx, sy); if (!sl) sl = 1; double qx = p->x - car->x, qy = p->y - car->y, al = (qx * sx + qy * sy) / sl, ac = std::fabs(-qx * sy + qy * sx) / sl;
      if (al > 3 && al < 16 && ac < 3.5 && rnd() < dt * 1.4 * (car->team == 0 ? D.ai * .7 : 1)) skBlock(p); }
    if (job == 0) {
      tx = car->x + car->vx * .25 - d * (car->team == 0 ? D.gap : 1.5); ty = car->y + car->vy * .25;
      if (std::fabs(car->x - ownX) < 75 && (car->x - ownX) * d > -2) {
        p->step = std::max(0.0, p->step - dt);
        if (p->step <= 0 && rnd() < dt * (car->user ? .35 * D.ai : .6)) p->step = .7;
        if (p->step <= 0) { double nx = ownX + d * 3 - car->x, ny = RK.cy - car->y, nl = hyp(nx, ny); if (!nl) nl = 1; double gp = car->team == 0 ? D.gap + 2 : 3;
          tx = car->x + nx / nl * std::min(gp, nl * .6); ty = car->y + ny / nl * std::min(gp, nl * .6); }
      }
      double dd = hyp(car->x - p->x, car->y - p->y), uk = car->user ? D.poke : 1;
      p->wantSprint = dd > 10 && p->st > 35;
      if (dd < 3.6 && p->poke <= 0) { p->poke = 1.0 / std::min(1.0, D.ai); if (skPoke(p, car, .16 * uk) && car->user) pushFeed("POKED AWAY", "#ff7a7a"); }
      if (dd < 4 && p->dcd <= 0 && hyp(p->vx, p->vy) > 10 && rnd() < dt * (.15 + p->at.chk * .07) * D.ai * (car->user ? D.hit : 1)) { if (skStartCheck(p, car->x - p->x, car->y - p->y)) { p->dash = .28; p->dcd = 1.6; } }
    } else if (job == 2) { tx = ownX + d * 6; ty = RK.cy + clamp((car->y - RK.cy) * .25, -2.5, 2.5); }
    else if (job == 3) { tx = ownX + d * 15; ty = RK.cy + (car->y < RK.cy ? 5 : -5); }
    else {
      Skater *mk = nullptr; double bd = 1e9; for (Skater *q : O.on) if (q != car) { double dd = hyp(q->x - p->x, q->y - p->y); if (dd < bd) { bd = dd; mk = q; } }
      double tight = p->tend == TD_CRASH ? .16 : .38;
      if (mk) { tx = mk->x + (ownX - mk->x) * tight; ty = mk->y + (RK.cy - mk->y) * tight; } else { tx = ownX + d * 18; ty = RK.cy; }
    }
  } else {
    bool shotAt = P.hasShot && P.shot.team != p->team, ourShot = P.hasShot && P.shot.team == p->team;
    double px = P.x + P.vx * .35, py = P.y + P.vy * .35, dOwn = std::fabs(P.x - ownX);
    if (shotAt) {
      if (p->tend == TD_NET || p->tend == TD_USER) { tx = ownX + d * 7; ty = RK.cy; }
      else if (p->tend == TD_REB) { tx = ownX + d * 6; ty = RK.cy + (P.y < RK.cy ? 6.5 : -6.5); }
      else { Skater *o = nullptr; double bd = 1e9; for (Skater *q : O.on) if (q != P.shot.by) { double v = std::fabs(q->x - ownX); if (v < bd) { bd = v; o = q; } }
        if (o) { tx = o->x + (ownX - o->x) * .15; ty = o->y + (RK.cy - o->y) * .15; } else { tx = ownX + d * 10; ty = RK.cy; } }
    } else if (ourShot && P.shot.by != p) {
      if (p->tend == TD_CRASH) { tx = ax - d * 5; ty = RK.cy + (p->y < RK.cy ? -2.5 : 2.5); }
      else if (p->tend == TD_REB) { tx = ax - d * 9; ty = RK.cy + (p->y < RK.cy ? -7 : 7); }
      else { tx = ax - d * 30; ty = RK.cy + p->lane * 14; }
    } else {
      std::vector<Skater *> ch; for (Skater *q : T.on) if (!q->user || g_autoplay) ch.push_back(q);
      std::stable_sort(ch.begin(), ch.end(), [&](Skater *a, Skater *b) { return hyp(a->x - px, a->y - py) < hyp(b->x - px, b->y - py); });
      int ci = alIndex(ch, p); double nearD = hyp(px - p->x, py - p->y);
      bool userCloser = p->team == 0 && user && !g_autoplay && onTeam(0, user) && hyp(user->x - px, user->y - py) < nearD - 4;
      if (P.passTo == p || (ci == 0 && !userCloser) || (ci == 1 && p->tend == TD_CRASH && nearD < 22)) { tx = px; ty = py; p->wantSprint = p->st > 40 && nearD > 12; }
      else if (dOwn < 70 && (p->tend == TD_NET || p->tend == TD_REB)) { tx = ownX + d * (p->tend == TD_NET ? 7 : 14); ty = RK.cy + (p->tend == TD_REB ? (py < RK.cy ? 5 : -5) : 0); }
      else if (p->lane == 0) { tx = px - d * 4; ty = RK.cy; }
      else { tx = px - d * 12; ty = RK.cy + p->lane * 16; }
    }
  }
  tx = clamp(tx, 3, RK.L - 3); ty = clamp(ty, 3, RK.Wd - 3);
  if (p->dash > 0) return {p->dx * ms * 1.4, p->dy * ms * 1.4};
  double dx = tx - p->x, dy = ty - p->y, dd = hyp(dx, dy);
  if (dd < .5) return {0, 0};
  double sp = ms * std::min(1.0, dd / 4);
  return {dx / dd * sp, dy / dd * sp};
}

// trophy.h - CHL 2026's trophies, in the PS Vita's own Trophies app: they pop with the system's notification and stay on
// the console like any game's. The pack is vita/sce_sys/trophy/NPWR90226_00/TROPHY.TRP (tools/make_trophies.py builds
// it; the ids below must match that list). A homebrew pack isn't signed by Sony, so the console needs Rinnegatamante's
// NoTrpDrm plugin to accept it; without the plugin (or on the PC test build) nothing pops and the game plays on.
#pragma once

enum TrophyId {
  TR_PLATINUM = 0, TR_FIRST_GAME, TR_FIRST_GOAL, TR_HAT_TRICK, TR_PLAYMAKER, TR_DRAFTED, TR_BIG_LEAGUE, TR_CENTURY,
  TR_TEAM_GOAL, TR_CHEMISTRY, TR_NEW_DIGS, TR_PLAYER_ONE, TR_PACK_RAT, TR_SHINY, TR_FULL_BINDER, TR_NATURAL,
  TR_HIGH_ROLLER, TR_UT_WIN, TR_QUICK_WIN, TR_SHUTOUT, TR_LOOKING_SHARP, TR_COUNT
};
void trophyInit();            // at start-up: load the trophy module and register the pack (off the main thread)
void trophyUnlock(int id);    // earn one (again is fine: the console ignores repeats). Never blocks the game
void trophyCheckPro();        // looks over the Be a Pro career for any trophy it has earned (after games, purchases...)
bool trophyActive();
bool trophyTick();             // every frame before the swap (the Vita build): true while the trophy setup dialog is up          // the console accepted the pack (false: no NoTrpDrm, or the PC build)

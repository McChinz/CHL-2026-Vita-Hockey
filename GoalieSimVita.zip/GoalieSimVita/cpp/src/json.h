// CHL 2026 native - a small dynamic JSON value. Ultimate Franchise and career state live in these, shaped
// exactly like the legacy JS objects, so the code ports line by line and save files keep the legacy format
// (legacy saves load as they are).
#pragma once
#include <string>
#include <vector>
#include <cstdint>

struct J {
  enum T : uint8_t { NUL, BOOL, NUM, STR, ARR, OBJ } t = NUL;
  bool b = false; double n = 0; std::string s;
  std::vector<J> a;                       // array items, or object values
  std::vector<std::string> k;             // object keys (insertion order, like JS)

  J() {}
  J(std::nullptr_t) {}
  J(bool v) : t(BOOL), b(v) {}
  J(int v) : t(NUM), n(v) {}
  J(long v) : t(NUM), n((double)v) {}
  J(long long v) : t(NUM), n((double)v) {}
  J(unsigned v) : t(NUM), n(v) {}
  J(size_t v) : t(NUM), n((double)v) {}
  J(double v) : t(NUM), n(v) {}
  J(const char *v) : t(STR), s(v) {}
  J(const std::string &v) : t(STR), s(v) {}
  static J arr() { J j; j.t = ARR; return j; }
  static J obj() { J j; j.t = OBJ; return j; }

  bool isNull() const { return t == NUL; }
  bool isArr() const { return t == ARR; }
  bool isObj() const { return t == OBJ; }
  bool isNum() const { return t == NUM; }
  bool isStr() const { return t == STR; }
  // JS truthiness
  bool truthy() const { return t == BOOL ? b : t == NUM ? (n != 0 && n == n) : t == STR ? !s.empty() : t != NUL; }
  explicit operator bool() const { return truthy(); }
  double num(double d = 0) const { return t == NUM ? n : t == BOOL ? (b ? 1 : 0) : d; }
  int i(int d = 0) const { return t == NUM ? (int)n : t == BOOL ? (b ? 1 : 0) : d; }
  const std::string &str() const { static const std::string e; return t == STR ? s : e; }

  // objects
  bool has(const std::string &key) const { if (t != OBJ) return false; for (auto &q : k) if (q == key) return true; return false; }
  const J *get(const std::string &key) const { if (t != OBJ) return nullptr; for (size_t x = 0; x < k.size(); x++) if (k[x] == key) return &a[x]; return nullptr; }
  J *get(const std::string &key) { if (t != OBJ) return nullptr; for (size_t x = 0; x < k.size(); x++) if (k[x] == key) return &a[x]; return nullptr; }
  J &operator[](const std::string &key) {   // creates the key (and turns null into an object), like obj[key] = ...
    if (t != OBJ) { *this = obj(); }
    for (size_t x = 0; x < k.size(); x++) if (k[x] == key) return a[x];
    k.push_back(key); a.emplace_back(); return a.back();
  }
  J &operator[](const char *key) { return (*this)[std::string(key)]; }
  const J &operator()(const std::string &key) const { static const J nul; const J *p = get(key); return p ? *p : nul; }   // read-only, null if missing
  void erase(const std::string &key) { if (t != OBJ) return; for (size_t x = 0; x < k.size(); x++) if (k[x] == key) { k.erase(k.begin() + x); a.erase(a.begin() + x); return; } }
  // arrays
  size_t size() const { return (t == ARR || t == OBJ) ? a.size() : 0; }
  J &operator[](size_t x) { return a[x]; }
  const J &operator[](size_t x) const { return a[x]; }
  J &operator[](int x) { return a[(size_t)x]; }
  const J &operator[](int x) const { return a[(size_t)x]; }
  void push(const J &v) { if (t != ARR) *this = arr(); a.push_back(v); }

  std::string dump() const;
  static J parse(const std::string &src, bool *ok = nullptr);
};

// CHL 2026 native - Ultimate Franchise screens: the hub, opponents, the shop, inventory, pack opening, the roster
// with the card menu, the examine view (the card grows and flips to every rating, perks and his line with your
// team), Road to the Cup. Ported from the legacy build: same layout, sizes, colours and animation timings.
#include "ut_int.h"
#include "sk_int.h"

bool utOpenOn = false; UOpen utOpen;
bool utMenuOnF = false; UMenu utMenu;
bool utExOnF = false; UEx utEx;
int utSel = 0, utPage = 0, utSwap = -1; bool utSell = false, utSwapFocus = false;
bool utExOn() { return utExOnF; }
bool utMenuOn() { return utMenuOnF; }
static struct { double t = -1e9; std::string s; } utMsg;
void utFlash(const std::string &s) { utMsg.t = now(); utMsg.s = s; }
void menuSkFig(double f, int d, double stride, Col col, Col stripe, Col skin, Col helm, double lean, double wind, bool star);
void menuGoalieFig(double f, Col col, Col stripe, Col pants);

// ---------------------------------------------------------------- pieces
static void star5(double x, double y, double r) {   // the legend star (the font has no glyph for it)
  ctx.beginPath(); for (int i = 0; i < 10; i++) { double a = -PI / 2 + i * PI / 5, rr = i % 2 ? r * .45 : r; if (i) ctx.lineTo(x + std::cos(a) * rr, y + std::sin(a) * rr); else ctx.moveTo(x + std::cos(a) * rr, y + std::sin(a) * rr); }
  ctx.closePath(); ctx.fillPath();
}
static void utCoin(double x, double y, double r) {
  ctx.fill("#b45309"); ctx.disc(x, y + r * .12, r); ctx.fill("#fbbf24"); ctx.disc(x, y, r); ctx.fill("#fde68a"); ctx.disc(x, y, r * .62);
  ctx.fill("#d97706"); ctx.font(r * 1.05); ctx.textMid(); ctx.fillText("C", x, y + 1);
}
static void utCoins(double xr, double y, double n) {   // right-aligned coin counter
  std::string s = fmtN(n); double px = .036 * U; ctx.font(px); double w = ctx.measure(s), r = px * .42;
  ctx.fill(rgba(15, 23, 42, .8)); ctx.fillRect(xr - w - r * 2 - .03 * U, y - px * .75, w + r * 2 + .04 * U, px * 1.5);
  ctx.fill("#fde68a"); ctx.textMid(AL_RIGHT); ctx.fillText(s, xr - .012 * U, y + 1); utCoin(xr - w - r - .022 * U, y, r);
}
static const char *UT_SKIN[4] = {"#f1c7a0", "#e0a878", "#c68a5e", "#8d5a3b"};
static std::pair<Col, Col> utColOf(const UTPDef *P) {
  if (P && P->leg) return {hex("#1c1917"), hex("#fbbf24")};
  if (P && P->t >= 0) return {hex(teamCol(P->t)), hex(teamStr(P->t))};
  return {hex("#334155"), hex("#ffffff")};
}
static void pkBadge(int id, int t, double bx, double by, double r) {
  if (id < 0 || id >= PK_N) return; const PerkDef &q = PERKS[id];
  ctx.fill(rgba(2, 6, 23, .8)); ctx.disc(bx, by, r * 1.28); ctx.fill(TIERC[t]); ctx.disc(bx, by, r * 1.16); ctx.fill(q.col); ctx.disc(bx, by, r * .92);
  ctx.fill("#0b1220"); ctx.textMid(); double px = r * .9; ctx.font(px); double w = ctx.measure(q.ab); if (w > r * 1.5) ctx.font(px * r * 1.5 / w); ctx.fillText(q.ab, bx, by + 1);
}
// a full card at (0,0), width w (height 1.4w). Static, so it is cached under the current translate.
static void utCardFace(const UCard &c, double w) {
  static UTPDef dflt; if (dflt.nm.empty()) { dflt.nm = "?"; dflt.pos = 'F'; dflt.ov = 50; dflt.t = -1; }
  const UTPDef *P = UTM(c.p); if (!P) P = &dflt;
  const RarDef &R = RAR[c.r]; double h = w * 1.4; int o = utOv(c); bool sec = c.r == 6; auto cl = utColOf(P); Col skin = hex(UT_SKIN[skHash(P->nm) % 4]);
  Grad g = gLin(0, 0, 0, h); g.add(0, hex(R.c)); g.add(1, hex(R.d)); ctx.fill(g); ctx.rr(0, 0, w, h, w * .07); ctx.fillPath();
  double b = w * .045, ix = b, iy = b, iw = w - 2 * b, ih = h - 2 * b;
  auto fig = [&](double f, double fx, double fy) { ctx.save(); ctx.translate(fx, fy);
    if (P->pos == 'G') menuGoalieFig(f * .92, cl.first, cl.second, shade(cl.first, -.55));
    else menuSkFig(f, 2, .35, cl.first, cl.second, skin, shade(cl.first, -.15), .2, 0, false); ctx.restore(); };
  if (sec) {
    // full art: the player fills the card over light rays
    Grad g2 = gLin(0, iy, 0, iy + ih); g2.add(0, hex("#3b0764")); g2.add(1, hex("#be185d")); ctx.fill(g2); ctx.rr(ix, iy, iw, ih, w * .05); ctx.fillPath();
    double cx = w / 2, cy = h * .42, Rr = w * .95; ctx.fill(rgba(255, 236, 250, .13));
    for (int i = 0; i < 12; i++) { double a0 = i / 12.0 * PI * 2, a1 = a0 + .16;
      auto C = [&](double x, double y) { return Pt{clamp(x, ix, ix + iw), clamp(y, iy, iy + ih)}; };
      Pt p0 = C(cx, cy), p1 = C(cx + std::cos(a0) * Rr, cy + std::sin(a0) * Rr), p2 = C(cx + std::cos(a1) * Rr, cy + std::sin(a1) * Rr);
      ctx.beginPath(); ctx.moveTo(p0.x, p0.y); ctx.lineTo(p1.x, p1.y); ctx.lineTo(p2.x, p2.y); ctx.closePath(); ctx.fillPath(); }
    ctx.fill(rgba(255, 255, 255, .16)); ctx.disc(cx, cy, w * .3);
    fig(h * .085, w * .52, h * .74);
    Grad g3 = gLin(0, h * .64, 0, h * .8); g3.add(0, rgba(20, 4, 30, 0)); g3.add(1, rgba(20, 4, 30, .95)); ctx.fill(g3); ctx.fillRect(ix, h * .64, iw, h * .16); ctx.fill(rgba(20, 4, 30, .95)); ctx.fillRect(ix, h * .8, iw, h * .2 - b);
    ctx.fill("#fff"); for (int i = 0; i < 7; i++) { double sx = ix + w * .06 + ((i * 53) % 97) / 97.0 * (iw - w * .12), sy = iy + h * .2 + ((i * 31) % 61) / 61.0 * ih * .4, s = w * (.012 + (i % 3) * .008);
      ctx.quad(sx, sy - s * 2.4, sx + s, sy, sx, sy + s * 2.4, sx - s, sy); }
  } else {
    ctx.fill("#0b1220"); ctx.rr(ix, iy, iw, ih, w * .05); ctx.fillPath();
    double ay = h * .16, ah = h * .56; Grad g2 = gLin(0, ay, 0, ay + ah); g2.add(0, shade(cl.first, .25)); g2.add(1, shade(cl.first, -.55)); ctx.fill(g2); ctx.fillRect(ix, ay, iw, ah);
    ctx.fill(rgba(255, 255, 255, .08)); ctx.beginPath(); ctx.moveTo(ix + iw * .55, ay); ctx.lineTo(ix + iw, ay); ctx.lineTo(ix + iw, ay + ah * .5); ctx.closePath(); ctx.fillPath();
    ctx.fill(R.c); ctx.fillRect(ix, ay + ah - 2, iw, std::max(2.0, h * .012));
    fig(h * .08, w * .53, ay + ah * .86);
    ctx.fill("#0b1220"); ctx.fillRect(ix, ay + ah, iw, h * .2);
    if (c.r == 0) {   // WORN: faded, scuffed, dog-eared
      ctx.fill(rgba(120, 92, 58, .32)); ctx.fillRect(ix, ay, iw, ah);
      ctx.stroke(rgba(235, 225, 205, .35)); ctx.lineWidth(std::max(1.0, w * .008));
      for (int i = 0; i < 5; i++) { double x1 = ix + iw * ((i * 37) % 17) / 17.0, y1 = ay + ah * ((i * 23) % 11) / 11.0, l = w * (.15 + .08 * (i % 3)); ctx.line(x1, y1, std::min(ix + iw, x1 + l), std::min(ay + ah, y1 + l * .35)); }
      ctx.fill(rgba(235, 225, 205, .55)); ctx.beginPath(); ctx.moveTo(w, h * .9); ctx.lineTo(w, h); ctx.lineTo(w * .88, h); ctx.closePath(); ctx.fillPath();
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(w * .1, 0); ctx.lineTo(0, w * .1); ctx.closePath(); ctx.fillPath(); }
    if (c.r >= 4) { ctx.stroke(R.c); ctx.lineWidth(std::max(1.5, w * .018)); ctx.rr(ix + w * .02, iy + w * .02, iw - w * .04, ih - w * .04, w * .04); ctx.strokePath(); }
  }
  ctx.baseline(BL_MIDDLE);
  // OVR + position, top left
  ctx.fill("#fff"); ctx.font(w * .25); ctx.align(AL_LEFT); ctx.fillText(istr(o), ix + w * .04, iy + h * .075);
  { double ow = ctx.measure(istr(o)); ctx.font(w * .1); ctx.fill(R.c); ctx.fillText(P->pos == 'G' ? "G" : "F", ix + w * .06 + ow, iy + h * .1); }
  // club / legend tag, top right
  ctx.align(AL_RIGHT);
  if (P->leg) { ctx.fill("#fbbf24"); star5(ix + iw - w * .1, iy + h * .07, w * .065); ctx.font(w * .075); ctx.align(AL_RIGHT); ctx.fillText("LEGEND", ix + iw - w * .04, iy + h * .135); }
  else { ctx.fill("#e2e8f0"); ctx.font(w * .13); ctx.fillText(P->t >= 0 ? TDP[P->t].ab : "", ix + iw - w * .05, iy + h * .075); }
  // perks: a badge each, down the right side of the art
  { auto pk = pkCard(c); double r = w * .064; for (size_t i = 0; i < pk.size(); i++) pkBadge(pk[i].id, pk[i].t, ix + iw - r * 1.3 - w * .03, iy + h * .2 + r * 1.3 + i * (r * 2.8), r); }
  // name
  double ny = h * .815; ctx.fill("#fff"); ctx.baseline(BL_MIDDLE);
  utFitTx(upper(utLast(P->nm)), w / 2, ny, w * .15, iw - w * .08, AL_CENTER);
  ctx.fill("#cbd5e1"); { std::string first = P->nm.substr(0, P->nm.find(' ')); utFitTx(upper(first), w / 2, ny - h * .072, w * .08, iw - w * .1, AL_CENTER); }
  // rarity strip
  double sy = h - b - h * .085; ctx.fill(sec ? rgba(255, 122, 200, .95) : hex(R.c)); ctx.fillRect(ix + w * .06, sy, iw - w * .12, h * .07);
  ctx.fill(c.r <= 1 ? "#1e293b" : "#0b1220"); utFitTx(sec ? "SECRET  FULL ART" : R.n, w / 2, sy + h * .036, w * .085, iw - w * .16, AL_CENTER);
}
static void utCardBack(double w) {
  double h = w * 1.4; ctx.fill("#0f172a"); ctx.rr(0, 0, w, h, w * .07); ctx.fillPath();
  Grad g = gLin(0, 0, 0, h); g.add(0, hex("#1e293b")); g.add(1, hex("#0b1024")); ctx.fill(g); ctx.rr(w * .05, w * .05, w * .9, h - w * .1, w * .05); ctx.fillPath();
  ctx.fill(rgba(242, 107, 91, .22)); for (int i = 0; i < 5; i++) ctx.fillRect(w * .05, h * (.12 + i * .04), w * .9, h * .01); for (int i = 0; i < 5; i++) ctx.fillRect(w * .05, h * (.72 + i * .04), w * .9, h * .01);
  ctx.fill(rgba(15, 23, 42, .9)); ctx.fillRect(w * .05, h * .4, w * .9, h * .2);
  wordmarkC(w / 2, h / 2, w * .14);
  ctx.stroke(rgba(255, 255, 255, .25)); ctx.lineWidth(std::max(1.0, w * .012)); ctx.rr(w * .08, w * .08, w * .84, h - w * .16, w * .04); ctx.strokePath();
}
struct UCR_ { int u; double x, y, w, h; }; static std::vector<UCR_> UCR;   // the cards drawn this frame (for hold-to-flip)
static void utDrawCard(const UCard *c, double x, double y, double w, bool back = false) {
  if (!back && c && c->u && !utExOnF) UCR.push_back({c->u, x, y, w, w * 1.4});
  ctx.save(); ctx.translate(std::round(x), std::round(y)); int wr = (int)std::round(w);
  if (back) cached(Key("utb") << wr, [&] { utCardBack(wr); }); else { UCard cc = *c; cached(Key("utc") << c->p << c->r << wr, [&] { utCardFace(cc, wr); }); }
  ctx.restore();
  if (!back && c->r == 6) {   // twinkle
    double t = now() / 1000, h = w * 1.4; ctx.fill("#fff");
    for (int i = 0; i < 4; i++) { double a = .5 + .5 * std::sin(t * 3 + i * 1.7); if (a < .3) continue; double sx = x + w * (.45 + .4 * ((i * 37) % 11) / 11.0), sy = y + h * (.25 + .35 * ((i * 23) % 7) / 7.0), s = w * .025 * a;
      ctx.alpha(a); ctx.quad(sx, sy - s * 3, sx + s, sy, sx, sy + s * 3, sx - s, sy); ctx.quad(sx - s * 3, sy, sx, sy - s, sx + s * 3, sy, sx, sy + s); }
    ctx.alpha(1);
  }
}
// a card mid-flip: squeezed horizontally, simple shapes only
static void utCardFlip(const UCard &c, double x, double y, double w, double sx, bool back) {
  double h = w * 1.4, cw = std::max(1.0, w * sx), cx = x + w / 2 - cw / 2;
  if (back) { ctx.fill("#0f172a"); ctx.fillRect(cx, y, cw, h); ctx.fill("#1e293b"); ctx.fillRect(cx + cw * .06, y + w * .05, cw * .88, h - w * .1); ctx.fill(ACC); ctx.fillRect(cx + cw * .3, y + h * .47, cw * .4, h * .06); }
  else { const RarDef &R = RAR[c.r]; ctx.fill(R.c); ctx.fillRect(cx, y, cw, h); ctx.fill(c.r == 6 ? "#6b1a5e" : "#0b1220"); ctx.fillRect(cx + cw * .05, y + w * .05, cw * .9, h - w * .1); ctx.fill(R.c); ctx.fillRect(cx + cw * .06, y + h * .86, cw * .88, h * .07); }
}
static void utPackArt(const PackDef &pk, double w) {
  double h = w * 1.45; Col c = hex(pk.col);
  Grad g = gLin(0, 0, w, h); g.add(0, shade(c, .35)); g.add(1, shade(c, -.45)); ctx.fill(g);
  // crimped foil top and bottom
  ctx.beginPath(); ctx.moveTo(0, h * .05); const int n = 10; for (int i = 0; i <= n; i++) ctx.lineTo(w * i / n, i % 2 ? 0 : h * .05); ctx.lineTo(w, h * .95); for (int i = n; i >= 0; i--) ctx.lineTo(w * i / n, i % 2 ? h : h * .95); ctx.closePath(); ctx.fillPath();
  ctx.fill(rgba(255, 255, 255, .14)); ctx.beginPath(); ctx.moveTo(w * .15, h * .05); ctx.lineTo(w * .4, h * .05); ctx.lineTo(w * .1, h * .95); ctx.lineTo(0, h * .95); ctx.lineTo(0, h * .3); ctx.closePath(); ctx.fillPath();
  ctx.fill(rgba(0, 0, 0, .25)); ctx.fillRect(0, h * .07, w, h * .02); ctx.fillRect(0, h * .91, w, h * .02);
  wordmarkC(w / 2, h * .25, w * .15);
  ctx.fill("#fff"); ctx.baseline(BL_MIDDLE); utFitTx(pk.n, w / 2, h * .5, w * .2, w * .86, AL_CENTER);
  ctx.fill(rgba(255, 255, 255, .85)); utFitTx("PACK", w / 2, h * .6, w * .12, w * .8, AL_CENTER);
  ctx.fill(rgba(15, 23, 42, .55)); ctx.fillRect(w * .18, h * .7, w * .64, h * .11); ctx.fill("#fff"); utFitTx(istr(pk.k) + (pk.k > 1 ? " CARDS" : " CARD"), w / 2, h * .755, w * .1, w * .6, AL_CENTER);
  if (pk.leg) { ctx.fill("#fde68a"); star5(w / 2, h * .39, w * .07); }
}
static void packAt(int t, double x, double y, double pw) { ctx.save(); ctx.translate(std::round(x), std::round(y)); int p = (int)std::round(pw); cached(Key("upk") << t << p, [&] { utPackArt(UT_PACKS[t], p); }); ctx.restore(); }
static void utHead(const std::string &t, const std::string &sub) {
  double m = .035 * U, ty = safeTop + .05 * U;
  ctx.baseline(BL_MIDDLE); ctx.fill("#fff"); utFitTx(t, m, ty, .055 * U, W * .55, AL_LEFT);
  if (!sub.empty()) { ctx.fill(ACC); utFitTx(sub, m, ty + .045 * U, fsz(.02) * U, W * .6, AL_LEFT); }
  if (UT) utCoins(W - m, ty, UT->coins);
}
// a toast that slides down from the top centre (clear of every screen's buttons), then fades away
static void utToast() {
  double a = (now() - utMsg.t) / 1000; if (utMsg.s.empty() || a > 2.6) return;
  double k = clamp(std::min(a / .22, (2.6 - a) / .35), 0, 1), e = 1 - std::pow(1 - k, 3);
  double px = fsz(.024) * U; ctx.font(px); double tw = ctx.measure(utMsg.s), mx = W - .12 * U; if (tw > mx - .06 * U) { px *= (mx - .06 * U) / tw; ctx.font(px); }
  double h = safeTop + .075 * U, y0 = -(1 - e) * h;
  ctx.fill(rgba(8, 12, 24, .97)); ctx.fillRect(0, y0, W, h); ctx.fill("#fbbf24"); ctx.fillRect(0, y0 + h - .006 * U, W, .006 * U);
  ctx.fill(rgba(2, 6, 23, .35)); ctx.fillRect(0, y0 + h, W, .012 * U);
  ctx.alpha(std::min(1.0, e * 1.4)); ctx.fill("#fff"); ctx.textMid(); ctx.font(px); ctx.fillText(utMsg.s, W / 2, y0 + safeTop + .037 * U); ctx.alpha(1);
}
static std::string firstWords(const std::string &nm) { size_t p = nm.rfind(' '); return p == std::string::npos ? "" : nm.substr(0, p); }
static std::string nickOf(const std::string &nm) { size_t p = nm.rfind(' '); return p == std::string::npos ? nm : nm.substr(p + 1); }

// ---------------------------------------------------------------- Road to the Cup
static void drawCupTables(const Cup &C2, double x, double y, double w, double h) {
  double gap = .02 * U, tw = (w - gap) / 2;
  for (int d = 0; d < 2; d++) {
    double tx0 = x + d * (tw + gap), rh = (h - .06 * U) / 8; auto ord = cupStand(C2, d);
    ctx.fill(rgba(15, 23, 42, .88)); ctx.fillRect(tx0, y, tw, h);
    tx(d ? "NORTH DIVISION" : "SOUTH DIVISION", tx0 + .02 * U, y + .03 * U, .02, ACC, AL_LEFT);
    tx("W-L", tx0 + tw * .76, y + .03 * U, .018, "#94a3b8", AL_CENTER); tx("PTS", tx0 + tw - .025 * U, y + .03 * U, .018, "#94a3b8", AL_RIGHT);
    for (size_t k = 0; k < ord.size(); k++) { const CupTeam &t = C2.T[ord[k]]; double ry = y + .055 * U + k * rh; const char *const *cl = UT_COLS[t.col % 12];
      if (t.me) { ctx.fill(rgba(251, 191, 36, .16)); ctx.fillRect(tx0, ry, tw, rh); }
      if (k == 4) { ctx.fill(rgba(242, 107, 91, .6)); ctx.fillRect(tx0 + .01 * U, ry - 1, tw - .02 * U, 2); }     // playoff line
      ctx.fill(cl[0]); ctx.fillRect(tx0 + .012 * U, ry + rh * .2, .008 * U, rh * .6);
      TXR = tx0 + tw * .66; tx(istr(k + 1) + ". " + upper(t.nm), tx0 + .03 * U, ry + rh / 2, .019, t.me ? "#fbbf24" : "#e2e8f0", AL_LEFT); TXR = 1e4;
      tx(istr(t.w) + "-" + istr(t.l), tx0 + tw * .76, ry + rh / 2, .019, "#cbd5e1", AL_CENTER); tx(istr(cupPts(t)), tx0 + tw - .025 * U, ry + rh / 2, .021, "#fff", AL_RIGHT); }
  }
}
static void drawCupBracket(const Cup &C2, double x, double y, double w, double h) {
  ctx.fill(rgba(15, 23, 42, .88)); ctx.fillRect(x, y, w, h);
  double cw = (w - .08 * U) / 3, bh = .085 * U;
  for (int r = 0; r < 3; r++) {
    const std::vector<CupMatch> *R = r < (int)C2.br.size() ? &C2.br[r] : nullptr; int n = r == 0 ? 4 : r == 1 ? 2 : 1; double cx = x + .02 * U + r * (cw + .02 * U);
    tx(CUP_RN[r], cx, y + .03 * U, .018, ACC, AL_LEFT);
    for (int i = 0; i < n; i++) {
      double cyy = y + .06 * U + (h - .08 * U) * (i + .5) / n - bh / 2;
      ctx.fill(rgba(30, 41, 59, .95)); ctx.fillRect(cx, cyy, cw, bh);
      if (!R || i >= (int)R->size()) { tx("TBD", cx + cw / 2, cyy + bh / 2, .02, "#64748b", AL_CENTER); continue; }
      const CupMatch &M = (*R)[i];
      for (int j = 0; j < 2; j++) { int ti = j ? M.b : M.a, sc = j ? M.sb : M.sa; const CupTeam &t = C2.T[ti]; double yy = cyy + bh * (j ? .72 : .28); bool won = M.w == ti, lost = M.w >= 0 && !won;
        if (t.me) { ctx.fill(rgba(251, 191, 36, .18)); ctx.fillRect(cx, cyy + bh * j / 2, cw, bh / 2); }
        TXR = cx + cw - .05 * U; tx(upper(t.nm), cx + .012 * U, yy, .017, lost ? "#64748b" : t.me ? "#fbbf24" : "#fff", AL_LEFT); TXR = 1e4;
        if (M.w >= 0) tx(istr(sc), cx + cw - .012 * U, yy, .019, won ? "#fff" : "#64748b", AL_RIGHT); }
    }
  }
  if (C2.champ >= 0) tx("CHAMPION: " + upper(C2.T[C2.champ].nm), x + w / 2, y + h - .025 * U, .022, hex("#fbbf24"), AL_CENTER, true);
}
static void drawUTCup(UTX &X) {
  double m = .03 * U;
  if (!X.cup) {
    utHead("ROAD TO THE CUP", "A SHORT SEASON WITH YOUR CURRENT LINEUP");
    double w = std::min(W - 2 * m, 1.3 * U), x = (W - w) / 2, y = safeTop + .16 * U, h = .42 * U;
    ctx.fill(rgba(15, 23, 42, .85)); ctx.fillRect(x, y, w, h); ctx.fill("#d97706"); ctx.fillRect(x, y, w, .008 * U);
    TXL = x; TXR = x + w - .03 * U;
    const std::string ln[4] = {"16 teams, two divisions of 8. A 20-game season: everyone in your division twice, 6 from the other.",
      "The top 4 in each division make the playoffs: single-game quarterfinal, semifinal and Cup Final.",
      "Every game pays coins like an EVEN match. Win the Cup and 3 STANDARD packs go to your INVENTORY.",
      "Your lineup LOCKS when the run starts and stays that way until it ends. Opponents are rated around your OVR (" + istr(utTeamOv(X)) + ")."};
    for (int i = 0; i < 4; i++) txWrap(ln[i], x + .035 * U, y + .07 * U + i * .085 * U, .024, w - .07 * U, hex("#cbd5e1"), AL_LEFT, 700, 2);
    TXL = 0; TXR = 1e4;
    double bw = .42 * U, by = y + h + .04 * U;
    ui("cup:new", W / 2 - bw - .015 * U, by, bw, .085 * U, "START A RUN", "#d97706", utFull(X), .036);
    ui("ut:hub", W / 2 + .015 * U, by, bw, .085 * U, "BACK", "#475569", true, .036);
    return;
  }
  Cup &C2 = *X.cup; const CupTeam &me = C2.T[0]; std::string rec = istr(me.w) + "-" + istr(me.l);
  utHead("ROAD TO THE CUP", C2.phase == "reg" ? "REGULAR SEASON   |   GAME " + istr(std::min(C2.g + 1, CUP_N)) + " / " + istr(CUP_N) + "   |   RECORD " + rec : C2.phase == "po" ? std::string("PLAYOFFS   |   ") + CUP_RN[std::min(C2.rd, 2)] + "   |   SEASON " + rec : "RUN OVER   |   SEASON " + rec);
  double lw = W * .62, top = safeTop + .12 * U, bot = H - .04 * U;
  if (C2.phase == "reg" || !C2.hasBr) drawCupTables(C2, m, top, lw, bot - top); else drawCupBracket(C2, m, top, lw, bot - top);
  // right panel: next game / result
  double rx = m + lw + .03 * U, rw = W - rx - m;
  ctx.fill(rgba(15, 23, 42, .88)); ctx.fillRect(rx, top, rw, bot - top);
  TXL = rx; TXR = rx + rw - .02 * U;
  UOpp op; bool hasOp = cupOppPick(X, op);
  if (C2.phase != "done" && hasOp) {
    const char *const *cl = UT_COLS[op.col % 12]; ctx.fill(cl[0]); ctx.fillRect(rx, top, rw, .16 * U); ctx.fill(cl[1]); ctx.fillRect(rx, top + .16 * U, rw, .006 * U);
    tx(C2.phase == "reg" ? "NEXT GAME" : CUP_RN[std::min(C2.rd, 2)], rx + .025 * U, top + .03 * U, .02, cl[1], AL_LEFT);
    tx(upper(firstWords(op.nm)), rx + .025 * U, top + .07 * U, .022, "#fff", AL_LEFT); tx(upper(nickOf(op.nm)), rx + .025 * U, top + .12 * U, .045, hex("#fff"), AL_LEFT, true);
    tx("OPPONENT OVR", rx + .025 * U, top + .21 * U, .02, "#94a3b8", AL_LEFT); tx(istr(op.tov), rx + rw - .03 * U, top + .21 * U, .04, hex("#fff"), AL_RIGHT, true);
    tx("YOUR TEAM OVR", rx + .025 * U, top + .27 * U, .02, "#94a3b8", AL_LEFT); tx(istr(cupLockOv(C2.lock)), rx + rw - .03 * U, top + .27 * U, .04, hex("#fff"), AL_RIGHT, true);
    ui("cup:play", rx + .02 * U, top + .33 * U, rw - .04 * U, .085 * U, "PLAY", "#d97706", true, .036);
    // the locked lineup
    tx("LINEUP LOCKED FOR THIS RUN", rx + .025 * U, top + .455 * U, .018, "#fbbf24", AL_LEFT);
    auto ln = [&](int i) { if (i >= (int)C2.lock.size() || !C2.lock[i].on || !UTM(C2.lock[i].p)) return std::string("-"); return upper(utLast(UTM(C2.lock[i].p)->nm)); };
    for (int l = 0; l < 3; l++) tx("L" + istr(l + 1) + "  " + ln(l * 3) + "  " + ln(l * 3 + 1) + "  " + ln(l * 3 + 2), rx + .025 * U, top + .495 * U + l * .035 * U, .017, "#cbd5e1", AL_LEFT);
    tx("G  " + ln(9) + "  /  " + ln(10), rx + .025 * U, top + .495 * U + 3 * .035 * U, .017, "#cbd5e1", AL_LEFT);
  } else {
    bool champ = C2.champ == 0;
    tx(champ ? "CUP CHAMPIONS!" : "RUN OVER", rx + rw / 2, top + .06 * U, .05, hex(champ ? "#fbbf24" : "#fff"), AL_CENTER, true);
    txWrap(champ ? "3 STANDARD packs are waiting in your INVENTORY." : C2.out + (C2.champ >= 0 ? ". The Cup went to the " + C2.T[C2.champ].nm + "." : ""), rx + rw / 2, top + .15 * U, .024, rw - .05 * U, hex("#cbd5e1"), AL_CENTER, 700, 3);
    ui("cup:new", rx + .02 * U, top + .27 * U, rw - .04 * U, .085 * U, "NEW RUN", "#d97706", utFull(X), .034);
    if (champ || !X.inv.empty()) ui("ut:inv", rx + .02 * U, top + .37 * U, rw - .04 * U, .07 * U, "INVENTORY (" + istr(X.inv.size()) + ")", "#16a34a", !X.inv.empty(), .028);
  }
  TXL = 0; TXR = 1e4;
  ui("ut:hub", rx + .02 * U, bot - .09 * U, rw - .04 * U, .07 * U, "BACK", "#475569", true, .028);
  if (C2.phase != "done") ui("cup:quit", rx + .02 * U, bot - .17 * U, rw - .04 * U, .065 * U, "ABANDON RUN", "#7f1d1d", true, .024);
}

// ---------------------------------------------------------------- the pack inventory (cup prizes and bought packs)
static void drawUTInv(UTX &X) {
  utHead("INVENTORY", "PACKS YOU OWN - OPEN THEM WHENEVER YOU LIKE");
  double m = .035 * U, top = safeTop + .14 * U, th = H - top - .18 * U;
  std::map<int, int> cnt; for (int t : X.inv) cnt[t]++; std::vector<int> ks; for (auto &e : cnt) ks.push_back(e.first);
  if (ks.empty()) tx("NO PACKS YET - BUY THEM IN THE SHOP OR WIN ROAD TO THE CUP", W / 2, H * .45, .024, "#94a3b8", AL_CENTER);
  int n = std::max(3, (int)ks.size()); double gap = .025 * U, tw = (W - 2 * m - gap * (n - 1)) / n, x00 = m + ((n - (int)ks.size()) * (tw + gap)) / 2;
  for (size_t i = 0; i < ks.size(); i++) { int t = ks[i]; const PackDef &pk = UT_PACKS[t]; double x0 = x00 + i * (tw + gap), pw = std::min(tw * .62, th * .55 / 1.45);
    ctx.fill(rgba(15, 23, 42, .85)); ctx.fillRect(x0, top, tw, th); ctx.fill(pk.col); ctx.fillRect(x0, top, tw, .008 * U);
    packAt(t, x0 + (tw - pw) / 2, top + .03 * U, pw);
    TXL = x0 + .01 * U; TXR = x0 + tw - .01 * U;
    tx(std::string(pk.n) + " PACK", x0 + tw / 2, top + .06 * U + pw * 1.45, .03, hex("#fff"), AL_CENTER, true);
    tx("x " + istr(cnt[t]), x0 + tw / 2, top + .11 * U + pw * 1.45, .04, hex("#fbbf24"), AL_CENTER, true);
    TXL = 0; TXR = 1e4;
    ui("inv:" + istr(t), x0 + tw * .08, top + th - .095 * U, tw * .84, .075 * U, "OPEN", pk.col, true, .032); }
  double bw = .4 * U;
  ui("ut:packs", W / 2 - bw - .015 * U, H - .12 * U, bw, .075 * U, "SHOP", "#334155", true, .032);
  ui("ut:hub", W / 2 + .015 * U, H - .12 * U, bw, .075 * U, "BACK", "#475569", true, .034);
}

// ---------------------------------------------------------------- opening a pack
static void drawUTOpen(UTX &X) {
  UOpen &O = utOpen; const PackDef &pk = UT_PACKS[O.t]; int n = (int)O.cards.size(); double t = (now() - O.t0) / 1000;
  const double RIP = .75, OUT = .45, FL = .5, flip0 = RIP + OUT;
  double cw = std::min(n == 1 ? .5 * U / 1.4 * 1.25 : (W - .1 * U) / n - .03 * U, (H - safeTop - .35 * U) / 1.4), gap = .03 * U, tot = n * cw + (n - 1) * gap, x0 = (W - tot) / 2, y0 = safeTop + .13 * U + (H - safeTop - .35 * U - cw * 1.4) / 2;
  double last = flip0 + n * FL;
  if (O.all && !O.done) { O.t0 = now() - (last + .05) * 1000; O.done = true; t = (now() - O.t0) / 1000; }
  utHead(std::string(pk.n) + " PACK", "");
  if (t < RIP) {   // the pack shakes, then tears open
    double pw = std::min(.32 * U, (H - safeTop - .3 * U) / 1.45), k = t / RIP, sh = std::sin(t * 60) * k * .012 * U;
    packAt(O.t, W / 2 - pw / 2 + sh, H / 2 - pw * 1.45 / 2 + .03 * U, pw);
    if (k > .6) { ctx.alpha((k - .6) / .4); ctx.fill("#fff"); ctx.fillRect(0, 0, W, H); ctx.alpha(1); }
    pushBtn("ut:reveal", 0, 0, W, H, "SKIP", true);
    return;
  }
  if (t < RIP + .25) { ctx.alpha(1 - (t - RIP) / .25); ctx.fill("#fff"); ctx.fillRect(0, 0, W, H); ctx.alpha(1); }
  for (int i = 0; i < n; i++) {
    UOpenCard &o = O.cards[i];
    double tx0 = x0 + i * (cw + gap), ft = t - flip0 - i * FL, out = clamp((t - RIP - i * .06) / OUT, 0, 1), e = 1 - std::pow(1 - out, 3);
    double cx = W / 2 - cw / 2 + (tx0 - (W / 2 - cw / 2)) * e, cy = y0 + (1 - e) * .08 * U;
    if (ft >= FL * .7) {   // revealed
      const RarDef &R = RAR[o.c.r];
      if (o.c.r >= 4) { double p = .5 + .5 * std::sin(now() / 260 + i); ctx.alpha(.22 + .18 * p); ctx.fill(R.c); ctx.rr(cx - cw * .07, cy - cw * .07, cw * 1.14, cw * 1.4 + cw * .14, cw * .1); ctx.fillPath(); ctx.alpha(1); }
      if (o.c.r == 6) { double a = now() / 1500; ctx.fill(rgba(255, 180, 230, .18)); double ccx = cx + cw / 2, ccy = cy + cw * .7, rr2 = cw * 1.2;
        for (int j = 0; j < 8; j++) { double a0 = a + j / 8.0 * PI * 2; ctx.beginPath(); ctx.moveTo(ccx, ccy); ctx.lineTo(ccx + std::cos(a0) * rr2, ccy + std::sin(a0) * rr2); ctx.lineTo(ccx + std::cos(a0 + .2) * rr2, ccy + std::sin(a0 + .2) * rr2); ctx.closePath(); ctx.fillPath(); } }
      utDrawCard(&o.c, cx, cy, cw);
      std::string tg = o.isNew ? "NEW" : "DUPLICATE"; ctx.font(fsz(.02) * U); double tw = ctx.measure(tg) + .025 * U;
      ctx.fill(o.isNew ? "#16a34a" : "#475569"); ctx.fillRect(cx + cw / 2 - tw / 2, cy + cw * 1.4 + .012 * U, tw, .035 * U); ctx.fill("#fff"); ctx.textMid(); ctx.fillText(tg, cx + cw / 2, cy + cw * 1.4 + .03 * U);
      if (ft < FL * .7 + .5 && o.c.r >= 4) { double k = (ft - FL * .7) / .5; ctx.alpha(1 - k); ctx.fill(R.c); ctx.font(.05 * U * (1 + k * .3)); ctx.textMid(); ctx.fillText(std::string(R.n) + "!", cx + cw / 2, cy - .03 * U - k * .03 * U); ctx.alpha(1); }
    } else if (ft > 0) { double k = ft / (FL * .7), sx = std::fabs(std::cos(k * PI)); utCardFlip(o.c, cx, cy, cw, sx, k < .5); }
    else if (out > 0) utDrawCard(nullptr, cx, cy, cw, true);
  }
  if (t < last) { pushBtn("ut:reveal", 0, 0, W, H, "SKIP", true); tx(IS_VITA ? "X: REVEAL ALL" : "TAP: REVEAL ALL", W / 2, H - .06 * U, .022, "#94a3b8", AL_CENTER); return; }
  O.done = true;
  int left = 0; for (int q : X.inv) if (q == O.t) left++;
  double bw = .47 * U, bh = .08 * U, by = H - bh - .035 * U; bool can = O.free ? left > 0 : X.coins >= pk.c;
  ui("ut:again", W / 2 - bw - .015 * U, by, bw, bh, O.free ? (can ? "OPEN NEXT (" + istr(left) + " LEFT)" : std::string("NO MORE PACKS")) : can ? "OPEN ANOTHER (" + istr(pk.c) + ")" : std::string("NOT ENOUGH COINS"), can ? hex(pk.col) : hex("#334155"), can, .032);
  ui("ut:done", W / 2 + .015 * U, by, bw, bh, "DONE", "#475569", true, .034);
  bool has = false; for (auto &b : btns) if (b.id == mFocus) has = true; if (mFocus.empty() || !has) mFocus = "ut:done";
}

// ---------------------------------------------------------------- the roster: the card menu and the examine view
static const double UT_EXT = .42;
void utExOpen(int u, double x, double y, double w) {
  UCard *c = utCard(u); if (!c) return;
  utEx = UEx(); utEx.c = *c; utEx.u = u; utEx.fx = x; utEx.fy = y; utEx.fw = w; utEx.t0 = now(); utEx.closing = false; utEx.focus = utMenuOnF ? "uc:" + istr(u) : mFocus;
  utExOnF = true; utMenuOnF = false;
}
void utExClose() { if (utExOnF && !utEx.closing) { utEx.closing = true; utEx.t0 = now(); } }
struct RectW { double x, y, w; };
static RectW utExRect() { double w = std::round(std::min(.62 * U, (H - .05 * U) / 1.4)); return {(W - w) / 2, (H - w * 1.4) / 2, w}; }
static const char *utValCol(int v) { return v >= 90 ? "#facc15" : v >= 80 ? "#4ade80" : v >= 70 ? "#93c5fd" : v >= 60 ? "#fdba74" : "#f87171"; }
// the back of a card: every rating, the same ones the career modes use
static void utExBack(const UCard &c, double w) {
  static UTPDef dflt; if (dflt.nm.empty()) { dflt.nm = "?"; dflt.pos = 'F'; dflt.t = -1; }
  const UTPDef *P = UTM(c.p); if (!P) P = &dflt; const RarDef &R = RAR[c.r]; const URat &Rt = utRat(c); double h = w * 1.4, b = w * .035, ix = b, iy = b, iw = w - 2 * b; auto cl = utColOf(P); bool g = P->pos == 'G';
  Grad gr = gLin(0, 0, 0, h); gr.add(0, hex(R.c)); gr.add(1, hex(R.d)); ctx.fill(gr); ctx.rr(0, 0, w, h, w * .06); ctx.fillPath();
  ctx.fill("#0b1220"); ctx.rr(ix, iy, iw, h - 2 * b, w * .045); ctx.fillPath();
  Grad hg = gLin(0, iy, 0, iy + h * .2); hg.add(0, shade(cl.first, .15)); hg.add(1, shade(cl.first, -.5)); ctx.fill(hg); ctx.fillRect(ix, iy + w * .03, iw, h * .19);
  ctx.fill(R.c); ctx.fillRect(ix, iy + w * .03 + h * .19, iw, std::max(2.0, h * .006));
  ctx.baseline(BL_MIDDLE); ctx.align(AL_LEFT);
  ctx.fill("#fff"); ctx.font(w * .17); ctx.fillText(istr(Rt.ovr), ix + w * .04, iy + h * .085);
  ctx.fill(R.c); ctx.font(w * .05); ctx.fillText(g ? "GOALIE" : "SKATER", ix + w * .05, iy + h * .165);
  double nx = ix + w * .3, nw = iw - w * .32;
  ctx.fill("#e2e8f0"); utFitTx(upper(P->nm.substr(0, P->nm.find(' '))), nx, iy + h * .055, w * .05, nw, AL_LEFT);
  ctx.fill("#fff"); utFitTx(upper(utLast(P->nm)), nx, iy + h * .1, w * .085, nw, AL_LEFT);
  ctx.fill(cl.second == hex("#ffffff") ? hex("#e2e8f0") : cl.second);
  utFitTx(P->leg ? "RETIRED LEGEND" : P->t >= 0 ? upper(TDP[P->t].city + " " + TDP[P->t].n) + (P->dr ? "  |  2026 DRAFT" : "") : "", nx, iy + h * .155, w * .045, nw, AL_LEFT);
  // rarity + style
  double sy = iy + h * .245; ctx.fill(c.r == 6 ? "#ff7ac8" : R.c); ctx.fillRect(ix + w * .04, sy - h * .022, iw * .46, h * .044);
  ctx.fill(c.r <= 1 ? "#1e293b" : "#0b1220"); utFitTx(c.r == 6 ? "SECRET  FULL ART" : R.n, ix + w * .04 + iw * .23, sy + 1, w * .045, iw * .42, AL_CENTER);
  ctx.fill("#cbd5e1"); utFitTx("STYLE: " + Rt.ar, ix + iw - w * .03, sy + 1, w * .045, iw * .46, AL_RIGHT);
  // ratings: two columns with bars
  auto pks = pkCard(c); std::vector<std::string> ks; if (g) for (auto k : UT_GK) ks.push_back(k); else { for (auto k : UT_SK) ks.push_back(k); for (auto k : BHKEYS) ks.push_back(k); }
  int rows = ((int)ks.size() + 1) / 2; double y0 = iy + h * .3, y1 = iy + h * (!pks.empty() ? .765 : .89), rh = (y1 - y0) / rows, cw = (iw - w * .1) / 2;
  for (size_t i = 0; i < ks.size(); i++) {
    int col = (int)i / rows, row = (int)i % rows; double x0 = ix + w * .04 + col * (cw + w * .03), yy = y0 + row * rh; int v = Rt.get(ks[i]);
    ctx.fill("#94a3b8"); utFitTx(g ? UT_GN(ks[i]) : FNICE(ks[i]), x0, yy + rh * .3, w * .042, cw * .74, AL_LEFT);
    ctx.fill(utValCol(v)); ctx.font(w * .065); ctx.align(AL_RIGHT); ctx.fillText(istr(v), x0 + cw, yy + rh * .32);
    ctx.fill("#1e293b"); ctx.fillRect(x0, yy + rh * .64, cw, std::max(3.0, rh * .14));
    ctx.fill(utValCol(v)); ctx.fillRect(x0, yy + rh * .64, std::max(2.0, cw * clamp((v - 40) / 59.0, 0, 1)), std::max(3.0, rh * .14));
  }
  // perks: name, colour tag and what it does
  for (size_t i = 0; i < pks.size(); i++) { const PerkDef &q = PERKS[pks[i].id]; int t = pks[i].t; double py = iy + h * (.778 + i * .064), ph = h * .056, px = ix + w * .04, pw = iw - w * .08; std::string tn = TIERN[t];
    ctx.fill(rgba(30, 41, 59, .95)); ctx.rr(px, py, pw, ph, ph * .2); ctx.fillPath(); ctx.fill(TIERC[t]); ctx.rr(px, py, std::max(3.0, w * .018), ph, ph * .1); ctx.fillPath();
    ctx.font(w * .032); double tw = ctx.measure(tn) + w * .03; ctx.fill(TIERC[t]); ctx.rr(px + pw - tw - w * .015, py + ph * .1, tw, ph * .42, ph * .12); ctx.fillPath();
    ctx.fill("#0b1220"); ctx.align(AL_CENTER); ctx.fillText(tn, px + pw - w * .015 - tw / 2, py + ph * .32);
    ctx.fill(q.col); utFitTx(q.n, px + w * .04, py + ph * .32, w * .04, pw - tw - w * .08, AL_LEFT);
    ctx.fill("#cbd5e1"); utFitTx(q.td[t - 1], px + w * .04, py + ph * .74, w * .028, pw - w * .06, AL_LEFT); }
  ctx.fill("#64748b"); utFitTx("QUICK SELL  " + istr(utVal(c)) + " COINS", w / 2, iy + h * .925, w * .04, iw * .9, AL_CENTER);
}
void drawUTEx() {
  if (!utExOnF || !UT) return; UTX &X = *UT; UEx &E = utEx;
  double k = clamp((now() - E.t0) / 1000 / UT_EXT, 0, 1); if (E.closing) k = 1 - k;
  if (E.closing && k <= 0) { mFocus = E.focus; utExOnF = false; return; }
  double e = k < .5 ? 2 * k * k : 1 - std::pow(-2 * k + 2, 2) / 2; RectW T = utExRect();
  btns.clear();
  ctx.fill(rgba(2, 6, 23, (float)(.82 * e))); ctx.fillRect(0, 0, W, H);
  double w = E.fw + (T.w - E.fw) * e, x = E.fx + (T.x - E.fx) * e, y = E.fy + (T.y - E.fy) * e;
  if (e >= 1) { ctx.save(); ctx.translate(T.x, std::round(T.y)); UCard cc = E.c; double tw = T.w; cached(Key("utx") << E.c.p << E.c.r << (int)T.w, [&] { utExBack(cc, tw); }); ctx.restore();
    int ri = -1; for (int i = 0; i < (int)X.ro.size(); i++) if (X.ro[i] == E.u) ri = i; int own = 0; for (auto &q : X.cards) if (q.p == E.c.p) own++;
    double hx = T.x + T.w + .03 * U; TXR = W - 6;
    tx(ri >= 0 ? "IN YOUR LINEUP: " + utSlotName(ri) : std::string("NOT IN YOUR LINEUP"), hx, H * .42, .022, ri >= 0 ? "#7CFC9A" : "#cbd5e1", AL_LEFT);
    tx("COPIES OWNED: " + istr(own), hx, H * .47, .022, "#cbd5e1", AL_LEFT);
    { const UBase &B = utBase(E.c.p); tx("SALARY: " + fmtM(utSal(E.c)), hx, H * .36, .022, "#86efac", AL_LEFT); if (!B.g) { Size Z = skSize(&B.q); tx(fmtHt(Z.ht) + "  " + istr(Z.wt) + " LBS", hx, H * .31, .022, "#cbd5e1", AL_LEFT); } }
    tx(IS_VITA ? "X / O: CLOSE" : "TAP: CLOSE", hx, H * .54, .02, "#64748b", AL_LEFT); TXR = 1e4;
    { auto it = X.cs.find(E.c.p); const UCStat *q = it == X.cs.end() ? nullptr : &it->second; bool g = UTM(E.c.p) && UTM(E.c.p)->pos == 'G'; double bw = std::min(W - hx - .03 * U, .62 * U), by = H * .6, bh = H * .3;
      ctx.fill(rgba(15, 23, 42, .92)); ctx.rr(hx, by, bw, bh, .015 * U); ctx.fillPath(); ctx.fill("#fbbf24"); ctx.rr(hx, by, bw, .006 * U, .003 * U); ctx.fillPath();
      TXR = hx + bw - .02 * U; tx("WITH YOUR TEAM", hx + .02 * U, by + .04 * U, .02, "#fbbf24", AL_LEFT);
      if (!q) tx("No games yet - his line starts the first time he dresses for you.", hx + .02 * U, by + bh * .5, .018, "#94a3b8", AL_LEFT);
      else { std::vector<std::pair<std::string, std::string>> cells;
        if (g) cells = {{"GP", istr(q->gp)}, {"W-L", istr(q->w) + "-" + istr(q->l)}, {"SV%", q->sa ? svp3(q->sv, q->sa) : "-"}, {"GAA", q->gp ? fixed((double)q->ga / q->gp, 2) : "-"}, {"SAVES", istr(q->sv)}, {"SO", istr(q->so)}};
        else cells = {{"GP", istr(q->gp)}, {"G", istr(q->g)}, {"A", istr(q->a)}, {"PTS", istr(q->g + q->a)}, {"+/-", (q->pm > 0 ? "+" : "") + istr(q->pm)}, {"P/GP", q->gp ? fixed((double)(q->g + q->a) / q->gp, 2) : "-"}};
        for (size_t i = 0; i < cells.size(); i++) { double cx = hx + .02 * U + (i % 3) * (bw - .04 * U) / 3, cy = by + bh * (i < 3 ? .42 : .78);
          tx(cells[i].second, cx, cy, .034, i == 4 && !g ? (q->pm > 0 ? "#4ade80" : q->pm < 0 ? "#f87171" : "#fff") : "#fff", AL_LEFT); tx(cells[i].first, cx, cy - .03 * U, .016, "#94a3b8", AL_LEFT); } }
      TXR = 1e4; }
  } else {
    // the flip: squeeze to the edge, swap sides, open back up, while growing toward the middle
    double sx = std::fabs(std::cos(e * PI));
    if (sx > .03) { ctx.save(); ctx.translate(x + w / 2, y);
      if (e < .5) { double k2 = w / E.fw; ctx.scale(sx * k2, k2); ctx.translate(-E.fw / 2, 0); utCardFace(E.c, std::round(E.fw)); }
      else { double k2 = w / T.w; ctx.scale(sx * k2, k2); ctx.translate(-T.w / 2, 0); utExBack(E.c, T.w); }
      ctx.restore(); }
  }
  pushBtn("ue:close", 0, 0, W, H, "BACK", true);
}
static void drawUTMenu(UTX &X) {
  if (!utMenuOnF) return; UMenu &M = utMenu; UCard *c = utCard(M.u); if (!c) { utMenuOnF = false; return; }
  btns.clear();
  ctx.fill(rgba(2, 6, 23, .6)); ctx.fillRect(0, 0, W, H);
  utDrawCard(c, M.x, M.y, M.w); ctx.stroke("#fbbf24"); ctx.lineWidth(3); ctx.rr(M.x - 3, M.y - 3, M.w + 6, M.w * 1.4 + 6, M.w * .09); ctx.strokePath();
  double pw = .44 * U, bh = .066 * U, gp = .009 * U, ph = bh * 5 + gp * 4 + .11 * U;
  double px = M.x + M.w + .02 * U; if (px + pw > W - 8) px = M.x - pw - .02 * U; double py = clamp(M.y + M.w * .7 - ph / 2, safeTop + 8, H - ph - 8);
  ctx.fill(rgba(15, 23, 42, .97)); ctx.fillRect(px, py, pw, ph); ctx.fill(RAR[c->r].c); ctx.fillRect(px, py, pw, .008 * U);
  TXL = px; TXR = px + pw - .02 * U;
  tx(upper(UTM(c->p) ? UTM(c->p)->nm : "?"), px + .02 * U, py + .04 * U, .026, hex("#fff"), AL_LEFT, true);
  { const UBase &B = utBase(c->p); std::string z; if (!B.g) { Size Z = skSize(&B.q); z = "   |   " + fmtHt(Z.ht) + "  " + istr(Z.wt) + " LBS"; }
    tx(std::string(RAR[c->r].n) + "   |   OVR " + istr(utOv(*c)) + "   |   " + utRat(*c).ar + z, px + .02 * U, py + .077 * U, .018, "#94a3b8", AL_LEFT); }
  TXL = 0; TXR = 1e4;
  int ri = -1; for (int i = 0; i < (int)X.ro.size(); i++) if (X.ro[i] == M.u) ri = i; bool here = ri == utSel; std::string sl = utSlotName(utSel); double by = py + .105 * U;
  if (M.slot) ui("um:swap", px + .02 * U, by, pw - .04 * U, bh, "SWAP PLAYER", "#16a34a", true, .024);
  else ui("um:add", px + .02 * U, by, pw - .04 * U, bh, here ? "ALREADY IN " + sl : ri >= 0 ? "SWAP INTO " + sl : "ADD TO LINEUP (" + sl + ")", "#16a34a", !here, .026);
  ui("um:ex", px + .02 * U, by + bh + gp, pw - .04 * U, bh, "EXAMINE", "#2563eb", true, .026);
  int nd = (int)utDupesOf(*c).size();
  ui("um:up", px + .02 * U, by + 2 * (bh + gp), pw - .04 * U, bh, c->r >= 6 ? std::string("MAX RARITY") : nd >= 3 ? std::string("UPGRADE TO ") + RAR[c->r + 1].n : "UPGRADE (" + istr(nd) + "/3 SPARES)", "#b45309", c->r < 6 && nd >= 3, .024);
  ui("um:sell", px + .02 * U, by + 3 * (bh + gp), pw - .04 * U, bh, "QUICK SELL  (" + istr(utVal(*c)) + ")", "#b91c1c", true, .024);
  ui("um:x", px + .02 * U, by + 4 * (bh + gp), pw - .04 * U, bh, "CANCEL", "#475569", true, .026);
  bool ok = false; for (auto &b : btns) if (b.id == mFocus && !b.dis) ok = true; if (!ok) mFocus = M.slot ? "um:swap" : here ? "um:ex" : "um:add";
}
static void drawUTRoster(UTX &X) {
  bool lockOn = X.cup && X.cup->phase != "done";
  utHead("MY ROSTER", lockOn ? "CUP RUN ACTIVE: THAT LINEUP IS LOCKED - CHANGES HERE ONLY AFFECT PLAY GAME" : std::string(utSell ? "SELL MODE: TAP A CARD TO QUICK SELL IT" : utSwap >= 0 ? "SWAP: PICK THE REPLACEMENT ON THE RIGHT" : "PICK A SLOT FOR ITS OPTIONS") + (IS_VITA ? "   |   L / R: PAGE   TRIANGLE: EXAMINE   SQUARE: SELL" : "   |   HOLD A CARD TO FLIP IT"));
  double m = .03 * U, top = safeTop + .12 * U, bot = H - .075 * U, lab = .03 * U, rowH = (bot - top) / 3, ch = rowH - lab - .012 * U, cw = ch / 1.4, cg = .012 * U;
  // left: three lines + the goalies
  for (int i = 0; i < 11; i++) {
    bool g = i >= 9; int col = g ? 3 : i % 3, row = g ? i - 9 : i / 3; double x0 = m + col * (cw + cg) + (g ? .02 * U : 0), y0 = top + row * rowH;
    if (col == 0 && !g) tx("L" + istr(row + 1) + " LW", x0, y0 + lab * .45, .017, ACC, AL_LEFT);
    else tx(g ? (i == 9 ? "G1" : "G2") : UT_POS[col], x0, y0 + lab * .45, .017, g ? "#93c5fd" : "#cbd5e1", AL_LEFT);
    double cy = y0 + lab; UCard *c = utCard(i < (int)X.ro.size() ? X.ro[i] : 0);
    if (c) { utDrawCard(c, x0, cy, cw); tx(fmtM(utSal(*c)), x0 + cw, y0 + lab * .45, .016, "#86efac", AL_RIGHT); }
    else { ctx.stroke(rgba(148, 163, 184, .5)); ctx.lineWidth(2); ctx.rr(x0 + 2, cy + 2, cw - 4, ch - 4, cw * .07); ctx.strokePath(); tx("EMPTY", x0 + cw / 2, cy + ch / 2, .02, "#64748b", AL_CENTER); }
    if (i == utSwap) { double p = .55 + .45 * std::sin(now() / 170); ctx.alpha(.25 * p); ctx.fill("#fbbf24"); ctx.rr(x0 - 4, cy - 4, cw + 8, ch + 8, cw * .09); ctx.fillPath(); ctx.alpha(1);
      ctx.stroke("#fbbf24"); ctx.lineWidth(4); ctx.rr(x0 - 4, cy - 4, cw + 8, ch + 8, cw * .09); ctx.strokePath();
      ctx.fill("#fbbf24"); ctx.fillRect(x0, cy + ch - .034 * U, cw, .034 * U); ctx.fill("#0f172a"); ctx.font(fsz(.017) * U); ctx.textMid(); ctx.fillText(c ? "REPLACING" : "FILLING", x0 + cw / 2, cy + ch - .017 * U); }
    else if (i == utSel) { ctx.stroke("#fbbf24"); ctx.lineWidth(3); ctx.rr(x0 - 3, cy - 3, cw + 6, ch + 6, cw * .09); ctx.strokePath(); }
    pushBtn("ur:" + istr(i), x0, cy, cw, ch, "SLOT");
  }
  { double x0 = m + 3 * (cw + cg) + .02 * U, y0 = top + 2 * rowH + lab; ctx.fill(rgba(15, 23, 42, .8)); ctx.fillRect(x0, y0, cw, ch);
    TXL = x0; TXR = x0 + cw; tx("TEAM", x0 + cw / 2, y0 + ch * .2, .02, "#94a3b8", AL_CENTER); tx("OVR", x0 + cw / 2, y0 + ch * .32, .02, "#94a3b8", AL_CENTER);
    tx(istr(utTeamOv(X)), x0 + cw / 2, y0 + ch * .5, .06, hex("#fff"), AL_CENTER, true);
    double pay = utPay(X), cap = utCapCheck(X); tx("PAYROLL", x0 + cw / 2, y0 + ch * .7, .016, "#94a3b8", AL_CENTER); tx(fmtM(pay) + " / " + fmtM(cap), x0 + cw / 2, y0 + ch * .8, .018, pay > cap + 1e-6 ? "#f87171" : "#7CFC9A", AL_CENTER);
    tx(istr(X.cards.size()) + " CARDS", x0 + cw / 2, y0 + ch * .9, .015, "#64748b", AL_CENTER); TXL = 0; TXR = 1e4; }
  // right: the cards that fit the slot
  double rx = m + 4 * (cw + cg) + .05 * U, rw = W - rx - m; auto L = utList(); const int cols = 4; double lcw = std::min((rw - (cols - 1) * .015 * U) / cols, (bot - top - .2 * U) / 2 / 1.4 - .02 * U), lch = lcw * 1.4; int per = cols * 2;
  int pages = std::max(1, (int)((L.size() + per - 1) / per)); utPage = std::min(utPage, pages - 1);
  std::string pos = utSel >= 9 ? (utSel == 9 ? "G1" : "G2") : "LINE " + istr(utSel / 3 + 1) + " " + UT_POS[utSel % 3];
  TXL = rx; TXR = rx + rw; tx(std::string(utSell ? "SELL FROM " : "CHOOSE FOR ") + pos + "   (" + istr(L.size()) + (utSel >= 9 ? " GOALIES)" : " SKATERS)"), rx, top + .012 * U, .022, "#fff", AL_LEFT); TXL = 0; TXR = 1e4;
  double ly0 = top + .04 * U, lg = (rw - cols * lcw) / (cols - 1);
  for (int k = 0; k < per && utPage * per + k < (int)L.size(); k++) {
    UCard *c = L[utPage * per + k]; double x0 = rx + (k % cols) * (lcw + lg), y0 = ly0 + (k / cols) * (lch + .04 * U); int ri = -1; for (int i = 0; i < (int)X.ro.size(); i++) if (X.ro[i] == c->u) ri = i;
    utDrawCard(c, x0, y0, lcw);
    auto tag = [&](const char *bg, const char *fg, const std::string &t) { ctx.fill(bg); ctx.fillRect(x0, y0 + lch + .004 * U, lcw, .028 * U); ctx.fill(fg); ctx.font(fsz(.017) * U); ctx.textMid(); ctx.fitPx(t, fsz(.017) * U, lcw - 4); ctx.fillText(t, x0 + lcw / 2, y0 + lch + .019 * U); };
    if (ri >= 0) tag(ri == utSel ? "#fbbf24" : "#2563eb", ri == utSel ? "#0f172a" : "#fff", "IN " + utSlotName(ri));
    else if (!utSell) tag("#14532d", "#bbf7d0", "SALARY " + fmtM(utSal(*c)));
    else tag("#b91c1c", "#fff", "SELL " + istr(utVal(*c)));
    pushBtn("uc:" + istr(c->u), x0, y0, lcw, lch, "CARD");
  }
  if (L.empty()) tx("NO CARDS FOR THIS SLOT YET", rx + rw / 2, ly0 + lch, .024, "#94a3b8", AL_CENTER);
  double py = ly0 + 2 * (lch + .04 * U) + .005 * U, pbw = .15 * U, pbh = .06 * U;
  ui("ut:prev", rx, py, pbw, pbh, "PREV", "#475569", utPage > 0, .026);
  tx("PAGE " + istr(utPage + 1) + " / " + istr(pages), rx + rw / 2, py + pbh / 2, .022, "#cbd5e1", AL_CENTER);
  ui("ut:next", rx + rw - pbw, py, pbw, pbh, "NEXT", "#475569", utPage < pages - 1, .026);
  double ay = py + pbh + .018 * U, abw = (rw - .03 * U) / 4, abh = std::min(.07 * U, bot + .06 * U - ay);
  ui("ut:auto", rx, ay, abw, abh, "AUTO BEST", "#16a34a", true, .024);
  ui("ut:sellm", rx + (abw + .01 * U), ay, abw, abh, utSell ? "SELL: ON" : "SELL: OFF", utSell ? "#dc2626" : "#334155", true, .024);
  ui("ut:dupes", rx + 2 * (abw + .01 * U), ay, abw, abh, "SELL DUPLICATES", "#b45309", true, .024);
  ui("ut:hub", rx + 3 * (abw + .01 * U), ay, abw, abh, utSwap >= 0 ? "CANCEL" : "BACK", "#475569", true, .024);
  if (utSwapFocus) { utSwapFocus = false; for (auto &b : btns) if (b.id.rfind("uc:", 0) == 0) { mFocus = b.id; break; } }
  drawUTMenu(X);
}

// ---------------------------------------------------------------- the screens
void drawUT() {
  UCR.clear();
  double m = .035 * U;
  if (screen == "utslots") {
    double w = std::min(W - 24.0, 1.7 * U), x = (W - w) / 2, y = safeTop + .02 * U, rh = .17 * U;
    tx("ULTIMATE FRANCHISE", W / 2, y + .05 * U, .075, hex("#fff"), AL_CENTER, true); tx("Choose a save file   (SQUARE: delete)", W / 2, y + .12 * U, .034, "#cbd5e1", AL_CENTER, 700);
    for (int i = 0; i < 3; i++) {
      double ry = y + .17 * U + i * (rh + .012 * U); UTX *d = utSlots[i].get();
      ctx.fill(rgba(15, 23, 42, .62)); ctx.fillRect(x, ry, w, rh);
      if (d) {
        ctx.fill(UT_COLS[d->col % 12][0]); ctx.fillRect(x, ry, .012 * U, rh);
        TXR = x + w - .27 * U;
        tx(d->nm, x + .035 * U, ry + rh * .28, .045, "#ffd54a", AL_LEFT);
        tx("TEAM OVR " + istr(utTeamOv(*d)) + "   |   " + istr(d->w) + "-" + istr(d->l), x + .035 * U, ry + rh * .56, .03, "#fff", AL_LEFT);
        tx(istr(d->cards.size()) + " CARDS   |   " + fmtN(d->coins) + " COINS   |   " + istr(d->packs) + " PACKS OPENED", x + .035 * U, ry + rh * .82, .023, "#94a3b8", AL_LEFT);
        TXR = 1e4;
        pushBtn("uslot:" + istr(i), x, ry, w - .25 * U, rh);
        ui("udel:" + istr(i), x + w - .24 * U, ry + rh * .3, .22 * U, rh * .4, "DELETE", "#475569", true, .026);
      } else { tx("FILE " + istr(i + 1) + " - NEW TEAM", W / 2, ry + rh / 2, .036, "#7aa7ff", AL_CENTER); pushBtn("uslot:" + istr(i), x, ry, w, rh); }
    }
    ui("ut:quit", (W - .5 * U) / 2, y + .17 * U + 3 * (rh + .012 * U) + .02 * U, .5 * U, .08 * U, "BACK", "#475569", true, .04);
    return;
  }
  if (!UT) { screen = "utslots"; return; } UTX &X = *UT;
  if (screen == "main") {
    bool land = W > H * 1.15; const char *const *cl = UT_COLS[X.col % 12];
    utHead(upper(X.nm), "ULTIMATE FRANCHISE   |   RECORD " + istr(X.w) + "-" + istr(X.l) + "   |   " + istr(X.cards.size()) + " CARDS");
    // menu, left
    double lx = m, lw = land ? W * .33 : W - 2 * m, ih = .075 * U, ly = safeTop + .17 * U; int ni = (int)X.inv.size();
    std::pair<std::string, std::string> it[6] = {{"ut:play", "PLAY GAME"}, {"ut:cup", "ROAD TO THE CUP"}, {"ut:roster", "MY ROSTER"}, {"ut:packs", "SHOP"}, {"ut:inv", "INVENTORY" + (ni ? " (" + istr(ni) + ")" : std::string())}, {"ut:quit", "MAIN MENU"}};
    for (int k = 0; k < 6; k++) { menuItem(it[k].first, it[k].second, lx, ly, lw, k == 0 ? ih * 1.05 : ih * .82, k == 0, false); ly += k == 0 ? ih * 1.15 : ih * .9; }
    // team OVR plate
    double py = ly + .03 * U; ctx.fill(rgba(15, 23, 42, .8)); ctx.fillRect(lx, py, lw, .12 * U); ctx.fill(cl[0]); ctx.fillRect(lx, py, .012 * U, .12 * U);
    tx("TEAM OVR", lx + .03 * U, py + .035 * U, .022, "#94a3b8", AL_LEFT); tx(istr(utTeamOv(X)), lx + .03 * U, py + .083 * U, .055, hex("#fff"), AL_LEFT, true);
    TXR = lx + lw - .01 * U; tx(utFull(X) ? "LINEUP READY" : "LINEUP INCOMPLETE", lx + lw * .42, py + .06 * U, .024, utFull(X) ? "#7CFC9A" : "#ff9a7a", AL_LEFT); TXR = 1e4;
    // showcase: your three best cards
    std::vector<UCard *> rc; for (int u : X.ro) { UCard *c = utCard(u); if (c) rc.push_back(c); }
    std::stable_sort(rc.begin(), rc.end(), [](UCard *a, UCard *b) { return utOv(*b) < utOv(*a); }); if (rc.size() > 3) rc.resize(3);
    double sx0 = land ? W * .4 : m, sw = W - sx0 - m, chh = std::min(H - safeTop - .3 * U, .62 * U), cw = std::min(chh / 1.4, sw / 3.4), top = safeTop + .16 * U;
    ctx.fill(rgba(15, 23, 42, .45)); ctx.fillRect(sx0, top - .01 * U, sw, cw * 1.4 * 1.08 + .09 * U);
    tx("TOP OF THE LINEUP", sx0 + .02 * U, top + .02 * U, .022, ACC, AL_LEFT);
    const int order[3] = {1, 0, 2};
    for (size_t i = 0; i < rc.size(); i++) { int k = order[i]; double w2 = i == 0 ? cw * 1.08 : cw * .92, cx = sx0 + sw / 2 + (k - 1) * cw * 1.12 - w2 / 2, cy = top + .05 * U + (i == 0 ? 0 : cw * .12); utDrawCard(rc[i], cx, cy, w2); }
    double ny = top + .05 * U + cw * 1.4 * 1.08 + .035 * U;
    if (X.opp.size() > 1) { const UOpp &nx = X.opp[1]; TXR = sx0 + sw; tx("NEXT EVEN MATCH:  " + upper(nx.nm) + "  (OVR " + istr(nx.tov ? nx.tov : nx.ov) + ")", sx0 + .02 * U, ny, .022, "#cbd5e1", AL_LEFT); TXR = 1e4; }
    footHints({{"D-PAD", "MOVE"}, {"X", "SELECT"}, {"O", "MAIN MENU"}});
  } else if (screen == "utopp") {
    utHead("PICK AN OPPONENT", "YOUR TEAM OVR " + istr(utTeamOv(X)) + "   |   WIN THE REWARD, A QUARTER OF IT FOR A LOSS, +10 A GOAL");
    int n = 3; double gap = .03 * U, cw = (W - 2 * m - gap * (n - 1)) / n, chh = std::min(H - safeTop - .36 * U, .62 * U), cy = safeTop + .15 * U;
    for (int i = 0; i < (int)X.opp.size() && i < 3; i++) {
      const UOpp &o = X.opp[i]; const OppDef &D = UT_OPP[o.k]; const char *const *cl = UT_COLS[o.col % 12]; double x0 = m + i * (cw + gap);
      ctx.fill(rgba(15, 23, 42, .88)); ctx.fillRect(x0, cy, cw, chh);
      ctx.fill(cl[0]); ctx.fillRect(x0, cy, cw, chh * .36); ctx.fill(cl[1]); ctx.fillRect(x0, cy + chh * .36, cw, chh * .018);
      ctx.fill(rgba(255, 255, 255, .1)); ctx.quad(x0 + cw * .6, cy, x0 + cw, cy, x0 + cw, cy + chh * .36, x0 + cw * .35, cy + chh * .36);
      ctx.fill(D.col); ctx.fillRect(x0 + cw * .06, cy + chh * .06, cw * .36, chh * .09);
      TXL = x0; TXR = x0 + cw - .02 * U;
      tx(D.n, x0 + cw * .24, cy + chh * .105, .028, hex("#fff"), AL_CENTER, true);
      tx(upper(firstWords(o.nm)), x0 + cw * .07, cy + chh * .22, .026, cl[1], AL_LEFT);
      tx(upper(nickOf(o.nm)), x0 + cw * .07, cy + chh * .3, .05, hex("#fff"), AL_LEFT, true);
      tx("OVR", x0 + cw / 2, cy + chh * .46, .024, "#94a3b8", AL_CENTER);
      tx(istr(o.tov ? o.tov : o.ov), x0 + cw / 2, cy + chh * .57, .085, hex("#fff"), AL_CENTER, true);
      tx("WIN  +" + istr(D.c) + " COINS", x0 + cw / 2, cy + chh * .72, .03, "#fde68a", AL_CENTER);
      tx("LOSS  +" + istr((int)jround(D.c * .25)) + "   (+10 A GOAL)", x0 + cw / 2, cy + chh * .8, .024, "#94a3b8", AL_CENTER);
      TXL = 0; TXR = 1e4;
      ui("uo:" + istr(i), x0 + cw * .08, cy + chh * .86, cw * .84, chh * .11, "PLAY", D.col, true, .034);
    }
    ui("ut:hub", (W - .5 * U) / 2, cy + chh + .03 * U, .5 * U, .075 * U, "BACK", "#475569", true, .036);
  } else if (screen == "utpacks") {
    utHead("SHOP", "PACKS GO TO YOUR INVENTORY   |   SALARY CAP " + fmtM(utCapCheck(X)) + " (PAYROLL " + fmtM(utPay(X)) + ")   |   MORE CAP SPACE BELOW");
    int n = 5; double gap = .025 * U, tw = (W - 2 * m - gap * (n - 1)) / n, ty = safeTop + .14 * U, th = H - ty - .18 * U;
    for (int i = 0; i < n; i++) {
      const PackDef &pk = UT_PACKS[i]; double x0 = m + i * (tw + gap), pw = std::min(tw * .62, th * .5 / 1.45);
      ctx.fill(rgba(15, 23, 42, .8)); ctx.fillRect(x0, ty, tw, th); ctx.fill(pk.col); ctx.fillRect(x0, ty, tw, .008 * U);
      packAt(i, x0 + (tw - pw) / 2, ty + .025 * U, pw);
      double by = ty + .025 * U + pw * 1.45 + .035 * U; TXL = x0 + .01 * U; TXR = x0 + tw - .01 * U;
      tx(std::string(pk.n) + " PACK", x0 + tw / 2, by, .032, hex("#fff"), AL_CENTER, true);
      auto od = utOddsTxt(pk); tx(od.first, x0 + tw / 2, by + .042 * U, .019, "#cbd5e1", AL_CENTER); tx(od.second, x0 + tw / 2, by + .074 * U, .019, "#94a3b8", AL_CENTER);
      TXL = 0; TXR = 1e4;
      bool can = X.coins >= pk.c; double bh = .075 * U; int own = 0; for (int q : X.inv) if (q == i) own++;
      if (own) { TXL = x0; TXR = x0 + tw; tx("IN INVENTORY: " + istr(own), x0 + tw / 2, ty + th - bh - .05 * U, .019, "#fbbf24", AL_CENTER); TXL = 0; TXR = 1e4; }
      ui("ubuy:" + istr(i), x0 + tw * .08, ty + th - bh - .02 * U, tw * .84, bh, "BUY  " + fmtN(pk.c), can ? hex(pk.col) : hex("#334155"), can, .03);
    }
    int ni = (int)X.inv.size(); double bw2 = .3 * U; int cc = utCapCost(X); utCapCheck(X);
    ui("ut:inv", W / 2 - bw2 * 1.5 - .03 * U, ty + th + .025 * U, bw2, .075 * U, "INVENTORY" + (ni ? " (" + istr(ni) + ")" : std::string()), "#16a34a", true, .03);
    ui("ut:cap", W / 2 - bw2 / 2, ty + th + .025 * U, bw2, .075 * U, "CAP +" + fmtM(UT_CAPSTEP) + "  " + fmtN(cc), X.coins >= cc ? "#0e7490" : "#334155", true, .026);
    ui("ut:hub", W / 2 + bw2 / 2 + .03 * U, ty + th + .025 * U, bw2, .075 * U, "BACK", "#475569", true, .032);
  } else if (screen == "utopen" && utOpenOn) drawUTOpen(X);
  else if (screen == "utcup") drawUTCup(X);
  else if (screen == "utinv") drawUTInv(X);
  else if (screen == "utroster") drawUTRoster(X);
  else screen = "main";
  utToast();
}

// ---------------------------------------------------------------- touch: hold a card to flip it
static struct { bool on = false; int id = 0; float x = 0, y = 0; double t0 = 0; UCR_ r{}; bool done = false; } utLP;
bool utLPDown(float x, float y, int id) {
  if (mode != "ut" || !UT || utExOnF || modal.on || trActive()) return false;
  const UCR_ *hit = nullptr; for (int i = (int)UCR.size() - 1; i >= 0; i--) { const UCR_ &r = UCR[i]; if (x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) { hit = &r; break; } }
  if (!hit || !utCard(hit->u)) return false;
  utLP.on = true; utLP.id = id; utLP.x = x; utLP.y = y; utLP.t0 = now(); utLP.r = *hit; utLP.done = false; return true;
}
void utLPCheck() { if (!utLP.on || utLP.done) return; if (now() - utLP.t0 >= 450) { utLP.done = true; utMenuOnF = false; utExOpen(utLP.r.u, utLP.r.x, utLP.r.y, utLP.r.w); } }
// let go before it flips: it was a tap
bool utLPUp(int id, float x, float y, bool) {
  if (!utLP.on || utLP.id != id) return false; utLP.on = false;
  if (!utLP.done && hyp(x - utLP.x, y - utLP.y) < .05 * U) { mPadUsed = false; for (auto &b : btns) if (utLP.x >= b.x && utLP.x <= b.x + b.w && utLP.y >= b.y && utLP.y <= b.y + b.h) { if (!b.dis) { std::string bid = b.id; uiTap(bid); } break; } }
  return true;
}
// L / R page the card list, SQUARE sells (or deletes a save), TRIANGLE examines
void utShoulder(int d) { if (!utMenuOnF && !utExOnF) utPage = std::max(0, utPage + d); }
void utPadSquare(const std::string &id) {
  if (screen == "utslots") { if (id.rfind("uslot:", 0) == 0) utAskDel(atoi(id.c_str() + 6)); else if (id.rfind("udel:", 0) == 0) utAskDel(atoi(id.c_str() + 5)); }
  else if (screen == "utroster" && !utMenuOnF && !utExOnF && id.rfind("uc:", 0) == 0) utSellOne(atoi(id.c_str() + 3));
}
void utPadTriangle(const Btn &b) {
  if (screen != "utroster" || utMenuOnF || utExOnF || !UT) return;
  int u = 0; if (b.id.rfind("uc:", 0) == 0) u = atoi(b.id.c_str() + 3); else if (b.id.rfind("ur:", 0) == 0) { int i = atoi(b.id.c_str() + 3); if (i >= 0 && i < (int)UT->ro.size()) u = UT->ro[i]; }
  if (u) utExOpen(u, b.x, b.y, b.w);
}

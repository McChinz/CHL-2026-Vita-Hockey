// CHL 2026 native - forward engine internals shared by sk_core.cpp and sk_play.cpp
#pragma once
#include "game.h"

struct SkD { double sp, gk, acc, ai, poke, hit, uacc, carry, thru, thruS, blk, gap; };
const SkD &SKD();
struct Wall { double x, y, nx, ny; };
extern double skHint;


Skater *skMk(int team, Role role, Src *src, bool user);
void skRefSnap();
void skPreviewStart();
void skIntroTick(double dt);
void skIntroBegin();
bool skWantPull(int ti);
void skCheckPull(int ti);
bool skBoards0(double &x, double &y, double &vx, double &vy, double r, double bounce, bool isPuck);
bool skBoardsP(Skater *o, double r, double b);
bool skBoardsPuck(double r, double bounce);
bool skNetBox(double &x, double &y, double &vx, double &vy, double r, double bounce, bool isPuck);
double skTilt(int t);
double skMaxSpd(const Skater *p);
bool skShort(int t);
bool onIce(const Skater *p);
bool onTeam(int ti, const Skater *p);
int alIndex(const std::vector<Skater *> &AL, const Skater *p);
void skRelease(Skater *p);
void skTagIcing(Skater *p);
void skShoot(Skater *p, double dx, double dy, double charge, ShotKind kind, double h, bool kindGiven = true);
void skAutoShot(Skater *p, ShotKind kind, double charge);
bool skLaneBlocked(const Skater *p, const Skater *to);
void skPass(Skater *p, Skater *to, double pw = 0, bool sau = false);
bool skSpin(Skater *p);
double skDekeSide(const Skater *p, double mx, double my);
bool skDeke(Skater *p, double s);
void skDekeUpdate(Skater *p, double dt);
bool skPoke(Skater *p, Skater *c, double base);
double skStam(Skater *p, bool want, bool moving, double dt);
std::string skShotName(const Puck &P);
bool skBlock(Skater *p);
bool skStartCheck(Skater *p, double dx, double dy, double pw = 1);
double skLaneOpen(double ax, double ay, double bx, double by, int team, const Skater *skip = nullptr);
double skShotQ(int team, double x, double y);
void skAIShot(Skater *p, ShotKind kind);
Skater *skBestPassTarget(Skater *p, double dirx, double diry);
void skShake(double a);
Wall skWall(double x, double y);
void skGlassHit(double x, double y, double a);
void skSpray(Skater *p, double v);
void skSprayUpd(double dt);
void skHit(Skater *a, Skater *b);
void skPenalty(Skater *p, const char *kind);
void skBoxOut(Team &T, int ti, Skater *p);
void skBoxTick(double dt);
void skRefUpdate(double dt);
void skPkFire(Skater *p, int id, int t = 0);
double fqSl(const Src *q);
double fqWr(const Src *q);
int pkTg(const Goalie *g, int id);
int pkCanG(const Goalie *g, int id);
void pkSpendG(Goalie *g, int id);
int skDefJobPub(Skater *p, Team &T, Skater *car, double ownX);
// sk_play.cpp
struct Want { double vx = 0, vy = 0; bool glide = false; };
Input skInput();
Want skUserControl(Skater *p, Input &I, double dt);
Want skAI(Skater *p, double dt);
void skGoalie(Goalie &g, double dt);
bool skGoalieSave(Goalie &g);
// the goalie's body as physics (sk_draw3d.cpp: the same pose the 3D view draws). Returns the part the puck touches or -1
enum { GT_PAD, GT_LEG, GT_BODY, GT_HEAD, GT_ARM, GT_GLOVE, GT_BLOCKER, GT_STICK };
int skGoalieTouch(Goalie &g, double x, double y, double zp, double r, double *nrm, double *aux);
constexpr double PUCK_R = .26;   // the puck's radius (an NHL puck is small: 3 inches across)
void skHoldUpdate(double dt);
void skTouchFrame();
Skater *skMateFor(int btn);
void skCallsUpdate(double dt);
bool skTouchOn(int side, double &sx, double &sy, double &cx, double &cy);
void skPuckJolt(double sp, double k);
void skGoalieReact(Goalie &g, double px, double py, double pvx, double pvy, double h);
void skGoalieAnimStart(Goalie &g, Pose pose, double side, double hold = -1);
Pose poseOf(const char *s);

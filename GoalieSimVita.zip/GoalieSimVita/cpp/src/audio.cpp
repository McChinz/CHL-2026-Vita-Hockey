// CHL 2026 native - sound synthesis and mixing (moved here from the JS build's main.c, unchanged recipes)
#include "audio.h"
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <atomic>

#define SR 22050
#define PI2 6.28318530718f
#define AU_VOICES 24

namespace {
struct Bq { float b0, b1, b2, a1, a2, x1, x2, y1, y2; };
unsigned g_rs = 1;
void rng_seed(unsigned s) { g_rs = s ? s : 1; }
float rnd1() { g_rs = g_rs * 1664525u + 1013904223u; return (float)(g_rs >> 8) / 16777216.f * 2.f - 1.f; }
void bq_set(Bq *f, int type, float fr, float Q) {   // type 0 bp, 1 lp, 2 hp
  if (fr > SR * 0.45f) fr = SR * 0.45f;
  float w = PI2 * fr / SR, cs = cosf(w), sn = sinf(w), a = sn / (2 * Q), b0, b1, b2;
  if (type == 0) { b0 = a; b1 = 0; b2 = -a; } else if (type == 1) { b0 = (1 - cs) / 2; b1 = 1 - cs; b2 = b0; } else { b0 = (1 + cs) / 2; b1 = -(1 + cs); b2 = b0; }
  float a0 = 1 + a;
  f->b0 = b0 / a0; f->b1 = b1 / a0; f->b2 = b2 / a0; f->a1 = -2 * cs / a0; f->a2 = (1 - a) / a0;
}
void bq_init(Bq *f, int type, float fr, float Q) { memset(f, 0, sizeof(*f)); bq_set(f, type, fr, Q); }
inline float bq(Bq *f, float x) { float y = f->b0 * x + f->b1 * f->x1 + f->b2 * f->x2 - f->a1 * f->y1 - f->a2 * f->y2; f->x2 = f->x1; f->x1 = x; f->y2 = f->y1; f->y1 = y; return y; }

int16_t *g_snd[S_COUNT];
int g_snd_len[S_COUNT];
std::atomic<bool> g_ready{false};

void syn_store(int id, float *a, int n, float pk) {
  float m = 0; for (int i = 0; i < n; i++) { float v = fabsf(a[i]); if (v > m) m = v; }
  float k = m > 0 ? pk * 32767.f / m : 0;
  int16_t *d = (int16_t *)malloc((size_t)n * 2);
  if (d) { for (int i = 0; i < n; i++) d[i] = (int16_t)(a[i] * k); g_snd_len[id] = n; g_snd[id] = d; }
  free(a);
}
float *syn_buf(float dur, int *n) { *n = (int)(dur * SR); return (float *)calloc((size_t)*n + 1, sizeof(float)); }
struct HitP { unsigned seed; int t1; float f1, q1, d1, g1, f2, q2, d2, g2, th0, th1, thd, td, tg; };
float *syn_hit(float dur, const HitP *o, int *n) {
  float *a = syn_buf(dur, n); if (!a) return nullptr;
  Bq f1, f2; bq_init(&f1, o->t1, o->f1, o->q1 > 0 ? o->q1 : 0.7f); bq_init(&f2, 0, o->f2, o->q2 > 0 ? o->q2 : 2.f);
  rng_seed(o->seed); float ph = 0;
  for (int i = 0; i < *n; i++) { float t = (float)i / SR, x = rnd1(); ph += (o->th0 + o->th1 * expf(-t / o->thd)) / SR;
    a[i] = bq(&f1, x) * expf(-t / o->d1) * o->g1 + bq(&f2, x) * expf(-t / o->d2) * o->g2 + sinf(PI2 * ph) * expf(-t / o->td) * o->tg; }
  return a;
}
typedef float (*EnvFn)(float t);
float env_grunt(float t) { return t < .015f ? t / .015f : t < .06f ? 1.f : expf(-(t - .06f) / .075f); }
float env_boo(float t) { return t < .35f ? t / .35f : t < 2.1f ? 1.f : fmaxf(0.f, 1.f - (t - 2.1f) / .75f); }
void syn_voice(float *a, int alen, int off, float dur, float f0a, float f0b, const float *F, float amp, unsigned seed, EnvFn env, float vib) {
  int n = (int)(dur * SR); Bq fs[3], br; const float Q[3] = {5, 8, 10};
  for (int k = 0; k < 3; k++) bq_init(&fs[k], 0, F[k], Q[k]);
  bq_init(&br, 0, 1500, 1); rng_seed(seed); float ph = 0;
  for (int i = 0; i < n && off + i < alen; i++) { float t = (float)i / SR, k = t / dur, f0 = (f0a + (f0b - f0a) * k) * (1 + vib * sinf(t * PI2 * 5.3f + seed));
    ph += f0 / SR; ph -= floorf(ph);
    float g = 1 - 2 * ph, src = g * fabsf(g) + rnd1() * .12f, e = env(t);
    a[off + i] += (bq(&fs[0], src) + bq(&fs[1], src) * .6f + bq(&fs[2], src) * .3f + bq(&br, rnd1()) * .12f) * e * amp; }
}

struct Voice { const int16_t *d; int len; double pos, step; float vol; int loop; std::atomic<int> on; unsigned age; std::atomic<unsigned> gen; };
Voice g_vo[AU_VOICES];
unsigned g_age = 0;
}  // namespace

void au_synth_all() {
  int n; float *a; Bq b, h, f;
  { HitP o = {3, 2, 2200, .7f, .011f, 1.1f, 3200, 3, .02f, .8f, 65, 120, .03f, .075f, .75f}; a = syn_hit(.32f, &o, &n); if (a) syn_store(S_SLAP, a, n, .92f); }
  { HitP o = {5, 2, 2600, .7f, .007f, .7f, 2300, 2.2f, .016f, .9f, 80, 90, .025f, .05f, .45f}; a = syn_hit(.24f, &o, &n); if (a) syn_store(S_WRIST, a, n, .92f); }
  { HitP o = {9, 0, 1100, 4, .013f, 1, 1500, 3, .01f, .3f, 520, 0, 1, .03f, .5f}; a = syn_hit(.16f, &o, &n); if (a) syn_store(S_PASS, a, n, .92f); }
  { HitP o = {11, 1, 450, .7f, .045f, 1.4f, 900, 1.5f, .03f, .4f, 110, 40, .04f, .06f, .6f}; a = syn_hit(.22f, &o, &n); if (a) syn_store(S_SAVE, a, n, .92f); }
  if ((a = syn_buf(.2f, &n))) { rng_seed(21); bq_init(&h, 2, 2500, .7f); bq_init(&b, 0, 5200, .8f);
    for (int i = 0; i < n; i++) { float t = (float)i / SR, e = t < .03f ? t / .03f : expf(-(t - .03f) / .065f); a[i] = bq(&b, bq(&h, rnd1())) * e * (.7f + .3f * rnd1()); }
    syn_store(S_SKATE, a, n, .9f); }
  if ((a = syn_buf(.56f, &n))) { rng_seed(23); bq_init(&h, 2, 1800, .7f); bq_init(&b, 0, 6000, .9f);
    for (int i = 0; i < n; i++) { float t = (float)i / SR; if (i % 32 == 0) bq_set(&b, 0, 6000 - 3500 * fminf(1.f, t / .45f), .9f);
      float e = t < .02f ? t / .02f : t < .22f ? 1.f : expf(-(t - .22f) / .11f); a[i] = bq(&b, bq(&h, rnd1())) * e * (.55f + .45f * fabsf(rnd1())); }
    syn_store(S_STOP, a, n, .9f); }
  { const float P[3][5] = {{150, 108, 640, 1190, 2390}, {128, 95, 450, 850, 2400}, {176, 128, 760, 1300, 2550}};
    for (int v = 0; v < 3; v++) if ((a = syn_buf(.32f, &n))) { syn_voice(a, n, 0, .3f, P[v][0], P[v][1], &P[v][2], 1, 32 + v, env_grunt, .01f); syn_store(S_GRUNT1 + v, a, n, .9f); } }
  { HitP o = {13, 1, 260, .7f, .055f, 1.6f, 380, 3, .12f, .7f, 52, 30, .05f, .11f, .9f}; a = syn_hit(.38f, &o, &n);
    if (a) { rng_seed(17); bq_init(&f, 0, 1800, 6); for (int i = 0; i < n; i++) a[i] += bq(&f, rnd1()) * expf(-((float)i / SR) / .09f) * .25f; syn_store(S_HIT, a, n, .92f); } }
  if ((a = syn_buf(1.05f, &n))) { const float P[6][3] = {{1050, 1, .55f}, {1053, .5f, .5f}, {2380, .7f, .4f}, {3610, .5f, .28f}, {5170, .35f, .18f}, {6890, .2f, .12f}};
    rng_seed(41); bq_init(&h, 2, 3000, .7f);
    for (int i = 0; i < n; i++) { float t = (float)i / SR, v = bq(&h, rnd1()) * expf(-t / .004f) * .7f; for (int k = 0; k < 6; k++) v += sinf(PI2 * P[k][0] * t) * P[k][1] * expf(-t / P[k][2]); a[i] = v; }
    syn_store(S_POST, a, n, .9f); }
  { int L = 4 * SR, X = SR / 2; float *w = (float *)calloc((size_t)(L + X), sizeof(float));
    if (w) { Bq B[3]; const float Bf[3][3] = {{350, .8f, 1}, {700, 1, .8f}, {1400, 1.2f, .4f}}; float bv[3] = {0, 0, 0};
      for (int k = 0; k < 3; k++) bq_init(&B[k], 0, Bf[k][0], Bf[k][1]);
      rng_seed(51);
      for (int i = 0; i < L + X; i++) { float v = 0; for (int k = 0; k < 3; k++) { bv[k] += (rnd1() * .9f - bv[k]) * .0006f; float m = .62f + .38f * fmaxf(-1.f, fminf(1.f, bv[k] * 3)); v += bq(&B[k], rnd1()) * Bf[k][2] * m; } w[i] = v; }
      float *o = (float *)malloc((size_t)L * sizeof(float));
      if (o) { for (int i = 0; i < L; i++) o[i] = i < X ? w[i] * ((float)i / X) + w[L + i] * (1 - (float)i / X) : w[i]; syn_store(S_AMB, o, L, .5f); }
      free(w); } }
  if ((a = syn_buf(3.6f, &n))) { Bq B[3], cl; const float Bf[3][3] = {{700, 1, 1}, {1150, 1.5f, .8f}, {2600, 2, .35f}};
    for (int k = 0; k < 3; k++) bq_init(&B[k], 0, Bf[k][0], Bf[k][1]);
    bq_init(&cl, 2, 1200, .7f); rng_seed(61);
    for (int i = 0; i < n; i++) { float t = (float)i / SR, u = t / .25f, e = t < .25f ? u * u * (3 - 2 * u) : t < 2.2f ? 1.f : fmaxf(0.f, 1 - (t - 2.2f) / 1.4f), v = 0;
      for (int k = 0; k < 3; k++) v += bq(&B[k], rnd1()) * Bf[k][2];
      a[i] = v * e * (.85f + .15f * sinf(t * PI2 * 7.3f)); }
    for (int k = 0; k < 140; k++) { float t0 = .25f + fabsf(rnd1()) * 2.6f, g = .25f + .25f * fabsf(rnd1()); int o = (int)(t0 * SR);
      for (int j = 0; j < 180 && o + j < n; j++) a[o + j] += bq(&cl, rnd1()) * expf(-j / 40.f) * g; }
    for (int k = 0; k < 5; k++) { float t0 = .3f + fabsf(rnd1()) * 1.4f, f0 = 1000 + fabsf(rnd1()) * 300, ph = 0; int o = (int)(t0 * SR), m = (int)(.55f * SR);
      for (int j = 0; j < m && o + j < n; j++) { float u = (float)j / m, fr = f0 * (1 + .45f * sinf(3.14159265f * u)) * (1 + .01f * sinf((float)j / SR * PI2 * 6)); ph += fr / SR; a[o + j] += sinf(PI2 * ph) * sinf(3.14159265f * u) * .08f; } }
    syn_store(S_CHEER, a, n, .92f); }
  if ((a = syn_buf(3.f, &n))) { rng_seed(71);
    for (int k = 0; k < 7; k++) { float f0 = 95 + fabsf(rnd1()) * 95; int off = (int)(fabsf(rnd1()) * .12f * SR); float F[3] = {300 + fabsf(rnd1()) * 40, 820, 2300};
      unsigned keep = g_rs; syn_voice(a, n, off, 2.85f, f0, f0 * .94f, F, .5f, 80 + k, env_boo, .02f); g_rs = keep; }
    bq_init(&f, 0, 420, 1);
    for (int i = 0; i < n; i++) a[i] += bq(&f, rnd1()) * .15f * env_boo((float)i / SR);
    syn_store(S_BOO, a, n, .9f); }
  g_ready = true;
}
bool au_ready() { return g_ready; }

int au_play(int id, float vol, float rate, bool loop) {
  if (!g_ready || id < 0 || id >= S_COUNT || !g_snd[id]) return -1;
  int pick = -1; unsigned oldest = 0xffffffffu;
  for (int v = 0; v < AU_VOICES; v++) if (!g_vo[v].on) { pick = v; break; }
  if (pick < 0) for (int v = 0; v < AU_VOICES; v++) if (!g_vo[v].loop && g_vo[v].age < oldest) { oldest = g_vo[v].age; pick = v; }   // steal the oldest one-shot
  if (pick < 0) return -1;
  Voice &o = g_vo[pick];
  o.on = 0; o.gen++;
  o.d = g_snd[id]; o.len = g_snd_len[id]; o.pos = 0;
  o.step = (rate > 0.05f ? rate : 0.05f) * 22050.0;   // divided by the output rate in au_mix
  o.vol = vol; o.loop = loop; o.age = ++g_age;
  o.gen++;
  o.on = 1;
  return pick;
}
void au_set(int v, float vol) { if (v >= 0 && v < AU_VOICES) g_vo[v].vol = vol; }
void au_stop(int v) { if (v < 0) { for (auto &o : g_vo) o.on = 0; } else if (v < AU_VOICES) g_vo[v].on = 0; }

void au_mix(int16_t *out, int n, int outRate) {
  static float mix[4096]; if (n > 4096) n = 4096;
  memset(mix, 0, sizeof(float) * n);
  for (int v = 0; v < AU_VOICES; v++) {
    Voice &o = g_vo[v];
    if (!o.on || !o.d) continue;
    const unsigned gen = o.gen;   // if the game restarts this voice while we mix, we leave its new state alone
    const int16_t *d = o.d; const int len = o.len; const float vol = o.vol; const int loop = o.loop;
    double pos = o.pos; const double st = o.step / outRate;
    if (len < 2 || pos < 0) { if (o.gen == gen) o.on = 0; continue; }
    int ended = 0;
    for (int i = 0; i < n; i++) {
      int ip = (int)pos;
      if (ip >= len - 1) {
        if (loop) { pos = fmod(pos, (double)(len - 1)); ip = (int)pos; if (ip >= len - 1) ip = 0; }
        else { ended = 1; break; }
      }
      float fr = (float)(pos - ip);
      mix[i] += ((float)d[ip] + (float)(d[ip + 1] - d[ip]) * fr) * vol;
      pos += st;
    }
    if (o.gen == gen) { o.pos = pos; if (ended) o.on = 0; }
  }
  for (int i = 0; i < n; i++) {   // soft limiter: loud moments squash instead of clipping
    float x = mix[i], a = x < 0 ? -x : x;
    if (a > 20000.f) { float y = 20000.f + (a - 20000.f) * 12767.f / (a - 20000.f + 12767.f); x = x < 0 ? -y : y; }
    out[i] = (int16_t)x;
  }
}

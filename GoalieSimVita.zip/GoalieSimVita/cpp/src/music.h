// CHL 2026 native - the soundtrack: MP3s from assets/music/soundtrack (app0:music/soundtrack on the Vita), listed in
// tracks.txt. A decoder thread (mus_pump) fills a ring buffer, the audio thread mixes it in (mus_mix), and the game
// (mus_frame) says when music should play and picks the next song. Shuffled, never the same song twice in a row.
#pragma once
#include <string>
#include <cstdint>

// the decoder each platform supplies (mus_vita.cpp: the Vita's own MP3 decoder; mus_host.cpp: ffmpeg)
struct MDec;
MDec *mdec_open(const std::string &path, int *rate, std::string *err);   // nullptr on failure (err says why)
int mdec_read(MDec *d, int16_t *stereo, int maxFrames);                   // interleaved stereo; 0 = end, <0 = error
void mdec_close(MDec *d);
std::string plat_asset_dir();   // where the packed files are: "app0:" on the Vita

void mus_init();                          // read the track list (main thread, once)
extern float g_musVol;   // the music slider, 0-1 (read by the audio thread)
void mus_frame(bool want);                // every frame on the main thread: want = music should be playing here
void mus_pump();                          // the decoder thread: keep the ring buffer topped up
void mus_mix(float *L, float *R, int n, int outRate);   // the audio thread: add the music (int16 scale)
void mus_skip();                          // next song now
int mus_tracks(int *user = nullptr);      // how many songs (and how many are your own, from the data folder)

struct MusNow { bool on = false; std::string title, artist, err; double started = -1, pos = 0, len = 0; int idx = -1; };
MusNow mus_now();                         // for the now-playing popup
void drawMusicPopup();                    // the little player that rises from the bottom for a few seconds (menu.cpp)

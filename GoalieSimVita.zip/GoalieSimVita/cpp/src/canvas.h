// CHL 2026 native - a Canvas 2D style drawing context in C++.
// The same model the web build was written against (paths, arcs, ellipses, gradients, text, transforms),
// turned into coloured triangles and glyph quads for the platform layer. Ported from vita_shim.js, so the
// game looks exactly the way it did on the Vita - just without a JavaScript engine in the middle.
//
// cacheBlock(key, fn): the first call records the triangles and glyphs fn produces; later calls with the
// same key (and the same scale / rotation / alpha) replay them moved to the current origin. Static-looking
// layers (the rink, the crowd, every player pose) are drawn this way, so most of a frame is a replay.
#pragma once
#include "util.h"
#include <functional>
#include <unordered_map>

// ---- the platform side (platform_vita.cpp / platform_host.cpp)
void plat_tris(const float *xy, const uint32_t *col, int n, float dx, float dy, float k);
void plat_glyphs(const float *g7, int n, uint32_t col, float dx, float dy, float k);   // [x,y,u,v,w,h,scale] per glyph

enum Align { AL_LEFT, AL_CENTER, AL_RIGHT };
enum Base { BL_ALPHA, BL_MIDDLE, BL_TOP, BL_BOTTOM };
enum Cap { CAP_BUTT, CAP_ROUND };

struct Grad {
  int kind = 0;           // 0 linear (x0,y0,x1,y1), 1 radial (x0,y0,r0,x1,y1,r1)
  float a[6] = {0};
  struct Stop { float o; Col c; };
  std::vector<Stop> stops;
  Grad &add(float o, Col c) {
    Stop s{o, c}; auto it = stops.begin(); while (it != stops.end() && it->o <= o) ++it; stops.insert(it, s); return *this;
  }
  Col at(float x, float y) const;
};
struct Style {
  bool isG = false; Col c; Grad g;
  Style() {}
  Style(Col c_) : c(c_) {}
};

class Canvas {
public:
  float W = 960, H = 544;
  // state
  struct St {
    float a = 1, b = 0, c = 0, d = 1, e = 0, f = 0;
    float alpha = 1, lw = 1, px = 10;
    Style fill, stroke;
    Align align = AL_LEFT; Base base = BL_ALPHA; Cap cap = CAP_BUTT;
  } S;
  std::vector<St> stack;

  // ---- state
  void save() { stack.push_back(S); }
  void restore() { if (!stack.empty()) { S = stack.back(); stack.pop_back(); } }
  void setTransform(float a, float b, float c, float d, float e, float f) { S.a = a; S.b = b; S.c = c; S.d = d; S.e = e; S.f = f; }
  void resetTransform() { setTransform(1, 0, 0, 1, 0, 0); }
  void translate(double x, double y) { S.e += S.a * x + S.c * y; S.f += S.b * x + S.d * y; }
  void scale(double x, double y) { S.a *= x; S.b *= x; S.c *= y; S.d *= y; }
  void rotate(double r) { float c = (float)std::cos(r), s = (float)std::sin(r), a = S.a, b = S.b, cc = S.c, d = S.d;
    S.a = a * c + cc * s; S.b = b * c + d * s; S.c = cc * c - a * s; S.d = d * c - b * s; }
  void alpha(double a) { S.alpha = (float)a; }
  float alpha() const { return S.alpha; }
  void fill(Col c) { S.fill = Style(c); }
  void fill(const Grad &g) { S.fill.isG = true; S.fill.g = g; }
  void fill(const char *s) { fill(hex(s)); }
  void stroke(Col c) { S.stroke = Style(c); }
  void stroke(const char *s) { stroke(hex(s)); }
  void lineWidth(double w) { S.lw = (float)w; }
  void lineCap(Cap c) { S.cap = c; }
  void font(double px) { S.px = (float)px; }
  void align(Align a) { S.align = a; }
  void baseline(Base b) { S.base = b; }
  void textMid(Align a = AL_CENTER) { S.align = a; S.base = BL_MIDDLE; }

  // ---- paths
  void beginPath() { pts.clear(); subs.clear(); cur = -1; }
  void closePath() { if (cur >= 0) { subs[cur].closed = true; lastX = pts[subs[cur].s]; lastY = pts[subs[cur].s + 1]; cur = -1; } }
  void moveTo(double x, double y) { newSub((float)x, (float)y); }
  void lineTo(double x, double y) { addPt((float)x, (float)y); }
  void rect(double x, double y, double w, double h) { newSub(x, y); addPt(x + w, y); addPt(x + w, y + h); addPt(x, y + h); subs[cur].closed = true; }
  void arc(double x, double y, double r, double a0, double a1, bool ccw = false) { ellipsePts(x, y, r, r, 0, a0, a1, ccw); }
  void ellipse(double x, double y, double rx, double ry, double rot, double a0, double a1, bool ccw = false) { ellipsePts(x, y, rx, ry, rot, a0, a1, ccw); }
  void arcTo(double x1, double y1, double x2, double y2, double r);
  void fillPath() { fillSubs(S.fill); }
  void strokePath() { strokeSubs(S.stroke); }
  void fillRect(double x, double y, double w, double h);
  void strokeRect(double x, double y, double w, double h);
  // shortcuts
  void disc(double x, double y, double r) { beginPath(); arc(x, y, r, 0, 7); fillPath(); }
  void ring(double x, double y, double r) { beginPath(); arc(x, y, r, 0, 7); strokePath(); }
  void oval(double x, double y, double rx, double ry, double rot = 0) { beginPath(); ellipse(x, y, rx, ry, rot, 0, 7); fillPath(); }
  void line(double x0, double y0, double x1, double y1) { beginPath(); moveTo(x0, y0); lineTo(x1, y1); strokePath(); }
  void quad(double x0, double y0, double x1, double y1, double x2, double y2, double x3, double y3) { beginPath(); moveTo(x0, y0); lineTo(x1, y1); lineTo(x2, y2); lineTo(x3, y3); closePath(); fillPath(); }
  void rr(double x, double y, double w, double h, double r);   // rounded rect path (cheap corners)

  // ---- text
  void fillText(const std::string &t, double x, double y) { drawText(t, (float)x, (float)y, S.fill, nullptr, 0); }
  void strokeText(const std::string &t, double x, double y);
  float measure(const std::string &t) const { return measurePx(t, S.px); }
  float measurePx(const std::string &t, float px) const;
  // shrink the font until t fits in maxW (returns the size used)
  float fitPx(const std::string &t, float px, float maxW) { float w = measurePx(t, px); if (w > maxW && w > 0) px *= maxW / w; S.px = px; return px; }

  // ---- cache
  void cacheBlock(const Key &key, const std::function<void()> &fn);
  void cacheBlockScaled(const Key &key, float k, const std::function<void()> &fn);
  void cacheClear() { cache.clear(); }
  size_t cacheSize() const { return cache.size(); }
  size_t cacheBytes() const;
  void frame() { flush(); frameNo++; }
  void flush();

private:
  struct Sub { int s, n; bool closed; };
  std::vector<float> pts; std::vector<Sub> subs; int cur = -1; float lastX = 0, lastY = 0;
  void newSub(float x, float y) { subs.push_back({(int)pts.size(), 1, false}); pts.push_back(x); pts.push_back(y); cur = (int)subs.size() - 1; lastX = x; lastY = y; }
  void addPt(float x, float y) { if (cur < 0) { newSub(x, y); return; } pts.push_back(x); pts.push_back(y); subs[cur].n++; lastX = x; lastY = y; }
  void newSub(double x, double y) { newSub((float)x, (float)y); }
  void addPt(double x, double y) { addPt((float)x, (float)y); }
  float scaleOf() const { float v = std::sqrt(std::fabs(S.a * S.d - S.b * S.c)); return v > 0 ? v : 1; }
  void ellipsePts(double x, double y, double rx, double ry, double rot, double a0, double a1, bool ccw);
  uint32_t colorAt(const Style &st, float x, float y, float alpha) const;
  void fillSubs(const Style &st);
  void strokeSubs(const Style &st);
  void discTri(float x, float y, float r, uint32_t c);
  void drawText(const std::string &t, float x, float y, const Style &st, const float (*offs)[2], int no);

  // triangle batch
  static const int MAXV = 30000;
  std::vector<float> VP = std::vector<float>(MAXV * 2);
  std::vector<uint32_t> VC = std::vector<uint32_t>(MAXV);
  int vn = 0;
  inline void vert(float x, float y, uint32_t c) { if (vn >= MAXV) flush(); VP[vn * 2] = x; VP[vn * 2 + 1] = y; VC[vn] = c; vn++; }
  inline void tri(float x0, float y0, uint32_t c0, float x1, float y1, uint32_t c1, float x2, float y2, uint32_t c2) {
    if (vn + 3 > MAXV) flush(); vert(x0, y0, c0); vert(x1, y1, c1); vert(x2, y2, c2); }
  void glyphOut(const float *buf, int n, uint32_t col);

  // recorded blocks
  struct Cmd { int t; std::vector<float> p; std::vector<uint32_t> c; int n; uint32_t col; };
  struct Block { std::vector<Cmd> cmds; float e, f; uint32_t u; };
  std::unordered_map<uint64_t, Block> cache;
  std::vector<Cmd> *rec = nullptr; bool recQuiet = false;
  uint32_t frameNo = 0;
  uint64_t fullKey(const Key &k) const;
  void replay(const Block &b, float k);
  void trim();
};

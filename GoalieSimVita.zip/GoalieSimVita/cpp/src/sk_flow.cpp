// CHL 2026 native - forward game engine, part 3: the main update, the puck, goals and celebrations, whistles,
// board battles, line changes, periods / overtime / shootout and the end of the game.
#include "game.h"
#include "sk_int.h"
#include "pro.h"
#include <set>
#include "menu.h"

void skGoal(int team);
void skIcing(int t);
void skOffside(double dt);
void skPeriodEnd();
static bool skChangeLine(int ti, bool fly);
static double skShiftLen(int li);
void skToFaceoff(const std::string &name, Col col, const std::string &sub);
void skBattleStart(Skater *a, Skater *b);
void skBattleUpdate(double dt, const Input &I);
void skBenchCheck();
void skNetPuck(double dt);
void skCeleb(double dt);
void skBottleUpdate(double dt);
void skScratch(double dt);
static void skPuck(double dt);
double fqSl(const Src *q);

void skPuckJolt(double sp, double k) { Puck &P = SK->puck; double q = clamp(sp / 60, 0, 1.2); if (q < .15) return; P.bvz = std::max(P.bvz, q * rand(3, 7.5) * k); P.wob = std::max(P.wob, .45 + .55 * std::min(1.0, q)); }

// ---------------------------------------------------------------- the main update
unsigned g_skTick = 0;   // counts updates: the goalie's body is rebuilt once per update, in every phase
void skUpdate(double dt, const Pad &pad, uint32_t press) {
  if (!SK) return;
  g_skTick++;
  (void)pad; (void)press;
  dt = std::min(dt, .05);
  skTouchFrame();
  if (SK->shk > 0) SK->shk = std::max(0.0, SK->shk - dt * 3.4);
  if (SK->hitFl > 0) SK->hitFl -= dt;
  if (!SK->gls.empty()) { for (auto &q : SK->gls) q.t += dt; if (SK->gls[0].t > 1.5) SK->gls.erase(SK->gls.begin()); }
  if (SK->hstop > 0) { SK->hstop -= dt; if (SK->phase == PH_PLAY) return; }
  if (SK->phase == PH_PLAY && SK->user && onIce(SK->user)) SK->me.toi += dt;   // your ice time
  for (auto &f : feed) f.t += dt; while (!feed.empty() && feed[0].t > 2.6) feed.erase(feed.begin());
  if (SK->banner.t > 0) SK->banner.t -= dt;
  skRefUpdate(dt);
  for (auto &e : SK->fx) e.t += dt; SK->fx.erase(std::remove_if(SK->fx.begin(), SK->fx.end(), [](const HitFx &e) { return e.t >= .5; }), SK->fx.end());
  if (skHint > 0 && SK->phase == PH_PLAY) skHint -= dt;
  Puck &P = SK->puck; std::vector<Skater *> all = skAll();
  // camera
  Layout lay = skLayout();
  { double svx = P.owner ? P.owner->vx : P.vx, svy = P.owner ? P.owner->vy : P.vy, lk = std::min(1.0, dt * 2.5);
    SK->lx += (svx * (P.owner ? .55 : .2) - SK->lx) * lk; SK->ly += (svy * (P.owner ? .55 : .2) - SK->ly) * lk; }
  Pt tg = skCamClamp(lay, P.x + SK->lx, P.y + SK->ly);
  if (SK->phase == PH_INTRO) { Pt f{0, 0}; if (SK->user) f = {SK->user->x, SK->user->y}; else { for (Skater *q : SK->T[0].on) { f.x += q->x; f.y += q->y; } f.x /= SK->T[0].on.size(); f.y /= SK->T[0].on.size(); } tg = skCamClamp(lay, f.x, f.y); }
  { double k = std::min(1.0, dt * 3.5); SK->cam += (tg.x - SK->cam) * k; SK->camY += (tg.y - SK->camY) * k; }
  if (SK->drill && pracUpdate(dt)) return;
  if (SK->phase == PH_FACEOFF) {
    Faceoff &F = SK->fo; F.t += dt;
    // the goalies skate (not teleport) back to their creases for the faceoff - from the bench gate at the start of a
    // game, or from wherever the last play left them; the puck isn't dropped until they're set
    { bool set = true;
      for (int ti = 0; ti < 2; ti++) { Goalie &g = SK->T[ti].g; if (g.out) continue; double tx = defendX(ti) + tdir(ti) * 2.2, ty = RK.cy, dx = tx - g.x, dy = ty - g.y, dd = hyp(dx, dy);
        if (dd > .3) { double v = std::min(24.0, dd * 3) * dt; g.x += dx / dd * std::min(dd, v); g.y += dy / dd * std::min(dd, v); g.mv = dd > 2 ? 10 : 0; } else g.mv = 0;
        if (dd > 2.5) set = false; }
      if (!set && F.t > F.show - .15) F.t = F.show - .15;
#ifdef HOST_BUILD
      if (getenv("CHL_FODBG")) fprintf(stderr, "FO t %.2f g0 %.1f,%.1f g1 %.1f,%.1f set %d\n", F.t, SK->T[0].g.x, SK->T[0].g.y, SK->T[1].g.x, SK->T[1].g.y, (int)set);
#endif
    }
    auto cOf = [](Team &t) { for (Skater *q : t.on) if (q->role == R_C) return q; return t.on.empty() ? (Skater *)nullptr : t.on[0]; };
    Skater *c0 = cOf(SK->T[0]), *c1 = cOf(SK->T[1]); double drop = F.show + F.close;
    bool mine = c0 == SK->user && c0 && c0->user && !g_autoplay;
    int w = -1; Input I;
    if (!mine) SK->tap = false;
    if (mine) {
      I = skInput(); if (F.t < F.show + .08) I.pass = false;
      double win = skFoWindow(c0);
      if (I.pass) { double e = F.t - drop;
        if (std::fabs(e) <= win) { w = 0; F.res = std::fabs(e) < win * .35 ? "PERFECT DRAW" : "FACEOFF WON"; }
        else { w = 1; F.res = e < 0 ? "TOO EARLY" : "TOO LATE"; } }
      else if (F.t > drop + win) { w = 1; F.res = "TOO LATE"; }
      if (w >= 0) { bool ok = w == 0; if (ok) award(1); fillStat("fo", ok ? .06 : .015); pushFeed(xpTag(F.res, ok ? 1 : 0), ok ? "#7CFC9A" : "#ff7a7a"); SK->me.fow += ok ? 1 : 0; SK->me.fot++; }
    } else if (F.t >= std::min(drop, 1.0) && c0 && c1) {
      w = rnd() < clamp(.5 + (c0->at.fo - c1->at.fo) * .06, .15, .85) ? 0 : 1;
    }
    if (w >= 0) {
      SK->T[w].fow++;
      std::vector<Skater *> wg; for (Skater *q : SK->T[w].on) if (q != cOf(SK->T[w])) wg.push_back(q);
      Skater *back = !wg.empty() ? wg[(int)std::floor(rnd() * wg.size())] : SK->T[w].on[0];
      if (w == 0 && mine && hyp(I.mx, I.my) > .3 && !wg.empty()) {
        double bs = -1e9; for (Skater *b : wg) { double v = ((b->x - P.x) * I.mx + (b->y - P.y) * I.my) / std::max(1e-6, hyp(b->x - P.x, b->y - P.y)); if (v > bs) { bs = v; back = b; } } }
      double bx = back->x - P.x, by = back->y - P.y, bd = hyp(bx, by); if (!bd) bd = 1;
      c0->cool = .55; c1->cool = .55; P.x += bx / bd * 2; P.y += by / bd * 2;
      P.vx = bx / bd * 34; P.vy = by / bd * 34; P.passTo = back; P.last = cOf(SK->T[w]); P.lastPasser = P.last; P.passT = now(); P.pl = false; P.id++;
      SK->phase = PH_PLAY;
    }
    return;
  }
  if (SK->phase == PH_PREVIEW) { SK->pv.t += dt; if ((SK->pv.t > .7 && ((g_press & B_CROSS) || SK->tap)) || SK->pv.t > 9 || g_autoplay) { SK->tap = false; skIntroBegin(); } else SK->tap = false; return; }
  if (SK->phase == PH_INTRO) { skIntroTick(dt); return; }
  if (SK->lineNote.t > 0) SK->lineNote.t -= dt;
  if (SK->phase == PH_HOLD) { SK->gt += dt; skHoldUpdate(dt); return; }
  if (SK->phase == PH_STOP || SK->phase == PH_GOAL) {
    SK->stopT -= dt;
    if (SK->phase == PH_GOAL) { SK->goalT += dt; skNetPuck(dt); skCeleb(dt); skBottleUpdate(dt); }
    else for (Skater *p : all) { p->vx *= .9; p->vy *= .9; p->x += p->vx * dt; p->y += p->vy * dt; skBoardsP(p, 1.3, .2); }
    if (SK->stopT <= 0) {
      if (SK->phase == PH_GOAL) {
        Team &T0 = SK->T[0], &T1 = SK->T[1]; Celeb &cl = SK->cel; SK->phase = PH_TRANS;
        std::string sub = upper(T0.name) + "  " + istr(T0.score) + "  -  " + istr(T1.score) + "  " + upper(T1.name);
        if (cl.sc) sub += "   |   " + upper(cl.sc->nm) + (cl.as ? " (A: " + upper(cl.as->nm) + ")" : "");
        if (trActive()) skResume(); else skToFaceoff(SK->endAfter ? "FINAL" : "FACEOFF", SK->T[cl.team].col, sub);
        return;
      }
      if (!trActive() && !SK->endAfter) {
        Team &T0 = SK->T[0], &T1 = SK->T[1]; SK->phase = PH_TRANS;
        std::string sub = SK->nextPer ? (SK->per >= 3 ? std::string("OVERTIME") : std::string(SK->per == 1 ? "2ND" : "3RD") + " PERIOD")
          : upper(T0.name) + "  " + istr(T0.score) + "  -  " + istr(T1.score) + "  " + upper(T1.name);
        skToFaceoff("FACEOFF", hex("#38bdf8"), sub); return; }
      skResume();
    }
    return;
  }
  if (SK->phase == PH_TRANS) return;
  // clock
  if (!SK->drill) { SK->clock -= dt; if (SK->clock <= 0) { SK->clock = 0; skPeriodEnd(); return; } }
  SK->callPass = std::max(0.0, SK->callPass - dt);
  skCallsUpdate(dt);
  skBoxTick(dt);
  for (int t = 0; t < 2; t++) if (skShort(1 - t)) SK->T[t].ppt += dt;
  { Skater *o = P.owner; if (o && (P.x - RK.L / 2) * tdir(o->team) > 0) SK->T[o->team].toa += dt; }
  for (auto &T : SK->T) T.lineT += dt;
  Input I = skInput();
  SK->gt += dt;
  if (SK->phase == PH_PLAY) { skScratch(dt); skSprayUpd(dt); }
  if (SK->per == 3 && (SK->pullT -= dt) <= 0) { SK->pullT = .5;
    for (int ti = 0; ti < 2; ti++) { Team &t = SK->T[ti]; Skater *o = P.owner; if (!t.pulled && o && o->team == ti && (P.x - RK.L / 2) * tdir(ti) > 0 && skWantPull(ti) && t.box.empty()) skCheckPull(ti); } }
  if (SK->user && !onTeam(0, SK->user)) { SK->user->sprint = false; SK->user->st = std::min(100.0, SK->user->st + (SK->uBench ? 14 : 6) * dt); if (SK->user->st > 30) SK->user->tired = false; }   // resting in the box (or on the bench)
  // D-pad RIGHT when you're tired: the CPU skates you to the bench for a line change (RIGHT again: stay on).
  // Be a Pro, on the bench: TRIANGLE sims to your next shift.
  if (!g_autoplay && SK->user) { Skater *u = SK->user;
    if ((g_press & B_RIGHT) && onTeam(0, u)) {
      if (SK->benchRun) { SK->benchRun = false; pushFeed("STAYING ON", "#cbd5e1"); }
      else if (skBenchOpen()) { SK->benchRun = true; pushFeed("HEADING TO THE BENCH", "#93c5fd");
        if (P.owner == u) { Skater *to = nullptr; double bd = 1e9; for (Skater *q : SK->T[0].on) if (q != u) { double d = hyp(q->x - u->x, q->y - u->y); if (d < bd) { bd = d; to = q; } } if (to) skPass(u, to); } }
      else pushFeed(u->st < 70 ? "NOT TIRED ENOUGH TO CHANGE YET" : "YOU'RE FRESH - STAY OUT THERE", "#cbd5e1"); }
    if ((g_press & B_TRIANGLE) && SK->uBench) { skSimShift(); if (SK->phase != PH_PLAY) return; } }
  if (SK->benchRun && (!SK->user || !onTeam(0, SK->user))) SK->benchRun = false;
  // lines change on the fly when a shift runs long (the top line stays out longest): the other team always, and
  // your team in Be a Pro while you're on the bench (on your line, you decide when to go off)
  for (int ti = 0; ti < 2; ti++) { Team &T = SK->T[ti];
    if (SK->drill || T.lines.size() < 2 || !T.box.empty() || T.pulled || T.lineT < skShiftLen(T.li)) continue;
    if (ti == 0 && !(skProBench() && SK->uBench)) continue;
    if (P.owner && onTeam(ti, P.owner)) { if (T.lineT < skShiftLen(T.li) + 12) continue; }
    else if ((P.x - RK.L / 2) * tdir(ti) < -20 && T.lineT < skShiftLen(T.li) + 10) continue;   // not with the puck deep in their own end
    if (skChangeLine(ti, true) && ti == 0) SK->lineNote = {3, T.li}; }
  skBattleUpdate(dt, I);
  all = skAll();
  for (Skater *p : all) {
    if (SK->hasBat && (p == SK->bat.a || p == SK->bat.b)) { p->vx = p->vy = 0; p->ph += dt * 3; p->stun = std::max(0.0, p->stun - dt); continue; }
    if (p->folT > 0) p->folT -= dt;
    if (p->pkF > 0) p->pkF -= dt; if (p->chopT > 0) p->chopT -= dt; if (p->pkL.t > 0) p->pkL.t -= dt;
    if (p->hasDk || p->dkLat) skDekeUpdate(p, dt);
    p->stun = std::max(0.0, p->stun - dt); if (p->stun <= 0) p->kd = false; else if (p->kd) p->rgT += dt; p->cool = std::max(0.0, p->cool - dt); p->dcd = std::max(0.0, p->dcd - dt); p->poke = std::max(0.0, p->poke - dt);
    p->pokeA = std::max(0.0, p->pokeA - dt); p->spin = std::max(0.0, p->spin - dt); p->spinCd = std::max(0.0, p->spinCd - dt); p->block = std::max(0.0, p->block - dt);
    p->dash = std::max(0.0, p->dash - dt);
    Want want;
    if (p->stun <= 0 && !(p->block > 0)) want = (p->user && !g_autoplay) ? (SK->benchRun && p == SK->user ? skBenchSteer(p) : skUserControl(p, I, dt)) : skAI(p, dt);
    if (want.glide) { double cs0 = hyp(p->vx, p->vy), dec = 4 * dt; if (cs0 > dec) { p->vx -= p->vx / cs0 * dec; p->vy -= p->vy / cs0 * dec; } else p->vx = p->vy = 0; want = {p->vx, p->vy, false}; }
    { double k = skStam(p, (p->user && !g_autoplay) ? (SK->benchRun ? false : I.sprint) : p->wantSprint, hyp(want.vx, want.vy) > 4, dt); want.vx *= k; want.vy *= k; }
    if (p->hs > 0) { p->hs -= dt; double skl = clamp((p->at.agl - 3.5) / 6.5, 0, 1), k = std::exp(-dt * (2.6 + skl * 10)); p->vx *= k; p->vy *= k; p->hb = .55; if (p->hs <= 0) p->hs = 0; }
    else if (p->hb > 0) p->hb -= dt;
    double wm = hyp(want.vx, want.vy), cs = hyp(p->vx, p->vy);
    if (p->dash <= 0 && wm < 1) {
      double dec = (p->block > 0 ? 34 : p->user ? 5 : 8) * dt; if (cs > dec) { p->vx -= p->vx / cs * dec; p->vy -= p->vy / cs * dec; } else { p->vx = p->vy = 0; }
    } else {
      double turn = cs > 4 && wm > 1 ? (p->vx * want.vx + p->vy * want.vy) / (cs * wm) : 1, sk = clamp((p->at.agl - 3.5) / 6.5, 0, 1);
      double hard = turn < .6 ? clamp((.6 - turn) / 1.6, 0, 1) * clamp((cs - 6) / 22, 0, 1) : 0; p->turnHard = hard > .2;
      if (p->user) { if (cs > 20) fillStat("skate", .00009 * dt * 60); if (cs > 12 && p->turnHard) fillStat("edge", .00016 * dt * 60); /* (slow: about half a point a game) */ }
      double acc = (p->dash > 0 ? 140 : (p->user ? 33 + sk * 24 : 38 + sk * 24) * (p->hb > 0 ? 1.35 + sk * .9 : 1 - hard * (p->user ? .72 - .4 * sk : .5 - .3 * sk))) * dt;
      double dvx = want.vx - p->vx, dvy = want.vy - p->vy, dm = hyp(dvx, dvy);
      if (p->dash > 0 || cs < 3) { if (dm > acc) { p->vx += dvx / dm * acc; p->vy += dvy / dm * acc; } else { p->vx = want.vx; p->vy = want.vy; } }
      else {
        double ux = p->vx / cs, uy = p->vy / cs, al = dvx * ux + dvy * uy, pe = -dvx * uy + dvy * ux, m = hyp(al, pe);
        if (m > acc) { al *= acc / m; pe *= acc / m; }
        double grip = 1 - .42 * clamp((cs - 8) / 24, 0, 1) * (1 - sk * .45); pe *= grip;
        p->vx += al * ux - pe * uy; p->vy += al * uy + pe * ux;
      }
    }
    p->x += p->vx * dt; p->y += p->vy * dt;
    { double v0 = hyp(p->vx, p->vy); if (skBoardsP(p, 1.3, .15) && v0 > 10 && SK->gt - p->hitT < .8) { skGlassHit(p->x, p->y, clamp(v0 / 28, .3, 1)); p->hitT = -9; } }
    skNetBox(p->x, p->y, p->vx, p->vy, 1.3, .1, false);
    double sp = hyp(p->vx, p->vy);
    if (sp > 2) { p->ang = wrapA(p->ang); double da = wrapA(std::atan2(p->vy, p->vx) - p->ang); p->ang += da * std::min(1.0, dt * 6.5); }
    p->ph += sp * dt * .45;
    if (p->dash > 0) for (Skater *o : SK->T[1 - p->team].on) { if (o->stun <= 0 && hyp(o->x - p->x, o->y - p->y) < 3.2) { skHit(p, o); p->dash = 0; p->vx *= .4; p->vy *= .4; break; } }
    if (SK->phase != PH_PLAY) break;   // a hit that stopped play (knockout, penalty): the rest of the frame waits
  }
  all = skAll();
  for (size_t i = 0; i < all.size(); i++) for (size_t j = i + 1; j < all.size(); j++) {
    Skater *a = all[i], *b = all[j]; double dx = b->x - a->x, dy = b->y - a->y, d = hyp(dx, dy);
    if (d < 3.3 && d > 0) { double push = (3.3 - d) / 2 * std::min(1.0, dt * 20), nx = dx / d, ny = dy / d; a->x -= nx * push; a->y -= ny * push; b->x += nx * push; b->y += ny * push; }
  }
  skBenchCheck();
  for (auto &t : SK->T) { Goalie &g = t.g; if (g.pkF > 0) g.pkF -= dt; if (g.pkL.t > 0) g.pkL.t -= dt; skGoalie(g, dt); }
  if (SK->phase == PH_PLAY) skPuck(dt);
  if (SK && SK->phase == PH_PLAY) skOffside(dt);
}
// offsides: the puck has to cross the blue line before any attacker does (the man carrying it in is fine). A man
// already over when it goes in kills the play - faceoff at the neutral-zone dot outside that line. Off in Settings,
// and in practice. Also counts your attacking-zone time (the coach watches it).
double skBlueX(int t) { return RK.L / 2 + tdir(t) * SK_BLUE / 2; }
bool skPuckInZone(int t) { return (SK->puck.x - skBlueX(t)) * tdir(t) > .5; }
long g_offN = 0;
void skOffside(double dt) {
  Puck &P = SK->puck;
  if (SK->user && onIce(SK->user) && skPuckInZone(SK->user->team)) SK->me.ozt += dt;
  for (int t = 0; t < 2; t++) {
    int in = skPuckInZone(t) ? 1 : 0, was = SK->pzIn[t]; SK->pzIn[t] = in;
    if (was == 1 && in == 0) SK->pzOut[t] = SK->gt;
    if (SK->gt - SK->pzOut[t] < 2.5) continue;   // just came out and straight back in: the linesman lets it go (they had no time to tag up)
    if (!g_rOff || SK->drill || mode == "practice" || was != 0 || in != 1) continue;
    Skater *by = P.owner ? P.owner : P.last; if (!by || by->team != t) continue;
    double bx = skBlueX(t), d = tdir(t); Skater *off = nullptr;
    for (Skater *q : SK->T[t].on) if (q != by && q != P.owner && (q->x - bx) * d > 1.5) { off = q; break; }
    if (!off) continue;
#ifdef HOST_BUILD
    if (getenv("CHL_OFFDBG")) fprintf(stderr, "OFF team %d pass %d passTo %d owner %d dist %.1f offvx %.1f byx %.1f user %d\n", t, (int)P.pl, (int)(off == P.passTo), (int)(P.owner != nullptr), (off->x - bx) * d, off->vx * d, (by->x - bx) * d, (int)off->user);
#endif
    P.owner = nullptr; P.vx = P.vy = 0; P.hasShot = false; P.passTo = nullptr; P.ice = -1;
    SK->phase = PH_STOP; SK->stopT = 1.2; SK->hasNextFo = true; SK->nextFo = {bx - d * 5, P.y < RK.cy ? RK.cy - 22 : RK.cy + 22};
    if (off->user) SK->me.offs++;
    g_offN++; SK->banner = {1.2, "OFFSIDE", (off->user ? std::string("YOU") : off->nm) + " - over the line before the puck", hex("#93c5fd")};
    if (SK->hasRef) SK->ref.arm = 1.4;
    return;
  }
}

// ---- skate scratches: each stride carves a short mark; hard stops spray a wider one (cleaned every faceoff)
static double skU = 0, skT2 = 0;
void skScratch(double dt) {
  auto &S = SK->scr;
  for (int ti = 0; ti < 2; ti++) for (Skater *p : SK->T[ti].on) {
    double sp = hyp(p->vx, p->vy); if (!p->scrInit) { p->scrInit = true; p->sx = p->x; p->sy = p->y; p->sv = sp; p->sf = 1; }
    double dx = p->x - p->sx, dy = p->y - p->sy, d = hyp(dx, dy), dec = (p->sv - sp) / std::max(dt, 1e-3); p->sv = sp;
    if (dec > 55 && sp > 3 && !(p->stopT > 0) && (!p->user || p->hs > 0)) { p->stopT = .35;   // (yours: only a real hard stop sprays, not a sharp turn)
      { double v = sp + dec * dt; if (v > 12 && !(p->dash > 0) && !(p->stun > 0) && SK->gt - p->hitT > .5) { skSpray(p, v); sfx(S_STOP, sndAt(p->x, p->y) * std::min(1.0, v / 30) * (p->user ? 1 : .75), rand(.93, 1.07)); } }
      double a = std::atan2(p->vy, p->vx) + PI / 2;
      S.cur.push_back({(float)(p->x - std::cos(a) * 1.2), (float)(p->y - std::sin(a) * 1.2), (float)(p->x + std::cos(a) * 1.2), (float)(p->y + std::sin(a) * 1.2), .32f, .5f}); }
    if (p->stopT > 0) p->stopT = std::max(0.0, p->stopT - dt);
    if (d > 2.4) {
      { double sv = sndAt(p->x, p->y), nw = now() / 1000; if (sp > 7 && (p->user ? nw - skU > .05 : sv > .5 && nw - skT2 > .17)) { if (p->user) skU = nw; else skT2 = nw; sfx(S_SKATE, sv * (p->user ? .9 : .5) * std::min(1.0, .35 + sp / 40), rand(.9, 1.12)); } }
      if (sp > 7) { p->sf = -p->sf; double nx = -dy / d * .32 * p->sf, ny = dx / d * .32 * p->sf;
        S.cur.push_back({(float)(p->sx + nx), (float)(p->sy + ny), (float)(p->x + nx * 1.4), (float)(p->y + ny * 1.4), (float)(.11 + std::min(.07, sp * .002)), (float)(.22 + std::min(.14, sp * .003))}); }
      p->sx = p->x; p->sy = p->y; }
  }
  if (S.cur.size() >= 12) { S.b.push_back({++S.id, S.cur}); S.cur.clear(); if (S.b.size() > 30) S.b.erase(S.b.begin()); }
}

// ---------------------------------------------------------------- the puck
static void skPuckBounce(double dt) {
  Puck &P = SK->puck;
  if (P.bvz || P.bz > 0) { P.bvz -= PG * dt; P.bz += P.bvz * dt;
    if (P.bz <= 0) { P.bz = 0; double v = -P.bvz; if (v > 2.6) { P.bvz = v * .38; P.wob = std::max(P.wob, std::min(1.0, .35 + v * .05)); P.hop = .45; P.hopN++;
        if (v > 5 && !(P.roll > 0) && rnd() < .22) P.roll = rand(.8, 1.5); double sp = hyp(P.vx, P.vy); if (sp > 1) { double k = 1 - std::min(.25, v * .012); P.vx *= k; P.vy *= k; } } else P.bvz = 0; } }
  if (P.hop > 0) P.hop -= dt;
  if (P.roll > 0) { P.roll -= dt; double sp = hyp(P.vx, P.vy); if (sp > 3) { double sg = sgn(std::sin((P.id ? P.id : 1) * 7.1)); double c = .9 * dt * (sg ? sg : 1), cs = std::cos(c), sn = std::sin(c), vx = P.vx; P.vx = vx * cs - P.vy * sn; P.vy = vx * sn + P.vy * cs; } else P.roll = 0; }
  // a fluttering shot also dips and rises a little (the knuckle puck) - the goalie read where it was going, not this
  if (P.wob > 0 && P.hasShot && P.bz > .25) P.bvz += std::sin(SK->gt * 17 + P.id * 3.1) * P.wob * 5 * dt;
  if (P.wob > 0) { P.wob = std::max(0.0, P.wob - dt * .85); double sp = hyp(P.vx, P.vy);
    if (sp > 4) { double w = std::sin(SK->gt * 13 + P.id) * P.wob * sp * .32 * dt; P.vx += -P.vy / sp * w; P.vy += P.vx / sp * w; P.vx *= 1 - .18 * P.wob * dt; P.vy *= 1 - .18 * P.wob * dt; } }
}
static void skRedirect(Puck &P, int team, double spd, double errDeg, Skater *by, bool tip, Skater *from) {
  double a = attackX(team), ty = RK.cy + rand(-2.3, 2.3), ang = std::atan2(ty - P.y, a - P.x) + errDeg * PI / 180 * (rnd() + rnd() - 1) * 1.4;
  P.vx = std::cos(ang) * spd; P.vy = std::sin(ang) * spd; P.owner = nullptr; P.passTo = nullptr; P.saucer = false; P.pl = false; P.id++;
  P.hasShot = true; P.shot = Shot(); P.shot.team = team; P.shot.by = by; P.shot.spd = spd; P.shot.h = rnd(); P.shot.kind = SH_WRIST; P.shot.tip = tip; P.shot.defl = !tip;
  if (tip) { P.lastPasser = from; P.passT = now(); P.last = by; SK->T[team].shots++; if (by->user) SK->me.shots++; }
  P.clearTips();
}
static void skPuck(double dt) {
  if (SK->hasBat) return;
  std::vector<Skater *> AL = skAll(); Puck &P = SK->puck;
  if (P.owner) { P.bz = 0; P.bvz = 0; P.wob = 0;
    Skater *o = P.owner; double dl = o->dkLat, sw = std::sin(o->ph * 2.2) * .5 * (dl ? .3 : 1) + dl, fw = 2.2 + o->dkF;
    P.x = o->x + std::cos(o->ang) * fw - std::sin(o->ang) * sw; P.y = o->y + std::sin(o->ang) * fw + std::cos(o->ang) * sw; P.vx = o->vx; P.vy = o->vy;
    return; }
  skPuckBounce(dt);
  int steps = std::max(1, (int)std::ceil(hyp(P.vx, P.vy) * dt / .6)); double h = dt / steps;   // fine steps: the puck can't jump through a pad
  for (int s = 0; s < steps; s++) {
    double px = P.x;
    if (P.mag) { if (P.passTo && !P.hasShot) { Pt st = stickPt(P.passTo); double dx = st.x - P.x, dy = st.y - P.y, dd = hyp(dx, dy);
        if (dd > .4) { double sp = hyp(P.vx, P.vy), k = std::min(1.0, h * P.mag); P.vx += (dx / dd * sp - P.vx) * k; P.vy += (dy / dd * sp - P.vy) * k; } } else P.mag = 0; }
    P.x += P.vx * h; P.y += P.vy * h;
    if (P.hasShot) P.shot.t += h;
    bool over = P.bz > PZ + .3;
    if (!over && skGoalieSave(SK->T[0].g)) return;
    if (!over && skGoalieSave(SK->T[1].g)) return;
    for (int ti = 0; ti < 2; ti++) {
      double gx = defendX(ti), d = tdir(ti);
      if ((px - gx) * d > 0 && (P.x - gx) * d <= 0) {
        double off = std::fabs(P.y - RK.cy);
        if (over && off < RK.post + .6) { if (P.hasShot && P.shot.by && P.shot.by->user) pushFeed("OVER THE NET", "#94a3b8"); continue; }
        if (off < RK.post - .25) { skGoal(1 - ti); return; }
        if (off < RK.post + .4) { sfx(S_POST, sndAt(P.x, P.y) * std::min(1.0, .45 + hyp(P.vx, P.vy) / 120), rand(.97, 1.03)); skPuckJolt(hyp(P.vx, P.vy), 1.4); P.vx = -P.vx * .6; P.x = gx + d * .3; pushFeed("POST!", "#ffb300"); skShake(.38); }
        else if (g_rIce && P.ice == 1 - ti && !skShort(1 - ti)) { skIcing(1 - ti); return; }
      }
    }
    { double sp0 = hyp(P.vx, P.vy); bool b1 = skBoardsPuck(.4, .55); bool b2 = over ? false : skNetBox(P.x, P.y, P.vx, P.vy, .4, .4, true); if (b1 || b2) { if (P.hasShot) P.shot.gnd = true; skPuckJolt(sp0, .8); } }
    double spd = hyp(P.vx, P.vy);
    if (spd < 48) { Skater *mp = nullptr; double md = 1e9; Pt ms{0, 0};
      for (Skater *p : AL) { if (p->stun > 0 || p->cool > 0 || (P.hasShot && P.shot.by == p && P.shot.t < .3)) continue; Pt st = stickPt(p); double dd = hyp(st.x - P.x, st.y - P.y); if (dd < md) { md = dd; mp = p; ms = st; } }
      if (mp) { double R = 2.4 + mp->at.hand * .18; if (md < R && md > .05) { double a = (10 + mp->at.hand * 3) * (1 - md / R) * h; P.vx += (ms.x - P.x) / md * a; P.vy += (ms.y - P.y) / md * a; } } }
    for (Skater *p : AL) {
      int k = alIndex(AL, p);
      if (p->block > 0) {
        if (p->block > .2 && ((P.hasShot && P.shot.team != p->team) || (P.pl && P.lastPasser && P.lastPasser->team != p->team))) {
          double ax = std::cos(p->blkA), ay = std::sin(p->blkA), rx = P.x - p->x, ry = P.y - p->y, along = rx * ax + ry * ay, across = -rx * ay + ry * ax; long kk = (long)P.id * 100 + k;
          if (std::fabs(along) < 3.1 && std::fabs(across) < 1.1 && P.lbk != kk) { P.lbk = kk;
            if (rnd() < (P.hasShot && P.shot.team == 0 ? SKD().blk : .25)) { skPuckJolt(hyp(P.vx, P.vy), 1.2); P.vx = -P.vx * .12 + rand(-6, 6); P.vy = -P.vy * .12 + rand(-6, 6); bool wasShot = P.hasShot; P.hasShot = false; P.passTo = nullptr; P.pl = false; P.ice = -1;
              if (p->user) { if (wasShot) SK->me.blk++; award(3); pushFeed(xpTag(wasShot ? "SHOT BLOCKED" : "PASS BLOCKED", 3), "#7CFC9A"); } else if (p->team == 1 && wasShot && P.last && P.last->user) pushFeed("BLOCKED", "#ff7a7a"); break; } } }
        continue;
      }
      if (p->stun > 0 || p->cool > 0) continue;
      Pt st = stickPt(p); double dd = hyp(st.x - P.x, st.y - P.y), bd = hyp(p->x - P.x, p->y - P.y);
      if (P.saucer && P.passTo && p != P.passTo && hyp(P.x - P.passTo->x, P.y - P.passTo->y) > 5) continue;
      if (P.hasShot && P.shot.team != p->team && bd < 1.3 && spd > 40 && P.blk != (long)P.id * 100 + k) { P.blk = (long)P.id * 100 + k;
        if (rnd() < (P.shot.team == 0 ? SKD().blk : .3)) {
          Skater *sh = P.shot.by;
          if (sh && rnd() < clamp(.06 + (sh->at.wacc + sh->at.wpow - 7) * .01, .06, .2)) { skRedirect(P, sh->team, spd * .7, 6, sh, false, nullptr); if (sh->team == 0) pushFeed("DEFLECTED!", "#ffd54a"); break; }
          P.vx = -P.vx * .25 + rand(-10, 10); P.vy = P.vy * .3 + rand(-10, 10); P.hasShot = false; if (p->user) { SK->me.blk++; pushFeed("BLOCKED SHOT", "#7CFC9A"); } break; } }
      if (P.hasShot && P.shot.team != p->team && spd > 25 && dd < 2.4) {
        if (P.sthId != P.id) { P.sthId = P.id; memset(P.sth, -1, sizeof P.sth); }
        if (k < 16 && P.sth[k] < 0) P.sth[k] = rnd() < (P.shot.team == 0 ? (P.shot.kind == SH_SLAP ? SKD().thruS : SKD().thru) : .4) ? 1 : 0;
        if (k < 16 && P.sth[k] == 1) continue;
      }
      double r0 = (P.passTo == p ? 2.8 : 1.9) + p->at.hand * .05;
      if (P.pl && P.lastPasser && p->team != P.lastPasser->team && dd < r0 && k < 16) {
        if (P.thru[k] < 0) { P.thru[k] = rnd() < clamp((P.lastPasser->team == 0 ? .17 : .1) + (P.lastPasser->at.pass - 3.5) * .03, .1, .38) + P.pp * .3 ? 1 : 0; if (P.thru[k] && P.lastPasser->team == 0) pushFeed("THREADED IT THROUGH", "#93c5fd"); }
        if (P.thru[k] > 0) { if (P.thru[k] == 1 && bd < 1.3 && P.bz < .4 && rnd() < .22) { P.thru[k] = 2; double a = std::atan2(P.vy, P.vx) + rand(-.45, .45), v = hyp(P.vx, P.vy) * .7; P.vx = std::cos(a) * v; P.vy = std::sin(a) * v; P.passTo = nullptr; P.wob = std::max(P.wob, .5);
            if (P.lastPasser && P.lastPasser->team == 0) pushFeed("OFF THE SKATE", "#94a3b8"); } continue; }
      }
      if (dd < 2 && P.last && P.last->team == p->team && P.last != p && ((P.hasShot && P.shot.team == p->team) || (P.pl && P.passTo == p))) {
        double a = attackX(p->team), dn = hyp(a - p->x, RK.cy - p->y); bool front = (a - p->x) * tdir(p->team) > 2;
        if (front && dn < 22 && P.tipOn && k < 16 && P.tipT[k] < 0) {
          Skater *fr = P.last; double ch = P.hasShot ? clamp(.1 + (p->at.hand + p->at.wacc - 7) * .012, .1, .3) : clamp(.06 + (fr->at.pass + p->at.wacc - 7) * .01, .06, .22);
          P.tipT[k] = rnd() < ch ? 1 : 0;
          if (P.tipT[k]) { skRedirect(P, p->team, std::max(spd * .8, 55.0), (11 - p->at.wacc) * .6, p, true, fr); if (p->team == 0) pushFeed(p->user ? "TIPPED IT!" : "TIPPED!", "#ffd54a"); break; }
        }
      }
      double r = r0;
      if ((dd < r || (bd < 1.9 && spd < 30)) && !(P.bz > .9) && (spd < 70 || P.passTo == p) && !(P.hasShot && P.shot.by == p && P.shot.t < .3)) {
        if (!P.owner && !P.passTo && !P.hasShot && SK->phase == PH_PLAY && !SK->hasBat && !(SK->batCd > SK->gt) && !(p->stun > 0)) {
          Wall w = skWall(P.x, P.y); if (hyp(P.x - w.x, P.y - w.y) < 5) {
            Skater *o = nullptr; for (Skater *q : SK->T[1 - p->team].on) if (!(q->stun > 0) && !(q->block > 0) && hyp(q->x - P.x, q->y - P.y) < 7) { o = q; break; }
            if (o && rnd() < .65) { skBattleStart(p, o); return; } } }
        bool chop = false;
        if (!P.passTo && (P.bz > .15 || P.hop > 0 || P.roll > 0)) { if (P.hopRid != P.id) { P.hopRid = P.id; P.hopR.clear(); }
          int kk = k * 1000 + P.hopN; auto it = P.hopR.find(kk);
          if (it == P.hopR.end()) it = P.hopR.emplace(kk, rnd() < (P.roll > 0 ? .4 : .5) ? (rnd() < clamp(.15 + p->at.hand * .07, .2, .85) ? 2 : 0) : 1).first;
          if (it->second == 0) { p->cool = std::max(p->cool, .25); continue; }
          chop = it->second == 2; }
        bool fromPass = P.passTo == p && P.lastPasser && P.lastPasser->team == p->team;
        if (chop) { p->chopT = .4; P.roll = 0; if (p->user) pushFeed("CHOPPED IT DOWN", "#93c5fd"); }
        P.owner = p; P.vx = P.vy = 0; P.hasShot = false; P.ice = -1; P.saucer = false; P.mag = 0;
        p->gotT = SK->gt; p->gotPass = fromPass; if (spd > 12) sfx(S_PASS, sndAt(p->x, p->y) * std::min(.6, spd / 90), rand(.78, .86)); p->dec = std::min(p->dec, fromPass ? .03 : .1);
        if (P.lastPasser && P.lastPasser->team != p->team) P.lastPasser = nullptr;
        if (!fromPass && P.last && P.last->team != p->team && p->user) SK->me.tk++;
        if (P.pl && P.lastPasser && P.lastPasser != p && P.lastPasser->team == p->team) SK->T[p->team].pc++;
        if (P.pl && P.lastPasser && P.lastPasser->user && P.lastPasser != p && P.lastPasser->team == p->team) { SK->me.pass++; award(1); fillStat("pass", .03); pushFeed(xpTag("PASS", 1), "#93c5fd"); }
        if (p->user) fillStat("hand", .006);
        P.pl = false;
        P.passTo = nullptr; P.last = p; return;
      }
    }
  }
  double f = std::exp(-.42 * dt); P.vx *= f; P.vy *= f;
  { double sp = hyp(P.vx, P.vy);
    if (P.passTo && sp < 8) { P.passTo = nullptr; P.saucer = false; }
    if (P.hasShot && (sp < 22 || P.shot.t > 1.6)) P.hasShot = false; }
}
void skIcing(int t) {
  Puck &P = SK->puck; P.owner = nullptr; P.vx = P.vy = 0; P.hasShot = false; P.passTo = nullptr; P.ice = -1;
  SK->phase = PH_STOP; SK->stopT = 1.3;
  SK->hasNextFo = true; SK->nextFo = {defendX(t) + tdir(t) * 20, P.y < RK.cy ? RK.cy - 22 : RK.cy + 22};
  SK->banner = {1.3, "ICING", SK->T[t].name + " - faceoff in their zone", hex("#93c5fd")};
}
// a goalie who lets in too many on too few shots gets the hook and the backup comes in (once a game)
static void skPullCheck(int gt) {
  Team &T = SK->T[gt], &O = SK->T[1 - gt];
  if (T.swapped || SK->per > 3 || T.g.out) return;
  int ga = O.score, sa = O.sog;
  if (!(ga >= 5 || (ga >= 4 && sa > 0 && (double)ga / sa > .22))) return;
  T.swapped = true;
  std::string old = T.g.nm;
  if (T.bk) { T.g.gs = gStats(T.bk); T.g.r = T.bk->r; T.g.nm = T.bk->nm; gsSplit(T.g.gs, T.g.nm); }   // Ultimate Franchise: the G2 card
  else { GS &g0 = T.g.gs; for (double *v : {&g0.agi, &g0.glv, &g0.blk, &g0.pad, &g0.chs, &g0.sta, &g0.rec, &g0.rd, &g0.gh, &g0.gl, &g0.bh, &g0.bl}) *v = std::max(50.0, *v - 6); T.g.nm = "BACKUP"; }
  T.g.ast = 100; T.g.faced = 0;
  pushFeed(upper(T.name) + " PULL " + upper(old) + " - " + upper(T.g.nm) + " IN", "#ff9800");
}

// ---------------------------------------------------------------- board battles
static double skBattleStr(const Skater *p) { return .8 + .4 * ((p->at.chk + p->at.hand) / 2 - 5) / 5; }
void skBattleStart(Skater *a, Skater *b) {
  Puck &P = SK->puck; Wall w = skWall(P.x, P.y); double tx = -w.ny, ty = w.nx; if (a->team != 0 && b->team == 0) std::swap(a, b);
  P.x = w.x - w.nx * 1.2; P.y = w.y - w.ny * 1.2; P.vx = P.vy = 0; P.bz = 0; P.bvz = 0; P.passTo = nullptr; P.hasShot = false; P.roll = 0;
  for (auto pr : {std::make_pair(a, 1.0), std::make_pair(b, -1.0)}) { Skater *p = pr.first; double s = pr.second;
    p->x = P.x - w.nx * 2.2 + tx * s * 1.1; p->y = P.y - w.ny * 2.2 + ty * s * 1.1; p->vx = p->vy = 0; p->ang = std::atan2(w.ny, w.nx); p->dash = 0; p->hasDk = false; p->dkLat = 0; }
  SK->hasBat = true; SK->bat = Battle(); SK->bat.a = a; SK->bat.b = b; SK->bat.w = {w.x, w.y, w.nx, w.ny}; SK->bat.user = (a == SK->user || b == SK->user) && !g_autoplay;
  if (SK->bat.user) pushFeed("BOARD BATTLE!", "#ffd54a");
}
void skBattleUpdate(double dt, const Input &I) {
  if (!SK->hasBat) return; Battle &B = SK->bat; B.t += dt; Puck &P = SK->puck;
  if (SK->phase != PH_PLAY || !onIce(B.a) || !onIce(B.b)) { SK->hasBat = false; return; }
  double sa = skBattleStr(B.a), sb = skBattleStr(B.b);
  if (B.user) { double mx = I.mx; int sg = mx > .5 ? 1 : mx < -.5 ? -1 : 0; if (sg && sg != B.ls) { if (B.ls) B.prog += .055 * sa; B.ls = sg; }
    B.prog -= .22 * sb * dt * (.8 + .4 * std::sin(B.t * 5.3)); }
  else B.prog += (sa - sb) * .5 * dt + rand(-.6, .6) * dt;
  P.x = B.w.x - B.w.nx * 1.2; P.y = B.w.y - B.w.ny * 1.2; P.vx = P.vy = 0;
  double lim = B.user ? 3.2 : 1.3;
  if (B.prog >= 1 || B.prog <= 0 || B.t > lim) { Skater *win = B.prog >= .5 ? B.a : B.b, *lose = win == B.a ? B.b : B.a;
    P.owner = win; win->gotT = SK->gt; win->gotPass = false; P.last = win; win->vx = -B.w.nx * 11; win->vy = -B.w.ny * 11; win->ang = std::atan2(-B.w.ny, -B.w.nx);
    lose->stun = std::max(lose->stun, .35); lose->cool = .6; SK->hasBat = false; SK->batCd = SK->gt + 18;
    if (win->user) pushFeed("WON THE BOARD BATTLE", "#7CFC9A"); else if (lose->user) pushFeed("LOST THE BATTLE", "#ff7a7a");
    sfx(S_HIT, sndAt(P.x, P.y) * .5, 1.15); }
}

// ---------------------------------------------------------------- goals
static void skBottleFly(int ti, const Puck &P) {
  if (SK->btl[ti].s != BT_NET) return;
  double s = -tdir(ti), gx = defendX(ti);
  SK->btl[ti] = {BT_FLY, gx + s * 1.4, RK.cy + 1.3, 5.2, s * rand(3, 7) + P.vx * .05, rand(-6, 6) + P.vy * .06, rand(8, 12), 0, rand(-16, 16)};
}
void skGoal(int team) {
  if (SK->drill) { pracGoal(team); return; }
  Puck &P = SK->puck; Team &T = SK->T[team]; T.score++; T.sog++; { int k = std::min(SK->per, 4) - 1; SK->pg[team][k]++; SK->ps[team][k]++; }
  { Goalie &gg = SK->T[1 - team].g; gg.conf = std::max(-.6, gg.conf - .2); gg.svRun = 0; }   // a goal rattles his confidence (enough that a team that keeps coming can chase even a great goalie)
#ifdef HOST_BUILD
  if (getenv("CHL_GKIND")) { Goalie &gg = SK->T[1 - team].g; const char *k = P.hasShot ? (SK->gt - P.shot.t < 1.2 ? "SHOT" : "SHOT_LATE") : P.pl ? "PASS" : P.owner ? "CARRY" : "LOOSE";
    fprintf(stderr, "GKIND %s team %d an %d p %d spr %.2f bz %.2f gx %.1f px %.1f spd %.0f gdist %.1f gy %.1f py %.1f rebound %d\n", k, team, (int)gg.hasAn, (int)gg.an.p, gg.spr, P.bz, (gg.x - defendX(1 - team)) * tdir(1 - team), (P.x - defendX(1 - team)) * tdir(1 - team), hyp(P.vx, P.vy), hyp(gg.x - defendX(1 - team), gg.y - RK.cy), gg.y - RK.cy, P.y - RK.cy, (int)(SK->gt - gg.lastSv < 2.0)); }
  if (getenv("CHL_SVDBG")) { Goalie &gg = SK->T[1 - team].g; fprintf(stderr, "GOAL read %d z %.2f off %.2f out %d spd %.0f aimY %.2f aimZ %.2f an %d p %d t %.2f age %.2f gx %.1f pass %.2f\n", (int)(gg.rid == P.id ? gg.read : -1), P.bz, P.y - gg.y, (int)gg.out, hyp(P.vx, P.vy), gg.aimY, gg.aimZ / 1.7, (int)gg.hasAn, (int)gg.an.p, gg.an.t, SK->gt - gg.aimT, (P.x - gg.x) * tdir(gg.team), P.lastPasser ? (now() - P.passT) / 1000.0 : 9.0); char b[400]; void skGoalieDbg(Goalie &, char *, int); skGoalieDbg(gg, b, 400); fprintf(stderr, "     %s\n", b); }
#endif
  if (skShort(team)) T.shg++;
  if (SK->user && onIce(SK->user) && !(SK->T[1 - team].box.size() > T.box.size())) SK->me.pm += SK->user->team == team ? 1 : -1;   // +/- (not on power-play goals)
  if (SK->ut) { bool pp = SK->T[1 - team].box.size() > T.box.size();
    if (!pp) for (Skater *q : SK->T[0].on) if (q->src && !q->src->utk.empty()) SK->utPM[q->src->utk] += team == 0 ? 1 : -1; }
  { Team &O = SK->T[1 - team]; for (size_t i = 0; i < O.box.size(); i++) if (!O.box[i].ko && O.box.size() > T.box.size()) { Skater *bp = O.box[i].p; O.box.erase(O.box.begin() + i); skBoxOut(O, 1 - team, bp); pushFeed("POWER PLAY GOAL", "#ffd54a"); break; } }
  Skater *sc = P.last && P.last->team == team ? P.last : (P.hasShot && P.shot.by) ? P.shot.by : P.last;
  Skater *as = P.lastPasser && P.lastPasser->team == team && P.lastPasser != sc && now() - P.passT < 9000 ? P.lastPasser : nullptr;
  if (SK->ut && team == 0) { if (sc && sc->src && !sc->src->utk.empty()) SK->utG[sc->src->utk]++; if (as && as->src && !as->src->utk.empty()) SK->utA[as->src->utk]++; }
  if (sc && sc->user) { SK->me.g++; SK->me.sog++; award(30); if (P.hasShot) fillStat(P.shot.kind == SH_SLAP ? "slacc" : P.shot.kind == SH_BACK ? "bha" : "sacc", .03); pushFeed(xpTag("GOAL! " + skShotName(P), 30), "#ffd54a"); }
  if (as && as->user) { SK->me.a++; award(10); fillStat("pass", .06); pushFeed(xpTag("ASSIST", 10), "#ffd54a"); }
  proCredit(sc, as);
  SK->banner = {2.2, team == 0 ? "GOAL!" : "GOAL", (sc ? sc->nm : "") + (as ? "  (A: " + as->nm + ")" : ""), team == 0 ? hex("#60a5fa") : hex("#ff5252")};
  SK->gcol = team == 0 ? hex("#22c55e") : hex("#ef4444"); SK->goalT = 0;
  if (team == SK->homeTi) { sfx(S_HORN, .85, 1); sfx(S_CHEER, .8, rand(.97, 1.03)); } else sfx(S_BOO, .85, rand(.96, 1.03));   // the home crowd: cheers for theirs, boos for the road team
  { int ti = 1 - team; if ((P.hasShot && P.shot.h > .6) || P.bz > 2.4) skBottleFly(ti, P); P.owner = nullptr; P.vx *= .85; P.vy *= .85; P.hasShot = false; P.passTo = nullptr;
    SK->hasNetIn = true; SK->netIn = {ti, defendX(ti), -tdir(ti)}; P.x = defendX(ti) - tdir(ti) * .4; }
  SK->hasCel = true; SK->cel = Celeb(); SK->cel.team = team; SK->cel.sc = sc && sc->team == team ? sc : nullptr; SK->cel.as = as;
  SK->phase = PH_GOAL; SK->stopT = 3; SK->hasNextFo = true; SK->nextFo = {RK.L / 2, RK.cy};
  skPullCheck(1 - team);
  if (SK->per > 3) SK->endAfter = true;
}
void skResume() {
  SK->hasCel = false; SK->hasNetIn = false; SK->hasBat = false; SK->nb[0] = SK->nb[1] = NetBulge(); SK->btl[0] = SK->btl[1] = Bottle(); SK->spr.clear(); SK->gls.clear(); SK->shk = 0; SK->hstop = 0;
  for (Skater *p : skAll()) { p->wind = 0; p->hasDk = false; p->dkLat = 0; p->dkF = 0; }
  if (SK->endAfter) { skEnd(); return; }
  if (SK->nextPer) { SK->nextPer = false; SK->per++; SK->clock = SK->per > 3 ? 60 : SK_PER; SK->foN = 0; }
  Pt f = SK->hasNextFo ? SK->nextFo : Pt{RK.L / 2, RK.cy}; SK->hasNextFo = false; skFaceoff(f.x, f.y);
}
void skBottleUpdate(double dt) {
  for (Bottle &b : SK->btl) { if (b.s == BT_NET) continue;
    b.x += b.vx * dt; b.y += b.vy * dt; b.a += b.va * dt;
    if (b.s == BT_FLY) { b.vz -= 32 * dt; b.z += b.vz * dt; if (b.z <= 0) { b.z = 0; if (b.vz < -5) { b.vz = -b.vz * .3; b.vx *= .6; b.vy *= .6; b.va *= .7; } else { b.vz = 0; b.s = BT_ICE; } } }
    else { double f = std::exp(-2.6 * dt); b.vx *= f; b.vy *= f; b.va *= f; }
    if (b.x < 1 || b.x > RK.L - 1) { b.vx = -b.vx * .4; b.x = clamp(b.x, 1, RK.L - 1); } if (b.y < 1 || b.y > RK.Wd - 1) { b.vy = -b.vy * .4; b.y = clamp(b.y, 1, RK.Wd - 1); }
  }
}
static void skNetHit(int ti, double y, double sp) {
  double a = clamp(std::pow(clamp((sp - 12) / 50, 0, 1.3), 1.35) * 2.3, .12, 2.4); NetBulge &o = SK->nb[ti];
  if (!o.on || a > o.a * std::exp(-3.2 * o.t)) o = {true, y, a, 0};
}
void skNetPuck(double dt) {
  Puck &P = SK->puck;
  for (auto &o : SK->nb) if (o.on) o.t += dt;
  if (!SK->hasNetIn) return; auto &G = SK->netIn;
  int n = std::max(1, (int)std::ceil(hyp(P.vx, P.vy) * dt / .4)); double h = dt / n, pw = RK.post - .45;
  for (int i = 0; i < n; i++) {
    P.x += P.vx * h; P.y += P.vy * h;
    double lat = P.y - RK.cy;
    if (std::fabs(lat) > pw) { double sg = sgn(lat); P.y = RK.cy + sg * pw; if (P.vy * sg > 0) { skNetHit(G.ti, lat, std::fabs(P.vy) * .6); P.vy = -P.vy * .25; P.vx *= .8; } lat = P.y - RK.cy; }
    double dep = (P.x - G.gx) * G.s, md = std::max(.6, RK.netD * .95 * std::pow(std::max(0.0, 1 - std::pow(std::fabs(lat) / RK.post, 4)), .25));
    if (dep > md) { P.x = G.gx + G.s * md; double vs = P.vx * G.s; if (vs > 0) { skNetHit(G.ti, lat, vs); P.vx = -P.vx * .08; P.vy = P.vy * .75 + rand(-1, 1) * vs * .1; } }
    else if (dep < .35) { P.x = G.gx + G.s * .35; if (P.vx * G.s < 0) P.vx = -P.vx * .3; }
  }
  double f = std::exp(-3 * dt); P.vx *= f; P.vy *= f;
}
void skCeleb(double dt) {
  if (!SK->hasCel) return; Celeb &c = SK->cel; c.t += dt;
  Team &T = SK->T[c.team], &O = SK->T[1 - c.team]; Skater *sc = c.sc && onTeam(c.team, c.sc) ? c.sc : (T.on.empty() ? nullptr : T.on[0]); double d = tdir(c.team);
  if (sc && !c.hasTg) { c.hasTg = true; c.tgx = attackX(c.team) - d * 17; c.tgy = sc->y < RK.cy ? 3.2 : RK.Wd - 3.2; }
  if (sc && !c.gl && hyp(sc->x - c.tgx, sc->y - c.tgy) < 2.6) { c.gl = true; skGlassHit(sc->x, sc->y, .85); skShake(.2); }
  auto steer = [&](Skater *p, double tx, double ty, double sp, double k) { double dx = tx - p->x, dy = ty - p->y, m = hyp(dx, dy), v = std::min(sp, m * 2.2), a = std::min(1.0, k * dt);
    p->vx += ((m > .3 ? dx / m * v : 0) - p->vx) * a; p->vy += ((m > .3 ? dy / m * v : 0) - p->vy) * a; };
  for (size_t i = 0; i < T.on.size(); i++) { Skater *p = T.on[i];
    if (!sc) break;
    if (p == sc) steer(p, c.tgx, c.tgy, 28, 2.4); else { double a = i * 2.3 + c.t * .9; steer(p, sc->x + std::cos(a) * 3.4, sc->y + std::sin(a) * 3.4, 31, 2.2); }
    bool nr = hyp(p->x - sc->x, p->y - sc->y) < 7;
    p->wind = (p == sc && c.t > .25) || (nr && c.t > .5) ? std::round(clamp(.55 + .45 * std::sin(c.t * 9 + i * 1.3), 0, 1) * 4) / 4 : 0; }
  for (Skater *p : O.on) { steer(p, p->x + (RK.L / 2 - p->x) * .3, p->y, 7, 1); p->wind = 0; }
  for (Skater *p : skAll()) { p->x += p->vx * dt; p->y += p->vy * dt; skBoardsP(p, 1.3, .2); double v = hyp(p->vx, p->vy); if (v > 2.5) p->ang = std::atan2(p->vy, p->vx); p->ph += v * dt * .45; }
}
void skPeriodEnd() {
  int t0 = SK->T[0].score, t1 = SK->T[1].score;
  SK->phase = PH_STOP; SK->stopT = 1.8;
  if (SK->per < 3) { SK->banner = {1.8, SK->per == 1 ? "END OF 1ST" : "END OF 2ND", "", hex("#ffffff")}; SK->nextPer = true; }
  else if (SK->per == 3 && t0 == t1) { SK->banner = {1.8, "OVERTIME", "", hex("#ffd54a")}; SK->nextPer = true; }
  else {
    if (t0 == t1) {   // a shootout after overtime: decided by the skills on the ice
      auto sk = [](Skater *p) { return (p->at.wacc + p->at.wpow + p->at.lacc + p->at.spow) / 2; };
      double a = 0, b = 0; for (Skater *p : SK->T[0].on) a += sk(p); a /= std::max<size_t>(1, SK->T[0].on.size()); for (Skater *p : SK->T[1].on) b += sk(p); b /= std::max<size_t>(1, SK->T[1].on.size());
      int w = rnd() < clamp(.5 + (a - b) * .03 + (SK->T[0].g.r - SK->T[1].g.r) * .02, .25, .75) ? 0 : 1;
      SK->T[w].score++; RS.so = true;
      SK->banner = {1.8, w == 0 ? "SHOOTOUT WIN" : "SHOOTOUT LOSS", "", w == 0 ? hex("#7CFC9A") : hex("#ff5252")};
    } else SK->banner = {1.8, "FINAL", "", hex("#ffffff")};
    SK->endAfter = true;
  }
}

// ---------------------------------------------------------------- lines
// Be a Pro: you play on the top line only; the other lines take their shifts while you sit on the bench
bool skProBench() { return SK && mode == "pro" && !SK->ut && !SK->drill && SK->T[0].lines.size() == 3 && SK->uLine >= 0 && SK->uLine < 3 && SK->T[0].lines[(size_t)SK->uLine].size() == 2; }
// how long a line stays out (game seconds): the top line plays the longest shifts, the third line the shortest
static double skShiftLen(int li) { static const double S[3] = {38, 28, 20}; return S[std::max(0, std::min(2, li))]; }
static double skBenchRest(const Src *src, double f) {
  if (!src || src->en < 0) return 100; double r = std::max(0.0, SK->gt - src->et - 3); static const double LG[4] = {1, 1.1, 1.2, 1.3};
  return std::min(100.0, src->en + r * 2.75 * (.7 + .6 * f) * LG[src->lg]);
}
static double skLineRest(Team &T, int i) {
  if (i == T.li) { double a = 0; for (Skater *p : T.on) a += p->st; return a / std::max<size_t>(1, T.on.size()); }
  auto &L = T.lines[i]; double a = 0; for (Src *s : L) a += skBenchRest(s, .5); return a / std::max<size_t>(1, L.size());
}
static int skNextLine(Team &T, bool force) {
  double cur = skLineRest(T, T.li); int nx = (T.li + 1) % T.lines.size();
  if (nx == 0 && skLineRest(T, 0) < 99.5) { int b = -1; double bv = -1; for (int i = 1; i < (int)T.lines.size(); i++) { if (i == T.li) continue; double v = skLineRest(T, i); if (v > bv) { bv = v; b = i; } }
    if (b >= 0 && (bv > cur || force)) nx = b; else nx = force ? nx : -1; }
  return nx;
}
static bool skChangeLine(int ti, bool fly) {
  Team &T = SK->T[ti]; if (T.lines.size() < 2 || !T.box.empty() || T.pulled) return false;
  bool pb = ti == 0 && skProBench(); Skater *U = SK->user;
  if (ti == 0 && U && !onTeam(0, U) && !(pb && SK->uBench)) return false;
  bool ut = SK->ut && ti == 0;
  std::vector<Skater *> olds; for (Skater *p : T.on) if (ut || !p->user || pb) olds.push_back(p);
  Puck &P = SK->puck; Skater *own = std::find(olds.begin(), olds.end(), P.owner) != olds.end() ? P.owner : nullptr; if (own && !fly) return false;   // on the fly the new man in his spot takes the puck
  T.li = (T.li + 1) % T.lines.size(); auto &L = T.lines[T.li];
  bool youOn = ti == 0 && U && !ut && (!pb || T.li == SK->uLine);   // Be a Pro: you are on the ice only with your line
  std::vector<Role> roles = youOn ? skMateRoles(skUserRole()) : std::vector<Role>{R_C, R_LW, R_RW};
  for (Skater *o : olds) if (o->src) { o->src->en = o->st; o->src->et = SK->gt; o->src->lg = pkT(o, PK_LUNGS); }
  std::vector<Skater *> nw;
  for (size_t k = 0; k < L.size(); k++) { Role r = k < roles.size() ? roles[k] : R_RW; Skater *np = skMk(ti, r, L[k], false);
    Skater *op = nullptr; for (Skater *o : olds) if (o->role == r) { op = o; break; } if (!op && k < olds.size()) op = olds[k];
    if (fly && op) { np->x = op->x; np->y = op->y; np->vx = op->vx; np->vy = op->vy; np->ang = op->ang; }
    np->lane = r == R_LW ? -tdir(ti) : r == R_RW ? tdir(ti) : 0; np->st = skBenchRest(L[k], clamp((np->at.stam - 3.5) / 6.5, 0, 1)); nw.push_back(np); }
  T.lineT = 0;
  // you get a breather on the change (a real one when you went to the bench)
  if (ti == 0 && U && !ut && !pb) { double f = clamp((U->at.stam - 3.5) / 6.5, 0, 1); U->st = std::min(100.0, U->st + (fly ? 60 : 40) * (.7 + .6 * f)); U->tired = U->st < 20; }
  if (pb) { bool wasOn = std::find(olds.begin(), olds.end(), U) != olds.end();
    if (wasOn && !youOn) { SK->uBench = true; U->vx = U->vy = 0; U->sprint = false; U->hasDk = false; U->wind = 0; BenchSpot B = skBench(); U->x = B.x; U->y = B.y + 4; if (P.owner == U) P.owner = nullptr; }
    if (youOn) { Skater *op = nullptr; for (Skater *o : olds) if (o->role == skUserRole()) op = o; if (!op && !olds.empty()) op = olds[0];
      if (fly && op) { U->x = op->x; U->y = op->y; U->vx = op->vx; U->vy = op->vy; U->ang = op->ang; } else { BenchSpot B = skBench(); U->x = B.x; U->y = B.y - 2; U->vx = U->vy = 0; }
      if (P.owner == op && op) own = op;
      SK->uBench = false; U->role = skUserRole(); U->stun = 0; U->tired = U->st < 20; } }
  if (std::find(olds.begin(), olds.end(), P.passTo) != olds.end()) P.passTo = nullptr;
  if (own) { Skater *np = nullptr; for (Skater *q : nw) if (q->role == own->role) { np = q; break; } if (!np) np = nw[0]; P.owner = np; np->gotT = SK->gt;
    if (pb && youOn && own->role == skUserRole()) { P.owner = U; U->gotT = SK->gt; } }
  if (ut) { nw[0]->user = true; nw[0]->tend = TD_USER; SK->user->user = false; SK->user = nw[0]; T.on = nw; }   // you take over the new center
  else { T.on.clear(); if (youOn) T.on.push_back(U); T.on.insert(T.on.end(), nw.begin(), nw.end()); }
  if (own && own == U && !youOn) { /* handled above */ }
  T.bench.clear(); for (size_t i = 0; i < T.lines.size(); i++) if ((int)i != T.li) T.bench.insert(T.bench.end(), T.lines[i].begin(), T.lines[i].end());
  SK->warmT = -1;
  if (ti == 0 && U && (fly || ut || pb)) pushFeed(ut ? "LINE " + istr(T.li + 1) + " ON - YOU: " + upper(SK->user->nm) : pb ? (youOn ? "YOUR LINE IS UP - BACK ON THE ICE" : "LINE " + istr(T.li + 1) + " ON - YOU ARE ON THE BENCH") : "LINE CHANGE - LINE " + istr(T.li + 1), "#93c5fd");
  return true;
}
// the CPU skates you to the bench gate
Want skBenchSteer(Skater *p) {
  BenchSpot B = skBench(); double dx = B.x - p->x, dy = B.y - p->y, d = hyp(dx, dy); if (d < .01) return Want();
  double v = skMaxSpd(p) * clamp(d / 6, .35, .9); Want w; w.vx = dx / d * v; w.vy = dy / d * v; return w;
}
// Be a Pro: TRIANGLE on the bench skips ahead to your next shift. The time is played out by the numbers (the lines on
// the ice, the goalies), you come back out fresh, and play restarts with a faceoff
void skSimShift() {
  if (!SK->uBench || SK->phase != PH_PLAY) return;
  Team &T0 = SK->T[0], &T1 = SK->T[1]; Puck &P = SK->puck; Skater *U = SK->user;
  if (!T0.box.empty() || !T1.box.empty()) { pushFeed("WAIT FOR THE PENALTY TO END", "#ffb300"); return; }
  int ul = SK->uLine; double need = std::max(0.0, skShiftLen(T0.li) - T0.lineT); for (int l = (T0.li + 1) % 3; l != ul; l = (l + 1) % 3) need += skShiftLen(l);
  double t = std::min(std::max(6.0, need), SK->clock);
  auto ovOn = [](Team &T) { double a = 0; int n = 0; for (Skater *q : T.on) if (q->src) { a += ovSk(q->src); n++; } return n ? a / n : 75.0; };
  auto gq = [](Goalie &g) { return (g.gs.agi + g.gs.glv + g.gs.blk + g.gs.pad + g.gs.chs) / 5; };
  double edge = (ovOn(T0) - ovOn(T1)) * .035 + (gq(T0.g) - gq(T1.g)) * .012, m0 = std::exp(edge), m1 = std::exp(-edge);
  int a = poisson(.0078 * t * m0), b = poisson(.0078 * t * m1);
  if (SK->per > 3 && a + b > 0) { if (rnd() < (double)a / (a + b)) { a = 1; b = 0; } else { a = 0; b = 1; } SK->endAfter = true; }
  auto credit = [](Team &T) { std::vector<Skater *> v; for (Skater *q : T.on) if (!q->user) v.push_back(q); if (v.empty()) return;
    Skater *sc = v[(size_t)std::floor(rnd() * v.size())], *as = nullptr; if (v.size() > 1 && rnd() < .85) { do { as = v[(size_t)std::floor(rnd() * v.size())]; } while (as == sc); } proCredit(sc, as); };
  for (int i = 0; i < a; i++) { T0.score++; T0.sog++; credit(T0); } for (int i = 0; i < b; i++) { T1.score++; T1.sog++; credit(T1); }
  { int s0 = poisson(.061 * t * m0), s1 = poisson(.061 * t * m1); T0.sog += s0; T1.sog += s1; int k = std::min(SK->per, 4) - 1; SK->pg[0][k] += a; SK->pg[1][k] += b; SK->ps[0][k] += a + s0; SK->ps[1][k] += b + s1; }
  SK->clock -= t; SK->gt += t; U->st = 100; U->tired = false;
  P.owner = nullptr; P.hasShot = false; P.passTo = nullptr; P.vx = P.vy = 0; P.x = RK.L / 2; P.y = RK.cy;
  T0.li = (ul + 2) % 3; skChangeLine(0, false); if (T1.lines.size() >= 2) skChangeLine(1, false);
  pushFeed("SIMMED " + mmss(t) + (a || b ? "  |  " + istr(a) + "-" + istr(b) + " WHILE YOU SAT" : "  |  NO SCORING"), a > b ? "#7CFC9A" : b > a ? "#ff7a7a" : "#cbd5e1");
  if (SK->clock <= 0) { SK->clock = 0; skPeriodEnd(); return; }
  SK->phase = PH_STOP; SK->stopT = .05; SK->hasNextFo = true; SK->nextFo = {RK.L / 2, RK.cy};
}
bool skBenchOpen() {
  Skater *u = SK ? SK->user : nullptr; if (!u) return false; Team &T = SK->T[0];
  return SK->phase == PH_PLAY && onTeam(0, u) && T.lines.size() >= 2 && T.box.empty() && !T.pulled && (u->st < 40 || u->tired) && !(SK->benchCd > SK->gt);
}
void skBenchCheck() {
  Skater *u = SK->user; if (!u) return;
  if (!(skBenchOpen() || (SK->benchRun && SK->phase == PH_PLAY && onTeam(0, u)))) return; BenchSpot B = skBench(); if (hyp(u->x - B.x, u->y - B.y) > B.r || SK->puck.owner == u) return;
  Team &T = SK->T[0]; int nx = skProBench() ? (SK->uLine + 1) % 3 : skNextLine(T, true); if (nx < 0) { SK->benchRun = false; return; }
  T.li = (nx + T.lines.size() - 1) % T.lines.size();
  if (skChangeLine(0, true)) { SK->benchCd = SK->gt + 6; SK->lineNote = {3, T.li}; sfx(S_PASS, .4, .7); }
  SK->benchRun = false;
}
// every stoppage: the CPU changes lines after a long shift; then the FACEOFF transition
void skToFaceoff(const std::string &name, Col col, const std::string &sub) {
  SK->benchRun = false;
  if (name != "FINAL") for (int ti = 0; ti < 2; ti++) { Team &T = SK->T[ti];
    if (T.lines.size() < 2 || !T.box.empty() || T.pulled) continue;
    if (ti == 0 && skProBench()) {   // Be a Pro: a long shift ends at the whistle; you come off if you're spent
      bool chg = SK->uBench ? T.lineT > skShiftLen(T.li) * .6 : (SK->user->st < 35 || SK->user->tired || T.lineT > skShiftLen(T.li) * 1.6);   // (the coach shortens a lower line's shifts)
      if (chg && skChangeLine(0, false)) SK->lineNote = {3, T.li}; else for (Skater *p : T.on) p->st = std::min(100.0, p->st + 5); continue; }
    double cur = skLineRest(T, T.li);
    if (cur < 72 || T.lineT > 45) { int nx = skNextLine(T, false);
      if (nx >= 0) { T.li = (nx + T.lines.size() - 1) % T.lines.size(); if (skChangeLine(ti, false) && ti == 0) SK->lineNote = {3, T.li}; } }
    else for (Skater *p : T.on) p->st = std::min(100.0, p->st + 5); }
  SK->phase = PH_TRANS; goMode(name, [] { if (SK && SK->phase == PH_TRANS) skResume(); }, col, true, sub);
}

// ---------------------------------------------------------------- the end
void skEnd() {
  RS.valid = true; RS.hn = SK->T[0].name; RS.an = SK->T[1].name; RS.hs = SK->T[0].score; RS.as = SK->T[1].score; RS.hsh = SK->T[0].sog; RS.ash = SK->T[1].sog; RS.f = SK->me;
  afterGame(SK->T[0].score > SK->T[1].score, false);
  delete SK; SK = nullptr; feed.clear();
}
// Be a Pro: quit a game and the rest of it is simulated - mostly by the score and the time left, then the rosters'
// overalls, the goalies and how hot each team is. What your player does in the sim is worth half the XP.
std::string g_simNote;
static void skSimRest() {
  Team &T0 = SK->T[0], &T1 = SK->T[1]; double tot = 3 * SK_PER, left = SK->phase == PH_PREVIEW || SK->phase == PH_INTRO ? 1 : SK->per > 3 ? 0 : clamp(((3 - SK->per) * SK_PER + SK->clock) / tot, 0, 1);
  auto ovT = [](Team &T) { std::set<const Src *> S; for (Skater *q : T.on) if (q->src) S.insert(q->src); for (auto &L : T.lines) for (Src *q : L) if (q) S.insert(q);
    double a = 0; int n = 0; for (const Src *q : S) { a += ovSk(q); n++; } return n ? a / n : 70.0; };
  auto gq = [](Goalie &g) { return (g.gs.agi + g.gs.glv + g.gs.blk + g.gs.pad + g.gs.chs) / 5; };
  auto hot = [](int ti) { if (!CR || CR->hist.empty()) return 1.0; int n = 0, w = 0; for (int i = (int)CR->hist.size() - 1; i >= 0 && n < 5; i--, n++) w += CR->hist[i].w; double f = (double)w / n; return ti == 0 ? .9 + f * .2 : 1.1 - f * .2; };
  double edge = (ovT(T0) - ovT(T1)) * .035 + (gq(T0.g) - gq(T1.g)) * .012, m0 = std::exp(edge) * hot(0), m1 = std::exp(-edge) * hot(1);
  int a = poisson(2.8 * left * m0), b = poisson(2.8 * left * m1);
  int sa0 = a + poisson(22 * left * m0), sb0 = b + poisson(22 * left * m1); T0.score += a; T1.score += b; T0.sog += sa0; T1.sog += sb0;
  { int p0 = std::min(SK->per, 3) - 1; double w[3] = {0, 0, 0}, tw = 0; for (int k = p0; k < 3; k++) { w[k] = k == p0 && SK->phase != PH_PREVIEW && SK->phase != PH_INTRO ? SK->clock / SK_PER : 1; tw += w[k]; }   // the simmed rest, spread over the periods left
    auto pick = [&] { double r = rnd() * tw; for (int k = p0; k < 3; k++) { r -= w[k]; if (r <= 0) return k; } return 2; };
    if (SK->per <= 3 && tw > 0) { for (int i = 0; i < a; i++) SK->pg[0][pick()]++; for (int i = 0; i < b; i++) SK->pg[1][pick()]++; for (int i = 0; i < sa0; i++) SK->ps[0][pick()]++; for (int i = 0; i < sb0; i++) SK->ps[1][pick()]++; } }
  bool ot = false; if (T0.score == T1.score) { ot = true; int w = rnd() < m0 / (m0 + m1) ? 0 : 1; SK->T[w].score++; SK->pg[w][3]++; SK->ps[w][3]++; SK->T[w].sog++; SK->per = std::max(SK->per, 4); }
  int ug = 0, ua = 0; double pg, pa; proUserShare(pg, pa);
  for (int i = 0; i < a; i++) { if (rnd() < pg) ug++; else if (rnd() < pa) ua++; }
  SK->me.g += ug; SK->me.a += ua; SK->me.sog += ug + poisson(2.2 * left); award((int)jround((ug * 30 + ua * 10) / 2.0));
  if (CR && CR->phase == "reg") { PP *u = youMe(); if (u) { u->gl += ug; u->as += ua; } }
  g_simNote = left >= .99 ? "GAME SIMULATED" : "SIMMED THE LAST " + mmss(left * tot) + (ot ? " (+OT)" : "") + (ug || ua ? "  YOU " + istr(ug) + "G " + istr(ua) + "A" : "");
  skEnd();
}
void skQuit() { RS.valid = false; paused = false;
  if (SK && mode == "pro" && CR && CR->phase != "over" && CR->phase != "retired") { skSimRest(); return; }
  if (SK) afterGame(false, true); delete SK; SK = nullptr; feed.clear(); }

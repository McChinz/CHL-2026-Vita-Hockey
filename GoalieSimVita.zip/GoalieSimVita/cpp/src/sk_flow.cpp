// CHL 2026 native - forward game engine, part 3: the main update, the puck, goals and celebrations, whistles,
// board battles, line changes, periods / overtime / shootout and the end of the game.
#include "game.h"
#include "sk_int.h"
#include "menu.h"

void skGoal(int team);
void skIcing(int t);
void skPeriodEnd();
void skToFaceoff(const std::string &name, Col col, const std::string &sub);
void skBattleStart(Skater *a, Skater *b);
void skBattleUpdate(double dt, const Input &I);
void skBenchCheck();
void skNetPuck(double dt);
void skCeleb(double dt);
void skBottleUpdate(double dt);
void skScratch(double dt);
static void skPuck(double dt);
double fqSl(const Src *q);

void skPuckJolt(double sp, double k) { Puck &P = SK->puck; double q = clamp(sp / 60, 0, 1.2); if (q < .15) return; P.bvz = std::max(P.bvz, q * rand(3, 7.5) * k); P.wob = std::max(P.wob, .45 + .55 * std::min(1.0, q)); }

// ---------------------------------------------------------------- the main update
void skUpdate(double dt, const Pad &pad, uint32_t press) {
  if (!SK) return;
  (void)pad; (void)press;
  dt = std::min(dt, .05);
  skTouchFrame();
  if (SK->shk > 0) SK->shk = std::max(0.0, SK->shk - dt * 3.4);
  if (SK->hitFl > 0) SK->hitFl -= dt;
  if (!SK->gls.empty()) { for (auto &q : SK->gls) q.t += dt; if (SK->gls[0].t > 1.5) SK->gls.erase(SK->gls.begin()); }
  if (SK->hstop > 0) { SK->hstop -= dt; if (SK->phase == PH_PLAY) return; }
  for (auto &f : feed) f.t += dt; while (!feed.empty() && feed[0].t > 2.6) feed.erase(feed.begin());
  if (SK->banner.t > 0) SK->banner.t -= dt;
  skRefUpdate(dt);
  for (auto &e : SK->fx) e.t += dt; SK->fx.erase(std::remove_if(SK->fx.begin(), SK->fx.end(), [](const HitFx &e) { return e.t >= .5; }), SK->fx.end());
  if (skHint > 0 && SK->phase == PH_PLAY) skHint -= dt;
  Puck &P = SK->puck; std::vector<Skater *> all = skAll();
  // camera
  Layout lay = skLayout();
  { double svx = P.owner ? P.owner->vx : P.vx, svy = P.owner ? P.owner->vy : P.vy, lk = std::min(1.0, dt * 2.5);
    SK->lx += (svx * (P.owner ? .55 : .2) - SK->lx) * lk; SK->ly += (svy * (P.owner ? .55 : .2) - SK->ly) * lk; }
  Pt tg = skCamClamp(lay, P.x + SK->lx, P.y + SK->ly);
  if (SK->phase == PH_INTRO) { Pt f{0, 0}; if (SK->user) f = {SK->user->x, SK->user->y}; else { for (Skater *q : SK->T[0].on) { f.x += q->x; f.y += q->y; } f.x /= SK->T[0].on.size(); f.y /= SK->T[0].on.size(); } tg = skCamClamp(lay, f.x, f.y); }
  { double k = std::min(1.0, dt * 3.5); SK->cam += (tg.x - SK->cam) * k; SK->camY += (tg.y - SK->camY) * k; }
  if (SK->phase == PH_FACEOFF) {
    Faceoff &F = SK->fo; F.t += dt;
    auto cOf = [](Team &t) { for (Skater *q : t.on) if (q->role == R_C) return q; return t.on.empty() ? (Skater *)nullptr : t.on[0]; };
    Skater *c0 = cOf(SK->T[0]), *c1 = cOf(SK->T[1]); double drop = F.show + F.close;
    bool mine = c0 == SK->user && c0 && c0->user && !g_autoplay;
    int w = -1; Input I;
    if (!mine) SK->tap = false;
    if (mine) {
      I = skInput(); if (F.t < F.show + .08) I.pass = false;
      double win = skFoWindow(c0);
      if (I.pass) { double e = F.t - drop;
        if (std::fabs(e) <= win) { w = 0; F.res = std::fabs(e) < win * .35 ? "PERFECT DRAW" : "FACEOFF WON"; }
        else { w = 1; F.res = e < 0 ? "TOO EARLY" : "TOO LATE"; } }
      else if (F.t > drop + win) { w = 1; F.res = "TOO LATE"; }
      if (w >= 0) { bool ok = w == 0; pushFeed(F.res, ok ? "#7CFC9A" : "#ff7a7a"); SK->me.fow += ok ? 1 : 0; SK->me.fot++; }
    } else if (F.t >= std::min(drop, 1.0) && c0 && c1) {
      w = rnd() < clamp(.5 + (c0->at.fo - c1->at.fo) * .06, .15, .85) ? 0 : 1;
    }
    if (w >= 0) {
      SK->T[w].fow++;
      std::vector<Skater *> wg; for (Skater *q : SK->T[w].on) if (q != cOf(SK->T[w])) wg.push_back(q);
      Skater *back = !wg.empty() ? wg[(int)std::floor(rnd() * wg.size())] : SK->T[w].on[0];
      if (w == 0 && mine && hyp(I.mx, I.my) > .3 && !wg.empty()) {
        double bs = -1e9; for (Skater *b : wg) { double v = ((b->x - P.x) * I.mx + (b->y - P.y) * I.my) / std::max(1e-6, hyp(b->x - P.x, b->y - P.y)); if (v > bs) { bs = v; back = b; } } }
      double bx = back->x - P.x, by = back->y - P.y, bd = hyp(bx, by); if (!bd) bd = 1;
      c0->cool = .55; c1->cool = .55; P.x += bx / bd * 2; P.y += by / bd * 2;
      P.vx = bx / bd * 34; P.vy = by / bd * 34; P.passTo = back; P.last = cOf(SK->T[w]); P.lastPasser = P.last; P.passT = now(); P.pl = false; P.id++;
      SK->phase = PH_PLAY;
    }
    return;
  }
  if (SK->phase == PH_PREVIEW) { SK->pv.t += dt; if ((SK->pv.t > .7 && ((g_press & B_CROSS) || SK->tap)) || SK->pv.t > 9 || g_autoplay) { SK->tap = false; skIntroBegin(); } else SK->tap = false; return; }
  if (SK->phase == PH_INTRO) { skIntroTick(dt); return; }
  if (SK->lineNote.t > 0) SK->lineNote.t -= dt;
  if (SK->phase == PH_HOLD) { SK->gt += dt; skHoldUpdate(dt); return; }
  if (SK->phase == PH_STOP || SK->phase == PH_GOAL) {
    SK->stopT -= dt;
    if (SK->phase == PH_GOAL) { SK->goalT += dt; skNetPuck(dt); skCeleb(dt); skBottleUpdate(dt); }
    else for (Skater *p : all) { p->vx *= .9; p->vy *= .9; p->x += p->vx * dt; p->y += p->vy * dt; skBoardsP(p, 1.3, .2); }
    if (SK->stopT <= 0) {
      if (SK->phase == PH_GOAL) {
        Team &T0 = SK->T[0], &T1 = SK->T[1]; Celeb &cl = SK->cel; SK->phase = PH_TRANS;
        std::string sub = upper(T0.name) + "  " + istr(T0.score) + "  -  " + istr(T1.score) + "  " + upper(T1.name);
        if (cl.sc) sub += "   |   " + upper(cl.sc->nm) + (cl.as ? " (A: " + upper(cl.as->nm) + ")" : "");
        if (trActive()) skResume(); else skToFaceoff(SK->endAfter ? "FINAL" : "FACEOFF", SK->T[cl.team].col, sub);
        return;
      }
      if (!trActive() && !SK->endAfter) {
        Team &T0 = SK->T[0], &T1 = SK->T[1]; SK->phase = PH_TRANS;
        std::string sub = SK->nextPer ? (SK->per >= 3 ? std::string("OVERTIME") : std::string(SK->per == 1 ? "2ND" : "3RD") + " PERIOD")
          : upper(T0.name) + "  " + istr(T0.score) + "  -  " + istr(T1.score) + "  " + upper(T1.name);
        skToFaceoff("FACEOFF", hex("#38bdf8"), sub); return; }
      skResume();
    }
    return;
  }
  if (SK->phase == PH_TRANS) return;
  // clock
  SK->clock -= dt; if (SK->clock <= 0) { SK->clock = 0; skPeriodEnd(); return; }
  SK->callPass = std::max(0.0, SK->callPass - dt);
  skCallsUpdate(dt);
  skBoxTick(dt);
  for (int t = 0; t < 2; t++) if (skShort(1 - t)) SK->T[t].ppt += dt;
  { Skater *o = P.owner; if (o && (P.x - RK.L / 2) * tdir(o->team) > 0) SK->T[o->team].toa += dt; }
  for (auto &T : SK->T) T.lineT += dt;
  Input I = skInput();
  SK->gt += dt;
  if (SK->phase == PH_PLAY) { skScratch(dt); skSprayUpd(dt); }
  if (SK->per == 3 && (SK->pullT -= dt) <= 0) { SK->pullT = .5;
    for (int ti = 0; ti < 2; ti++) { Team &t = SK->T[ti]; Skater *o = P.owner; if (!t.pulled && o && o->team == ti && (P.x - RK.L / 2) * tdir(ti) > 0 && skWantPull(ti) && t.box.empty()) skCheckPull(ti); } }
  if (SK->user && !onTeam(0, SK->user)) { SK->user->sprint = false; SK->user->st = std::min(100.0, SK->user->st + 6 * dt); }   // resting in the box
  skBattleUpdate(dt, I);
  all = skAll();
  for (Skater *p : all) {
    if (SK->hasBat && (p == SK->bat.a || p == SK->bat.b)) { p->vx = p->vy = 0; p->ph += dt * 3; p->stun = std::max(0.0, p->stun - dt); continue; }
    if (p->folT > 0) p->folT -= dt;
    if (p->pkF > 0) p->pkF -= dt; if (p->chopT > 0) p->chopT -= dt; if (p->pkL.t > 0) p->pkL.t -= dt;
    if (p->hasDk || p->dkLat) skDekeUpdate(p, dt);
    p->stun = std::max(0.0, p->stun - dt); if (p->stun <= 0) p->kd = false; p->cool = std::max(0.0, p->cool - dt); p->dcd = std::max(0.0, p->dcd - dt); p->poke = std::max(0.0, p->poke - dt);
    p->pokeA = std::max(0.0, p->pokeA - dt); p->spin = std::max(0.0, p->spin - dt); p->spinCd = std::max(0.0, p->spinCd - dt); p->block = std::max(0.0, p->block - dt);
    p->dash = std::max(0.0, p->dash - dt);
    Want want;
    if (p->stun <= 0 && !(p->block > 0)) want = (p->user && !g_autoplay) ? skUserControl(p, I, dt) : skAI(p, dt);
    if (want.glide) { double cs0 = hyp(p->vx, p->vy), dec = 4 * dt; if (cs0 > dec) { p->vx -= p->vx / cs0 * dec; p->vy -= p->vy / cs0 * dec; } else p->vx = p->vy = 0; want = {p->vx, p->vy, false}; }
    { double k = skStam(p, (p->user && !g_autoplay) ? I.sprint : p->wantSprint, hyp(want.vx, want.vy) > 4, dt); want.vx *= k; want.vy *= k; }
    if (p->hs > 0) { p->hs -= dt; double skl = clamp((p->at.agl - 3.5) / 6.5, 0, 1), k = std::exp(-dt * (2.6 + skl * 10)); p->vx *= k; p->vy *= k; p->hb = .55; if (p->hs <= 0) p->hs = 0; }
    else if (p->hb > 0) p->hb -= dt;
    double wm = hyp(want.vx, want.vy), cs = hyp(p->vx, p->vy);
    if (p->dash <= 0 && wm < 1) {
      double dec = (p->block > 0 ? 34 : p->user ? 5 : 8) * dt; if (cs > dec) { p->vx -= p->vx / cs * dec; p->vy -= p->vy / cs * dec; } else { p->vx = p->vy = 0; }
    } else {
      double turn = cs > 4 && wm > 1 ? (p->vx * want.vx + p->vy * want.vy) / (cs * wm) : 1, sk = clamp((p->at.agl - 3.5) / 6.5, 0, 1);
      double hard = turn < .6 ? clamp((.6 - turn) / 1.6, 0, 1) * clamp((cs - 6) / 22, 0, 1) : 0; p->turnHard = hard > .2;
      double acc = (p->dash > 0 ? 140 : (p->user ? 33 + sk * 24 : 38 + sk * 24) * (p->hb > 0 ? 1.35 + sk * .9 : 1 - hard * (p->user ? .72 - .4 * sk : .5 - .3 * sk))) * dt;
      double dvx = want.vx - p->vx, dvy = want.vy - p->vy, dm = hyp(dvx, dvy);
      if (p->dash > 0 || cs < 3) { if (dm > acc) { p->vx += dvx / dm * acc; p->vy += dvy / dm * acc; } else { p->vx = want.vx; p->vy = want.vy; } }
      else {
        double ux = p->vx / cs, uy = p->vy / cs, al = dvx * ux + dvy * uy, pe = -dvx * uy + dvy * ux, m = hyp(al, pe);
        if (m > acc) { al *= acc / m; pe *= acc / m; }
        double grip = 1 - .42 * clamp((cs - 8) / 24, 0, 1) * (1 - sk * .45); pe *= grip;
        p->vx += al * ux - pe * uy; p->vy += al * uy + pe * ux;
      }
    }
    p->x += p->vx * dt; p->y += p->vy * dt;
    { double v0 = hyp(p->vx, p->vy); if (skBoardsP(p, 1.3, .15) && v0 > 10 && SK->gt - p->hitT < .8) { skGlassHit(p->x, p->y, clamp(v0 / 28, .3, 1)); p->hitT = -9; } }
    skNetBox(p->x, p->y, p->vx, p->vy, 1.3, .1, false);
    double sp = hyp(p->vx, p->vy);
    if (sp > 2) { p->ang = wrapA(p->ang); double da = wrapA(std::atan2(p->vy, p->vx) - p->ang); p->ang += da * std::min(1.0, dt * 6.5); }
    p->ph += sp * dt * .45;
    if (p->dash > 0) for (Skater *o : SK->T[1 - p->team].on) { if (o->stun <= 0 && hyp(o->x - p->x, o->y - p->y) < 3.2) { skHit(p, o); p->dash = 0; p->vx *= .4; p->vy *= .4; break; } }
    if (SK->phase != PH_PLAY) break;   // a hit that stopped play (knockout, penalty): the rest of the frame waits
  }
  all = skAll();
  for (size_t i = 0; i < all.size(); i++) for (size_t j = i + 1; j < all.size(); j++) {
    Skater *a = all[i], *b = all[j]; double dx = b->x - a->x, dy = b->y - a->y, d = hyp(dx, dy);
    if (d < 3.3 && d > 0) { double push = (3.3 - d) / 2 * std::min(1.0, dt * 20), nx = dx / d, ny = dy / d; a->x -= nx * push; a->y -= ny * push; b->x += nx * push; b->y += ny * push; }
  }
  skBenchCheck();
  for (auto &t : SK->T) { Goalie &g = t.g; if (g.pkF > 0) g.pkF -= dt; if (g.pkL.t > 0) g.pkL.t -= dt; skGoalie(g, dt); }
  if (SK->phase == PH_PLAY) skPuck(dt);
}

// ---- skate scratches: each stride carves a short mark; hard stops spray a wider one (cleaned every faceoff)
static double skU = 0, skT2 = 0;
void skScratch(double dt) {
  auto &S = SK->scr;
  for (int ti = 0; ti < 2; ti++) for (Skater *p : SK->T[ti].on) {
    double sp = hyp(p->vx, p->vy); if (!p->scrInit) { p->scrInit = true; p->sx = p->x; p->sy = p->y; p->sv = sp; p->sf = 1; }
    double dx = p->x - p->sx, dy = p->y - p->sy, d = hyp(dx, dy), dec = (p->sv - sp) / std::max(dt, 1e-3); p->sv = sp;
    if (dec > 55 && sp > 3 && !(p->stopT > 0)) { p->stopT = .35;
      { double v = sp + dec * dt; if (v > 12 && !(p->dash > 0) && !(p->stun > 0) && SK->gt - p->hitT > .5) { skSpray(p, v); sfx(S_STOP, sndAt(p->x, p->y) * std::min(1.0, v / 30) * (p->user ? 1 : .75), rand(.93, 1.07)); } }
      double a = std::atan2(p->vy, p->vx) + PI / 2;
      S.cur.push_back({(float)(p->x - std::cos(a) * 1.2), (float)(p->y - std::sin(a) * 1.2), (float)(p->x + std::cos(a) * 1.2), (float)(p->y + std::sin(a) * 1.2), .32f, .5f}); }
    if (p->stopT > 0) p->stopT = std::max(0.0, p->stopT - dt);
    if (d > 2.4) {
      { double sv = sndAt(p->x, p->y), nw = now() / 1000; if (sp > 7 && (p->user ? nw - skU > .05 : sv > .5 && nw - skT2 > .17)) { if (p->user) skU = nw; else skT2 = nw; sfx(S_SKATE, sv * (p->user ? .9 : .5) * std::min(1.0, .35 + sp / 40), rand(.9, 1.12)); } }
      if (sp > 7) { p->sf = -p->sf; double nx = -dy / d * .32 * p->sf, ny = dx / d * .32 * p->sf;
        S.cur.push_back({(float)(p->sx + nx), (float)(p->sy + ny), (float)(p->x + nx * 1.4), (float)(p->y + ny * 1.4), (float)(.11 + std::min(.07, sp * .002)), (float)(.22 + std::min(.14, sp * .003))}); }
      p->sx = p->x; p->sy = p->y; }
  }
  if (S.cur.size() >= 12) { S.b.push_back({++S.id, S.cur}); S.cur.clear(); if (S.b.size() > 30) S.b.erase(S.b.begin()); }
}

// ---------------------------------------------------------------- the puck
static void skPuckBounce(double dt) {
  Puck &P = SK->puck;
  if (P.bvz || P.bz > 0) { P.bvz -= PG * dt; P.bz += P.bvz * dt;
    if (P.bz <= 0) { P.bz = 0; double v = -P.bvz; if (v > 2.6) { P.bvz = v * .38; P.wob = std::max(P.wob, std::min(1.0, .35 + v * .05)); P.hop = .45; P.hopN++;
        if (v > 5 && !(P.roll > 0) && rnd() < .22) P.roll = rand(.8, 1.5); double sp = hyp(P.vx, P.vy); if (sp > 1) { double k = 1 - std::min(.25, v * .012); P.vx *= k; P.vy *= k; } } else P.bvz = 0; } }
  if (P.hop > 0) P.hop -= dt;
  if (P.roll > 0) { P.roll -= dt; double sp = hyp(P.vx, P.vy); if (sp > 3) { double sg = sgn(std::sin((P.id ? P.id : 1) * 7.1)); double c = .9 * dt * (sg ? sg : 1), cs = std::cos(c), sn = std::sin(c), vx = P.vx; P.vx = vx * cs - P.vy * sn; P.vy = vx * sn + P.vy * cs; } else P.roll = 0; }
  if (P.wob > 0) { P.wob = std::max(0.0, P.wob - dt * .85); double sp = hyp(P.vx, P.vy);
    if (sp > 4) { double w = std::sin(SK->gt * 13 + P.id) * P.wob * sp * .32 * dt; P.vx += -P.vy / sp * w; P.vy += P.vx / sp * w; P.vx *= 1 - .18 * P.wob * dt; P.vy *= 1 - .18 * P.wob * dt; } }
}
static void skRedirect(Puck &P, int team, double spd, double errDeg, Skater *by, bool tip, Skater *from) {
  double a = attackX(team), ty = RK.cy + rand(-2.3, 2.3), ang = std::atan2(ty - P.y, a - P.x) + errDeg * PI / 180 * (rnd() + rnd() - 1) * 1.4;
  P.vx = std::cos(ang) * spd; P.vy = std::sin(ang) * spd; P.owner = nullptr; P.passTo = nullptr; P.saucer = false; P.pl = false; P.id++;
  P.hasShot = true; P.shot = Shot(); P.shot.team = team; P.shot.by = by; P.shot.spd = spd; P.shot.h = rnd(); P.shot.kind = SH_WRIST; P.shot.tip = tip; P.shot.defl = !tip;
  if (tip) { P.lastPasser = from; P.passT = now(); P.last = by; SK->T[team].shots++; if (by->user) SK->me.shots++; }
  P.clearTips();
}
static void skPuck(double dt) {
  if (SK->hasBat) return;
  std::vector<Skater *> AL = skAll(); Puck &P = SK->puck;
  if (P.owner) { P.bz = 0; P.bvz = 0; P.wob = 0;
    Skater *o = P.owner; double dl = o->dkLat, sw = std::sin(o->ph * 2.2) * .5 * (dl ? .3 : 1) + dl, fw = 2.2 + o->dkF;
    P.x = o->x + std::cos(o->ang) * fw - std::sin(o->ang) * sw; P.y = o->y + std::sin(o->ang) * fw + std::cos(o->ang) * sw; P.vx = o->vx; P.vy = o->vy;
    return; }
  skPuckBounce(dt);
  int steps = std::max(1, (int)std::ceil(hyp(P.vx, P.vy) * dt / 1.2)); double h = dt / steps;
  for (int s = 0; s < steps; s++) {
    double px = P.x;
    if (P.mag) { if (P.passTo && !P.hasShot) { Pt st = stickPt(P.passTo); double dx = st.x - P.x, dy = st.y - P.y, dd = hyp(dx, dy);
        if (dd > .4) { double sp = hyp(P.vx, P.vy), k = std::min(1.0, h * P.mag); P.vx += (dx / dd * sp - P.vx) * k; P.vy += (dy / dd * sp - P.vy) * k; } } else P.mag = 0; }
    P.x += P.vx * h; P.y += P.vy * h;
    if (P.hasShot) P.shot.t += h;
    bool over = P.bz > PZ + .3;
    if (!over && skGoalieSave(SK->T[0].g)) return;
    if (!over && skGoalieSave(SK->T[1].g)) return;
    for (int ti = 0; ti < 2; ti++) {
      double gx = defendX(ti), d = tdir(ti);
      if ((px - gx) * d > 0 && (P.x - gx) * d <= 0) {
        double off = std::fabs(P.y - RK.cy);
        if (over && off < RK.post + .6) { if (P.hasShot && P.shot.by && P.shot.by->user) pushFeed("OVER THE NET", "#94a3b8"); continue; }
        if (off < RK.post - .25) { skGoal(1 - ti); return; }
        if (off < RK.post + .4) { sfx(S_POST, sndAt(P.x, P.y) * std::min(1.0, .45 + hyp(P.vx, P.vy) / 120), rand(.97, 1.03)); skPuckJolt(hyp(P.vx, P.vy), 1.4); P.vx = -P.vx * .6; P.x = gx + d * .3; pushFeed("POST!", "#ffb300"); skShake(.38); }
        else if (P.ice == 1 - ti && !skShort(1 - ti)) { skIcing(1 - ti); return; }
      }
    }
    { double sp0 = hyp(P.vx, P.vy); bool b1 = skBoardsPuck(.4, .55); bool b2 = over ? false : skNetBox(P.x, P.y, P.vx, P.vy, .4, .4, true); if (b1 || b2) { if (P.hasShot) P.shot.gnd = true; skPuckJolt(sp0, .8); } }
    double spd = hyp(P.vx, P.vy);
    if (spd < 48) { Skater *mp = nullptr; double md = 1e9; Pt ms{0, 0};
      for (Skater *p : AL) { if (p->stun > 0 || p->cool > 0 || (P.hasShot && P.shot.by == p && P.shot.t < .3)) continue; Pt st = stickPt(p); double dd = hyp(st.x - P.x, st.y - P.y); if (dd < md) { md = dd; mp = p; ms = st; } }
      if (mp) { double R = 2.4 + mp->at.hand * .18; if (md < R && md > .05) { double a = (10 + mp->at.hand * 3) * (1 - md / R) * h; P.vx += (ms.x - P.x) / md * a; P.vy += (ms.y - P.y) / md * a; } } }
    for (Skater *p : AL) {
      int k = alIndex(AL, p);
      if (p->block > 0) {
        if (p->block > .2 && ((P.hasShot && P.shot.team != p->team) || (P.pl && P.lastPasser && P.lastPasser->team != p->team))) {
          double ax = std::cos(p->blkA), ay = std::sin(p->blkA), rx = P.x - p->x, ry = P.y - p->y, along = rx * ax + ry * ay, across = -rx * ay + ry * ax; long kk = (long)P.id * 100 + k;
          if (std::fabs(along) < 3.1 && std::fabs(across) < 1.1 && P.lbk != kk) { P.lbk = kk;
            if (rnd() < (P.hasShot && P.shot.team == 0 ? SKD().blk : .25)) { skPuckJolt(hyp(P.vx, P.vy), 1.2); P.vx = -P.vx * .12 + rand(-6, 6); P.vy = -P.vy * .12 + rand(-6, 6); bool wasShot = P.hasShot; P.hasShot = false; P.passTo = nullptr; P.pl = false; P.ice = -1;
              if (p->user) pushFeed(wasShot ? "SHOT BLOCKED" : "PASS BLOCKED", "#7CFC9A"); else if (p->team == 1 && wasShot && P.last && P.last->user) pushFeed("BLOCKED", "#ff7a7a"); break; } } }
        continue;
      }
      if (p->stun > 0 || p->cool > 0) continue;
      Pt st = stickPt(p); double dd = hyp(st.x - P.x, st.y - P.y), bd = hyp(p->x - P.x, p->y - P.y);
      if (P.saucer && P.passTo && p != P.passTo && hyp(P.x - P.passTo->x, P.y - P.passTo->y) > 5) continue;
      if (P.hasShot && P.shot.team != p->team && bd < 1.3 && spd > 40 && P.blk != (long)P.id * 100 + k) { P.blk = (long)P.id * 100 + k;
        if (rnd() < (P.shot.team == 0 ? SKD().blk : .3)) {
          Skater *sh = P.shot.by;
          if (sh && rnd() < clamp(.06 + (sh->at.wacc + sh->at.wpow - 7) * .01, .06, .2)) { skRedirect(P, sh->team, spd * .7, 6, sh, false, nullptr); if (sh->team == 0) pushFeed("DEFLECTED!", "#ffd54a"); break; }
          P.vx = -P.vx * .25 + rand(-10, 10); P.vy = P.vy * .3 + rand(-10, 10); P.hasShot = false; if (p->user) pushFeed("BLOCKED SHOT", "#7CFC9A"); break; } }
      if (P.hasShot && P.shot.team != p->team && spd > 25 && dd < 2.4) {
        if (P.sthId != P.id) { P.sthId = P.id; memset(P.sth, -1, sizeof P.sth); }
        if (k < 16 && P.sth[k] < 0) P.sth[k] = rnd() < (P.shot.team == 0 ? (P.shot.kind == SH_SLAP ? SKD().thruS : SKD().thru) : .4) ? 1 : 0;
        if (k < 16 && P.sth[k] == 1) continue;
      }
      double r0 = (P.passTo == p ? 2.8 : 1.9) + p->at.hand * .05;
      if (P.pl && P.lastPasser && p->team != P.lastPasser->team && dd < r0 && k < 16) {
        if (P.thru[k] < 0) { P.thru[k] = rnd() < clamp((P.lastPasser->team == 0 ? .17 : .1) + (P.lastPasser->at.pass - 3.5) * .03, .1, .38) + P.pp * .3 ? 1 : 0; if (P.thru[k] && P.lastPasser->team == 0) pushFeed("THREADED IT THROUGH", "#93c5fd"); }
        if (P.thru[k] > 0) { if (P.thru[k] == 1 && bd < 1.3 && P.bz < .4 && rnd() < .22) { P.thru[k] = 2; double a = std::atan2(P.vy, P.vx) + rand(-.45, .45), v = hyp(P.vx, P.vy) * .7; P.vx = std::cos(a) * v; P.vy = std::sin(a) * v; P.passTo = nullptr; P.wob = std::max(P.wob, .5);
            if (P.lastPasser && P.lastPasser->team == 0) pushFeed("OFF THE SKATE", "#94a3b8"); } continue; }
      }
      if (dd < 2 && P.last && P.last->team == p->team && P.last != p && ((P.hasShot && P.shot.team == p->team) || (P.pl && P.passTo == p))) {
        double a = attackX(p->team), dn = hyp(a - p->x, RK.cy - p->y); bool front = (a - p->x) * tdir(p->team) > 2;
        if (front && dn < 22 && P.tipOn && k < 16 && P.tipT[k] < 0) {
          Skater *fr = P.last; double ch = P.hasShot ? clamp(.1 + (p->at.hand + p->at.wacc - 7) * .012, .1, .3) : clamp(.06 + (fr->at.pass + p->at.wacc - 7) * .01, .06, .22);
          P.tipT[k] = rnd() < ch ? 1 : 0;
          if (P.tipT[k]) { skRedirect(P, p->team, std::max(spd * .8, 55.0), (11 - p->at.wacc) * .6, p, true, fr); if (p->team == 0) pushFeed(p->user ? "TIPPED IT!" : "TIPPED!", "#ffd54a"); break; }
        }
      }
      double r = r0;
      if ((dd < r || (bd < 1.9 && spd < 30)) && !(P.bz > .9) && (spd < 70 || P.passTo == p) && !(P.hasShot && P.shot.by == p && P.shot.t < .3)) {
        if (!P.owner && !P.passTo && !P.hasShot && SK->phase == PH_PLAY && !SK->hasBat && !(SK->batCd > SK->gt) && !(p->stun > 0)) {
          Wall w = skWall(P.x, P.y); if (hyp(P.x - w.x, P.y - w.y) < 5) {
            Skater *o = nullptr; for (Skater *q : SK->T[1 - p->team].on) if (!(q->stun > 0) && !(q->block > 0) && hyp(q->x - P.x, q->y - P.y) < 7) { o = q; break; }
            if (o && rnd() < .65) { skBattleStart(p, o); return; } } }
        bool chop = false;
        if (!P.passTo && (P.bz > .15 || P.hop > 0 || P.roll > 0)) { if (P.hopRid != P.id) { P.hopRid = P.id; P.hopR.clear(); }
          int kk = k * 1000 + P.hopN; auto it = P.hopR.find(kk);
          if (it == P.hopR.end()) it = P.hopR.emplace(kk, rnd() < (P.roll > 0 ? .4 : .5) ? (rnd() < clamp(.15 + p->at.hand * .07, .2, .85) ? 2 : 0) : 1).first;
          if (it->second == 0) { p->cool = std::max(p->cool, .25); continue; }
          chop = it->second == 2; }
        bool fromPass = P.passTo == p && P.lastPasser && P.lastPasser->team == p->team;
        if (chop) { p->chopT = .4; P.roll = 0; if (p->user) pushFeed("CHOPPED IT DOWN", "#93c5fd"); }
        P.owner = p; P.vx = P.vy = 0; P.hasShot = false; P.ice = -1; P.saucer = false; P.mag = 0;
        p->gotT = SK->gt; p->gotPass = fromPass; if (spd > 12) sfx(S_PASS, sndAt(p->x, p->y) * std::min(.6, spd / 90), rand(.78, .86)); p->dec = std::min(p->dec, fromPass ? .03 : .1);
        if (P.lastPasser && P.lastPasser->team != p->team) P.lastPasser = nullptr;
        if (!fromPass && P.last && P.last->team != p->team && p->user) SK->me.tk++;
        if (P.pl && P.lastPasser && P.lastPasser != p && P.lastPasser->team == p->team) SK->T[p->team].pc++;
        if (P.pl && P.lastPasser && P.lastPasser->user && P.lastPasser != p && P.lastPasser->team == p->team) pushFeed("PASS", "#93c5fd");
        P.pl = false;
        P.passTo = nullptr; P.last = p; return;
      }
    }
  }
  double f = std::exp(-.42 * dt); P.vx *= f; P.vy *= f;
  { double sp = hyp(P.vx, P.vy);
    if (P.passTo && sp < 8) { P.passTo = nullptr; P.saucer = false; }
    if (P.hasShot && (sp < 22 || P.shot.t > 1.6)) P.hasShot = false; }
}
void skIcing(int t) {
  Puck &P = SK->puck; P.owner = nullptr; P.vx = P.vy = 0; P.hasShot = false; P.passTo = nullptr; P.ice = -1;
  SK->phase = PH_STOP; SK->stopT = 1.3;
  SK->hasNextFo = true; SK->nextFo = {defendX(t) + tdir(t) * 20, P.y < RK.cy ? RK.cy - 22 : RK.cy + 22};
  SK->banner = {1.3, "ICING", SK->T[t].name + " - faceoff in their zone", hex("#93c5fd")};
}
// a goalie who lets in too many on too few shots gets the hook and the backup comes in (once a game)
static void skPullCheck(int gt) {
  Team &T = SK->T[gt], &O = SK->T[1 - gt];
  if (T.swapped || SK->per > 3 || T.g.out) return;
  int ga = O.score, sa = O.sog;
  if (!(ga >= 5 || (ga >= 4 && sa > 0 && (double)ga / sa > .22))) return;
  T.swapped = true;
  std::string old = T.g.nm;
  if (T.bk) { T.g.gs = gStats(T.bk); T.g.r = T.bk->r; T.g.nm = T.bk->nm; }   // Ultimate Franchise: the G2 card
  else { GS &g0 = T.g.gs; for (double *v : {&g0.agi, &g0.glv, &g0.blk, &g0.pad, &g0.chs, &g0.sta, &g0.rec, &g0.rd}) *v = std::max(50.0, *v - 6); T.g.nm = "BACKUP"; }
  T.g.ast = 100; T.g.faced = 0;
  pushFeed(upper(T.name) + " PULL " + upper(old) + " - " + upper(T.g.nm) + " IN", "#ff9800");
}

// ---------------------------------------------------------------- board battles
static double skBattleStr(const Skater *p) { return .8 + .4 * ((p->at.chk + p->at.hand) / 2 - 5) / 5; }
void skBattleStart(Skater *a, Skater *b) {
  Puck &P = SK->puck; Wall w = skWall(P.x, P.y); double tx = -w.ny, ty = w.nx; if (a->team != 0 && b->team == 0) std::swap(a, b);
  P.x = w.x - w.nx * 1.2; P.y = w.y - w.ny * 1.2; P.vx = P.vy = 0; P.bz = 0; P.bvz = 0; P.passTo = nullptr; P.hasShot = false; P.roll = 0;
  for (auto pr : {std::make_pair(a, 1.0), std::make_pair(b, -1.0)}) { Skater *p = pr.first; double s = pr.second;
    p->x = P.x - w.nx * 2.2 + tx * s * 1.1; p->y = P.y - w.ny * 2.2 + ty * s * 1.1; p->vx = p->vy = 0; p->ang = std::atan2(w.ny, w.nx); p->dash = 0; p->hasDk = false; p->dkLat = 0; }
  SK->hasBat = true; SK->bat = Battle(); SK->bat.a = a; SK->bat.b = b; SK->bat.w = {w.x, w.y, w.nx, w.ny}; SK->bat.user = (a == SK->user || b == SK->user) && !g_autoplay;
  if (SK->bat.user) pushFeed("BOARD BATTLE!", "#ffd54a");
}
void skBattleUpdate(double dt, const Input &I) {
  if (!SK->hasBat) return; Battle &B = SK->bat; B.t += dt; Puck &P = SK->puck;
  if (SK->phase != PH_PLAY || !onIce(B.a) || !onIce(B.b)) { SK->hasBat = false; return; }
  double sa = skBattleStr(B.a), sb = skBattleStr(B.b);
  if (B.user) { double mx = I.mx; int sg = mx > .5 ? 1 : mx < -.5 ? -1 : 0; if (sg && sg != B.ls) { if (B.ls) B.prog += .055 * sa; B.ls = sg; }
    B.prog -= .22 * sb * dt * (.8 + .4 * std::sin(B.t * 5.3)); }
  else B.prog += (sa - sb) * .5 * dt + rand(-.6, .6) * dt;
  P.x = B.w.x - B.w.nx * 1.2; P.y = B.w.y - B.w.ny * 1.2; P.vx = P.vy = 0;
  double lim = B.user ? 3.2 : 1.3;
  if (B.prog >= 1 || B.prog <= 0 || B.t > lim) { Skater *win = B.prog >= .5 ? B.a : B.b, *lose = win == B.a ? B.b : B.a;
    P.owner = win; win->gotT = SK->gt; win->gotPass = false; P.last = win; win->vx = -B.w.nx * 11; win->vy = -B.w.ny * 11; win->ang = std::atan2(-B.w.ny, -B.w.nx);
    lose->stun = std::max(lose->stun, .35); lose->cool = .6; SK->hasBat = false; SK->batCd = SK->gt + 18;
    if (win->user) pushFeed("WON THE BOARD BATTLE", "#7CFC9A"); else if (lose->user) pushFeed("LOST THE BATTLE", "#ff7a7a");
    sfx(S_HIT, sndAt(P.x, P.y) * .5, 1.15); }
}

// ---------------------------------------------------------------- goals
static void skBottleFly(int ti, const Puck &P) {
  if (SK->btl[ti].s != BT_NET) return;
  double s = -tdir(ti), gx = defendX(ti);
  SK->btl[ti] = {BT_FLY, gx + s * 1.4, RK.cy + 1.3, 5.2, s * rand(3, 7) + P.vx * .05, rand(-6, 6) + P.vy * .06, rand(8, 12), 0, rand(-16, 16)};
}
void skGoal(int team) {
  Puck &P = SK->puck; Team &T = SK->T[team]; T.score++; T.sog++;
  if (skShort(team)) T.shg++;
  if (SK->ut) { bool pp = SK->T[1 - team].box.size() > T.box.size();
    if (!pp) for (Skater *q : SK->T[0].on) if (q->src && !q->src->utk.empty()) SK->utPM[q->src->utk] += team == 0 ? 1 : -1; }
  { Team &O = SK->T[1 - team]; for (size_t i = 0; i < O.box.size(); i++) if (!O.box[i].ko && O.box.size() > T.box.size()) { Skater *bp = O.box[i].p; O.box.erase(O.box.begin() + i); skBoxOut(O, 1 - team, bp); pushFeed("POWER PLAY GOAL", "#ffd54a"); break; } }
  Skater *sc = P.last && P.last->team == team ? P.last : (P.hasShot && P.shot.by) ? P.shot.by : P.last;
  Skater *as = P.lastPasser && P.lastPasser->team == team && P.lastPasser != sc && now() - P.passT < 9000 ? P.lastPasser : nullptr;
  if (SK->ut && team == 0) { if (sc && sc->src && !sc->src->utk.empty()) SK->utG[sc->src->utk]++; if (as && as->src && !as->src->utk.empty()) SK->utA[as->src->utk]++; }
  if (sc && sc->user) { SK->me.g++; SK->me.sog++; pushFeed("GOAL! " + skShotName(P), "#ffd54a"); }
  if (as && as->user) { SK->me.a++; pushFeed("ASSIST", "#ffd54a"); }
  SK->banner = {2.2, team == 0 ? "GOAL!" : "GOAL", (sc ? sc->nm : "") + (as ? "  (A: " + as->nm + ")" : ""), team == 0 ? hex("#60a5fa") : hex("#ff5252")};
  SK->gcol = team == 0 ? hex("#22c55e") : hex("#ef4444"); SK->goalT = 0;
  if (team == 0) sfx(S_CHEER, 1, rand(.97, 1.03)); else sfx(S_BOO, .85, rand(.96, 1.03));
  { int ti = 1 - team; if ((P.hasShot && P.shot.h > .6) || P.bz > 2.4) skBottleFly(ti, P); P.owner = nullptr; P.vx *= .85; P.vy *= .85; P.hasShot = false; P.passTo = nullptr;
    SK->hasNetIn = true; SK->netIn = {ti, defendX(ti), -tdir(ti)}; P.x = defendX(ti) - tdir(ti) * .4; }
  SK->hasCel = true; SK->cel = Celeb(); SK->cel.team = team; SK->cel.sc = sc && sc->team == team ? sc : nullptr; SK->cel.as = as;
  SK->phase = PH_GOAL; SK->stopT = 3; SK->hasNextFo = true; SK->nextFo = {RK.L / 2, RK.cy};
  skPullCheck(1 - team);
  if (SK->per > 3) SK->endAfter = true;
}
void skResume() {
  SK->hasCel = false; SK->hasNetIn = false; SK->hasBat = false; SK->nb[0] = SK->nb[1] = NetBulge(); SK->btl[0] = SK->btl[1] = Bottle(); SK->spr.clear(); SK->gls.clear(); SK->shk = 0; SK->hstop = 0;
  for (Skater *p : skAll()) { p->wind = 0; p->hasDk = false; p->dkLat = 0; p->dkF = 0; }
  if (SK->endAfter) { skEnd(); return; }
  if (SK->nextPer) { SK->nextPer = false; SK->per++; SK->clock = SK->per > 3 ? 60 : SK_PER; SK->foN = 0; }
  Pt f = SK->hasNextFo ? SK->nextFo : Pt{RK.L / 2, RK.cy}; SK->hasNextFo = false; skFaceoff(f.x, f.y);
}
void skBottleUpdate(double dt) {
  for (Bottle &b : SK->btl) { if (b.s == BT_NET) continue;
    b.x += b.vx * dt; b.y += b.vy * dt; b.a += b.va * dt;
    if (b.s == BT_FLY) { b.vz -= 32 * dt; b.z += b.vz * dt; if (b.z <= 0) { b.z = 0; if (b.vz < -5) { b.vz = -b.vz * .3; b.vx *= .6; b.vy *= .6; b.va *= .7; } else { b.vz = 0; b.s = BT_ICE; } } }
    else { double f = std::exp(-2.6 * dt); b.vx *= f; b.vy *= f; b.va *= f; }
    if (b.x < 1 || b.x > RK.L - 1) { b.vx = -b.vx * .4; b.x = clamp(b.x, 1, RK.L - 1); } if (b.y < 1 || b.y > RK.Wd - 1) { b.vy = -b.vy * .4; b.y = clamp(b.y, 1, RK.Wd - 1); }
  }
}
static void skNetHit(int ti, double y, double sp) {
  double a = clamp(std::pow(clamp((sp - 12) / 50, 0, 1.3), 1.35) * 2.3, .12, 2.4); NetBulge &o = SK->nb[ti];
  if (!o.on || a > o.a * std::exp(-3.2 * o.t)) o = {true, y, a, 0};
}
void skNetPuck(double dt) {
  Puck &P = SK->puck;
  for (auto &o : SK->nb) if (o.on) o.t += dt;
  if (!SK->hasNetIn) return; auto &G = SK->netIn;
  int n = std::max(1, (int)std::ceil(hyp(P.vx, P.vy) * dt / .4)); double h = dt / n, pw = RK.post - .45;
  for (int i = 0; i < n; i++) {
    P.x += P.vx * h; P.y += P.vy * h;
    double lat = P.y - RK.cy;
    if (std::fabs(lat) > pw) { double sg = sgn(lat); P.y = RK.cy + sg * pw; if (P.vy * sg > 0) { skNetHit(G.ti, lat, std::fabs(P.vy) * .6); P.vy = -P.vy * .25; P.vx *= .8; } lat = P.y - RK.cy; }
    double dep = (P.x - G.gx) * G.s, md = std::max(.6, RK.netD * .95 * std::pow(std::max(0.0, 1 - std::pow(std::fabs(lat) / RK.post, 4)), .25));
    if (dep > md) { P.x = G.gx + G.s * md; double vs = P.vx * G.s; if (vs > 0) { skNetHit(G.ti, lat, vs); P.vx = -P.vx * .08; P.vy = P.vy * .75 + rand(-1, 1) * vs * .1; } }
    else if (dep < .35) { P.x = G.gx + G.s * .35; if (P.vx * G.s < 0) P.vx = -P.vx * .3; }
  }
  double f = std::exp(-3 * dt); P.vx *= f; P.vy *= f;
}
void skCeleb(double dt) {
  if (!SK->hasCel) return; Celeb &c = SK->cel; c.t += dt;
  Team &T = SK->T[c.team], &O = SK->T[1 - c.team]; Skater *sc = c.sc && onTeam(c.team, c.sc) ? c.sc : (T.on.empty() ? nullptr : T.on[0]); double d = tdir(c.team);
  if (sc && !c.hasTg) { c.hasTg = true; c.tgx = attackX(c.team) - d * 17; c.tgy = sc->y < RK.cy ? 3.2 : RK.Wd - 3.2; }
  if (sc && !c.gl && hyp(sc->x - c.tgx, sc->y - c.tgy) < 2.6) { c.gl = true; skGlassHit(sc->x, sc->y, .85); skShake(.2); }
  auto steer = [&](Skater *p, double tx, double ty, double sp, double k) { double dx = tx - p->x, dy = ty - p->y, m = hyp(dx, dy), v = std::min(sp, m * 2.2), a = std::min(1.0, k * dt);
    p->vx += ((m > .3 ? dx / m * v : 0) - p->vx) * a; p->vy += ((m > .3 ? dy / m * v : 0) - p->vy) * a; };
  for (size_t i = 0; i < T.on.size(); i++) { Skater *p = T.on[i];
    if (!sc) break;
    if (p == sc) steer(p, c.tgx, c.tgy, 28, 2.4); else { double a = i * 2.3 + c.t * .9; steer(p, sc->x + std::cos(a) * 3.4, sc->y + std::sin(a) * 3.4, 31, 2.2); }
    bool nr = hyp(p->x - sc->x, p->y - sc->y) < 7;
    p->wind = (p == sc && c.t > .25) || (nr && c.t > .5) ? std::round(clamp(.55 + .45 * std::sin(c.t * 9 + i * 1.3), 0, 1) * 4) / 4 : 0; }
  for (Skater *p : O.on) { steer(p, p->x + (RK.L / 2 - p->x) * .3, p->y, 7, 1); p->wind = 0; }
  for (Skater *p : skAll()) { p->x += p->vx * dt; p->y += p->vy * dt; skBoardsP(p, 1.3, .2); double v = hyp(p->vx, p->vy); if (v > 2.5) p->ang = std::atan2(p->vy, p->vx); p->ph += v * dt * .45; }
}
void skPeriodEnd() {
  int t0 = SK->T[0].score, t1 = SK->T[1].score;
  SK->phase = PH_STOP; SK->stopT = 1.8;
  if (SK->per < 3) { SK->banner = {1.8, SK->per == 1 ? "END OF 1ST" : "END OF 2ND", "", hex("#ffffff")}; SK->nextPer = true; }
  else if (SK->per == 3 && t0 == t1) { SK->banner = {1.8, "OVERTIME", "", hex("#ffd54a")}; SK->nextPer = true; }
  else {
    if (t0 == t1) {   // a shootout after overtime: decided by the skills on the ice
      auto sk = [](Skater *p) { return (p->at.wacc + p->at.wpow + p->at.lacc + p->at.spow) / 2; };
      double a = 0, b = 0; for (Skater *p : SK->T[0].on) a += sk(p); a /= std::max<size_t>(1, SK->T[0].on.size()); for (Skater *p : SK->T[1].on) b += sk(p); b /= std::max<size_t>(1, SK->T[1].on.size());
      int w = rnd() < clamp(.5 + (a - b) * .03 + (SK->T[0].g.r - SK->T[1].g.r) * .02, .25, .75) ? 0 : 1;
      SK->T[w].score++; RS.so = true;
      SK->banner = {1.8, w == 0 ? "SHOOTOUT WIN" : "SHOOTOUT LOSS", "", w == 0 ? hex("#7CFC9A") : hex("#ff5252")};
    } else SK->banner = {1.8, "FINAL", "", hex("#ffffff")};
    SK->endAfter = true;
  }
}

// ---------------------------------------------------------------- lines
static double skBenchRest(const Src *src, double f) {
  if (!src || src->en < 0) return 100; double r = std::max(0.0, SK->gt - src->et - 3); static const double LG[4] = {1, 1.1, 1.2, 1.3};
  return std::min(100.0, src->en + r * 2.75 * (.7 + .6 * f) * LG[src->lg]);
}
static double skLineRest(Team &T, int i) {
  if (i == T.li) { double a = 0; for (Skater *p : T.on) a += p->st; return a / std::max<size_t>(1, T.on.size()); }
  auto &L = T.lines[i]; double a = 0; for (Src *s : L) a += skBenchRest(s, .5); return a / std::max<size_t>(1, L.size());
}
static int skNextLine(Team &T, bool force) {
  double cur = skLineRest(T, T.li); int nx = (T.li + 1) % T.lines.size();
  if (nx == 0 && skLineRest(T, 0) < 99.5) { int b = -1; double bv = -1; for (int i = 1; i < (int)T.lines.size(); i++) { if (i == T.li) continue; double v = skLineRest(T, i); if (v > bv) { bv = v; b = i; } }
    if (b >= 0 && (bv > cur || force)) nx = b; else nx = force ? nx : -1; }
  return nx;
}
static bool skChangeLine(int ti, bool fly) {
  Team &T = SK->T[ti]; if (T.lines.size() < 2 || !T.box.empty() || T.pulled) return false;
  if (ti == 0 && SK->user && !onTeam(0, SK->user)) return false;
  bool ut = SK->ut && ti == 0;
  std::vector<Skater *> olds; for (Skater *p : T.on) if (ut || !p->user) olds.push_back(p);
  Puck &P = SK->puck; Skater *own = std::find(olds.begin(), olds.end(), P.owner) != olds.end() ? P.owner : nullptr; if (own && !fly) return false;   // on the fly the new man in his spot takes the puck
  T.li = (T.li + 1) % T.lines.size(); auto &L = T.lines[T.li];
  std::vector<Role> roles = ti == 0 && SK->user && !ut ? std::vector<Role>{R_LW, R_RW} : std::vector<Role>{R_C, R_LW, R_RW};
  for (Skater *o : olds) if (o->src) { o->src->en = o->st; o->src->et = SK->gt; o->src->lg = pkT(o, PK_LUNGS); }
  std::vector<Skater *> nw;
  for (size_t k = 0; k < L.size(); k++) { Role r = k < roles.size() ? roles[k] : R_RW; Skater *np = skMk(ti, r, L[k], false);
    Skater *op = nullptr; for (Skater *o : olds) if (o->role == r) { op = o; break; } if (!op && k < olds.size()) op = olds[k];
    if (fly && op) { np->x = op->x; np->y = op->y; np->vx = op->vx; np->vy = op->vy; np->ang = op->ang; }
    np->lane = r == R_LW ? -tdir(ti) : r == R_RW ? tdir(ti) : 0; np->st = skBenchRest(L[k], clamp((np->at.stam - 3.5) / 6.5, 0, 1)); nw.push_back(np); }
  T.lineT = 0;
  // you get a breather on the change (a real one when you went to the bench)
  if (ti == 0 && SK->user && !ut) { double f = clamp((SK->user->at.stam - 3.5) / 6.5, 0, 1); SK->user->st = std::min(100.0, SK->user->st + (fly ? 60 : 40) * (.7 + .6 * f)); SK->user->tired = SK->user->st < 20; }
  if (std::find(olds.begin(), olds.end(), P.passTo) != olds.end()) P.passTo = nullptr;
  if (own) { Skater *np = nullptr; for (Skater *q : nw) if (q->role == own->role) { np = q; break; } if (!np) np = nw[0]; P.owner = np; np->gotT = SK->gt; }
  if (ut) { nw[0]->user = true; nw[0]->tend = TD_USER; SK->user->user = false; SK->user = nw[0]; T.on = nw; }   // you take over the new center
  else { T.on.clear(); if (ti == 0 && SK->user) T.on.push_back(SK->user); T.on.insert(T.on.end(), nw.begin(), nw.end()); }
  T.bench.clear(); for (size_t i = 0; i < T.lines.size(); i++) if ((int)i != T.li) T.bench.insert(T.bench.end(), T.lines[i].begin(), T.lines[i].end());
  SK->warmT = -1;
  if (ti == 0 && SK->user && (fly || ut)) pushFeed(ut ? "LINE " + istr(T.li + 1) + " ON - YOU: " + upper(SK->user->nm) : "LINE CHANGE - LINE " + istr(T.li + 1), "#93c5fd");
  return true;
}
bool skBenchOpen() {
  Skater *u = SK ? SK->user : nullptr; if (!u) return false; Team &T = SK->T[0];
  return SK->phase == PH_PLAY && onTeam(0, u) && T.lines.size() >= 2 && T.box.empty() && !T.pulled && (u->st < 40 || u->tired) && !(SK->benchCd > SK->gt);
}
void skBenchCheck() {
  if (!skBenchOpen()) return; Skater *u = SK->user; BenchSpot B = skBench(); if (hyp(u->x - B.x, u->y - B.y) > B.r || SK->puck.owner == u) return;
  Team &T = SK->T[0]; int nx = skNextLine(T, true); if (nx < 0) return;
  T.li = (nx + T.lines.size() - 1) % T.lines.size();
  if (skChangeLine(0, true)) { SK->benchCd = SK->gt + 6; SK->lineNote = {3, T.li}; sfx(S_PASS, .4, .7); }
}
// every stoppage: the CPU changes lines after a long shift; then the FACEOFF transition
void skToFaceoff(const std::string &name, Col col, const std::string &sub) {
  if (name != "FINAL") for (int ti = 0; ti < 2; ti++) { Team &T = SK->T[ti];
    if (T.lines.size() < 2 || !T.box.empty() || T.pulled) continue;
    double cur = skLineRest(T, T.li);
    if (cur < 72 || T.lineT > 45) { int nx = skNextLine(T, false);
      if (nx >= 0) { T.li = (nx + T.lines.size() - 1) % T.lines.size(); if (skChangeLine(ti, false) && ti == 0) SK->lineNote = {3, T.li}; } }
    else for (Skater *p : T.on) p->st = std::min(100.0, p->st + 5); }
  SK->phase = PH_TRANS; goMode(name, [] { if (SK && SK->phase == PH_TRANS) skResume(); }, col, true, sub);
}

// ---------------------------------------------------------------- the end
void skEnd() {
  RS.valid = true; RS.hn = SK->T[0].name; RS.an = SK->T[1].name; RS.hs = SK->T[0].score; RS.as = SK->T[1].score; RS.hsh = SK->T[0].sog; RS.ash = SK->T[1].sog; RS.f = SK->me;
  afterGame(SK->T[0].score > SK->T[1].score, false);
  delete SK; SK = nullptr; feed.clear();
}
void skQuit() { RS.valid = false; paused = false; if (SK) afterGame(false, true); delete SK; SK = nullptr; feed.clear(); }

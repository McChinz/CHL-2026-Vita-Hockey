// CHL 2026 native - the soundtrack's decoder on the Vita: the system's own MP3 decoder (SceAudiodec), so there's no
// decoder library in the game and the work happens in the codec engine, not on the game's CPU cores.
// The declarations are written out here (they match psp2/audiodec.h) so the build never depends on that header;
// CMake defines CHL_AUDIODEC when it finds libSceAudiodec_stub, and without it the game simply stays quiet.
#include "music.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <malloc.h>
#include <algorithm>

std::string plat_asset_dir() { return "app0:"; }

#ifdef CHL_AUDIODEC
extern "C" {
struct AdInitStream { uint32_t size, totalStreams; };
struct AdInfoMp3 { uint32_t size, ch, version; };
union AdInfo { uint32_t size; AdInfoMp3 mp3; uint8_t pad[64]; };
struct AdCtrl { uint32_t size; int32_t handle; uint8_t *pEs; uint32_t inputEsSize, maxEsSize; uint8_t *pPcm; uint32_t outputPcmSize, maxPcmSize, wordLength; AdInfo *pInfo; };
int sceAudiodecInitLibrary(uint32_t codecType, void *initParam);
int sceAudiodecCreateDecoder(AdCtrl *ctrl, uint32_t codecType);
int sceAudiodecDeleteDecoder(AdCtrl *ctrl);
int sceAudiodecDecode(AdCtrl *ctrl);
}
static const uint32_t AD_MP3 = 0x1004, ES_MAX = 1441, ALIGN = 256;
static bool g_lib = false; static int g_libErr = 0;
struct MDec { FILE *f; AdCtrl c; AdInfo info; uint8_t *es, *pcm; uint8_t buf[16384]; int bpos, blen, ch, bad; bool eof, made; };
static void refill(MDec *d) {
  if (d->bpos > 0) { memmove(d->buf, d->buf + d->bpos, (size_t)(d->blen - d->bpos)); d->blen -= d->bpos; d->bpos = 0; }
  if (!d->eof) { size_t n = fread(d->buf + d->blen, 1, sizeof d->buf - (size_t)d->blen, d->f); if (n == 0) d->eof = true; d->blen += (int)n; }
}
// a layer III frame header at p? (MPEG 1, 2 or 2.5)
static bool hdrOk(const uint8_t *p) { return p[0] == 0xFF && (p[1] & 0xE0) == 0xE0 && ((p[1] >> 3) & 3) != 1 && ((p[1] >> 1) & 3) == 1 && (p[2] >> 4) != 0 && (p[2] >> 4) != 15 && ((p[2] >> 2) & 3) != 3; }
static int frameLen(const uint8_t *p) {   // bytes in the frame, from its header
  static const int BR1[16] = {0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 0}, BR2[16] = {0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0};
  static const int SR[4][3] = {{11025, 12000, 8000}, {0, 0, 0}, {22050, 24000, 16000}, {44100, 48000, 32000}};
  int v = (p[1] >> 3) & 3, br = (v == 3 ? BR1 : BR2)[p[2] >> 4] * 1000, sr = SR[v][(p[2] >> 2) & 3], pad = (p[2] >> 1) & 1;
  return sr ? (v == 3 ? 144 : 72) * br / sr + pad : 0;
}
static bool sync(MDec *d) {   // move to the next real frame header
  for (;;) { if (d->blen - d->bpos < 4) { refill(d); if (d->blen - d->bpos < 4) return false; }
    const uint8_t *p = d->buf + d->bpos;
    if (p[0] == 'I' && p[1] == 'D' && p[2] == '3' && d->blen - d->bpos >= 10) {   // an ID3v2 tag: skip it
      int n = 10 + ((p[6] & 127) << 21 | (p[7] & 127) << 14 | (p[8] & 127) << 7 | (p[9] & 127)); while (n > 0) { int k = std::min(n, d->blen - d->bpos); d->bpos += k; n -= k; if (n > 0) { refill(d); if (d->blen == d->bpos) return false; } } continue; }
    if (hdrOk(p)) return true; d->bpos++; }
}
MDec *mdec_open(const std::string &path, int *rate, std::string *err) {
  if (!g_lib) { AdInitStream ip = {sizeof(AdInitStream), 1}; g_libErr = sceAudiodecInitLibrary(AD_MP3, &ip); g_lib = g_libErr >= 0 || (uint32_t)g_libErr == 0x807F0003u; }   // already initialised is fine
  if (!g_lib) { char b[48]; snprintf(b, sizeof b, "MP3 DECODER INIT 0x%08X", (unsigned)g_libErr); if (err) *err = b; g_lib = false; return nullptr; }
  FILE *f = fopen(path.c_str(), "rb"); if (!f) { if (err) *err = "MISSING " + path.substr(path.rfind('/') + 1); return nullptr; }
  MDec *d = (MDec *)calloc(1, sizeof(MDec)); d->f = f;
  if (!sync(d)) { if (err) *err = "NOT AN MP3"; fclose(f); free(d); return nullptr; }
  const uint8_t *p = d->buf + d->bpos; int v = (p[1] >> 3) & 3; d->ch = ((p[3] >> 6) & 3) == 3 ? 1 : 2;
  static const int SR[4][3] = {{11025, 12000, 8000}, {0, 0, 0}, {22050, 24000, 16000}, {44100, 48000, 32000}}; *rate = SR[v][(p[2] >> 2) & 3];
  d->info.mp3.size = sizeof(AdInfoMp3); d->info.mp3.ch = (uint32_t)d->ch; d->info.mp3.version = (uint32_t)v;
  d->c.size = sizeof(AdCtrl); d->c.pInfo = &d->info; d->c.wordLength = 16;
  int r = sceAudiodecCreateDecoder(&d->c, AD_MP3);
  d->made = r >= 0;
  if (r < 0) { char b[48]; snprintf(b, sizeof b, "MP3 DECODER 0x%08X", (unsigned)r); if (err) *err = b; fclose(f); free(d); return nullptr; }
  uint32_t es = d->c.maxEsSize > ES_MAX ? d->c.maxEsSize : ES_MAX, pc = d->c.maxPcmSize > 1152 * 4 ? d->c.maxPcmSize : 1152 * 4;
  es = (es + ALIGN - 1) & ~(ALIGN - 1); pc = (pc + ALIGN - 1) & ~(ALIGN - 1);
  d->es = (uint8_t *)memalign(ALIGN, es); d->pcm = (uint8_t *)memalign(ALIGN, pc); d->c.maxEsSize = ES_MAX; d->c.maxPcmSize = pc;
  if (!d->es || !d->pcm) { if (err) *err = "OUT OF MEMORY"; mdec_close(d); return nullptr; }
  return d;
}
int mdec_read(MDec *d, int16_t *out, int maxFrames) {
  for (int tries = 0; tries < 64; tries++) {
    if (!sync(d)) return 0;
    if (d->blen - d->bpos < (int)ES_MAX) refill(d);
    int avail = d->blen - d->bpos, fl = frameLen(d->buf + d->bpos); if (fl <= 4 || fl > avail) { if (d->eof && fl > avail) return 0; d->bpos++; continue; }
    memset(d->es, 0, ES_MAX); memcpy(d->es, d->buf + d->bpos, (size_t)std::min(avail, (int)ES_MAX));
    d->c.pEs = d->es; d->c.inputEsSize = (uint32_t)fl; d->c.pPcm = d->pcm; d->c.outputPcmSize = 0;
    int r = sceAudiodecDecode(&d->c);
    if (r < 0) { d->bpos++; if (++d->bad > 200) return -1; continue; }
    d->bpos += d->c.inputEsSize > 0 && (int)d->c.inputEsSize <= avail ? (int)d->c.inputEsSize : fl;
    int n = (int)(d->c.outputPcmSize / (2 * (uint32_t)d->ch)); if (n > maxFrames) n = maxFrames;
    const int16_t *s = (const int16_t *)d->pcm;
    if (d->ch == 2) memcpy(out, s, (size_t)n * 4); else for (int i = 0; i < n; i++) out[i * 2] = out[i * 2 + 1] = s[i];
    if (n > 0) return n;
  }
  return -1;
}
void mdec_close(MDec *d) {
  if (!d) return; if (d->made) sceAudiodecDeleteDecoder(&d->c);
  if (d->f) fclose(d->f); free(d->es); free(d->pcm); free(d);
}
#else
struct MDec {};
MDec *mdec_open(const std::string &, int *, std::string *err) { if (err) *err = "NO MP3 DECODER IN THIS BUILD"; return nullptr; }
int mdec_read(MDec *, int16_t *, int) { return 0; }
void mdec_close(MDec *) {}
#endif

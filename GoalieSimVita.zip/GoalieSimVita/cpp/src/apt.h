// CHL 2026 native - BE A PRO: your apartment, the hub you walk around in first person. It is yours for good (every
// career lives here), starts rundown, and fills up as you spend: the upgrades and the trophy shelf (every title you
// have ever won, in any career) are kept in chl_home.json, not in a career save.
#pragma once
#include "platform.h"
#include <string>
#include <cstdint>

// what can be bought: 0 flooring, 1 couch, 2 TV, 3 entertainment center ([cat][0] is what the place came with)
constexpr int HOME_NC = 4, HOME_NO = 4;
struct HomeOpt { const char *n; int c; const char *d; };
extern const char *HOME_CAT[HOME_NC];
extern const HomeOpt HOME_OPT[HOME_NC][HOME_NO];
// each save file has its own apartment: what's in it is saved with the career (proSave / proLoadSlot)
struct Home { int sel[HOME_NC] = {0, 0, 0, 0}, own[HOME_NC] = {1, 1, 1, 1}; };
extern Home HOME;
struct J; J homeToJ(); void homeFromJ(const J &o);   // also unloads the apartment, so the next visit rebuilds it
bool homeTestMade(); void homeSetTestMade();        // the one-time TEST file (chl_home.json)
int homeBuy(int cat, int i);              // 1 bought, 2 equipped, 0 not enough cash (uses your career's cash)

// the walk-around view
extern bool aptBuild;                     // build mode (D-PAD LEFT): upgrade prompts show
enum { APT_NONE = -1, APT_DOOR = 10, APT_SHELF = 11 };
void aptReset();
bool aptReady();     // built and ready to draw
void aptLoad();      // build it now (the loading screen calls this)
void aptUnload();    // free the geometry and the GPU copy (before a game, leaving Be a Pro)
                          // stand inside the front door
void aptDraw();                           // the 3D apartment (call before any 2D on top)
void aptHUD();                            // crosshair, prompt, build banner
void aptMove(const Pad &pad, const Touch &touch, double dt);
int aptLook();                            // what the crosshair is on: a HOME cat, APT_DOOR, APT_SHELF or APT_NONE
void aptDirty();                          // rebuild the geometry (after a purchase)
void aptView(double x, double y, double yaw, double pitch);   // tests: put the camera somewhere
int aptTris();
void aptPos(double &x, double &y);

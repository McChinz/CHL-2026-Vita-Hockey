// CHL 2026 native - BE A PRO: your apartment, the hub you walk around in first person. Each save file has its own:
// it starts rundown and fills up as you spend, room by room. Everything you buy also nudges a rating or two (homePts).
#pragma once
#include "platform.h"
#include <string>
#include <vector>
#include <cstdint>

// the rooms (floor, paint and drywall are bought per room; the hall counts as the living room)
constexpr int HOME_NR = 4;
extern const char *ROOMN[HOME_NR];   // LIVING ROOM, KITCHEN, BEDROOM, OFFICE
// what can be bought: a slot is a spot in the apartment, [0] of each is what the place came with
enum HomeSlot { HS_COUCH, HS_TV, HS_ENT, HS_RECL, HS_ISLE, HS_FLOOR, HS_PAINT = HS_FLOOR + HOME_NR, HS_WALL = HS_PAINT + HOME_NR,
  HS_BED = HS_WALL + HOME_NR, HS_BAR, HS_GAME, HS_CAVE, HS_BPAINT, HS_CPAINT, HOME_NS };   // BPAINT / CPAINT: the bathroom's and the man cave's paint   // (new slots go on the end: the saves keep their order)
constexpr int ROOM_BATH = 4, ROOM_CAVE = 5;   // homeRoomAt: the bathroom and the penthouse's man cave (not painted / floored per room)
struct HomeOpt { const char *n; int c; const char *d; const char *fx; };   // fx: rating nudges, "fstam:0.5,pass:0.25"
struct HomeSlotDef { const char *n; std::vector<HomeOpt> o; int lvl; };      // lvl: the apartment it needs
extern const HomeSlotDef HSLOT[HOME_NS];
std::string homeSlotName(int s);   // "FLOORING  |  KITCHEN"
// the kitchen counter: small appliances, up to four out at a time
constexpr int HOME_NCTR = 4;
extern const std::vector<HomeOpt> COUNTER;
// the places you can move to (the office computer)
extern const std::vector<HomeOpt> APTS;
struct Home {
  int sel[HOME_NS], own[HOME_NS], col[HOME_NS]; int junk = 0, lvl = 0, lvlOwn = 1, ctrOwn = 0, ctr[HOME_NCTR] = {-1, -1, -1, -1}, ctrCol[16];
  Home() { for (int i = 0; i < HOME_NS; i++) { sel[i] = 0; own[i] = 1; col[i] = -1; } for (int &c : ctrCol) c = -1; }
};
// colours: most things you buy come in a choice of colours (picked from swatches before you pay; -1: as it comes)
struct Swatch { const char *n, *c; };
const std::vector<Swatch> &homeSwatches(int slot, int opt);   // empty: that one has no colour choice
const std::vector<Swatch> &ctrSwatches();                     // the counter appliances
void homeSetCol(int slot, int c); void homeSetCtrCol(int item, int c);
extern Home HOME;
struct J; J homeToJ(); void homeFromJ(const J &o);   // saved with the career; loading also unloads the apartment
bool homeTestMade(); void homeSetTestMade();        // the one-time TEST file (chl_home.json)
int homeBuy(int slot, int i);             // 1 bought, 2 swapped in, 0 not enough cash, -1 not possible yet (paint before drywall...)
int homeCounter(int i);                   // buy / put out / put away a counter item: 1 bought+placed, 2 placed, 3 put away, 4 counter full, 0 cash
int homeMove(int lvl);                    // buy / move into an apartment: 1 bought, 2 moved, 0 cash
bool homeCtrOut(int i);
double homePts(const std::string &k);     // the rating nudges from everything in the place (added with the gear's)
std::string homeFxTxt(const char *fx);    // "+0.5 STAMINA  +0.25 PASSING"
int homeRoomAt(double x, double y);

// the walk-around view
extern bool aptBuild;                     // build mode (D-PAD LEFT): upgrade prompts show
enum { APT_NONE = -1, APT_DOOR = 10, APT_SHELF = 11, APT_HDOOR = 12, APT_JUNK = 20, APT_COUNTER = 40, APT_PC = 41, APT_RADIO = 42, APT_LIGHT = 50, APT_SLOT = 100 };
constexpr int APT_NLIGHT = 6;   // APT_LIGHT + 0..5: the light switches (living room + hall, kitchen, bedroom, office, bathroom, man cave)
extern const char *APT_LIGHTN[APT_NLIGHT];
void aptLight(int i); bool aptLightOn(int i);   // flip a room's lights (they start on)
constexpr int APT_NHD = 3;   // the inside doors
// APT_HDOOR + 0/1/2: bedroom / office / bathroom door; APT_JUNK + bit; APT_SLOT + a HomeSlot (build mode only)
constexpr int APT_NJUNK = 5;
extern const char *APT_JUNKN[APT_NJUNK];   // "THE MOVING BOXES"...
void aptThrow(int bit);                    // throw out a piece of the mess (saved with the career)
void aptDoor(int i);                       // open (or close) a hallway door
bool aptDoorOpen(int i);
void aptReset();                           // stand inside the front door
void aptSit();                             // sit on the couch (after a game); X stands you up
bool aptSitting();
void aptStand();
bool aptReady();     // built and ready to draw
void aptLoad();      // build it now (the loading screen calls this)
void aptUnload();    // free the geometry and the GPU copy (before a game, leaving Be a Pro)
void aptDraw();                           // the 3D apartment (call before any 2D on top)
void aptHUD();                            // crosshair
void aptMove(const Pad &pad, const Touch &touch, double dt);
int aptLook();                            // what the crosshair is on (APT_*), or APT_NONE
void aptDirty();                          // rebuild the geometry (after a purchase)
void aptView(double x, double y, double yaw, double pitch);   // tests: put the camera somewhere
int aptTris();
void aptPos(double &x, double &y);

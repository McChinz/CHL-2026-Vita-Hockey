// CHL 2026 native - Ultimate Franchise: open card packs, slot 11 cards (3 lines of LW-C-RW + 2 goalies), play
// CPU teams near your level for coins, the salary cap, Road to the Cup. Three save files (chl_ut.json, the
// legacy format: legacy saves load as they are). Ported line by line from the legacy build.
#pragma once
#include "menu.h"
#include <map>
#include <memory>

struct UCard { int u = 0; std::string p; int r = 0; };
struct ULock { bool on = false; std::string p; int r = 0; };          // a card copy (player + rarity), or empty
struct UOpp { std::string nm; int col = 0, ov = 60, tov = 0, k = 1; double seed = 0; bool cup = false; int ci = -1; };
struct UStat { int gp = 0, g = 0, a = 0, sa = 0, sv = 0, w = 0, l = 0; };
struct UCStat { int gp = 0, g = 0, a = 0, pm = 0, sa = 0, sv = 0, ga = 0, w = 0, l = 0, so = 0; };
struct CupTeam { std::string nm; int col = 0, ov = 0, tov = 0, div = 0, w = 0, l = 0, gf = 0, ga = 0; double seed = 0; bool me = false; };
struct CupMatch { int a = 0, b = 0, w = -1, sa = 0, sb = 0; };
struct Cup {
  int v = 1; std::vector<CupTeam> T; std::vector<int> sched; int g = 0; std::string phase = "reg";
  bool hasBr = false; std::vector<std::vector<CupMatch>> br; int rd = 0, champ = -1; std::string out;
  std::vector<ULock> lock; bool hasLock = false; std::map<std::string, UStat> st;
};
struct UTX {
  int v = 2, pv = 2; std::string nm; int col = 0; double coins = 500; std::vector<UCard> cards; std::vector<int> ro;
  int n = 1, w = 0, l = 0, gp = 0, packs = 0; std::vector<UOpp> opp; bool hasOpp = false; int oppFor = -1;
  bool hasCap = false; double cap = 24; int capN = 0; std::vector<int> inv;
  std::unique_ptr<Cup> cup; std::map<std::string, UStat> st; std::map<std::string, UCStat> cs;
  UTX() {}
  UTX(const UTX &o) { *this = o; }
  UTX &operator=(const UTX &o);
};
extern std::unique_ptr<UTX> utSlots[3];
extern UTX *UT; extern int utSlot;

// the card pool and ratings (league.cpp has the players)
struct URat { Ratings rt; GS g; int ovr = 50; std::string ar; bool goalie = false; int get(const std::string &k) const; };
const URat &utRat(const UCard &c);
int utOv(const UCard &c);
int utTeamOv(const UTX &X);
double utSal(const UCard &c);
bool utFull(const UTX &X);
std::string utLast(const std::string &nm);
extern const char *UT_COLS[12][2];

// screens and input
bool utTap(const std::string &id);
void drawUT();
void drawUTEx();
bool utExOn(); bool utMenuOn();
void utLPCheck();
bool utLPDown(float x, float y, int id);
bool utLPUp(int id, float x, float y, bool still);
void utShoulder(int d);
void utPadSquare(const std::string &id);
void utPadTriangle(const Btn &b);
void utAskDel(int i);
void utLoad(int i);
void utNew(int i, const std::string &nm);
void utLeave();        // back to the main menu
// the game
void utGameRosters(Rosters &R);   // called by skStart in Ultimate Franchise
bool utPreview(int ti, PvTeam &o, const std::vector<Skater *> &on, const Goalie &G);   // the pre-game lineup card
int utAfter(bool won, bool quit);
extern std::string utRet;
bool utHasPick();
std::string utPreviewSub();   // the line under TONIGHT'S MATCHUP
// saves
void utSave();
void utLoadAll(const std::string &json);

// CHL 2026 native - BE A PRO screens: save files, the new-career setup, draft night, the hub, upgrades and perks,
// training, the gear shop, the office (contract, no-trade clause, trade requests, offers), the trade alert, the
// schedule, the league (standings, scorers, goalies, news, your team, the playoff bracket) and retirement.
#include "trophy.h"
#include "pro.h"
#include "emblem.h"
#include "apt.h"
#include "music.h"
#include <algorithm>

double proBusyT = 0;
static char pendPos = 'C', pendSh = 'L';
static int pendNum = 19, pendDiff = 1, upTab = 0, shopCat = 0, standTab = 0, standLg = 0, schedPg = -1, busyF = 0, perkSel = 0;
static std::vector<int> tqSel;
static double draftT0 = 0;
#define C (*CR)

// ---------------------------------------------------------------- pieces
static void T(const std::string &t, double x, double y, double sz, const char *c, Align al = AL_LEFT, int wt = 800) { tx(t, x, y, sz, c, al, wt); }
static void TB(const std::string &t, double x, double y, double sz, const char *c, Align al = AL_LEFT) { tx(t, x, y, sz, hex(c), al, true); }
static void TF(const std::string &t, double x, double y, double sz, double mw, const char *c, Align al = AL_LEFT) { txFit(t, x, y, sz, mw, hex(c), al); }
static void panel(double x, double y, double w, double h, double a = .74) { glass(x, y, w, h, a * .8); }
static void scrHead(const std::string &t, const std::string &sub) { double m = .03 * U, ty = safeTop + .045 * U; TB(t, m, ty, .055, "#fff"); if (!sub.empty()) { TXR = W * .7; T(sub, m, ty + .045 * U, .019, "#f26b5b", AL_LEFT, 700); TXR = 1e4; } }
static void cashTag() { double m = .03 * U; T("CASH", W - m, safeTop + .028 * U, .016, "#94a3b8", AL_RIGHT, 700); TB("$" + fmtN(C.money), W - m, safeTop + .06 * U, .034, "#ffd54a", AL_RIGHT); }
static void xpTagTop() { double m = .03 * U; T("XP", W - m - .2 * U, safeTop + .028 * U, .016, "#94a3b8", AL_RIGHT, 700); TB(fmtN(C.xp), W - m - .2 * U, safeTop + .06 * U, .034, "#ffd54a", AL_RIGHT); }
static void dimOut(double x, double y, double w, double h) { ctx.fill(rgba(11, 16, 36, .62)); ctx.fillRect(x, y, w, h); if (!btns.empty()) btns.back().dis = true; }
static void meter(double x, double y, double w, double v, const char *col, const std::string &lb) {
  T(lb, x, y, .016, "#94a3b8", AL_LEFT, 700); T(istr((int)jround(v * 100)), x + w, y, .017, "#fff", AL_RIGHT, 900);
  ctx.fill(rgba(148, 163, 184, .25)); ctx.fillRect(x, y + .016 * U, w, 5); ctx.fill(col); ctx.fillRect(x, y + .016 * U, std::max(2.0, w * v), 5);
}
static void badge(double x, double y, double r, int t) {
  ctx.fill(rgba(2, 6, 23, .45)); ctx.disc(x + r * .06, y + r * .1, r * 1.08); drawEmblem(C.L[t].ab, x, y, r * 1.12, hex(teamCol(t)), hex(teamStr(t)));
}
static const std::vector<std::pair<std::string, std::string>> PADH = {{"D-PAD", "MOVE"}, {"X", "SELECT"}, {"O", "BACK"}};
static void back(const std::string &id, double y) { ui(id, (W - .4 * U) / 2, y, .4 * U, .07 * U, "BACK", "#475569", true, .032); }
static std::string money2(double v) { return "$" + fixed(v, 2) + "M"; }
static HeroSpec youSpec() { HeroSpec h; h.nm = C.nm; h.j = hex(teamCol(C.me)); h.s = hex(teamStr(C.me)); h.skin = skinOf(C.nm); h.num = C.num; h.right = C.sh == 'R'; return h; }
// you, in 3D, in your current team's sweater (f: the old figure's scale; he's about 6.2 f tall)
static void you(double x, double y, double f, double cx0 = -1e9, double cy0 = -1e9, double cx1 = 1e9, double cy1 = 1e9) { model3D(x, y, f * 6.2, youSpec(), 4, .35f, false, cx0, cy0, cx1, cy1); }

// ---------------------------------------------------------------- save files and a new career
static void drawSlots() {
  double w = std::min(W - 24.0, 1.7 * U), x = (W - w) / 2, y = safeTop + .02 * U, rh = .17 * U;
  TB("BE A PRO", W / 2, y + .05 * U, .075, "#fff", AL_CENTER); T("Choose a career   (SQUARE: delete)", W / 2, y + .12 * U, .03, "#cbd5e1", AL_CENTER, 700);
  for (int i = 0; i < 3; i++) {
    double ry = y + .17 * U + i * (rh + .012 * U); ProSlotInfo s = proSlotInfo(i); panel(x, ry, w, rh, .62);
    if (s.on) {
      accentBar(x, ry, rh, hex("#c8102e")); TXR = x + w - .27 * U;
      TB(upper(s.nm), x + .035 * U, ry + rh * .28, .045, "#ffd54a");
      T(s.phase == "retired" ? "RETIRED  |  " + istr(s.titles) + (s.titles == 1 ? " TITLE" : " TITLES") : "FORWARD  |  OVR " + istr(s.ov) + "  |  " + upper(s.team), x + .035 * U, ry + rh * .56, .03, "#fff");
      T("AGE " + istr(s.age) + "   |   SEASON " + istr(s.season) + "   |   " + istr(s.titles) + (s.titles == 1 ? " CHAMPIONSHIP" : " CHAMPIONSHIPS"), x + .035 * U, ry + rh * .82, .023, "#94a3b8", AL_LEFT, 700);
      TXR = 1e4; pushBtn("pslot:" + istr(i), x, ry, w - .25 * U, rh);
      ui("pdel:" + istr(i), x + w - .24 * U, ry + rh * .3, .22 * U, rh * .4, "DELETE", "#475569", true, .026);
    } else { T("FILE " + istr(i + 1) + " - NEW CAREER", W / 2, ry + rh / 2, .036, "#7aa7ff", AL_CENTER); pushBtn("pslot:" + istr(i), x, ry, w, rh); }
  }
  double hy = y + .17 * U + 3 * (rh + .012 * U) + .015 * U;
  if (proHofCareers) T("HALL OF FAME: " + istr(proHofCareers) + (proHofCareers == 1 ? " CAREER" : " CAREERS") + " COMPLETE  |  MOST TITLES " + istr(proHofBest), W / 2, hy, .02, "#94a3b8", AL_CENTER, 700);
  back("nav:modes", hy + .025 * U);
}
static Look pendLook; static std::string pendLookFor = "\x01"; double g_creatorYaw = -99;   // (tests: hold the bust still)
static void drawNew() {
  { std::string nm = pname; while (!nm.empty() && nm.back() == ' ') nm.pop_back(); if (pendLookFor != nm) { pendLookFor = nm; pendLook = lookOf(nm.empty() ? "ROOKIE" : nm); } }
  double m = .04 * U, y = safeTop + .02 * U;
  TB("NEW CAREER", W / 2, y + .04 * U, .052, "#fff", AL_CENTER); T(upper(pname), W / 2, y + .088 * U, .028, "#ffd54a", AL_CENTER);
  double top = y + .125 * U, lw = .5 * U, rx = m + lw + .03 * U, rw = W - rx - m;
  // left: him, turning on a stand, and his look
  { double ph = .44 * U; panel(m, top, lw, ph, .62); topLine(m, top, lw, hex("#38bdf8"));
    softGlow(m + lw / 2, top + ph * .55, lw * .42, ph * .42, hex("#38bdf8"), .18);
    ctx.fill(rgba(255, 255, 255, .06)); ctx.oval(m + lw / 2, top + ph * .93, lw * .3, ph * .035);
    double yaw = g_creatorYaw > -9 ? g_creatorYaw : std::sin(now() / 1000.0 * .7) * .6;
    sk3HeadPreview(m + lw / 2, top + ph * .56, ph * .86, pendLook, (float)yaw, false, hex("#c8102e"));
    T("YOUR LOOK", m + .02 * U, top + .03 * U, .017, "#94a3b8", AL_LEFT, 800);
    double ry = top + ph + .012 * U, rh = .058 * U;
    auto row = [&](const char *lab, const std::string &key, const std::string &val, Col sw, bool swatch) {
      glass(m, ry, lw, rh, .5); T(lab, m + .02 * U, ry + rh / 2, .019, "#fff", AL_LEFT, 800);
      double bw = .05 * U, bx1 = m + lw - .015 * U - bw, bx0 = m + lw * .4;
      ui("look:" + key + ":-1", bx0, ry + rh * .14, bw, rh * .72, "<", "#334155", true, .026);
      ui("look:" + key + ":1", bx1, ry + rh * .14, bw, rh * .72, ">", "#334155", true, .026);
      double mid = (bx0 + bw + bx1) / 2;
      if (swatch) { ctx.fill(sw); ctx.disc(mid - .06 * U, ry + rh / 2, rh * .28); ctx.stroke(rgba(255, 255, 255, .6)); ctx.lineWidth(1.5); ctx.beginPath(); ctx.arc(mid - .06 * U, ry + rh / 2, rh * .28, 0, 7); ctx.strokePath(); T(val, mid - .03 * U, ry + rh / 2, .016, "#e2e8f0", AL_LEFT, 800); }
      else T(val, mid, ry + rh / 2, .017, "#e2e8f0", AL_CENTER, 800);
      ry += rh + .008 * U; };
    row("SKIN", "skin", "TONE " + istr(pendLook.skin + 1), skinTone(pendLook.skin), true);
    row("FACE", "face", faceName(pendLook.face), Col(0, 0, 0), false);
    row("HAIR", "hair", hairName(pendLook.hair), Col(0, 0, 0), false);
    row("HAIR COLOUR", "hairc", hairCName(pendLook.hairC), hairCol(pendLook.hairC), true); }
  // right: the hockey side
  double ry = top, rh = .1 * U, ba = rw - .24 * U, bxa = rx + .22 * U, gp = .01 * U;
  panel(rx, ry, rw, rh, .62); T("JERSEY NUMBER", rx + .025 * U, ry + rh / 2, .024, "#fff");
  { double w1 = (ba - 4 * gp - .16 * U) / 4; double bx = bxa;
    ui("pnum:-10", bx, ry + rh * .2, w1, rh * .6, "-10", "#334155", true, .022); bx += w1 + gp; ui("pnum:-1", bx, ry + rh * .2, w1, rh * .6, "<", "#334155", true, .028); bx += w1 + gp;
    TB("#" + istr(pendNum), bx + .08 * U, ry + rh / 2, .044, "#fff", AL_CENTER); bx += .16 * U + gp;
    ui("pnum:1", bx, ry + rh * .2, w1, rh * .6, ">", "#334155", true, .028); bx += w1 + gp; ui("pnum:10", bx, ry + rh * .2, w1, rh * .6, "+10", "#334155", true, .022); }
  ry += rh + .012 * U; panel(rx, ry, rw, rh, .62); T("POSITION", rx + .025 * U, ry + rh * .38, .024, "#fff");
  T(pendPos == 'C' ? "Takes the draws." : "Plays the wing.", rx + .025 * U, ry + rh * .72, .0145, "#94a3b8", AL_LEFT, 700);
  { const char *pc[3] = {"C", "L", "R"}, *pn[3] = {"CENTER", "LEFT WING", "RIGHT WING"}; double w1 = (ba - 3 * gp) / 4;
    for (int i = 0; i < 3; i++) ui(std::string("ppos:") + pc[i], bxa + i * (w1 + gp), ry + rh * .18, w1, rh * .64, pn[i], pendPos == pc[i][0] ? "#16a34a" : "#334155", true, .019);
    ui("ppos:G", bxa + 3 * (w1 + gp), ry + rh * .18, w1, rh * .64, "GOALIE - SOON", "#475569", false, .016); btns.back().dis = true; }
  ry += rh + .012 * U; panel(rx, ry, rw, rh, .62); T("SHOOTS", rx + .025 * U, ry + rh / 2, .024, "#fff");
  { double w1 = (ba - gp) / 2; ui("psh:L", bxa, ry + rh * .18, w1, rh * .64, "LEFT", pendSh == 'L' ? "#16a34a" : "#334155", true, .024);
    ui("psh:R", bxa + w1 + gp, ry + rh * .18, w1, rh * .64, "RIGHT", pendSh == 'R' ? "#16a34a" : "#334155", true, .024); }
  ry += rh + .012 * U; double dh = rh * 1.3; panel(rx, ry, rw, dh, .62); T("DIFFICULTY", rx + .025 * U, ry + rh * .4, .024, "#fff");
  static const char *DN[3] = {"CASUAL", "STANDARD", "HARDCORE"}, *DC[3] = {"#16a34a", "#2563eb", "#dc2626"};
  static const char *DD[3] = {"Slower CPU skaters, wider faceoff windows, softer hits.", "The game as it's meant to be played.", "Faster, sharper CPU skaters. Every mistake costs you."};
  { double w1 = (ba - 2 * gp) / 3; for (int i = 0; i < 3; i++) ui("pdiff:" + istr(i), bxa + i * (w1 + gp), ry + rh * .14, w1, rh * .52, DN[i], pendDiff == i ? DC[i] : "#334155", true, .02); }
  TF(DD[pendDiff], rx + .025 * U, ry + dh * .8, .016, rw - .05 * U, "#94a3b8");
  ry += dh + .03 * U; double b2 = (rw - .02 * U) / 2;
  ui("pgo", rx, ry, b2, .085 * U, "START CAREER", "#16a34a", true, .03);
  ui("pncancel", rx + b2 + .02 * U, ry, b2, .085 * U, "BACK", "#475569", true, .03);
}
// draft night: the picks come in one by one until it's your turn
static void drawDraft() {
  double m = .03 * U, top = safeTop + .13 * U, t = (now() - draftT0) / 1000; int shown = std::min(C.dPick + 1, (int)(t / .11) + 1); bool done = shown > C.dPick;
  scrHead("DRAFT NIGHT", "ROUND 1  |  SEASON " + istr(C.season) + "  |  32 TEAMS, ONE PICK EACH");
  int cols = 4, rows = 8; double gap = .01 * U, cw = (W * .62 - 2 * m - (cols - 1) * gap) / cols, rh = std::min(.052 * U, (H - top - .16 * U) / rows - .005 * U);
  for (int k = 0; k < shown && k < 32; k++) { int c = k / rows, r = k % rows; double x = m + c * (cw + gap), y = top + r * (rh + .005 * U); int tm = C.dOrder[k]; bool me = k == C.dPick;
    panel(x, y, cw, rh, me ? .9 : .62); if (me) { ctx.fill(rgba(255, 213, 74, .25)); ctx.fillRect(x, y, cw, rh); }
    badge(x + rh * .5, y + rh / 2, rh * .36, tm); TF(istr(k + 1) + ". " + (me ? upper(C.nm) : upper(C.dNm[k])), x + rh * 1.0, y + rh / 2, .017, cw - rh * 1.1, me ? "#ffd54a" : "#e2e8f0"); }
  double rx = W * .62 + m * .5, rw = W - rx - m; panel(rx, top, rw, H - top - .14 * U);
  if (!done) { TB("ON THE CLOCK", rx + rw / 2, top + .08 * U, .04, "#fff", AL_CENTER); T("PICK " + istr(shown + 1), rx + rw / 2, top + .14 * U, .03, "#94a3b8", AL_CENTER); }
  else { T("WITH PICK #" + istr(C.dPick + 1) + ", THE", rx + rw / 2, top + .05 * U, .022, "#94a3b8", AL_CENTER, 700);
    TF(upper(teamFull(orgOf(C.me))), rx + rw / 2, top + .1 * U, .036, rw * .92, "#fff", AL_CENTER);
    T("SELECT", rx + rw / 2, top + .15 * U, .022, "#94a3b8", AL_CENTER, 700); TF(upper(C.nm), rx + rw / 2, top + .21 * U, .05, rw * .9, "#ffd54a", AL_CENTER);
    { double fy = top + .5 * U; softGlow(rx + rw / 2, fy, rw * .3, .025 * U, Col(255, 255, 255), .16); you(rx + rw / 2, fy, .26 * U / 6.2); }
    T("FORWARD  |  #" + istr(C.num) + "  |  AGE " + istr(C.age) + "  |  OVR " + istr(proOvr()), rx + rw / 2, top + .58 * U, .019, "#cbd5e1", AL_CENTER, 700);
    if (C.me >= NA) TF("ASSIGNED TO THE " + upper(C.L[C.me].n) + " (AHL)", rx + rw / 2, top + .625 * U, .019, rw * .92, "#ffd54a", AL_CENTER);
    ui("draftdone", (W - .44 * U) / 2, H - .11 * U, .44 * U, .08 * U, "START YOUR CAREER", "#16a34a", true, .034); }
}

// ---------------------------------------------------------------- the hub
[[maybe_unused]] static void drawHub() {
  if (C.showTrade && C.hasTrade) { screen = "trade"; return; }
  bool land = W > H * 1.15; double m = .03 * U; PP *Y = youMe(); PTeam &r = C.L[C.me]; std::string ph = C.phase;
  // top: your card, your season, your wallet
  double ty = safeTop + .012 * U, th = .1 * U, av = th * .9;
  panel(m, ty, av, av, .7); you(m + av / 2, ty + av * 2.3, av * 2.4 / 6.2, m + 2, ty + 2, m + av - 2, ty + av - 2);   // head and shoulders
  double cx = m + av + .02 * U; T("OVR", cx, ty + th * .2, .0204, "#94a3b8", AL_LEFT, 700); TB(istr(proOvr()), cx, ty + th * .6, .05, "#fff");
  cx += .085 * U; TB(upper(C.nm), cx, ty + th * .3, .034, "#fff");
  TF("#" + istr(C.num) + " | C | " + upper(r.n) + (C.me >= NA ? " (AHL)" : "") + " | AGE " + istr(C.age) + " | YEAR " + istr(C.season), cx, ty + th * .68, .0216, (land ? W * .52 - .05 * U : W - .5 * U) - cx, "#cbd5e1");
  int gp, sg, sa; proLine(gp, sg, sa);
  std::pair<std::string, std::string> sl[4] = {{"GP", istr(gp)}, {"G", istr(sg)}, {"A", istr(sa)}, {"PTS", istr(sg + sa)}};
  if (land) for (int k = 0; k < 4; k++) { double xx = W * .52 + k * .075 * U; T(sl[k].first, xx, ty + th * .25, .0198, "#94a3b8", AL_CENTER, 700); TB(sl[k].second, xx, ty + th * .62, .03, "#fff", AL_CENTER); }
  std::pair<std::string, std::string> wl3[3] = {{"XP", fmtN(C.xp)}, {"CASH", "$" + fmtN(C.money)}, {C.me >= NA ? "CALL-UP" : "CUPS", C.me >= NA ? istr(readiness()) + "/" + istr(callBar()) : istr(C.titles)}};
  for (int k = 0; k < 3; k++) { double xx = W - m - (2 - k) * .11 * U - .05 * U; T(wl3[k].first, xx, ty + th * .25, .0198, "#94a3b8", AL_CENTER, 700); TB(wl3[k].second, xx, ty + th * .62, .03, k == 0 ? "#ffd54a" : "#fff", AL_CENTER); }
  double top = ty + th + .02 * U, bot = H - .07 * U;
  double clx = m, clw = W * .25, cmx = m + W * .25 + .02 * U, cmw = W * .47, crx = m + W * .72 + .03 * U, crw = W - crx - m;
  // centre: key art, the headline, the matchup
  double heroH = (bot - top) * .6, hy = top;
  std::string head, tag;
  std::string cupN = C.me >= NA ? "the Calder Cup" : "the Stanley Cup";
  if (ph == "over") { head = C.champ == C.me ? "Champions! The " + r.n + " lift " + cupN : "Season over: the " + C.L[C.champ < 0 ? 0 : C.champ].n + " win " + cupN; tag = "OFF-SEASON"; }
  else { head = headline(); tag = std::string(C.me >= NA ? "AHL " : "NHL ") + (ph == "po" ? "PLAYOFFS  |  " + std::string(RN[std::min(3, C.round)]) : "REGULAR SEASON"); }
  heroArt(cmx, hy, cmw, heroH, youSpec(), C.season * 31 + C.me);
  { double hfs = std::min(.042 * U, cmw * .055); std::vector<std::string> lines; for (int k = 0; k < 8; k++) { ctx.font(hfs); lines = wrapText(head, cmw * .9); if (lines.size() <= 2) break; hfs *= .9; }
    if (lines.size() > 3) lines.resize(3); double lh = hfs * 1.12, bh = lines.size() * lh + .05 * U; ctx.fill(rgba(8, 12, 24, .55)); ctx.fillRect(cmx, hy + heroH - bh, cmw, bh);
    for (size_t k = 0; k < lines.size(); k++) { ctx.font(hfs); ctx.fill("#fff"); ctx.textMid(AL_LEFT); ctx.fillText(lines[k], cmx + .025 * U, hy + heroH - .052 * U - (lines.size() - 1 - k) * lh); }
    TXL = cmx; TXR = cmx + cmw - .02 * U; T(tag + (ph == "reg" ? "  |  GAME " + istr(std::min(C.day + 1, PRO_GAMES)) + " OF " + istr(PRO_GAMES) + (C.cal.empty() ? "" : "  |  " + calDate(C.ci)) : ""), cmx + .025 * U, hy + heroH - .018 * U, .018, "#cbd5e1", AL_LEFT, 700); TXL = 0; TXR = 1e4; }
  double my = hy + heroH + .012 * U, mh = (bot - my) * .62; panel(cmx, my, cmw, mh, .8);
  if (ph != "over" && ph != "retired") {
    double br = mh * .24; int o = C.opp; PTeam &O = C.L[o];
    badge(cmx + br * 1.4, my + mh * .36, br, C.me); badge(cmx + cmw - br * 1.4, my + mh * .36, br, o);
    double nmW = cmw / 2 - br * 2.7 - .045 * U; TF(upper(r.n), cmx + br * 2.7, my + mh * .3, .03, nmW, "#fff"); T(istr(r.w) + "-" + istr(r.l), cmx + br * 2.7, my + mh * .52, .0204, "#94a3b8", AL_LEFT, 700);
    TF(upper(O.n), cmx + cmw - br * 2.7, my + mh * .3, .03, nmW, "#fff", AL_RIGHT); T(istr(O.w) + "-" + istr(O.l), cmx + cmw - br * 2.7, my + mh * .52, .0204, "#94a3b8", AL_RIGHT, 700);
    TB(proAway() ? "AT" : "VS", cmx + cmw / 2, my + mh * .3, .0228, "#f26b5b", AL_CENTER); T(proAway() ? "ROAD" : "HOME", cmx + cmw / 2, my + mh * .41, .013, "#94a3b8", AL_CENTER, 800); T(ph == "po" ? "SERIES " + istr(C.sw) + "-" + istr(C.sl) : "GAME " + istr(C.day + 1), cmx + cmw / 2, my + mh * .52, .0192, "#94a3b8", AL_CENTER, 700);
    // recent results and what's next
    struct Cell { int t; std::string s; const char *c; }; std::vector<Cell> cells; int n0 = 0;
    for (int i = (int)C.hist.size() - 1; i >= 0 && n0 < 2; i--) if (!C.hist[i].po) { n0++; const PHist &h = C.hist[i]; cells.insert(cells.begin(), {h.o, (h.w ? "W " : "L ") + istr(h.hs) + "-" + istr(h.as), h.w ? "#7CFC9A" : "#fca5a5"}); }
    if (ph == "reg") for (int k = 0; k < 5 && C.day + k < (int)C.sched.size(); k++) { int gi = -1; for (size_t i = 0; i < C.cal.size(); i++) if (C.cal[i] == C.day + k) gi = (int)i; cells.push_back({C.sched[C.day + k], gi >= 0 ? calDate(gi) : "G" + istr(C.day + k + 1), k ? "#94a3b8" : "#f26b5b"}); }
    double cw = cmw / std::max<size_t>(7, cells.size()), cy0 = my + mh * .68, rowH = mh * .3; ctx.fill(rgba(255, 255, 255, .05)); ctx.fillRect(cmx, cy0, cmw, rowH);
    for (size_t k = 0; k < cells.size(); k++) { double xx = cmx + cw * (k + .5) + (cmw - cw * cells.size()) / 2; badge(xx - cw * .3, cy0 + rowH / 2, rowH * .28, cells[k].t); TXR = xx + cw * .47; T(cells[k].s, xx - cw * .16, cy0 + rowH / 2 + 1, .0155, cells[k].c, AL_LEFT, 800); TXR = 1e4; }
    pushBtn("nav:sched", cmx, my, cmw, mh, "", true);
  } else {
    TRank rk = teamRank(C.me); std::string run = "MISSED THE PLAYOFFS";
    for (size_t ri = 0; ri < C.br.size(); ri++) { const PSeries *s = nullptr; for (auto &x : C.br[ri]) if (x.a == C.me || x.b == C.me) s = &x; if (!s) break; int opp = s->a == C.me ? s->b : s->a;
      run = s->w == C.me ? (ri == 3 ? (C.me >= NA ? "WON THE CALDER CUP" : "WON THE STANLEY CUP") : "WON THE " + std::string(RN[ri])) : "LOST IN THE " + std::string(RN[ri]) + " TO THE " + upper(C.L[opp].n); }
    badge(cmx + mh * .32, my + mh * .36, mh * .22, C.me);
    TF(upper(r.n) + "   " + istr(r.w) + "-" + istr(r.l), cmx + mh * .62, my + mh * .26, .032, cmw - mh * .7, "#fff");
    TF(upper(ordn(rk.div)) + " IN THE " + divName(C.me) + "  |  " + upper(ordn(rk.all)) + " OVERALL  |  " + run, cmx + mh * .62, my + mh * .48, .017, cmw - mh * .7, run[0] == 'W' ? "#7CFC9A" : "#cbd5e1");
    ctx.fill(rgba(255, 255, 255, .05)); ctx.fillRect(cmx, my + mh * .68, cmw, mh * .3);
    T("YOUR SEASON", cmx + .02 * U, my + mh * .83, .015, "#94a3b8"); TB(istr(sg) + " G   " + istr(sa) + " A   " + istr(sg + sa) + " PTS", cmx + cmw - .02 * U, my + mh * .83, .022, "#ffd54a", AL_RIGHT);
  }
  // left: the menu
  double ly = top; bool off = offDay(), hurt = ph != "over" && userHurt(), need = C.need; int nOff = (int)C.offers.size();
  std::string hd = ph == "over" ? "OFF-SEASON" : need ? "CONTRACT EXPIRED" : off ? "OFF DAY  |  " + calDate(C.ci) : hurt ? "INJURED  |  " + istr(Y->inj) + (Y->inj == 1 ? " GAME LEFT" : " GAMES LEFT") : "UP NEXT" + (ph == "reg" && !C.cal.empty() ? "  |  " + calDate(C.ci) : "");
  T(hd, clx, ly + .012 * U, .0198, off || need || hurt ? "#f26b5b" : "#94a3b8"); ly += .03 * U;
  double ih = std::min(.06 * U, (bot - ly) / 9.7);
  auto big = [&](const std::string &id, const std::string &lb) { menuItem(id, lb, clx, ly, clw, ih * 1.15, true, true); ly += ih * 1.3; };
  std::vector<std::pair<std::string, std::string>> items;
  if (need) big("off:neg", "SIGN YOUR CONTRACT");
  else if (off) { big("skipday", "REST (SKIP DAY)"); items.push_back({"nav:train", "TRAIN  ($" + istr(trainCost()) + ")"}); items.push_back({"sim1", "SIM TO NEXT GAME"}); }
  else if (ph == "over") big("next", "NEXT SEASON");
  else if (hurt) { big("simheal", "SIM UNTIL HEALTHY"); items.push_back({"sim1", "SIM ONE GAME"}); }
  else { big("play", "PLAY NEXT GAME"); items.push_back({"sim1", "SIM GAME"}); items.push_back({"simN", ph == "po" ? "SIM SERIES" : "SIM 10 GAMES"}); }
  items.push_back({"nav:upg", "UPGRADES"}); items.push_back({"nav:office", "OFFICE" + std::string(need ? "  (!)" : nOff ? "  (" + istr(nOff) + (nOff > 1 ? " OFFERS)" : " OFFER)") : C.hasTreq ? "  (TRADE ASKED)" : "")});
  items.push_back({"nav:shop", "GEAR SHOP"}); items.push_back({"nav:sched", "SCHEDULE"}); items.push_back({"nav:stand", "LEAGUE"}); items.push_back({"nav:modes", "MAIN MENU"});
  double ih2 = std::min(ih, (bot - ly - .01 * U) / items.size());
  for (auto &it : items) { menuItem(it.first, it.second, clx, ly, clw, ih2, false, false); ly += ih2; }
  // right: headlines and the weekly goals
  double ry = top, hh = (bot - top) * .46; panel(crx, ry, crw, hh, .6);
  TB("TOP HEADLINES", crx + .012 * U, ry + .022 * U, .0216, "#f26b5b");
  double yy = ry + .05 * U; ctx.font(.0195 * U); int nh = 0;
  { std::string pn = C.me >= NA || (youMe() && youMe()->isCu) ? prospectNote() : ""; if (!pn.empty()) { nh = 1;   // the organization's view of you comes first
      T("FROM THE " + upper(C.L[orgOf(C.me)].n) + " FRONT OFFICE", crx + .012 * U, yy, .014, "#ffd54a", AL_LEFT, 800); yy += .022 * U;
      auto ls = wrapText(pn, crw - .045 * U); if (ls.size() > 3) ls.resize(3); for (auto &l : ls) { T(l, crx + .012 * U, yy, .0165, "#fde68a", AL_LEFT, 700); yy += .022 * U; }
      yy += .012 * U; ctx.fill(rgba(148, 163, 184, .15)); ctx.fillRect(crx + .012 * U, yy - .015 * U, crw - .024 * U, 1); } }
  for (auto &h : C.log) { if (nh++ >= 4 || yy > ry + hh - .05 * U) break; auto ls = wrapText(h.s, crw - .045 * U); if (ls.size() > 2) ls.resize(2);
    for (auto &l : ls) { T(l, crx + .012 * U, yy, .0165, "#e2e8f0", AL_LEFT, 700); yy += .022 * U; } T("Season " + istr(h.y), crx + .012 * U, yy, .014, "#64748b", AL_LEFT, 700); yy += .03 * U;
    ctx.fill(rgba(148, 163, 184, .15)); ctx.fillRect(crx + .012 * U, yy - .015 * U, crw - .024 * U, 1); }
  if (C.log.empty()) T("No news yet.", crx + .012 * U, yy, .0165, "#64748b");
  ry += hh + .012 * U; panel(crx, ry, crw, bot - ry, .6);
  { double x = crx + .012 * U, w = crw - .024 * U, y = ry + .025 * U; TB("WEEKLY GOALS", x, y, .0216, "#f26b5b");
    if (ph == "reg" && C.wk.w >= 0) { y += .026 * U; int left = 7 - (C.ci % 7); T("WEEK " + istr(C.wk.w + 1) + "  |  " + istr(left) + (left == 1 ? " DAY" : " DAYS") + " LEFT", x, y, .014, "#94a3b8", AL_LEFT, 700); }
    y += .032 * U;
    if (ph != "reg" || C.wk.goals.empty()) txWrap(ph == "reg" ? "No games this week." : "Weekly goals return next regular season.", x, y + .01 * U, .016, w, hex("#64748b"), AL_LEFT, 700, 2);
    else for (auto &g : C.wk.goals) { std::string cnt = istr(std::min(g.pr, g.tg)) + " / " + istr(g.tg); const char *c = g.done ? "#7CFC9A" : "#e2e8f0";
      T(cnt, x + w, y, .0175, c, AL_RIGHT, 700); TXL = x; TXR = x + w - .07 * U; T(g.txt, x, y, .016, c, AL_LEFT, 700); TXL = 0; TXR = 1e4;
      ctx.fill(rgba(148, 163, 184, .25)); ctx.fillRect(x, y + .014 * U, w, 3); ctx.fill(c); ctx.fillRect(x, y + .014 * U, w * clamp((double)g.pr / g.tg, 0, 1), 3);
      T("+" + istr(g.xp) + " XP  +$" + istr(g.cash), x + w, y + .03 * U, .0155, "#ffd54a", AL_RIGHT, 700); y += .062 * U; } }
  // the latest result / sim message
  std::string msg = !C.wkMsg.empty() ? C.wkMsg : !C.injMsg.empty() ? C.injMsg : !C.offMsg.empty() && screen == "main" && false ? C.offMsg : proMsg;
  if (!msg.empty()) { double px = std::min(.02 * U, (W - .06 * U) / std::max<size_t>(1, msg.size()) * 1.7); ctx.font(px); double tw = ctx.measure(msg) + .04 * U;
    ctx.fill(rgba(8, 12, 24, .9)); ctx.rr(W / 2 - tw / 2, bot + .006 * U, tw, .036 * U, .018 * U); ctx.fillPath(); ctx.fill("#ffd54a"); ctx.textMid(); ctx.fillText(msg, W / 2, bot + .024 * U); }
  else footHints({{"D-PAD", "MOVE"}, {"X", "SELECT"}, {"O", "MAIN MENU"}, {"START", "PAUSE IN GAME"}});
}

// ---------------------------------------------------------------- upgrades: ratings and perks
static const char *UPK[15] = {"skate", "edge", "deke", "hand", "pass", "sacc", "wpow", "slacc", "spow", "bha", "bhp", "check", "poise", "fstam", "fo"};
static void drawUpg() {
  double m = .03 * U, top = safeTop + .19 * U;
  scrHead("UPGRADES", "SPEND XP ON YOUR RATINGS AND PERKS  |  OVR " + istr(proOvr()) + "  |  L / R: SWITCH TABS"); xpTagTop(); cashTag();
  ui("utab:0", m, safeTop + .115 * U, .24 * U, .055 * U, "RATINGS", upTab == 0 ? "#f26b5b" : "#334155", true, .026); btns.back().np = true;
  ui("utab:1", m + .25 * U, safeTop + .115 * U, .24 * U, .055 * U, "PERKS", upTab == 1 ? "#f26b5b" : "#334155", true, .026); btns.back().np = true;
  if (upTab == 0) {
    int cols = 3, rows = 5; double gap = .012 * U, cw = (W - 2 * m - (cols - 1) * gap) / cols, rh = std::min(.098 * U, (H - top - .13 * U) / rows - .008 * U);
    for (int i = 0; i < 15; i++) { std::string k = UPK[i]; int c = i / rows, r = i % rows; double x = m + c * (cw + gap), y = top + r * (rh + .008 * U); int v = g_stats(k).i(50), gp = (int)gearPts(k);
      panel(x, y, cw, rh, .7); T(FNICE(k), x + .015 * U, y + rh * .25, .019, "#cbd5e1", AL_LEFT, 800);
      TB(istr(v), x + .015 * U, y + rh * .65, .038, v >= 90 ? "#ffd54a" : "#fff"); if (gp) T((gp > 0 ? "+" : "") + istr(gp) + " GEAR", x + .085 * U, y + rh * .67, .014, gp > 0 ? "#7dd3fc" : "#fca5a5", AL_LEFT, 700);
      double pr = 0; auto it = C.sxp.find(k); if (it != C.sxp.end()) pr = it->second; ctx.fill(rgba(148, 163, 184, .25)); ctx.fillRect(x + .015 * U, y + rh * .88, cw * .38, 3); ctx.fill("#ffd54a"); ctx.fillRect(x + .015 * U, y + rh * .88, cw * .38 * clamp(pr, 0, 1), 3);
      int m1, m5, c1 = proCostN(k, 1, &m1), c5 = proCostN(k, 5, &m5); double bw = cw * .26, bh = rh * .6, by = y + rh * .2;
      ui("up1:" + k, x + cw - 2 * bw - .02 * U, by, bw, bh, m1 ? "+1  " + fmtN(c1) : "MAX", "#16a34a", m1 && C.xp >= c1, .018); if (!(m1 && C.xp >= c1)) btns.back().dis = true;
      ui("up5:" + k, x + cw - bw - .01 * U, by, bw, bh, m5 ? "+" + istr(m5) + "  " + fmtN(c5) : "MAX", "#2563eb", m5 && C.xp >= c5, .018); if (!(m5 && C.xp >= c5)) btns.back().dis = true; }
    T("Ratings also grow on their own as you play: shoot to build your shot, hit to build checking, skate to build speed.", W / 2, H - .1 * U, .016, "#94a3b8", AL_CENTER, 700);
  } else {
    int n = pkSlots(proOvr()); std::vector<int> ids; for (int i = 0; i < PK_N; i++) if (PERKS[i].pos == 'F' && !PERKS[i].user) ids.push_back(i);
    std::string eq; for (auto &e : C.perkEq) { int i = perkIndex(e); if (i >= 0) eq += (eq.empty() ? "" : ", ") + std::string(PERKS[i].n); }
    T("PERK SLOTS: " + istr(n) + "   (1 SLOT AT 78 OVR, 2 AT 89)   |   EQUIPPED: " + (eq.empty() ? "NONE" : eq), m, top - .01 * U, .017, "#cbd5e1", AL_LEFT, 700);
    double rh = std::min(.072 * U, (H - top - .13 * U) / ids.size() - .006 * U);
    for (size_t j = 0; j < ids.size(); j++) { const PerkDef &P = PERKS[ids[j]]; std::string id = P.id; double y = top + .015 * U + j * (rh + .006 * U);
      bool own = std::find(C.perkOwn.begin(), C.perkOwn.end(), id) != C.perkOwn.end(), on = std::find(C.perkEq.begin(), C.perkEq.end(), id) != C.perkEq.end();
      int tier = proUserTier(P), lv = own ? std::max(1, C.perkLv[id]) : 0, myT = own ? pkMine(id) : 0;
      panel(m, y, W - 2 * m, rh, on ? .85 : .66); if (on) { ctx.fill(rgba(56, 189, 248, .16)); ctx.fillRect(m, y, W - 2 * m, rh); }
      ctx.fill(TIERC[myT]); ctx.disc(m + rh * .5, y + rh / 2, rh * .34); ctx.fill(P.col); ctx.disc(m + rh * .5, y + rh / 2, rh * .27); ctx.fill("#fff"); ctx.font(rh * .24); ctx.textMid(); ctx.fillText(P.ab, m + rh * .5, y + rh / 2 + 1);
      TB(P.n, m + rh, y + rh * .22, .02, "#fff"); TXR = W * .62;
      { std::string d = std::string(P.d) + (myT ? "  -  NOW: " + std::string(P.td[myT - 1]) : "  -  BRONZE: " + std::string(P.td[0])); TF(d, m + rh, y + rh * .52, .0135, W - 2 * m - rh - .44 * U, "#e2e8f0", AL_LEFT); }
      T(std::string(FNICE(P.k)) + " " + istr(P.rq[0]) + " / " + istr(P.rq[1]) + " / " + istr(P.rq[2]) + " FOR BRONZE / SILVER / GOLD  |  YOU: " + istr(userRatings().get(P.k)) + (own ? "  |  OWNED: " + std::string(TIERN[std::max(1, myT)]) + (lv > myT && myT ? "" : "") : ""), m + rh, y + rh * .82, .0125, tier ? "#94a3b8" : "#fca5a5", AL_LEFT, 700); TXR = 1e4;
      double bw = .2 * U, bh = rh * .62, bx = W - m - .015 * U - bw, by = y + (rh - bh) / 2;
      if (!own) { bool ok = C.xp >= P.c; ui("pbuy:" + id, bx, by, bw, bh, "BUY  " + fmtN(P.c) + " XP", "#16a34a", ok, .018); if (!ok) btns.back().dis = true; }
      else { int nx = lv + 1, c = pkUpCost(P, nx); bool ok = nx <= 3 && C.xp >= c && tier >= nx;
        ui("pup:" + id, bx - bw - .01 * U, by, bw, bh, nx > 3 ? "GOLD" : "TO " + std::string(TIERN[nx]) + "  " + fmtN(c), "#d97706", ok, .017); if (!ok) btns.back().dis = true;
        bool eok = on || (n > 0 && tier > 0); ui("peq:" + id, bx, by, bw, bh, on ? "UNEQUIP" : n ? "EQUIP" : "NEED 78 OVR", on ? "#0891b2" : "#2563eb", eok, .018); if (!eok) btns.back().dis = true; } }
    (void)perkSel;
  }
  back("nav:main", H - .085 * U);
}
static void drawTrain() {
  double m = .03 * U, top = safeTop + .14 * U; bool can = canTrain(); int c = trainCost();
  scrHead("TRAINING", can ? "OFF DAY  |  ONE SESSION A DAY  |  $" + istr(c) + " A SESSION" : "TRAINING IS FOR OFF DAYS"); cashTag();
  static const char *TN[4] = {"SKATING", "SHOOTING", "PLAYMAKING", "PHYSICAL"};
  static const char *TK[4][4] = {{"skate", "edge", nullptr, nullptr}, {"sacc", "wpow", "slacc", "spow"}, {"pass", "hand", "deke", "fo"}, {"check", "poise", "fstam", nullptr}};
  double gw = (W - 2 * m - .036 * U) / 4, gh = .34 * U;
  for (int i = 0; i < 4; i++) { double x = m + i * (gw + .012 * U); panel(x, top, gw, gh); topLine(x, top, gw, hex("#f26b5b"));
    TB(TN[i], x + gw / 2, top + .05 * U, .03, "#fff", AL_CENTER); double y = top + .1 * U;
    for (int k = 0; k < 4 && TK[i][k]; k++) { T(FNICE(TK[i][k]), x + .02 * U, y, .017, "#cbd5e1", AL_LEFT, 700); T(istr(g_stats(TK[i][k]).i(50)), x + gw - .02 * U, y, .02, "#fff", AL_RIGHT, 900); y += .035 * U; }
    bool ok = can && C.money >= c; ui("train:" + istr(i), x + .015 * U, top + gh - .075 * U, gw - .03 * U, .06 * U, "TRAIN  $" + istr(c), "#16a34a", ok, .024); if (!ok) btns.back().dis = true; }
  txWrap("A session pushes every rating in the group toward its next point. Training uses up the off day.", W / 2, top + gh + .05 * U, .018, W - 2 * m, hex("#94a3b8"), AL_CENTER, 700, 2);
  back("nav:main", H - .11 * U);
}
static void drawShop() {
  double m = .03 * U; shopCat = std::max(0, std::min(shopCat, (int)GEARF.size() - 1));
  scrHead("GEAR SHOP", "STICKS, HELMETS, SKATES AND PADS  |  EVERYTHING COSTS CASH  |  L / R: CATEGORY"); cashTag();
  double ty = safeTop + .12 * U, tw = (W - 2 * m - .012 * U * (GEARF.size() - 1)) / GEARF.size();
  for (size_t i = 0; i < GEARF.size(); i++) { ui("gcat:" + istr(i), m + i * (tw + .012 * U), ty, tw, .055 * U, GEARF[i].n, shopCat == (int)i ? "#f26b5b" : "#334155", true, .024); btns.back().np = true; }
  const GearCat &cat = GEARF[shopCat]; double y0 = ty + .08 * U, rh = std::min(.1 * U, (H - y0 - .3 * U) / cat.it.size() - .01 * U);
  int eqI = -1; { auto it = C.gearEq.find(cat.k); if (it != C.gearEq.end()) eqI = it->second; else for (size_t i = 0; i < cat.it.size(); i++) if (!cat.it[i].c) { eqI = (int)i; break; } }
  for (size_t i = 0; i < cat.it.size(); i++) { const GearIt &it = cat.it[i]; double y = y0 + i * (rh + .01 * U); bool eq = eqI == (int)i, own = !it.c || C.gearOwn.count(std::string(cat.k) + ":" + istr(i));
    panel(m, y, W - 2 * m, rh); if (eq) { ctx.fill(rgba(56, 189, 248, .16)); ctx.rr(m, y, W - 2 * m, rh, std::min(.02 * U, rh * .3)); ctx.fillPath(); accentBar(m, y, rh, hex("#38bdf8")); }
    TB(it.n, m + .03 * U, y + rh * .3, .028, "#fff"); T(it.d, m + .03 * U, y + rh * .62, .016, "#cbd5e1", AL_LEFT, 700);
    std::string fx = fxTxt(it.fx); if (it.inj != 1) fx += std::string(fx.empty() ? "" : "   ") + (it.inj < 1 ? "-" : "+") + istr((int)jround(std::fabs(1 - it.inj) * 100)) + "% INJURY RISK";
    TF(fx.empty() ? "NO RATING CHANGES" : fx, m + .03 * U, y + rh * .86, .0155, W * .6, fx.empty() ? "#64748b" : "#7dd3fc");
    double bw = .26 * U, bh = rh * .56, bx = W - m - bw - .02 * U, by = y + (rh - bh) / 2;
    if (eq) TB("EQUIPPED", bx + bw / 2, y + rh / 2, .026, "#38bdf8", AL_CENTER);
    else { bool ok = own || C.money >= it.c; ui("gear:" + std::string(cat.k) + ":" + istr(i), bx, by, bw, bh, own ? "EQUIP" : "BUY  $" + fmtN(it.c), own ? "#2563eb" : "#16a34a", ok, .026); if (!ok) btns.back().dis = true; } }
  double py = y0 + cat.it.size() * (rh + .01 * U) + .015 * U, ph = std::min(.15 * U, H - .13 * U - py);
  if (ph > .08 * U) { panel(m, py, W - 2 * m, ph, .6); T("WHAT YOU ARE WEARING", m + .02 * U, py + .025 * U, .016, "#f26b5b");
    double cw = (W - 2 * m - .04 * U) / GEARF.size();
    for (size_t i = 0; i < GEARF.size(); i++) { const GearCat &g = GEARF[i]; int e = 0; auto it = C.gearEq.find(g.k); if (it != C.gearEq.end()) e = it->second; else for (size_t j = 0; j < g.it.size(); j++) if (!g.it[j].c) { e = (int)j; break; }
      T(g.n, m + .02 * U + i * cw, py + .06 * U, .014, "#94a3b8", AL_LEFT, 700); TB(g.it[e].n, m + .02 * U + i * cw, py + .088 * U, .022, "#fff"); }
    std::string tot; for (auto k : FKEYS) { int v = (int)gearPts(k); if (v) tot += (tot.empty() ? "" : "   ") + std::string(v > 0 ? "+" : "") + istr(v) + " " + FNICE(k); }
    TF("TOTAL:  " + (tot.empty() ? std::string("NO RATING CHANGES") : tot) + (gearInj() != 1 ? "   INJURY RISK x" + fixed(gearInj(), 2) : ""), m + .02 * U, py + ph - .025 * U, .016, W - 2 * m - .04 * U, "#ffd54a"); }
  back("nav:main", H - .1 * U);
}

// ---------------------------------------------------------------- the office
static void drawOffice() {
  PP *Y = youMe(); double m = .03 * U, top = safeTop + .115 * U, bot = H - .075 * U, cap = capOf(), pay = payroll(orgOf(C.me)); PTeam &L = C.L[orgOf(C.me)];
  scrHead("OFFICE", "GENERAL MANAGER  |  " + upper(L.city + " " + L.n) + (C.need ? "  |  YOUR CONTRACT HAS EXPIRED" : "")); cashTag();
  double lw = W * .34, lx = m; panel(lx, top, lw, bot - top); accentBar(lx, top, bot - top, hex("#f26b5b"));
  double y = top + .045 * U; badge(lx + .05 * U, y, .03 * U, orgOf(C.me)); T(C.me >= NA ? "YOUR CONTRACT  |  TWO-WAY" : "YOUR CONTRACT", lx + .095 * U, y - .014 * U, .016, "#94a3b8", AL_LEFT, 700); TF(upper(L.n), lx + .095 * U, y + .016 * U, .03, lw - .12 * U, "#fff");
  y += .07 * U;
  auto row = [&](const std::string &k, const std::string &v, const char *c) { T(k, lx + .025 * U, y, .017, "#94a3b8", AL_LEFT, 700); TF(v, lx + lw - .025 * U, y, .023, lw * .55, c, AL_RIGHT); ctx.fill(rgba(148, 163, 184, .15)); ctx.fillRect(lx + .025 * U, y + .021 * U, lw - .05 * U, 1); y += .047 * U; };
  row("SALARY", money2(Y->sal) + " / YR", "#fff");
  row("CONTRACT", C.deals ? (C.perfB ? "STANDARD + PERFORMANCE BONUSES" : "STANDARD") : "ENTRY-LEVEL", C.deals ? "#fff" : "#fde68a");
  row("YEARS LEFT", C.need ? "EXPIRED" : istr(Y->cy) + (Y->cy == 1 ? "  (FINAL YEAR)" : ""), C.need || Y->cy <= 1 ? "#fca5a5" : "#fff");
  row("NO-TRADE CLAUSE", C.ntc ? "YES" : "NO", C.ntc ? "#7CFC9A" : "#cbd5e1");
  if (Y->hasExt) row("NEXT CONTRACT", istr(Y->extYrs) + " x " + money2(Y->extSal) + (Y->extNtc ? " + NTC" : ""), "#7CFC9A");
  row("GAME PAY", "$" + istr(gamePay()) + " PER GAME", "#ffd54a");
  row("MARKET VALUE", money2(market(proOvr())), "#fff");
  row("TEAM PAYROLL", "$" + fixed(pay, 1) + "M / $" + fixed(cap, 1) + "M", pay > cap ? "#fca5a5" : "#7CFC9A");
  y += .012 * U; meter(lx + .025 * U, y, lw - .05 * U, perfScore(), "#38bdf8", "PERFORMANCE"); y += .05 * U; meter(lx + .025 * U, y, lw - .05 * U, loyalty(), "#f59e0b", "LOYALTY");
  if (false) { double cv = clamp(C.coach / 100, 0, 1); const char *cc = C.coach >= 70 ? "#4ade80" : C.coach >= 50 ? "#a3e635" : C.coach >= 35 ? "#fbbf24" : "#f87171";   // (moved to My Team)
    const char *word = C.coach >= 80 ? "LOVES YOUR GAME" : C.coach >= 65 ? "TRUSTS YOU" : C.coach >= 50 ? "LIKES WHAT HE SEES" : C.coach >= 35 ? "WANTS MORE" : "ON THIN ICE";
    static const char *LNS[3] = {"1ST LINE", "2ND LINE", "3RD LINE"};
    y += .05 * U; meter(lx + .025 * U, y, lw - .05 * U, cv, cc, "COACH'S APPRECIATION");
    std::string dl = std::fabs(C.coachD) >= .05 ? std::string(" (") + (C.coachD > 0 ? "+" : "") + fmt("%.1f", C.coachD) + ")" : "";
    y += .042 * U; TF(std::string(word) + dl + "  |  " + LNS[std::max(0, std::min(2, C.line))] + (C.cen ? "  |  CENTER" : "  |  WING"), lx + .025 * U, y, .0145, lw - .05 * U, cc); }
  y += .06 * U; T("BIGGEST CONTRACTS", lx + .025 * U, y, .016, "#f26b5b"); y += .03 * U;
  std::vector<PP *> big; for (auto &q : C.P) if ((q->t == orgOf(C.me) || q->me) && !q->isCu) big.push_back(q.get()); std::sort(big.begin(), big.end(), [](PP *a, PP *b) { return a->sal > b->sal; });
  for (PP *q : big) { if (y > bot - .02 * U) break; TF(q->nm() + (q->g ? " (G)" : ""), lx + .025 * U, y, .016, lw * .55, q->me ? "#ffd54a" : "#e2e8f0"); T("$" + fixed(q->sal, 1) + "M  " + istr(q->cy) + "Y", lx + lw - .025 * U, y, .016, "#7CFC9A", AL_RIGHT); y += .029 * U; }
  double mx = lx + lw + .03 * U, mw = W * .29, my = top; T("ACTIONS", mx, my + .012 * U, .017, "#f26b5b"); my += .04 * U;
  double ih = .064 * U; bool canExt = !C.need && C.phase != "over" && C.phase != "retired" && Y->cy <= 1 && !Y->hasExt; int n = (int)C.offers.size();
  struct Act { std::string id, lb; bool on; } act[4] = {{"off:neg", C.need ? "SIGN NEW CONTRACT" : "NEGOTIATE EXTENSION", C.need || canExt},     {"nav:treq", C.hasTreq ? "TRADE REQUESTED" : "REQUEST A TRADE", tradeOpen() && !C.hasTreq && !C.need}, {"nav:toff", "TRADE OFFERS" + (n ? "  (" + istr(n) + ")" : std::string()), true}, {"nav:main", "BACK", true}};
  for (int k = 0; k < 4; k++) { menuItem(act[k].id, act[k].lb, mx, my, mw, ih, false, k == 0 && C.need); if (!act[k].on) dimOut(mx, my, mw, ih); my += ih * 1.14; }
  my += .01 * U; txWrap(C.need ? "You cannot play until you sign - or walk away into free agency." : !canExt ? "Extensions open in the final year of your deal." : "Sign now and the new deal starts next season.", mx, my + .02 * U, .016, mw, hex("#94a3b8"), AL_LEFT, 700, 3);
  double rx = mx + mw + .03 * U, rw = W - rx - m; panel(rx, top, rw, bot - top);
  double ry = top + .035 * U; TB("INBOX", rx + .02 * U, ry, .022, "#f26b5b"); ry += .045 * U;
  auto note = [&](const std::string &t, const char *c) { if (ry > bot - .03 * U) return; ctx.font(fsz(.0165) * U); for (auto &l : wrapText(t, rw - .04 * U)) { if (ry > bot - .02 * U) return; T(l, rx + .02 * U, ry, .0165, c, AL_LEFT, 700); ry += .025 * U; } ry += .014 * U; };
  if (!C.offMsg.empty()) note(C.offMsg, "#ffd54a");
  { std::string pn = prospectNote(); if (!pn.empty()) note("PROSPECT REPORT: " + pn, "#fde68a"); }
  if (C.need) note("Your contract is up and the " + L.n + " want to talk. Sign here before your next game - or walk away and test free agency.", "#fca5a5");
  if (C.hasTreq) { std::string l; for (int t : C.treqT) l += C.L[t].ab + " "; note("TRADE REQUEST: you move in " + istr(std::max(0, C.treqAt - C.ci)) + " day(s). Your list: " + l, "#e2e8f0"); }
  if (n) note(istr(n) + (n > 1 ? " teams want" : " team wants") + " you. Open TRADE OFFERS to answer.", "#7CFC9A");
  note(C.phase == "reg" ? (tradeOpen() ? "Trade deadline: game " + istr(PRO_DEADLINE) + " (" + istr(PRO_DEADLINE - C.day) + " games away)." : "The trade deadline has passed. Requests carry over to the summer.") : "Trades reopen next season.", "#94a3b8");
  note(C.ntc ? "Your no-trade clause means no team can move you without your OK." : "Without a no-trade clause the team can trade you at any time. A no-trade clause can only come with a new contract.", "#94a3b8");
  footHints(PADH);
}
static void drawNeg() {
  if (!C.hasNeg) negStart(C.need);
  PNeg &N = C.neg; double m = .03 * U, top = safeTop + .115 * U, bot = H - .17 * U, s = negSal(); bool ok = ntcChance(false) >= .5; PTeam &L = C.L[orgOf(C.me)];
  scrHead("CONTRACT TALKS", upper(L.n) + "  |  " + (C.deals ? "" : "YOUR ENTRY-LEVEL DEAL IS DONE  |  ") + (N.forced ? "NEW CONTRACT" : "EXTENSION: STARTS NEXT SEASON")); cashTag();
  double lw = W * .56, lx = m; panel(lx, top, lw, bot - top); accentBar(lx, top, bot - top, hex("#16a34a"));
  double y = top + .04 * U; T(N.fin ? "THEIR FINAL OFFER" : "THEIR OFFER", lx + .03 * U, y, .018, N.fin ? "#fca5a5" : "#94a3b8");
  y += .075 * U; std::string sv = money2(s); TB(sv, lx + .03 * U, y, .08, "#fff"); ctx.font(fsz(.08) * U); double sw = ctx.measure(sv);
  T("PER SEASON", lx + .05 * U + sw, y - .012 * U, .018, "#94a3b8", AL_LEFT, 700); T("$" + fixed(s * N.yrs, 1) + "M TOTAL", lx + .05 * U + sw, y + .016 * U, .02, "#ffd54a");
  y += .075 * U; T("TERM", lx + .03 * U, y, .018, "#94a3b8", AL_LEFT, 700); double bx = lx + .13 * U, bw = .07 * U, bh = .06 * U;
  ui("neg:y-", bx, y - bh / 2, bw, bh, "<", "#334155", N.yrs > 1, .035); TB(istr(N.yrs) + (N.yrs > 1 ? " YEARS" : " YEAR"), bx + bw + .11 * U, y, .034, "#fff", AL_CENTER); ui("neg:y+", bx + bw + .22 * U, y - bh / 2, bw, bh, ">", "#334155", N.yrs < 5, .035);
  y += .085 * U; ui("neg:ntc", lx + .03 * U, y - bh / 2, .36 * U, bh, N.ntc ? "NO-TRADE CLAUSE: ASKING" : "NO-TRADE CLAUSE: NO", "#0891b2", true, .023);
  txWrap(N.ntc ? (ok ? "They will agree to it - it costs you 6% of the salary." : "They will refuse it. You can still sign without one.") : (ok ? "They would agree to a no-trade clause." : "They would not give you a no-trade clause right now."), lx + .42 * U, y, .016, lw - .45 * U, hex(N.ntc ? (ok ? "#7CFC9A" : "#fca5a5") : "#94a3b8"), AL_LEFT, 700, 2);
  y += .07 * U; static const char *BN[3] = {"SIGNING BONUS: NONE", "SIGNING BONUS: SMALL", "SIGNING BONUS: BIG"};
  ui("neg:bonus", lx + .03 * U, y - bh / 2, .36 * U, bh, BN[N.bonus], "#7c3aed", true, .023);
  txWrap(N.bonus ? "+$" + fmtN(negBonusCash()) + " cash the day you sign, for " + istr(4 * N.bonus) + "% less salary." : "Cash up front for a little less salary.", lx + .42 * U, y, .016, lw - .45 * U, hex(N.bonus ? "#ffd54a" : "#94a3b8"), AL_LEFT, 700, 2);
  y += .07 * U; ui("neg:perf", lx + .03 * U, y - bh / 2, .36 * U, bh, N.perf ? "PERFORMANCE BONUSES: YES" : "PERFORMANCE BONUSES: NO", "#b45309", true, .023);
  txWrap(N.perf ? "Season goals pay 50% more (Goals app), for 5% less salary." : "Bet on yourself: bigger season bonuses for a little less salary.", lx + .42 * U, y, .016, lw - .45 * U, hex(N.perf ? "#7CFC9A" : "#94a3b8"), AL_LEFT, 700, 2);
  y += .065 * U; txWrap(std::string(C.age <= 26 ? "Young players get a little more per year on longer deals. " : C.age >= 32 ? "At your age, longer deals pay less per year. " : "") + "Ask for more and they might come up - or lose patience.", lx + .03 * U, y, .016, lw - .06 * U, hex("#94a3b8"), AL_LEFT, 700, 2);
  double rx = lx + lw + .025 * U, rw = W - rx - m; panel(rx, top, rw, bot - top);
  double ry = top + .04 * U; T("YOUR VALUE", rx + .02 * U, ry, .018, "#94a3b8"); ry += .045 * U;
  TB(money2(market(proOvr())), rx + .02 * U, ry, .045, "#fff"); TB("OVR " + istr(proOvr()), rx + rw - .02 * U, ry, .026, "#ffd54a", AL_RIGHT); ry += .055 * U;
  meter(rx + .02 * U, ry, rw - .04 * U, perfScore(), "#38bdf8", "PERFORMANCE"); ry += .05 * U; meter(rx + .02 * U, ry, rw - .04 * U, loyalty(), "#f59e0b", "LOYALTY"); ry += .06 * U;
  T("THEIR PATIENCE", rx + .02 * U, ry, .016, "#94a3b8", AL_LEFT, 700); for (int k = 0; k < 3; k++) { ctx.fill(k < N.pat ? hex("#f59e0b") : rgba(148, 163, 184, .25)); ctx.fillRect(rx + rw - .02 * U - (3 - k) * .035 * U, ry - .008 * U, .028 * U, .016 * U); }
  ry += .045 * U; if (!N.msg.empty()) { T(N.msg, rx + .02 * U, ry, .018, "#ffd54a"); ry += .035 * U; }
  ry += .01 * U; T("COMPARABLE CONTRACTS", rx + .02 * U, ry, .016, "#f26b5b"); ry += .03 * U;
  int me = proOvr(); std::vector<PP *> pool; for (auto &q : C.P) if (!q->me && !q->g && q->t >= 0 && !q->isCu && q->cy > 0) pool.push_back(q.get());
  std::sort(pool.begin(), pool.end(), [me](PP *a, PP *b) { int da = std::abs(ovQ(a) - me), db = std::abs(ovQ(b) - me); return da != db ? da < db : a->sal > b->sal; });
  for (size_t i = 0; i < pool.size() && i < 8 && ry < bot - .02 * U; i++) { PP *q = pool[i]; TF(q->nm() + "  " + C.L[q->t].ab + "  OVR " + istr(ovQ(q)), rx + .02 * U, ry, .016, rw * .62, "#e2e8f0"); T(money2(q->sal), rx + rw - .02 * U, ry, .016, "#7CFC9A", AL_RIGHT); ry += .029 * U; }
  double by = bot + .025 * U, gw = (W - 2 * m - .04 * U) / 3, gh = .075 * U;
  ui("neg:ok", m, by, gw, gh, "SIGN IT", "#16a34a", true, .032);
  ui("neg:push", m + gw + .02 * U, by, gw, gh, "ASK FOR MORE", "#d97706", N.pat > 0, .032); if (N.pat <= 0) btns.back().dis = true;
  if (N.forced) ui("neg:walk", m + 2 * (gw + .02 * U), by, gw, gh, N.sure ? "SURE? GO TO FREE AGENCY" : "WALK AWAY", "#dc2626", true, N.sure ? .022 : .032);
  else ui("neg:walk", m + 2 * (gw + .02 * U), by, gw, gh, "BACK", "#475569", true, .032);
}
static void drawNtc() {
  double m = .03 * U, cw = std::min(W - 2 * m, .95 * U), cx = (W - cw) / 2, top = safeTop + .16 * U, ch = .5 * U;
  scrHead("NO-TRADE CLAUSE", "OFFICE  |  ONE ASK PER SEASON"); cashTag();
  panel(cx, top, cw, ch); accentBar(cx, top, ch, hex("#f26b5b"));
  double y = top + .05 * U; TB("Ask the " + C.L[orgOf(C.me)].n + " for a no-trade clause", cx + .03 * U, y, .028, "#fff"); y += .06 * U;
  txWrap("They decide on how you are playing and how much you seem to want to stay. A pay cut shows you mean it. If they say no, you can ask again next season.", cx + .03 * U, y + .02 * U, .018, cw - .06 * U, hex("#cbd5e1"), AL_LEFT, 700, 3); y += .1 * U;
  meter(cx + .03 * U, y, cw / 2 - .05 * U, perfScore(), "#38bdf8", "PERFORMANCE"); meter(cx + cw / 2 + .02 * U, y, cw / 2 - .05 * U, loyalty(), "#f59e0b", "LOYALTY");
  y += .06 * U; double c0 = ntcChance(false), c1 = ntcChance(true), bw = (cw - .08 * U) / 2, bh = .085 * U; PP *Y = youMe();
  ui("ntc:0", cx + .03 * U, y, bw, bh, "JUST ASK  (" + istr((int)jround(c0 * 100)) + "%)", "#0891b2", true, .026);
  ui("ntc:1", cx + .05 * U + bw, y, bw, bh, "TAKE 10% LESS  (" + istr((int)jround(c1 * 100)) + "%)", "#16a34a", true, .026);
  T("Pay cut: " + money2(Y->sal) + "  ->  " + money2(Y->sal * .9), cx + .05 * U + bw * 1.5, y + bh + .025 * U, .016, "#94a3b8", AL_CENTER, 700);
  back("nav:office", top + ch + .03 * U);
}
static void drawTreq() {
  double m = .03 * U, top = safeTop + .13 * U, gap = .012 * U, cw = (W - 2 * m - 3 * gap) / 4, rh = std::min(.052 * U, (H - top - .14 * U) / 8 - .006 * U);
  scrHead("REQUEST A TRADE", "PICK UP TO 10 TEAMS  |  " + istr(tqSel.size()) + " / 10 PICKED  |  ONE OF THEM GETS YOU IN 7 DAYS" + std::string(C.me >= NA ? "  |  YOU REPORT TO THEIR AHL CLUB" : "")); cashTag();
  PP *Y = youMe();
  for (int d = 0; d < 4; d++) { double x = m + d * (cw + gap); T(DIVN[d], x + 4, top - .016 * U, .015, "#94a3b8"); std::vector<int> ids; for (int i = 0; i < 32; i++) if (C.L[i].d == d) ids.push_back(i);
    std::vector<int> o = standOrd(ids);
    for (size_t k = 0; k < o.size(); k++) { int t = o[k]; double y = top + k * (rh + .006 * U); bool sel = std::find(tqSel.begin(), tqSel.end(), t) != tqSel.end(), me = t == orgOf(C.me); double room = capOf() - payroll(t);
      glass(x, y, cw, rh, .74); if (sel) { ctx.fill(rgba(242, 107, 91, .3)); ctx.rr(x, y, cw, rh, std::min(.02 * U, rh * .3)); ctx.fillPath(); } if (sel) { accentBar(x, y, rh, hex("#f26b5b")); }
      badge(x + rh * .55, y + rh / 2, rh * .36, t); TF(upper(C.L[t].n), x + rh * 1.05, y + rh * .34, .019, cw - rh * 1.2 - .02 * U, me ? "#64748b" : "#fff");
      T(istr(C.L[t].w) + "-" + istr(C.L[t].l) + "   " + (room >= .05 ? "CAP ROOM $" + fixed(room, 1) + "M" : room > -.05 ? "AT THE CAP" : "$" + fixed(-room, 1) + "M OVER"), x + rh * 1.05, y + rh * .74, .0135, room >= Y->sal ? "#7CFC9A" : "#94a3b8", AL_LEFT, 700);
      if (!me) pushBtn("tq:" + istr(t), x, y, cw, rh, C.L[t].n); } }
  double by = top + 8 * (rh + .006 * U) + .02 * U, bw = .3 * U, bh = .07 * U;
  ui("tq:go", m, by, bw, bh, "SUBMIT REQUEST", "#16a34a", !tqSel.empty(), .028); if (tqSel.empty()) btns.back().dis = true;
  ui("tq:clr", m + bw + .02 * U, by, .2 * U, bh, "CLEAR", "#334155", !tqSel.empty(), .028);
  ui("nav:office", W - m - .25 * U, by, .25 * U, bh, "BACK", "#475569", true, .028);
  txWrap("Asking out hurts your loyalty. Teams have to send back players so both payrolls stay under the cap.", m + bw + .24 * U, by + bh / 2, .015, W - m - .27 * U - (m + bw + .24 * U), hex("#94a3b8"), AL_LEFT, 700, 2);
}
static void drawOffers() {
  double m = .03 * U, top = safeTop + .13 * U;
  scrHead("TRADE OFFERS", C.ntc ? "YOUR NO-TRADE CLAUSE GIVES YOU THE FINAL SAY" : "NO NO-TRADE CLAUSE: OFFERS ARE DECIDED WITHOUT YOU"); cashTag();
  if (C.offers.empty()) { panel(m, top, W - 2 * m, .2 * U); TB("No offers right now.", W / 2, top + .07 * U, .034, "#fff", AL_CENTER);
    T(C.ntc ? "When a team calls about you, the offer lands here and you can accept or reject it." : "Get a no-trade clause in the Office to have a say when teams call.", W / 2, top + .13 * U, .018, "#94a3b8", AL_CENTER, 700); }
  double ch = .15 * U;
  for (size_t i = 0; i < C.offers.size() && i < 3; i++) { const POffer &o = C.offers[i]; double y = top + i * (ch + .015 * U); panel(m, y, W - 2 * m, ch); accentBar(m, y, ch, hex("#0891b2"));
    badge(m + .055 * U, y + ch / 2, .034 * U, o.t); TB("THE " + upper(C.L[o.t].n) + " WANT YOU", m + .105 * U, y + .035 * U, .026, "#fff");
    std::string rt; for (auto &n : o.ret) rt += (rt.empty() ? "" : ", ") + n; TF("YOUR TEAM GETS: " + rt, m + .105 * U, y + .075 * U, .017, W * .5, "#cbd5e1");
    T(istr(C.L[o.t].w) + "-" + istr(C.L[o.t].l) + "  |  " + divName(o.t) + "  |  EXPIRES IN " + istr(std::max(0, o.exp - C.ci)) + " DAYS", m + .105 * U, y + .11 * U, .015, "#94a3b8", AL_LEFT, 700);
    double bw = .2 * U, bh = .06 * U; ui("tof:a:" + istr(i), W - m - 2 * bw - .035 * U, y + (ch - bh) / 2, bw, bh, "ACCEPT", "#16a34a", tradeOpen(), .026); if (!tradeOpen()) btns.back().dis = true;
    ui("tof:r:" + istr(i), W - m - bw - .015 * U, y + (ch - bh) / 2, bw, bh, "REJECT", "#dc2626", true, .026); }
  back("nav:office", H - .12 * U);
}
static void drawTradeAlert() {
  if (!C.hasTrade) { screen = "main"; return; }
  const PTrade &tr = C.trade; double m = .03 * U, cw = std::min(W - 2 * m, 1.3 * U), cx = (W - cw) / 2, top = safeTop + .05 * U;
  TB(tr.title.empty() ? "TRADE ALERT" : tr.title, W / 2, top + .04 * U, .07, "#fff", AL_CENTER);
  double ch = .36 * U, y = top + .1 * U; panel(cx, y, cw, ch); topLine(cx, y, cw, hex("#f26b5b"));
  double r = .07 * U; if (tr.title != "FREE AGENCY") { badge(cx + cw * .22, y + .12 * U, r, tr.from); T(upper(C.L[tr.from].n), cx + cw * .22, y + .22 * U, .022, "#94a3b8", AL_CENTER); TB("->", W / 2, y + .12 * U, .05, "#f26b5b", AL_CENTER); }
  badge(cx + cw * (tr.title != "FREE AGENCY" ? .78 : .5), y + .12 * U, r, tr.to); T(upper(C.L[tr.to].n), cx + cw * (tr.title != "FREE AGENCY" ? .78 : .5), y + .22 * U, .022, "#fff", AL_CENTER);
  txWrap(tr.why, W / 2, y + .27 * U, .019, cw - .06 * U, hex("#cbd5e1"), AL_CENTER, 700, 3);
  if (!tr.ret.empty()) { std::string rt; for (auto &n : tr.ret) rt += (rt.empty() ? "" : ", ") + n; TF("GOING THE OTHER WAY: " + rt, W / 2, y + ch - .03 * U, .017, cw - .06 * U, "#94a3b8", AL_CENTER); }
  y += ch + .03 * U; PTeam &L = C.L[tr.to];
  T("YOUR NEW TEAM: " + istr(L.w) + "-" + istr(L.l) + "  |  " + divName(tr.to) + (tr.to >= NA ? "  |  AHL AFFILIATE OF THE " + upper(C.L[orgOf(tr.to)].n) : "  |  NHL  |  PAYROLL $" + fixed(payroll(tr.to), 1) + "M"), W / 2, y, .02, "#e2e8f0", AL_CENTER, 700);
  ui("ptradeok", (W - .44 * U) / 2, H - .13 * U, .44 * U, .08 * U, "CONTINUE", "#16a34a", true, .034);
}

// ---------------------------------------------------------------- schedule and the league
static void drawSched() {
  double m = .03 * U, top = safeTop + .14 * U; PTeam &r = C.L[C.me];
  scrHead("SCHEDULE", upper(r.n) + "  |  " + istr(r.w) + "-" + istr(r.l) + "  |  80 GAMES  |  L / R: PAGE");
  int per = 20, pages = (PRO_GAMES + per - 1) / per; if (schedPg < 0) schedPg = std::min(pages - 1, C.day / per); schedPg = std::max(0, std::min(pages - 1, schedPg));
  std::map<int, const PHist *> res; for (auto &h : C.hist) if (!h.po) res[h.d] = &h;
  double cw = (W - 2 * m - .02 * U) / 2, rh = std::min(.042 * U, (H - top - .13 * U) / 10 - .004 * U);
  for (int k = 0; k < per; k++) { int d = schedPg * per + k; if (d >= (int)C.sched.size()) break; int c = k / 10, rr = k % 10; double x = m + c * (cw + .02 * U), y = top + rr * (rh + .004 * U); int o = C.sched[d];
    panel(x, y, cw, rh, d == C.day && C.phase == "reg" ? .9 : .62); if (d == C.day && C.phase == "reg") { accentBar(x, y, rh, hex("#f26b5b")); }
    int gi = -1; for (size_t i = 0; i < C.cal.size(); i++) if (C.cal[i] == d) gi = (int)i;
    T("G" + istr(d + 1), x + .015 * U, y + rh / 2, .016, "#64748b"); T(gi >= 0 ? calDate(gi) : "", x + .07 * U, y + rh / 2, .016, "#94a3b8", AL_LEFT, 700);
    badge(x + .17 * U, y + rh / 2, rh * .36, o); TF(upper(C.L[o].n), x + .2 * U, y + rh / 2, .018, cw * .4, "#fff");
    auto it = res.find(d); if (it != res.end()) { const PHist &h = *it->second; T((h.w ? "W " : "L ") + istr(h.hs) + "-" + istr(h.as) + (h.ln && !h.dnp ? "   " + istr(h.g) + "G " + istr(h.a) + "A" : h.dnp ? "   DNP" : ""), x + cw - .015 * U, y + rh / 2, .017, h.w ? "#7CFC9A" : "#fca5a5", AL_RIGHT); }
    else T(d == C.day && C.phase == "reg" ? "NEXT" : "", x + cw - .015 * U, y + rh / 2, .017, "#f26b5b", AL_RIGHT); }
  T("PAGE " + istr(schedPg + 1) + " / " + istr(pages), W / 2, top + 10 * (rh + .004 * U) + .02 * U, .017, "#94a3b8", AL_CENTER, 700);
  ui("sch:-", m, H - .1 * U, .2 * U, .065 * U, "< PREV", "#334155", schedPg > 0, .026); ui("sch:+", W - m - .2 * U, H - .1 * U, .2 * U, .065 * U, "NEXT >", "#334155", schedPg < pages - 1, .026);
  back("nav:main", H - .1 * U);
}
static const char *STABS[9] = {"ATLANTIC", "METRO", "CENTRAL", "PACIFIC", "SCORERS", "GOALIES", "NEWS", "MY TEAM", "PLAYOFFS"};
static const char *ASTABS[4] = {"ATLANTIC", "NORTH", "CENTRAL", "PACIFIC"};
static bool inLg(int t) { return t >= 0 && (t >= NA ? 1 : 0) == standLg; }
static void drawBracket(double top, double bot) {
  double m = .02 * U; int cols = 7; double cw = std::min(.21 * U, (W - 2 * m) / cols - .012 * U), gapX = (W - 2 * m - cw * cols) / (cols - 1), bh = .072 * U;
  bool mine = standLg == proLg(); std::vector<std::vector<PSeries>> BR = mine ? C.br : C.obr; int champ = mine ? C.champ : C.ochamp;
  if (BR.empty()) { Seeds E = seeds(0, standLg), Wt = seeds(1, standLg); std::vector<PSeries> r; for (auto *S : {&E, &Wt}) for (auto &p : S->pairs) { PSeries s; s.a = p.first; s.b = p.second; s.proj = true; r.push_back(s); } BR.push_back(r); }
  auto colX = [&](int c) { return m + c * (cw + gapX); };
  auto place = [&](int r, int i, int &c, double &y) { int n = 8 >> r, half = n / 2; if (r == 3) { c = 3; y = (top + bot) / 2; return; } int side = i < half ? 0 : 1, k = side ? i - half : i; double slot = (bot - top) / half; c = side ? 6 - r : r; y = top + slot * (k + .5); };
  ctx.stroke(rgba(148, 163, 184, .35)); ctx.lineWidth(1.5);
  for (int r = 0; r < 3; r++) for (int i = 0; i < (8 >> r); i++) { int ca, cb; double ya, yb; place(r, i, ca, ya); place(r + 1, i / 2, cb, yb); bool left = ca < 3;
    double x0 = left ? colX(ca) + cw : colX(ca), x1 = left ? colX(cb) : colX(cb) + cw, xm = (x0 + x1) / 2; ctx.beginPath(); ctx.moveTo(x0, ya); ctx.lineTo(xm, ya); ctx.lineTo(xm, yb); ctx.lineTo(x1, yb); ctx.strokePath(); }
  for (int r = 0; r < 4; r++) for (int i = 0; i < (8 >> r); i++) { int c; double py; place(r, i, c, py); double x = colX(c), y = py - bh / 2; bool fin = r == 3;
    ctx.fill(fin ? rgba(255, 213, 74, .12) : rgba(15, 23, 42, .88)); ctx.fillRect(x, y, cw, bh); if (fin) { ctx.stroke("#ffd54a"); ctx.strokeRect(x, y, cw, bh); }
    const PSeries *s = r < (int)BR.size() && i < (int)BR[r].size() ? &BR[r][i] : nullptr;
    auto line = [&](int t, int wins, double yy, bool won, bool lost) { if (t < 0) { T("TBD", x + .012 * U, yy, .017, "#475569"); return; } bool me = t == C.me; if (me) { ctx.fill(rgba(255, 213, 74, .22)); ctx.fillRect(x, yy - bh / 4, cw, bh / 2); }
      accentBar(x, yy - bh / 4, bh / 2, hex(teamCol(t))); TB(C.L[t].ab, x + .014 * U, yy, .019, lost ? "#64748b" : me ? "#ffd54a" : "#fff");
      T(s && s->proj ? istr(C.L[t].w) + "-" + istr(C.L[t].l) : istr(wins), x + cw - .01 * U, yy, .017, won ? "#7CFC9A" : lost ? "#64748b" : "#cbd5e1", AL_RIGHT, 900); };
    if (!s) { line(-1, 0, y + bh * .27, false, false); line(-1, 0, y + bh * .73, false, false); continue; }
    line(s->a, s->wa, y + bh * .27, s->w == s->a, s->w >= 0 && s->w != s->a); line(s->b, s->wb, y + bh * .73, s->w == s->b, s->w >= 0 && s->w != s->b); }
  int c; double fy; place(3, 0, c, fy); TB(standLg ? "CALDER CUP FINAL" : "STANLEY CUP FINAL", colX(3) + cw / 2, fy - bh / 2 - .02 * U, .02, "#ffd54a", AL_CENTER);
  if (champ >= 0) { T("CHAMPIONS", colX(3) + cw / 2, fy + bh / 2 + .03 * U, .016, "#94a3b8", AL_CENTER); TF(upper(C.L[champ].n), colX(3) + cw / 2, fy + bh / 2 + .06 * U, .026, cw * 1.6, "#ffd54a", AL_CENTER); }
  static const char *CL[7] = {"EAST  R1", "R2", "EAST FINAL", "", "WEST FINAL", "R2", "WEST  R1"}; for (int k = 0; k < 7; k++) if (CL[k][0]) T(CL[k], colX(k) + cw / 2, bot + .03 * U, .015, "#94a3b8", AL_CENTER);
}
static void drawStand() {
  double m = .03 * U, ty = safeTop + .115 * U; standTab = std::max(0, std::min(8, standTab)); if (CR->L.size() < (size_t)NALL) standLg = 0;
  bool mineB = standLg == proLg(); const auto &BRx = mineB ? C.br : C.obr;
  scrHead(standLg ? "AHL" : "NHL", standTab == 8 ? (BRx.empty() ? "16 TEAMS  |  TOP 3 IN EACH DIVISION + 2 WILD CARDS PER CONFERENCE" : mineB && C.phase == "po" ? std::string(RN[std::min(3, C.round)]) + "  |  BEST OF 3 EVERY ROUND" : std::string("BEST OF 3 EVERY ROUND")) : "SEASON " + istr(C.season) + "  |  L / R: SWITCH TABS");
  if (CR->L.size() == (size_t)NALL) { double bw = .13 * U, bx = W - m - 2 * bw - .01 * U, by = safeTop + .03 * U;   // which league
    ui("slg:0", bx, by, bw, .055 * U, "NHL", standLg == 0 ? "#2563eb" : "#334155", true, .024); btns.back().np = true;
    ui("slg:1", bx + bw + .01 * U, by, bw, .055 * U, "AHL", standLg == 1 ? "#c8102e" : "#334155", true, .024); btns.back().np = true; }
  if (standTab == 6) standTab = 7;   // (the news has its own app now)
  double tw = (W - 2 * m - 7 * .006 * U) / 8; static const int TABS[8] = {0, 1, 2, 3, 4, 5, 7, 8};
  for (int j = 0; j < 8; j++) { int i = TABS[j]; ui("stab:" + istr(i), m + j * (tw + .006 * U), ty, tw, .05 * U, i < 4 && standLg ? ASTABS[i] : STABS[i], standTab == i ? "#f26b5b" : "#334155", true, .019); btns.back().np = true; }
  double y0 = ty + .075 * U, x = m, w = W - 2 * m;
  auto hdr = [&](const std::vector<std::pair<std::string, double>> &c) { for (auto &e : c) T(e.first, e.second, y0 + .005 * U, .015, "#94a3b8", AL_RIGHT); };
  if (standTab < 4) {
    std::vector<int> ids; for (int i : lgTeams(standLg)) if (C.L[i].d == standTab) ids.push_back(i); std::vector<int> o = standOrd(ids);
    std::map<int, char> spot; for (int c = 0; c < 2; c++) { Seeds S = seeds(c, standLg); for (auto &d : S.top) for (int t : d) spot[t] = 'x'; for (int t : S.wc) spot[t] = 'w'; }
    double rh = std::min(.052 * U, (H - y0 - .2 * U) / std::max<size_t>(8, o.size()) - .005 * U); hdr({{"W", x + w * .55}, {"L", x + w * .62}, {"GF", x + w * .72}, {"GA", x + w * .8}, {"DIFF", x + w * .89}, {"STRK", x + w - .02 * U}});
    for (size_t k = 0; k < o.size(); k++) { int t = o[k]; PTeam &L = C.L[t]; double ry = y0 + .02 * U + k * (rh + .005 * U); panel(x, ry, w, rh, .62); if (t == C.me) { ctx.fill(rgba(255, 213, 74, .22)); ctx.fillRect(x, ry, w, rh); }
      badge(x + .04 * U, ry + rh / 2, rh * .36, t); TB(istr(k + 1) + ". " + upper(teamFull(t)), x + .075 * U, ry + rh / 2, .022, t == C.me ? "#ffd54a" : t == orgOf(C.me) || t == orgOf(C.me) + NA ? "#fde68a" : "#fff");
      if (spot.count(t)) T(std::string(1, spot[t]), x + w * .45, ry + rh / 2, .02, spot[t] == 'x' ? "#7CFC9A" : "#93c5fd", AL_CENTER);
      int dd = L.gf - L.ga; std::string sk = L.sk > 0 ? "W" + istr(L.sk) : L.sk < 0 ? "L" + istr(-L.sk) : "-";
      T(istr(L.w), x + w * .55, ry + rh / 2, .022, "#fff", AL_RIGHT); T(istr(L.l), x + w * .62, ry + rh / 2, .022, "#fff", AL_RIGHT); T(istr(L.gf), x + w * .72, ry + rh / 2, .02, "#cbd5e1", AL_RIGHT); T(istr(L.ga), x + w * .8, ry + rh / 2, .02, "#cbd5e1", AL_RIGHT);
      T((dd > 0 ? "+" : "") + istr(dd), x + w * .89, ry + rh / 2, .02, dd >= 0 ? "#7CFC9A" : "#fca5a5", AL_RIGHT); T(sk, x + w - .02 * U, ry + rh / 2, .02, "#cbd5e1", AL_RIGHT); }
    T("x = top 3 in the division    w = wild card (next 2 best in the conference)    16 teams make it", x, y0 + .02 * U + std::max<size_t>(8, o.size()) * (rh + .005 * U) + .025 * U, .016, "#94a3b8", AL_LEFT, 700);
  } else if (standTab == 4) {
    std::vector<PP *> top; for (auto &q : C.P) if (!q->g && inLg(q->t)) top.push_back(q.get());
    std::sort(top.begin(), top.end(), [](PP *a, PP *b) { int pa = a->gl + a->as, pb = b->gl + b->as; return pa != pb ? pa > pb : a->gl > b->gl; }); double rh = .04 * U;
    hdr({{"G", x + w * .8}, {"A", x + w * .88}, {"PTS", x + w - .02 * U}});
    for (size_t k = 0; k < top.size() && k < 12; k++) { PP *q = top[k]; double ry = y0 + .02 * U + k * (rh + .004 * U); panel(x, ry, w, rh, .62); if (q->me) { ctx.fill(rgba(255, 213, 74, .22)); ctx.fillRect(x, ry, w, rh); }
      T(istr(k + 1) + ". " + q->nm(), x + .06 * U, ry + rh / 2, .021, q->me ? "#ffd54a" : q->t == C.me ? "#fde68a" : "#fff"); ctx.fill(hex(teamCol(q->t))); ctx.disc(x + .035 * U, ry + rh / 2, .012 * U);
      T(C.L[q->t].ab + "   OVR " + istr(ovQ(q)) + "   AGE " + istr(q->age), x + w * .45, ry + rh / 2, .016, "#94a3b8", AL_LEFT, 700);
      T(istr(q->gl), x + w * .8, ry + rh / 2, .022, "#cbd5e1", AL_RIGHT); T(istr(q->as), x + w * .88, ry + rh / 2, .022, "#cbd5e1", AL_RIGHT); TB(istr(q->gl + q->as), x + w - .02 * U, ry + rh / 2, .024, "#fff", AL_RIGHT); }
    T("Top 12 scorers this regular season", x, y0 + .02 * U + 12 * (.044 * U) + .02 * U, .016, "#94a3b8", AL_LEFT, 700);
  } else if (standTab == 5) {
    std::vector<PP *> l; for (auto &q : C.P) if (q->g && inLg(q->t) && q->sa >= 40) l.push_back(q.get());
    std::sort(l.begin(), l.end(), [](PP *a, PP *b) { return (double)a->sv / a->sa > (double)b->sv / b->sa; }); double rh = .04 * U;
    hdr({{"GP", x + w * .8}, {"SV%", x + w - .02 * U}});
    for (size_t k = 0; k < l.size() && k < 12; k++) { PP *q = l[k]; double ry = y0 + .02 * U + k * (rh + .004 * U); panel(x, ry, w, rh, .62); ctx.fill(hex(teamCol(q->t))); ctx.disc(x + .035 * U, ry + rh / 2, .012 * U);
      T(istr(k + 1) + ". " + q->nm(), x + .06 * U, ry + rh / 2, .021, q->t == C.me ? "#fde68a" : "#fff"); T(C.L[q->t].ab + "   OVR " + istr(ovQ(q)) + "   AGE " + istr(q->age), x + w * .45, ry + rh / 2, .016, "#94a3b8", AL_LEFT, 700);
      T(istr(q->gp), x + w * .8, ry + rh / 2, .022, "#cbd5e1", AL_RIGHT); TB(svp3(q->sv, q->sa), x + w - .02 * U, ry + rh / 2, .024, "#7CFC9A", AL_RIGHT); }
    if (l.empty()) TB("Goalie stats appear after a few games", W / 2, y0 + .1 * U, .03, "#94a3b8", AL_CENTER);
  } else if (standTab == 6) {
    double rh = .038 * U; if (C.log.empty()) TB("No league news yet", W / 2, y0 + .1 * U, .03, "#94a3b8", AL_CENTER);
    for (size_t k = 0; k < C.log.size() && k < 13; k++) { double ry = y0 + .01 * U + k * (rh + .004 * U); panel(x, ry, w, rh, .62); T("Y" + istr(C.log[k].y), x + .02 * U, ry + rh / 2, .016, "#64748b"); TF(C.log[k].s, x + .07 * U, ry + rh / 2, .018, w - .09 * U, "#e2e8f0"); }
  } else if (standTab == 7) {
    std::vector<PP *> S = teamS(C.me); std::sort(S.begin(), S.end(), [](PP *a, PP *b) { if (a->isCu != b->isCu) return !a->isCu; return ovQ(a) > ovQ(b); });
    std::vector<PP *> GG = teamG(C.me); std::sort(GG.begin(), GG.end(), [](PP *a, PP *b) { return ovQ(a) > ovQ(b); });
    double pay = payroll(orgOf(C.me)), cap = capOf(), lw = w * .63, rx = x + lw + .02 * U, rw = w - lw - .02 * U, rh = std::min(.044 * U, (H - y0 - .03 * U) / std::max<size_t>(9, S.size()) - .004 * U);
    for (size_t k = 0; k < S.size(); k++) { PP *q = S[k]; double ry = y0 + k * (rh + .004 * U); panel(x, ry, lw, rh, .62); if (q->me) { ctx.fill(rgba(255, 213, 74, .22)); ctx.fillRect(x, ry, lw, rh); }
      std::string tg = q->inj ? "  INJ " + istr(q->inj) : q->isCu ? "  CALL-UP" : ""; TF((q->star ? "* " : "") + q->nm() + tg, x + .015 * U, ry + rh / 2, .02, lw * .46, q->me ? "#ffd54a" : q->inj ? "#fca5a5" : q->isCu ? "#93c5fd" : "#fff");
      T("OVR " + istr(ovQ(q)) + "  AGE " + istr(q->age), x + lw * .5, ry + rh / 2, .016, "#cbd5e1", AL_LEFT, 700); T(istr(q->gl) + "G " + istr(q->as) + "A", x + lw * .73, ry + rh / 2, .016, "#cbd5e1", AL_LEFT, 700);
      T(q->isCu ? "-" : "$" + fixed(q->sal, 1) + "M " + istr(q->cy) + "Y", x + lw - .012 * U, ry + rh / 2, .016, "#7CFC9A", AL_RIGHT); }
    double ry = y0; panel(rx, ry, rw, .12 * U); T(C.me >= NA ? upper(C.L[orgOf(C.me)].n) + " PAYROLL (NHL)" : "PAYROLL", rx + .015 * U, ry + .025 * U, .015, "#94a3b8", AL_LEFT, 700); TB("$" + fixed(pay, 1) + "M / $" + fixed(cap, 1) + "M", rx + .015 * U, ry + .06 * U, .028, pay > cap ? "#fca5a5" : "#7CFC9A");
    T((cap - pay >= 0 ? "$" + fixed(cap - pay, 1) + "M UNDER" : "$" + fixed(pay - cap, 1) + "M OVER") + std::string(" THE CAP"), rx + .015 * U, ry + .095 * U, .015, "#cbd5e1", AL_LEFT, 700);
    ry += .135 * U; T("GOALIES", rx, ry, .016, "#f26b5b"); ry += .022 * U;
    for (PP *q : GG) { panel(rx, ry, rw, .06 * U, .62); TF(q->nm(), rx + .015 * U, ry + .02 * U, .02, rw * .6, "#fff"); T("OVR " + istr(ovQ(q)), rx + rw - .012 * U, ry + .02 * U, .017, "#cbd5e1", AL_RIGHT);
      T("SV% " + svp3(q->sv, q->sa) + "  GP " + istr(q->gp) + "   $" + fixed(q->sal, 1) + "M " + istr(q->cy) + "Y", rx + .015 * U, ry + .045 * U, .015, "#94a3b8", AL_LEFT, 700); ry += .066 * U; }
  } else drawBracket(y0 + .02 * U, H - .15 * U);
  back("nav:main", H - .085 * U);
}
static void drawRetired() {
  double w = std::min(W - 24.0, 1.4 * U), x = (W - w) / 2, y = safeTop + .04 * U;
  TB("CAREER OVER", W / 2, y + .05 * U, .075, "#fff", AL_CENTER);
  T(C.retWhy == "injury" ? "A broken back ends it at age " + istr(C.age) + "." : "You hang up the skates at " + istr(C.age) + ".", W / 2, y + .12 * U, .03, "#cbd5e1", AL_CENTER, 700);
  double ry = y + .17 * U, rh = .3 * U; panel(x, ry, w, rh); topLine(x, ry, w, hex("#c8102e"));
  softGlow(x + .12 * U, ry + rh * .86, .1 * U, .02 * U, Col(255, 255, 255), .14); you(x + .12 * U, ry + rh * .86, .23 * U / 6.2);
  std::pair<std::string, std::string> st[6] = {{"SEASONS", istr(C.season - (C.retWhy == "age" ? 1 : 0))}, {"NHL GAMES", istr(C.cGP)}, {"NHL GOALS", istr(C.cG)}, {"NHL ASSISTS", istr(C.cA)}, {"NHL POINTS", istr(C.cG + C.cA)}, {"STANLEY CUPS", istr(C.titles)}};
  for (int i = 0; i < 6; i++) { double cx = x + .28 * U + (i % 3) * (w - .32 * U) / 3, cy = ry + .08 * U + (i / 3) * .12 * U; T(st[i].first, cx, cy, .018, "#94a3b8", AL_LEFT, 700); TB(st[i].second, cx, cy + .045 * U, .045, i == 5 ? "#ffd54a" : "#fff"); }
  T("AHL: " + istr(C.aGP) + " GP  " + istr(C.aG) + " G  " + istr(C.aA) + " A  |  CALDER CUPS " + istr(C.calder) + (C.debut ? "  |  NHL DEBUT AT " + istr(C.debut) : "  |  NEVER MADE THE NHL"), W / 2, ry + rh - .03 * U, .018, "#94a3b8", AL_CENTER, 700);
  T("FINAL OVR " + istr(proOvr()) + "   |   HALL OF FAME: " + istr(proHofCareers) + (proHofCareers == 1 ? " CAREER" : " CAREERS") + "   |   MOST TITLES " + istr(proHofBest), W / 2, ry + rh + .04 * U, .02, "#cbd5e1", AL_CENTER, 700);
  double by = ry + rh + .08 * U, bw = .42 * U;
  ui("pnewc", W / 2 - bw - .01 * U, by, bw, .085 * U, "NEW CAREER", "#16a34a", true, .034); ui("nav:modes", W / 2 + .01 * U, by, bw, .085 * U, "MAIN MENU", "#475569", true, .034);
}
static void drawBusy() {
  TB("OFF-SEASON", W / 2, H * .4, .08, "#fff", AL_CENTER);
  T("CONTRACTS EXPIRE   |   THE DRAFT   |   FREE AGENCY   |   TRADES", W / 2, H * .4 + .075 * U, .022, "#f26b5b", AL_CENTER);
  T("Building next season...", W / 2, H * .4 + .13 * U, .02, "#94a3b8", AL_CENTER, 700);
  if (++busyF >= 3) { busyF = 0; proNextSeason(); }
}

static bool pre(const std::string &id, const char *p) { return id.rfind(p, 0) == 0; }
// ---------------------------------------------------------------- home: the apartment, and the phone that runs your career
static int phApp = -1, storeSlot = 0, phLast = 0, presPg = 0, newsMark = 0; static bool phOn = false; static std::string aptOv, aptToast; static double aptToastT = 0, phT0 = 0, aptLastT = 0, presT0 = 0;
struct AppDef { const char *n, *c0, *c1, *scr; };
static const AppDef APPS[] = {{"SCHEDULE", "#f8fafc", "#e2e8f0", "sched"}, {"MY HEALTH", "#fb7185", "#e11d48", "health"}, {"UPGRADES", "#fbbf24", "#d97706", "upg"},
  {"TRAINING", "#38bdf8", "#0284c7", "train"}, {"GM CONNECT", "#818cf8", "#4f46e5", "office"}, {"GEAR SHOP", "#fb923c", "#ea580c", "shop"},
  {"PERFORMANCE", "#c084fc", "#9333ea", "perf"}, {"LEAGUE", "#2dd4bf", "#0d9488", "stand"}, {"NEWS", "#f87171", "#b91c1c", "news"},
  {"GOALS", "#a3e635", "#4d7c0f", "goals"}, {"MESSAGES", "#4ade80", "#16a34a", "msgs"}, {"SETTINGS", "#94a3b8", "#475569", "settings"}, {"MY TEAM", "#60a5fa", "#1d4ed8", "myteam"}, {"HOCKEYMON", "#fbbf24", "#ea580c", "hockeymon"}, {"CASINO", "#f43f5e", "#7f1d1d", "casino"}, {"EXIT BE A PRO", "#334155", "#0f172a", ""}};
static const int NAPPS = (int)(sizeof APPS / sizeof APPS[0]);
bool proInPhone() { return phApp >= 0; }
static void toast(const std::string &s) { aptToast = s; aptToastT = now(); }
bool proAptWorld() { return mode == "pro" && CR && screen == "main" && !phOn && aptOv.empty() && phApp < 0 && C.phase != "retired" && !modal.on && aptReady(); }
static Grad vgrad(double y0, double y1, Col a, Col b) { Grad g = gLin(0, (float)y0, 0, (float)y1); g.add(0, a); g.add(1, b); return g; }
struct PhR { double x, y, w, h, sx, sy, sw, sh; };
static PhR phoneRect() {
  PhR r; r.h = std::min(H * .9, H - safeTop - .03 * U); r.w = r.h * .5; r.x = W - r.w - .035 * U; r.y = H - r.h - .02 * U;
  double e = clamp((now() - phT0) / 220, 0, 1); e = 1 - std::pow(1 - e, 3); r.y += (1 - e) * r.h * .7;
  double b = r.w * .045; r.sx = r.x + b; r.sy = r.y + b; r.sw = r.w - 2 * b; r.sh = r.h - 2 * b; return r;
}
static void phoneBody(const PhR &r) {
  ctx.fill(rgba(0, 0, 0, .35)); ctx.rr(r.x + 6, r.y + 8, r.w, r.h, r.w * .14); ctx.fillPath();
  ctx.fill("#1f2937"); ctx.rr(r.x - 2, r.y - 2, r.w + 4, r.h + 4, r.w * .15); ctx.fillPath(); ctx.fill("#0a0a0c"); ctx.rr(r.x, r.y, r.w, r.h, r.w * .14); ctx.fillPath();
  Col a = hex(teamCol(C.me)); ctx.fill(vgrad(r.sy, r.sy + r.sh, shade(a, -.25), hex("#0b1020"))); ctx.rr(r.sx, r.sy, r.sw, r.sh, r.w * .11); ctx.fillPath();
  ctx.fill("#0a0a0c"); ctx.rr(r.x + r.w * .36, r.sy + r.sh * .012, r.w * .28, r.sh * .028, r.sh * .014); ctx.fillPath();   // the island
}
// the status bar: date at the left, signal and battery at the right, both clear of the island in the middle
static void statusBar(double x, double y, double w, double h, bool island = true) {
  double k = std::min(h * .3, .011 * U), cy = y + h * .55, side = island ? w * .3 : w * .2;   // k: one unit of the icons
  T(C.cal.empty() || C.phase != "reg" ? "CHL" : calDate(C.ci), x + w * .07, cy, .0115, "#fff", AL_LEFT, 800); (void)side;
  double bx = x + w * .93 - k * 2.3; ctx.fill(rgba(255, 255, 255, .9));
  ctx.fillRect(bx, cy - k * .55, k * 2.1, k * 1.1); ctx.fill(rgba(0, 0, 0, .6)); ctx.fillRect(bx + k * .2, cy - k * .35, k * 1.7, k * .7);
  ctx.fill(rgba(255, 255, 255, .9)); ctx.fillRect(bx + k * .3, cy - k * .25, k * 1.2, k * .5); ctx.fillRect(bx + k * 2.1, cy - k * .25, k * .2, k * .5);
  for (int i = 0; i < 4; i++) ctx.fillRect(bx - k * (2.9 - i * .65), cy + k * .55 - k * (.35 + i * .3), k * .42, k * (.35 + i * .3));
}
// the icons: simple glyphs on rounded tiles
static void appIcon(int i, double x, double y, double s, bool dim) {
  ctx.alpha(dim ? .45f : 1); ctx.fill(vgrad(y, y + s, hex(APPS[i].c0), hex(APPS[i].c1))); ctx.rr(x, y, s, s, s * .24); ctx.fillPath();
  double cx = x + s / 2, cy = y + s / 2, u = s / 10; ctx.fill("#fff");
  switch (i) {
    case 0: ctx.fill("#ef4444"); ctx.fillRect(x + u * 2, y + u * 2, u * 6, u * 1.6); ctx.fill("#fff"); ctx.fillRect(x + u * 2, y + u * 3.6, u * 6, u * 4.4); ctx.font(u * 3.4); ctx.fill("#111827"); ctx.textMid(); ctx.fillText(istr(C.cal.empty() ? 1 : 1 + C.ci % 28), cx, y + u * 5.9); break;
    case 1: ctx.fillRect(cx - u * .9, cy - u * 3, u * 1.8, u * 6); ctx.fillRect(cx - u * 3, cy - u * .9, u * 6, u * 1.8); break;
    case 2: ctx.beginPath(); ctx.moveTo(cx, y + u * 2); ctx.lineTo(x + u * 7.6, y + u * 5.2); ctx.lineTo(x + u * 2.4, y + u * 5.2); ctx.closePath(); ctx.fillPath(); ctx.fillRect(cx - u * 1.1, y + u * 5, u * 2.2, u * 3); break;
    case 3: ctx.fillRect(x + u * 2.6, cy - u * .5, u * 4.8, u); ctx.fillRect(x + u * 1.6, cy - u * 2, u * 1.4, u * 4); ctx.fillRect(x + u * 7, cy - u * 2, u * 1.4, u * 4); ctx.fillRect(x + u * 1, cy - u * 1.2, u * .8, u * 2.4); ctx.fillRect(x + u * 8.2, cy - u * 1.2, u * .8, u * 2.4); break;
    case 4: ctx.fillRect(x + u * 2, y + u * 3.6, u * 6, u * 4); ctx.fill(APPS[4].c1); ctx.fillRect(x + u * 2, y + u * 5.2, u * 6, u * .5); ctx.fill("#fff"); ctx.fillRect(x + u * 3.8, y + u * 2.4, u * 2.4, u * .9); ctx.fillRect(x + u * 3.8, y + u * 2.4, u * .6, u * 1.4); ctx.fillRect(x + u * 5.6, y + u * 2.4, u * .6, u * 1.4); break;
    case 5: ctx.beginPath(); ctx.moveTo(x + u * 6.6, y + u * 1.8); ctx.lineTo(x + u * 7.6, y + u * 2.2); ctx.lineTo(x + u * 4.2, y + u * 7.2); ctx.lineTo(x + u * 3.2, y + u * 6.8); ctx.closePath(); ctx.fillPath(); ctx.fillRect(x + u * 1.6, y + u * 6.8, u * 3.2, u * 1.2); ctx.fill("#111827"); ctx.disc(x + u * 6.6, y + u * 7.6, u * .9); break;
    case 6: for (int k = 0; k < 4; k++) { double hh = u * (1.8 + k * 1.3); ctx.fillRect(x + u * (1.8 + k * 1.7), y + u * 8 - hh, u * 1.2, hh); } break;
    case 7: for (int k = 0; k < 4; k++) { ctx.fill(k ? "#fff" : "#fde68a"); ctx.fillRect(x + u * 2, y + u * (2.2 + k * 1.5), u * 6, u * 1.05); } ctx.fill(APPS[7].c1); for (int k = 0; k < 4; k++) ctx.fillRect(x + u * 5.6, y + u * (2.2 + k * 1.5), u * .25, u * 1.05); break;
    case 8: ctx.fillRect(x + u * 2, y + u * 2.2, u * 6, u * 5.6); ctx.fill(APPS[8].c1); ctx.fillRect(x + u * 2.7, y + u * 2.9, u * 4.6, u * 1.3); for (int k = 0; k < 3; k++) ctx.fillRect(x + u * 2.7, y + u * (4.8 + k * .9), u * (k == 2 ? 2.8 : 4.6), u * .45); break;
    case 9: for (int k = 0; k < 3; k++) { ctx.fill(k % 2 ? APPS[9].c1 : "#fff"); ctx.disc(cx, cy, u * (3.4 - k * 1.1)); } ctx.fill("#fff"); ctx.disc(cx, cy, u * .45); break;
    case 10: ctx.rr(x + u * 1.8, y + u * 2.2, u * 6.4, u * 4.4, u * 2); ctx.fillPath(); ctx.beginPath(); ctx.moveTo(x + u * 3, y + u * 6); ctx.lineTo(x + u * 2.4, y + u * 8); ctx.lineTo(x + u * 4.6, y + u * 6.2); ctx.closePath(); ctx.fillPath(); break;
    case 11: for (int k = 0; k < 8; k++) { double a = k * .785; ctx.save(); ctx.translate(cx + std::cos(a) * u * 2.6, cy + std::sin(a) * u * 2.6); ctx.fillRect(-u * .7, -u * .7, u * 1.4, u * 1.4); ctx.restore(); }
      ctx.disc(cx, cy, u * 2.7); ctx.fill(APPS[11].c1); ctx.disc(cx, cy, u * 1.1); break;
    case 12: ctx.alpha(dim ? .3f : .7f); ctx.disc(x + u * 6.4, y + u * 3.6, u * 1.3); ctx.rr(x + u * 4.4, y + u * 5.4, u * 4, u * 2.6, u * 1.2); ctx.fillPath(); ctx.alpha(dim ? .45f : 1);   // two of you: a team
      ctx.disc(x + u * 4, y + u * 3.9, u * 1.5); ctx.rr(x + u * 1.6, y + u * 5.9, u * 4.8, u * 2.6, u * 1.3); ctx.fillPath(); break;
    case 13: { ctx.rr(x + u * 2.6, y + u * 1.6, u * 4.8, u * 6.8, u * .7); ctx.fillPath(); ctx.fill(APPS[13].c1); ctx.disc(x + u * 5, y + u * 4.6, u * 1.7);   // a card with a little monster
      ctx.fill("#fff"); ctx.disc(x + u * 4.4, y + u * 4.3, u * .5); ctx.disc(x + u * 5.6, y + u * 4.3, u * .5); ctx.fill("#111827"); ctx.disc(x + u * 4.5, y + u * 4.4, u * .25); ctx.disc(x + u * 5.7, y + u * 4.4, u * .25); break; }
    case 14: { ctx.rr(x + u * 1.6, y + u * 2.4, u * 4.2, u * 5.6, u * .6); ctx.fillPath(); ctx.save(); ctx.translate(x + u * 6, y + u * 5); ctx.rotate(.3);   // two cards and a chip
      ctx.fill("#fde68a"); ctx.rr(-u * 2, -u * 2.8, u * 4.2, u * 5.6, u * .6); ctx.fillPath(); ctx.restore(); ctx.fill("#ef4444"); ctx.disc(x + u * 3.6, y + u * 5.2, u * 1.1);
      ctx.fill("#111827"); ctx.disc(x + u * 3.6, y + u * 3.9, u * .5); ctx.disc(x + u * 3.1, y + u * 4.6, u * .5); ctx.disc(x + u * 4.1, y + u * 4.6, u * .5); ctx.fill("#fff"); ctx.disc(x + u * 3.6, y + u * 5.2, u * .35); break; }
    case 15: ctx.fillRect(x + u * 2, y + u * 2, u * 3.6, u * 6); ctx.fill(APPS[15].c1); ctx.fillRect(x + u * 2.5, y + u * 2.5, u * 2.6, u * 5); ctx.fill("#fff");
      ctx.beginPath(); ctx.moveTo(x + u * 8.3, cy); ctx.lineTo(x + u * 6.4, cy - u * 1.6); ctx.lineTo(x + u * 6.4, cy + u * 1.6); ctx.closePath(); ctx.fillPath(); ctx.fillRect(x + u * 4.2, cy - u * .5, u * 2.4, u); break;
  }
  ctx.alpha(1);
}
// the training app shows an update ring: full and ready on an off day, otherwise still "installing"
static void trainRing(double x, double y, double s, bool ready) {
  double cx = x + s / 2, cy = y + s / 2, r = s * .62;
  ctx.lineWidth(std::max(2.0, s * .06)); ctx.stroke(rgba(255, 255, 255, .25)); ctx.ring(cx, cy, r);
  double a0 = -1.5708, a1 = ready ? a0 + 6.2832 : a0 + 6.2832 * (.18 + .1 * std::sin(now() / 900)), sp = ready ? 0 : now() / 700;
  ctx.stroke(ready ? hex("#4ade80") : hex("#94a3b8")); ctx.beginPath(); ctx.arc(cx, cy, r, a0 + sp, a1 + sp); ctx.strokePath();
}
static int appBadge(int i) {
  if (i == 4) return (C.need ? 1 : 0) + (int)C.offers.size() + (C.showTrade && C.hasTrade ? 1 : 0);
  if (i == 1) return C.phase != "over" && userHurt() ? 1 : 0;
  if (i == 3) return canTrain() ? 1 : 0;
  if (i == 8) return C.newsN > C.newsSeen ? -1 : 0;   // -1: the "!" badge
  if (i == 10) return proUnreadTexts();
  if (i == 13) { int n = 0; for (int k = 0; k < HM_NP; k++) n += C.hmDoor[k]; return n; }
  return 0;
}
static void drawPhoneGrid() {
  PhR r = phoneRect(); phoneBody(r); double sb = r.sh * .06; statusBar(r.sx, r.sy, r.sw, sb); struct TK { TK() { g_txK = 1.12; } ~TK() { g_txK = 1; } } tk_;
  double top = r.sy + sb + r.sh * .02; TB("$" + fmtN(C.money), r.sx + r.sw / 2, top + r.sh * .02, .028, "#ffd54a", AL_CENTER);
  T(upper(C.nm) + "  |  OVR " + istr(proOvr()) + "  |  " + fmtN(C.xp) + " XP", r.sx + r.sw / 2, top + r.sh * .06, .0125, "#cbd5e1", AL_CENTER, 700);
  int cols = 4; double gx = r.sw * .055, s = (r.sw - gx * (cols + 1)) / cols, gy = s * .55, y0 = top + r.sh * .1;
  for (int i = 0; i < NAPPS; i++) { int c = i % cols, rw = i / cols; double x = r.sx + gx + c * (s + gx), y = y0 + rw * (s + gy);
    bool dim = i == 3 && !canTrain(); appIcon(i, x, y, s, dim); if (i == 3) trainRing(x, y, s, !dim);
    int b = appBadge(i); if (b && i != 3) { double br = s * .2; ctx.fill("#ef4444"); ctx.disc(x + s - br * .4, y + br * .4, br); ctx.font(br * 1.25); ctx.fill("#fff"); ctx.textMid(); ctx.fillText(b < 0 ? "!" : istr(b), x + s - br * .4, y + br * .4 + 1); }
    ctx.font(std::min(.0105 * U, s * .17)); ctx.fill("#fff"); ctx.textMid(); ctx.fillText(APPS[i].n, x + s / 2, y + s + s * .2);
    pushBtn("app:" + istr(i), x - gx * .3, y - gx * .3, s + gx * .6, s + s * .32 + gx * .3, APPS[i].n); }
  double dy = r.sy + r.sh - r.sh * .1; ctx.fill(rgba(255, 255, 255, .12)); ctx.rr(r.sx + r.sw * .05, dy, r.sw * .9, r.sh * .075, r.sh * .03); ctx.fillPath();
  T("X OPEN   O / START CLOSE", r.sx + r.sw / 2, dy + r.sh * .0375, .0125, "#e2e8f0", AL_CENTER, 700);
  ctx.fill(rgba(255, 255, 255, .7)); ctx.rr(r.sx + r.sw * .34, r.sy + r.sh - r.sh * .018, r.sw * .32, r.sh * .008, r.sh * .004); ctx.fillPath();
  pushBtn("ph:close", 0, 0, 0, 0, "BACK", true);
}
// the stores on the phone: a spot in the apartment (build mode), the kitchen counter
static void storeRow(const std::string &id, const HomeOpt &o, double x, double yy, double w, double rh, double sh, const std::string &tag, const char *tagC, bool hi, bool ok) {
  ctx.fill(hi ? rgba(56, 189, 248, .22) : rgba(255, 255, 255, .08)); ctx.rr(x, yy, w, rh, sh * .02); ctx.fillPath(); if (hi) { ctx.fill("#38bdf8"); ctx.fillRect(x, yy + rh * .15, 3, rh * .7); }
  TF(o.n, x + w * .05, yy + rh * .2, .0155, w * .55, ok ? "#fff" : "#94a3b8"); TF(tag, x + w * .95, yy + rh * .2, .014, w * .36, tagC, AL_RIGHT);
  txWrap(o.d, x + w * .05, yy + rh * .46, .0118, w * .9, hex("#cbd5e1"), AL_LEFT, 700, 1);
  std::string fx = homeFxTxt(o.fx); if (!fx.empty()) TF(fx, x + w * .05, yy + rh * .78, .0118, w * .9, "#7CFC9A");
  pushBtn(id, x, yy, w, rh, o.n); if (!ok) btns.back().dis = true;
}
// the colour picker: the swatches for what you're about to buy (or recolour), a big preview, then BUY / USE
static int pickSlot = -1, pickOpt = -1, pickCol = -1; static bool pickCtr = false;
static void pickClose() { pickSlot = pickOpt = -1; pickCtr = false; }
static bool drawPicker(const PhR &r) {
  if (pickOpt < 0) return false;
  const std::vector<Swatch> &sw = pickCtr ? ctrSwatches() : homeSwatches(pickSlot, pickOpt); const HomeOpt &o = pickCtr ? COUNTER[(size_t)pickOpt] : HSLOT[pickSlot].o[(size_t)pickOpt];
  bool own = pickCtr ? (HOME.ctrOwn >> pickOpt & 1) : (HOME.own[pickSlot] >> pickOpt & 1);
  double sb = r.sh * .06, x = r.sx + r.sw * .06, w = r.sw * .88, y = r.sy + sb + r.sh * .02;
  ctx.fill(rgba(4, 8, 18, .96)); ctx.fillRect(r.sx, r.sy + sb, r.sw, r.sh - sb);
  T("PICK A COLOUR", x, y + r.sh * .01, .013, "#94a3b8", AL_LEFT, 800); TB("$" + fmtN(C.money), x + w, y + r.sh * .01, .022, "#ffd54a", AL_RIGHT);
  TF(o.n, x, y + r.sh * .05, .022, w, "#fff"); y += r.sh * .085;
  // the preview: a big chip of the colour (the original: shown as a plain grey check)
  double ph = r.sh * .14; if (pickCol >= 0) { ctx.fill(hex(sw[(size_t)pickCol].c)); ctx.rr(x, y, w, ph, r.sh * .02); ctx.fillPath(); ctx.fill(rgba(255, 255, 255, .12)); ctx.fillRect(x, y, w, ph * .35); }
  else { for (int i = 0; i < 12; i++) { ctx.fill(i & 1 ? hex("#475569") : hex("#334155")); ctx.fillRect(x + w * i / 12, y, w / 12 + 1, ph); } }
  T(pickCol >= 0 ? sw[(size_t)pickCol].n : "AS IT COMES", x + w / 2, y + ph / 2, .02, pickCol >= 0 && (hex(sw[(size_t)pickCol].c).r + hex(sw[(size_t)pickCol].c).g + hex(sw[(size_t)pickCol].c).b) > 1.9f ? "#0f172a" : "#fff", AL_CENTER, 800);
  y += ph + r.sh * .025;
  // the swatches (the first: as it comes)
  int n = (int)sw.size() + 1, cols = 5; double gap = w * .03, sz = (w - gap * (cols - 1)) / cols, sh = std::min(sz * .62, (r.sh * .82 - (y - r.sy)) / ((n + cols - 1) / cols) - gap);
  for (int k = -1; k < (int)sw.size(); k++) { int i = k + 1; double sx = x + (i % cols) * (sz + gap), sy = y + (i / cols) * (sh + gap); bool on = k == pickCol;
    if (k < 0) { ctx.fill(hex("#334155")); ctx.rr(sx, sy, sz, sh, sh * .2); ctx.fillPath(); T("ORIGINAL", sx + sz / 2, sy + sh / 2, .0105, "#cbd5e1", AL_CENTER, 800); }
    else { ctx.fill(hex(sw[(size_t)k].c)); ctx.rr(sx, sy, sz, sh, sh * .2); ctx.fillPath(); }
    if (on) { ctx.stroke("#ffd54a"); ctx.lineWidth(3); ctx.rr(sx - 2, sy - 2, sz + 4, sh + 4, sh * .22); ctx.strokePath(); }
    pushBtn("hcol:" + istr(k), sx, sy, sz, sh, k < 0 ? "ORIGINAL" : sw[(size_t)k].n); }
  double by = r.sy + r.sh * .86, bw = w * .62;
  std::string lb = own ? "USE IT" : "BUY  $" + fmtN(o.c); bool ok = own || C.money >= o.c;
  ui("hpick:ok", x, by, bw, r.sh * .07, lb, ok ? "#16a34a" : "#475569", ok, .022); if (!ok) btns.back().dis = true;
  ui("hpick:no", x + bw + w * .04, by, w - bw - w * .04, r.sh * .07, "BACK", "#475569", true, .02);
  T("PICK A SWATCH, THEN X ON " + std::string(own ? "USE IT" : "BUY") + "   O BACK", r.sx + r.sw / 2, r.sy + r.sh * .955, .0115, "#94a3b8", AL_CENTER, 700);
  pushBtn("ph:close", 0, 0, 0, 0, "BACK", true);
  return true;
}
static void drawPhoneStore() {
  PhR r = phoneRect(); phoneBody(r); double sb = r.sh * .06; statusBar(r.sx, r.sy, r.sw, sb);
  if (drawPicker(r)) return;
  int sl = storeSlot; const HomeSlotDef &D = HSLOT[sl]; double x = r.sx + r.sw * .06, w = r.sw * .88, y = r.sy + sb + r.sh * .02;
  T("HOME STORE", x, y + r.sh * .01, .013, "#94a3b8", AL_LEFT, 800); TB("$" + fmtN(C.money), x + w, y + r.sh * .01, .022, "#ffd54a", AL_RIGHT);
  TF(homeSlotName(sl), x, y + r.sh * .05, .022, w, "#fff"); y += r.sh * .085;
  bool needWall = sl >= HS_PAINT && sl < HS_PAINT + HOME_NR && HOME.sel[HS_WALL + sl - HS_PAINT] == 0;
  int n = (int)D.o.size(); double rh = std::min(r.sh * .17, (r.sh * .9 - (y - r.sy)) / n - r.sh * .012);
  for (int i = 0; i < n; i++) { const HomeOpt &o = D.o[(size_t)i]; bool own = HOME.own[sl] >> i & 1, eq = HOME.sel[sl] == i, ok = (own || C.money >= o.c) && !(needWall && i > 0);
    storeRow("hb:" + istr(sl) + ":" + istr(i), o, x, y + i * (rh + r.sh * .012), w, rh, r.sh, eq ? "IN USE" : own ? "OWNED" : o.c ? "$" + fmtN(o.c) : "FREE", eq ? "#38bdf8" : own ? "#7CFC9A" : ok ? "#ffd54a" : "#fca5a5", eq, ok); }
  if (HOME.col[sl] >= 0) { const auto &sw = homeSwatches(sl, HOME.sel[sl]); if (HOME.col[sl] < (int)sw.size()) { double yy = y + HOME.sel[sl] * (rh + r.sh * .012), d = rh * .26; ctx.fill(hex(sw[(size_t)HOME.col[sl]].c)); ctx.disc(x + w * .95 - w * .36 - d, yy + rh * .2, d * .5); } }
  T(needWall ? "FIX THE DRYWALL FIRST" : "X BUY / USE (THEN PICK A COLOUR)   O BACK", r.sx + r.sw / 2, r.sy + r.sh * .955, .0125, needWall ? "#fca5a5" : "#94a3b8", AL_CENTER, 700);
  pushBtn("ph:close", 0, 0, 0, 0, "BACK", true);
}
static void drawPhoneCounter() {
  PhR r = phoneRect(); phoneBody(r); double sb = r.sh * .06; statusBar(r.sx, r.sy, r.sw, sb);
  if (drawPicker(r)) return;
  double x = r.sx + r.sw * .05, w = r.sw * .9, y = r.sy + sb + r.sh * .015; int out = 0; for (int k = 0; k < HOME_NCTR; k++) if (HOME.ctr[k] >= 0) out++;
  T("THE COUNTER  |  " + istr(out) + " / " + istr(HOME_NCTR) + " OUT", x, y + r.sh * .01, .013, "#94a3b8", AL_LEFT, 800); TB("$" + fmtN(C.money), x + w, y + r.sh * .01, .022, "#ffd54a", AL_RIGHT); y += r.sh * .04;
  int n = (int)COUNTER.size(); double rh = (r.sh * .91 - (y - r.sy)) / n - r.sh * .006;
  for (int i = 0; i < n; i++) { const HomeOpt &o = COUNTER[(size_t)i]; bool own = HOME.ctrOwn >> i & 1, on = homeCtrOut(i), ok = on || ((own || C.money >= o.c) && out < HOME_NCTR);
    double yy = y + i * (rh + r.sh * .006); ctx.fill(on ? rgba(56, 189, 248, .22) : rgba(255, 255, 255, .08)); ctx.rr(x, yy, w, rh, r.sh * .015); ctx.fillPath();
    TF(o.n, x + w * .04, yy + rh * .32, .0145, w * .55, ok ? "#fff" : "#94a3b8"); TF(on ? "ON THE COUNTER" : own ? "IN THE CUPBOARD" : "$" + fmtN(o.c), x + w * .96, yy + rh * .32, .0125, w * .4, on ? "#38bdf8" : own ? "#7CFC9A" : ok ? "#ffd54a" : "#fca5a5", AL_RIGHT);
    TF(homeFxTxt(o.fx), x + w * .04, yy + rh * .72, .0112, w * .92, "#7CFC9A"); pushBtn("hc:" + istr(i), x, yy, w, rh, o.n); if (!ok) btns.back().dis = true; }
  T("X BUY / PUT OUT / PUT AWAY   O BACK", r.sx + r.sw / 2, r.sy + r.sh * .955, .012, "#94a3b8", AL_CENTER, 700);
  pushBtn("ph:close", 0, 0, 0, 0, "BACK", true);
}
static void drawHealth() {
  double m = .03 * U, top = safeTop + .14 * U; PP *Y = youMe(); InjRisk k = injRisk(); bool hurt = C.phase != "over" && userHurt();
  scrHead("MY HEALTH", hurt ? "INJURED  |  OUT " + istr(Y ? Y->inj : 0) + " MORE GAMES" : "CLEARED TO PLAY");
  double lw = W * .36; panel(m, top, lw, H - top - .13 * U); accentBar(m, top, H - top - .13 * U, hex(hurt ? "#ef4444" : "#22c55e"));
  T("STATUS", m + .03 * U, top + .04 * U, .017, "#94a3b8", AL_LEFT, 700); TB(hurt ? "INJURED" : "HEALTHY", m + .03 * U, top + .1 * U, .06, hurt ? "#fca5a5" : "#7CFC9A");
  if (hurt && Y) { TF(upper(Y->it) + " INJURY", m + .03 * U, top + .16 * U, .022, lw - .06 * U, "#fff"); T(istr(Y->inj) + (Y->inj == 1 ? " GAME TO GO" : " GAMES TO GO"), m + .03 * U, top + .2 * U, .018, "#cbd5e1", AL_LEFT, 700); }
  else T("No knocks. Keep it that way.", m + .03 * U, top + .16 * U, .018, "#cbd5e1", AL_LEFT, 700);
  double pg = k.p * 100, ps = (1 - std::pow(1 - k.p, PRO_GAMES)) * 100;
  T("RISK PER GAME", m + .03 * U, top + .27 * U, .016, "#94a3b8", AL_LEFT, 700); TB(fixed(pg, 2) + "%", m + .03 * U, top + .32 * U, .045, pg > .5 ? "#fca5a5" : "#fff");
  T("OVER A FULL SEASON", m + .03 * U, top + .38 * U, .016, "#94a3b8", AL_LEFT, 700); TB(istr((int)jround(ps)) + "%", m + .03 * U, top + .43 * U, .045, ps > 30 ? "#fca5a5" : "#fff");
  double rx = m + lw + .02 * U, rw = W - rx - m, y = top; panel(rx, y, rw, H - top - .13 * U, .6);
  TB("WHAT DRIVES YOUR RISK", rx + .025 * U, y + .04 * U, .024, "#f26b5b"); y += .09 * U;
  auto fac = [&](const std::string &n, const std::string &why, double f) {
    T(n, rx + .025 * U, y, .019, "#fff", AL_LEFT, 800); TB("x" + fixed(f, 2), rx + rw - .025 * U, y, .024, f > 1.02 ? "#fca5a5" : f < .98 ? "#7CFC9A" : "#cbd5e1", AL_RIGHT);
    TF(why, rx + .025 * U, y + .03 * U, .015, rw - .05 * U, "#94a3b8"); double bw = rw - .05 * U; ctx.fill(rgba(148, 163, 184, .2)); ctx.rr(rx + .025 * U, y + .052 * U, bw, 4, 2); ctx.fillPath();
    ctx.fill(f > 1.02 ? "#ef4444" : f < .98 ? "#22c55e" : "#94a3b8"); ctx.fillRect(rx + .025 * U, y + .052 * U, bw * clamp(f / 2, 0, 1), 4); y += .1 * U; };
  fac("AGE " + istr(C.age), C.age <= 24 ? "Young legs bounce back." : C.age <= 29 ? "Prime years: no extra risk." : "Every year past 29 adds about 7%.", k.age);
  fac("CONTACT", k.games ? fixed(k.hitsPG, 1) + " hits a game over your last " + istr(k.games) + " games. Play the body, pay the price." : "No games played yet.", k.hits);
  fac("GEAR", k.gear < 1 ? "Your helmet and gear take some of the hits." : k.gear > 1 ? "Light gear: faster, but less protection." : "Standard protection. The gear shop has better.", k.gear);
  T("Injuries also knock a point off two of your ratings.", rx + .025 * U, y + .01 * U, .015, "#64748b", AL_LEFT, 700);
  back("nav:main", H - .1 * U);
}
// Messages: teammates text you after games - praise or a scolding - and you pick one of three answers (chemistry moves)
static int msgSel = -1;   // the open conversation (index into the sender list)
static std::vector<std::string> msgSenders() {   // newest conversation first
  std::vector<std::string> v; for (int i = (int)C.texts.size() - 1; i >= 0; i--) { const std::string &f = C.texts[(size_t)i].from; if (std::find(v.begin(), v.end(), f) == v.end()) v.push_back(f); } return v; }
static Col nameCol(const std::string &nm) { static const char *P[8] = {"#ef4444", "#f59e0b", "#22c55e", "#06b6d4", "#3b82f6", "#8b5cf6", "#ec4899", "#14b8a6"}; unsigned h = 0; for (char c : nm) h = h * 31 + (unsigned char)c; return hex(P[h % 8]); }
static std::string initials(const std::string &nm) { std::string s; bool st = true; for (char c : nm) { if (c == ' ') st = true; else if (st) { s += (char)toupper((unsigned char)c); st = false; } } return s.substr(0, 2); }
static void avatarDisc(double cx, double cy, double r, const std::string &nm) { ctx.fill(nameCol(nm)); ctx.disc(cx, cy, r); ctx.fill("#fff"); ctx.font(r * .85); ctx.textMid(); ctx.fillText(initials(nm), cx, cy + 1); }
static void drawMsgs() {
  scrHead("MESSAGES", "YOUR TEAMMATES  |  ANSWER TO BUILD CHEMISTRY");
  double m = .03 * U, top = safeTop + .12 * U, bot = H - .085 * U; auto S = msgSenders();
  if (S.empty()) { double cx = W / 2, cy = H * .42; ctx.fill(rgba(74, 222, 128, .2)); ctx.rr(cx - .09 * U, cy - .1 * U, .18 * U, .11 * U, .04 * U); ctx.fillPath();
    TB("No messages yet.", cx, cy + .07 * U, .032, "#fff", AL_CENTER); T("Play games - your teammates will be in touch.", cx, cy + .115 * U, .018, "#94a3b8", AL_CENTER, 700);
    footHints(PADH); return; }
  if (msgSel < 0 || msgSel >= (int)S.size()) { msgSel = 0; for (int k = 0; k < (int)S.size(); k++) { bool un = false; for (auto &t : C.texts) if (t.from == S[(size_t)k] && t.ans == -1) un = true; if (un) { msgSel = k; break; } } }
  // left: the conversations
  double lw = W * .3, rh = .075 * U, y = top;
  for (int k = 0; k < (int)S.size() && y + rh <= bot; k++) { const std::string &f = S[(size_t)k]; const PText *last = nullptr; bool un = false;
    for (auto &t : C.texts) if (t.from == f) { last = &t; if (t.ans == -1) un = true; }
    glass(m, y, lw, rh - .008 * U, .55); if (k == msgSel) { ctx.fill(rgba(74, 222, 128, .12)); ctx.rr(m, y, lw, rh - .008 * U, .015 * U); ctx.fillPath(); accentBar(m, y, rh - .008 * U, hex("#4ade80")); }
    avatarDisc(m + .045 * U, y + (rh - .008 * U) / 2, .024 * U, f);
    TF(upper(f), m + .08 * U, y + rh * .3, .017, lw - .12 * U, "#fff"); TF(last ? (last->ans >= 0 ? last->re[last->ans] : last->body) : std::string(), m + .08 * U, y + rh * .62, .0135, lw - .13 * U, "#94a3b8");
    if (un) { ctx.fill("#4ade80"); ctx.disc(m + lw - .02 * U, y + (rh - .008 * U) / 2, .008 * U); }
    pushBtn("msg:t:" + istr(k), m, y, lw, rh - .008 * U, f); y += rh; }
  // right: the conversation
  const std::string &who = S[(size_t)msgSel]; double rx = m + lw + .02 * U, rw = W - rx - m; glass(rx, top, rw, bot - top, .6);
  avatarDisc(rx + .04 * U, top + .035 * U, .022 * U, who); TB(upper(who), rx + .075 * U, top + .027 * U, .022, "#fff");
  { double ch = proChem(who); const char *cc = ch >= 70 ? "#4ade80" : ch >= 45 ? "#e2e8f0" : "#f87171"; T("CHEMISTRY " + istr((int)jround(ch)), rx + rw - .025 * U, top + .03 * U, .016, cc, AL_RIGHT, 800); }
  ctx.fill(rgba(255, 255, 255, .08)); ctx.fillRect(rx + .02 * U, top + .065 * U, rw - .04 * U, 1);
  int open = -1; for (int i = 0; i < (int)C.texts.size(); i++) if (C.texts[(size_t)i].from == who && C.texts[(size_t)i].ans == -1) open = i;
  double optH = .052 * U, tgx = open >= 0 && C.texts[(size_t)open].gk >= 0 ? .028 * U : 0, chatBot = open >= 0 ? bot - 3 * (optH + .008 * U) - .015 * U - tgx : bot - .015 * U;
  struct Bub { int side; std::string s; Col c; }; std::vector<Bub> B;   // side: 0 him, 1 you, 2 a day line
  for (auto &t : C.texts) if (t.from == who) { B.push_back({2, (t.season != C.season ? "SEASON " + istr(t.season) + "  |  " : std::string()) + "AFTER GAME " + istr(t.day + 1), Col(0, 0, 0)});
    B.push_back({0, t.body, t.kind == 3 ? Col(67, 56, 120) : t.kind > 0 ? Col(30, 64, 52) : Col(76, 29, 36)}); if (t.ans >= 0) { B.push_back({1, t.opt[t.ans], Col(37, 99, 235)}); B.push_back({0, t.re[t.ans], Col(45, 55, 72)}); } }
  double fs = fsz(.0175) * U, lh = fs * 1.25, by = chatBot, maxW = rw * .66; ctx.font(fs);
  for (int k = (int)B.size() - 1; k >= 0; k--) { const Bub &b = B[(size_t)k];
    if (b.side == 2) { if (by - .03 * U < top + .075 * U) break; by -= .03 * U; T(b.s, rx + rw / 2, by + .014 * U, .013, "#64748b", AL_CENTER, 800); continue; }
    ctx.font(fs); auto L = wrapText(b.s, maxW - .03 * U); double bw = 0; for (auto &l : L) bw = std::max(bw, (double)ctx.measure(l)); bw += .03 * U; double bh = L.size() * lh + .02 * U;
    if (by - bh - .01 * U < top + .075 * U) break; by -= bh + .01 * U; double bx = b.side == 1 ? rx + rw - .025 * U - bw : rx + .025 * U;
    ctx.fill(b.c); ctx.rr(bx, by, bw, bh, std::min(bh / 2, .02 * U)); ctx.fillPath();
    for (size_t i = 0; i < L.size(); i++) T(L[i], bx + .015 * U, by + .01 * U + lh * (i + .5), .0175, "#fff", AL_LEFT, 700); }
  if (open >= 0) { const PText &t = C.texts[(size_t)open]; double oy = chatBot + .01 * U + tgx;
    for (int k = 0; k < 3; k++) { ui("msg:r:" + istr(open) + ":" + istr(k), rx + .025 * U, oy, rw - .05 * U, optH, t.opt[k], "#334155", true, .02); oy += optH + .008 * U; }
    if (t.gk >= 0) T("TEAM GOAL - SHOWS UP IN YOUR GOALS APP IF YOU TAKE IT ON", rx + rw / 2, chatBot + .022 * U, .0125, "#a78bfa", AL_CENTER, 800); }
  footHints({{"D-PAD", "MOVE"}, {"X", "SELECT / REPLY"}, {"O", "BACK"}});
}
// ---------------------------------------------------------------- the casino: blackjack and slots for real (career) cash
static int casTab = 0, casBet = 1; static long casNet = 0;   // this visit's net (resets when the app opens)
static const int CAS_BETS[5] = {10, 25, 100, 500, 1000};
struct BJ { std::vector<int> deck, ph, dh; int st = 0, bet = 0; bool dbl = false; std::string msg; double t = 0; } BJS;   // st: 0 betting, 1 your turn, 2 the hand is over
static int bjVal(const std::vector<int> &h, bool *soft = nullptr) { int v = 0, a = 0; for (int c : h) { int r = c % 13; v += r == 0 ? 11 : r >= 10 ? 10 : r + 1; if (r == 0) a++; } while (v > 21 && a) { v -= 10; a--; } if (soft) *soft = a > 0; return v; }
static int bjDraw() { if (BJS.deck.empty()) { for (int d = 0; d < 4; d++) for (int i = 0; i < 52; i++) BJS.deck.push_back(i); for (size_t i = BJS.deck.size(); i > 1; i--) std::swap(BJS.deck[i - 1], BJS.deck[(size_t)std::floor(rnd() * i) % i]); }
  int c = BJS.deck.back(); BJS.deck.pop_back(); return c; }
static void casPay(int delta) { C.money += delta; casNet += delta; proSave(); }
static void bjFinish() {
  int p = bjVal(BJS.ph); bool pbj = BJS.ph.size() == 2 && p == 21 && !BJS.dbl;
  if (p <= 21 && !pbj) { bool soft; while (true) { int d = bjVal(BJS.dh, &soft); if (d < 17) BJS.dh.push_back(bjDraw()); else break; } }
  int d = bjVal(BJS.dh); bool dbj = BJS.dh.size() == 2 && d == 21; int b = BJS.bet;
  if (p > 21) { BJS.msg = "BUST - YOU LOSE $" + fmtN(b); }
  else if (pbj && !dbj) { trophyUnlock(TR_NATURAL); casPay(b + b * 3 / 2); BJS.msg = "BLACKJACK! +$" + fmtN(b * 3 / 2); sfx(S_HORN, .4); }
  else if (dbj && !pbj) BJS.msg = "DEALER BLACKJACK - YOU LOSE $" + fmtN(b);
  else if (d > 21 || p > d) { casPay(2 * b); BJS.msg = (d > 21 ? "DEALER BUSTS - " : "YOU WIN - ") + std::string("+$") + fmtN(b); sfx(S_CHEER, .3); }
  else if (p == d) { casPay(b); BJS.msg = "PUSH - YOUR BET COMES BACK"; }
  else BJS.msg = "DEALER WINS - YOU LOSE $" + fmtN(b);
  BJS.st = 2; BJS.t = now();
}
// slots: three reels, weighted symbols (about 92% comes back over time)
static const char *SLN[6] = {"CHERRY", "LEMON", "BELL", "PUCK", "BAR", "7"}; static const int SLW[6] = {5, 5, 4, 3, 2, 1};
struct SL { int r[3] = {5, 4, 3}, fin[3] = {5, 4, 3}; double t0 = -1e9; bool spin = false; int bet = 0; std::string msg; } SLS;
static int slRoll() { int t = (int)std::floor(rnd() * 20) % 20; for (int i = 0; i < 6; i++) { if (t < SLW[i]) return i; t -= SLW[i]; } return 0; }
static int slPay(const int *r) {   // the multiple of the bet paid back
  if (r[0] == r[1] && r[1] == r[2]) { static const int M[6] = {8, 5, 10, 15, 20, 50}; return M[r[0]]; }
  if (r[0] == 0 && r[1] == 0) return 4; if (r[0] == 0) return 2; return 0; }
static void slSym(int k, double cx, double cy, double sz) {
  switch (k) {
    case 0: ctx.stroke("#15803d"); ctx.lineWidth(sz * .06); ctx.line(cx - sz * .15, cy + sz * .05, cx + sz * .05, cy - sz * .3); ctx.line(cx + sz * .17, cy + sz * .08, cx + sz * .05, cy - sz * .3);
      ctx.fill("#dc2626"); ctx.disc(cx - sz * .17, cy + sz * .12, sz * .15); ctx.disc(cx + sz * .17, cy + sz * .15, sz * .15); ctx.fill(rgba(255, 255, 255, .5)); ctx.disc(cx - sz * .21, cy + sz * .07, sz * .04); break;
    case 1: ctx.fill("#facc15"); ctx.oval(cx, cy, sz * .3, sz * .21); ctx.fill("#eab308"); ctx.disc(cx + sz * .3, cy, sz * .05); ctx.disc(cx - sz * .3, cy, sz * .05); break;
    case 2: ctx.fill("#f59e0b"); ctx.beginPath(); ctx.moveTo(cx - sz * .26, cy + sz * .18); ctx.lineTo(cx - sz * .18, cy - sz * .1); ctx.arc(cx, cy - sz * .12, sz * .18, PI, 0); ctx.lineTo(cx + sz * .26, cy + sz * .18); ctx.closePath(); ctx.fillPath();
      ctx.fill("#b45309"); ctx.disc(cx, cy + sz * .24, sz * .06); break;
    case 3: ctx.fill("#111827"); ctx.oval(cx, cy + sz * .08, sz * .3, sz * .1); ctx.fillRect(cx - sz * .3, cy - sz * .08, sz * .6, sz * .16); ctx.fill("#374151"); ctx.oval(cx, cy - sz * .08, sz * .3, sz * .1); break;
    case 4: ctx.fill("#111827"); ctx.rr(cx - sz * .32, cy - sz * .13, sz * .64, sz * .26, sz * .04); ctx.fillPath(); T("BAR", cx, cy, .02 * sz / (.1 * U), "#fff", AL_CENTER, 900); break;
    default: TB("7", cx, cy, .06 * sz / (.1 * U), "#dc2626", AL_CENTER); break;
  }
}
// a playing card: c 0..51 (rank = c % 13, suit = c / 13 % 4), or face down
static void cardDraw(int c, double x, double y, double w, double h, bool down) {
  ctx.fill(rgba(0, 0, 0, .3)); ctx.rr(x + 2, y + 3, w, h, w * .1); ctx.fillPath();
  if (down) { ctx.fill("#1d4ed8"); ctx.rr(x, y, w, h, w * .1); ctx.fillPath(); ctx.stroke(rgba(255, 255, 255, .6)); ctx.lineWidth(2); ctx.rr(x + w * .08, y + w * .08, w * .84, h - w * .16, w * .06); ctx.strokePath(); return; }
  ctx.fill("#f8fafc"); ctx.rr(x, y, w, h, w * .1); ctx.fillPath();
  int r = c % 13, su = c / 13 % 4; static const char *RN[13] = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"}; Col col = su == 1 || su == 2 ? hex("#dc2626") : hex("#111827");
  auto suit = [&](double cx, double cy, double k) { ctx.fill(col);
    if (su == 1) { ctx.disc(cx - k * .25, cy - k * .12, k * .28); ctx.disc(cx + k * .25, cy - k * .12, k * .28); ctx.beginPath(); ctx.moveTo(cx - k * .52, cy - k * .04); ctx.lineTo(cx + k * .52, cy - k * .04); ctx.lineTo(cx, cy + k * .55); ctx.closePath(); ctx.fillPath(); }
    else if (su == 2) { ctx.beginPath(); ctx.moveTo(cx, cy - k * .55); ctx.lineTo(cx + k * .4, cy); ctx.lineTo(cx, cy + k * .55); ctx.lineTo(cx - k * .4, cy); ctx.closePath(); ctx.fillPath(); }
    else if (su == 0) { ctx.disc(cx - k * .25, cy + k * .12, k * .28); ctx.disc(cx + k * .25, cy + k * .12, k * .28); ctx.beginPath(); ctx.moveTo(cx - k * .52, cy + k * .04); ctx.lineTo(cx + k * .52, cy + k * .04); ctx.lineTo(cx, cy - k * .55); ctx.closePath(); ctx.fillPath(); ctx.fillRect(cx - k * .06, cy + k * .1, k * .12, k * .45); }
    else { ctx.disc(cx, cy - k * .25, k * .24); ctx.disc(cx - k * .26, cy + k * .1, k * .24); ctx.disc(cx + k * .26, cy + k * .1, k * .24); ctx.fillRect(cx - k * .06, cy, k * .12, k * .5); } };
  T(RN[r], x + w * .1, y + h * .14, .2 * w / U, r == 9 ? "#000" : "#000", AL_LEFT, 900); ctx.fill(col); T(RN[r], x + w * .1, y + h * .14, .2 * w / U, su == 1 || su == 2 ? "#dc2626" : "#111827", AL_LEFT, 900);
  suit(x + w * .2, y + h * .32, w * .22); suit(x + w / 2, y + h * .6, w * .5);
}
static void drawCasino() {
  scrHead("CASINO", "PLAY WITH YOUR CAREER CASH  |  THIS VISIT: " + std::string(casNet >= 0 ? "+$" : "-$") + fmtN(std::labs(casNet))); cashTag();
  double m = .03 * U, top = safeTop + .12 * U, bot = H - .11 * U;
  { const char *tb[2] = {"BLACKJACK", "SLOTS"}; double tw = .22 * U; for (int i = 0; i < 2; i++) ui("cas:tab:" + istr(i), m + i * (tw + .012 * U), top, tw, .055 * U, tb[i], casTab == i ? "#be123c" : "#334155", true, .022); }
  // the bet chips
  bool busy = (casTab == 0 && BJS.st == 1) || (casTab == 1 && SLS.spin);
  { double cx0 = W - m - 5 * .085 * U; T("BET", cx0 - .02 * U, top + .0275 * U, .017, "#94a3b8", AL_RIGHT, 800);
    for (int i = 0; i < 5; i++) { double cx = cx0 + i * .085 * U + .035 * U, cy = top + .0275 * U, r = .03 * U; bool on = casBet == i, ok = C.money >= CAS_BETS[i];
      static const char *CC[5] = {"#2563eb", "#16a34a", "#111827", "#7c3aed", "#d97706"};
      ctx.fill(on ? hex("#ffd54a") : rgba(255, 255, 255, .15)); ctx.disc(cx, cy, r * 1.15); ctx.fill(ok ? hex(CC[i]) : hex("#475569")); ctx.disc(cx, cy, r); ctx.stroke(rgba(255, 255, 255, .7)); ctx.lineWidth(2); ctx.beginPath(); ctx.arc(cx, cy, r * .72, 0, 7); ctx.strokePath();
      T(CAS_BETS[i] >= 1000 ? "1K" : istr(CAS_BETS[i]), cx, cy, .016, "#fff", AL_CENTER, 900); pushBtn("cas:bet:" + istr(i), cx - r * 1.2, cy - r * 1.2, r * 2.4, r * 2.4, "$" + istr(CAS_BETS[i]));
      if (busy || !ok) btns.back().dis = true; } }
  double fy = top + .08 * U, fh = bot - fy; panel(m, fy, W - 2 * m, fh, .7);
  ctx.fill(rgba(21, 128, 61, .35)); ctx.rr(m + .015 * U, fy + .015 * U, W - 2 * m - .03 * U, fh - .03 * U, .03 * U); ctx.fillPath();   // the felt
  int bet = CAS_BETS[casBet];
  if (casTab == 0) {
    double cw = .1 * U, ch = cw * 1.42, cx0 = W / 2 - .3 * U;
    T("DEALER STANDS ON 17  |  BLACKJACK PAYS 3 TO 2", W / 2, fy + .04 * U, .015, "#bbf7d0", AL_CENTER, 800);
    bool hide = BJS.st == 1;
    T("DEALER" + (BJS.dh.empty() ? std::string() : "  " + (hide ? std::string("?") : istr(bjVal(BJS.dh)))), m + .04 * U, fy + .1 * U, .02, "#fff", AL_LEFT, 900);
    for (size_t i = 0; i < BJS.dh.size(); i++) cardDraw(BJS.dh[i], cx0 + i * cw * .75, fy + .08 * U, cw, ch, hide && i == 1);
    double py = fy + .08 * U + ch + .05 * U;
    T("YOU" + (BJS.ph.empty() ? std::string() : "  " + istr(bjVal(BJS.ph))), m + .04 * U, py + .02 * U, .02, "#fff", AL_LEFT, 900);
    for (size_t i = 0; i < BJS.ph.size(); i++) cardDraw(BJS.ph[i], cx0 + i * cw * .75, py, cw, ch, false);
    if (!BJS.msg.empty()) TB(BJS.msg, W / 2 + .26 * U, fy + fh * .42, .026, BJS.msg.find('+') != std::string::npos ? "#7CFC9A" : BJS.msg.find("PUSH") == 0 ? "#fde68a" : "#fca5a5", AL_CENTER);
    double by = bot - .085 * U, bw = .2 * U, gx = .015 * U, bx = W / 2 - (bw * 3 + gx * 2) / 2;
    if (BJS.st == 1) { ui("cas:hit", bx, by, bw, .06 * U, "HIT", "#16a34a", true, .024); ui("cas:stand", bx + bw + gx, by, bw, .06 * U, "STAND", "#b91c1c", true, .024);
      bool canD = BJS.ph.size() == 2 && C.money >= BJS.bet; ui("cas:dbl", bx + 2 * (bw + gx), by, bw, .06 * U, "DOUBLE", "#7c3aed", canD, .024); if (!canD) btns.back().dis = true; }
    else { bool ok = C.money >= bet; ui("cas:deal", W / 2 - .17 * U, by, .34 * U, .06 * U, "DEAL  ($" + fmtN(bet) + ")", ok ? "#16a34a" : "#475569", ok, .024); if (!ok) btns.back().dis = true; }
  } else {
    double rw = .17 * U, rh = .22 * U, gx = .02 * U, rx0 = W / 2 - (3 * rw + 2 * gx) / 2, ry = fy + .07 * U, t = now();
    ctx.fill("#7f1d1d"); ctx.rr(rx0 - .03 * U, ry - .03 * U, 3 * rw + 2 * gx + .06 * U, rh + .06 * U, .03 * U); ctx.fillPath();
    for (int i = 0; i < 3; i++) { double x = rx0 + i * (rw + gx); ctx.fill("#f8fafc"); ctx.rr(x, ry, rw, rh, .015 * U); ctx.fillPath();
      double stopT = SLS.t0 + 900 + i * 450; bool rolling = SLS.spin && t < stopT;
      if (rolling) { int k = (int)((t - SLS.t0) / 70 + i * 2) % 6; double off = std::fmod((t - SLS.t0) / 70, 1.0) * rh * .5; slSym(k, x + rw / 2, ry + rh / 2 - off + rh * .25, rh * .55); slSym((k + 1) % 6, x + rw / 2, ry - off + rh * .25, rh * .55); }
      else slSym(SLS.r[i], x + rw / 2, ry + rh / 2, rh * .8);
      ctx.fill(rgba(0, 0, 0, .12)); ctx.fillRect(x, ry, rw, rh * .12); ctx.fillRect(x, ry + rh * .88, rw, rh * .12); }
    // land the reels one at a time, then pay
    if (SLS.spin) { for (int i = 0; i < 3; i++) if (t >= SLS.t0 + 900 + i * 450) SLS.r[i] = SLS.fin[i];
      if (t >= SLS.t0 + 900 + 2 * 450) { SLS.spin = false; int k = slPay(SLS.fin), win = k * SLS.bet;
        if (k >= 10) trophyUnlock(TR_HIGH_ROLLER);
        if (win) { casPay(win); SLS.msg = (k >= 10 ? "JACKPOT! +$" : "WIN +$") + fmtN(win - SLS.bet); sfx(k >= 10 ? S_HORN : S_CHEER, .35); } else SLS.msg = "NO LUCK"; } }
    T("3 x 7: 50x   3 BARS: 20x   3 PUCKS: 15x   3 BELLS: 10x   3 CHERRIES: 8x   3 LEMONS: 5x   CHERRY, CHERRY FIRST: 4x   CHERRY FIRST: 2x", W / 2, ry + rh + .05 * U, .0135, "#bbf7d0", AL_CENTER, 800);
    if (!SLS.msg.empty() && !SLS.spin) TB(SLS.msg, W / 2, ry + rh + .1 * U, .028, SLS.msg[0] == 'N' ? "#fca5a5" : "#7CFC9A", AL_CENTER);
    bool ok = !SLS.spin && C.money >= bet; ui("cas:spin", W / 2 - .17 * U, bot - .085 * U, .34 * U, .06 * U, SLS.spin ? "SPINNING..." : "SPIN  ($" + fmtN(bet) + ")", ok ? "#be123c" : "#475569", ok, .024); if (!ok) btns.back().dis = true;
  }
  T("Just for fun - it's only your player's money. Know when to walk away.", W / 2, bot + .03 * U, .0135, "#64748b", AL_CENTER, 700);
  footHints(PADH);
}
bool BJS_active() { return BJS.st == 1; } int slRollT() { return slRoll(); } int slPayT(const int *r) { return slPay(r); }   // (tests)
static bool casTap(const std::string &id) {
  if (!pre(id, "cas:")) return false;
  if (pre(id, "cas:tab:")) { if (!(BJS.st == 1 || SLS.spin)) casTab = atoi(id.c_str() + 8); return true; }
  if (pre(id, "cas:bet:")) { casBet = atoi(id.c_str() + 8); return true; }
  int bet = CAS_BETS[casBet];
  if (id == "cas:deal" && BJS.st != 1 && C.money >= bet) { BJS.ph.clear(); BJS.dh.clear(); BJS.msg.clear(); BJS.dbl = false; BJS.bet = bet; casPay(-bet);
    if (BJS.deck.size() < 52) BJS.deck.clear(); BJS.ph.push_back(bjDraw()); BJS.dh.push_back(bjDraw()); BJS.ph.push_back(bjDraw()); BJS.dh.push_back(bjDraw()); BJS.st = 1; sfx(S_PASS, .3);
    if (bjVal(BJS.ph) == 21 || bjVal(BJS.dh) == 21) bjFinish(); return true; }
  if (BJS.st == 1) {
    if (id == "cas:hit") { BJS.ph.push_back(bjDraw()); sfx(S_PASS, .3); if (bjVal(BJS.ph) >= 21) bjFinish(); return true; }
    if (id == "cas:stand") { bjFinish(); return true; }
    if (id == "cas:dbl" && BJS.ph.size() == 2 && C.money >= BJS.bet) { casPay(-BJS.bet); BJS.bet *= 2; BJS.dbl = true; BJS.ph.push_back(bjDraw()); bjFinish(); return true; } }
  if (id == "cas:spin" && !SLS.spin && C.money >= bet) { casPay(-bet); SLS.bet = bet; for (int i = 0; i < 3; i++) SLS.fin[i] = slRoll(); SLS.t0 = now(); SLS.spin = true; SLS.msg.clear(); sfx(S_PASS, .3); return true; }
  return true;
}
// ---------------------------------------------------------------- Hockeymon: the shop, the packs at your door (and opening them), the collection
static int hmTab = 0, hmPage = 0, hmSel = -1, hmOpenK = -1, hmRev = 0; static std::vector<HmCard> hmOpening; static double hmRevT = 0;
static void hmBack(double x, double y, double w, double h) {   // a card's back
  double r = w * .06; ctx.fill("#1e3a8a"); ctx.rr(x, y, w, h, r); ctx.fillPath(); ctx.fill("#2563eb"); ctx.rr(x + w * .05, y + w * .05, w * .9, h - w * .1, r * .8); ctx.fillPath();
  ctx.fill("#fbbf24"); ctx.disc(x + w / 2, y + h / 2, w * .26); ctx.fill("#1e3a8a"); ctx.disc(x + w / 2, y + h / 2, w * .2); ctx.fill("#fff"); ctx.font(w * .1); ctx.textMid(); ctx.fillText("HOCKEYMON", x + w / 2, y + h * .16); }
static int hmBestV(int id) { for (int v = HM_NV - 1; v >= 0; v--) if (C.hmCnt[id][v]) return v; return -1; }
static void drawHockeymon() {
  scrHead("HOCKEYMON", "CASH $" + fmtN(C.money) + "  |  COLLECTION " + istr(proHmOwned()) + " / " + istr(HM_N) + "  |  WORTH " + hmCash(proHmValue()));
  double m = .03 * U, top = safeTop + .115 * U, bot = H - .085 * U;
  // the tabs
  { int door = 0, way = 0; for (int k = 0; k < HM_NP; k++) { door += C.hmDoor[k]; way += C.hmPend[k]; }
    std::string tl[3] = {"SHOP", door ? "AT YOUR DOOR (" + istr(door) + ")" : std::string("AT YOUR DOOR"), "COLLECTION"}; double tw = (W - 2 * m - .04 * U) / 3, th = .05 * U;
    for (int i = 0; i < 3; i++) { double x = m + i * (tw + .02 * U); bool on = hmTab == i; if (on) { ctx.fill("#fff"); ctx.rr(x, top, tw, th, th / 2); ctx.fillPath(); } else glass(x, top, tw, th, .45);
      T(tl[i], x + tw / 2, top + th / 2, .019, on ? "#0b1220" : "#cbd5e1", AL_CENTER, 800); pushBtn("hm:tab:" + istr(i), x, top, tw, th, tl[i]); }
    (void)way; }
  double y0 = top + .075 * U;
  if (!hmOpening.empty()) {   // opening a pack: the cards face down, X turns the next one; the best is last
    int n = (int)hmOpening.size(); int cols = n > 6 ? 6 : n, rows = (n + cols - 1) / cols; double ch = std::min((bot - y0 - .08 * U) / rows - .015 * U, .36 * U), cw = ch / 1.4, gx = .015 * U;
    double totW = cols * cw + (cols - 1) * gx, x0 = (W - totW) / 2; int tot = 0;
    for (int i = 0; i < n; i++) { double x = x0 + (i % cols) * (cw + gx), y = y0 + (i / cols) * (ch + .015 * U); const HmCard &c = hmOpening[(size_t)i];
      if (i < hmRev) { int val = hmValue(c.id, c.v); tot += val; bool hit = val >= hmPack(hmOpenK).price * 100; double age = (now() - hmRevT) / 1000;
        if (hit || c.v) { double pl = .5 + .5 * std::sin(now() / 200.0); softGlow(x + cw / 2, y + ch / 2, cw * .9, ch * .75, hit ? hex("#fbbf24") : hex("#a78bfa"), (hit ? .45 : .25) * (.7 + .3 * pl)); }
        double pop = i == hmRev - 1 ? clamp(age / .25, 0, 1) : 1, sw = cw * (.4 + .6 * pop); hmDrawCard(x + (cw - sw) / 2, y, sw, ch, c.id, c.v);
        if (hit && pop >= 1) { T(val >= hmPack(hmOpenK).price * 1000 ? "HUGE HIT!" : "HIT!", x + cw / 2, y - .012 * U, .02, "#fde047", AL_CENTER, 900); } }
      else hmBack(x, y, cw, ch); }
    double by = bot - .06 * U;
    if (hmRev < n) { T("CARD " + istr(hmRev + 1) + " OF " + istr(n), W / 2, by - .02 * U, .018, "#94a3b8", AL_CENTER, 800); ui("hm:rev", W / 2 - .15 * U, by, .3 * U, .055 * U, hmRev == n - 1 ? "REVEAL THE LAST CARD" : "NEXT CARD", "#ea580c", true, .022); ui("hm:revall", W / 2 + .17 * U, by, .2 * U, .055 * U, "SHOW ALL", "#475569", true, .02); }
    else { int pr = hmPack(hmOpenK).price * 100; T("THIS PACK: " + hmCash(tot) + "  (PAID " + hmCash(pr) + ")", W / 2, by - .02 * U, .02, tot >= pr ? "#4ade80" : "#cbd5e1", AL_CENTER, 900);
      ui("hm:done", W / 2 - .15 * U, by, .3 * U, .055 * U, "DONE", "#16a34a", true, .024); }
    footHints({{"X", "REVEAL"}, {"O", "BACK"}}); return; }
  if (hmTab == 0) {   // the shop
    double cw = (W - 2 * m - .04 * U) / 3, ph = std::min(bot - y0 - .17 * U, .34 * U), pw = ph * .66;
    for (int k = 0; k < HM_NP; k++) { const HmPack &p = hmPack(k); double x = m + k * (cw + .02 * U); glass(x, y0, cw, bot - y0 - .04 * U, .5);
      hmDrawPack(x + (cw - pw) / 2, y0 + .015 * U, pw, ph, k); double ty = y0 + ph + .04 * U;
      TB(p.n, x + cw / 2, ty, .022, "#fff", AL_CENTER); TF(p.d, x + cw / 2, ty + .03 * U, .0145, cw - .03 * U, "#94a3b8", AL_CENTER);
      bool can = C.money >= p.price; ui("hm:buy:" + istr(k), x + cw * .15, ty + .055 * U, cw * .7, .05 * U, "BUY  $" + istr(p.price), can ? "#16a34a" : "#475569", can, .022);
      if (C.hmPend[k] + C.hmDoor[k]) T(istr(C.hmPend[k]) + " ON THE WAY  |  " + istr(C.hmDoor[k]) + " AT THE DOOR", x + cw / 2, ty + .125 * U, .0135, "#fbbf24", AL_CENTER, 800); }
    T("Packs ship to your door after your next game. Most cards sell for less than the pack - but you never know.", W / 2, bot - .015 * U, .0145, "#94a3b8", AL_CENTER, 700); }
  else if (hmTab == 1) {   // the door
    int any = 0; double x = m; for (int k = 0; k < HM_NP; k++) if (C.hmDoor[k]) any++;
    if (!any) { int way = 0; for (int k = 0; k < HM_NP; k++) way += C.hmPend[k]; double cy = (y0 + bot) / 2;
      TB("Nothing at the door yet.", W / 2, cy - .02 * U, .03, "#fff", AL_CENTER); T(way ? istr(way) + (way == 1 ? " PACK IS" : " PACKS ARE") + " ON THE WAY - THEY ARRIVE AFTER YOUR NEXT GAME." : std::string("ORDER PACKS IN THE SHOP - THEY ARRIVE AFTER YOUR NEXT GAME."), W / 2, cy + .03 * U, .016, "#94a3b8", AL_CENTER, 800); }
    else { double ph = std::min(bot - y0 - .12 * U, .34 * U), pw = ph * .66, gap = .04 * U, totW = any * pw + (any - 1) * gap; x = (W - totW) / 2;
      for (int k = 0; k < HM_NP; k++) if (C.hmDoor[k]) { hmDrawPack(x, y0 + .01 * U, pw, ph, k); if (C.hmDoor[k] > 1) { ctx.fill("#ef4444"); ctx.disc(x + pw - .01 * U, y0 + .02 * U, .022 * U); T("x" + istr(C.hmDoor[k]), x + pw - .01 * U, y0 + .02 * U, .017, "#fff", AL_CENTER, 900); }
        ui("hm:open:" + istr(k), x, y0 + ph + .03 * U, pw, .05 * U, "OPEN", "#ea580c", true, .022); x += pw + gap; } } }
  else {   // the collection
    if (hmSel >= 0) {   // one monster: its card big, what you have of it, sell
      int id = hmSel; const HmMon &mn = hmMon(id); int bv = std::max(0, hmBestV(id)); double ch = bot - y0 - .02 * U, cw = ch / 1.4;
      hmDrawCard(m + .02 * U, y0, cw, ch, id, bv, hmBestV(id) >= 0);
      double rx = m + cw + .06 * U, rw = W - rx - m, yy = y0 + .02 * U; TB(mn.n, rx, yy, .034, "#fff"); yy += .045 * U;
      T(std::string("No. ") + (id < 9 ? "0" : "") + istr(id + 1) + "  |  " + hmTypeName(mn.type) + "  |  " + hmTierName(mn.tier), rx, yy, .017, "#94a3b8", AL_LEFT, 800); yy += .05 * U;
      for (int v = 0; v < HM_NV; v++) { if (v == 2 && mn.tier < 2) continue; int n = C.hmCnt[id][v]; std::string vn = v == 0 ? "REGULAR" : hmVarName(v);
        glass(rx, yy, rw, .06 * U, .5); T(vn, rx + .02 * U, yy + .03 * U, .018, v == 2 ? "#fbbf24" : v == 1 ? "#c4b5fd" : "#e2e8f0", AL_LEFT, 900);
        T("x" + istr(n) + "   " + hmCash(hmValue(id, v)) + " EACH", rx + rw * .3, yy + .03 * U, .017, n ? "#fff" : "#64748b", AL_LEFT, 800);
        ui("hm:sell:" + istr(id) + ":" + istr(v), rx + rw - .2 * U, yy + .007 * U, .19 * U, .046 * U, "SELL ONE", n ? "#16a34a" : "#475569", n > 0, .018); yy += .07 * U; }
      ui("hm:back", rx, bot - .06 * U, .2 * U, .05 * U, "BACK", "#475569", true, .02); }
    else {
      const int cols = 6, rows = 2, per = cols * rows, pages = (HM_N + per - 1) / per; hmPage = std::max(0, std::min(pages - 1, hmPage));
      double gx = .012 * U, cw = std::min((W - 2 * m - (cols - 1) * gx) / cols, ((bot - y0 - .08 * U) / rows - gx) / 1.4), ch = cw * 1.4, gw = cols * cw + (cols - 1) * gx, x0 = (W - gw) / 2;
      for (int i = 0; i < per; i++) { int id = hmPage * per + i; if (id >= HM_N) break; double x = x0 + (i % cols) * (cw + gx), y = y0 + (i / cols) * (ch + gx); int bv = hmBestV(id);
        hmDrawCard(x, y, cw, ch, id, std::max(0, bv), bv >= 0); int n = C.hmCnt[id][0] + C.hmCnt[id][1] + C.hmCnt[id][2];
        if (n > 1) { ctx.fill("#ef4444"); ctx.disc(x + cw - .012 * U, y + .012 * U, .017 * U); T("x" + istr(n), x + cw - .012 * U, y + .012 * U, .013, "#fff", AL_CENTER, 900); }
        if (bv >= 0) pushBtn("hm:mon:" + istr(id), x, y, cw, ch, hmMon(id).n); }
      double by = bot - .055 * U; ui("hm:pg:-1", m, by, .1 * U, .048 * U, "<", "#475569", hmPage > 0, .026); ui("hm:pg:1", m + .11 * U, by, .1 * U, .048 * U, ">", "#475569", hmPage < pages - 1, .026);
      T("PAGE " + istr(hmPage + 1) + " / " + istr(pages), m + .23 * U, by + .024 * U, .016, "#94a3b8", AL_LEFT, 800);
      int dv = proHmDupValue(); ui("hm:dups", W - m - .34 * U, by, .34 * U, .048 * U, dv ? "SELL DUPLICATES  " + hmCash(dv) : std::string("NO DUPLICATES"), dv ? "#16a34a" : "#475569", dv > 0, .018);
      if (C.hmBest >= 0) T("BEST PULL: " + std::string(hmVarName(C.hmBest % 3)) + (C.hmBest % 3 ? " " : "") + hmMon(C.hmBest / 3).n + "  " + hmCash(hmValue(C.hmBest / 3, C.hmBest % 3)), W / 2 + .02 * U, by + .024 * U, .014, "#fbbf24", AL_CENTER, 800); } }
  footHints({{"D-PAD", "MOVE"}, {"X", "SELECT"}, {"O", "BACK"}});
}
static bool hmTap(const std::string &id) {
  if (pre(id, "hm:tab:")) { hmTab = atoi(id.c_str() + 7); hmSel = -1; return true; }
  if (pre(id, "hm:buy:")) { int k = atoi(id.c_str() + 7); if (proHmBuy(k)) toast(std::string(hmPack(k).n) + " ORDERED - AT YOUR DOOR AFTER THE NEXT GAME"); else toast("NOT ENOUGH CASH"); return true; }
  if (pre(id, "hm:open:")) { int k = atoi(id.c_str() + 8); hmOpening = proHmOpen(k); hmOpenK = k; hmRev = 0; hmRevT = now(); mFocus = "hm:rev"; return true; }
  if (id == "hm:rev") { if (hmRev < (int)hmOpening.size()) { hmRev++; hmRevT = now(); const HmCard &c = hmOpening[(size_t)hmRev - 1]; sfx(hmValue(c.id, c.v) >= hmPack(hmOpenK).price * 100 ? S_HORN : S_PASS, .6); }
    if (hmRev >= (int)hmOpening.size()) mFocus = "hm:done"; return true; }
  if (id == "hm:revall") { hmRev = (int)hmOpening.size(); hmRevT = now() - 1000; mFocus = "hm:done"; return true; }
  if (id == "hm:done") { hmOpening.clear(); hmRev = 0; bool more = false; for (int k = 0; k < HM_NP; k++) if (C.hmDoor[k]) more = true; if (!more) hmTab = 2; mFocus = ""; return true; }
  if (pre(id, "hm:mon:")) { hmSel = atoi(id.c_str() + 7); mFocus = ""; return true; }
  if (id == "hm:back") { mFocus = "hm:mon:" + istr(hmSel); hmSel = -1; return true; }
  if (pre(id, "hm:pg:")) { hmPage += atoi(id.c_str() + 6); return true; }
  if (pre(id, "hm:sell:")) { int mid = atoi(id.c_str() + 8); size_t c = id.find(':', 8); int v = c == std::string::npos ? 0 : atoi(id.c_str() + c + 1); int val = hmValue(mid, v);
    auto doIt = [mid, v] { int got = proHmSell(mid, v, 1); if (got) toast("SOLD FOR " + hmCash(got)); };
    if (val >= 2000) askModal("SELL IT?", std::string("Sell your ") + hmVarName(v) + (v ? " " : "") + hmMon(mid).n + " for " + hmCash(val) + "?", doIt); else doIt(); return true; }
  if (id == "hm:dups") { int dv = proHmDupValue(); askModal("SELL DUPLICATES?", "Keep your best copy of each card and sell the rest for " + hmCash(dv) + "?", [] { int got = proHmSellDups(); toast("SOLD FOR " + hmCash(got)); }); return true; }
  return false;
}
// ---------------------------------------------------------------- the CHL Station: Pong on the TV (walk up to the console, X)
static struct PongS { double bx = .5, by = .5, vx = .5, vy = .2, py = .5, cy = .5, wait = 1; int ps = 0, cs = 0; bool over = false; double t0 = 0; } PNG;
static void pongServe(int dir) { PNG.bx = .5; PNG.by = .5; double a = (rnd() - .5) * .9; PNG.vx = .55 * dir * std::cos(a); PNG.vy = .55 * std::sin(a); PNG.wait = .8; }
static void pongStart() { trophyUnlock(TR_PLAYER_ONE); PNG = PongS(); PNG.t0 = now(); pongServe(rnd() < .5 ? 1 : -1); }
static void pongStep(uint32_t press, const Pad &pad, const Touch &touch, double dt) {
  if (press & B_CIRCLE) { aptOv.clear(); return; }
  if (PNG.over) { if (press & B_CROSS) pongStart(); return; }
  const double PH = .2, PW = .02, BS = .022;   // paddle height, paddle width, ball size (court units: 0-1 both ways)
  double in = (pad.btn & B_UP ? -1 : 0) + (pad.btn & B_DOWN ? 1 : 0); double sy = (pad.ly - 128) / 127.0; if (std::fabs(sy) > .2) in = sy;
  PNG.py = clamp(PNG.py + in * 1.4 * dt, PH / 2, 1 - PH / 2);
  for (int i = 0; i < touch.n; i++) if (touch.p[i].x < W * .6) { double cy0 = H * .16, ch = H * .7; PNG.py = clamp((touch.p[i].y - cy0) / ch, PH / 2, 1 - PH / 2); }
  { double tgt = PNG.vx > 0 ? PNG.by + (std::sin(now() / 700.0) * .06) : .5; double d = tgt - PNG.cy, mx = .62 * dt; PNG.cy = clamp(PNG.cy + clamp(d, -mx, mx), PH / 2, 1 - PH / 2); }   // the CPU: quick, not perfect
  if (PNG.wait > 0) { PNG.wait -= dt; return; }
  PNG.bx += PNG.vx * dt; PNG.by += PNG.vy * dt;
  if (PNG.by < BS / 2) { PNG.by = BS / 2; PNG.vy = std::fabs(PNG.vy); sfx(S_POST, .25, 1.6); } if (PNG.by > 1 - BS / 2) { PNG.by = 1 - BS / 2; PNG.vy = -std::fabs(PNG.vy); sfx(S_POST, .25, 1.6); }
  auto hitP = [&](double px, double pyc, int dir) { if (std::fabs(PNG.by - pyc) < PH / 2 + BS / 2) { double off = (PNG.by - pyc) / (PH / 2), sp = std::min(1.6, std::sqrt(PNG.vx * PNG.vx + PNG.vy * PNG.vy) * 1.07);
      double a = off * .9; PNG.vx = dir * sp * std::cos(a); PNG.vy = sp * std::sin(a); PNG.bx = px + dir * (PW / 2 + BS / 2); sfx(S_PASS, .55, 1.3); return true; } return false; };
  if (PNG.vx < 0 && PNG.bx < .04 + PW / 2 + BS / 2 && PNG.bx > .02) hitP(.04, PNG.py, 1);
  if (PNG.vx > 0 && PNG.bx > .96 - PW / 2 - BS / 2 && PNG.bx < .98) hitP(.96, PNG.cy, -1);
  if (PNG.bx < -.03) { PNG.cs++; sfx(S_BOO, .3); if (PNG.cs >= 7) PNG.over = true; else pongServe(1); }
  if (PNG.bx > 1.03) { PNG.ps++; sfx(S_HORN, .35); if (PNG.ps >= 7) PNG.over = true; else pongServe(-1); }
}
static void drawPong() {
  ctx.fill(rgba(0, 0, 0, .85)); ctx.fillRect(0, 0, W, H);
  double cx0 = W * .08, cy0 = H * .16, cw = W * .84, ch = H * .7;   // the court (the TV)
  ctx.fill("#1a1c22"); ctx.rr(cx0 - .025 * U, cy0 - .025 * U, cw + .05 * U, ch + .05 * U, .03 * U); ctx.fillPath();
  ctx.fill("#050807"); ctx.fillRect(cx0, cy0, cw, ch);
  Col fg = hex("#d9fbe6"); ctx.fill(fg);
  for (double y = 0; y < 1; y += .05) ctx.fillRect(cx0 + cw / 2 - 2, cy0 + ch * (y + .012), 4, ch * .026);   // the net
  const double PH = .2, PW = .02, BS = .022;
  ctx.fillRect(cx0 + cw * (.04 - PW / 2), cy0 + ch * (PNG.py - PH / 2), cw * PW, ch * PH); ctx.fillRect(cx0 + cw * (.96 - PW / 2), cy0 + ch * (PNG.cy - PH / 2), cw * PW, ch * PH);
  if (PNG.wait <= 0 || std::fmod(now() / 200.0, 2) < 1) ctx.fillRect(cx0 + cw * PNG.bx - ch * BS / 2, cy0 + ch * (PNG.by - BS / 2), ch * BS, ch * BS);
  ctx.font(.09 * U); ctx.textMid(); ctx.fillText(istr(PNG.ps), cx0 + cw * .38, cy0 + .07 * U); ctx.fillText(istr(PNG.cs), cx0 + cw * .62, cy0 + .07 * U);
  ctx.alpha(.06f); ctx.fill("#000"); for (double y = cy0; y < cy0 + ch; y += 3) ctx.fillRect(cx0, y, cw, 1); ctx.alpha(1);   // scanlines
  TB("CHL STATION", W * .08, H * .08, .03, "#38bdf8"); T("PONG  |  FIRST TO 7", W * .92, H * .08, .018, "#94a3b8", AL_RIGHT, 800);
  if (PNG.over) { ctx.fill(rgba(0, 0, 0, .6)); ctx.fillRect(cx0, cy0, cw, ch); TB(PNG.ps > PNG.cs ? "YOU WIN!" : "THE CPU WINS", W / 2, cy0 + ch * .42, .06, PNG.ps > PNG.cs ? "#4ade80" : "#f87171", AL_CENTER);
    T("X  PLAY AGAIN     O  PUT THE CONTROLLER DOWN", W / 2, cy0 + ch * .58, .02, "#e2e8f0", AL_CENTER, 800); }
  footHints({{"D-PAD", "UP / DOWN"}, {"TOUCH", "DRAG YOUR PADDLE"}, {"O", "QUIT"}});
}
// My Team: the coach (what he thinks, your line and the way up) and your chemistry with every teammate
static void drawMyTeam() {
  PTeam &L = C.L[C.me]; double tc = proTeamChem();
  scrHead("MY TEAM", upper(teamFull(C.me)) + "  |  " + istr(L.w) + "-" + istr(L.l) + "  |  TEAM CHEMISTRY " + istr((int)jround(tc)));
  double m = .03 * U, top = safeTop + .12 * U, bot = H - .085 * U, lw = W * .38;
  // the coach
  panel(m, top, lw, bot - top); accentBar(m, top, bot - top, hex("#60a5fa"));
  double x = m + .03 * U, w = lw - .055 * U, y = top + .035 * U; TB("THE COACH", x, y, .022, "#60a5fa"); y += .05 * U;
  const char *cc = C.coach >= 70 ? "#4ade80" : C.coach >= 50 ? "#a3e635" : C.coach >= 35 ? "#fbbf24" : "#f87171";
  const char *word = C.coach >= 80 ? "LOVES YOUR GAME" : C.coach >= 65 ? "TRUSTS YOU" : C.coach >= 50 ? "LIKES WHAT HE SEES" : C.coach >= 35 ? "WANTS MORE" : "ON THIN ICE";
  meter(x, y, w, clamp(C.coach / 100, 0, 1), cc, "COACH'S APPRECIATION"); y += .045 * U;
  { std::string dl = std::fabs(C.coachD) >= .05 ? std::string("  (") + (C.coachD > 0 ? "+" : "") + fmt("%.1f", C.coachD) + " LAST GAME)" : ""; TF(std::string(word) + dl, x, y, .016, w, cc); } y += .045 * U;
  static const char *LNS[3] = {"1ST LINE", "2ND LINE", "3RD LINE"}; int ln; double v, need, prog, cn; proLineProgress(ln, v, need, prog, cn);
  T("YOUR LINE", x, y, .015, "#94a3b8", AL_LEFT, 800); TB(std::string(LNS[ln]) + (C.cen ? "  |  CENTER" : "  |  WING"), x + w, y, .02, "#fff", AL_RIGHT); y += .04 * U;
  if (ln == 0) { meter(x, y, w, 1, "#ffd54a", "TOP LINE - KEEP IT"); y += .045 * U; T("You're on the first line. Keep him happy to stay there.", x, y, .0145, "#94a3b8", AL_LEFT, 700); }
  else { meter(x, y, w, prog, "#38bdf8", std::string("PROGRESS TO THE ") + LNS[ln - 1]); y += .045 * U;
    ctx.font(fsz(.0145) * U); for (auto &l : wrapText(cn >= 99.5 ? "Raise your overall - at OVR " + istr(proOvr()) + " even his full trust isn't enough yet." : "Coach appreciation of about " + istr((int)std::ceil(cn)) + " moves you up at OVR " + istr(proOvr()) + ". A higher overall lowers the bar.", w)) { T(l, x, y, .0145, "#94a3b8", AL_LEFT, 700); y += .024 * U; } }
  if (!C.coachMsg.empty()) { y += .02 * U; ctx.font(fsz(.016) * U); for (auto &l : wrapText("\"" + C.coachMsg + "\"", w)) { if (y > bot - .02 * U) break; T(l, x, y, .016, "#fde68a", AL_LEFT, 800); y += .026 * U; } }
  // chemistry
  double rx = m + lw + .02 * U, rw = W - rx - m; panel(rx, top, rw, bot - top);
  double ry = top + .035 * U; TB("TEAM CHEMISTRY", rx + .025 * U, ry, .022, "#4ade80"); TB(istr((int)jround(tc)), rx + rw - .025 * U, ry, .03, tc >= 60 ? "#4ade80" : tc >= 45 ? "#fff" : "#f87171", AL_RIGHT);
  ry += .03 * U; T("How you get on with each teammate. Answer their texts well and it grows.", rx + .025 * U, ry, .0135, "#94a3b8", AL_LEFT, 700); ry += .03 * U;
  std::vector<std::pair<double, PP *>> T2; for (PP *q : teamS(C.me, false, false)) if (!q->me) T2.push_back({proChem(q->nm()), q}); for (PP *q : teamG(C.me)) T2.push_back({proChem(q->nm()), q});
  std::stable_sort(T2.begin(), T2.end(), [](const std::pair<double, PP *> &a, const std::pair<double, PP *> &b) { return a.first > b.first; });
  int cols = 2; double cw = (rw - .05 * U - .02 * U) / cols, rh2 = .036 * U; int rows = std::max(1, (int)((bot - ry - .01 * U) / rh2));
  for (int i = 0; i < (int)T2.size() && i < rows * cols; i++) { double cx = rx + .025 * U + (i / rows) * (cw + .02 * U), cy = ry + (i % rows) * rh2; PP *q = T2[(size_t)i].second; double ch = T2[(size_t)i].first;
    const char *c2 = ch >= 70 ? "#4ade80" : ch >= 45 ? "#cbd5e1" : "#f87171";
    TF(q->nm() + (q->g ? "  (G)" : ""), cx, cy + rh2 * .35, .0145, cw * .55, "#e2e8f0"); double bx = cx + cw * .58, bw = cw * .3;
    ctx.fill(rgba(148, 163, 184, .22)); ctx.rr(bx, cy + rh2 * .3, bw, 5, 2.5); ctx.fillPath(); ctx.fill(c2); ctx.rr(bx, cy + rh2 * .3, std::max(5.0, bw * ch / 100), 5, 2.5); ctx.fillPath();
    T(istr((int)jround(ch)), cx + cw, cy + rh2 * .35, .0145, c2, AL_RIGHT, 800); }
  footHints(PADH);
}
// Performance: your season so far
static void drawPerf() {
  const PSeason &S = C.st; scrHead("PERFORMANCE", "SEASON " + istr(C.season) + "  |  " + upper(C.L[C.me].n) + "  |  " + istr(S.gp) + (S.gp == 1 ? " GAME" : " GAMES") + " PLAYED");
  double m = .03 * U, top = safeTop + .13 * U, gap = .015 * U, cw = (W - 2 * m - 4 * gap) / 5, ch = (H - top - .14 * U - gap) / 2;
  auto mmss = [](double mins) { int s = (int)jround(mins * 60); char b[16]; snprintf(b, sizeof b, "%d:%02d", s / 60, s % 60); return std::string(b); };
  double gp = std::max(1, S.gp);
  std::string pmS = (S.pm > 0 ? "+" : "") + istr(S.pm);
  struct Tl { const char *k; std::string v, sub; const char *c; } t[10] = {
    {"GOALS", istr(S.g), fixed(S.g / gp, 2) + " A GAME", "#ffd54a"}, {"ASSISTS", istr(S.a), istr(S.g + S.a) + (S.g + S.a == 1 ? " POINT" : " POINTS"), "#7CFC9A"},
    {"PLUS / MINUS", pmS, "EVEN STRENGTH", S.pm > 0 ? "#4ade80" : S.pm < 0 ? "#f87171" : "#e2e8f0"}, {"SHOTS TAKEN", istr(S.sh), fixed(S.sh / gp, 1) + " A GAME", "#e2e8f0"},
    {"COMPLETED PASSES", istr(S.pass), fixed(S.pass / gp, 1) + " A GAME", "#93c5fd"}, {"CHECKS", istr(S.hits), fixed(S.hits / gp, 1) + " A GAME", "#fca5a5"}, {"PENALTY MINUTES", istr(S.pim), istr(S.pim / 2) + (S.pim / 2 == 1 ? " MINOR" : " MINORS"), "#fdba74"},
    {"AVG TIME ON ICE", S.gp ? mmss(S.toi / gp) : std::string("0:00"), "PER GAME", "#c4b5fd"}, {"SHOTS BLOCKED", istr(S.blk), fixed(S.blk / gp, 1) + " A GAME", "#5eead4"},
    {"SHOT ACCURACY", S.sh ? istr((int)jround(100.0 * S.sog / S.sh)) + "%" : std::string("-"), istr(S.sog) + " ON NET", "#f9a8d4"}};
  int rk[10], rn = 0; proLeagueRanks(rk, rn); const char *lgN = proLg() ? "AHL" : "NHL";
  auto ord = [](int k) { int t = k % 100; const char *sf = (t >= 11 && t <= 13) ? "TH" : k % 10 == 1 ? "ST" : k % 10 == 2 ? "ND" : k % 10 == 3 ? "RD" : "TH"; return istr(k) + sf; };
  for (int i = 0; i < 10; i++) { double x = m + (i % 5) * (cw + gap), y = top + (i / 5) * (ch + gap); panel(x, y, cw, ch, .78); accentBar(x, y, ch, hex(t[i].c));
    TF(t[i].k, x + .028 * U, y + ch * .16, .016, cw - .04 * U, "#94a3b8"); TB(t[i].v, x + .028 * U, y + ch * .44, .058, t[i].c); TF(t[i].sub, x + .028 * U, y + ch * .68, .0145, cw - .04 * U, "#94a3b8");
    // where it ranks in the league: a chip along the bottom
    if (S.gp > 0) { int r = rk[i]; const char *cc = r <= 10 ? "#ffd54a" : r <= 50 ? "#7CFC9A" : "#cbd5e1"; std::string lb = ord(r) + " IN " + lgN;
      double chh = .034 * U, cy = y + ch - chh - .014 * U, cxx = x + .02 * U, cww = cw - .034 * U; Col c = hex(cc);
      ctx.fill(rgba((int)c.r, (int)c.g, (int)c.b, r <= 10 ? .2f : .1f)); ctx.rr(cxx, cy, cww, chh, chh / 2); ctx.fillPath();
      TF((r == 1 ? std::string("LEADS THE ") + lgN : lb), cxx + cww / 2, cy + chh / 2, .0155, cww - .02 * U, cc, AL_CENTER); } }
  if (S.gp > 0) T("RANKED AGAINST " + istr(rn) + " " + lgN + " SKATERS", W - m, top - .022 * U, .0145, "#94a3b8", AL_RIGHT, 700);
  back("nav:main", H - .1 * U);
}
// News: the league's wire (new stories since you last looked are marked)
static void drawNews() {
  scrHead("NEWS", "AROUND THE LEAGUE  |  SEASON " + istr(C.season)); double m = .03 * U, y0 = safeTop + .12 * U, w = W - 2 * m, rh = std::min(.045 * U, (H - y0 - .13 * U) / 12 - .005 * U);
  if (C.log.empty()) TB("No league news yet", W / 2, y0 + .12 * U, .03, "#94a3b8", AL_CENTER);
  for (size_t k = 0; k < C.log.size() && k < 12; k++) { double ry = y0 + k * (rh + .005 * U); bool nw = (int)k < newsMark; panel(m, ry, w, rh, nw ? .9 : .62);
    if (nw) { accentBar(m, ry, rh, hex("#f87171")); T("NEW", m + .02 * U, ry + rh / 2, .0135, "#f87171"); } else T("Y" + istr(C.log[k].y), m + .02 * U, ry + rh / 2, .015, "#64748b");
    TF(C.log[k].s, m + .075 * U, ry + rh / 2, .0175, w - .095 * U, nw ? "#fff" : "#cbd5e1"); }
  back("nav:main", H - .1 * U);
}
// Goals: this week's (XP and a little cash) and the season's (a contract-style bonus)
static void drawGoals() {
  ensureYear(); scrHead("GOALS", std::string("WEEKLY GOALS PAY XP AND CASH  |  SEASON GOALS PAY A BONUS  |  TEAM GOALS BUILD CHEMISTRY") + (C.perfB ? "  |  BONUSES +50%" : ""));
  double m = .03 * U, top = safeTop + .12 * U, gap = .018 * U, cw = (W - 2 * m - 2 * gap) / 3, bot = H - .12 * U, rh = .1 * U;
  auto head = [&](double x, const char *title, const std::string &sub, Col c) {
    panel(x, top, cw, bot - top, .78); topLine(x, top, cw, c);
    TB(title, x + .022 * U, top + .04 * U, .025, "#fff"); TF(sub, x + .022 * U, top + .072 * U, .0135, cw - .044 * U, "#94a3b8"); };
  auto row = [&](double x, double y, const std::string &txt, const std::string &pay, const std::string &cnt, double fr, int st, Col c) {   // st: 0 on, 1 done, 2 failed
    ctx.fill(st == 1 ? rgba(34, 197, 94, .16) : st == 2 ? rgba(239, 68, 68, .14) : rgba(255, 255, 255, .05)); ctx.rr(x + .012 * U, y, cw - .024 * U, rh, .012 * U); ctx.fillPath();
    TF(upper(txt), x + .025 * U, y + rh * .24, .0165, cw - .05 * U, st == 1 ? "#7CFC9A" : st == 2 ? "#fca5a5" : "#fff");
    TF(pay, x + .025 * U, y + rh * .5, .0135, cw * .62, "#ffd54a"); T(cnt, x + cw - .025 * U, y + rh * .5, .0135, st == 1 ? "#7CFC9A" : st == 2 ? "#fca5a5" : "#cbd5e1", AL_RIGHT, 800);
    double bw = cw - .05 * U; ctx.fill(rgba(148, 163, 184, .25)); ctx.fillRect(x + .025 * U, y + rh * .76, bw, 4); ctx.fill(st == 1 ? hex("#22c55e") : st == 2 ? hex("#ef4444") : c); ctx.fillRect(x + .025 * U, y + rh * .76, bw * clamp(fr, 0, 1), 4); };
  auto col = [&](double x, const char *title, const std::string &sub, const std::vector<PGoal> &G, bool year) {
    Col c = hex(year ? "#a3e635" : "#38bdf8"); head(x, title, sub, c);
    double y = top + .1 * U; if (G.empty()) TF(year ? "Set when the season starts." : "No games this week.", x + .025 * U, y + .02 * U, .016, cw - .05 * U, "#94a3b8");
    for (auto &g : G) { if (y + rh > bot - .01 * U) break;
      std::string pay = year ? "+$" + fmtN(yearBonusCash(g)) + "  +" + istr(g.xp) + " XP" : "+" + istr(g.xp) + " XP  +$" + istr(g.cash);
      row(x, y, g.txt, pay, g.done ? "DONE" : istr(std::min(g.pr, g.tg)) + " / " + istr(g.tg), (double)g.pr / std::max(1, g.tg), g.done ? 1 : 0, c); y += rh + .008 * U; } };
  int left = 7 - (C.ci % 7);
  col(m, "THIS WEEK", C.phase == "reg" && C.wk.w >= 0 ? "WEEK " + istr(C.wk.w + 1) + "  |  " + istr(left) + (left == 1 ? " DAY LEFT" : " DAYS LEFT") : std::string("OFF-SEASON"), C.phase == "reg" ? C.wk.goals : std::vector<PGoal>(), false);
  col(m + cw + gap, "THIS SEASON", "PAID WHEN YOU HIT THEM", C.yr.goals, true);
  { double x = m + 2 * (cw + gap); Col c = hex("#a78bfa"); int on = proTeamGoalsOn();
    head(x, "TEAM GOALS", on ? istr(on) + " ON  |  FROM YOUR TEAMMATES' TEXTS" : std::string("TEAMMATES TEXT YOU CHALLENGES"), c);
    double y = top + .1 * U; std::vector<const TGoal *> L; for (int i = (int)C.tgoals.size() - 1; i >= 0; i--) if (!C.tgoals[(size_t)i].st) L.push_back(&C.tgoals[(size_t)i]);
    for (int i = (int)C.tgoals.size() - 1; i >= 0; i--) if (C.tgoals[(size_t)i].st) L.push_back(&C.tgoals[(size_t)i]);
    if (L.empty()) TF("None yet. After a game a teammate may text you a challenge - take it on in Messages.", x + .025 * U, y + .02 * U, .016, cw - .05 * U, "#94a3b8");
    for (const TGoal *g : L) { if (y + rh + .03 * U > bot - .01 * U) break;
      std::string who = g->from; size_t sp = who.find(' '); if (sp != std::string::npos && sp > 0) who = who.substr(0, 1) + ". " + who.substr(sp + 1);
      T("WITH " + upper(who), x + .025 * U, y + .012 * U, .0125, "#c4b5fd", AL_LEFT, 800);
      if (!g->st) T(istr(g->left) + (g->left == 1 ? " GAME LEFT" : " GAMES LEFT"), x + cw - .025 * U, y + .012 * U, .0125, "#cbd5e1", AL_RIGHT, 800);
      y += .024 * U;
      std::string cnt = g->st == 1 ? "DONE" : g->st == 2 ? "MISSED" : g->k == 6 ? istr(g->pr) + " / " + istr(g->tg) + " CLEAN" : (g->k == 5 ? (g->pr >= 0 ? "+" : "") + istr(g->pr) : istr(std::max(0, std::min(g->pr, g->tg)))) + " / " + (g->k == 5 ? "+" : "") + istr(g->tg);
      row(x, y, tgoalText(*g), "+" + istr(g->xp) + " XP  +$" + istr(g->cash) + "  +CHEM", cnt, (double)std::max(0, g->pr) / std::max(1, g->tg), g->st, c); y += rh + .01 * U; } }
  back("nav:main", H - .1 * U);
}
static void drawAptView(bool dim);
static void drawInPhone(void (*fn)()) {
  drawAptView(true);
  double b = .012 * U, sx = W * .03 + b, sy = H * .035 + b, sw = W * .94 - 2 * b, sh = H * .93 - 2 * b;
  ctx.fill(rgba(0, 0, 0, .4)); ctx.rr(sx - b + 8, sy - b + 10, sw + 2 * b, sh + 2 * b, .05 * U); ctx.fillPath();
  ctx.fill("#0a0a0c"); ctx.rr(sx - b, sy - b, sw + 2 * b, sh + 2 * b, .05 * U); ctx.fillPath();
  ctx.fill(vgrad(sy, sy + sh, hex("#111a33"), hex("#070b16"))); ctx.rr(sx, sy, sw, sh, .04 * U); ctx.fillPath();
  float oW = W, oH = H, oU = U, oT = safeTop; size_t n0 = btns.size();
  W = (float)sw; H = (float)sh; U = std::min(W, H); safeTop = .03f * U;
  ctx.save(); ctx.translate(sx, sy); statusBar(0, 0, W, safeTop, false); g_txK = 1.1; fn(); g_txK = 1; ctx.restore();
  W = oW; H = oH; U = oU; safeTop = oT;
  for (size_t i = n0; i < btns.size(); i++) { btns[i].x += sx; btns[i].y += sy; }
  pushBtn("ph:close", 0, 0, 0, 0, "", true);
}
// the world, and what's drawn over it
static void drawAptView(bool dim) {
  if (!aptReady()) { ctx.fill("#05070d"); ctx.fillRect(0, 0, W, H); return; }
  aptDraw();
  if (dim) { ctx.fill(rgba(2, 6, 23, .45)); ctx.fillRect(0, 0, W, H); }
}
static void drawDoor() {
  ctx.fill(rgba(2, 6, 23, .5)); ctx.fillRect(0, 0, W, H); pushBtn("ad:close", 0, 0, 0, 0, "BACK", true);
  double w = std::min(W * .5, .9 * U), x = (W - w) / 2, y = safeTop + .08 * U, h = H - y - .08 * U; panel(x, y, w, h, .92); topLine(x, y, w, hex("#f26b5b"));
  std::string ph = C.phase; bool off = offDay(), hurt = ph != "over" && userHurt(), need = C.need; PTeam &r = C.L[C.me];
  TB("FRONT DOOR", x + .03 * U, y + .05 * U, .04, "#fff");
  std::string sub = ph == "over" ? "THE SEASON IS OVER" : need ? "YOUR CONTRACT HAS EXPIRED" : off ? "OFF DAY  |  " + calDate(C.ci) : hurt ? "INJURED  |  OUT " + istr(youMe()->inj) + " MORE" : (ph == "po" ? "PLAYOFFS  |  SERIES " + istr(C.sw) + "-" + istr(C.sl) : "GAME " + istr(C.day + 1) + " OF " + istr(PRO_GAMES));
  T(sub, x + .03 * U, y + .095 * U, .018, off || need || hurt ? "#f26b5b" : "#94a3b8", AL_LEFT, 800);
  double ly = y + .13 * U;
  if (ph != "over") { badge(x + .06 * U, ly + .035 * U, .03 * U, C.me); TB(proAway() ? "AT" : "VS", x + w / 2, ly + .035 * U, .022, "#f26b5b", AL_CENTER); badge(x + w - .06 * U, ly + .035 * U, .03 * U, C.opp);
    TF(upper(r.n), x + .1 * U, ly + .035 * U, .02, w / 2 - .14 * U, "#fff"); TF(upper(C.L[C.opp].n), x + w - .1 * U, ly + .035 * U, .02, w / 2 - .14 * U, "#fff", AL_RIGHT); ly += .09 * U; }
  double ih = .062 * U, iw = w - .06 * U, ix = x + .03 * U;
  auto it = [&](const std::string &id, const std::string &lb, bool big) { menuItem(id, lb, ix, ly, iw, big ? ih * 1.15 : ih, big, true); ly += (big ? ih * 1.15 : ih) + .008 * U; };
  if (need) it("off:neg", "SIGN YOUR CONTRACT", true);
  else if (off) { it("skipday", "REST (SKIP DAY)", true); it("nav:train", "TRAIN  ($" + istr(trainCost()) + ")", false); it("sim1", "SIM TO NEXT GAME", false); }
  else if (ph == "over") it("next", "NEXT SEASON", true);
  else if (hurt) { it("simheal", "SIM UNTIL HEALTHY", true); it("sim1", "SIM ONE GAME", false); }
  else { it("play", "PLAY NEXT GAME", true); it("sim1", "SIM GAME", false); it("simN", ph == "po" ? "SIM SERIES" : "SIM 10 GAMES", false); }
  ui("ad:close", x + w / 2 - .15 * U, y + h - .08 * U, .3 * U, .06 * U, "BACK", "#475569", true, .026);
}
// the office computer: the apartment finder
static void drawPC() {
  ctx.fill(rgba(2, 6, 23, .55)); ctx.fillRect(0, 0, W, H); pushBtn("pc:close", 0, 0, 0, 0, "BACK", true);
  double w = std::min(W * .86, 1.55 * U), h = H * .82, x = (W - w) / 2, y = (H - h) / 2 - .01 * U;
  ctx.fill("#1f2328"); ctx.rr(x - .015 * U, y - .015 * U, w + .03 * U, h + .03 * U, .02 * U); ctx.fillPath();
  ctx.fill(vgrad(y, y + h, hex("#0e2a47"), hex("#071526"))); ctx.fillRect(x, y, w, h);
  ctx.fill(rgba(255, 255, 255, .08)); ctx.fillRect(x, y, w, .055 * U); TB("APARTMENT FINDER", x + .025 * U, y + .028 * U, .024, "#fff"); TB("$" + fmtN(C.money), x + w - .025 * U, y + .028 * U, .024, "#ffd54a", AL_RIGHT);
  int n = (int)APTS.size(); double gap = .02 * U, cw = (w - .05 * U - gap * (n - 1)) / n, ch = h - .17 * U, cy = y + .075 * U;
  for (int i = 0; i < n; i++) { const HomeOpt &a = APTS[(size_t)i]; double cx = x + .025 * U + i * (cw + gap); bool own = HOME.lvlOwn >> i & 1, here = HOME.lvl == i, ok = own || C.money >= a.c;
    panel(cx, cy, cw, ch, .85); topLine(cx, cy, cw, hex(here ? "#38bdf8" : own ? "#22c55e" : "#64748b"));
    // a little floor plan: bigger for the bigger place
    static const double PX[3] = {34, 40, 58}, PY[3] = {26, 30, 32}, PL[3] = {14, 18, 20}, PK[3] = {12, 14, 16}, PKX[3] = {34, 40, 44}; int q = std::min(i, 2);
    double pw = cw * (.5 + .12 * q), phh = pw * PY[q] / PX[q], px = cx + (cw - pw) / 2, py = cy + .03 * U; ctx.fill(rgba(255, 255, 255, .08)); ctx.fillRect(px, py, pw, phh);
    ctx.fill(rgba(255, 255, 255, .5)); double sx = pw / PX[q], sy = phh / PY[q];
    ctx.fillRect(px, py + phh - PL[q] * sy, 14 * sx, 2); ctx.fillRect(px + 20 * sx, py, 2, phh - PK[q] * sy); ctx.fillRect(px + 14 * sx, py + 7 * sy, 6 * sx, 2);   // bedroom, office, bathroom walls (north is up)
    if (q == 2) { ctx.fill(rgba(255, 213, 74, .6)); ctx.fillRect(px + PKX[q] * sx, py, 2, phh); }   // the man cave
    double ty = py + phh + .045 * U; TF(a.n, cx + .025 * U, ty, .028, cw - .05 * U, "#fff"); ty += .035 * U;
    txWrap(a.d, cx + .025 * U, ty + .022 * U, .016, cw - .05 * U, hex("#cbd5e1"), AL_LEFT, 700, 3); ty += .085 * U;
    std::string fx = homeFxTxt(a.fx); if (!fx.empty()) TF("LIVING HERE: " + fx, cx + .025 * U, ty, .015, cw - .05 * U, "#7CFC9A");
    std::string lb = here ? "YOU LIVE HERE" : own ? "MOVE BACK IN" : "BUY  $" + fmtN(a.c); ui("pc:" + istr(i), cx + .025 * U, cy + ch - .08 * U, cw - .05 * U, .06 * U, lb, here ? "#334155" : own ? "#16a34a" : "#2563eb", !here && ok, .024);
    if (here || !ok) btns.back().dis = true; }
  T("Moving keeps everything you own. Some furniture only fits the bigger place.", x + w / 2, y + h - .045 * U, .015, "#94a3b8", AL_CENTER, 700);
  ui("pc:close", x + w / 2 - .12 * U, y + h - .03 * U, .24 * U, .045 * U, "LOG OFF", "#475569", true, .02);
}
// an incoming call: the GM or your agent (trades, call-ups, contract talks, offers)
struct CallInfo { int key = 0; std::string who, why, scr; };
static CallInfo callNow() {
  CallInfo c; if (!CR || C.phase == "retired") return c;
  auto h = [](const std::string &s) { int v = 7; for (char ch : s) v = v * 31 + (unsigned char)ch; return v ? v : 1; };
  if (C.showTrade && C.hasTrade) { c.who = "GM  |  " + upper(C.L[orgOf(C.trade.to)].n); c.why = C.trade.title.empty() ? "We need to talk about your future." : C.trade.title; c.scr = "trade"; c.key = h("t" + C.trade.title + C.trade.why + istr(C.ci)); return c; }
  if (C.need) { c.who = "YOUR AGENT"; c.why = "Your contract is up. Let's get you signed."; c.scr = "neg"; c.key = h("n" + istr(C.season) + istr(C.me)); return c; }
  if (!C.offers.empty()) { c.who = "YOUR AGENT"; c.why = istr(C.offers.size()) + (C.offers.size() > 1 ? " teams are asking about you." : " team is asking about you."); c.scr = "toff"; c.key = h("o" + istr(C.offers.size()) + istr(C.offers[0].t) + istr(C.offers[0].exp)); return c; }
  return c;
}
static void drawCall() {
  CallInfo c = callNow(); PhR r = phoneRect(); phoneBody(r); double t = now();
  ctx.fill(vgrad(r.sy, r.sy + r.sh, hex("#14532d"), hex("#052e16"))); ctx.rr(r.sx, r.sy, r.sw, r.sh, r.w * .11); ctx.fillPath();
  double cx = r.sx + r.sw / 2, cy = r.sy + r.sh * .3;
  for (int k = 0; k < 3; k++) { double ph = std::fmod(t / 1000 + k * .33, 1.0); ctx.alpha((float)(.5 * (1 - ph))); ctx.fill("#4ade80"); ctx.disc(cx, cy, r.sw * (.14 + ph * .2)); } ctx.alpha(1);
  ctx.fill("#e2e8f0"); ctx.disc(cx, cy, r.sw * .14); ctx.fill("#14532d"); ctx.disc(cx, cy - r.sw * .03, r.sw * .05); ctx.fillRect(cx - r.sw * .07, cy + r.sw * .03, r.sw * .14, r.sw * .06);
  T("INCOMING CALL", cx, r.sy + r.sh * .08, .014, "#86efac", AL_CENTER, 800);
  TF(c.who, cx - r.sw * .42, r.sy + r.sh * .5, .02, r.sw * .84, "#fff"); txWrap(c.why, cx - r.sw * .42, r.sy + r.sh * .56, .0155, r.sw * .84, hex("#d1fae5"), AL_LEFT, 700, 3);
  double by = r.sy + r.sh * .78, br = r.sw * .12;
  ctx.fill("#ef4444"); ctx.disc(cx - r.sw * .24, by, br); ctx.fill("#22c55e"); ctx.disc(cx + r.sw * .24, by, br * (1 + .06 * std::sin(t / 120)));
  T("DECLINE (O)", cx - r.sw * .24, by + br + r.sh * .03, .0115, "#fecaca", AL_CENTER, 800); T("ANSWER (X)", cx + r.sw * .24, by + br + r.sh * .03, .0115, "#bbf7d0", AL_CENTER, 800);
  pushBtn("call:no", cx - r.sw * .24 - br, by - br, br * 2, br * 2, "BACK", false); pushBtn("call:yes", cx + r.sw * .24 - br, by - br, br * 2, br * 2, "ANSWER");
}
// after a game: the final, period by period, then your skills filling up; then you're home on the couch
static void presDone() { presPg = 0; aptOv.clear(); phOn = false; phApp = -1; state = ST_MENU; screen = "main"; aptSit(); }
static void drawPResult() {
  aptOv.clear(); double m = .03 * U, t = (now() - presT0) / 1000; if (presT0 <= 0) { presT0 = now(); t = 0; }
  bool won = rs.hs > rs.as;
  if (presPg == 0) {
    scrHead(won ? "WIN" : "LOSS", "FINAL" + std::string(rs.np > 3 ? (rs.so ? " / SO" : " / OT") : "") + (rs.note.empty() ? "" : "  |  " + rs.note));
    double top = safeTop + .13 * U, w = W - 2 * m; panel(m, top, w, .16 * U, .85); accentBar(m, top, .16 * U, hex(won ? "#22c55e" : "#ef4444"));
    badge(m + .08 * U, top + .08 * U, .05 * U, C.me); badge(m + w - .08 * U, top + .08 * U, .05 * U, C.opp);
    TF(upper(rs.hn), m + .15 * U, top + .06 * U, .028, w * .3, "#fff"); TF(upper(rs.an), m + w - .15 * U, top + .06 * U, .028, w * .3, "#fff", AL_RIGHT);
    TB(istr(rs.hs) + "  -  " + istr(rs.as), W / 2, top + .08 * U, .07, "#fff", AL_CENTER);
    T("SHOTS " + istr(rs.hsh) + " - " + istr(rs.ash), W / 2, top + .135 * U, .016, "#94a3b8", AL_CENTER, 800);
    // by period
    double ty = top + .19 * U, tw = w * .55, cw = tw / 7, rh = .042 * U; panel(m, ty, tw, rh * 5.4, .78); int np = std::max(3, std::min(4, rs.np));
    const char *PH[5] = {"1ST", "2ND", "3RD", "OT", "T"};
    T("GOALS", m + .02 * U, ty + rh * .6, .014, "#94a3b8", AL_LEFT, 800); T("SHOTS", m + .02 * U, ty + rh * 3.4, .014, "#94a3b8", AL_LEFT, 800);
    for (int k = 0; k < 5; k++) { if (k == 3 && np < 4) continue; double x = m + cw * (2.2 + k); T(PH[k], x, ty + rh * .6, .014, "#64748b", AL_CENTER, 800); }
    for (int tm = 0; tm < 2; tm++) for (int sec = 0; sec < 2; sec++) { double ry = ty + rh * (1.5 + tm + sec * 2.8 - (sec ? .4 : 0)); const char *ab = C.L[tm ? C.opp : C.me].ab.c_str();
      T(ab, m + .02 * U + cw * .9, ry, .016, tm ? "#fca5a5" : "#93c5fd", AL_CENTER, 800); int tot = 0;
      for (int k = 0; k < 4; k++) { if (k == 3 && np < 4) continue; int v = sec ? rs.ps[tm][k] : rs.pg[tm][k]; tot += v; T(istr(v), m + cw * (2.2 + k), ry, .018, "#fff", AL_CENTER, 800); }
      TB(istr(sec ? (tm ? rs.ash : rs.hsh) : (tm ? rs.as : rs.hs)), m + cw * 6.2, ry, .02, "#ffd54a", AL_CENTER); (void)tot; }
    // your line
    double lx = m + tw + .02 * U, lw = w - tw - .02 * U; panel(lx, ty, lw, rh * 5.4, .78); TB("YOUR GAME", lx + .02 * U, ty + .03 * U, .02, "#f26b5b");
    const MeStats &f = rs.f; int toi = (int)jround(f.toi / SK_PER * 20 * 60);
    std::pair<std::string, std::string> L[8] = {{"G", istr(f.g)}, {"A", istr(f.a)}, {"SOG", istr(f.sog)}, {"SHOTS", istr(f.shots)}, {"PASSES", istr(f.pass)}, {"HITS", istr(f.hits)}, {"PIM", istr(f.pim)}, {"TOI", istr(toi / 60) + ":" + (toi % 60 < 10 ? "0" : "") + istr(toi % 60)}};
    for (int i = 0; i < 8; i++) { double x = lx + .02 * U + (i % 4) * (lw - .04 * U) / 4, y = ty + .075 * U + (i / 4) * .075 * U; T(L[i].first, x, y, .013, "#94a3b8", AL_LEFT, 800); TB(L[i].second, x, y + .03 * U, .03, "#fff"); }
    T("+" + fmtN(rs.xp) + " XP   +$" + fmtN(rs.cash), lx + lw - .02 * U, ty + rh * 5.4 - .02 * U, .018, "#ffd54a", AL_RIGHT, 800);
    // the coach: his view of you, your line, your spot on it
    { double cy = ty + rh * 5.4 + .015 * U, ch = std::min(.15 * U, H - .12 * U - cy); if (ch > .08 * U) {
      panel(m, cy, w, ch, .82); accentBar(m, cy, ch, hex("#f59e0b"));
      static const char *LN[3] = {"1ST LINE", "2ND LINE", "3RD LINE"};
      TB("COACH", m + .02 * U, cy + .028 * U, .02, "#f59e0b");
      double bx = m + .12 * U, bw = w * .26, by = cy + .02 * U; ctx.fill(rgba(148, 163, 184, .25)); ctx.fillRect(bx, by, bw, .016 * U);
      double cv = clamp(C.coach / 100, 0, 1); ctx.fill(C.coach >= 60 ? "#22c55e" : C.coach >= 40 ? "#eab308" : "#ef4444"); ctx.fillRect(bx, by, bw * cv, .016 * U);
      T(istr((int)jround(C.coach)) + (C.coachD >= .05 ? "  +" + fmt("%.1f", C.coachD) : C.coachD <= -.05 ? "  " + fmt("%.1f", C.coachD) : ""), bx + bw + .015 * U, by + .008 * U, .016, C.coachD >= 0 ? "#7CFC9A" : "#fca5a5", AL_LEFT, 800);
      std::string ln = C.lineWas >= 0 && C.lineWas != C.line ? std::string(LN[std::max(0, std::min(2, C.lineWas))]) + " > " + LN[std::max(0, std::min(2, C.line))] : LN[std::max(0, std::min(2, C.line))];
      std::string role = C.cen ? "CENTER" : C.pos == 'R' ? "RIGHT WING" : "LEFT WING";
      const MeStats &f2 = rs.f; int ozs = (int)jround(f2.ozt / std::max(1.0, f2.toi) * 100);
      T(ln + "   |   " + role + "   |   +/- " + (f2.pm > 0 ? "+" : "") + istr(f2.pm) + "   |   FACEOFFS " + istr(f2.fow) + "/" + istr(f2.fot) + "   |   ZONE TIME " + istr(ozs) + "%   |   POKES " + istr(f2.tk), m + .02 * U, cy + .065 * U, .016, "#fff", AL_LEFT, 800);
      if (!C.coachMsg.empty()) T("\"" + C.coachMsg + "\"", m + .02 * U, cy + .1 * U, .017, "#fde68a", AL_LEFT, 800);
      if (C.cOffer) { ui("coach:yes", m + w - .5 * U, cy + ch - .06 * U, .24 * U, .05 * U, "MOVE TO CENTER", "#16a34a", true, .02); ui("coach:no", m + w - .25 * U, cy + ch - .06 * U, .23 * U, .05 * U, "STAY ON THE WING", "#475569", true, .02); } } }
    ui("pres:next", W / 2 - .2 * U, H - .1 * U, .4 * U, .07 * U, "SKILL PROGRESS", "#2563eb", true, .03); ui("pres:skip", W - m - .22 * U, H - .1 * U, .22 * U, .07 * U, "SKIP", "#475569", true, .026);
    return;
  }
  if (presPg == 2) {   // the goals: the week's and the season's, filling up from where they stood before the game
    const GoalRes &R = proGoalRes(); scrHead("GOALS", "THIS WEEK AND THIS SEASON  |  WHERE TONIGHT LEFT THEM");
    double top = safeTop + .13 * U, gap = .02 * U, cw = (W - 2 * m - gap) / 2, bot = H - .2 * U;
    auto col = [&](double x, const char *title, const PWeek &P, const std::vector<int> &pre, bool year) {
      panel(x, top, cw, bot - top, .8); topLine(x, top, cw, hex(year ? "#a3e635" : "#38bdf8")); TB(title, x + .02 * U, top + .04 * U, .024, "#fff");
      bool all = !P.goals.empty(); for (auto &g : P.goals) if (!g.done) all = false;
      T(all ? (year ? "ALL DONE  |  +$" + fmtN(yearAllBonus()) : "ALL DONE  |  +$" + fmtN(weekAllBonus())) : std::string("FINISH THEM ALL: +$") + fmtN(year ? yearAllBonus() : weekAllBonus()), x + cw - .02 * U, top + .04 * U, .014, all ? "#7CFC9A" : "#94a3b8", AL_RIGHT, 800);
      double y = top + .08 * U, rh = std::min(.075 * U, (bot - y - .01 * U) / std::max<size_t>(1, P.goals.size()) - .008 * U);
      if (P.goals.empty()) T("No goals set right now.", x + .02 * U, y + .02 * U, .016, "#94a3b8", AL_LEFT, 700);
      for (size_t i = 0; i < P.goals.size(); i++) { const PGoal &g = P.goals[i]; double gy = y + i * (rh + .008 * U), k = clamp((t - .2 - i * .15) / 1.0, 0, 1); k = 1 - std::pow(1 - k, 3);
        double a = i < pre.size() ? std::min(pre[i], g.tg) : std::min(g.pr, g.tg), b = std::min(g.pr, g.tg), v = a + (b - a) * k, fr = clamp(v / std::max(1, g.tg), 0, 1);
        bool justDone = g.done && a < g.tg && k >= 1;
        ctx.fill(g.done ? rgba(34, 197, 94, .14) : rgba(255, 255, 255, .05)); ctx.fillRect(x + .012 * U, gy, cw - .024 * U, rh);
        TF(upper(g.txt), x + .025 * U, gy + rh * .3, .016, cw * .62, g.done ? "#7CFC9A" : "#fff");
        T(g.done ? (justDone ? "DONE!" : "DONE") : istr((int)jround(v)) + " / " + istr(g.tg), x + cw - .025 * U, gy + rh * .3, .016, g.done ? "#7CFC9A" : "#cbd5e1", AL_RIGHT, 800);
        double bx = x + .025 * U, bw = cw - .05 * U; ctx.fill(rgba(148, 163, 184, .22)); ctx.fillRect(bx, gy + rh * .62, bw, std::max(4.0, rh * .14));
        ctx.fill(g.done ? "#22c55e" : year ? "#a3e635" : "#38bdf8"); ctx.fillRect(bx, gy + rh * .62, bw * fr, std::max(4.0, rh * .14));
        if (b > a && !g.done) T("+" + istr((int)(b - a)), bx + bw * fr + 6, gy + rh * .69, .013, "#ffd54a", AL_LEFT, 800); } };
    col(m, "THIS WEEK", R.wk, R.preW, false); col(m + cw + gap, "THIS SEASON", R.yr, R.preY, true);
    std::string line; if (R.perf) line = "PERFORMANCE BONUS +$" + istr(R.perf) + "  (" + istr(R.pg) + " G x $" + istr(proLg() ? 10 : 25) + ", " + istr(R.pa) + " A x $" + istr(proLg() ? 5 : 10) + ")";
    if (R.allW) line += std::string(line.empty() ? "" : "   |   ") + "ALL WEEKLY GOALS +$" + fmtN(R.allW); if (R.allY) line += std::string(line.empty() ? "" : "   |   ") + "ALL SEASON GOALS +$" + fmtN(R.allY);
    if (!line.empty()) TB(line, W / 2, bot + .035 * U, .018, "#ffd54a", AL_CENTER);
    ui("pres:next", W / 2 - .2 * U, H - .1 * U, .4 * U, .07 * U, "HEAD HOME", "#16a34a", true, .03);
    return;
  }
  scrHead("SKILL PROGRESS", "WHAT TONIGHT DID FOR YOUR GAME  |  +" + fmtN(rs.xp) + " XP");
  std::vector<SkillGain> G = proSkillGains(); double top = safeTop + .13 * U, w = W - 2 * m;
  if (G.empty()) TB("No skill growth this time.", W / 2, top + .1 * U, .03, "#94a3b8", AL_CENTER);
  double rh = std::min(.058 * U, (H - top - .14 * U) / std::max<size_t>(1, G.size()) - .008 * U);
  for (size_t i = 0; i < G.size() && i < 10; i++) { const SkillGain &g = G[i]; double y = top + i * (rh + .008 * U), k = clamp((t - i * .12) / 1.1, 0, 1); k = 1 - std::pow(1 - k, 3);
    double v = g.a + (g.b - g.a) * k; int lv = (int)std::floor(v); double fr = v - lv; bool up = (int)std::floor(v) > (int)std::floor(g.a);
    panel(m, y, w, rh, .7); TF(FNICE(g.k), m + .02 * U, y + rh / 2, .019, w * .22, "#fff"); TB(istr(lv), m + w * .27, y + rh / 2, .026, up ? "#7CFC9A" : "#ffd54a", AL_RIGHT);
    double bx = m + w * .3, bw = w * .55; ctx.fill(rgba(148, 163, 184, .2)); ctx.fillRect(bx, y + rh * .35, bw, rh * .3);
    double a0 = (int)std::floor(v) > (int)std::floor(g.a) ? 0 : g.a - std::floor(g.a); ctx.fill("#94a3b8"); ctx.fillRect(bx, y + rh * .35, bw * a0, rh * .3); ctx.fill(up ? "#22c55e" : "#38bdf8"); ctx.fillRect(bx + bw * a0, y + rh * .35, bw * std::max(0.0, fr - a0), rh * .3);
    T(up ? "LEVEL UP!" : "+" + istr((int)jround((g.b - g.a) * 100)) + "%", m + w - .02 * U, y + rh / 2, .017, up ? "#7CFC9A" : "#cbd5e1", AL_RIGHT, 800); }
  ui("pres:next", W / 2 - .2 * U, H - .1 * U, .4 * U, .07 * U, "YOUR GOALS", "#16a34a", true, .03);
}
// heading home: the apartment is built behind a loading screen, and thrown away again before every game
static int loadF = 0; static double loadT0 = 0;
static void drawAptLoad() {
  if (loadF == 0) loadT0 = now();
  Col a = hex(teamCol(C.me)); ctx.fill(vgrad(0, H, shade(a, -.55), hex("#05070d"))); ctx.fillRect(0, 0, W, H);
  double cx = W / 2, cy = H * .42, t = now() / 1000;
  for (int i = 0; i < 10; i++) { double ang = t * 5 - i * .45, r = .06 * U; ctx.fill(rgba(255, 213, 74, (float)(1 - i * .09))); ctx.disc(cx + std::cos(ang) * r, cy + std::sin(ang) * r, .009 * U * (1 - i * .06)); }
  TB("HEADING HOME", cx, cy + .14 * U, .05, "#fff", AL_CENTER);
  T(upper(C.nm) + "'S PLACE  |  FILE " + istr(proSlot + 1), cx, cy + .2 * U, .02, "#94a3b8", AL_CENTER, 700);
  double k = clamp((now() - loadT0) / 450, 0, 1), bw = .5 * U; ctx.fill(rgba(255, 255, 255, .12)); ctx.rr(cx - bw / 2, cy + .25 * U, bw, 4, 2); ctx.fillPath(); ctx.fill("#ffd54a"); ctx.rr(cx - bw / 2, cy + .25 * U, std::max(4.0, bw * (aptReady() ? k : k * .5)), 4, 2); ctx.fillPath();
  if (++loadF == 2) aptLoad();
  if (loadF > 2 && aptReady() && now() - loadT0 > 450) { loadF = 0; screen = "main"; }
}
static void drawApt() {
  if (phApp >= 0) { phApp = -1; phOn = true; mFocus = "app:" + istr(phLast); }   // an app closed itself: back to the home screen
  // the phone rings when something about your spot on a roster comes up
  if (C.hmArrived && aptOv.empty() && !phOn) { toast(istr(C.hmArrived) + (C.hmArrived == 1 ? " HOCKEYMON PACK" : " HOCKEYMON PACKS") + " AT YOUR DOOR - OPEN IN THE HOCKEYMON APP"); C.hmArrived = 0; }
  if (aptOv.empty() && !phOn) { CallInfo c = callNow(); if (c.key && c.key != C.callSeen) { aptOv = "call"; phT0 = now(); mPadUsed = true; mFocus = "call:yes"; } }
  drawAptView(phOn || !aptOv.empty());
  double m = .03 * U, ty = safeTop + .03 * U;
  if (!phOn && aptOv.empty()) {
    aptHUD(); int lk = aptLook(); bool sit = aptSitting();
    ctx.fill(rgba(8, 12, 24, .6)); ctx.rr(m, ty - .01 * U, .5 * U, .085 * U, .015 * U); ctx.fillPath();
    TB(upper(C.nm) + "  |  OVR " + istr(proOvr()), m + .02 * U, ty + .015 * U, .022, "#fff");
    std::string nx = C.phase == "over" ? "OFF-SEASON: THE DOOR STARTS NEXT SEASON" : C.need ? "CONTRACT EXPIRED: SEE GM CONNECT" : offDay() ? "OFF DAY  |  TRAIN OR REST" : userHurt() ? "INJURED  |  OUT " + istr(youMe()->inj) : (proAway() ? "NEXT: AT " : "NEXT: VS ") + upper(C.L[C.opp].n);
    TF(nx, m + .02 * U, ty + .05 * U, .016, .46 * U, "#cbd5e1");
    TB("$" + fmtN(C.money), W - m, ty + .015 * U, .03, "#ffd54a", AL_RIGHT); TB(fmtN(C.xp) + " XP", W - m, ty + .052 * U, .02, "#93c5fd", AL_RIGHT);
    if (aptBuild) { ctx.fill(rgba(217, 119, 6, .9)); ctx.rr(W / 2 - .17 * U, ty - .01 * U, .34 * U, .05 * U, .012 * U); ctx.fillPath(); TB("BUILD MODE", W / 2, ty + .015 * U, .024, "#fff", AL_CENTER); }
    std::string pr;
    if (sit) pr = "X  STAND UP";
    else if (lk == APT_DOOR) pr = "X  FRONT DOOR"; else if (lk == APT_SHELF) pr = "X  TROPHY SHELF"; else if (lk == APT_PC) pr = "X  USE THE COMPUTER";
    else if (lk >= APT_HDOOR && lk < APT_HDOOR + APT_NHD) pr = aptDoorOpen(lk - APT_HDOOR) ? "X  CLOSE DOOR" : "X  OPEN DOOR";
    else if (lk >= APT_LIGHT && lk < APT_LIGHT + APT_NLIGHT) pr = std::string("X  ") + (aptLightOn(lk - APT_LIGHT) ? "LIGHTS OFF" : "LIGHTS ON") + "  |  " + APT_LIGHTN[lk - APT_LIGHT];
    else if (lk == APT_CONSOLE) pr = "X  PLAY PONG ON THE CHL STATION";
    else if (lk == APT_RADIO) { MusNow mn = mus_now(); pr = !settings.music ? std::string("X  TURN ON THE RADIO") : mn.on ? "X  NEXT SONG  |  " + upper(mn.title) : std::string("X  NEXT SONG"); }
    else if (lk >= APT_JUNK && lk < APT_JUNK + APT_NJUNK) pr = "X  THROW OUT " + std::string(APT_JUNKN[lk - APT_JUNK]);
    else if (lk == APT_COUNTER) { int out = 0; for (int k = 0; k < HOME_NCTR; k++) if (HOME.ctr[k] >= 0) out++; pr = "X  COUNTERTOP  (" + istr(out) + " / " + istr(HOME_NCTR) + ")"; }
    else if (lk >= APT_SLOT) { int s = lk - APT_SLOT; std::string what = s >= HS_BED ? "UPGRADE " + homeSlotName(s) : s >= HS_WALL ? "FIX THE DRYWALL  |  " + std::string(ROOMN[s - HS_WALL]) : s >= HS_PAINT ? "PAINT THE " + std::string(ROOMN[s - HS_PAINT]) : s >= HS_FLOOR ? "NEW FLOORING  |  " + std::string(ROOMN[s - HS_FLOOR]) : "UPGRADE " + homeSlotName(s);
      pr = "X  " + what + "  (" + HSLOT[s].o[(size_t)HOME.sel[s]].n + ")"; }
    if (!pr.empty()) { ctx.font(.022 * U); double tw = ctx.measure(pr) + .04 * U; ctx.fill(rgba(8, 12, 24, .82)); ctx.rr(W / 2 - tw / 2, H / 2 + .05 * U, tw, .05 * U, .025 * U); ctx.fillPath(); TB(pr, W / 2, H / 2 + .075 * U, .022, "#ffd54a", AL_CENTER); }
    double pw = .07 * U, ph = .12 * U, px = W - m - pw, py = H - ph + .02 * U; ctx.fill("#0a0a0c"); ctx.rr(px, py, pw, ph, .014 * U); ctx.fillPath(); ctx.fill(hex(teamCol(C.me))); ctx.rr(px + 3, py + 3, pw - 6, ph - 6, .011 * U); ctx.fillPath();
    T("START", px + pw / 2, py + .03 * U, .012, "#fff", AL_CENTER, 800);
    T(sit ? std::string("R-STICK LOOK   X STAND UP   START PHONE") : std::string("L-STICK MOVE   R-STICK LOOK   X USE   START PHONE   D-PAD LEFT ") + (aptBuild ? "EXIT BUILD" : "BUILD MODE"), m, H - .03 * U, .0145, "#e2e8f0", AL_LEFT, 700);
  }
  std::string msg = now() - aptToastT < 3200 ? aptToast : !C.wkMsg.empty() ? C.wkMsg : !C.injMsg.empty() ? C.injMsg : proMsg;
  if (!msg.empty() && aptOv != "door" && aptOv != "pc" && aptOv != "pong") { double px = std::min(.02 * U, (W - .06 * U) / std::max<size_t>(1, msg.size()) * 1.7); ctx.font(px); double tw = ctx.measure(msg) + .04 * U, my = safeTop + .1 * U;
    ctx.fill(rgba(8, 12, 24, .9)); ctx.rr(W / 2 - tw / 2, my, tw, .036 * U, .018 * U); ctx.fillPath(); ctx.fill("#ffd54a"); ctx.textMid(); ctx.fillText(msg, W / 2, my + .018 * U); }
  if (aptOv == "door") drawDoor(); else if (aptOv == "store") drawPhoneStore(); else if (aptOv == "ctr") drawPhoneCounter(); else if (aptOv == "pc") drawPC(); else if (aptOv == "pong") drawPong(); else if (aptOv == "call") drawCall(); else if (phOn) drawPhoneGrid();
}
// the pad and touch in the apartment (the menus take over when the phone or a panel is up)
bool proAptInput(uint32_t press, const Pad &pad, const Touch &touch) {
  if (mode != "pro" || !CR || modal.on) return false;
  bool inHome = screen == "main" || phApp >= 0;
  if (inHome && (press & B_START) && C.phase != "retired" && aptOv != "call") {
    if (proAptWorld()) { phOn = true; phT0 = now(); mFocus = "app:" + istr(phLast); mPadUsed = true; }
    else { phOn = false; phApp = -1; aptOv.clear(); screen = "main"; }
    return true; }
  if (aptOv == "pong" && mode == "pro" && screen == "main" && !phOn) { double t = now(), dt = clamp((t - aptLastT) / 1000, 0, .05); aptLastT = t; pongStep(press, pad, touch, dt); return true; }
  if (!proAptWorld()) { aptLastT = now(); return false; }
  double t = now(), dt = clamp((t - aptLastT) / 1000, 0, .05); aptLastT = t;
  Touch tt = touch; tt.n = 0; static int phTid = -1; bool tapPh = false;
  for (int i = 0; i < touch.n; i++) { const TouchPt &p = touch.p[i]; bool onPh = p.x > W - .12 * U && p.y > H - .14 * U;
    if (onPh && p.id != phTid) { phTid = p.id; tapPh = true; } else if (!onPh && tt.n < 6) tt.p[tt.n++] = p; }
  if (!touch.n) phTid = -1;
  if (tapPh) { phOn = true; phT0 = now(); mFocus = "app:" + istr(phLast); return true; }
  aptMove(pad, tt, dt);
  if (aptSitting()) { if (press & B_CROSS) aptStand(); return true; }
  if (press & B_LEFT) { aptBuild = !aptBuild; toast(aptBuild ? "BUILD MODE: LOOK AT SOMETHING AND PRESS X" : "BUILD MODE OFF"); }
  if (press & B_CROSS) { int lk = aptLook();
    if (lk == APT_DOOR) { aptOv = "door"; mPadUsed = true; mFocus = ""; }
    else if (lk == APT_SHELF) { int a = C.titles, b = C.calder; toast(a + b ? istr(a) + (a == 1 ? " STANLEY CUP" : " STANLEY CUPS") + "  |  " + istr(b) + (b == 1 ? " CALDER CUP" : " CALDER CUPS") : "AN EMPTY SHELF. GO WIN SOMETHING."); }
    else if (lk >= APT_HDOOR && lk < APT_HDOOR + APT_NHD) aptDoor(lk - APT_HDOOR);
    else if (lk >= APT_LIGHT && lk < APT_LIGHT + APT_NLIGHT) aptLight(lk - APT_LIGHT);
    else if (lk == APT_RADIO) { if (!settings.music) { setVolume(true, 60); toast("RADIO ON"); } else { mus_skip(); toast("NEXT SONG"); } }
    else if (lk == APT_CONSOLE) { aptOv = "pong"; pongStart(); }
    else if (lk == APT_PC) { aptOv = "pc"; mPadUsed = true; { int f = HOME.lvl; for (int i = 0; i < (int)APTS.size(); i++) if (!(HOME.lvlOwn >> i & 1)) { f = i; break; } mFocus = "pc:" + istr(f); } }
    else if (lk >= APT_JUNK && lk < APT_JUNK + APT_NJUNK) { int b = lk - APT_JUNK; mPadUsed = true; askModal("THROW IT OUT?", "Take " + std::string(APT_JUNKN[b]) + " to the dumpster? They're gone for good.", [b] { aptThrow(b); toast("GONE. THE PLACE LOOKS BIGGER ALREADY."); }); }
    else if (lk == APT_COUNTER) { pickClose(); aptOv = "ctr"; phT0 = now(); mPadUsed = true; mFocus = "hc:0"; }
    else if (lk >= APT_SLOT) { pickClose(); aptOv = "store"; storeSlot = lk - APT_SLOT; phT0 = now(); mPadUsed = true; mFocus = "hb:" + istr(storeSlot) + ":" + istr(HOME.sel[storeSlot]); } }
  return true;
}
static bool aptTap(const std::string &id) {
  if (id == "coach:yes" || id == "coach:no") { proCoachAnswer(id == "coach:yes"); return true; }
  if (pre(id, "pres:")) { if (id == "pres:next" && presPg < 2) { presPg++; presT0 = now(); } else presDone(); return true; }
  if (id == "ph:close" && pickOpt >= 0) return aptTap("hpick:no");
  if (id == "ph:close") { if (phApp >= 0) { phApp = -1; screen = "main"; mFocus = "app:" + istr(phLast); } else if (aptOv == "call") return true; else if (!aptOv.empty()) aptOv.clear(); else phOn = false; return true; }
  if (id == "ad:close" || id == "pc:close") { aptOv.clear(); return true; }
  if (id == "call:yes" || id == "call:no") { CallInfo c = callNow(); C.callSeen = c.key; aptOv.clear(); proSave();
    if (id == "call:yes" && !c.scr.empty()) { phOn = true; phApp = 4; phLast = 4; screen = c.scr; } return true; }
  if (pre(id, "pc:")) { int i = atoi(id.c_str() + 3); int r = homeMove(i); toast(r == 1 ? "YOU BOUGHT " + std::string(APTS[(size_t)i].n) + ". WELCOME HOME." : r == 2 ? "MOVED INTO " + std::string(APTS[(size_t)i].n) : "NOT ENOUGH CASH");
    if (r) { aptOv.clear(); aptReset(); } return true; }
  if (pre(id, "app:")) { int i = atoi(id.c_str() + 4); phLast = i;
    if (i == NAPPS - 1) { phOn = false; phApp = -1; aptOv.clear(); pickClose(); proSave(); screen = "main"; uiTap("nav:modes"); return true; }   // exit: saved, then out to the main menu
    phApp = i; screen = APPS[i].scr; mFocus = "";
    if (i == 10) { msgSel = -1; proReadTexts(); }
    if (i == 14) casNet = 0;
    if (i == 13) { hmSel = -1; hmOpening.clear(); int d = 0; for (int k = 0; k < HM_NP; k++) d += C.hmDoor[k]; hmTab = d ? 1 : 0; }
    if (i == 0) schedPg = -1; if (i == 7) { standLg = proLg(); standTab = C.phase == "po" || C.phase == "over" ? 8 : C.L[C.me].d; } if (i == 8) { newsMark = C.newsN - C.newsSeen; C.newsSeen = C.newsN; }
    if (i == 4 && C.showTrade && C.hasTrade) screen = "trade";
    return true; }
  if (pre(id, "hm:") && hmTap(id)) return true;
  if (casTap(id)) return true;
  if (pre(id, "msg:t:")) { msgSel = atoi(id.c_str() + 6); return true; }
  if (pre(id, "msg:r:")) { int i = atoi(id.c_str() + 6); size_t c = id.find(':', 6); int o = c == std::string::npos ? 0 : atoi(id.c_str() + c + 1); proAnswerText(i, o); mFocus = "msg:t:" + istr(std::max(0, msgSel)); return true; }
  if (pre(id, "hcol:")) { pickCol = atoi(id.c_str() + 5); return true; }
  if (id == "hpick:no") { int o = pickOpt; bool ct = pickCtr; int sl = pickSlot; pickClose(); mFocus = ct ? "hc:" + istr(o) : "hb:" + istr(sl) + ":" + istr(o); return true; }
  if (id == "hpick:ok" && pickOpt >= 0) { int o = pickOpt, c = pickCol, sl = pickSlot; bool ct = pickCtr; pickClose();
    if (ct) { int r = homeCounter(o); if (r == 1 || r == 2) homeSetCtrCol(o, c); const char *n = COUNTER[(size_t)o].n;
      toast(r == 1 ? "BOUGHT: " + std::string(n) : r == 2 ? "PUT OUT: " + std::string(n) : r == 4 ? "THE COUNTER IS FULL (4 MAX)" : "NOT ENOUGH CASH"); mFocus = "hc:" + istr(o); }
    else { int r = homeBuy(sl, o); if (r == 1 || r == 2) homeSetCol(sl, c);
      toast(r == 1 ? "BOUGHT: " + std::string(HSLOT[sl].o[(size_t)o].n) : r == 2 ? "IN USE: " + std::string(HSLOT[sl].o[(size_t)o].n) : r < 0 ? "FIX THE DRYWALL FIRST" : "NOT ENOUGH CASH"); mFocus = "hb:" + istr(sl) + ":" + istr(o); }
    return true; }
  if (pre(id, "hb:")) { int c = atoi(id.c_str() + 3), i = atoi(id.c_str() + id.rfind(':') + 1);
    if (!homeSwatches(c, i).empty()) { pickSlot = c; pickOpt = i; pickCtr = false; pickCol = HOME.sel[c] == i ? HOME.col[c] : -1; mFocus = "hcol:" + istr(pickCol); return true; }   // colours first
    int r = homeBuy(c, i);
    toast(r == 1 ? "BOUGHT: " + std::string(HSLOT[c].o[(size_t)i].n) : r == 2 ? "SWAPPED IN: " + std::string(HSLOT[c].o[(size_t)i].n) : r < 0 ? "FIX THE DRYWALL FIRST" : "NOT ENOUGH CASH"); return true; }
  if (pre(id, "hc:")) { int i = atoi(id.c_str() + 3);
    if (!homeCtrOut(i)) { int out = 0; for (int k = 0; k < HOME_NCTR; k++) if (HOME.ctr[k] >= 0) out++;
      if (out < HOME_NCTR) { pickSlot = -1; pickOpt = i; pickCtr = true; pickCol = HOME.ctrCol[i]; mFocus = "hcol:" + istr(pickCol); return true; } }
    int r = homeCounter(i); const char *n = COUNTER[(size_t)i].n;
    toast(r == 1 ? "BOUGHT: " + std::string(n) : r == 2 ? "PUT OUT: " + std::string(n) : r == 3 ? "PUT AWAY: " + std::string(n) : r == 4 ? "THE COUNTER IS FULL (4 MAX)" : "NOT ENOUGH CASH"); return true; }
  if (aptOv == "door") { if (id == "off:neg") { aptOv.clear(); phOn = true; phApp = 4; return false; } if (id == "nav:train") { aptOv.clear(); phOn = true; phApp = 3; return false; }
    if (id == "play" || id == "sim1" || id == "simN" || id == "simheal" || id == "skipday" || id == "next") aptOv.clear(); }
  if (id == "nav:modes" && phApp >= 0 && screen == "settings") { phApp = -1; screen = "main"; mFocus = "app:" + istr(phLast); return true; }   // the Settings app's BACK
  if (id == "nav:modes") { phOn = false; phApp = -1; aptOv.clear(); aptUnload(); }
  return false;
}
static void drawSettingsApp() { drawSettingsBody(); }
// the career screens that live on the phone
static void (*phoneScreen())() {
  if (screen == "sched") return drawSched; if (screen == "health") return drawHealth; if (screen == "upg") return drawUpg; if (screen == "train") return drawTrain;
  if (screen == "office") return drawOffice; if (screen == "neg") return drawNeg; if (screen == "ntc") return drawNtc; if (screen == "treq") return drawTreq; if (screen == "toff") return drawOffers;
  if (screen == "trade") return drawTradeAlert; if (screen == "shop") return drawShop; if (screen == "stand") return drawStand; if (screen == "msgs") return drawMsgs; if (screen == "casino") return drawCasino; if (screen == "hockeymon") return drawHockeymon; if (screen == "myteam") return drawMyTeam;
  if (screen == "perf") return drawPerf; if (screen == "news") return drawNews; if (screen == "goals") return drawGoals; if (screen == "settings") return drawSettingsApp;
  return nullptr;
}

// ---------------------------------------------------------------- the router
void proEnter() {
  CR.reset(); proSlot = -1; mode = "pro"; screen = "proslots"; phOn = false; phApp = -1; aptOv.clear(); aptBuild = false;
  // a one-time test file in slot 3 with money to spend in the apartment; once deleted it's an ordinary slot
  aptUnload();
  if (!homeTestMade()) { homeSetTestMade(); if (!proSlotInfo(2).on) { proNew(2, "TEST", 19, 1); C.money = 100000; C.draftDone = true; proSave(); CR.reset(); proSlot = -1; } }
}
void proContinue(int i) { proEnter(); proLoadSlot(i); if (CR) { setLast("pro", i); screen = !C.draftDone ? "draft" : C.phase == "retired" ? "retired" : "main"; draftT0 = now(); aptReset(); } }
void drawPro() {
  if (screen == "proslots") { drawSlots(); return; }
  if (screen == "pronew") { drawNew(); return; }
  if (!CR) { screen = "proslots"; drawSlots(); return; }
  if (C.phase == "retired" && screen != "retired") screen = "retired";
  if (phApp >= 0 || (phOn && screen != "main")) { auto fn = phoneScreen(); if (fn) { if (phApp < 0) phApp = 4; drawInPhone(fn); return; }
    if (phApp >= 0) { phApp = -1; phOn = true; mFocus = "app:" + istr(phLast); } else phOn = false; }   // back out of an app: the home screen
  if (screen == "draft") drawDraft();
  else if (screen == "upg") drawUpg();
  else if (screen == "train") drawTrain();
  else if (screen == "shop") drawShop();
  else if (screen == "office") drawOffice();
  else if (screen == "neg") drawNeg();
  else if (screen == "ntc") drawNtc();
  else if (screen == "treq") drawTreq();
  else if (screen == "toff") drawOffers();
  else if (screen == "trade") drawTradeAlert();
  else if (screen == "sched") drawSched();
  else if (screen == "stand") drawStand();
  else if (screen == "retired") drawRetired();
  else if (screen == "busy") drawBusy();
  else if (screen == "aptload") drawAptLoad();
  else if (screen == "presult") drawPResult();
  else { screen = "main"; if (!aptReady()) { loadF = 0; screen = "aptload"; drawAptLoad(); } else drawApt(); }
}
void proShoulder(int d) {
  if (screen == "upg") upTab = (upTab + 2 + d) % 2;
  else if (screen == "shop") shopCat = (shopCat + (int)GEARF.size() + d) % (int)GEARF.size();
  else if (screen == "stand") { do standTab = (standTab + 9 + d) % 9; while (standTab == 6); }
  else if (screen == "sched") schedPg = std::max(0, schedPg + d);
}
bool proTap(const std::string &id) {
  if (mode != "pro") return false;
  if (screen != "main" && CR) { C.wkMsg.clear(); C.injMsg.clear(); }
  if (pre(id, "pslot:")) { int i = atoi(id.c_str() + 6); if (proSlotInfo(i).on) proContinue(i);
    else proNameStart(i); return true; }
  if (pre(id, "pdel:")) { int i = atoi(id.c_str() + 5); askModal("DELETE FILE " + istr(i + 1) + "?", "ARE YOU SURE? " + upper(proSlotInfo(i).nm) + "'s career will be gone for good.", [i] { proDelete(i); mFocus = "pslot:" + istr(i); }); return true; }
  if (id == "pncancel") { screen = "proslots"; return true; }
  if (pre(id, "pnum:")) { int d = atoi(id.c_str() + 5); pendNum = ((pendNum - 1 + d) % 99 + 99) % 99 + 1; return true; }
  if (pre(id, "pdiff:")) { pendDiff = atoi(id.c_str() + 6); return true; }
  if (id == "ppos:C" || id == "ppos:L" || id == "ppos:R") { pendPos = id[5]; return true; }
  if (id == "psh:L" || id == "psh:R") { pendSh = id[4]; return true; }
  if (pre(id, "look:")) { size_t c = id.find(':', 5); std::string k = id.substr(5, c - 5); int d = atoi(id.c_str() + c + 1);
    auto cyc = [&](int &v, int n) { v = ((v + d) % n + n) % n; };
    if (k == "skin") cyc(pendLook.skin, NSKIN); else if (k == "face") cyc(pendLook.face, NFACE); else if (k == "hair") cyc(pendLook.hair, NHAIR); else if (k == "hairc") cyc(pendLook.hairC, NHAIRC);
    return true; }
  if (id == "pgo") { std::string nm = pname; while (!nm.empty() && nm.back() == ' ') nm.pop_back(); if (nm.empty()) nm = "ROOKIE"; proNew(nameTarget, nm, pendNum, pendDiff, pendPos, pendSh, &pendLook); pendLookFor = "\x01"; setLast("pro", nameTarget); screen = "draft"; draftT0 = now(); return true; }
  if (!CR) return false;
  if (aptTap(id)) return true;
  if (id == "draftdone") { C.draftDone = true; screen = "main"; proSave(); return true; }
  if (id == "ptradeok") { C.showTrade = false; C.hasTrade = false; screen = C.need ? "office" : "main"; proSave(); return true; }
  if (id == "pnewc") { proNameStart(proSlot); return true; }
  if (id == "sim1") { proSimGames(1); return true; }
  if (id == "simN") { proSimGames(C.phase == "po" ? 5 : 10); return true; }
  if (id == "simheal") { proSimHealthy(); return true; }
  if (id == "skipday") { proSkipDay(); return true; }
  if (id == "next") { screen = "busy"; busyF = 0; return true; }
  if (pre(id, "train:")) { proDoTrain(atoi(id.c_str() + 6)); screen = "main"; return true; }
  if (pre(id, "utab:")) { upTab = atoi(id.c_str() + 5); return true; }
  if (pre(id, "up1:")) { proUpgrade(id.substr(4), 1); return true; }
  if (pre(id, "up5:")) { proUpgrade(id.substr(4), 5); return true; }
  if (pre(id, "pbuy:")) { pkBuy(id.substr(5)); return true; }
  if (pre(id, "pup:")) { pkUp(id.substr(4)); return true; }
  if (pre(id, "peq:")) { pkEquip(id.substr(4)); return true; }
  if (pre(id, "gcat:")) { shopCat = atoi(id.c_str() + 5); return true; }
  if (pre(id, "gear:")) { std::string r = id.substr(5); size_t c = r.find(':'); gearTap(r.substr(0, c), atoi(r.c_str() + c + 1)); return true; }
  if (pre(id, "stab:")) { standTab = atoi(id.c_str() + 5); return true; }
  if (id == "sch:-") { schedPg--; return true; } if (id == "sch:+") { schedPg++; return true; }
  if (id == "nav:sched") { schedPg = -1; screen = "sched"; return true; }
  if (id == "nav:stand") { standLg = proLg(); standTab = C.phase == "po" || C.phase == "over" ? 8 : C.L[C.me].d; screen = "stand"; return true; }
  if (pre(id, "slg:")) { standLg = atoi(id.c_str() + 4) ? 1 : 0; if (standLg && CR->L.size() < (size_t)NALL) standLg = 0; return true; }
  if (id == "off:neg") { if (!C.hasNeg || C.neg.forced != C.need) negStart(C.need); screen = "neg"; return true; }
  if (id == "neg:y-") { C.neg.yrs = std::max(1, C.neg.yrs - 1); return true; }
  if (id == "neg:y+") { C.neg.yrs = std::min(5, C.neg.yrs + 1); return true; }
  if (id == "neg:ntc") { C.neg.ntc = !C.neg.ntc; return true; }
  if (id == "neg:bonus") { C.neg.bonus = (C.neg.bonus + 1) % 3; return true; }
  if (id == "neg:perf") { C.neg.perf = !C.neg.perf; return true; }
  if (id == "neg:push") { negPush(); return true; }
  if (id == "neg:ok") { negAccept(); screen = "office"; return true; }
  if (id == "neg:walk") { if (C.neg.forced) { if (C.neg.sure) { proFreeAgency(); screen = "trade"; proSave(); } else C.neg.sure = true; } else { C.hasNeg = false; screen = "office"; } return true; }
  if (pre(id, "ntc:")) { askNTC(id == "ntc:1"); screen = "office"; return true; }
  if (id == "nav:treq") { tqSel = C.hasTreq ? C.treqT : std::vector<int>(); screen = "treq"; return true; }
  if (pre(id, "tq:")) { std::string k = id.substr(3); if (k == "go") { submitTradeReq(tqSel); screen = "office"; } else if (k == "clr") tqSel.clear();
    else { int t = atoi(k.c_str()); auto it = std::find(tqSel.begin(), tqSel.end(), t); if (it != tqSel.end()) tqSel.erase(it); else if (tqSel.size() < 10) tqSel.push_back(t); } return true; }
  if (pre(id, "tof:")) { int i = atoi(id.c_str() + 6); if (id[4] == 'a') acceptOffer(i); else rejectOffer(i); return true; }
  if (id == "nav:main") { screen = "main"; return true; }
  return false;
}
#undef C

// CHL 2026 native - BE A PRO screens: save files, the new-career setup, draft night, the hub, upgrades and perks,
// training, the gear shop, the office (contract, no-trade clause, trade requests, offers), the trade alert, the
// schedule, the league (standings, scorers, goalies, news, your team, the playoff bracket) and retirement.
#include "pro.h"
#include "apt.h"
#include <algorithm>

void menuSkFig(double f, int d, double stride, Col col, Col stripe, Col skin, Col helm, double lean, double wind, bool star);
double proBusyT = 0;
static int pendNum = 19, pendDiff = 1, upTab = 0, shopCat = 0, standTab = 0, standLg = 0, schedPg = -1, busyF = 0, perkSel = 0;
static std::vector<int> tqSel;
static double draftT0 = 0;
#define C (*CR)

// ---------------------------------------------------------------- pieces
static void T(const std::string &t, double x, double y, double sz, const char *c, Align al = AL_LEFT, int wt = 800) { tx(t, x, y, sz, c, al, wt); }
static void TB(const std::string &t, double x, double y, double sz, const char *c, Align al = AL_LEFT) { tx(t, x, y, sz, hex(c), al, true); }
static void TF(const std::string &t, double x, double y, double sz, double mw, const char *c, Align al = AL_LEFT) { txFit(t, x, y, sz, mw, hex(c), al); }
static void panel(double x, double y, double w, double h, double a = .74) { ctx.fill(rgba(15, 23, 42, (float)a)); ctx.fillRect(x, y, w, h); }
static void scrHead(const std::string &t, const std::string &sub) { double m = .03 * U, ty = safeTop + .045 * U; TB(t, m, ty, .055, "#fff"); if (!sub.empty()) { TXR = W * .7; T(sub, m, ty + .045 * U, .019, "#f26b5b", AL_LEFT, 700); TXR = 1e4; } }
static void cashTag() { double m = .03 * U; T("CASH", W - m, safeTop + .028 * U, .016, "#94a3b8", AL_RIGHT, 700); TB("$" + fmtN(C.money), W - m, safeTop + .06 * U, .034, "#ffd54a", AL_RIGHT); }
static void xpTagTop() { double m = .03 * U; T("XP", W - m - .2 * U, safeTop + .028 * U, .016, "#94a3b8", AL_RIGHT, 700); TB(fmtN(C.xp), W - m - .2 * U, safeTop + .06 * U, .034, "#ffd54a", AL_RIGHT); }
static void dimOut(double x, double y, double w, double h) { ctx.fill(rgba(11, 16, 36, .62)); ctx.fillRect(x, y, w, h); if (!btns.empty()) btns.back().dis = true; }
static void meter(double x, double y, double w, double v, const char *col, const std::string &lb) {
  T(lb, x, y, .016, "#94a3b8", AL_LEFT, 700); T(istr((int)jround(v * 100)), x + w, y, .017, "#fff", AL_RIGHT, 900);
  ctx.fill(rgba(148, 163, 184, .25)); ctx.fillRect(x, y + .016 * U, w, 5); ctx.fill(col); ctx.fillRect(x, y + .016 * U, std::max(2.0, w * v), 5);
}
static void badge(double x, double y, double r, int t) {
  ctx.fill(rgba(2, 6, 23, .8)); ctx.disc(x, y, r * 1.12); ctx.fill(hex(teamCol(t))); ctx.disc(x, y, r); ctx.fill(hex(teamStr(t))); ctx.font(r * .72); ctx.textMid(); ctx.fillText(C.L[t].ab, x, y + 1);
}
static const std::vector<std::pair<std::string, std::string>> PADH = {{"D-PAD", "MOVE"}, {"X", "SELECT"}, {"O", "BACK"}};
static void back(const std::string &id, double y) { ui(id, (W - .4 * U) / 2, y, .4 * U, .07 * U, "BACK", "#475569", true, .032); }
static std::string money2(double v) { return "$" + fixed(v, 2) + "M"; }
static void you(double x, double y, double f) {
  ctx.save(); ctx.translate(x, y); Col c = hex(teamCol(C.me)); menuSkFig(f, 2, 0, c, hex(teamStr(C.me)), hex("#e0a878"), shade(c, -.15), .1, 0, false); ctx.restore();
}

// ---------------------------------------------------------------- save files and a new career
static void drawSlots() {
  double w = std::min(W - 24.0, 1.7 * U), x = (W - w) / 2, y = safeTop + .02 * U, rh = .17 * U;
  TB("BE A PRO", W / 2, y + .05 * U, .075, "#fff", AL_CENTER); T("Choose a career   (SQUARE: delete)", W / 2, y + .12 * U, .03, "#cbd5e1", AL_CENTER, 700);
  for (int i = 0; i < 3; i++) {
    double ry = y + .17 * U + i * (rh + .012 * U); ProSlotInfo s = proSlotInfo(i); panel(x, ry, w, rh, .62);
    if (s.on) {
      ctx.fill("#c8102e"); ctx.fillRect(x, ry, .012 * U, rh); TXR = x + w - .27 * U;
      TB(upper(s.nm), x + .035 * U, ry + rh * .28, .045, "#ffd54a");
      T(s.phase == "retired" ? "RETIRED  |  " + istr(s.titles) + (s.titles == 1 ? " TITLE" : " TITLES") : "FORWARD  |  OVR " + istr(s.ov) + "  |  " + upper(s.team), x + .035 * U, ry + rh * .56, .03, "#fff");
      T("AGE " + istr(s.age) + "   |   SEASON " + istr(s.season) + "   |   " + istr(s.titles) + (s.titles == 1 ? " CHAMPIONSHIP" : " CHAMPIONSHIPS"), x + .035 * U, ry + rh * .82, .023, "#94a3b8", AL_LEFT, 700);
      TXR = 1e4; pushBtn("pslot:" + istr(i), x, ry, w - .25 * U, rh);
      ui("pdel:" + istr(i), x + w - .24 * U, ry + rh * .3, .22 * U, rh * .4, "DELETE", "#475569", true, .026);
    } else { T("FILE " + istr(i + 1) + " - NEW CAREER", W / 2, ry + rh / 2, .036, "#7aa7ff", AL_CENTER); pushBtn("pslot:" + istr(i), x, ry, w, rh); }
  }
  double hy = y + .17 * U + 3 * (rh + .012 * U) + .015 * U;
  if (proHofCareers) T("HALL OF FAME: " + istr(proHofCareers) + (proHofCareers == 1 ? " CAREER" : " CAREERS") + " COMPLETE  |  MOST TITLES " + istr(proHofBest), W / 2, hy, .02, "#94a3b8", AL_CENTER, 700);
  back("nav:modes", hy + .025 * U);
}
static void drawNew() {
  double w = std::min(W - 24.0, 1.5 * U), x = (W - w) / 2, y = safeTop + .03 * U;
  TB("NEW CAREER", W / 2, y + .045 * U, .06, "#fff", AL_CENTER); T(upper(pname), W / 2, y + .1 * U, .032, "#ffd54a", AL_CENTER);
  double ry = y + .14 * U, rh = .12 * U;
  panel(x, ry, w, rh, .62); T("JERSEY NUMBER", x + .03 * U, ry + rh / 2, .03, "#fff");
  double bx = x + w - .5 * U; ui("pnum:-10", bx, ry + rh * .2, .08 * U, rh * .6, "-10", "#334155", true, .025); ui("pnum:-1", bx + .09 * U, ry + rh * .2, .07 * U, rh * .6, "<", "#334155", true, .03);
  TB("#" + istr(pendNum), bx + .24 * U, ry + rh / 2, .05, "#fff", AL_CENTER);
  ui("pnum:1", bx + .32 * U, ry + rh * .2, .07 * U, rh * .6, ">", "#334155", true, .03); ui("pnum:10", bx + .4 * U, ry + rh * .2, .08 * U, rh * .6, "+10", "#334155", true, .025);
  ry += rh + .015 * U; panel(x, ry, w, rh, .62); T("POSITION", x + .03 * U, ry + rh / 2, .03, "#fff");
  ui("ppos:F", x + w - .62 * U, ry + rh * .18, .3 * U, rh * .64, "FORWARD", "#16a34a", true, .03);
  ui("ppos:G", x + w - .3 * U, ry + rh * .18, .28 * U, rh * .64, "GOALIE - SOON", "#475569", false, .024); btns.back().dis = true;
  ry += rh + .015 * U; panel(x, ry, w, rh * 1.25, .62); T("DIFFICULTY", x + .03 * U, ry + rh * .35, .03, "#fff");
  static const char *DN[3] = {"CASUAL", "STANDARD", "HARDCORE"}, *DC[3] = {"#16a34a", "#2563eb", "#dc2626"};
  static const char *DD[3] = {"Slower CPU skaters, wider faceoff windows, softer hits.", "The game as it's meant to be played.", "Faster, sharper CPU skaters. Every mistake costs you."};
  for (int i = 0; i < 3; i++) ui("pdiff:" + istr(i), x + w - .9 * U + i * .3 * U, ry + rh * .12, .28 * U, rh * .5, DN[i], pendDiff == i ? DC[i] : "#334155", true, .026);
  T(DD[pendDiff], x + .03 * U, ry + rh * .95, .021, "#94a3b8", AL_LEFT, 700);
  ry += rh * 1.25 + .03 * U; double b2 = .42 * U;
  ui("pgo", W / 2 - b2 - .01 * U, ry, b2, .09 * U, "START CAREER", "#16a34a", true, .036);
  ui("pncancel", W / 2 + .01 * U, ry, b2, .09 * U, "BACK", "#475569", true, .036);
}
// draft night: the picks come in one by one until it's your turn
static void drawDraft() {
  double m = .03 * U, top = safeTop + .13 * U, t = (now() - draftT0) / 1000; int shown = std::min(C.dPick + 1, (int)(t / .11) + 1); bool done = shown > C.dPick;
  scrHead("DRAFT NIGHT", "ROUND 1  |  SEASON " + istr(C.season) + "  |  32 TEAMS, ONE PICK EACH");
  int cols = 4, rows = 8; double gap = .01 * U, cw = (W * .62 - 2 * m - (cols - 1) * gap) / cols, rh = std::min(.052 * U, (H - top - .16 * U) / rows - .005 * U);
  for (int k = 0; k < shown && k < 32; k++) { int c = k / rows, r = k % rows; double x = m + c * (cw + gap), y = top + r * (rh + .005 * U); int tm = C.dOrder[k]; bool me = k == C.dPick;
    panel(x, y, cw, rh, me ? .9 : .62); if (me) { ctx.fill(rgba(255, 213, 74, .25)); ctx.fillRect(x, y, cw, rh); }
    badge(x + rh * .5, y + rh / 2, rh * .36, tm); TF(istr(k + 1) + ". " + (me ? upper(C.nm) : upper(C.dNm[k])), x + rh * 1.0, y + rh / 2, .017, cw - rh * 1.1, me ? "#ffd54a" : "#e2e8f0"); }
  double rx = W * .62 + m * .5, rw = W - rx - m; panel(rx, top, rw, H - top - .14 * U);
  if (!done) { TB("ON THE CLOCK", rx + rw / 2, top + .08 * U, .04, "#fff", AL_CENTER); T("PICK " + istr(shown + 1), rx + rw / 2, top + .14 * U, .03, "#94a3b8", AL_CENTER); }
  else { T("WITH PICK #" + istr(C.dPick + 1) + ", THE", rx + rw / 2, top + .05 * U, .022, "#94a3b8", AL_CENTER, 700);
    TF(upper(teamFull(orgOf(C.me))), rx + rw / 2, top + .1 * U, .036, rw * .92, "#fff", AL_CENTER);
    T("SELECT", rx + rw / 2, top + .15 * U, .022, "#94a3b8", AL_CENTER, 700); TF(upper(C.nm), rx + rw / 2, top + .21 * U, .05, rw * .9, "#ffd54a", AL_CENTER);
    you(rx + rw / 2, top + .49 * U, .05 * U);
    T("FORWARD  |  #" + istr(C.num) + "  |  AGE " + istr(C.age) + "  |  OVR " + istr(proOvr()), rx + rw / 2, top + .53 * U, .019, "#cbd5e1", AL_CENTER, 700);
    if (C.me >= NA) TF("ASSIGNED TO THE " + upper(C.L[C.me].n) + " (AHL)", rx + rw / 2, top + .575 * U, .019, rw * .92, "#ffd54a", AL_CENTER);
    ui("draftdone", (W - .44 * U) / 2, H - .11 * U, .44 * U, .08 * U, "START YOUR CAREER", "#16a34a", true, .034); }
}

// ---------------------------------------------------------------- the hub
[[maybe_unused]] static void drawHub() {
  if (C.showTrade && C.hasTrade) { screen = "trade"; return; }
  bool land = W > H * 1.15; double m = .03 * U; PP *Y = youMe(); PTeam &r = C.L[C.me]; std::string ph = C.phase;
  // top: your card, your season, your wallet
  double ty = safeTop + .012 * U, th = .1 * U, av = th * .9;
  panel(m, ty, av, av, .7); you(m + av / 2, ty + av * .95, av / 6.2);
  double cx = m + av + .02 * U; T("OVR", cx, ty + th * .2, .0204, "#94a3b8", AL_LEFT, 700); TB(istr(proOvr()), cx, ty + th * .6, .05, "#fff");
  cx += .085 * U; TB(upper(C.nm), cx, ty + th * .3, .034, "#fff");
  TF("#" + istr(C.num) + " | C | " + upper(r.n) + (C.me >= NA ? " (AHL)" : "") + " | AGE " + istr(C.age) + " | YEAR " + istr(C.season), cx, ty + th * .68, .0216, (land ? W * .52 - .05 * U : W - .5 * U) - cx, "#cbd5e1");
  int gp, sg, sa; proLine(gp, sg, sa);
  std::pair<std::string, std::string> sl[4] = {{"GP", istr(gp)}, {"G", istr(sg)}, {"A", istr(sa)}, {"PTS", istr(sg + sa)}};
  if (land) for (int k = 0; k < 4; k++) { double xx = W * .52 + k * .075 * U; T(sl[k].first, xx, ty + th * .25, .0198, "#94a3b8", AL_CENTER, 700); TB(sl[k].second, xx, ty + th * .62, .03, "#fff", AL_CENTER); }
  std::pair<std::string, std::string> wl3[3] = {{"XP", fmtN(C.xp)}, {"CASH", "$" + fmtN(C.money)}, {C.me >= NA ? "CALL-UP" : "CUPS", C.me >= NA ? istr(readiness()) + "/" + istr(callBar()) : istr(C.titles)}};
  for (int k = 0; k < 3; k++) { double xx = W - m - (2 - k) * .11 * U - .05 * U; T(wl3[k].first, xx, ty + th * .25, .0198, "#94a3b8", AL_CENTER, 700); TB(wl3[k].second, xx, ty + th * .62, .03, k == 0 ? "#ffd54a" : "#fff", AL_CENTER); }
  double top = ty + th + .02 * U, bot = H - .07 * U;
  double clx = m, clw = W * .25, cmx = m + W * .25 + .02 * U, cmw = W * .47, crx = m + W * .72 + .03 * U, crw = W - crx - m;
  // centre: key art, the headline, the matchup
  double heroH = (bot - top) * .6, hy = top;
  std::string head, tag;
  std::string cupN = C.me >= NA ? "the Calder Cup" : "the Stanley Cup";
  if (ph == "over") { head = C.champ == C.me ? "Champions! The " + r.n + " lift " + cupN : "Season over: the " + C.L[C.champ < 0 ? 0 : C.champ].n + " win " + cupN; tag = "OFF-SEASON"; }
  else { head = headline(); tag = std::string(C.me >= NA ? "AHL " : "NHL ") + (ph == "po" ? "PLAYOFFS  |  " + std::string(RN[std::min(3, C.round)]) : "REGULAR SEASON"); }
  heroArt(cmx, hy, cmw, heroH, hex(teamCol(C.me)), hex(teamStr(C.me)), false, C.season * 31 + C.me);
  { double hfs = std::min(.042 * U, cmw * .055); std::vector<std::string> lines; for (int k = 0; k < 8; k++) { ctx.font(hfs); lines = wrapText(head, cmw * .9); if (lines.size() <= 2) break; hfs *= .9; }
    if (lines.size() > 3) lines.resize(3); double lh = hfs * 1.12, bh = lines.size() * lh + .05 * U; ctx.fill(rgba(8, 12, 24, .55)); ctx.fillRect(cmx, hy + heroH - bh, cmw, bh);
    for (size_t k = 0; k < lines.size(); k++) { ctx.font(hfs); ctx.fill("#fff"); ctx.textMid(AL_LEFT); ctx.fillText(lines[k], cmx + .025 * U, hy + heroH - .052 * U - (lines.size() - 1 - k) * lh); }
    TXL = cmx; TXR = cmx + cmw - .02 * U; T(tag + (ph == "reg" ? "  |  GAME " + istr(std::min(C.day + 1, PRO_GAMES)) + " OF " + istr(PRO_GAMES) + (C.cal.empty() ? "" : "  |  " + calDate(C.ci)) : ""), cmx + .025 * U, hy + heroH - .018 * U, .018, "#cbd5e1", AL_LEFT, 700); TXL = 0; TXR = 1e4; }
  double my = hy + heroH + .012 * U, mh = (bot - my) * .62; panel(cmx, my, cmw, mh, .8);
  if (ph != "over" && ph != "retired") {
    double br = mh * .24; int o = C.opp; PTeam &O = C.L[o];
    badge(cmx + br * 1.4, my + mh * .36, br, C.me); badge(cmx + cmw - br * 1.4, my + mh * .36, br, o);
    double nmW = cmw / 2 - br * 2.7 - .045 * U; TF(upper(r.n), cmx + br * 2.7, my + mh * .3, .03, nmW, "#fff"); T(istr(r.w) + "-" + istr(r.l), cmx + br * 2.7, my + mh * .52, .0204, "#94a3b8", AL_LEFT, 700);
    TF(upper(O.n), cmx + cmw - br * 2.7, my + mh * .3, .03, nmW, "#fff", AL_RIGHT); T(istr(O.w) + "-" + istr(O.l), cmx + cmw - br * 2.7, my + mh * .52, .0204, "#94a3b8", AL_RIGHT, 700);
    TB("VS", cmx + cmw / 2, my + mh * .3, .0228, "#f26b5b", AL_CENTER); T(ph == "po" ? "SERIES " + istr(C.sw) + "-" + istr(C.sl) : "GAME " + istr(C.day + 1), cmx + cmw / 2, my + mh * .52, .0192, "#94a3b8", AL_CENTER, 700);
    // recent results and what's next
    struct Cell { int t; std::string s; const char *c; }; std::vector<Cell> cells; int n0 = 0;
    for (int i = (int)C.hist.size() - 1; i >= 0 && n0 < 2; i--) if (!C.hist[i].po) { n0++; const PHist &h = C.hist[i]; cells.insert(cells.begin(), {h.o, (h.w ? "W " : "L ") + istr(h.hs) + "-" + istr(h.as), h.w ? "#7CFC9A" : "#fca5a5"}); }
    if (ph == "reg") for (int k = 0; k < 5 && C.day + k < (int)C.sched.size(); k++) { int gi = -1; for (size_t i = 0; i < C.cal.size(); i++) if (C.cal[i] == C.day + k) gi = (int)i; cells.push_back({C.sched[C.day + k], gi >= 0 ? calDate(gi) : "G" + istr(C.day + k + 1), k ? "#94a3b8" : "#f26b5b"}); }
    double cw = cmw / std::max<size_t>(7, cells.size()), cy0 = my + mh * .68, rowH = mh * .3; ctx.fill(rgba(255, 255, 255, .05)); ctx.fillRect(cmx, cy0, cmw, rowH);
    for (size_t k = 0; k < cells.size(); k++) { double xx = cmx + cw * (k + .5) + (cmw - cw * cells.size()) / 2; badge(xx - cw * .3, cy0 + rowH / 2, rowH * .28, cells[k].t); TXR = xx + cw * .47; T(cells[k].s, xx - cw * .16, cy0 + rowH / 2 + 1, .0155, cells[k].c, AL_LEFT, 800); TXR = 1e4; }
    pushBtn("nav:sched", cmx, my, cmw, mh, "", true);
  } else {
    TRank rk = teamRank(C.me); std::string run = "MISSED THE PLAYOFFS";
    for (size_t ri = 0; ri < C.br.size(); ri++) { const PSeries *s = nullptr; for (auto &x : C.br[ri]) if (x.a == C.me || x.b == C.me) s = &x; if (!s) break; int opp = s->a == C.me ? s->b : s->a;
      run = s->w == C.me ? (ri == 3 ? (C.me >= NA ? "WON THE CALDER CUP" : "WON THE STANLEY CUP") : "WON THE " + std::string(RN[ri])) : "LOST IN THE " + std::string(RN[ri]) + " TO THE " + upper(C.L[opp].n); }
    badge(cmx + mh * .32, my + mh * .36, mh * .22, C.me);
    TF(upper(r.n) + "   " + istr(r.w) + "-" + istr(r.l), cmx + mh * .62, my + mh * .26, .032, cmw - mh * .7, "#fff");
    TF(upper(ordn(rk.div)) + " IN THE " + divName(C.me) + "  |  " + upper(ordn(rk.all)) + " OVERALL  |  " + run, cmx + mh * .62, my + mh * .48, .017, cmw - mh * .7, run[0] == 'W' ? "#7CFC9A" : "#cbd5e1");
    ctx.fill(rgba(255, 255, 255, .05)); ctx.fillRect(cmx, my + mh * .68, cmw, mh * .3);
    T("YOUR SEASON", cmx + .02 * U, my + mh * .83, .015, "#94a3b8"); TB(istr(sg) + " G   " + istr(sa) + " A   " + istr(sg + sa) + " PTS", cmx + cmw - .02 * U, my + mh * .83, .022, "#ffd54a", AL_RIGHT);
  }
  // left: the menu
  double ly = top; bool off = offDay(), hurt = ph != "over" && userHurt(), need = C.need; int nOff = (int)C.offers.size();
  std::string hd = ph == "over" ? "OFF-SEASON" : need ? "CONTRACT EXPIRED" : off ? "OFF DAY  |  " + calDate(C.ci) : hurt ? "INJURED  |  " + istr(Y->inj) + (Y->inj == 1 ? " GAME LEFT" : " GAMES LEFT") : "UP NEXT" + (ph == "reg" && !C.cal.empty() ? "  |  " + calDate(C.ci) : "");
  T(hd, clx, ly + .012 * U, .0198, off || need || hurt ? "#f26b5b" : "#94a3b8"); ly += .03 * U;
  double ih = std::min(.06 * U, (bot - ly) / 9.7);
  auto big = [&](const std::string &id, const std::string &lb) { menuItem(id, lb, clx, ly, clw, ih * 1.15, true, true); ly += ih * 1.3; };
  std::vector<std::pair<std::string, std::string>> items;
  if (need) big("off:neg", "SIGN YOUR CONTRACT");
  else if (off) { big("skipday", "REST (SKIP DAY)"); items.push_back({"nav:train", "TRAIN  ($" + istr(trainCost()) + ")"}); items.push_back({"sim1", "SIM TO NEXT GAME"}); }
  else if (ph == "over") big("next", "NEXT SEASON");
  else if (hurt) { big("simheal", "SIM UNTIL HEALTHY"); items.push_back({"sim1", "SIM ONE GAME"}); }
  else { big("play", "PLAY NEXT GAME"); items.push_back({"sim1", "SIM GAME"}); items.push_back({"simN", ph == "po" ? "SIM SERIES" : "SIM 10 GAMES"}); }
  items.push_back({"nav:upg", "UPGRADES"}); items.push_back({"nav:office", "OFFICE" + std::string(need ? "  (!)" : nOff ? "  (" + istr(nOff) + (nOff > 1 ? " OFFERS)" : " OFFER)") : C.hasTreq ? "  (TRADE ASKED)" : "")});
  items.push_back({"nav:shop", "GEAR SHOP"}); items.push_back({"nav:sched", "SCHEDULE"}); items.push_back({"nav:stand", "LEAGUE"}); items.push_back({"nav:modes", "MAIN MENU"});
  double ih2 = std::min(ih, (bot - ly - .01 * U) / items.size());
  for (auto &it : items) { menuItem(it.first, it.second, clx, ly, clw, ih2, false, false); ly += ih2; }
  // right: headlines and the weekly goals
  double ry = top, hh = (bot - top) * .46; panel(crx, ry, crw, hh, .6);
  TB("TOP HEADLINES", crx + .012 * U, ry + .022 * U, .0216, "#f26b5b");
  double yy = ry + .05 * U; ctx.font(.0195 * U); int nh = 0;
  { std::string pn = C.me >= NA || (youMe() && youMe()->isCu) ? prospectNote() : ""; if (!pn.empty()) { nh = 1;   // the organization's view of you comes first
      T("FROM THE " + upper(C.L[orgOf(C.me)].n) + " FRONT OFFICE", crx + .012 * U, yy, .014, "#ffd54a", AL_LEFT, 800); yy += .022 * U;
      auto ls = wrapText(pn, crw - .045 * U); if (ls.size() > 3) ls.resize(3); for (auto &l : ls) { T(l, crx + .012 * U, yy, .0165, "#fde68a", AL_LEFT, 700); yy += .022 * U; }
      yy += .012 * U; ctx.fill(rgba(148, 163, 184, .15)); ctx.fillRect(crx + .012 * U, yy - .015 * U, crw - .024 * U, 1); } }
  for (auto &h : C.log) { if (nh++ >= 4 || yy > ry + hh - .05 * U) break; auto ls = wrapText(h.s, crw - .045 * U); if (ls.size() > 2) ls.resize(2);
    for (auto &l : ls) { T(l, crx + .012 * U, yy, .0165, "#e2e8f0", AL_LEFT, 700); yy += .022 * U; } T("Season " + istr(h.y), crx + .012 * U, yy, .014, "#64748b", AL_LEFT, 700); yy += .03 * U;
    ctx.fill(rgba(148, 163, 184, .15)); ctx.fillRect(crx + .012 * U, yy - .015 * U, crw - .024 * U, 1); }
  if (C.log.empty()) T("No news yet.", crx + .012 * U, yy, .0165, "#64748b");
  ry += hh + .012 * U; panel(crx, ry, crw, bot - ry, .6);
  { double x = crx + .012 * U, w = crw - .024 * U, y = ry + .025 * U; TB("WEEKLY GOALS", x, y, .0216, "#f26b5b");
    if (ph == "reg" && C.wk.w >= 0) { y += .026 * U; int left = 7 - (C.ci % 7); T("WEEK " + istr(C.wk.w + 1) + "  |  " + istr(left) + (left == 1 ? " DAY" : " DAYS") + " LEFT", x, y, .014, "#94a3b8", AL_LEFT, 700); }
    y += .032 * U;
    if (ph != "reg" || C.wk.goals.empty()) txWrap(ph == "reg" ? "No games this week." : "Weekly goals return next regular season.", x, y + .01 * U, .016, w, hex("#64748b"), AL_LEFT, 700, 2);
    else for (auto &g : C.wk.goals) { std::string cnt = istr(std::min(g.pr, g.tg)) + " / " + istr(g.tg); const char *c = g.done ? "#7CFC9A" : "#e2e8f0";
      T(cnt, x + w, y, .0175, c, AL_RIGHT, 700); TXL = x; TXR = x + w - .07 * U; T(g.txt, x, y, .016, c, AL_LEFT, 700); TXL = 0; TXR = 1e4;
      ctx.fill(rgba(148, 163, 184, .25)); ctx.fillRect(x, y + .014 * U, w, 3); ctx.fill(c); ctx.fillRect(x, y + .014 * U, w * clamp((double)g.pr / g.tg, 0, 1), 3);
      T("+" + istr(g.xp) + " XP  +$" + istr(g.cash), x + w, y + .03 * U, .0155, "#ffd54a", AL_RIGHT, 700); y += .062 * U; } }
  // the latest result / sim message
  std::string msg = !C.wkMsg.empty() ? C.wkMsg : !C.injMsg.empty() ? C.injMsg : !C.offMsg.empty() && screen == "main" && false ? C.offMsg : proMsg;
  if (!msg.empty()) { double px = std::min(.02 * U, (W - .06 * U) / std::max<size_t>(1, msg.size()) * 1.7); ctx.font(px); double tw = ctx.measure(msg) + .04 * U;
    ctx.fill(rgba(8, 12, 24, .9)); ctx.rr(W / 2 - tw / 2, bot + .006 * U, tw, .036 * U, .018 * U); ctx.fillPath(); ctx.fill("#ffd54a"); ctx.textMid(); ctx.fillText(msg, W / 2, bot + .024 * U); }
  else footHints({{"D-PAD", "MOVE"}, {"X", "SELECT"}, {"O", "MAIN MENU"}, {"START", "PAUSE IN GAME"}});
}

// ---------------------------------------------------------------- upgrades: ratings and perks
static const char *UPK[15] = {"skate", "edge", "deke", "hand", "pass", "sacc", "wpow", "slacc", "spow", "bha", "bhp", "check", "poise", "fstam", "fo"};
static void drawUpg() {
  double m = .03 * U, top = safeTop + .19 * U;
  scrHead("UPGRADES", "SPEND XP ON YOUR RATINGS AND PERKS  |  OVR " + istr(proOvr()) + "  |  L / R: SWITCH TABS"); xpTagTop(); cashTag();
  ui("utab:0", m, safeTop + .115 * U, .24 * U, .055 * U, "RATINGS", upTab == 0 ? "#f26b5b" : "#334155", true, .026); btns.back().np = true;
  ui("utab:1", m + .25 * U, safeTop + .115 * U, .24 * U, .055 * U, "PERKS", upTab == 1 ? "#f26b5b" : "#334155", true, .026); btns.back().np = true;
  if (upTab == 0) {
    int cols = 3, rows = 5; double gap = .012 * U, cw = (W - 2 * m - (cols - 1) * gap) / cols, rh = std::min(.098 * U, (H - top - .13 * U) / rows - .008 * U);
    for (int i = 0; i < 15; i++) { std::string k = UPK[i]; int c = i / rows, r = i % rows; double x = m + c * (cw + gap), y = top + r * (rh + .008 * U); int v = g_stats(k).i(50), gp = (int)gearPts(k);
      panel(x, y, cw, rh, .7); T(FNICE(k), x + .015 * U, y + rh * .25, .019, "#cbd5e1", AL_LEFT, 800);
      TB(istr(v), x + .015 * U, y + rh * .65, .038, v >= 90 ? "#ffd54a" : "#fff"); if (gp) T((gp > 0 ? "+" : "") + istr(gp) + " GEAR", x + .085 * U, y + rh * .67, .014, gp > 0 ? "#7dd3fc" : "#fca5a5", AL_LEFT, 700);
      double pr = 0; auto it = C.sxp.find(k); if (it != C.sxp.end()) pr = it->second; ctx.fill(rgba(148, 163, 184, .25)); ctx.fillRect(x + .015 * U, y + rh * .88, cw * .38, 3); ctx.fill("#ffd54a"); ctx.fillRect(x + .015 * U, y + rh * .88, cw * .38 * clamp(pr, 0, 1), 3);
      int m1, m5, c1 = proCostN(k, 1, &m1), c5 = proCostN(k, 5, &m5); double bw = cw * .26, bh = rh * .6, by = y + rh * .2;
      ui("up1:" + k, x + cw - 2 * bw - .02 * U, by, bw, bh, m1 ? "+1  " + fmtN(c1) : "MAX", "#16a34a", m1 && C.xp >= c1, .018); if (!(m1 && C.xp >= c1)) btns.back().dis = true;
      ui("up5:" + k, x + cw - bw - .01 * U, by, bw, bh, m5 ? "+" + istr(m5) + "  " + fmtN(c5) : "MAX", "#2563eb", m5 && C.xp >= c5, .018); if (!(m5 && C.xp >= c5)) btns.back().dis = true; }
    T("Ratings also grow on their own as you play: shoot to build your shot, hit to build checking, skate to build speed.", W / 2, H - .1 * U, .016, "#94a3b8", AL_CENTER, 700);
  } else {
    int n = pkSlots(proOvr()); std::vector<int> ids; for (int i = 0; i < PK_N; i++) if (PERKS[i].pos == 'F' && !PERKS[i].user) ids.push_back(i);
    std::string eq; for (auto &e : C.perkEq) { int i = perkIndex(e); if (i >= 0) eq += (eq.empty() ? "" : ", ") + std::string(PERKS[i].n); }
    T("PERK SLOTS: " + istr(n) + "   (1 SLOT AT 78 OVR, 2 AT 89)   |   EQUIPPED: " + (eq.empty() ? "NONE" : eq), m, top - .01 * U, .017, "#cbd5e1", AL_LEFT, 700);
    double rh = std::min(.072 * U, (H - top - .13 * U) / ids.size() - .006 * U);
    for (size_t j = 0; j < ids.size(); j++) { const PerkDef &P = PERKS[ids[j]]; std::string id = P.id; double y = top + .015 * U + j * (rh + .006 * U);
      bool own = std::find(C.perkOwn.begin(), C.perkOwn.end(), id) != C.perkOwn.end(), on = std::find(C.perkEq.begin(), C.perkEq.end(), id) != C.perkEq.end();
      int tier = proUserTier(P), lv = own ? std::max(1, C.perkLv[id]) : 0, myT = own ? pkMine(id) : 0;
      panel(m, y, W - 2 * m, rh, on ? .85 : .66); if (on) { ctx.fill(rgba(56, 189, 248, .16)); ctx.fillRect(m, y, W - 2 * m, rh); }
      ctx.fill(TIERC[myT]); ctx.disc(m + rh * .5, y + rh / 2, rh * .34); ctx.fill(P.col); ctx.disc(m + rh * .5, y + rh / 2, rh * .27); ctx.fill("#fff"); ctx.font(rh * .24); ctx.textMid(); ctx.fillText(P.ab, m + rh * .5, y + rh / 2 + 1);
      TB(P.n, m + rh, y + rh * .3, .021, "#fff"); TXR = W * .62;
      T(std::string(FNICE(P.k)) + " " + istr(P.rq[0]) + " / " + istr(P.rq[1]) + " / " + istr(P.rq[2]) + " FOR BRONZE / SILVER / GOLD  |  YOU: " + istr(userRatings().get(P.k)) + (own ? "  |  OWNED: " + std::string(TIERN[std::max(1, myT)]) + (lv > myT && myT ? "" : "") : ""), m + rh, y + rh * .7, .0145, tier ? "#94a3b8" : "#fca5a5", AL_LEFT, 700); TXR = 1e4;
      double bw = .2 * U, bh = rh * .62, bx = W - m - .015 * U - bw, by = y + (rh - bh) / 2;
      if (!own) { bool ok = C.xp >= P.c; ui("pbuy:" + id, bx, by, bw, bh, "BUY  " + fmtN(P.c) + " XP", "#16a34a", ok, .018); if (!ok) btns.back().dis = true; }
      else { int nx = lv + 1, c = pkUpCost(P, nx); bool ok = nx <= 3 && C.xp >= c && tier >= nx;
        ui("pup:" + id, bx - bw - .01 * U, by, bw, bh, nx > 3 ? "GOLD" : "TO " + std::string(TIERN[nx]) + "  " + fmtN(c), "#d97706", ok, .017); if (!ok) btns.back().dis = true;
        bool eok = on || (n > 0 && tier > 0); ui("peq:" + id, bx, by, bw, bh, on ? "UNEQUIP" : n ? "EQUIP" : "NEED 78 OVR", on ? "#0891b2" : "#2563eb", eok, .018); if (!eok) btns.back().dis = true; } }
    (void)perkSel;
  }
  back("nav:main", H - .085 * U);
}
static void drawTrain() {
  double m = .03 * U, top = safeTop + .14 * U; bool can = canTrain(); int c = trainCost();
  scrHead("TRAINING", can ? "OFF DAY  |  ONE SESSION A DAY  |  $" + istr(c) + " A SESSION" : "TRAINING IS FOR OFF DAYS"); cashTag();
  static const char *TN[4] = {"SKATING", "SHOOTING", "PLAYMAKING", "PHYSICAL"};
  static const char *TK[4][4] = {{"skate", "edge", nullptr, nullptr}, {"sacc", "wpow", "slacc", "spow"}, {"pass", "hand", "deke", "fo"}, {"check", "poise", "fstam", nullptr}};
  double gw = (W - 2 * m - .036 * U) / 4, gh = .34 * U;
  for (int i = 0; i < 4; i++) { double x = m + i * (gw + .012 * U); panel(x, top, gw, gh); ctx.fill("#f26b5b"); ctx.fillRect(x, top, gw, 4);
    TB(TN[i], x + gw / 2, top + .05 * U, .03, "#fff", AL_CENTER); double y = top + .1 * U;
    for (int k = 0; k < 4 && TK[i][k]; k++) { T(FNICE(TK[i][k]), x + .02 * U, y, .017, "#cbd5e1", AL_LEFT, 700); T(istr(g_stats(TK[i][k]).i(50)), x + gw - .02 * U, y, .02, "#fff", AL_RIGHT, 900); y += .035 * U; }
    bool ok = can && C.money >= c; ui("train:" + istr(i), x + .015 * U, top + gh - .075 * U, gw - .03 * U, .06 * U, "TRAIN  $" + istr(c), "#16a34a", ok, .024); if (!ok) btns.back().dis = true; }
  txWrap("A session pushes every rating in the group toward its next point. Training uses up the off day.", W / 2, top + gh + .05 * U, .018, W - 2 * m, hex("#94a3b8"), AL_CENTER, 700, 2);
  back("nav:main", H - .11 * U);
}
static void drawShop() {
  double m = .03 * U; shopCat = std::max(0, std::min(shopCat, (int)GEARF.size() - 1));
  scrHead("GEAR SHOP", "STICKS, HELMETS AND SKATES  |  EVERYTHING COSTS CASH  |  L / R: CATEGORY"); cashTag();
  double ty = safeTop + .12 * U, tw = (W - 2 * m - .012 * U * (GEARF.size() - 1)) / GEARF.size();
  for (size_t i = 0; i < GEARF.size(); i++) { ui("gcat:" + istr(i), m + i * (tw + .012 * U), ty, tw, .055 * U, GEARF[i].n, shopCat == (int)i ? "#f26b5b" : "#334155", true, .024); btns.back().np = true; }
  const GearCat &cat = GEARF[shopCat]; double y0 = ty + .08 * U, rh = std::min(.1 * U, (H - y0 - .3 * U) / cat.it.size() - .01 * U);
  int eqI = -1; { auto it = C.gearEq.find(cat.k); if (it != C.gearEq.end()) eqI = it->second; else for (size_t i = 0; i < cat.it.size(); i++) if (!cat.it[i].c) { eqI = (int)i; break; } }
  for (size_t i = 0; i < cat.it.size(); i++) { const GearIt &it = cat.it[i]; double y = y0 + i * (rh + .01 * U); bool eq = eqI == (int)i, own = !it.c || C.gearOwn.count(std::string(cat.k) + ":" + istr(i));
    panel(m, y, W - 2 * m, rh); if (eq) { ctx.fill(rgba(56, 189, 248, .16)); ctx.fillRect(m, y, W - 2 * m, rh); ctx.fill("#38bdf8"); ctx.fillRect(m, y, 4, rh); }
    TB(it.n, m + .03 * U, y + rh * .3, .028, "#fff"); T(it.d, m + .03 * U, y + rh * .62, .016, "#cbd5e1", AL_LEFT, 700);
    std::string fx = fxTxt(it.fx); if (it.inj != 1) fx += std::string(fx.empty() ? "" : "   ") + (it.inj < 1 ? "-" : "+") + istr((int)jround(std::fabs(1 - it.inj) * 100)) + "% INJURY RISK";
    TF(fx.empty() ? "NO RATING CHANGES" : fx, m + .03 * U, y + rh * .86, .0155, W * .6, fx.empty() ? "#64748b" : "#7dd3fc");
    double bw = .26 * U, bh = rh * .56, bx = W - m - bw - .02 * U, by = y + (rh - bh) / 2;
    if (eq) TB("EQUIPPED", bx + bw / 2, y + rh / 2, .026, "#38bdf8", AL_CENTER);
    else { bool ok = own || C.money >= it.c; ui("gear:" + std::string(cat.k) + ":" + istr(i), bx, by, bw, bh, own ? "EQUIP" : "BUY  $" + fmtN(it.c), own ? "#2563eb" : "#16a34a", ok, .026); if (!ok) btns.back().dis = true; } }
  double py = y0 + cat.it.size() * (rh + .01 * U) + .015 * U, ph = std::min(.15 * U, H - .13 * U - py);
  if (ph > .08 * U) { panel(m, py, W - 2 * m, ph, .6); T("WHAT YOU ARE WEARING", m + .02 * U, py + .025 * U, .016, "#f26b5b");
    double cw = (W - 2 * m - .04 * U) / GEARF.size();
    for (size_t i = 0; i < GEARF.size(); i++) { const GearCat &g = GEARF[i]; int e = 0; auto it = C.gearEq.find(g.k); if (it != C.gearEq.end()) e = it->second; else for (size_t j = 0; j < g.it.size(); j++) if (!g.it[j].c) { e = (int)j; break; }
      T(g.n, m + .02 * U + i * cw, py + .06 * U, .014, "#94a3b8", AL_LEFT, 700); TB(g.it[e].n, m + .02 * U + i * cw, py + .088 * U, .022, "#fff"); }
    std::string tot; for (auto k : FKEYS) { int v = (int)gearPts(k); if (v) tot += (tot.empty() ? "" : "   ") + std::string(v > 0 ? "+" : "") + istr(v) + " " + FNICE(k); }
    TF("TOTAL:  " + (tot.empty() ? std::string("NO RATING CHANGES") : tot) + (gearInj() != 1 ? "   INJURY RISK x" + fixed(gearInj(), 2) : ""), m + .02 * U, py + ph - .025 * U, .016, W - 2 * m - .04 * U, "#ffd54a"); }
  back("nav:main", H - .1 * U);
}

// ---------------------------------------------------------------- the office
static void drawOffice() {
  PP *Y = youMe(); double m = .03 * U, top = safeTop + .115 * U, bot = H - .075 * U, cap = capOf(), pay = payroll(orgOf(C.me)); PTeam &L = C.L[orgOf(C.me)];
  scrHead("OFFICE", "GENERAL MANAGER  |  " + upper(L.city + " " + L.n) + (C.need ? "  |  YOUR CONTRACT HAS EXPIRED" : "")); cashTag();
  double lw = W * .34, lx = m; panel(lx, top, lw, bot - top); ctx.fill("#f26b5b"); ctx.fillRect(lx, top, 4, bot - top);
  double y = top + .045 * U; badge(lx + .05 * U, y, .03 * U, orgOf(C.me)); T(C.me >= NA ? "YOUR CONTRACT  |  TWO-WAY" : "YOUR CONTRACT", lx + .095 * U, y - .014 * U, .016, "#94a3b8", AL_LEFT, 700); TF(upper(L.n), lx + .095 * U, y + .016 * U, .03, lw - .12 * U, "#fff");
  y += .07 * U;
  auto row = [&](const std::string &k, const std::string &v, const char *c) { T(k, lx + .025 * U, y, .017, "#94a3b8", AL_LEFT, 700); TF(v, lx + lw - .025 * U, y, .023, lw * .55, c, AL_RIGHT); ctx.fill(rgba(148, 163, 184, .15)); ctx.fillRect(lx + .025 * U, y + .021 * U, lw - .05 * U, 1); y += .047 * U; };
  row("SALARY", money2(Y->sal) + " / YR", "#fff");
  row("YEARS LEFT", C.need ? "EXPIRED" : istr(Y->cy) + (Y->cy == 1 ? "  (FINAL YEAR)" : ""), C.need || Y->cy <= 1 ? "#fca5a5" : "#fff");
  row("NO-TRADE CLAUSE", C.ntc ? "YES" : "NO", C.ntc ? "#7CFC9A" : "#cbd5e1");
  if (Y->hasExt) row("NEXT CONTRACT", istr(Y->extYrs) + " x " + money2(Y->extSal) + (Y->extNtc ? " + NTC" : ""), "#7CFC9A");
  row("GAME PAY", "$" + istr(gamePay()) + " PER GAME", "#ffd54a");
  row("MARKET VALUE", money2(market(proOvr())), "#fff");
  row("TEAM PAYROLL", "$" + fixed(pay, 1) + "M / $" + fixed(cap, 1) + "M", pay > cap ? "#fca5a5" : "#7CFC9A");
  y += .012 * U; meter(lx + .025 * U, y, lw - .05 * U, perfScore(), "#38bdf8", "PERFORMANCE"); y += .05 * U; meter(lx + .025 * U, y, lw - .05 * U, loyalty(), "#f59e0b", "LOYALTY");
  y += .06 * U; T("BIGGEST CONTRACTS", lx + .025 * U, y, .016, "#f26b5b"); y += .03 * U;
  std::vector<PP *> big; for (auto &q : C.P) if ((q->t == orgOf(C.me) || q->me) && !q->isCu) big.push_back(q.get()); std::sort(big.begin(), big.end(), [](PP *a, PP *b) { return a->sal > b->sal; });
  for (PP *q : big) { if (y > bot - .02 * U) break; TF(q->nm() + (q->g ? " (G)" : ""), lx + .025 * U, y, .016, lw * .55, q->me ? "#ffd54a" : "#e2e8f0"); T("$" + fixed(q->sal, 1) + "M  " + istr(q->cy) + "Y", lx + lw - .025 * U, y, .016, "#7CFC9A", AL_RIGHT); y += .029 * U; }
  double mx = lx + lw + .03 * U, mw = W * .29, my = top; T("ACTIONS", mx, my + .012 * U, .017, "#f26b5b"); my += .04 * U;
  double ih = .064 * U; bool canExt = !C.need && C.phase != "over" && C.phase != "retired" && Y->cy <= 1 && !Y->hasExt; int n = (int)C.offers.size();
  struct Act { std::string id, lb; bool on; } act[5] = {{"off:neg", C.need ? "SIGN NEW CONTRACT" : "NEGOTIATE EXTENSION", C.need || canExt}, {"nav:ntc", C.ntc ? "NO-TRADE CLAUSE: YES" : "REQUEST NO-TRADE CLAUSE", !C.ntc && C.ntcTry != C.season && !C.need},
    {"nav:treq", C.hasTreq ? "TRADE REQUESTED" : "REQUEST A TRADE", tradeOpen() && !C.hasTreq && !C.need}, {"nav:toff", "TRADE OFFERS" + (n ? "  (" + istr(n) + ")" : std::string()), true}, {"nav:main", "BACK", true}};
  for (int k = 0; k < 5; k++) { menuItem(act[k].id, act[k].lb, mx, my, mw, ih, false, k == 0 && C.need); if (!act[k].on) dimOut(mx, my, mw, ih); my += ih * 1.14; }
  my += .01 * U; txWrap(C.need ? "You cannot play until you sign - or walk away into free agency." : !canExt ? "Extensions open in the final year of your deal." : "Sign now and the new deal starts next season.", mx, my + .02 * U, .016, mw, hex("#94a3b8"), AL_LEFT, 700, 3);
  double rx = mx + mw + .03 * U, rw = W - rx - m; panel(rx, top, rw, bot - top);
  double ry = top + .035 * U; TB("INBOX", rx + .02 * U, ry, .022, "#f26b5b"); ry += .045 * U;
  auto note = [&](const std::string &t, const char *c) { if (ry > bot - .03 * U) return; ctx.font(fsz(.0165) * U); for (auto &l : wrapText(t, rw - .04 * U)) { if (ry > bot - .02 * U) return; T(l, rx + .02 * U, ry, .0165, c, AL_LEFT, 700); ry += .025 * U; } ry += .014 * U; };
  if (!C.offMsg.empty()) note(C.offMsg, "#ffd54a");
  { std::string pn = prospectNote(); if (!pn.empty()) note("PROSPECT REPORT: " + pn, "#fde68a"); }
  if (C.need) note("Your contract is up and the " + L.n + " want to talk. Sign here before your next game - or walk away and test free agency.", "#fca5a5");
  if (C.hasTreq) { std::string l; for (int t : C.treqT) l += C.L[t].ab + " "; note("TRADE REQUEST: you move in " + istr(std::max(0, C.treqAt - C.ci)) + " day(s). Your list: " + l, "#e2e8f0"); }
  if (n) note(istr(n) + (n > 1 ? " teams want" : " team wants") + " you. Open TRADE OFFERS to answer.", "#7CFC9A");
  note(C.phase == "reg" ? (tradeOpen() ? "Trade deadline: game " + istr(PRO_DEADLINE) + " (" + istr(PRO_DEADLINE - C.day) + " games away)." : "The trade deadline has passed. Requests carry over to the summer.") : "Trades reopen next season.", "#94a3b8");
  note(C.ntc ? "Your no-trade clause means no team can move you without your OK." : "Without a no-trade clause the team can trade you at any time.", "#94a3b8");
  footHints(PADH);
}
static void drawNeg() {
  if (!C.hasNeg) negStart(C.need);
  PNeg &N = C.neg; double m = .03 * U, top = safeTop + .115 * U, bot = H - .17 * U, s = negSal(); bool ok = ntcChance(false) >= .5; PTeam &L = C.L[orgOf(C.me)];
  scrHead(N.forced ? "NEW CONTRACT" : "CONTRACT EXTENSION", upper(L.n) + "  |  " + (N.forced ? "YOUR OLD DEAL IS DONE" : "THE NEW DEAL STARTS NEXT SEASON")); cashTag();
  double lw = W * .56, lx = m; panel(lx, top, lw, bot - top); ctx.fill("#16a34a"); ctx.fillRect(lx, top, 4, bot - top);
  double y = top + .04 * U; T(N.fin ? "THEIR FINAL OFFER" : "THEIR OFFER", lx + .03 * U, y, .018, N.fin ? "#fca5a5" : "#94a3b8");
  y += .075 * U; std::string sv = money2(s); TB(sv, lx + .03 * U, y, .08, "#fff"); ctx.font(fsz(.08) * U); double sw = ctx.measure(sv);
  T("PER SEASON", lx + .05 * U + sw, y - .012 * U, .018, "#94a3b8", AL_LEFT, 700); T("$" + fixed(s * N.yrs, 1) + "M TOTAL", lx + .05 * U + sw, y + .016 * U, .02, "#ffd54a");
  y += .075 * U; T("TERM", lx + .03 * U, y, .018, "#94a3b8", AL_LEFT, 700); double bx = lx + .13 * U, bw = .07 * U, bh = .06 * U;
  ui("neg:y-", bx, y - bh / 2, bw, bh, "<", "#334155", N.yrs > 1, .035); TB(istr(N.yrs) + (N.yrs > 1 ? " YEARS" : " YEAR"), bx + bw + .11 * U, y, .034, "#fff", AL_CENTER); ui("neg:y+", bx + bw + .22 * U, y - bh / 2, bw, bh, ">", "#334155", N.yrs < 5, .035);
  y += .085 * U; ui("neg:ntc", lx + .03 * U, y - bh / 2, .36 * U, bh, N.ntc ? "NO-TRADE CLAUSE: ASKING" : "NO-TRADE CLAUSE: NO", "#0891b2", true, .023);
  txWrap(N.ntc ? (ok ? "They will agree to it - it costs you 6% of the salary." : "They will refuse it. You can still sign without one.") : (ok ? "They would agree to a no-trade clause." : "They would not give you a no-trade clause right now."), lx + .42 * U, y, .016, lw - .45 * U, hex(N.ntc ? (ok ? "#7CFC9A" : "#fca5a5") : "#94a3b8"), AL_LEFT, 700, 2);
  y += .075 * U; txWrap(std::string(C.age <= 26 ? "Young players get a little more per year on longer deals. " : C.age >= 32 ? "At your age, longer deals pay less per year. " : "") + "Ask for more and they might come up - or lose patience.", lx + .03 * U, y, .016, lw - .06 * U, hex("#94a3b8"), AL_LEFT, 700, 2);
  double rx = lx + lw + .025 * U, rw = W - rx - m; panel(rx, top, rw, bot - top);
  double ry = top + .04 * U; T("YOUR VALUE", rx + .02 * U, ry, .018, "#94a3b8"); ry += .045 * U;
  TB(money2(market(proOvr())), rx + .02 * U, ry, .045, "#fff"); TB("OVR " + istr(proOvr()), rx + rw - .02 * U, ry, .026, "#ffd54a", AL_RIGHT); ry += .055 * U;
  meter(rx + .02 * U, ry, rw - .04 * U, perfScore(), "#38bdf8", "PERFORMANCE"); ry += .05 * U; meter(rx + .02 * U, ry, rw - .04 * U, loyalty(), "#f59e0b", "LOYALTY"); ry += .06 * U;
  T("THEIR PATIENCE", rx + .02 * U, ry, .016, "#94a3b8", AL_LEFT, 700); for (int k = 0; k < 3; k++) { ctx.fill(k < N.pat ? hex("#f59e0b") : rgba(148, 163, 184, .25)); ctx.fillRect(rx + rw - .02 * U - (3 - k) * .035 * U, ry - .008 * U, .028 * U, .016 * U); }
  ry += .045 * U; if (!N.msg.empty()) { T(N.msg, rx + .02 * U, ry, .018, "#ffd54a"); ry += .035 * U; }
  ry += .01 * U; T("COMPARABLE CONTRACTS", rx + .02 * U, ry, .016, "#f26b5b"); ry += .03 * U;
  int me = proOvr(); std::vector<PP *> pool; for (auto &q : C.P) if (!q->me && !q->g && q->t >= 0 && !q->isCu && q->cy > 0) pool.push_back(q.get());
  std::sort(pool.begin(), pool.end(), [me](PP *a, PP *b) { int da = std::abs(ovQ(a) - me), db = std::abs(ovQ(b) - me); return da != db ? da < db : a->sal > b->sal; });
  for (size_t i = 0; i < pool.size() && i < 8 && ry < bot - .02 * U; i++) { PP *q = pool[i]; TF(q->nm() + "  " + C.L[q->t].ab + "  OVR " + istr(ovQ(q)), rx + .02 * U, ry, .016, rw * .62, "#e2e8f0"); T(money2(q->sal), rx + rw - .02 * U, ry, .016, "#7CFC9A", AL_RIGHT); ry += .029 * U; }
  double by = bot + .025 * U, gw = (W - 2 * m - .04 * U) / 3, gh = .075 * U;
  ui("neg:ok", m, by, gw, gh, "SIGN IT", "#16a34a", true, .032);
  ui("neg:push", m + gw + .02 * U, by, gw, gh, "ASK FOR MORE", "#d97706", N.pat > 0, .032); if (N.pat <= 0) btns.back().dis = true;
  if (N.forced) ui("neg:walk", m + 2 * (gw + .02 * U), by, gw, gh, N.sure ? "SURE? GO TO FREE AGENCY" : "WALK AWAY", "#dc2626", true, N.sure ? .022 : .032);
  else ui("neg:walk", m + 2 * (gw + .02 * U), by, gw, gh, "BACK", "#475569", true, .032);
}
static void drawNtc() {
  double m = .03 * U, cw = std::min(W - 2 * m, .95 * U), cx = (W - cw) / 2, top = safeTop + .16 * U, ch = .5 * U;
  scrHead("NO-TRADE CLAUSE", "OFFICE  |  ONE ASK PER SEASON"); cashTag();
  panel(cx, top, cw, ch); ctx.fill("#f26b5b"); ctx.fillRect(cx, top, 4, ch);
  double y = top + .05 * U; TB("Ask the " + C.L[orgOf(C.me)].n + " for a no-trade clause", cx + .03 * U, y, .028, "#fff"); y += .06 * U;
  txWrap("They decide on how you are playing and how much you seem to want to stay. A pay cut shows you mean it. If they say no, you can ask again next season.", cx + .03 * U, y + .02 * U, .018, cw - .06 * U, hex("#cbd5e1"), AL_LEFT, 700, 3); y += .1 * U;
  meter(cx + .03 * U, y, cw / 2 - .05 * U, perfScore(), "#38bdf8", "PERFORMANCE"); meter(cx + cw / 2 + .02 * U, y, cw / 2 - .05 * U, loyalty(), "#f59e0b", "LOYALTY");
  y += .06 * U; double c0 = ntcChance(false), c1 = ntcChance(true), bw = (cw - .08 * U) / 2, bh = .085 * U; PP *Y = youMe();
  ui("ntc:0", cx + .03 * U, y, bw, bh, "JUST ASK  (" + istr((int)jround(c0 * 100)) + "%)", "#0891b2", true, .026);
  ui("ntc:1", cx + .05 * U + bw, y, bw, bh, "TAKE 10% LESS  (" + istr((int)jround(c1 * 100)) + "%)", "#16a34a", true, .026);
  T("Pay cut: " + money2(Y->sal) + "  ->  " + money2(Y->sal * .9), cx + .05 * U + bw * 1.5, y + bh + .025 * U, .016, "#94a3b8", AL_CENTER, 700);
  back("nav:office", top + ch + .03 * U);
}
static void drawTreq() {
  double m = .03 * U, top = safeTop + .13 * U, gap = .012 * U, cw = (W - 2 * m - 3 * gap) / 4, rh = std::min(.052 * U, (H - top - .14 * U) / 8 - .006 * U);
  scrHead("REQUEST A TRADE", "PICK UP TO 10 TEAMS  |  " + istr(tqSel.size()) + " / 10 PICKED  |  ONE OF THEM GETS YOU IN 7 DAYS" + std::string(C.me >= NA ? "  |  YOU REPORT TO THEIR AHL CLUB" : "")); cashTag();
  PP *Y = youMe();
  for (int d = 0; d < 4; d++) { double x = m + d * (cw + gap); T(DIVN[d], x + 4, top - .016 * U, .015, "#94a3b8"); std::vector<int> ids; for (int i = 0; i < 32; i++) if (C.L[i].d == d) ids.push_back(i);
    std::vector<int> o = standOrd(ids);
    for (size_t k = 0; k < o.size(); k++) { int t = o[k]; double y = top + k * (rh + .006 * U); bool sel = std::find(tqSel.begin(), tqSel.end(), t) != tqSel.end(), me = t == orgOf(C.me); double room = capOf() - payroll(t);
      ctx.fill(sel ? rgba(242, 107, 91, .38) : rgba(15, 23, 42, .74)); ctx.fillRect(x, y, cw, rh); if (sel) { ctx.fill("#f26b5b"); ctx.fillRect(x, y, 4, rh); }
      badge(x + rh * .55, y + rh / 2, rh * .36, t); TF(upper(C.L[t].n), x + rh * 1.05, y + rh * .34, .019, cw - rh * 1.2 - .02 * U, me ? "#64748b" : "#fff");
      T(istr(C.L[t].w) + "-" + istr(C.L[t].l) + "   " + (room >= .05 ? "CAP ROOM $" + fixed(room, 1) + "M" : room > -.05 ? "AT THE CAP" : "$" + fixed(-room, 1) + "M OVER"), x + rh * 1.05, y + rh * .74, .0135, room >= Y->sal ? "#7CFC9A" : "#94a3b8", AL_LEFT, 700);
      if (!me) pushBtn("tq:" + istr(t), x, y, cw, rh, C.L[t].n); } }
  double by = top + 8 * (rh + .006 * U) + .02 * U, bw = .3 * U, bh = .07 * U;
  ui("tq:go", m, by, bw, bh, "SUBMIT REQUEST", "#16a34a", !tqSel.empty(), .028); if (tqSel.empty()) btns.back().dis = true;
  ui("tq:clr", m + bw + .02 * U, by, .2 * U, bh, "CLEAR", "#334155", !tqSel.empty(), .028);
  ui("nav:office", W - m - .25 * U, by, .25 * U, bh, "BACK", "#475569", true, .028);
  txWrap("Asking out hurts your loyalty. Teams have to send back players so both payrolls stay under the cap.", m + bw + .24 * U, by + bh / 2, .015, W - m - .27 * U - (m + bw + .24 * U), hex("#94a3b8"), AL_LEFT, 700, 2);
}
static void drawOffers() {
  double m = .03 * U, top = safeTop + .13 * U;
  scrHead("TRADE OFFERS", C.ntc ? "YOUR NO-TRADE CLAUSE GIVES YOU THE FINAL SAY" : "NO NO-TRADE CLAUSE: OFFERS ARE DECIDED WITHOUT YOU"); cashTag();
  if (C.offers.empty()) { panel(m, top, W - 2 * m, .2 * U); TB("No offers right now.", W / 2, top + .07 * U, .034, "#fff", AL_CENTER);
    T(C.ntc ? "When a team calls about you, the offer lands here and you can accept or reject it." : "Get a no-trade clause in the Office to have a say when teams call.", W / 2, top + .13 * U, .018, "#94a3b8", AL_CENTER, 700); }
  double ch = .15 * U;
  for (size_t i = 0; i < C.offers.size() && i < 3; i++) { const POffer &o = C.offers[i]; double y = top + i * (ch + .015 * U); panel(m, y, W - 2 * m, ch); ctx.fill("#0891b2"); ctx.fillRect(m, y, 4, ch);
    badge(m + .055 * U, y + ch / 2, .034 * U, o.t); TB("THE " + upper(C.L[o.t].n) + " WANT YOU", m + .105 * U, y + .035 * U, .026, "#fff");
    std::string rt; for (auto &n : o.ret) rt += (rt.empty() ? "" : ", ") + n; TF("YOUR TEAM GETS: " + rt, m + .105 * U, y + .075 * U, .017, W * .5, "#cbd5e1");
    T(istr(C.L[o.t].w) + "-" + istr(C.L[o.t].l) + "  |  " + divName(o.t) + "  |  EXPIRES IN " + istr(std::max(0, o.exp - C.ci)) + " DAYS", m + .105 * U, y + .11 * U, .015, "#94a3b8", AL_LEFT, 700);
    double bw = .2 * U, bh = .06 * U; ui("tof:a:" + istr(i), W - m - 2 * bw - .035 * U, y + (ch - bh) / 2, bw, bh, "ACCEPT", "#16a34a", tradeOpen(), .026); if (!tradeOpen()) btns.back().dis = true;
    ui("tof:r:" + istr(i), W - m - bw - .015 * U, y + (ch - bh) / 2, bw, bh, "REJECT", "#dc2626", true, .026); }
  back("nav:office", H - .12 * U);
}
static void drawTradeAlert() {
  if (!C.hasTrade) { screen = "main"; return; }
  const PTrade &tr = C.trade; double m = .03 * U, cw = std::min(W - 2 * m, 1.3 * U), cx = (W - cw) / 2, top = safeTop + .05 * U;
  TB(tr.title.empty() ? "TRADE ALERT" : tr.title, W / 2, top + .04 * U, .07, "#fff", AL_CENTER);
  double ch = .36 * U, y = top + .1 * U; panel(cx, y, cw, ch); ctx.fill("#f26b5b"); ctx.fillRect(cx, y, cw, 4);
  double r = .07 * U; if (tr.title != "FREE AGENCY") { badge(cx + cw * .22, y + .12 * U, r, tr.from); T(upper(C.L[tr.from].n), cx + cw * .22, y + .22 * U, .022, "#94a3b8", AL_CENTER); TB("->", W / 2, y + .12 * U, .05, "#f26b5b", AL_CENTER); }
  badge(cx + cw * (tr.title != "FREE AGENCY" ? .78 : .5), y + .12 * U, r, tr.to); T(upper(C.L[tr.to].n), cx + cw * (tr.title != "FREE AGENCY" ? .78 : .5), y + .22 * U, .022, "#fff", AL_CENTER);
  txWrap(tr.why, W / 2, y + .27 * U, .019, cw - .06 * U, hex("#cbd5e1"), AL_CENTER, 700, 3);
  if (!tr.ret.empty()) { std::string rt; for (auto &n : tr.ret) rt += (rt.empty() ? "" : ", ") + n; TF("GOING THE OTHER WAY: " + rt, W / 2, y + ch - .03 * U, .017, cw - .06 * U, "#94a3b8", AL_CENTER); }
  y += ch + .03 * U; PTeam &L = C.L[tr.to];
  T("YOUR NEW TEAM: " + istr(L.w) + "-" + istr(L.l) + "  |  " + divName(tr.to) + (tr.to >= NA ? "  |  AHL AFFILIATE OF THE " + upper(C.L[orgOf(tr.to)].n) : "  |  NHL  |  PAYROLL $" + fixed(payroll(tr.to), 1) + "M"), W / 2, y, .02, "#e2e8f0", AL_CENTER, 700);
  ui("ptradeok", (W - .44 * U) / 2, H - .13 * U, .44 * U, .08 * U, "CONTINUE", "#16a34a", true, .034);
}

// ---------------------------------------------------------------- schedule and the league
static void drawSched() {
  double m = .03 * U, top = safeTop + .14 * U; PTeam &r = C.L[C.me];
  scrHead("SCHEDULE", upper(r.n) + "  |  " + istr(r.w) + "-" + istr(r.l) + "  |  80 GAMES  |  L / R: PAGE");
  int per = 20, pages = (PRO_GAMES + per - 1) / per; if (schedPg < 0) schedPg = std::min(pages - 1, C.day / per); schedPg = std::max(0, std::min(pages - 1, schedPg));
  std::map<int, const PHist *> res; for (auto &h : C.hist) if (!h.po) res[h.d] = &h;
  double cw = (W - 2 * m - .02 * U) / 2, rh = std::min(.042 * U, (H - top - .13 * U) / 10 - .004 * U);
  for (int k = 0; k < per; k++) { int d = schedPg * per + k; if (d >= (int)C.sched.size()) break; int c = k / 10, rr = k % 10; double x = m + c * (cw + .02 * U), y = top + rr * (rh + .004 * U); int o = C.sched[d];
    panel(x, y, cw, rh, d == C.day && C.phase == "reg" ? .9 : .62); if (d == C.day && C.phase == "reg") { ctx.fill("#f26b5b"); ctx.fillRect(x, y, 4, rh); }
    int gi = -1; for (size_t i = 0; i < C.cal.size(); i++) if (C.cal[i] == d) gi = (int)i;
    T("G" + istr(d + 1), x + .015 * U, y + rh / 2, .016, "#64748b"); T(gi >= 0 ? calDate(gi) : "", x + .07 * U, y + rh / 2, .016, "#94a3b8", AL_LEFT, 700);
    badge(x + .17 * U, y + rh / 2, rh * .36, o); TF(upper(C.L[o].n), x + .2 * U, y + rh / 2, .018, cw * .4, "#fff");
    auto it = res.find(d); if (it != res.end()) { const PHist &h = *it->second; T((h.w ? "W " : "L ") + istr(h.hs) + "-" + istr(h.as) + (h.ln && !h.dnp ? "   " + istr(h.g) + "G " + istr(h.a) + "A" : h.dnp ? "   DNP" : ""), x + cw - .015 * U, y + rh / 2, .017, h.w ? "#7CFC9A" : "#fca5a5", AL_RIGHT); }
    else T(d == C.day && C.phase == "reg" ? "NEXT" : "", x + cw - .015 * U, y + rh / 2, .017, "#f26b5b", AL_RIGHT); }
  T("PAGE " + istr(schedPg + 1) + " / " + istr(pages), W / 2, top + 10 * (rh + .004 * U) + .02 * U, .017, "#94a3b8", AL_CENTER, 700);
  ui("sch:-", m, H - .1 * U, .2 * U, .065 * U, "< PREV", "#334155", schedPg > 0, .026); ui("sch:+", W - m - .2 * U, H - .1 * U, .2 * U, .065 * U, "NEXT >", "#334155", schedPg < pages - 1, .026);
  back("nav:main", H - .1 * U);
}
static const char *STABS[9] = {"ATLANTIC", "METRO", "CENTRAL", "PACIFIC", "SCORERS", "GOALIES", "NEWS", "MY TEAM", "PLAYOFFS"};
static const char *ASTABS[4] = {"ATLANTIC", "NORTH", "CENTRAL", "PACIFIC"};
static bool inLg(int t) { return t >= 0 && (t >= NA ? 1 : 0) == standLg; }
static void drawBracket(double top, double bot) {
  double m = .02 * U; int cols = 7; double cw = std::min(.21 * U, (W - 2 * m) / cols - .012 * U), gapX = (W - 2 * m - cw * cols) / (cols - 1), bh = .072 * U;
  bool mine = standLg == proLg(); std::vector<std::vector<PSeries>> BR = mine ? C.br : C.obr; int champ = mine ? C.champ : C.ochamp;
  if (BR.empty()) { Seeds E = seeds(0, standLg), Wt = seeds(1, standLg); std::vector<PSeries> r; for (auto *S : {&E, &Wt}) for (auto &p : S->pairs) { PSeries s; s.a = p.first; s.b = p.second; s.proj = true; r.push_back(s); } BR.push_back(r); }
  auto colX = [&](int c) { return m + c * (cw + gapX); };
  auto place = [&](int r, int i, int &c, double &y) { int n = 8 >> r, half = n / 2; if (r == 3) { c = 3; y = (top + bot) / 2; return; } int side = i < half ? 0 : 1, k = side ? i - half : i; double slot = (bot - top) / half; c = side ? 6 - r : r; y = top + slot * (k + .5); };
  ctx.stroke(rgba(148, 163, 184, .35)); ctx.lineWidth(1.5);
  for (int r = 0; r < 3; r++) for (int i = 0; i < (8 >> r); i++) { int ca, cb; double ya, yb; place(r, i, ca, ya); place(r + 1, i / 2, cb, yb); bool left = ca < 3;
    double x0 = left ? colX(ca) + cw : colX(ca), x1 = left ? colX(cb) : colX(cb) + cw, xm = (x0 + x1) / 2; ctx.beginPath(); ctx.moveTo(x0, ya); ctx.lineTo(xm, ya); ctx.lineTo(xm, yb); ctx.lineTo(x1, yb); ctx.strokePath(); }
  for (int r = 0; r < 4; r++) for (int i = 0; i < (8 >> r); i++) { int c; double py; place(r, i, c, py); double x = colX(c), y = py - bh / 2; bool fin = r == 3;
    ctx.fill(fin ? rgba(255, 213, 74, .12) : rgba(15, 23, 42, .88)); ctx.fillRect(x, y, cw, bh); if (fin) { ctx.stroke("#ffd54a"); ctx.strokeRect(x, y, cw, bh); }
    const PSeries *s = r < (int)BR.size() && i < (int)BR[r].size() ? &BR[r][i] : nullptr;
    auto line = [&](int t, int wins, double yy, bool won, bool lost) { if (t < 0) { T("TBD", x + .012 * U, yy, .017, "#475569"); return; } bool me = t == C.me; if (me) { ctx.fill(rgba(255, 213, 74, .22)); ctx.fillRect(x, yy - bh / 4, cw, bh / 2); }
      ctx.fill(hex(teamCol(t))); ctx.fillRect(x, yy - bh / 4, 4, bh / 2); TB(C.L[t].ab, x + .014 * U, yy, .019, lost ? "#64748b" : me ? "#ffd54a" : "#fff");
      T(s && s->proj ? istr(C.L[t].w) + "-" + istr(C.L[t].l) : istr(wins), x + cw - .01 * U, yy, .017, won ? "#7CFC9A" : lost ? "#64748b" : "#cbd5e1", AL_RIGHT, 900); };
    if (!s) { line(-1, 0, y + bh * .27, false, false); line(-1, 0, y + bh * .73, false, false); continue; }
    line(s->a, s->wa, y + bh * .27, s->w == s->a, s->w >= 0 && s->w != s->a); line(s->b, s->wb, y + bh * .73, s->w == s->b, s->w >= 0 && s->w != s->b); }
  int c; double fy; place(3, 0, c, fy); TB(standLg ? "CALDER CUP FINAL" : "STANLEY CUP FINAL", colX(3) + cw / 2, fy - bh / 2 - .02 * U, .02, "#ffd54a", AL_CENTER);
  if (champ >= 0) { T("CHAMPIONS", colX(3) + cw / 2, fy + bh / 2 + .03 * U, .016, "#94a3b8", AL_CENTER); TF(upper(C.L[champ].n), colX(3) + cw / 2, fy + bh / 2 + .06 * U, .026, cw * 1.6, "#ffd54a", AL_CENTER); }
  static const char *CL[7] = {"EAST  R1", "R2", "EAST FINAL", "", "WEST FINAL", "R2", "WEST  R1"}; for (int k = 0; k < 7; k++) if (CL[k][0]) T(CL[k], colX(k) + cw / 2, bot + .03 * U, .015, "#94a3b8", AL_CENTER);
}
static void drawStand() {
  double m = .03 * U, ty = safeTop + .115 * U; standTab = std::max(0, std::min(8, standTab)); if (CR->L.size() < (size_t)NALL) standLg = 0;
  bool mineB = standLg == proLg(); const auto &BRx = mineB ? C.br : C.obr;
  scrHead(standLg ? "AHL" : "NHL", standTab == 8 ? (BRx.empty() ? "16 TEAMS  |  TOP 3 IN EACH DIVISION + 2 WILD CARDS PER CONFERENCE" : mineB && C.phase == "po" ? std::string(RN[std::min(3, C.round)]) + "  |  BEST OF 3 EVERY ROUND" : std::string("BEST OF 3 EVERY ROUND")) : "SEASON " + istr(C.season) + "  |  L / R: SWITCH TABS");
  if (CR->L.size() == (size_t)NALL) { double bw = .13 * U, bx = W - m - 2 * bw - .01 * U, by = safeTop + .03 * U;   // which league
    ui("slg:0", bx, by, bw, .055 * U, "NHL", standLg == 0 ? "#2563eb" : "#334155", true, .024); btns.back().np = true;
    ui("slg:1", bx + bw + .01 * U, by, bw, .055 * U, "AHL", standLg == 1 ? "#c8102e" : "#334155", true, .024); btns.back().np = true; }
  double tw = (W - 2 * m - 8 * .006 * U) / 9;
  for (int i = 0; i < 9; i++) { ui("stab:" + istr(i), m + i * (tw + .006 * U), ty, tw, .05 * U, i < 4 && standLg ? ASTABS[i] : STABS[i], standTab == i ? "#f26b5b" : "#334155", true, .019); btns.back().np = true; }
  double y0 = ty + .075 * U, x = m, w = W - 2 * m;
  auto hdr = [&](const std::vector<std::pair<std::string, double>> &c) { for (auto &e : c) T(e.first, e.second, y0 + .005 * U, .015, "#94a3b8", AL_RIGHT); };
  if (standTab < 4) {
    std::vector<int> ids; for (int i : lgTeams(standLg)) if (C.L[i].d == standTab) ids.push_back(i); std::vector<int> o = standOrd(ids);
    std::map<int, char> spot; for (int c = 0; c < 2; c++) { Seeds S = seeds(c, standLg); for (auto &d : S.top) for (int t : d) spot[t] = 'x'; for (int t : S.wc) spot[t] = 'w'; }
    double rh = std::min(.052 * U, (H - y0 - .2 * U) / std::max<size_t>(8, o.size()) - .005 * U); hdr({{"W", x + w * .55}, {"L", x + w * .62}, {"GF", x + w * .72}, {"GA", x + w * .8}, {"DIFF", x + w * .89}, {"STRK", x + w - .02 * U}});
    for (size_t k = 0; k < o.size(); k++) { int t = o[k]; PTeam &L = C.L[t]; double ry = y0 + .02 * U + k * (rh + .005 * U); panel(x, ry, w, rh, .62); if (t == C.me) { ctx.fill(rgba(255, 213, 74, .22)); ctx.fillRect(x, ry, w, rh); }
      badge(x + .04 * U, ry + rh / 2, rh * .36, t); TB(istr(k + 1) + ". " + upper(teamFull(t)), x + .075 * U, ry + rh / 2, .022, t == C.me ? "#ffd54a" : t == orgOf(C.me) || t == orgOf(C.me) + NA ? "#fde68a" : "#fff");
      if (spot.count(t)) T(std::string(1, spot[t]), x + w * .45, ry + rh / 2, .02, spot[t] == 'x' ? "#7CFC9A" : "#93c5fd", AL_CENTER);
      int dd = L.gf - L.ga; std::string sk = L.sk > 0 ? "W" + istr(L.sk) : L.sk < 0 ? "L" + istr(-L.sk) : "-";
      T(istr(L.w), x + w * .55, ry + rh / 2, .022, "#fff", AL_RIGHT); T(istr(L.l), x + w * .62, ry + rh / 2, .022, "#fff", AL_RIGHT); T(istr(L.gf), x + w * .72, ry + rh / 2, .02, "#cbd5e1", AL_RIGHT); T(istr(L.ga), x + w * .8, ry + rh / 2, .02, "#cbd5e1", AL_RIGHT);
      T((dd > 0 ? "+" : "") + istr(dd), x + w * .89, ry + rh / 2, .02, dd >= 0 ? "#7CFC9A" : "#fca5a5", AL_RIGHT); T(sk, x + w - .02 * U, ry + rh / 2, .02, "#cbd5e1", AL_RIGHT); }
    T("x = top 3 in the division    w = wild card (next 2 best in the conference)    16 teams make it", x, y0 + .02 * U + std::max<size_t>(8, o.size()) * (rh + .005 * U) + .025 * U, .016, "#94a3b8", AL_LEFT, 700);
  } else if (standTab == 4) {
    std::vector<PP *> top; for (auto &q : C.P) if (!q->g && inLg(q->t)) top.push_back(q.get());
    std::sort(top.begin(), top.end(), [](PP *a, PP *b) { int pa = a->gl + a->as, pb = b->gl + b->as; return pa != pb ? pa > pb : a->gl > b->gl; }); double rh = .04 * U;
    hdr({{"G", x + w * .8}, {"A", x + w * .88}, {"PTS", x + w - .02 * U}});
    for (size_t k = 0; k < top.size() && k < 12; k++) { PP *q = top[k]; double ry = y0 + .02 * U + k * (rh + .004 * U); panel(x, ry, w, rh, .62); if (q->me) { ctx.fill(rgba(255, 213, 74, .22)); ctx.fillRect(x, ry, w, rh); }
      T(istr(k + 1) + ". " + q->nm(), x + .06 * U, ry + rh / 2, .021, q->me ? "#ffd54a" : q->t == C.me ? "#fde68a" : "#fff"); ctx.fill(hex(teamCol(q->t))); ctx.disc(x + .035 * U, ry + rh / 2, .012 * U);
      T(C.L[q->t].ab + "   OVR " + istr(ovQ(q)) + "   AGE " + istr(q->age), x + w * .45, ry + rh / 2, .016, "#94a3b8", AL_LEFT, 700);
      T(istr(q->gl), x + w * .8, ry + rh / 2, .022, "#cbd5e1", AL_RIGHT); T(istr(q->as), x + w * .88, ry + rh / 2, .022, "#cbd5e1", AL_RIGHT); TB(istr(q->gl + q->as), x + w - .02 * U, ry + rh / 2, .024, "#fff", AL_RIGHT); }
    T("Top 12 scorers this regular season", x, y0 + .02 * U + 12 * (.044 * U) + .02 * U, .016, "#94a3b8", AL_LEFT, 700);
  } else if (standTab == 5) {
    std::vector<PP *> l; for (auto &q : C.P) if (q->g && inLg(q->t) && q->sa >= 40) l.push_back(q.get());
    std::sort(l.begin(), l.end(), [](PP *a, PP *b) { return (double)a->sv / a->sa > (double)b->sv / b->sa; }); double rh = .04 * U;
    hdr({{"GP", x + w * .8}, {"SV%", x + w - .02 * U}});
    for (size_t k = 0; k < l.size() && k < 12; k++) { PP *q = l[k]; double ry = y0 + .02 * U + k * (rh + .004 * U); panel(x, ry, w, rh, .62); ctx.fill(hex(teamCol(q->t))); ctx.disc(x + .035 * U, ry + rh / 2, .012 * U);
      T(istr(k + 1) + ". " + q->nm(), x + .06 * U, ry + rh / 2, .021, q->t == C.me ? "#fde68a" : "#fff"); T(C.L[q->t].ab + "   OVR " + istr(ovQ(q)) + "   AGE " + istr(q->age), x + w * .45, ry + rh / 2, .016, "#94a3b8", AL_LEFT, 700);
      T(istr(q->gp), x + w * .8, ry + rh / 2, .022, "#cbd5e1", AL_RIGHT); TB(svp3(q->sv, q->sa), x + w - .02 * U, ry + rh / 2, .024, "#7CFC9A", AL_RIGHT); }
    if (l.empty()) TB("Goalie stats appear after a few games", W / 2, y0 + .1 * U, .03, "#94a3b8", AL_CENTER);
  } else if (standTab == 6) {
    double rh = .038 * U; if (C.log.empty()) TB("No league news yet", W / 2, y0 + .1 * U, .03, "#94a3b8", AL_CENTER);
    for (size_t k = 0; k < C.log.size() && k < 13; k++) { double ry = y0 + .01 * U + k * (rh + .004 * U); panel(x, ry, w, rh, .62); T("Y" + istr(C.log[k].y), x + .02 * U, ry + rh / 2, .016, "#64748b"); TF(C.log[k].s, x + .07 * U, ry + rh / 2, .018, w - .09 * U, "#e2e8f0"); }
  } else if (standTab == 7) {
    std::vector<PP *> S = teamS(C.me); std::sort(S.begin(), S.end(), [](PP *a, PP *b) { if (a->isCu != b->isCu) return !a->isCu; return ovQ(a) > ovQ(b); });
    std::vector<PP *> GG = teamG(C.me); std::sort(GG.begin(), GG.end(), [](PP *a, PP *b) { return ovQ(a) > ovQ(b); });
    double pay = payroll(orgOf(C.me)), cap = capOf(), lw = w * .63, rx = x + lw + .02 * U, rw = w - lw - .02 * U, rh = std::min(.044 * U, (H - y0 - .03 * U) / std::max<size_t>(9, S.size()) - .004 * U);
    for (size_t k = 0; k < S.size(); k++) { PP *q = S[k]; double ry = y0 + k * (rh + .004 * U); panel(x, ry, lw, rh, .62); if (q->me) { ctx.fill(rgba(255, 213, 74, .22)); ctx.fillRect(x, ry, lw, rh); }
      std::string tg = q->inj ? "  INJ " + istr(q->inj) : q->isCu ? "  CALL-UP" : ""; TF((q->star ? "* " : "") + q->nm() + tg, x + .015 * U, ry + rh / 2, .02, lw * .46, q->me ? "#ffd54a" : q->inj ? "#fca5a5" : q->isCu ? "#93c5fd" : "#fff");
      T("OVR " + istr(ovQ(q)) + "  AGE " + istr(q->age), x + lw * .5, ry + rh / 2, .016, "#cbd5e1", AL_LEFT, 700); T(istr(q->gl) + "G " + istr(q->as) + "A", x + lw * .73, ry + rh / 2, .016, "#cbd5e1", AL_LEFT, 700);
      T(q->isCu ? "-" : "$" + fixed(q->sal, 1) + "M " + istr(q->cy) + "Y", x + lw - .012 * U, ry + rh / 2, .016, "#7CFC9A", AL_RIGHT); }
    double ry = y0; panel(rx, ry, rw, .12 * U); T(C.me >= NA ? upper(C.L[orgOf(C.me)].n) + " PAYROLL (NHL)" : "PAYROLL", rx + .015 * U, ry + .025 * U, .015, "#94a3b8", AL_LEFT, 700); TB("$" + fixed(pay, 1) + "M / $" + fixed(cap, 1) + "M", rx + .015 * U, ry + .06 * U, .028, pay > cap ? "#fca5a5" : "#7CFC9A");
    T((cap - pay >= 0 ? "$" + fixed(cap - pay, 1) + "M UNDER" : "$" + fixed(pay - cap, 1) + "M OVER") + std::string(" THE CAP"), rx + .015 * U, ry + .095 * U, .015, "#cbd5e1", AL_LEFT, 700);
    ry += .135 * U; T("GOALIES", rx, ry, .016, "#f26b5b"); ry += .022 * U;
    for (PP *q : GG) { panel(rx, ry, rw, .06 * U, .62); TF(q->nm(), rx + .015 * U, ry + .02 * U, .02, rw * .6, "#fff"); T("OVR " + istr(ovQ(q)), rx + rw - .012 * U, ry + .02 * U, .017, "#cbd5e1", AL_RIGHT);
      T("SV% " + svp3(q->sv, q->sa) + "  GP " + istr(q->gp) + "   $" + fixed(q->sal, 1) + "M " + istr(q->cy) + "Y", rx + .015 * U, ry + .045 * U, .015, "#94a3b8", AL_LEFT, 700); ry += .066 * U; }
  } else drawBracket(y0 + .02 * U, H - .15 * U);
  back("nav:main", H - .085 * U);
}
static void drawRetired() {
  double w = std::min(W - 24.0, 1.4 * U), x = (W - w) / 2, y = safeTop + .04 * U;
  TB("CAREER OVER", W / 2, y + .05 * U, .075, "#fff", AL_CENTER);
  T(C.retWhy == "injury" ? "A broken back ends it at age " + istr(C.age) + "." : "You hang up the skates at " + istr(C.age) + ".", W / 2, y + .12 * U, .03, "#cbd5e1", AL_CENTER, 700);
  double ry = y + .17 * U, rh = .3 * U; panel(x, ry, w, rh); ctx.fill("#c8102e"); ctx.fillRect(x, ry, w, 4);
  you(x + .12 * U, ry + rh * .85, .045 * U);
  std::pair<std::string, std::string> st[6] = {{"SEASONS", istr(C.season - (C.retWhy == "age" ? 1 : 0))}, {"NHL GAMES", istr(C.cGP)}, {"NHL GOALS", istr(C.cG)}, {"NHL ASSISTS", istr(C.cA)}, {"NHL POINTS", istr(C.cG + C.cA)}, {"STANLEY CUPS", istr(C.titles)}};
  for (int i = 0; i < 6; i++) { double cx = x + .28 * U + (i % 3) * (w - .32 * U) / 3, cy = ry + .08 * U + (i / 3) * .12 * U; T(st[i].first, cx, cy, .018, "#94a3b8", AL_LEFT, 700); TB(st[i].second, cx, cy + .045 * U, .045, i == 5 ? "#ffd54a" : "#fff"); }
  T("AHL: " + istr(C.aGP) + " GP  " + istr(C.aG) + " G  " + istr(C.aA) + " A  |  CALDER CUPS " + istr(C.calder) + (C.debut ? "  |  NHL DEBUT AT " + istr(C.debut) : "  |  NEVER MADE THE NHL"), W / 2, ry + rh - .03 * U, .018, "#94a3b8", AL_CENTER, 700);
  T("FINAL OVR " + istr(proOvr()) + "   |   HALL OF FAME: " + istr(proHofCareers) + (proHofCareers == 1 ? " CAREER" : " CAREERS") + "   |   MOST TITLES " + istr(proHofBest), W / 2, ry + rh + .04 * U, .02, "#cbd5e1", AL_CENTER, 700);
  double by = ry + rh + .08 * U, bw = .42 * U;
  ui("pnewc", W / 2 - bw - .01 * U, by, bw, .085 * U, "NEW CAREER", "#16a34a", true, .034); ui("nav:modes", W / 2 + .01 * U, by, bw, .085 * U, "MAIN MENU", "#475569", true, .034);
}
static void drawBusy() {
  TB("OFF-SEASON", W / 2, H * .4, .08, "#fff", AL_CENTER);
  T("CONTRACTS EXPIRE   |   THE DRAFT   |   FREE AGENCY   |   TRADES", W / 2, H * .4 + .075 * U, .022, "#f26b5b", AL_CENTER);
  T("Building next season...", W / 2, H * .4 + .13 * U, .02, "#94a3b8", AL_CENTER, 700);
  if (++busyF >= 3) { busyF = 0; proNextSeason(); }
}

static bool pre(const std::string &id, const char *p) { return id.rfind(p, 0) == 0; }
// ---------------------------------------------------------------- home: the apartment, and the phone that runs your career
static int phApp = -1, storeCat = 0, phLast = 0; static bool phOn = false; static std::string aptOv; static std::string aptToast; static double aptToastT = 0, phT0 = 0, aptLastT = 0;
static const char *APPN[8] = {"SCHEDULE", "MY HEALTH", "UPGRADES", "TRAINING", "GM CONNECT", "GEAR SHOP", "PERFORMANCE", "MESSAGES"};
static const char *APPC[8][2] = {{"#f8fafc", "#e2e8f0"}, {"#fb7185", "#e11d48"}, {"#fbbf24", "#d97706"}, {"#38bdf8", "#0284c7"}, {"#818cf8", "#4f46e5"}, {"#fb923c", "#ea580c"}, {"#c084fc", "#9333ea"}, {"#4ade80", "#16a34a"}};
static void toast(const std::string &s) { aptToast = s; aptToastT = now(); }
bool proAptWorld() { return mode == "pro" && CR && screen == "main" && aptReady() && !phOn && aptOv.empty() && phApp < 0 && C.phase != "retired" && !modal.on; }
// the phone in your hand: portrait, bottom right
static Grad vgrad(double y0, double y1, Col a, Col b) { Grad g = gLin(0, (float)y0, 0, (float)y1); g.add(0, a); g.add(1, b); return g; }
struct PhR { double x, y, w, h, sx, sy, sw, sh; };
static PhR phoneRect() {
  PhR r; r.h = std::min(H * .9, H - safeTop - .03 * U); r.w = r.h * .5; r.x = W - r.w - .035 * U; r.y = H - r.h - .02 * U;
  double e = clamp((now() - phT0) / 220, 0, 1); e = 1 - std::pow(1 - e, 3); r.y += (1 - e) * r.h * .7;
  double b = r.w * .045; r.sx = r.x + b; r.sy = r.y + b; r.sw = r.w - 2 * b; r.sh = r.h - 2 * b; return r;
}
static void phoneBody(const PhR &r) {
  ctx.fill(rgba(0, 0, 0, .35)); ctx.rr(r.x + 6, r.y + 8, r.w, r.h, r.w * .14); ctx.fillPath();
  ctx.fill("#1f2937"); ctx.rr(r.x - 2, r.y - 2, r.w + 4, r.h + 4, r.w * .15); ctx.fillPath(); ctx.fill("#0a0a0c"); ctx.rr(r.x, r.y, r.w, r.h, r.w * .14); ctx.fillPath();
  Col a = hex(teamCol(C.me)); ctx.fill(vgrad(r.sy, r.sy + r.sh, shade(a, -.25), hex("#0b1020"))); ctx.rr(r.sx, r.sy, r.sw, r.sh, r.w * .11); ctx.fillPath();
  ctx.fill("#0a0a0c"); ctx.rr(r.x + r.w * .36, r.sy + r.sh * .012, r.w * .28, r.sh * .028, r.sh * .014); ctx.fillPath();   // the island
}
static void statusBar(double x, double y, double w, double h) {
  T(C.cal.empty() || C.phase != "reg" ? "CHL" : calDate(C.ci), x + h * .9, y + h / 2, .0135, "#fff", AL_LEFT, 800);
  double bx = x + w - h * 2.2; ctx.fill(rgba(255, 255, 255, .9)); ctx.fillRect(bx, y + h * .32, h * 1.1, h * .36); ctx.fillRect(bx + h * 1.12, y + h * .42, h * .1, h * .16);
  for (int i = 0; i < 4; i++) ctx.fillRect(bx - h * (1.4 - i * .28), y + h * (.66 - i * .1), h * .18, h * (.1 + i * .1));
}
// the icons: simple glyphs on rounded tiles
static void appIcon(int i, double x, double y, double s, bool dim) {
  ctx.alpha(dim ? .45f : 1); ctx.fill(vgrad(y, y + s, hex(APPC[i][0]), hex(APPC[i][1]))); ctx.rr(x, y, s, s, s * .24); ctx.fillPath();
  double cx = x + s / 2, cy = y + s / 2, u = s / 10; ctx.fill("#fff");
  switch (i) {
    case 0: ctx.fill("#ef4444"); ctx.fillRect(x + u * 2, y + u * 2, u * 6, u * 1.6); ctx.fill("#fff"); ctx.fillRect(x + u * 2, y + u * 3.6, u * 6, u * 4.4); ctx.font(u * 3.4); ctx.fill("#111827"); ctx.textMid(); ctx.fillText(istr(C.cal.empty() ? 1 : 1 + C.ci % 28), cx, y + u * 5.9); break;
    case 1: ctx.fillRect(cx - u * .9, cy - u * 3, u * 1.8, u * 6); ctx.fillRect(cx - u * 3, cy - u * .9, u * 6, u * 1.8); break;
    case 2: ctx.beginPath(); ctx.moveTo(cx, y + u * 2); ctx.lineTo(x + u * 7.6, y + u * 5.2); ctx.lineTo(x + u * 2.4, y + u * 5.2); ctx.closePath(); ctx.fillPath(); ctx.fillRect(cx - u * 1.1, y + u * 5, u * 2.2, u * 3); break;
    case 3: ctx.fillRect(x + u * 2.6, cy - u * .5, u * 4.8, u); ctx.fillRect(x + u * 1.6, cy - u * 2, u * 1.4, u * 4); ctx.fillRect(x + u * 7, cy - u * 2, u * 1.4, u * 4); ctx.fillRect(x + u * 1, cy - u * 1.2, u * .8, u * 2.4); ctx.fillRect(x + u * 8.2, cy - u * 1.2, u * .8, u * 2.4); break;
    case 4: ctx.fillRect(x + u * 2, y + u * 3.6, u * 6, u * 4); ctx.fill(APPC[4][1]); ctx.fillRect(x + u * 2, y + u * 5.2, u * 6, u * .5); ctx.fill("#fff"); ctx.fillRect(x + u * 3.8, y + u * 2.4, u * 2.4, u * .9); ctx.fillRect(x + u * 3.8, y + u * 2.4, u * .6, u * 1.4); ctx.fillRect(x + u * 5.6, y + u * 2.4, u * .6, u * 1.4); break;
    case 5: ctx.beginPath(); ctx.moveTo(x + u * 6.6, y + u * 1.8); ctx.lineTo(x + u * 7.6, y + u * 2.2); ctx.lineTo(x + u * 4.2, y + u * 7.2); ctx.lineTo(x + u * 3.2, y + u * 6.8); ctx.closePath(); ctx.fillPath(); ctx.fillRect(x + u * 1.6, y + u * 6.8, u * 3.2, u * 1.2); ctx.fill("#111827"); ctx.disc(x + u * 6.6, y + u * 7.6, u * .9); break;
    case 6: for (int k = 0; k < 4; k++) { double hh = u * (1.8 + k * 1.3); ctx.fillRect(x + u * (1.8 + k * 1.7), y + u * 8 - hh, u * 1.2, hh); } break;
    case 7: ctx.rr(x + u * 1.8, y + u * 2.2, u * 6.4, u * 4.4, u * 2); ctx.fillPath(); ctx.beginPath(); ctx.moveTo(x + u * 3, y + u * 6); ctx.lineTo(x + u * 2.4, y + u * 8); ctx.lineTo(x + u * 4.6, y + u * 6.2); ctx.closePath(); ctx.fillPath(); break;
  }
  ctx.alpha(1);
}
// the training app shows an update ring: full and ready on an off day, otherwise still "installing"
static void trainRing(double x, double y, double s, bool ready) {
  double cx = x + s / 2, cy = y + s / 2, r = s * .62;
  ctx.lineWidth(std::max(2.0, s * .06)); ctx.stroke(rgba(255, 255, 255, .25)); ctx.ring(cx, cy, r);
  double a0 = -1.5708, a1 = ready ? a0 + 6.2832 : a0 + 6.2832 * (.18 + .1 * std::sin(now() / 900)), sp = ready ? 0 : now() / 700;
  ctx.stroke(ready ? hex("#4ade80") : hex("#94a3b8")); ctx.beginPath(); ctx.arc(cx, cy, r, a0 + sp, a1 + sp); ctx.strokePath();
}
static int appBadge(int i) {
  if (i == 4) return (C.need ? 1 : 0) + (int)C.offers.size() + (C.showTrade && C.hasTrade ? 1 : 0);
  if (i == 1) return C.phase != "over" && userHurt() ? 1 : 0;
  if (i == 3) return canTrain() ? 1 : 0;
  return 0;
}
static void drawPhoneGrid() {
  PhR r = phoneRect(); phoneBody(r); double sb = r.sh * .06; statusBar(r.sx, r.sy, r.sw, sb);
  double top = r.sy + sb + r.sh * .03; TB("$" + fmtN(C.money), r.sx + r.sw / 2, top + r.sh * .02, .03, "#ffd54a", AL_CENTER);
  T(upper(C.nm) + "  |  OVR " + istr(proOvr()), r.sx + r.sw / 2, top + r.sh * .065, .0135, "#cbd5e1", AL_CENTER, 700);
  int cols = 3; double gx = r.sw * .09, s = (r.sw - gx * (cols + 1)) / cols, gy = s * .62, y0 = top + r.sh * .12;
  for (int i = 0; i < 8; i++) { int c = i % cols, rw = i / cols; double x = r.sx + gx + c * (s + gx), y = y0 + rw * (s + gy);
    bool dim = i == 3 && !canTrain(); appIcon(i, x, y, s, dim); if (i == 3) trainRing(x, y, s, !dim);
    int b = appBadge(i); if (b && i != 3) { double br = s * .17; ctx.fill("#ef4444"); ctx.disc(x + s - br * .4, y + br * .4, br); ctx.font(br * 1.2); ctx.fill("#fff"); ctx.textMid(); ctx.fillText(istr(b), x + s - br * .4, y + br * .4 + 1); }
    ctx.font(std::min(.0125 * U, s * .2)); ctx.fill("#fff"); ctx.textMid(); ctx.fillText(APPN[i], x + s / 2, y + s + s * .2);
    pushBtn("app:" + istr(i), x - gx * .3, y - gx * .3, s + gx * .6, s + s * .32 + gx * .3, APPN[i]); }
  // the dock: hints
  double dy = r.sy + r.sh - r.sh * .1; ctx.fill(rgba(255, 255, 255, .12)); ctx.rr(r.sx + r.sw * .05, dy, r.sw * .9, r.sh * .075, r.sh * .03); ctx.fillPath();
  T("X OPEN   O / SELECT CLOSE", r.sx + r.sw / 2, dy + r.sh * .0375, .0125, "#e2e8f0", AL_CENTER, 700);
  ctx.fill(rgba(255, 255, 255, .7)); ctx.rr(r.sx + r.sw * .34, r.sy + r.sh - r.sh * .018, r.sw * .32, r.sh * .008, r.sh * .004); ctx.fillPath();
  pushBtn("ph:close", 0, 0, 0, 0, "BACK", true);
}
// the store: walk up to something in build mode, the phone shows what you could put there
static void drawPhoneStore() {
  PhR r = phoneRect(); phoneBody(r); double sb = r.sh * .06; statusBar(r.sx, r.sy, r.sw, sb);
  int cat = storeCat; double x = r.sx + r.sw * .06, w = r.sw * .88, y = r.sy + sb + r.sh * .02;
  T("HOME STORE", x, y + r.sh * .01, .013, "#94a3b8", AL_LEFT, 800); TB("$" + fmtN(C.money), x + w, y + r.sh * .01, .022, "#ffd54a", AL_RIGHT);
  TF(HOME_CAT[cat], x, y + r.sh * .05, .026, w, "#fff"); y += r.sh * .085;
  double rh = (r.sh * .9 - (y - r.sy)) / HOME_NO - r.sh * .012;
  for (int i = 0; i < HOME_NO; i++) { const HomeOpt &o = HOME_OPT[cat][i]; bool own = HOME.own[cat] >> i & 1, eq = HOME.sel[cat] == i, ok = own || C.money >= o.c; double yy = y + i * (rh + r.sh * .012);
    ctx.fill(eq ? rgba(56, 189, 248, .22) : rgba(255, 255, 255, .08)); ctx.rr(x, yy, w, rh, r.sw * .04); ctx.fillPath(); if (eq) { ctx.fill("#38bdf8"); ctx.fillRect(x, yy + rh * .15, 3, rh * .7); }
    TF(o.n, x + w * .05, yy + rh * .22, .0165, w * .5, ok ? "#fff" : "#94a3b8");
    TF(eq ? "IN USE" : own ? "OWNED" : o.c ? "$" + fmtN(o.c) : "FREE", x + w * .95, yy + rh * .22, .0145, w * .36, eq ? "#38bdf8" : own ? "#7CFC9A" : ok ? "#ffd54a" : "#fca5a5", AL_RIGHT);
    txWrap(o.d, x + w * .05, yy + rh * .52, .0122, w * .9, hex("#cbd5e1"), AL_LEFT, 700, 2);
    pushBtn("hb:" + istr(cat) + ":" + istr(i), x, yy, w, rh, o.n); if (!ok) btns.back().dis = true; }
  T("X BUY / EQUIP   O BACK", r.sx + r.sw / 2, r.sy + r.sh * .955, .0125, "#94a3b8", AL_CENTER, 700);
  pushBtn("ph:close", 0, 0, 0, 0, "BACK", true);
}
// apps run the career screens on a bigger, sideways phone: the screen is drawn at the phone's size and moved into place
static void drawHealth() {
  double m = .03 * U, top = safeTop + .14 * U; PP *Y = youMe(); InjRisk k = injRisk(); bool hurt = C.phase != "over" && userHurt();
  scrHead("MY HEALTH", hurt ? "INJURED  |  OUT " + istr(Y ? Y->inj : 0) + " MORE GAMES" : "CLEARED TO PLAY");
  double lw = W * .36; panel(m, top, lw, H - top - .13 * U); ctx.fill(hurt ? "#ef4444" : "#22c55e"); ctx.fillRect(m, top, 4, H - top - .13 * U);
  T("STATUS", m + .03 * U, top + .04 * U, .017, "#94a3b8", AL_LEFT, 700); TB(hurt ? "INJURED" : "HEALTHY", m + .03 * U, top + .1 * U, .06, hurt ? "#fca5a5" : "#7CFC9A");
  if (hurt && Y) { TF(upper(Y->it) + " INJURY", m + .03 * U, top + .16 * U, .022, lw - .06 * U, "#fff"); T(istr(Y->inj) + (Y->inj == 1 ? " GAME TO GO" : " GAMES TO GO"), m + .03 * U, top + .2 * U, .018, "#cbd5e1", AL_LEFT, 700); }
  else T("No knocks. Keep it that way.", m + .03 * U, top + .16 * U, .018, "#cbd5e1", AL_LEFT, 700);
  double pg = k.p * 100, ps = (1 - std::pow(1 - k.p, PRO_GAMES)) * 100;
  T("RISK PER GAME", m + .03 * U, top + .27 * U, .016, "#94a3b8", AL_LEFT, 700); TB(fixed(pg, 2) + "%", m + .03 * U, top + .32 * U, .045, pg > .5 ? "#fca5a5" : "#fff");
  T("OVER A FULL SEASON", m + .03 * U, top + .38 * U, .016, "#94a3b8", AL_LEFT, 700); TB(istr((int)jround(ps)) + "%", m + .03 * U, top + .43 * U, .045, ps > 30 ? "#fca5a5" : "#fff");
  double rx = m + lw + .02 * U, rw = W - rx - m, y = top; panel(rx, y, rw, H - top - .13 * U, .6);
  TB("WHAT DRIVES YOUR RISK", rx + .025 * U, y + .04 * U, .024, "#f26b5b"); y += .09 * U;
  auto fac = [&](const std::string &n, const std::string &why, double f) {
    T(n, rx + .025 * U, y, .019, "#fff", AL_LEFT, 800); TB("x" + fixed(f, 2), rx + rw - .025 * U, y, .024, f > 1.02 ? "#fca5a5" : f < .98 ? "#7CFC9A" : "#cbd5e1", AL_RIGHT);
    TF(why, rx + .025 * U, y + .03 * U, .015, rw - .05 * U, "#94a3b8"); double bw = rw - .05 * U; ctx.fill(rgba(148, 163, 184, .2)); ctx.fillRect(rx + .025 * U, y + .052 * U, bw, 4);
    ctx.fill(f > 1.02 ? "#ef4444" : f < .98 ? "#22c55e" : "#94a3b8"); ctx.fillRect(rx + .025 * U, y + .052 * U, bw * clamp(f / 2, 0, 1), 4); y += .1 * U; };
  fac("AGE " + istr(C.age), C.age <= 24 ? "Young legs bounce back." : C.age <= 29 ? "Prime years: no extra risk." : "Every year past 29 adds about 7%.", k.age);
  fac("CONTACT", k.games ? fixed(k.hitsPG, 1) + " hits a game over your last " + istr(k.games) + " games. Play the body, pay the price." : "No games played yet.", k.hits);
  fac("GEAR", k.gear < 1 ? "Your helmet and gear take some of the hits." : k.gear > 1 ? "Light gear: faster, but less protection." : "Standard protection. The gear shop has better.", k.gear);
  T("Injuries also knock a point off two of your ratings.", rx + .025 * U, y + .01 * U, .015, "#64748b", AL_LEFT, 700);
  back("nav:main", H - .1 * U);
}
static void drawMsgs() {
  scrHead("MESSAGES", "TEXTS FROM YOUR AGENT, TEAMMATES AND FAMILY");
  double cx = W / 2, cy = H * .45; ctx.fill(rgba(74, 222, 128, .2)); ctx.rr(cx - .1 * U, cy - .12 * U, .2 * U, .13 * U, .05 * U); ctx.fillPath();
  TB("No messages yet.", cx, cy + .07 * U, .034, "#fff", AL_CENTER); T("Coming in a future update.", cx, cy + .12 * U, .018, "#94a3b8", AL_CENTER, 700);
  back("nav:main", H - .1 * U);
}
static void drawAptView(bool dim);
static void drawInPhone(void (*fn)()) {
  drawAptView(true);
  double b = .012 * U, sx = W * .03 + b, sy = H * .035 + b, sw = W * .94 - 2 * b, sh = H * .93 - 2 * b;
  ctx.fill(rgba(0, 0, 0, .4)); ctx.rr(sx - b + 8, sy - b + 10, sw + 2 * b, sh + 2 * b, .05 * U); ctx.fillPath();
  ctx.fill("#0a0a0c"); ctx.rr(sx - b, sy - b, sw + 2 * b, sh + 2 * b, .05 * U); ctx.fillPath();
  ctx.fill(vgrad(sy, sy + sh, hex("#111a33"), hex("#070b16"))); ctx.rr(sx, sy, sw, sh, .04 * U); ctx.fillPath();
  float oW = W, oH = H, oU = U, oT = safeTop; size_t n0 = btns.size();
  W = (float)sw; H = (float)sh; U = std::min(W, H); safeTop = .03f * U;
  ctx.save(); ctx.translate(sx, sy); statusBar(0, 0, W, safeTop); fn(); ctx.restore();
  W = oW; H = oH; U = oU; safeTop = oT;
  for (size_t i = n0; i < btns.size(); i++) { btns[i].x += sx; btns[i].y += sy; }
  pushBtn("ph:close", 0, 0, 0, 0, "", true);
}
// the world, and what's drawn over it
static void drawAptView(bool dim) {
  if (!aptReady()) { ctx.fill("#05070d"); ctx.fillRect(0, 0, W, H); return; }   // not loaded (never built outside the loading screen)
  aptDraw();
  if (dim) { ctx.fill(rgba(2, 6, 23, .45)); ctx.fillRect(0, 0, W, H); }
}
static void drawDoor() {
  ctx.fill(rgba(2, 6, 23, .5)); ctx.fillRect(0, 0, W, H);
  double w = std::min(W * .5, .9 * U), x = (W - w) / 2, y = safeTop + .08 * U, h = H - y - .08 * U; panel(x, y, w, h, .92); ctx.fill("#f26b5b"); ctx.fillRect(x, y, w, 4);
  std::string ph = C.phase; bool off = offDay(), hurt = ph != "over" && userHurt(), need = C.need; PTeam &r = C.L[C.me];
  TB("FRONT DOOR", x + .03 * U, y + .05 * U, .04, "#fff");
  std::string sub = ph == "over" ? "THE SEASON IS OVER" : need ? "YOUR CONTRACT HAS EXPIRED" : off ? "OFF DAY  |  " + calDate(C.ci) : hurt ? "INJURED  |  OUT " + istr(youMe()->inj) + " MORE" : (ph == "po" ? "PLAYOFFS  |  SERIES " + istr(C.sw) + "-" + istr(C.sl) : "GAME " + istr(C.day + 1) + " OF " + istr(PRO_GAMES));
  T(sub, x + .03 * U, y + .095 * U, .018, off || need || hurt ? "#f26b5b" : "#94a3b8", AL_LEFT, 800);
  double ly = y + .13 * U;
  if (ph != "over") { badge(x + .06 * U, ly + .035 * U, .03 * U, C.me); TB("VS", x + w / 2, ly + .035 * U, .022, "#f26b5b", AL_CENTER); badge(x + w - .06 * U, ly + .035 * U, .03 * U, C.opp);
    TF(upper(r.n), x + .1 * U, ly + .035 * U, .02, w / 2 - .14 * U, "#fff"); TF(upper(C.L[C.opp].n), x + w - .1 * U, ly + .035 * U, .02, w / 2 - .14 * U, "#fff", AL_RIGHT); ly += .09 * U; }
  double ih = .062 * U, iw = w - .06 * U, ix = x + .03 * U;
  auto it = [&](const std::string &id, const std::string &lb, bool big) { menuItem(id, lb, ix, ly, iw, big ? ih * 1.15 : ih, big, true); ly += (big ? ih * 1.15 : ih) + .008 * U; };
  if (need) it("off:neg", "SIGN YOUR CONTRACT", true);
  else if (off) { it("skipday", "REST (SKIP DAY)", true); it("nav:train", "TRAIN  ($" + istr(trainCost()) + ")", false); it("sim1", "SIM TO NEXT GAME", false); }
  else if (ph == "over") it("next", "NEXT SEASON", true);
  else if (hurt) { it("simheal", "SIM UNTIL HEALTHY", true); it("sim1", "SIM ONE GAME", false); }
  else { it("play", "PLAY NEXT GAME", true); it("sim1", "SIM GAME", false); it("simN", ph == "po" ? "SIM SERIES" : "SIM 10 GAMES", false); }
  it("nav:modes", "MAIN MENU", false);
  ui("ad:close", x + w / 2 - .15 * U, y + h - .08 * U, .3 * U, .06 * U, "BACK", "#475569", true, .026);
}
// heading home: the apartment is built behind a loading screen, and thrown away again before every game
static int loadF = 0; static double loadT0 = 0;
static void drawAptLoad() {
  if (loadF == 0) loadT0 = now();
  Col a = hex(teamCol(C.me)); ctx.fill(vgrad(0, H, shade(a, -.55), hex("#05070d"))); ctx.fillRect(0, 0, W, H);
  double cx = W / 2, cy = H * .42, t = now() / 1000;
  // a key turning in a door, more or less: a ring of dots chasing round
  for (int i = 0; i < 10; i++) { double ang = t * 5 - i * .45, r = .06 * U; ctx.fill(rgba(255, 213, 74, (float)(1 - i * .09))); ctx.disc(cx + std::cos(ang) * r, cy + std::sin(ang) * r, .009 * U * (1 - i * .06)); }
  TB("HEADING HOME", cx, cy + .14 * U, .05, "#fff", AL_CENTER);
  T(upper(C.nm) + "'S PLACE  |  FILE " + istr(proSlot + 1), cx, cy + .2 * U, .02, "#94a3b8", AL_CENTER, 700);
  double k = clamp((now() - loadT0) / 450, 0, 1), bw = .5 * U; ctx.fill(rgba(255, 255, 255, .12)); ctx.fillRect(cx - bw / 2, cy + .25 * U, bw, 4); ctx.fill("#ffd54a"); ctx.fillRect(cx - bw / 2, cy + .25 * U, bw * (aptReady() ? k : k * .5), 4);
  if (++loadF == 2) aptLoad();   // the screen is up: build now
  if (loadF > 2 && aptReady() && now() - loadT0 > 450) { loadF = 0; screen = "main"; }
}
static void drawApt() {
  if (C.showTrade && C.hasTrade) { phOn = true; phApp = 4; screen = "trade"; return; }
  if (phApp >= 0) { phApp = -1; phOn = true; }   // an app closed itself: back to the home screen
  drawAptView(phOn || !aptOv.empty());
  double m = .03 * U, ty = safeTop + .03 * U;
  if (!phOn && aptOv.empty()) {
    aptHUD(); int lk = aptLook();
    // who you are, what's next
    ctx.fill(rgba(8, 12, 24, .6)); ctx.rr(m, ty - .01 * U, .5 * U, .085 * U, .015 * U); ctx.fillPath();
    TB(upper(C.nm) + "  |  OVR " + istr(proOvr()), m + .02 * U, ty + .015 * U, .022, "#fff");
    std::string nx = C.phase == "over" ? "OFF-SEASON: THE DOOR STARTS NEXT SEASON" : C.need ? "CONTRACT EXPIRED: SEE GM CONNECT" : offDay() ? "OFF DAY  |  TRAIN OR REST" : userHurt() ? "INJURED  |  OUT " + istr(youMe()->inj) : "NEXT: VS " + upper(C.L[C.opp].n);
    TF(nx, m + .02 * U, ty + .05 * U, .016, .46 * U, "#cbd5e1"); TB("$" + fmtN(C.money), W - m, ty + .015 * U, .03, "#ffd54a", AL_RIGHT);
    if (aptBuild) { ctx.fill(rgba(217, 119, 6, .9)); ctx.rr(W / 2 - .17 * U, ty - .01 * U, .34 * U, .05 * U, .012 * U); ctx.fillPath(); TB("BUILD MODE", W / 2, ty + .015 * U, .024, "#fff", AL_CENTER); }
    std::string pr; if (lk == APT_DOOR) pr = "X  FRONT DOOR"; else if (lk == APT_SHELF) pr = "X  TROPHY SHELF";
    else if (aptBuild && lk >= 0 && lk < HOME_NC) pr = "X  UPGRADE " + std::string(HOME_CAT[lk]) + "  (" + HOME_OPT[lk][HOME.sel[lk]].n + ")";
    if (!pr.empty()) { ctx.font(.022 * U); double tw = ctx.measure(pr) + .04 * U; ctx.fill(rgba(8, 12, 24, .82)); ctx.rr(W / 2 - tw / 2, H / 2 + .05 * U, tw, .05 * U, .025 * U); ctx.fillPath(); TB(pr, W / 2, H / 2 + .075 * U, .022, "#ffd54a", AL_CENTER); }
    // the phone, peeking out: tap it
    double pw = .07 * U, ph = .12 * U, px = W - m - pw, py = H - ph + .02 * U; ctx.fill("#0a0a0c"); ctx.rr(px, py, pw, ph, .014 * U); ctx.fillPath(); ctx.fill(hex(teamCol(C.me))); ctx.rr(px + 3, py + 3, pw - 6, ph - 6, .011 * U); ctx.fillPath();
    T("SELECT", px + pw / 2, py + .03 * U, .012, "#fff", AL_CENTER, 800);
    T(std::string("L-STICK MOVE   R-STICK LOOK   X USE   D-PAD LEFT ") + (aptBuild ? "EXIT BUILD" : "BUILD MODE"), m, H - .03 * U, .0145, "#e2e8f0", AL_LEFT, 700);
  }
  std::string msg = now() - aptToastT < 3200 ? aptToast : !C.wkMsg.empty() ? C.wkMsg : !C.injMsg.empty() ? C.injMsg : proMsg;
  if (!msg.empty() && aptOv != "door") { double px = std::min(.02 * U, (W - .06 * U) / std::max<size_t>(1, msg.size()) * 1.7); ctx.font(px); double tw = ctx.measure(msg) + .04 * U, my = safeTop + .1 * U;
    ctx.fill(rgba(8, 12, 24, .9)); ctx.rr(W / 2 - tw / 2, my, tw, .036 * U, .018 * U); ctx.fillPath(); ctx.fill("#ffd54a"); ctx.textMid(); ctx.fillText(msg, W / 2, my + .018 * U); }
  if (aptOv == "door") drawDoor(); else if (aptOv == "store") drawPhoneStore(); else if (phOn) drawPhoneGrid();
}
// the pad and touch in the apartment (the menus take over when the phone or a panel is up)
bool proAptInput(uint32_t press, const Pad &pad, const Touch &touch) {
  if (mode != "pro" || !CR || modal.on) return false;
  bool inHome = screen == "main" || phApp >= 0;
  if (inHome && (press & B_SELECT) && C.phase != "retired") {
    if (proAptWorld()) { phOn = true; phT0 = now(); mFocus = "app:" + istr(phLast); mPadUsed = true; }
    else { phOn = false; phApp = -1; aptOv.clear(); screen = "main"; }
    return true; }
  if (!proAptWorld()) { aptLastT = now(); return false; }
  double t = now(), dt = clamp((t - aptLastT) / 1000, 0, .05); aptLastT = t;
  Touch tt = touch; tt.n = 0; static int phTid = -1; bool tapPh = false;
  for (int i = 0; i < touch.n; i++) { const TouchPt &p = touch.p[i]; bool onPh = p.x > W - .12 * U && p.y > H - .14 * U;
    if (onPh && p.id != phTid) { phTid = p.id; tapPh = true; } else if (!onPh && tt.n < 6) tt.p[tt.n++] = p; }
  if (!touch.n) phTid = -1;
  if (tapPh) { phOn = true; phT0 = now(); mFocus = "app:" + istr(phLast); return true; }
  aptMove(pad, tt, dt);
  if (press & B_LEFT) { aptBuild = !aptBuild; toast(aptBuild ? "BUILD MODE: LOOK AT SOMETHING AND PRESS X" : "BUILD MODE OFF"); }
  if (press & B_CROSS) { int lk = aptLook();
    if (lk == APT_DOOR) { aptOv = "door"; mPadUsed = true; mFocus = ""; }
    else if (lk == APT_SHELF) { int a = C.titles, b = C.calder; toast(a + b ? istr(a) + (a == 1 ? " STANLEY CUP" : " STANLEY CUPS") + "  |  " + istr(b) + (b == 1 ? " CALDER CUP" : " CALDER CUPS") : "AN EMPTY SHELF. GO WIN SOMETHING."); }
    else if (aptBuild && lk >= 0 && lk < HOME_NC) { aptOv = "store"; storeCat = lk; phT0 = now(); mPadUsed = true; mFocus = "hb:" + istr(lk) + ":" + istr(HOME.sel[lk]); } }
  return true;
}
static bool aptTap(const std::string &id) {
  if (id == "ph:close") { if (phApp >= 0) { phApp = -1; screen = "main"; } else if (!aptOv.empty()) aptOv.clear(); else phOn = false; return true; }
  if (id == "ad:close") { aptOv.clear(); return true; }
  if (pre(id, "app:")) { int i = atoi(id.c_str() + 4); phLast = i; phApp = i;
    static const char *S[8] = {"sched", "health", "upg", "train", "office", "shop", "stand", "msgs"}; screen = S[i];
    if (i == 0) schedPg = -1; if (i == 6) { standLg = proLg(); standTab = 7; } mFocus = ""; return true; }
  if (pre(id, "hb:")) { int c = atoi(id.c_str() + 3), i = atoi(id.c_str() + id.rfind(':') + 1); int r = homeBuy(c, i);
    toast(r == 1 ? "BOUGHT: " + std::string(HOME_OPT[c][i].n) : r == 2 ? "SWAPPED IN: " + std::string(HOME_OPT[c][i].n) : "NOT ENOUGH CASH"); return true; }
  if (aptOv == "door") { if (id == "off:neg") { aptOv.clear(); phOn = true; phApp = 4; return false; } if (id == "nav:train") { aptOv.clear(); phOn = true; phApp = 3; return false; }
    if (id == "play" || id == "sim1" || id == "simN" || id == "simheal" || id == "skipday" || id == "next" || id == "nav:modes") aptOv.clear(); }
  if (id == "nav:modes") { phOn = false; phApp = -1; aptOv.clear(); aptUnload(); }
  if (id == "play") aptUnload();
  return false;
}
// the career screens that live on the phone
static void (*phoneScreen())() {
  if (screen == "sched") return drawSched; if (screen == "health") return drawHealth; if (screen == "upg") return drawUpg; if (screen == "train") return drawTrain;
  if (screen == "office") return drawOffice; if (screen == "neg") return drawNeg; if (screen == "ntc") return drawNtc; if (screen == "treq") return drawTreq; if (screen == "toff") return drawOffers;
  if (screen == "trade") return drawTradeAlert; if (screen == "shop") return drawShop; if (screen == "stand") return drawStand; if (screen == "msgs") return drawMsgs;
  return nullptr;
}

// ---------------------------------------------------------------- the router
void proEnter() {
  CR.reset(); proSlot = -1; mode = "pro"; screen = "proslots"; phOn = false; phApp = -1; aptOv.clear(); aptBuild = false;
  // a one-time test file in slot 3 with money to spend in the apartment; once deleted it's an ordinary slot
  aptUnload();
  if (!homeTestMade()) { homeSetTestMade(); if (!proSlotInfo(2).on) { proNew(2, "TEST", 19, 1); C.money = 100000; C.draftDone = true; proSave(); CR.reset(); proSlot = -1; } }
}
void proContinue(int i) { proEnter(); proLoadSlot(i); if (CR) { setLast("pro", i); screen = !C.draftDone ? "draft" : C.phase == "retired" ? "retired" : "main"; draftT0 = now(); aptReset(); } }
void drawPro() {
  if (screen == "proslots") { drawSlots(); return; }
  if (screen == "pronew") { drawNew(); return; }
  if (!CR) { screen = "proslots"; drawSlots(); return; }
  if (C.phase == "retired" && screen != "retired") screen = "retired";
  if (phApp >= 0 || (phOn && screen != "main")) { auto fn = phoneScreen(); if (fn) { if (phApp < 0) phApp = 4; drawInPhone(fn); return; } phApp = -1; phOn = false; }
  if (screen == "draft") drawDraft();
  else if (screen == "upg") drawUpg();
  else if (screen == "train") drawTrain();
  else if (screen == "shop") drawShop();
  else if (screen == "office") drawOffice();
  else if (screen == "neg") drawNeg();
  else if (screen == "ntc") drawNtc();
  else if (screen == "treq") drawTreq();
  else if (screen == "toff") drawOffers();
  else if (screen == "trade") drawTradeAlert();
  else if (screen == "sched") drawSched();
  else if (screen == "stand") drawStand();
  else if (screen == "retired") drawRetired();
  else if (screen == "busy") drawBusy();
  else if (screen == "aptload") drawAptLoad();
  else { screen = "main"; if (!aptReady()) { loadF = 0; screen = "aptload"; drawAptLoad(); } else drawApt(); }
}
void proShoulder(int d) {
  if (screen == "upg") upTab = (upTab + 2 + d) % 2;
  else if (screen == "shop") shopCat = (shopCat + (int)GEARF.size() + d) % (int)GEARF.size();
  else if (screen == "stand") standTab = (standTab + 9 + d) % 9;
  else if (screen == "sched") schedPg = std::max(0, schedPg + d);
}
bool proTap(const std::string &id) {
  if (mode != "pro") return false;
  if (screen != "main" && CR) { C.wkMsg.clear(); C.injMsg.clear(); }
  if (pre(id, "pslot:")) { int i = atoi(id.c_str() + 6); if (proSlotInfo(i).on) proContinue(i);
    else { nameTarget = i; nameFor = "pro"; pname = ""; screen = "name"; } return true; }
  if (pre(id, "pdel:")) { int i = atoi(id.c_str() + 5); askModal("DELETE FILE " + istr(i + 1) + "?", "ARE YOU SURE? " + upper(proSlotInfo(i).nm) + "'s career will be gone for good.", [i] { proDelete(i); mFocus = "pslot:" + istr(i); }); return true; }
  if (id == "pncancel") { screen = "proslots"; return true; }
  if (pre(id, "pnum:")) { int d = atoi(id.c_str() + 5); pendNum = ((pendNum - 1 + d) % 99 + 99) % 99 + 1; return true; }
  if (pre(id, "pdiff:")) { pendDiff = atoi(id.c_str() + 6); return true; }
  if (id == "ppos:F") return true;
  if (id == "pgo") { std::string nm = pname; while (!nm.empty() && nm.back() == ' ') nm.pop_back(); if (nm.empty()) nm = "ROOKIE"; proNew(nameTarget, nm, pendNum, pendDiff); setLast("pro", nameTarget); screen = "draft"; draftT0 = now(); return true; }
  if (!CR) return false;
  if (aptTap(id)) return true;
  if (id == "draftdone") { C.draftDone = true; screen = "main"; proSave(); return true; }
  if (id == "ptradeok") { C.showTrade = false; C.hasTrade = false; screen = C.need ? "office" : "main"; proSave(); return true; }
  if (id == "pnewc") { nameTarget = proSlot; nameFor = "pro"; pname = ""; screen = "name"; return true; }
  if (id == "sim1") { proSimGames(1); return true; }
  if (id == "simN") { proSimGames(C.phase == "po" ? 5 : 10); return true; }
  if (id == "simheal") { proSimHealthy(); return true; }
  if (id == "skipday") { proSkipDay(); return true; }
  if (id == "next") { screen = "busy"; busyF = 0; return true; }
  if (pre(id, "train:")) { proDoTrain(atoi(id.c_str() + 6)); screen = "main"; return true; }
  if (pre(id, "utab:")) { upTab = atoi(id.c_str() + 5); return true; }
  if (pre(id, "up1:")) { proUpgrade(id.substr(4), 1); return true; }
  if (pre(id, "up5:")) { proUpgrade(id.substr(4), 5); return true; }
  if (pre(id, "pbuy:")) { pkBuy(id.substr(5)); return true; }
  if (pre(id, "pup:")) { pkUp(id.substr(4)); return true; }
  if (pre(id, "peq:")) { pkEquip(id.substr(4)); return true; }
  if (pre(id, "gcat:")) { shopCat = atoi(id.c_str() + 5); return true; }
  if (pre(id, "gear:")) { std::string r = id.substr(5); size_t c = r.find(':'); gearTap(r.substr(0, c), atoi(r.c_str() + c + 1)); return true; }
  if (pre(id, "stab:")) { standTab = atoi(id.c_str() + 5); return true; }
  if (id == "sch:-") { schedPg--; return true; } if (id == "sch:+") { schedPg++; return true; }
  if (id == "nav:sched") { schedPg = -1; screen = "sched"; return true; }
  if (id == "nav:stand") { standLg = proLg(); standTab = C.phase == "po" || C.phase == "over" ? 8 : C.L[C.me].d; screen = "stand"; return true; }
  if (pre(id, "slg:")) { standLg = atoi(id.c_str() + 4) ? 1 : 0; if (standLg && CR->L.size() < (size_t)NALL) standLg = 0; return true; }
  if (id == "off:neg") { if (!C.hasNeg || C.neg.forced != C.need) negStart(C.need); screen = "neg"; return true; }
  if (id == "neg:y-") { C.neg.yrs = std::max(1, C.neg.yrs - 1); return true; }
  if (id == "neg:y+") { C.neg.yrs = std::min(5, C.neg.yrs + 1); return true; }
  if (id == "neg:ntc") { C.neg.ntc = !C.neg.ntc; return true; }
  if (id == "neg:push") { negPush(); return true; }
  if (id == "neg:ok") { negAccept(); screen = "office"; return true; }
  if (id == "neg:walk") { if (C.neg.forced) { if (C.neg.sure) { proFreeAgency(); screen = "trade"; proSave(); } else C.neg.sure = true; } else { C.hasNeg = false; screen = "office"; } return true; }
  if (pre(id, "ntc:")) { askNTC(id == "ntc:1"); screen = "office"; return true; }
  if (id == "nav:treq") { tqSel = C.hasTreq ? C.treqT : std::vector<int>(); screen = "treq"; return true; }
  if (pre(id, "tq:")) { std::string k = id.substr(3); if (k == "go") { submitTradeReq(tqSel); screen = "office"; } else if (k == "clr") tqSel.clear();
    else { int t = atoi(k.c_str()); auto it = std::find(tqSel.begin(), tqSel.end(), t); if (it != tqSel.end()) tqSel.erase(it); else if (tqSel.size() < 10) tqSel.push_back(t); } return true; }
  if (pre(id, "tof:")) { int i = atoi(id.c_str() + 6); if (id[4] == 'a') acceptOffer(i); else rejectOffer(i); return true; }
  if (id == "nav:main") { screen = "main"; return true; }
  return false;
}
#undef C

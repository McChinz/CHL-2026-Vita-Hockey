// CHL 2026 native - players and ratings (see league.h). Ported from the legacy build.
#include "league.h"
#include "data.h"

// ---------------------------------------------------------------- random numbers
SkRng *g_seeded = nullptr;
double rnd() { return g_seeded ? (*g_seeded)() : g_rng.next(); }
void withSeed(int seed, const std::function<void()> &fn) {
  SkRng R(seed); R(); R(); SkRng *prev = g_seeded; g_seeded = &R;
  fn();
  g_seeded = prev;
}

// ---------------------------------------------------------------- perks
const PerkDef PERKS[PK_N] = {
  {"onetouch", "ONE TOUCH WONDER", "1T", 'F', "#38bdf8", "pass", {80, 88, 95}, PKK_USE, {3, 4, 5}, {0, 0, 0}, false, 600, "Long passes, passes through traffic and feeds into the zone are dead accurate and bend to the stick", {"smart passes 60% tighter, a little bend", "85% tighter, a strong bend", "perfect, bent right onto the tape"}},
  {"otking", "ONE TIMER KING", "OT", 'F', "#f97316", "spow", {80, 88, 95}, PKK_USE, {3, 4, 5}, {0, 0, 0}, false, 700, "One-timers in range come off harder, and a save can kick the rebound to a teammate", {"+15% power, 40% of saves go to a teammate", "+25% power, 70% of saves go to a teammate", "+35% power, every save goes to a teammate"}},
  {"demon", "SPEED DEMON", "SD", 'F', "#ef4444", "skate", {82, 89, 96}, PKK_USE, {3, 4, 5}, {0, 0, 0}, false, 600, "Keep holding sprint with the puck (or chasing it) and keep getting faster", {"sprinting builds to +10% speed", "builds to +16% speed", "builds to +22% speed"}},
  {"flick", "FLICK OF THE WRIST", "FW", 'F', "#a78bfa", "wpow", {84, 90, 96}, PKK_USE, {3, 4, 5}, {0, 0, 0}, false, 600, "Wrist shots in the zone come off lightning quick and are hard to read", {"zone wristers +15% speed", "+25% speed, harder to read", "+35% speed, much harder to read"}},
  {"eyes", "EYES ON THE PRIZE", "EP", 'F', "#22c55e", "hand", {80, 88, 95}, PKK_USE, {3, 4, 5}, {0, 0, 0}, false, 500, "Poke checks are more effective (a use only counts when it wins the puck)", {"poke checks 15% stronger", "25% stronger", "35% stronger"}},
  {"freight", "FREIGHT TRAIN", "FT", 'F', "#d97706", "check", {82, 89, 96}, PKK_USE, {1, 1, 1}, {0, 0, 0}, false, 750, "A hit on the puck carrier can knock him out: 3 on 2 for 30s (once a game)", {"6% of hits on the carrier knock him out", "10% of hits on the carrier", "15% of hits on the carrier"}},
  {"wall", "IMMOVABLE", "IM", 'F', "#94a3b8", "poise", {82, 89, 96}, PKK_USE, {3, 4, 5}, {0, 0, 0}, false, 600, "Stays on his feet through a hit that would flatten him, and holds the puck more", {"50% chance to stay up on a big hit", "75% chance to stay up", "never knocked down"}},
  {"lungs", "IRON LUNGS", "IL", 'F', "#14b8a6", "fstam", {82, 89, 96}, PKK_PAS, {3, 4, 5}, {0, 0, 0}, false, 500, "Always on: energy drains slower and refills faster on the bench", {"-15% drain, +10% rest", "-23% drain, +20% rest", "-30% drain, +30% rest"}},
  {"dangle", "DANGLER", "DG", 'F', "#ec4899", "deke", {82, 89, 96}, PKK_USE, {3, 4, 5}, {0, 0, 0}, false, 600, "A poke that would take the puck mid-deke misses; dekes recharge faster", {"60% of mid-deke pokes miss, dekes 20% quicker", "80% miss, dekes 35% quicker", "every one misses, dekes twice as quick"}},
  {"leather", "FLASH OF LEATHER", "FL", 'G', "#facc15", "glv", {84, 90, 96}, PKK_CD, {0, 0, 0}, {75, 55, 40}, false, 700, "Glove saves are held more; off cooldown he can steal a glove-side goal", {"60% of glove saves held, 40% steal, 75s", "80% held, 55% steal, 55s recharge", "all held, 70% steal, 40s recharge"}},
  {"stpaul", "WALL OF ST. PAUL", "SP", 'G', "#cbd5e1", "chs", {82, 89, 95}, PKK_PAS, {0, 0, 0}, {0, 0, 0}, false, 600, "Always on: more chest saves, and pucks off the chest get smothered", {"chest saves +3%, 70% smothered", "+5%, 85% smothered", "+8%, always smothered"}},
  {"robber", "ROBBERY", "RB", 'G', "#e11d48", "agi", {84, 90, 96}, PKK_CD, {0, 0, 0}, {90, 65, 45}, false, 750, "Off cooldown, a shot that beat him can be robbed with a desperation save", {"35% chance to rob a goal, 90s recharge", "50% chance, 65s recharge", "65% chance, 45s recharge"}},
  {"reset", "QUICK RESET", "QR", 'G', "#0ea5e9", "rec", {82, 89, 95}, PKK_PAS, {0, 0, 0}, {0, 0, 0}, false, 550, "Always on: less slow-down between saves", {"40% less slow-down between saves", "70% less slow-down", "no slow-down at all"}},
  {"ironman", "IRON MAN", "IR", 'G', "#a8a29e", "sta", {82, 89, 95}, PKK_PAS, {0, 0, 0}, {0, 0, 0}, false, 500, "Always on: tires slower", {"tires 20% slower", "tires 35% slower", "tires half as fast"}},
  {"padlock", "FIVE-HOLE LOCK", "5H", 'G', "#3b82f6", "pad", {82, 89, 95}, PKK_PAS, {0, 0, 0}, {0, 0, 0}, false, 550, "Always on: the five-hole stays shut more and low shots are easier", {"five-hole shut 50% more, low shots +2%", "shut 75% more, low +3.5%", "always shut, low shots +5%"}},
  {"cross", "CROSSHAIR", "CH", 'G', "#f472b6", nullptr, {0, 0, 0}, PKK_PAS, {0, 0, 0}, {0, 0, 0}, true, 500, "Yours only: 35% of shots show where they will cross your crease", {"", "", ""}}};
const Col TIERC[4] = {hex("#64748b"), hex("#cd7f32"), hex("#cbd5e1"), hex("#facc15")};
const char *TIERN[4] = {"", "BRONZE", "SILVER", "GOLD"};
int perkIndex(const std::string &id) { for (int i = 0; i < PK_N; i++) if (id == PERKS[i].id) return i; return -1; }
int pkTierOf(const PerkDef &pk, const std::function<int(const std::string &)> &rt) {
  if (!pk.k) return 3; int v = rt(pk.k), t = 0; for (int i = 0; i < 3; i++) if (v >= pk.rq[i]) t = i + 1; return t;
}
// the perks a CPU player or a card carries: a fixed roll per player decides whether each open slot is used,
// then the perks he leans toward (also fixed per player) among the ones his ratings reach, best tiers first
std::vector<PerkE> pkAuto(const std::function<int(const std::string &)> &rt, int ov, bool g, const std::string &seed) {
  std::vector<PerkE> o; int n = pkSlots(ov); if (!n) return o;
  int h = skHash(seed + "|pk"), m = ((h % 100) < (n >= 2 ? 70 : g ? 50 : 42) ? 1 : 0) + (n >= 2 && ((h >> 7) % 100) < 65 ? 1 : 0);
  if (!m) return o;
  struct C { int id, t; double w; }; std::vector<C> c;
  for (int i = 0; i < PK_N; i++) { const PerkDef &p = PERKS[i]; if (p.user || p.pos != (g ? 'G' : 'F')) continue;
    int t = pkTierOf(p, rt); if (t > 0) c.push_back({i, t, (skHash(seed + "|" + p.id) % 1000) / 1000.0}); }
  std::stable_sort(c.begin(), c.end(), [](const C &a, const C &b) { return (b.w + b.t * .12) < (a.w + a.t * .12); });
  for (int i = 0; i < (int)c.size() && i < m; i++) o.push_back({c[i].id, c[i].t});
  return o;
}
std::vector<PerkE> pkOfSrc(const Src *q) {
  if (!q) return {}; Ratings r = skRatings(q);
  return pkAuto([&](const std::string &k) { return r.get(k); }, ovSk(q), false, !q->pkSeed.empty() ? q->pkSeed : !q->nm.empty() ? q->nm : "?");
}
std::vector<PerkE> pkOfG(const GSrc *g) {
  if (!g) return {}; GS s = gStats(g);
  return pkAuto([&](const std::string &k) { return (int)s.get(k); }, (int)s.ovr, true, !g->pkSeed.empty() ? g->pkSeed : !g->nm.empty() ? g->nm : "g");
}

// ---------------------------------------------------------------- rating keys and names
const char *FKEYS[13] = {"skate", "edge", "sacc", "wpow", "slacc", "spow", "pass", "hand", "deke", "fo", "check", "poise", "fstam"};
const char *BHKEYS[2] = {"bhp", "bha"};
const char *UT_SK[13] = {"skate", "edge", "sacc", "wpow", "slacc", "spow", "pass", "hand", "deke", "fo", "check", "poise", "fstam"};
const char *UT_GK[8] = {"agi", "glv", "blk", "pad", "chs", "sta", "rec", "rd"};
std::string FNICE(const std::string &k) {
  static const std::map<std::string, std::string> M = {{"bhp", "BACKHAND POWER"}, {"bha", "BACKHAND ACCURACY"}, {"skate", "SPEED"}, {"edge", "EDGE WORK"}, {"deke", "DEKING"}, {"pass", "PASSING"}, {"sacc", "WRIST ACCURACY"}, {"wpow", "WRIST POWER"},
    {"slacc", "SLAP ACCURACY"}, {"spow", "SLAP POWER"}, {"fstam", "STAMINA"}, {"check", "CHECKING"}, {"poise", "POISE"}, {"hand", "STICKHANDLING"}, {"fo", "FACEOFFS"}};
  auto it = M.find(k); return it == M.end() ? k : it->second;
}
std::string UT_GN(const std::string &k) {
  static const std::map<std::string, std::string> M = {{"agi", "REFLEXES"}, {"glv", "GLOVE"}, {"blk", "BLOCKER"}, {"pad", "LEG PADS"}, {"chs", "CHEST"}, {"sta", "STAMINA"}, {"rec", "RECOVERY"}, {"rd", "SHOT READ"}};
  auto it = M.find(k); return it == M.end() ? k : it->second;
}
int Ratings::get(const std::string &k) const {
  if (k == "skate") return skate; if (k == "edge") return edge; if (k == "deke") return deke; if (k == "pass") return pass; if (k == "sacc") return sacc;
  if (k == "wpow") return wpow; if (k == "slacc") return slacc; if (k == "spow") return spow; if (k == "fstam") return fstam; if (k == "check") return check;
  if (k == "poise") return poise; if (k == "hand") return hand; if (k == "fo") return fo; if (k == "bhp") return bhp; if (k == "bha") return bha;
  return 0;
}
void Ratings::set(const std::string &k, int v) {
  if (k == "skate") skate = v; else if (k == "edge") edge = v; else if (k == "deke") deke = v; else if (k == "pass") pass = v; else if (k == "sacc") sacc = v;
  else if (k == "wpow") wpow = v; else if (k == "slacc") slacc = v; else if (k == "spow") spow = v; else if (k == "fstam") fstam = v; else if (k == "check") check = v;
  else if (k == "poise") poise = v; else if (k == "hand") hand = v; else if (k == "fo") fo = v; else if (k == "bhp") bhp = v; else if (k == "bha") bha = v;
}
double GS::get(const std::string &k) const {
  if (k == "agi") return agi; if (k == "glv") return glv; if (k == "blk") return blk; if (k == "pad") return pad; if (k == "chs") return chs;
  if (k == "sta") return sta; if (k == "rec") return rec; if (k == "rd") return rd; if (k == "ovr") return ovr; return 0;
}
int ovOf(const Ratings &r) { return (int)jround((r.skate + r.edge + r.sacc + r.wpow + r.slacc + r.spow + r.pass + r.hand + r.deke + r.fo + r.check + r.poise + r.fstam) / 13.0); }

// ---------------------------------------------------------------- you
J g_stats;
void statsDefaults(J &st) {
  const char *k50[] = {"reflex", "strafe", "pressure", "stamina", "recovery", "glove", "legpad", "chest", "blocker", "skate", "pass", "sacc", "wpow", "slacc", "spow", "fstam", "check", "poise", "hand", "fo", "edge", "deke"};
  if (!st.isObj()) st = J::obj();
  if (!st.has("bhp")) st["bhp"] = 46; if (!st.has("bha")) st["bha"] = 46;
  for (auto k : k50) if (!st.has(k)) st[k] = 50;
}
double gearPts(const std::string &) { return 0; }   // career gear: comes with Be a Pro
static int stOf(const std::string &k) { const J *v = g_stats.get(k); return v ? v->i(50) : 50; }
Ratings userRatings() {
  Ratings r; for (auto k : FKEYS) r.set(k, stOf(k));
  r.bhp = g_stats.has("bhp") && g_stats("bhp").i() ? stOf("bhp") : (int)jround(stOf("wpow") * .88);
  r.bha = g_stats.has("bha") && g_stats("bha").i() ? stOf("bha") : (int)jround(stOf("sacc") * .88);
  return r;
}
double uAttr(const std::string &k) { return 3.5 + (clamp(stOf(k) + gearPts(k), 40, 104) - 50) * 6.5 / 49; }
char g_meSh = 'L';
std::function<double()> g_leagueAdj;
GS userGS() {
  GS g; g.agi = stOf("reflex"); g.glv = stOf("glove"); g.blk = stOf("blocker"); g.pad = stOf("legpad"); g.chs = stOf("chest"); g.sta = stOf("stamina"); g.rec = stOf("recovery"); g.rd = 70;
  g.ovr = jround((stOf("reflex") + stOf("strafe") + stOf("pressure") + stOf("stamina") + stOf("recovery") + stOf("glove") + stOf("legpad") + stOf("chest") + stOf("blocker")) / 9.0);
  return g;
}

// ---------------------------------------------------------------- archetypes and traits
const char *ARK[6] = {"BALANCED", "SNIPER", "SLAPPER", "PLAYMAKER", "FINISHER", "POWER"};
const char *ARN[6] = {"BALANCED", "SNIPER", "CANNON", "PLAYMAKER", "FINISHER", "POWER"};
static const double AR_PASS[6] = {1, .8, .8, 2.2, .9, .7}, AR_WR[6] = {1, 1.7, .7, 1, .9, 1.1}, AR_SL[6] = {1, .5, 2.3, .6, .7, 1.5}, AR_OT[6] = {1, 1, .9, 1.5, 2.6, 1.1};
static const double AR_SP[6][3] = {{1, 1, 1}, {1, .95, 1}, {.97, 1.2, 1}, {.96, .95, 1}, {1, 1, 1.15}, {1.1, 1.12, 1.1}};
static const double AR_AC[6][3] = {{0, 0, 0}, {2.2, -.3, .5}, {-.4, -1.4, 0}, {.5, 0, .8}, {0, -.3, 2}, {-.7, -.9, -.5}};
static Arch pickAr(int pref) {
  if (pref >= 0 && rnd() < .45) return (Arch)pref;
  const int w[6] = {30, 15, 15, 15, 12, 13}; double r = rnd() * 112;
  for (int k = 0; k < 6; k++) { r -= w[k]; if (r <= 0) return (Arch)k; }
  return AR_BALANCED;
}
// the same draws, in the same order, as the legacy ensureTraits (a player made from a seed comes out identical)
void ensureTraits(Src &q, int pref) {
  if (!q.hasAr) { q.ar = pickAr(pref); q.hasAr = true; }
  if (!q.hasTv) { for (int i = 0; i < 3; i++) q.tv[i] = rand(.94, 1.06); for (int i = 0; i < 3; i++) q.ta[i] = rand(-.6, .6); q.hasTv = true; }
  if (!q.hasFx) {
    auto r = [] { return rand(-1.6, 1.6); };
    Fx &f = q.fx; f.spd = r(); f.pass = r(); f.sacc = r(); f.spow = r(); f.wpow = r(); f.lacc = r(); f.stam = r() * .6; f.fo = r();
    double c = r(); f.chk = c + (rnd() < .15 ? 1.8 : 0); f.hand = r(); f.hasW = f.hasL = true; q.hasFx = true;
  }
}
Profile profile(Src &q) {
  ensureTraits(q); int a = q.ar; double pw = q.p ? q.p : 3; Profile P;
  P.fq[0] = AR_PASS[a]; P.fq[1] = AR_WR[a]; P.fq[2] = AR_SL[a] * (.25 + .04 * pw); P.fq[3] = AR_OT[a];
  for (int i = 0; i < 3; i++) { P.spd[i] = AR_SP[a][i] * q.tv[i]; P.acc[i] = AR_AC[a][i] + q.ta[i]; }
  return P;
}
Size skSize(const Src *s) {
  if (s && s->me) return {72, 195};
  const std::string nm = s && !s->nm.empty() ? s->nm : "x"; auto h = [&](const char *k) { return (skHash(nm + k) % 1000) / 1000.0; };
  Arch ar = s && s->hasAr ? s->ar : AR_BALANCED;
  double big = ar == AR_POWER ? 1 : ar == AR_SLAPPER ? .5 : (ar == AR_SNIPER || ar == AR_PLAYMAKER) ? -.6 : 0;
  int ht = (int)jround(clamp(72.6 + big * 1.4 + (h("ht") + h("ht2") - 1) * 4.6, 67, 79));
  int wt = (int)jround(clamp(192 + (ht - 72.6) * 6.5 + big * 10 + (h("wt") + h("wt2") - 1) * 26, 165, 245));
  return {ht, wt};
}
std::string fmtHt(int i) { return istr(i / 12) + "'" + istr(i % 12) + "\""; }
Raw skRaw(const Src *src) {
  static Src dflt; if (!src) { dflt = Src(); src = &dflt; } else ensureTraits(const_cast<Src &>(*src));
  const Src &s = *src; Arch ar = s.hasAr ? s.ar : AR_BALANCED; const Fx &f = s.fx;
  const std::string nm = s.nm.empty() ? "x" : s.nm;
  auto hv = [&](const char *k) { return ((skHash(nm + k) % 1000) / 1000.0 - .5) * 2; };
  Size Z = skSize(src); double bw = (Z.wt - 195) / 25.0, bh = (Z.ht - 72.6) / 3;
  auto C10 = [](double v) { return clamp(v, 1, 10); };
  bool PM = ar == AR_PLAYMAKER, SNP = ar == AR_SNIPER, PW = ar == AR_POWER, SL = ar == AR_SLAPPER, FI = ar == AR_FINISHER;
  Raw r;
  r.spd = C10((s.p + s.a) / 2 + (PW ? .8 : 0) + (PM ? .3 : 0) + f.spd + hv("spd") * 1.7);
  r.agl = C10((s.p + s.a) / 2 + (PM || SNP ? .8 : 0) - (PW ? .9 : 0) + hv("agl") * 2.2);
  r.deke = C10(s.a * .65 + s.p * .2 + 1 + (PM || SNP ? .9 : 0) - (PW ? .5 : 0) + hv("dk") * 1.8);
  r.pass = C10(s.a + (PM ? 1.3 : 0) + f.pass);
  r.wacc = C10(s.a + (SNP ? 1 : 0) + (FI ? .6 : 0) + f.sacc);
  r.wpow = C10(s.p * .5 + s.a * .5 + (SNP ? .5 : 0) + (FI ? .5 : 0) + (f.hasW ? f.wpow : f.spow * .6));
  r.lacc = C10(s.a * .5 + s.p * .4 + .6 + (SL ? 1 : 0) + (f.hasL ? f.lacc : f.sacc * .6));
  r.spow = C10(s.p + (SL ? 1.2 : 0) + (PW ? .6 : 0) + f.spow);
  r.chk = C10(s.p * .75 + 1 + (PW ? 1.2 : 0) + (SL ? .4 : 0) + f.chk + bw * .9 + bh * .25);
  r.poise = C10(s.p * .42 + s.a * .22 + 1.9 + (PW ? .8 : 0) + bw * 1.15 + bh * .35 + hv("po") * 1.3);
  r.hand = C10(s.a * .6 + s.p * .2 + 1 + (PM || SNP ? 1 : 0) + f.hand);
  r.stam = C10(2 + (s.p + s.a) / 3 + f.stam + hv("stm") * 2.4);
  r.fo = C10(s.a * .5 + s.p * .3 + 1.5 + (PM ? .8 : 0) + f.fo);
  return r;
}
double rt2at(double v) { return 3.5 + (v - 50) / 49 * 6.5; }
int at2rt(double a) { return (int)jround(clamp(50 + (a - 3.5) / 6.5 * 49, 40, 99)); }
Ratings skRatings(const Src *q) {
  if (q && q->me) return userRatings();
  if (q && q->hasRt) return q->rt;
  Raw a = skRaw(q); int j = skHash((q && !q->nm.empty() ? q->nm : std::string("x")) + "bh");
  Ratings r;
  r.bhp = at2rt(clamp(a.wpow * .82 + ((j % 17) - 8) * .09, 1, 10)); r.bha = at2rt(clamp(a.wacc * .82 + (((j >> 5) % 17) - 8) * .09, 1, 10));
  r.skate = at2rt(a.spd); r.edge = at2rt(a.agl); r.deke = at2rt(a.deke); r.pass = at2rt(a.pass); r.sacc = at2rt(a.wacc); r.wpow = at2rt(a.wpow);
  r.slacc = at2rt(a.lacc); r.spow = at2rt(a.spow); r.fstam = at2rt(a.stam); r.check = at2rt(a.chk); r.poise = at2rt(a.poise); r.hand = at2rt(a.hand); r.fo = at2rt(a.fo);
  return r;
}
int ovSk(const Src *q) { return ovOf(skRatings(q)); }
// rate a real player: find the internal ratings that land on his real overall
void fitS(Src &s, int ov) {
  bool had = s.hasRt; s.hasRt = false;
  for (int k = 0; k < 8; k++) { double d = (ov - ovSk(&s)) / 49.0 * 6.5; if (std::fabs(d) < .02) break; s.p = clamp(s.p + d, 1, 10); s.a = clamp(s.a + d, 1, 10); }
  s.hasRt = had;
}
static const std::map<std::string, char> &shootMap() { static std::map<std::string, char> m; if (m.empty()) for (auto &q : SHOOTS) m[q.nm] = q.h; return m; }
char skShoots(const Src *q) {
  if (!q) return 'L'; if (q->me) return g_meSh;
  auto &m = shootMap(); auto it = m.find(q->nm); if (it != m.end()) return it->second;
  return skHash((q->nm.empty() ? std::string("x") : q->nm) + "|sh") % 100 < 62 ? 'L' : 'R';
}
Tend skTend(Src *q) {
  if (!q) return TD_REB;
  if (q->tend == TD_NONE) {
    Arch ar = q->hasAr ? q->ar : AR_BALANCED; double r = rnd(), w[2];
    if (ar == AR_POWER) { w[0] = .6; w[1] = .25; } else if (ar == AR_SNIPER || ar == AR_FINISHER) { w[0] = .2; w[1] = .2; }
    else if (ar == AR_PLAYMAKER) { w[0] = .2; w[1] = .35; } else if (ar == AR_SLAPPER) { w[0] = .3; w[1] = .45; } else { w[0] = .34; w[1] = .33; }
    q->tend = r < w[0] ? TD_CRASH : r < w[0] + w[1] ? TD_NET : TD_REB;
  }
  return q->tend;
}

// ---------------------------------------------------------------- goalies
const char *GARK[5] = {"ATHLETIC", "BUTTERFLY", "GLOVE HAND", "WALL", "HYBRID"};
static const double GAR[5][7] = {{9, 2, 0, -3, -3, 3, 5}, {-2, 0, 0, 9, 3, 0, 2}, {0, 10, -2, -2, 0, 0, 0}, {-5, 2, 6, 4, 8, 2, -3}, {2, 2, 2, 2, 2, 2, 2}};   // agi glv blk pad chs sta rec
static int garIndex(const std::string &g) { for (int i = 0; i < 5; i++) if (g == GARK[i]) return i; return 4; }
void ensureGTraits(GSrc &g) {
  if (!g.hasGo) { int a = (int)std::floor(rnd() * 5); const double *b = GAR[a]; g.gar = GARK[a];
    g.go[0] = b[0] + rand(-8, 8); g.go[1] = b[1] + rand(-8, 8); g.go[2] = b[2] + rand(-8, 8); g.go[3] = b[3] + rand(-8, 8);
    const double *b2 = GAR[garIndex(g.gar)]; g.go[4] = b2[4] + rand(-8, 8); g.go[5] = b2[5] + rand(-9, 9); g.go[6] = b2[6] + rand(-9, 9); g.hasGo = true; }
}
GS gStats(const GSrc *g) {
  GS r;
  if (!g) return r;
  if (g->hasGst) { r = g->gst; return r; }
  if (g->me) return userGS();
  GSrc &G = const_cast<GSrc &>(*g); ensureGTraits(G);
  double base = 32 + g->r * 7; auto c = [&](double v) { return jround(clamp(base + v, 40, 99)); }; const double *o = g->go;
  r.agi = c(o[0]); r.glv = c(o[1]); r.blk = c(o[2]); r.pad = c(o[3]); r.chs = c(o[4]); r.sta = c(o[5]); r.rec = c(o[6]);
  r.rd = c(g->hasRd ? o[7] : ((skHash((g->nm.empty() ? std::string("g") : g->nm) + "rd") % 19) - 9 + (o[0] + o[6]) / 2));
  r.ovr = jround((r.agi + r.glv + r.blk + r.pad + r.chs + r.sta + r.rec) / 7);
  return r;
}
void fitG(GSrc &g, int ov) { for (int k = 0; k < 6; k++) { double d = (ov - gStats(&g).ovr) / 7; if (std::fabs(d) < .03) break; g.r = clamp(g.r + d, .5, 9.9); } }

// ---------------------------------------------------------------- names
static const char *FN[] = {"Adam","Alex","Anton","Ben","Brady","Brock","Cole","Connor","Dylan","Eli","Emil","Erik","Evan","Filip","Gabe","Hugo","Isak","Jack","Jake","Jonas","Josh","Kai","Kasper","Leo","Liam","Lucas","Luke","Marco","Matt","Max","Mikko","Nick","Nils","Noah","Oliver","Oscar","Owen","Pavel","Quinn","Ryan","Sam","Sean","Theo","Tyler","Viktor","Will","Zach","Aaron","Carter","Dmitri","Henrik","Ivan","Jesper","Logan","Mason","Nolan","Pierre","Rasmus","Simon","Tomas"};
static const char *SN[] = {"Smith","Novak","Tremblay","Larsen","Brown","Petrov","Kowalski","Nyberg","Moreau","Bergman","Sato","Olsen","Fischer","Volkov","Hansen","Pavel","Cooper","Reid","Maki","Rossi","Walsh","Eriksson","Mercer","Hartley","Voss","Lindqvist","Haddad","Okafor","Doyle","Becker","Nakamura","Morrow","Vasquez","Kivi","Strand","Castro","Galloway","Whitlock","Pruitt","Abernathy","Okonkwo","Marek","Nilsson","Bolduc","Ferraro","Huang","Ristola","Varga","Sorensen","Novotny","Petersen","Ashby","Winslow","Dupont","Archer","Fitzgerald","Brennan","Chu","Patel","Yamada","Kowal","Ozolins","Lacroix",
  "Anders","Bishop","Carlsen","Draper","Egan","Gallo","Hayes","Isaksen","Jensen","Klein","Marsh","Nolan","Thorne","Underwood","Vance","Wolfe","Yates","Zeller","Baker","Chase","Flynn","Irwin","Judd","Knox","Lund","Ahlgren","Brandt","Corvo","Delaney","Ekstrom","Fallon","Grieve","Halvorsen","Ingram","Jarvinen","Kerr","Lavoie","Mattsson","Norlund","Ostby","Paquette","Rydell","Sjoberg","Toivonen","Ulmer","Vachon","Wexler"};
std::string genName() { int a = (int)std::floor(rnd() * (sizeof FN / sizeof *FN)); int b = (int)std::floor(rnd() * (sizeof SN / sizeof *SN)); return std::string(FN[a]) + " " + SN[b]; }

// ---------------------------------------------------------------- the league and the card pool
std::vector<TeamDef> TDP;
std::vector<UTPDef> UTP;
std::vector<const UTPDef *> UT_CUR, UT_LEGP;
static std::map<std::string, int> UTMi;
const UTPDef *UTM(const std::string &k) { auto it = UTMi.find(k); return it == UTMi.end() ? nullptr : &UTP[it->second]; }
const std::string &teamCol(int t) { return TDP[((t % NT) + NT) % NT].col; }
const std::string &teamStr(int t) { return TDP[((t % NT) + NT) % NT].st; }
int teamIndex(const std::string &ab) { for (int i = 0; i < (int)TDP.size(); i++) if (TDP[i].ab == ab) return i; return -1; }
static std::vector<std::string> split(const std::string &s, char c) { std::vector<std::string> o; std::string cur; for (char ch : s) { if (ch == c) { o.push_back(cur); cur.clear(); } else cur += ch; } o.push_back(cur); return o; }
void leagueInit() {
  if (!TDP.empty()) return;
  for (int i = 0; i < NT; i++) {
    auto f = split(TD[i], '|'); TeamDef T; T.ab = f[0]; T.city = f[1]; T.n = f[2]; T.d = atoi(f[3].c_str()); T.col = f[4]; T.st = f[5];
    auto pl = [](const std::string &x) { std::vector<TPl> o; for (auto &e : split(x, ',')) { auto p = split(e, ':'); o.push_back({p[0], atoi(p[1].c_str()), atoi(p[2].c_str())}); } return o; };
    T.S = pl(f[6]); T.G = pl(f[7]); TDP.push_back(T);
  }
  for (int t = 0; t < NT; t++) {
    for (auto &s : TDP[t].S) { UTPDef p; p.k = TDP[t].ab + "|" + s.nm; p.nm = s.nm; p.pos = 'F'; p.ov = s.ov; p.t = t; p.age = s.age; UTP.push_back(p); }
    for (auto &s : TDP[t].G) { UTPDef p; p.k = TDP[t].ab + "|" + s.nm; p.nm = s.nm; p.pos = 'G'; p.ov = s.ov; p.t = t; p.age = s.age; UTP.push_back(p); }
  }
  for (auto &l : UT_LEG) { UTPDef p; p.k = std::string("LEG|") + l.nm; p.nm = l.nm; p.pos = l.pos; p.ov = l.ov; p.t = -1; p.leg = true; UTP.push_back(p); }
  // the 2026 draft class: cards of their new clubs (after the legends, so legacy pack odds keep their order)
  for (auto &d : DRAFT26) { int t = teamIndex(d.team); if (t < 0) continue; UTPDef p; p.k = std::string(d.team) + "|" + d.nm; p.nm = d.nm; p.pos = 'F'; p.ov = d.ov; p.t = t; p.dr = true; p.age = d.age; UTP.push_back(p); }
  for (int i = 0; i < (int)UTP.size(); i++) UTMi[UTP[i].k] = i;
  for (auto &p : UTP) (p.leg ? UT_LEGP : UT_CUR).push_back(&p);
}

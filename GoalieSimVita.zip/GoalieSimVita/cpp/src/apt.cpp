// CHL 2026 native - BE A PRO: the apartment. Two sizes: the starter (34 x 26 ft) and the corner unit (40 x 30 ft), both
// with 9 ft ceilings: living room and an open kitchen along the front, a hall to the bedroom and the office. Built
// from lit, vertex-coloured boxes (feet: x east, y north, z up), drawn by the GPU in one static batch, walked in first person.
#include "apt.h"
#include "pro.h"
#include "json.h"
#include <algorithm>
#include <cmath>

#define C (*CR)
// ---------------------------------------------------------------- what you can buy (fx: small rating nudges, more for the good stuff)
const char *ROOMN[HOME_NR] = {"LIVING ROOM", "KITCHEN", "BEDROOM", "OFFICE"};
static const HomeSlotDef FLOORDEF = {"FLOORING", {{"WORN CARPET", 0, "Stained, flattened, smells like the last tenant.", ""}, {"VINYL PLANK", 600, "Clean grey-oak planks. Wipes right up.", "edge:0.1"},
  {"OAK HARDWOOD", 2000, "Real wood, warm and narrow-planked.", "edge:0.25,skate:0.1"}, {"MARBLE TILE", 6000, "Polished white marble with grey veins.", "edge:0.5,skate:0.25"}}, 0};
static const HomeSlotDef PAINTDEF = {"PAINT", {{"DINGY BEIGE", 0, "Whatever the last tenant left, plus nicotine.", ""}, {"FRESH WHITE", 200, "Clean, bright, simple.", "sacc:0.1"},
  {"SAGE GREEN", 350, "Calm and earthy.", "sacc:0.15,wpow:0.1"}, {"DEEP NAVY", 600, "A moody accent colour. Very grown-up.", "sacc:0.25,wpow:0.15"}}, 0};
static const HomeSlotDef WALLDEF = {"DRYWALL", {{"HOLES AND CRACKS", 0, "Fist-sized holes and a crack you could post a letter through.", ""},
  {"PATCH, TAPE AND SAND", 400, "Smooth walls, ready for paint.", "check:0.15"}}, 0};
const HomeSlotDef HSLOT[HOME_NS] = {
  {"COUCH", {{"CURBSIDE FUTON", 0, "Found it on the curb. Sags in the middle.", ""}, {"THRIFT STORE SOFA", 250, "A brown three-seater with all its springs.", "fstam:0.25"},
    {"LEATHER SECTIONAL", 1400, "Dark leather L with a chaise for film study.", "fstam:0.5,pass:0.25"}, {"DESIGNER MODULAR", 5000, "Low, deep, pale-grey modules and bright pillows.", "fstam:1,pass:0.5"}}, 0},
  {"TV", {{"OLD CRT", 0, "Twenty-inch tube. The picture rolls.", ""}, {"40\" LED", 300, "A thin flat screen. Finally.", "pass:0.25"},
    {"65\" 4K", 1100, "Big, sharp and bright. Great for film.", "pass:0.5,deke:0.25"}, {"85\" OLED", 4000, "Wall-sized and paper thin.", "pass:1,deke:0.5"}}, 0},
  {"ENTERTAINMENT CENTER", {{"MILK CRATES", 0, "Two crates and a plank.", ""}, {"PARTICLE BOARD STAND", 150, "Black, flat-packed, a little wobbly.", "hand:0.15"},
    {"OAK MEDIA CONSOLE", 800, "Solid oak with drawers for the games.", "hand:0.35"}, {"FLOATING WALNUT UNIT", 3000, "Wall-mounted walnut with a glowing light strip.", "hand:0.75,deke:0.25"}}, 0},
  {"RECLINER", {{"EMPTY CORNER", 0, "Room for one more seat.", ""}, {"THRIFT RECLINER", 400, "Corduroy, but it reclines.", "fstam:0.25"},
    {"LEATHER POWER RECLINER", 1800, "One button and you're horizontal.", "fstam:0.5,edge:0.25"}, {"ZERO-GRAVITY MASSAGE CHAIR", 6000, "Kneads the legs after a long road trip.", "fstam:1,edge:0.5"}}, 1},
  {"KITCHEN ISLAND", {{"EMPTY FLOOR", 0, "A lot of linoleum.", ""}, {"BUTCHER BLOCK CART", 500, "Rolls around. Somewhere to chop.", "skate:0.25"},
    {"QUARTZ ISLAND", 2500, "White quartz top, stools on one side.", "skate:0.5,check:0.25"}, {"WATERFALL MARBLE ISLAND", 7000, "The marble runs down both ends.", "skate:1,check:0.5"}}, 1},
  FLOORDEF, FLOORDEF, FLOORDEF, FLOORDEF, PAINTDEF, PAINTDEF, PAINTDEF, PAINTDEF, WALLDEF, WALLDEF, WALLDEF, WALLDEF};
std::string homeSlotName(int s) {
  if (s >= HS_FLOOR && s < HS_FLOOR + HOME_NR) return std::string("FLOORING  |  ") + ROOMN[s - HS_FLOOR];
  if (s >= HS_PAINT && s < HS_PAINT + HOME_NR) return std::string("PAINT  |  ") + ROOMN[s - HS_PAINT];
  if (s >= HS_WALL && s < HS_WALL + HOME_NR) return std::string("DRYWALL  |  ") + ROOMN[s - HS_WALL];
  return s >= 0 && s < HOME_NS ? HSLOT[s].n : "";
}
const std::vector<HomeOpt> COUNTER = {{"TOASTER", 60, "Two slots, one setting: burnt.", "hand:0.05"}, {"KNIFE BLOCK", 90, "Six knives and a sharpener.", "hand:0.1"},
  {"COFFEE MAKER", 120, "Twelve cups of drip before the morning skate.", "fstam:0.1"}, {"BLENDER", 150, "Protein shakes on demand.", "skate:0.1"},
  {"AIR FRYER", 180, "Crispy without the guilt.", "check:0.1"}, {"MICROWAVE", 200, "For the meal-prep containers.", "pass:0.05"},
  {"STAND MIXER", 450, "Candy-apple red. Bakes the team cookies.", "spow:0.15"}, {"ESPRESSO MACHINE", 900, "Twin boilers, steam wand, the works.", "fstam:0.25,edge:0.1"}};
const std::vector<HomeOpt> APTS = {{"THE STARTER", 0, "34 x 26 ft. Living room, kitchen, bedroom, office. Cosy.", ""},
  {"THE CORNER UNIT", 15000, "40 x 30 ft. A deeper living room with space for a recliner, and a bigger kitchen with room for an island.", "fstam:0.25"}};
Home HOME;
J homeToJ() {
  J o = J::obj(), s = J::arr(), w = J::arr(), c = J::arr(); for (int i = 0; i < HOME_NS; i++) { s.push(HOME.sel[i]); w.push(HOME.own[i]); }
  for (int i = 0; i < HOME_NCTR; i++) c.push(HOME.ctr[i]);
  o["v"] = 2; o["sel"] = s; o["own"] = w; o["junk"] = HOME.junk; o["lvl"] = HOME.lvl; o["lvlOwn"] = HOME.lvlOwn; o["ctrOwn"] = HOME.ctrOwn; o["ctr"] = c; return o;
}
void aptUnload();
void homeFromJ(const J &o) {
  HOME = Home(); aptUnload(); if (!o.isObj()) return;
  auto at = [&](const char *k, int c, int d) { const J &a = o(k); return a.isArr() && (size_t)c < a.a.size() ? a.a[(size_t)c].i(d) : d; };
  if (o("v").i() < 2) {   // the first apartment file: floor, couch, TV, stand (one floor for the whole place)
    int map[4] = {-1, HS_COUCH, HS_TV, HS_ENT};
    for (int c = 1; c < 4; c++) { HOME.sel[map[c]] = at("sel", c, 0); HOME.own[map[c]] = at("own", c, 1) | 1; }
    for (int r : {0, 2, 3}) { HOME.sel[HS_FLOOR + r] = at("sel", 0, 0); HOME.own[HS_FLOOR + r] = at("own", 0, 1) | 1; }
  } else for (int i = 0; i < HOME_NS; i++) { HOME.sel[i] = at("sel", i, 0); HOME.own[i] = at("own", i, 1) | 1; }
  for (int i = 0; i < HOME_NS; i++) { HOME.sel[i] = std::max(0, std::min((int)HSLOT[i].o.size() - 1, HOME.sel[i])); if (!(HOME.own[i] >> HOME.sel[i] & 1)) HOME.sel[i] = 0; }
  HOME.junk = o("junk").i(); HOME.lvlOwn = o("lvlOwn").i(1) | 1; HOME.lvl = std::max(0, std::min((int)APTS.size() - 1, o("lvl").i())); if (!(HOME.lvlOwn >> HOME.lvl & 1)) HOME.lvl = 0;
  HOME.ctrOwn = o("ctrOwn").i(); for (int i = 0; i < HOME_NCTR; i++) { int v = at("ctr", i, -1); HOME.ctr[i] = v >= 0 && v < (int)COUNTER.size() && (HOME.ctrOwn >> v & 1) ? v : -1; }
}
bool homeTestMade() { std::string s; if (!plat_read_file(plat_data_dir() + "chl_home.json", s) || s.empty()) return false; J o = J::parse(s); return o.isObj() && o("testMade").truthy(); }
void homeSetTestMade() { J o = J::obj(); o["testMade"] = true; plat_write_file(plat_data_dir() + "chl_home.json", o.dump()); }
static void bonusChanged();
int homeBuy(int s, int i) {
  if (s < 0 || s >= HOME_NS || i < 0 || i >= (int)HSLOT[s].o.size()) return 0;
  if (HSLOT[s].lvl > HOME.lvl) return -1;
  if (s >= HS_PAINT && s < HS_PAINT + HOME_NR && i > 0 && HOME.sel[HS_WALL + s - HS_PAINT] == 0) return -1;   // fix the walls first
  if (HOME.own[s] >> i & 1) { HOME.sel[s] = i; if (CR) proSave(); aptDirty(); bonusChanged(); return 2; }
  if (!CR || C.money < HSLOT[s].o[(size_t)i].c) return 0;
  C.money -= HSLOT[s].o[(size_t)i].c; HOME.own[s] |= 1 << i; HOME.sel[s] = i; proSave(); aptDirty(); bonusChanged(); return 1;
}
bool homeCtrOut(int i) { for (int k = 0; k < HOME_NCTR; k++) if (HOME.ctr[k] == i) return true; return false; }
int homeCounter(int i) {
  if (i < 0 || i >= (int)COUNTER.size()) return 0;
  for (int k = 0; k < HOME_NCTR; k++) if (HOME.ctr[k] == i) { HOME.ctr[k] = -1; if (CR) proSave(); aptDirty(); bonusChanged(); return 3; }   // put it away
  int free = -1; for (int k = 0; k < HOME_NCTR; k++) if (HOME.ctr[k] < 0) { free = k; break; }
  bool own = HOME.ctrOwn >> i & 1;
  if (free < 0) return own ? 4 : 4;
  if (!own) { if (!CR || C.money < COUNTER[(size_t)i].c) return 0; C.money -= COUNTER[(size_t)i].c; HOME.ctrOwn |= 1 << i; }
  HOME.ctr[free] = i; if (CR) proSave(); aptDirty(); bonusChanged(); return own ? 2 : 1;
}
int homeMove(int l) {
  if (l < 0 || l >= (int)APTS.size()) return 0;
  if (HOME.lvlOwn >> l & 1) { HOME.lvl = l; if (CR) proSave(); aptDirty(); bonusChanged(); return 2; }
  if (!CR || C.money < APTS[(size_t)l].c) return 0;
  C.money -= APTS[(size_t)l].c; HOME.lvlOwn |= 1 << l; HOME.lvl = l; proSave(); aptDirty(); bonusChanged(); return 1;
}
// the rating nudges: everything in use adds its fx, each rating capped at +3
static std::vector<std::pair<std::string, double>> fxParse(const char *fx) {
  std::vector<std::pair<std::string, double>> o; std::string s = fx ? fx : ""; size_t i = 0;
  while (i < s.size()) { size_t c = s.find(':', i), e = s.find(',', i); if (c == std::string::npos) break; if (e == std::string::npos) e = s.size(); o.push_back({s.substr(i, c - i), atof(s.substr(c + 1, e - c - 1).c_str())}); i = e + 1; }
  return o;
}
static struct { bool ok = false; std::vector<std::pair<std::string, double>> m; } HB;
static void bonusChanged() { HB.ok = false; gearChanged(); }
double homePts(const std::string &k) {
  if (!HB.ok) { HB.ok = true; HB.m.clear(); auto add = [&](const char *fx) { for (auto &p : fxParse(fx)) { bool f = false; for (auto &q : HB.m) if (q.first == p.first) { q.second += p.second; f = true; } if (!f) HB.m.push_back(p); } };
    for (int s = 0; s < HOME_NS; s++) if (HSLOT[s].lvl <= HOME.lvl) add(HSLOT[s].o[(size_t)HOME.sel[s]].fx);
    for (int k2 = 0; k2 < HOME_NCTR; k2++) if (HOME.ctr[k2] >= 0) add(COUNTER[(size_t)HOME.ctr[k2]].fx);
    add(APTS[(size_t)HOME.lvl].fx); }
  for (auto &q : HB.m) if (q.first == k) return std::min(3.0, q.second);
  return 0;
}
std::string homeFxTxt(const char *fx) {
  std::string o; for (auto &p : fxParse(fx)) { if (!o.empty()) o += "  "; char b[16]; snprintf(b, sizeof b, "+%g ", p.second); o += b + FNICE(p.first); }
  return o;
}

// ---------------------------------------------------------------- geometry
struct P3 { float x, y, z; };
static inline P3 operator+(P3 a, P3 b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
static inline P3 operator-(P3 a, P3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static inline P3 operator*(P3 a, float k) { return {a.x * k, a.y * k, a.z * k}; }
static inline float dot3(P3 a, P3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static inline P3 cross3(P3 a, P3 b) { return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
static inline P3 nrm3(P3 a) { float l = std::sqrt(dot3(a, a)); return l > 1e-6f ? a * (1 / l) : P3{0, 0, 1}; }
static std::vector<V3c> AG;                       // the world, ready for the GPU
static uint32_t aptVer = 1; static bool aptOk = false, aptLoaded = false;   // ok: geometry current; loaded: in memory (between the loading screen and the next game)
struct Rc { float x0, y0, x1, y1; bool wall = false; }; static std::vector<Rc> COL;     // what you bump into
struct Hot { int id; P3 p; float r; }; static std::vector<Hot> HOT;  // what you can look at and use
struct Lamp { P3 p; float k; }; static std::vector<Lamp> LAMPS;
static const float CEIL = 9, WT = .25f;
static float AX = 34, AY = 26, LY = 14, KY = 12;   // the size, where the bedroom wall and the kitchen's back wall stand (set by the apartment)
void aptDirty() { aptOk = false; }
static uint32_t sd = 1; static float frand() { sd = sd * 1664525u + 1013904223u; return (sd >> 8) / 16777216.f; }
// light at a point on a surface: a dim warm ambient, daylight from the south windows, the ceiling bulbs
static Col litAt(Col c, P3 p, P3 n) {
  float l = .44f + .12f * std::max(0.f, n.z) + .14f * std::max(0.f, -n.y) * std::max(0.f, 1 - p.y / 16) + .05f * std::fabs(n.x);
  for (auto &L : LAMPS) { P3 d = L.p - p; float d2 = dot3(d, d), dl = std::sqrt(d2) + 1e-4f; float nd = std::max(0.f, dot3(n, d * (1 / dl))); l += L.k * (.25f + .75f * nd) / (1 + d2 * .016f); }
  l = std::min(l, 1.3f);
  return Col(std::min(255.f, c.r * l * 1.02f), std::min(255.f, c.g * l * .97f), std::min(255.f, c.b * l * .88f), 1);
}
static std::vector<V3c> DY, *OUT = &AG;   // DY: what moves (the hallway doors), rebuilt each frame
static void vtx(P3 p, uint32_t c) { V3c v; v.x = p.x; v.y = p.y; v.z = p.z; v.c = c; v.u = v.v = 0; OUT->push_back(v); }
// a flat quad a-b-c-d with normal n, split into tiles so the light falls off smoothly across it; glow: unlit
static void quad(P3 a, P3 b, P3 c, P3 d, Col col, P3 n, float tile = 3, bool glow = false) {
  float lu = std::sqrt(dot3(b - a, b - a)), lv = std::sqrt(dot3(d - a, d - a)); int nu = std::max(1, std::min(10, (int)std::ceil(lu / tile))), nv = std::max(1, std::min(10, (int)std::ceil(lv / tile)));
  if (glow) nu = nv = 1;
  auto at = [&](float u, float v) { P3 p = a + (b - a) * u + (d - a) * v + (c - b - (d - a)) * (u * v); return p; };
  for (int i = 0; i < nu; i++) for (int j = 0; j < nv; j++) {
    P3 q[4] = {at((float)i / nu, (float)j / nv), at((float)(i + 1) / nu, (float)j / nv), at((float)(i + 1) / nu, (float)(j + 1) / nv), at((float)i / nu, (float)(j + 1) / nv)};
    uint32_t k[4]; for (int m = 0; m < 4; m++) k[m] = glow ? col.pack() : litAt(col, q[m], n).pack();
    vtx(q[0], k[0]); vtx(q[1], k[1]); vtx(q[2], k[2]); vtx(q[0], k[0]); vtx(q[2], k[2]); vtx(q[3], k[3]); }
}
// a box; skip bit 1 drops the bottom (anything on the floor)
static void box(float x0, float y0, float z0, float x1, float y1, float z1, Col c, float tile = 3, int skip = 1, bool glow = false) {
  if (x1 < x0) std::swap(x0, x1); if (y1 < y0) std::swap(y0, y1);
  quad({x0, y0, z1}, {x1, y0, z1}, {x1, y1, z1}, {x0, y1, z1}, c, {0, 0, 1}, tile, glow);
  if (!(skip & 1)) quad({x0, y0, z0}, {x0, y1, z0}, {x1, y1, z0}, {x1, y0, z0}, c, {0, 0, -1}, tile, glow);
  quad({x0, y0, z0}, {x1, y0, z0}, {x1, y0, z1}, {x0, y0, z1}, c, {0, -1, 0}, tile, glow);
  quad({x1, y1, z0}, {x0, y1, z0}, {x0, y1, z1}, {x1, y1, z1}, c, {0, 1, 0}, tile, glow);
  quad({x0, y1, z0}, {x0, y0, z0}, {x0, y0, z1}, {x0, y1, z1}, c, {-1, 0, 0}, tile, glow);
  quad({x1, y0, z0}, {x1, y1, z0}, {x1, y1, z1}, {x1, y0, z1}, c, {1, 0, 0}, tile, glow);
}
static void solid(float x0, float y0, float x1, float y1, bool wall = false) { COL.push_back({std::min(x0, x1), std::min(y0, y1), std::max(x0, x1), std::max(y0, y1), wall}); }
// a round thing: n sides from radius r0 at z0 to r1 at z1 (and a lid)
static void cyl(float cx, float cy, float z0, float z1, float r0, float r1, Col c, int n = 8, bool lid = true, bool glow = false) {
  for (int i = 0; i < n; i++) { float a0 = i * 6.2832f / n, a1 = (i + 1) * 6.2832f / n, am = (a0 + a1) / 2;
    P3 nn = nrm3({std::cos(am), std::sin(am), (r0 - r1) / std::max(.01f, z1 - z0)});
    quad({cx + std::cos(a0) * r0, cy + std::sin(a0) * r0, z0}, {cx + std::cos(a1) * r0, cy + std::sin(a1) * r0, z0}, {cx + std::cos(a1) * r1, cy + std::sin(a1) * r1, z1}, {cx + std::cos(a0) * r1, cy + std::sin(a0) * r1, z1}, c, nn, 9, glow);
    if (lid) { uint32_t k = glow ? c.pack() : litAt(c, {cx, cy, z1}, {0, 0, 1}).pack(); vtx({cx, cy, z1}, k); vtx({cx + std::cos(a0) * r1, cy + std::sin(a0) * r1, z1}, k); vtx({cx + std::cos(a1) * r1, cy + std::sin(a1) * r1, z1}, k); } }
}
// a thin patch on a wall or floor (stains, holes, rugs): centre p, half sizes along u and v, facing n
static void patch(P3 p, P3 u, P3 v, Col c, P3 n, bool glow = false) { P3 o = p + n * .03f; quad(o - u - v, o + u - v, o + u + v, o - u + v, c, n, 9, glow); }
static Col HX(const char *h) { return hex(h); }
static Col vary(Col c, float k) { float f = 1 + (frand() - .5f) * k; return Col(std::min(255.f, c.r * f), std::min(255.f, c.g * f), std::min(255.f, c.b * f), 1); }

// walls: a line of boxes along x (or y), with openings (doors from the floor, windows from z0)
struct Gap { float a, b, z0, z1; };
static void wbox(float x0, float y0, float z0, float x1, float y1, float z1, bool bottom);
static void wall(bool alongX, float fix, float from, float to, std::vector<Gap> gaps, Col) {
  std::sort(gaps.begin(), gaps.end(), [](const Gap &a, const Gap &b) { return a.a < b.a; });
  auto piece = [&](float a, float b, float z0, float z1, bool coll) { if (b - a < .01f || z1 - z0 < .01f) return;
    if (alongX) { wbox(a, fix - WT, z0, b, fix + WT, z1, z0 > 0); if (coll) solid(a, fix - WT, b, fix + WT, true); }
    else { wbox(fix - WT, a, z0, fix + WT, b, z1, z0 > 0); if (coll) solid(fix - WT, a, fix + WT, b, true); } };
  float cur = from;
  for (auto &g : gaps) { piece(cur, g.a, 0, CEIL, true); piece(g.a, g.b, 0, g.z0, g.z0 > 0); piece(g.a, g.b, g.z1, CEIL, false); cur = g.b; }
  piece(cur, to, 0, CEIL, true);
}
// a window in an outer wall: frame, sill, the view (the city, a bit grimy through dirty glass)
static void window(bool alongX, float fix, float a, float b, float z0, float z1, float out) {
  Col fr = HX("#cfc6ad"), sky0 = HX("#9fb0bc"), sky1 = HX("#c9cfc8");
  float t = .12f;
  if (alongX) {
    box(a - .15f, fix - WT - .25f, z0 - .15f, b + .15f, fix + WT + .25f, z0 + .05f, fr, 3, 0);   // sill: sits proud of the wall
    box(a + .01f, fix - .08f, z0 + .05f, a + t, fix + .08f, z1 - .01f, fr); box(b - t, fix - .08f, z0 + .05f, b - .01f, fix + .08f, z1 - .01f, fr); box(a + .01f, fix - .08f, z1 - t, b - .01f, fix + .08f, z1 - .01f, fr, 3, 0);
    box((a + b) / 2 - t / 2, fix - .06f, z0 + .05f, (a + b) / 2 + t / 2, fix + .06f, z1 - t, fr); box(a + t, fix - .06f, (z0 + z1) / 2 - t / 2, b - t, fix + .06f, (z0 + z1) / 2 + t / 2, fr, 3, 0);
    float yo = fix + out * 1.2f, ny = -out;
    quad({a - 1, yo, z0 - 1}, {b + 1, yo, z0 - 1}, {b + 1, yo, z1 + 1}, {a - 1, yo, z1 + 1}, sky1, {0, ny, 0}, 9, true);
    quad({a - 1, yo + out * .01f, z0 - 1}, {b + 1, yo + out * .01f, z0 - 1}, {b + 1, yo + out * .01f, (z0 + z1) / 2}, {a - 1, yo + out * .01f, (z0 + z1) / 2}, sky0, {0, ny, 0}, 9, true);
    for (float x = a - .8f; x < b + .8f; x += .5f + frand() * .7f) { float hb = z0 - .4f + frand() * 2.2f, w = .3f + frand() * .5f;   // the skyline
      quad({x, yo - out * .02f, z0 - 1}, {x + w, yo - out * .02f, z0 - 1}, {x + w, yo - out * .02f, hb}, {x, yo - out * .02f, hb}, vary(HX("#6f7a80"), .2f), {0, ny, 0}, 9, true); }
  } else {
    box(fix - WT - .25f, a - .15f, z0 - .15f, fix + WT + .25f, b + .15f, z0 + .05f, fr, 3, 0);
    box(fix - .08f, a + .01f, z0 + .05f, fix + .08f, a + t, z1 - .01f, fr); box(fix - .08f, b - t, z0 + .05f, fix + .08f, b - .01f, z1 - .01f, fr); box(fix - .08f, a + .01f, z1 - t, fix + .08f, b - .01f, z1 - .01f, fr, 3, 0);
    box(fix - .06f, (a + b) / 2 - t / 2, z0 + .05f, fix + .06f, (a + b) / 2 + t / 2, z1 - t, fr); box(fix - .06f, a + t, (z0 + z1) / 2 - t / 2, fix + .06f, b - t, (z0 + z1) / 2 + t / 2, fr, 3, 0);
    float xo = fix + out * 1.2f, nx = -out;
    quad({xo, a - 1, z0 - 1}, {xo, b + 1, z0 - 1}, {xo, b + 1, z1 + 1}, {xo, a - 1, z1 + 1}, sky1, {nx, 0, 0}, 9, true);
    quad({xo + out * .01f, a - 1, z0 - 1}, {xo + out * .01f, b + 1, z0 - 1}, {xo + out * .01f, b + 1, (z0 + z1) / 2}, {xo + out * .01f, a - 1, (z0 + z1) / 2}, sky0, {nx, 0, 0}, 9, true);
    for (float y = a - .8f; y < b + .8f; y += .5f + frand() * .7f) { float hb = z0 - .4f + frand() * 2.2f, w = .3f + frand() * .5f;
      quad({xo - out * .02f, y, z0 - 1}, {xo - out * .02f, y + w, z0 - 1}, {xo - out * .02f, y + w, hb}, {xo - out * .02f, y, hb}, vary(HX("#6f7a80"), .2f), {nx, 0, 0}, 9, true); }
  }
  // grime on the glass: streaks along the bottom of each pane
  for (int i = 0; i < 2; i++) for (int k = 0; k < 2; k++) { float u0 = a + (b - a) * (.5f * i + .03f), u1 = a + (b - a) * (.5f * i + .47f), zz = z0 + (z1 - z0) * (.5f * k) + .2f; Col g = vary(HX("#a9a58f"), .08f); float hh = .12f + frand() * .15f;
    if (alongX) quad({u0, fix - .07f * out, zz}, {u1, fix - .07f * out, zz}, {u1, fix - .07f * out, zz + hh}, {u0, fix - .07f * out, zz + hh * .4f}, g, {0, -out, 0}, 9, true);
    else quad({fix - .07f * out, u0, zz}, {fix - .07f * out, u1, zz}, {fix - .07f * out, u1, zz + hh}, {fix - .07f * out, u0, zz + hh * .4f}, g, {-out, 0, 0}, 9, true); }
}

// ---------------------------------------------------------------- floors
// an irregular flat shape (a stain, a puddle) or, with h, a soft low mound (a pile of clothes)
static void blob(float cx, float cy, float z, float r, float h, Col c, P3 n = {0, 0, 1}, int k = 10) {
  float rr[16]; for (int i = 0; i < k; i++) rr[i] = r * (.65f + .5f * frand());
  P3 ctr = {cx, cy, z + h * (n.z < 0 ? -1 : 1)}; uint32_t cc = litAt(c, ctr, n).pack();
  for (int i = 0; i < k; i++) { float a0 = i * 6.2832f / k, a1 = (i + 1) * 6.2832f / k; P3 p0 = {cx + std::cos(a0) * rr[i], cy + std::sin(a0) * rr[i], z}, p1 = {cx + std::cos(a1) * rr[(i + 1) % k], cy + std::sin(a1) * rr[(i + 1) % k], z};
    vtx(ctr, cc); vtx(p0, litAt(shade(c, -.12), p0, n).pack()); vtx(p1, litAt(shade(c, -.12), p1, n).pack()); }
}
static void floorRect(float x0, float y0, float x1, float y1, int type, bool kitchen = false) {
  P3 up = {0, 0, 1};
  if (type == 0 && kitchen) {   // the kitchen's cracked linoleum
    for (float i = x0; i < x1 - .01f; i++) for (float j = y0; j < y1 - .01f; j++) { int a = (int)i, b = (int)j; Col t = ((a + b) & 1) ? HX("#b9b29c") : HX("#8f8a7c"); if (frand() < .12f) t = HX("#7a7262");
      quad({i, j, .01f}, {std::min(x1, i + 1), j, .01f}, {std::min(x1, i + 1), std::min(y1, j + 1), .01f}, {i, std::min(y1, j + 1), .01f}, vary(t, .06f), up, 9); }
    return;
  }
  if (type == 0) {   // worn carpet: one colour, flattened paths and stains
    quad({x0, y0, 0}, {x1, y0, 0}, {x1, y1, 0}, {x0, y1, 0}, HX("#7b7060"), up, 2.5f);
    int ns = (int)((x1 - x0) * (y1 - y0) / 22); for (int i = 0; i < ns; i++) { float cx = x0 + (x1 - x0) * frand(), cy = y0 + (y1 - y0) * frand(), r = .4f + frand() * 1.1f;
      blob(cx, cy, .02f, r, 0, vary(HX("#655b4c"), .12f)); }
    return;
  }
  if (type == 3) {   // marble: 2 ft tiles, grout between, a vein across each
    quad({x0, y0, 0}, {x1, y0, 0}, {x1, y1, 0}, {x0, y1, 0}, HX("#9a968e"), up, 6);
    for (float x = x0; x < x1 - .05f; x += 2) for (float y = y0; y < y1 - .05f; y += 2) { float xe = std::min(x1, x + 2) - .04f, ye = std::min(y1, y + 2) - .04f; Col t = vary(HX("#e9e6df"), .06f);
      quad({x + .04f, y + .04f, .02f}, {xe, y + .04f, .02f}, {xe, ye, .02f}, {x + .04f, ye, .02f}, t, up, 9);
      float vy = y + .3f + frand() * 1.3f; quad({x + .1f, vy, .03f}, {xe - .1f, vy + (frand() - .5f) * .8f, .03f}, {xe - .1f, vy + .05f + (frand() - .5f) * .8f, .03f}, {x + .1f, vy + .06f, .03f}, HX("#b4b0aa"), up, 9); }
    return;
  }
  // planks along x: vinyl (wide, grey-tan) or oak (narrow, warm)
  float pw = type == 1 ? .62f : .38f; Col base = type == 1 ? HX("#b5a68d") : HX("#9b6b40");
  quad({x0, y0, 0}, {x1, y0, 0}, {x1, y1, 0}, {x0, y1, 0}, type == 1 ? HX("#6e6556") : HX("#4a311d"), up, 6);
  for (float y = y0; y < y1 - .02f; y += pw) { float ye = std::min(y1, y + pw) - .025f, x = x0 - frand() * 3;
    while (x < x1) { float l = (type == 1 ? 3.5f : 2.5f) + frand() * 2, xa = std::max(x0, x), xb = std::min(x1, x + l) - .025f; if (xb > xa + .05f) quad({xa, y, .015f}, {xb, y, .015f}, {xb, ye, .015f}, {xa, ye, .015f}, vary(base, type == 1 ? .1f : .22f), up, 9); x += l; } }
}

// ---------------------------------------------------------------- the furniture you can upgrade
static void couchGeo(int v) {   // against nothing, facing west toward the TV; the seat front at x 10.4
  if (v == 0) { Col f = HX("#5b4a3a"), m = HX("#b49a4e");   // a futon: wood frame, a sagging mustard mattress
    box(10.4f, 3.6f, 0, 13.2f, 10.4f, .8f, f); box(10.5f, 3.7f, .8f, 13.1f, 10.3f, 1.35f, m, 2); box(12.6f, 3.6f, 1.2f, 13.3f, 10.4f, 3.0f, m, 2);
    box(11.4f, 6.2f, 1.33f, 12.2f, 7.8f, 1.37f, HX("#8c7535"));   // the sag
    patch({11.2f, 8.6f, 1.36f}, {.4f, 0, 0}, {0, .3f, 0}, HX("#6f5f2e"), {0, 0, 1}); solid(10.4f, 3.6f, 13.3f, 10.4f); }
  else if (v == 1) { Col c = HX("#6b4a2f");   // thrift sofa
    box(10.5f, 3.8f, 0, 13.2f, 10.2f, 1.5f, c, 2); box(12.4f, 3.8f, 1.5f, 13.2f, 10.2f, 3.0f, c, 2);
    box(10.5f, 3.4f, 0, 13.2f, 3.9f, 2.2f, c); box(10.5f, 10.1f, 0, 13.2f, 10.6f, 2.2f, c);
    for (int i = 0; i < 3; i++) box(10.6f, 4.0f + i * 2.05f, 1.5f, 12.4f, 5.95f + i * 2.05f, 1.85f, vary(HX("#7d5838"), .08f), 2);
    solid(10.5f, 3.4f, 13.2f, 10.6f); }
  else if (v == 2) { Col c = HX("#2e2522"), s = HX("#3b302b");   // leather sectional with a chaise toward the TV
    box(10.6f, 3.0f, 0, 13.4f, 11.0f, 1.45f, c, 2); box(12.6f, 3.0f, 1.45f, 13.4f, 11.0f, 3.0f, c, 2);
    box(8.0f, 9.0f, 0, 10.6f, 11.0f, 1.45f, c, 2); box(8.0f, 10.4f, 1.45f, 10.6f, 11.0f, 3.0f, c, 2);
    box(10.6f, 2.5f, 0, 13.4f, 3.0f, 2.1f, c);
    for (int i = 0; i < 3; i++) box(10.7f, 3.1f + i * 2.0f, 1.45f, 12.6f, 4.95f + i * 2.0f, 1.85f, vary(s, .06f), 2);
    box(8.1f, 9.1f, 1.45f, 10.6f, 10.4f, 1.85f, s, 2); solid(10.6f, 2.5f, 13.4f, 11.0f); solid(8.0f, 9.0f, 10.6f, 11.0f); }
  else { Col c = HX("#c9c8c4");   // designer modular
    box(10.2f, 2.6f, 0, 13.6f, 11.4f, 1.2f, c, 2); box(12.8f, 2.6f, 1.2f, 13.6f, 11.4f, 2.6f, c, 2);
    box(10.2f, 2.2f, 0, 13.6f, 2.6f, 1.9f, c); box(10.2f, 11.4f, 0, 13.6f, 11.8f, 1.9f, c);
    const char *pc[5] = {"#e0703a", "#2b6f8f", "#e9c14b", "#2b6f8f", "#e0703a"};
    for (int i = 0; i < 5; i++) { float y = 3.2f + i * 1.65f; box(12.3f, y, 1.2f, 12.8f, y + 1.1f, 2.4f, HX(pc[i]), 2); }
    box(10.3f, 2.7f, 1.2f, 12.8f, 11.3f, 1.55f, HX("#d6d5d1"), 2); solid(10.2f, 2.2f, 13.6f, 11.8f); }
}
static float entTop = 2.2f;   // where the TV stands
static void entGeo(int v) {   // against the west wall, centred at y 7
  if (v == 0) { Col r = HX("#b0302c"), b = HX("#2f5a9a");   // two milk crates and a plank
    auto crate = [&](float y0, Col c) { box(.4f, y0, 0, 1.5f, y0 + 1.1f, 1.1f, c, 1); box(.5f, y0 + .1f, .1f, 1.4f, y0 + 1.0f, 1.12f, HX("#1a1a1a")); };
    crate(5.2f, r); crate(7.7f, b); box(.35f, 5.0f, 1.12f, 1.6f, 9.0f, 1.25f, HX("#8a7352"), 2); entTop = 1.25f; solid(.25f, 5.0f, 1.6f, 9.0f); }
  else if (v == 1) { Col k = HX("#1c1c1f"); box(.3f, 4.5f, 0, 1.8f, 9.5f, 1.8f, k, 2); box(.35f, 4.7f, .3f, 1.82f, 9.3f, .35f, HX("#2c2c30")); box(.35f, 4.7f, 1.0f, 1.82f, 9.3f, 1.05f, HX("#2c2c30"));
    box(1.0f, 5.0f, .36f, 1.6f, 6.2f, .6f, HX("#111")); entTop = 1.8f; solid(.25f, 4.5f, 1.8f, 9.5f); }
  else if (v == 2) { Col o = HX("#9a6a3c"); box(.3f, 3.8f, 0, 1.9f, 10.2f, 2.0f, o, 2);
    for (int i = 0; i < 3; i++) { float y = 4.1f + i * 2.05f; box(1.88f, y, .3f, 1.93f, y + 1.8f, 1.7f, vary(HX("#875a31"), .05f)); box(1.92f, y + .8f, .95f, 2.0f, y + 1.0f, 1.05f, HX("#d8c08a")); }
    entTop = 2.0f; solid(.25f, 3.8f, 1.9f, 10.2f); }
  else { Col w = HX("#5a3a24"); box(.3f, 2.8f, 1.2f, 1.7f, 11.2f, 2.3f, w, 2, 0); box(.32f, 2.9f, 1.15f, 1.68f, 11.1f, 1.2f, HX("#7fd6ff"), 9, 0, true);   // the light strip underneath
    for (int i = 0; i < 4; i++) box(1.68f, 3.2f + i * 2.0f, 1.3f, 1.72f, 4.9f + i * 2.0f, 2.2f, vary(HX("#6b4630"), .05f));
    entTop = 2.3f; solid(.25f, 2.8f, 1.7f, 11.2f); }
}
// the screen shows a rink, of course
static void screenPic(float x, float y0, float y1, float z0, float z1, bool crt) {
  Col bg = crt ? HX("#7f9a8a") : HX("#e8eef4"); quad({x, y1, z0}, {x, y0, z0}, {x, y0, z1}, {x, y1, z1}, bg, {1, 0, 0}, 9, true);
  float w = y1 - y0, h = z1 - z0, xi = x + .01f;
  auto bar = [&](float u0, float u1, float v0, float v1, Col c) { quad({xi, y1 - w * u0, z0 + h * v0}, {xi, y1 - w * u1, z0 + h * v0}, {xi, y1 - w * u1, z0 + h * v1}, {xi, y1 - w * u0, z0 + h * v1}, c, {1, 0, 0}, 9, true); };
  bar(.495f, .505f, .08f, .92f, crt ? HX("#7a3a3a") : HX("#d23b3b")); bar(.33f, .345f, .08f, .92f, crt ? HX("#3a4a7a") : HX("#2f64d6")); bar(.655f, .67f, .08f, .92f, crt ? HX("#3a4a7a") : HX("#2f64d6"));
  bar(.08f, .09f, .25f, .75f, HX("#c23")); bar(.91f, .92f, .25f, .75f, HX("#c23"));
  bar(.4f, .43f, .45f, .55f, HX("#111")); bar(.6f, .62f, .6f, .7f, HX("#222")); bar(.03f, .3f, .86f, .96f, crt ? HX("#2a3a2a") : HX("#0b1220"));   // a skater, the puck, the score bug
}
static void tvGeo(int v) {
  float z = entTop, cy = 7; P3 hot;
  if (v == 0) { box(.45f, 5.9f, z, 1.6f, 8.1f, z + 1.5f, HX("#4a4a46")); screenPic(1.61f, 6.15f, 7.85f, z + .2f, z + 1.3f, true); hot = {1.6f, cy, z + .75f}; }
  else { float w = v == 1 ? 3.0f : v == 2 ? 4.7f : 6.2f, h = w * .5625f, z0 = v == 3 ? 3.6f : z + .5f, x = v == 3 ? .3f : .7f, d = v == 3 ? .12f : .18f;
    box(x, cy - w / 2 - .06f, z0 - .06f, x + d, cy + w / 2 + .06f, z0 + h + .06f, HX("#111214"), 9, 0);
    if (v < 3) { box(x - .1f, cy - .5f, z, x + .5f, cy + .5f, z + .07f, HX("#222")); box(x + .02f, cy - .1f, z, x + .1f, cy + .1f, z0, HX("#222")); }
    screenPic(x + d + .005f, cy - w / 2, cy + w / 2, z0, z0 + h, false); hot = {x + d, cy, z0 + h / 2}; }
  HOT.push_back({APT_SLOT + HS_TV, hot, 15});
}

// ---------------------------------------------------------------- the trophy shelf (every title, every career)
static void cupMini(float x, float y, float z, bool calder) {
  if (!calder) { Col s = HX("#d9dee4"), d = HX("#9aa3ad");   // the Stanley Cup: tiered barrel, collar, bowl
    cyl(x, y, z, z + .12f, .2f, .2f, HX("#2a2a2a")); cyl(x, y, z + .12f, z + .4f, .18f, .16f, s); cyl(x, y, z + .4f, z + .5f, .16f, .13f, d); cyl(x, y, z + .5f, z + .66f, .1f, .06f, s);
    cyl(x, y, z + .66f, z + .78f, .07f, .14f, s); cyl(x, y, z + .78f, z + .8f, .14f, .14f, d); }
  else { Col g = HX("#d8b04a");   // the Calder Cup: a gold urn with handles
    cyl(x, y, z, z + .08f, .14f, .14f, HX("#3a2a1a")); cyl(x, y, z + .08f, z + .25f, .05f, .05f, g); cyl(x, y, z + .25f, z + .55f, .07f, .16f, g);
    box(x - .2f, y - .02f, z + .38f, x - .16f, y + .02f, z + .5f, g); box(x + .16f, y - .02f, z + .38f, x + .2f, y + .02f, z + .5f, g); }
}
static void shelfGeo() {   // on the living-room face of the bedroom wall
  float y1 = LY - WT, y0 = y1 - .85f, x0 = 3.0f, x1 = 9.4f; Col wd = HX("#6a5236");
  float zs[3] = {3.4f, 4.7f, 6.0f};
  for (float z : zs) { box(x0, y0, z - .1f, x1, y1, z, wd, 3, 0); box(x0 + .3f, y1 - .1f, z - .5f, x0 + .45f, y1, z - .1f, HX("#333")); box(x1 - .45f, y1 - .1f, z - .5f, x1 - .3f, y1, z - .1f, HX("#333")); }
  int cups = CR ? C.titles : 0, cal = CR ? C.calder : 0, nc = std::min(cups, 20), nk = std::min(cal, 30 - nc), i = 0;
  for (int k = 0; k < nc + nk; k++, i++) { int row = i / 10, col = i % 10; if (row > 2) break; cupMini(x0 + .35f + col * .62f, (y0 + y1) / 2, zs[2 - row], k >= nc); }
  if (!nc && !nk) { patch({(x0 + x1) / 2, y0 + .02f, zs[1] + .45f}, {.45f, 0, 0}, {0, 0, .3f}, HX("#f2e27a"), {0, -1, 0}); }   // a sticky note: "win something"
  HOT.push_back({APT_SHELF, {(x0 + x1) / 2, y0, 4.8f}, 10});
}

// ---------------------------------------------------------------- the newer pieces: recliner, island, counter items, the jersey
static void reclGeo(int v) {   // beside the couch, angled toward the TV
  if (v == 0 || HOME.lvl < 1) return;
  Col c = v == 1 ? HX("#7a5c3e") : v == 2 ? HX("#3a2a22") : HX("#2b2f36"); float x0 = 10.8f, y0 = 13.2f, x1 = 13.6f, y1 = 15.9f;
  box(x0, y0, 0, x1, y1, 1.5f, c, 2); box(x1 - .7f, y0, 1.5f, x1, y1, 3.6f, c, 2); box(x0, y0 - .35f, 0, x1 - .2f, y0, 2.3f, c); box(x0, y1, 0, x1 - .2f, y1 + .35f, 2.3f, c);
  box(x0 + .1f, y0 + .1f, 1.5f, x1 - .7f, y1 - .1f, 1.75f, shade(c, .12), 2);
  if (v == 3) { box(x0 - 1.3f, y0 + .3f, .3f, x0, y1 - .3f, 1.1f, c, 2); for (int i = 0; i < 3; i++) box(x1 - .72f, y0 + .5f + i * .7f, 2.0f + i * .4f, x1 - .68f, y0 + 1.0f + i * .7f, 2.3f + i * .4f, HX("#5ad1ff"), 9, 0, true); }   // footrest, a glowing panel
  solid(x0 - (v == 3 ? 1.3f : 0), y0 - .35f, x1, y1 + .35f); HOT.push_back({APT_SLOT + HS_RECL, {12.2f, 14.5f, 1.8f}, 15});
}
static void isleGeo(int v) {   // the middle of the bigger kitchen
  if (HOME.lvl < 1) return;
  float x0 = 29.5f, x1 = 34.5f, y0 = 5.2f, y1 = 7.8f;
  if (v == 0) { HOT.push_back({APT_SLOT + HS_ISLE, {32, 6.5f, .5f}, 15}); return; }
  if (v == 1) { Col w = HX("#a8743f"); box(x0 + 1, y0 + .4f, 2.9f, x1 - 1, y1 - .4f, 3.2f, w, 3, 0); box(x0 + 1.1f, y0 + .5f, .5f, x1 - 1.1f, y1 - .5f, .6f, w, 3, 0);
    for (float x : {x0 + 1.1f, x1 - 1.2f}) for (float y : {y0 + .5f, y1 - .6f}) box(x, y, 0, x + .1f, y + .1f, 2.9f, HX("#444"), 9); solid(x0 + 1, y0 + .4f, x1 - 1, y1 - .4f); }
  else { Col top = v == 2 ? HX("#eceae6") : HX("#f3f1ee"), base = v == 2 ? HX("#3c4a5c") : HX("#e7e4de");
    box(x0 + .1f, y0 + .1f, 0, x1 - .1f, y1 - .1f, 2.95f, base); box(x0 - .1f, y0 - .1f, 2.95f, x1 + .1f, y1 + .4f, 3.15f, top, 3, 0);
    if (v == 3) { box(x0 - .1f, y0 - .1f, 0, x0 + .1f, y1 + .4f, 2.95f, top); box(x1 - .1f, y0 - .1f, 0, x1 + .1f, y1 + .4f, 2.95f, top); }
    for (int i = 0; i < 3; i++) { float x = x0 + .8f + i * 1.6f; cyl(x, y1 + 1.0f, 0, 2.2f, .07f, .07f, HX("#333"), 6, false); cyl(x, y1 + 1.0f, 2.2f, 2.35f, .45f, .45f, v == 2 ? HX("#8a6a4a") : HX("#2b2b2b")); }
    solid(x0 - .1f, y0 - .1f, x1 + .1f, y1 + 1.5f); }
  HOT.push_back({APT_SLOT + HS_ISLE, {32, 6.5f, 3.2f}, 15});
}
static void ctrItem(int id, float cx, float cy, float z) {   // small appliances on the east counter (facing west)
  switch (id) {
    case 0: box(cx - .35f, cy - .5f, z, cx + .35f, cy + .5f, z + .65f, HX("#c9cdd2")); box(cx - .2f, cy - .35f, z + .65f, cx + .2f, cy - .05f, z + .67f, HX("#222")); box(cx - .2f, cy + .05f, z + .65f, cx + .2f, cy + .35f, z + .67f, HX("#222")); break;
    case 1: box(cx - .25f, cy - .35f, z, cx + .25f, cy + .35f, z + .8f, HX("#5a3a24")); for (int i = 0; i < 4; i++) box(cx - .15f + i * .08f, cy - .2f, z + .8f, cx - .1f + i * .08f, cy + .2f, z + 1.15f, HX("#222")); break;
    case 2: box(cx - .45f, cy - .4f, z, cx + .35f, cy + .4f, z + .2f, HX("#1d1d1f")); box(cx + .05f, cy - .4f, z + .2f, cx + .35f, cy + .4f, z + 1.25f, HX("#1d1d1f")); box(cx - .45f, cy - .4f, z + 1.0f, cx + .35f, cy + .4f, z + 1.25f, HX("#1d1d1f")); cyl(cx - .2f, cy, z + .2f, z + .75f, .25f, .27f, HX("#9fb6c6")); break;
    case 3: box(cx - .3f, cy - .3f, z, cx + .3f, cy + .3f, z + .45f, HX("#d9d9d9")); cyl(cx, cy, z + .45f, z + 1.4f, .22f, .3f, HX("#bfd9e6")); cyl(cx, cy, z + 1.4f, z + 1.5f, .3f, .3f, HX("#222")); break;
    case 4: box(cx - .45f, cy - .45f, z, cx + .4f, cy + .45f, z + .95f, HX("#2a2a2a")); box(cx - .48f, cy - .3f, z + .2f, cx - .45f, cy + .3f, z + .6f, HX("#111")); break;
    case 5: box(cx - .8f, cy - .7f, z, cx + .5f, cy + .7f, z + .95f, HX("#e8e8e4")); box(cx - .82f, cy - .55f, z + .15f, cx - .8f, cy + .3f, z + .8f, HX("#20262c")); break;
    case 6: { Col r = HX("#c8102e"); box(cx - .4f, cy - .3f, z, cx + .4f, cy + .3f, z + .12f, r); box(cx + .1f, cy - .2f, z + .12f, cx + .35f, cy + .2f, z + 1.0f, r); box(cx - .45f, cy - .25f, z + .8f, cx + .35f, cy + .25f, z + 1.15f, r); cyl(cx - .2f, cy, z + .12f, z + .55f, .25f, .3f, HX("#d0d0d0")); } break;
    case 7: box(cx - .5f, cy - .6f, z, cx + .45f, cy + .6f, z + 1.15f, HX("#b9bcc0")); box(cx - .52f, cy - .45f, z + .45f, cx - .5f, cy + .45f, z + .55f, HX("#1d1d1f")); cyl(cx - .7f, cy + .25f, z + .5f, z + .9f, .04f, .04f, HX("#ddd")); cyl(cx - .62f, cy - .2f, z, z + .25f, .12f, .14f, HX("#f2efe6")); break;
  }
}
// the jersey on the back of the front door: your team's colours, a crest with its letters
static const uint8_t FONT5[36][7] = {
  {14, 17, 17, 31, 17, 17, 17}, {30, 17, 17, 30, 17, 17, 30}, {14, 17, 16, 16, 16, 17, 14}, {30, 17, 17, 17, 17, 17, 30}, {31, 16, 16, 30, 16, 16, 31}, {31, 16, 16, 30, 16, 16, 16},
  {14, 17, 16, 23, 17, 17, 15}, {17, 17, 17, 31, 17, 17, 17}, {14, 4, 4, 4, 4, 4, 14}, {7, 2, 2, 2, 2, 18, 12}, {17, 18, 20, 24, 20, 18, 17}, {16, 16, 16, 16, 16, 16, 31},
  {17, 27, 21, 21, 17, 17, 17}, {17, 17, 25, 21, 19, 17, 17}, {14, 17, 17, 17, 17, 17, 14}, {30, 17, 17, 30, 16, 16, 16}, {14, 17, 17, 17, 21, 18, 13}, {30, 17, 17, 30, 20, 18, 17},
  {15, 16, 16, 14, 1, 1, 30}, {31, 4, 4, 4, 4, 4, 4}, {17, 17, 17, 17, 17, 17, 14}, {17, 17, 17, 17, 17, 10, 4}, {17, 17, 17, 21, 21, 21, 10}, {17, 17, 10, 4, 10, 17, 17},
  {17, 17, 10, 4, 4, 4, 4}, {31, 1, 2, 4, 8, 16, 31}, {14, 17, 19, 21, 25, 17, 14}, {4, 12, 4, 4, 4, 4, 14}, {14, 17, 1, 2, 4, 8, 31}, {30, 1, 1, 14, 1, 1, 30},
  {2, 6, 10, 18, 31, 2, 2}, {31, 16, 30, 1, 1, 17, 14}, {6, 8, 16, 30, 17, 17, 14}, {31, 1, 2, 4, 8, 8, 8}, {14, 17, 17, 14, 17, 17, 14}, {14, 17, 17, 15, 1, 2, 12}};
static void letters(const std::string &s, float cx, float y, float zc, float px, Col c) {   // block letters on a wall facing +y
  float w = (float)s.size() * 6 * px - px, x = cx + w / 2 - px;   // the wall faces +y, so seen from the room +x is to the left: lay the letters out right to left
  for (char ch : s) { int k = ch >= 'A' && ch <= 'Z' ? ch - 'A' : ch >= 'a' && ch <= 'z' ? ch - 'a' : ch >= '0' && ch <= '9' ? 26 + ch - '0' : -1;
    if (k >= 0) for (int r = 0; r < 7; r++) for (int b = 0; b < 5; b++) if (FONT5[k][r] >> (4 - b) & 1) {
      float x0 = x - b * px, z1 = zc + 3.5f * px - r * px; quad({x0, y, z1 - px}, {x0 + px, y, z1 - px}, {x0 + px, y, z1}, {x0, y, z1}, c, {0, 1, 0}, 9, true); }
    x -= 6 * px; }
}
static int jerseyTeam = -1;
static void jersey() {
  if (!CR) return; int t = C.me; jerseyTeam = t; Col pc = hex(teamCol(t)), sc = hex(teamStr(t)); float y = .135f;
  auto fq = [&](float x0, float z0, float x1, float z1, Col c, float dy) { quad({x0, y + dy, z0}, {x1, y + dy, z0}, {x1, y + dy, z1}, {x0, y + dy, z1}, c, {0, 1, 0}, 9); };
  auto sl = [&](float xa, float za, float xb, float zb, float xc, float zc2, float xd, float zd, Col c, float dy) { quad({xa, y + dy, za}, {xb, y + dy, zb}, {xc, y + dy, zc2}, {xd, y + dy, zd}, c, {0, 1, 0}, 9); };
  box(3.42f, .12f, 5.95f, 3.58f, .3f, 6.1f, HX("#9a9a9a"));   // the hook
  fq(2.8f, 3.1f, 4.2f, 5.75f, pc, 0);   // body
  sl(2.8f, 5.75f, 2.8f, 4.95f, 2.15f, 4.55f, 2.25f, 5.35f, pc, 0); sl(4.2f, 4.95f, 4.2f, 5.75f, 4.75f, 5.35f, 4.85f, 4.55f, pc, 0);   // sleeves
  fq(2.8f, 3.45f, 4.2f, 3.65f, sc, .012f); fq(2.8f, 3.75f, 4.2f, 3.85f, sc, .012f);   // hem stripes
  sl(2.36f, 4.66f, 2.22f, 4.94f, 2.29f, 5.04f, 2.44f, 4.76f, sc, .012f); sl(4.64f, 4.76f, 4.71f, 5.04f, 4.78f, 4.94f, 4.56f, 4.66f, sc, .012f);   // sleeve stripes
  sl(3.25f, 5.75f, 3.75f, 5.75f, 3.6f, 5.45f, 3.4f, 5.45f, shade(pc, -.45), .012f);   // the collar
  // the crest: two discs facing out of the door, then the team's letters
  for (int L = 0; L < 2; L++) { float r = L ? .36f : .42f; Col c = L ? pc : sc; P3 ctr = {3.5f, y + .02f + L * .012f, 4.55f}; uint32_t k = litAt(c, ctr, {0, 1, 0}).pack();
    for (int i = 0; i < 16; i++) { float a0 = i * 6.2832f / 16, a1 = (i + 1) * 6.2832f / 16; vtx(ctr, k); vtx({3.5f + std::cos(a0) * r, ctr.y, 4.55f + std::sin(a0) * r}, k); vtx({3.5f + std::cos(a1) * r, ctr.y, 4.55f + std::sin(a1) * r}, k); } }
  std::string ab = C.L[(size_t)t].ab; letters(ab, 3.5f, y + .05f, 4.55f, ab.size() > 2 ? .028f : .034f, sc);
}

// ---------------------------------------------------------------- the whole place
static Col wallPaint(P3 p, P3 n) {   // the paint on a wall face: whichever room it faces
  static const char *ORIG[HOME_NR] = {"#a29a86", "#b2a98d", "#8e8e99", "#9b9a88"}, *PAL[4] = {"", "#e9e5db", "#a3b79e", "#3a4966"};
  P3 q = p + n * .6f; if (q.x < 0 || q.y < 0 || q.x > AX || q.y > AY) return HX("#a29a86");
  int r = homeRoomAt(q.x, q.y), v = HOME.sel[HS_PAINT + r]; return HX(v ? PAL[v] : ORIG[r]);
}
static void wbox(float x0, float y0, float z0, float x1, float y1, float z1, bool bottom) {   // a wall box, each face painted for its room
  auto f = [&](P3 a, P3 b, P3 c, P3 d, P3 n) { P3 m = (a + b + c + d) * .25f; quad(a, b, c, d, wallPaint(m, n), n, 3); };
  f({x0, y0, z1}, {x1, y0, z1}, {x1, y1, z1}, {x0, y1, z1}, {0, 0, 1}); if (bottom) f({x0, y0, z0}, {x0, y1, z0}, {x1, y1, z0}, {x1, y0, z0}, {0, 0, -1});
  f({x0, y0, z0}, {x1, y0, z0}, {x1, y0, z1}, {x0, y0, z1}, {0, -1, 0}); f({x1, y1, z0}, {x0, y1, z0}, {x0, y1, z1}, {x1, y1, z1}, {0, 1, 0});
  f({x0, y1, z0}, {x0, y0, z0}, {x0, y0, z1}, {x0, y1, z1}, {-1, 0, 0}); f({x1, y0, z0}, {x1, y1, z0}, {x1, y1, z1}, {x1, y0, z1}, {1, 0, 0});
}
int homeRoomAt(double x, double y) { if (x >= 18 && y < KY) return 1; if (x >= 20 && y >= KY) return 3; if (x < 14 && y >= LY) return 2; return 0; }
static const float DOORY = 4.5f;   // the hallway doors start this far up the hall
struct HDoor { float hx, hy, side; double a = 0, tgt = 0, hold = 0; };
static HDoor HD[2] = {{14, 18.62f, -1}, {20, 18.62f, 1}};
static const float DW = 2.76f, DH = 6.95f, DT = .14f;
static void build() {
  AG.clear(); COL.clear(); HOT.clear(); LAMPS.clear(); sd = 7;
  const int L = HOME.lvl; AX = L ? 40.f : 34.f; LY = L ? 18.f : 14.f; KY = L ? 14.f : 12.f; AY = LY + 12; const float DX = AX - 34, DY = LY - 14, DK = KY - 12, dy0 = LY + DOORY;
  HD[0].hx = 14; HD[1].hx = 20; HD[0].hy = HD[1].hy = dy0 + .12f;
  LAMPS = {{{9, LY / 2, 8.4f}, .5f}, {{26 + DX / 2, KY / 2, 8.4f}, .45f}, {{7, LY + 6, 8.4f}, .38f}, {{27 + DX / 2, (KY + AY) / 2, 8.4f}, .38f}, {{17, LY + 6, 8.4f}, .3f}};
  // floors, room by room
  floorRect(0, 0, 18, LY, HOME.sel[HS_FLOOR]); floorRect(18, KY, 20, LY, HOME.sel[HS_FLOOR]); floorRect(14, LY, 20, AY, HOME.sel[HS_FLOOR]);
  floorRect(18, 0, AX, KY, HOME.sel[HS_FLOOR + 1], true); floorRect(0, LY, 14, AY, HOME.sel[HS_FLOOR + 2]); floorRect(20, KY, AX, AY, HOME.sel[HS_FLOOR + 3]);
  // the ceiling, water-stained
  quad({0, AY, CEIL}, {AX, AY, CEIL}, {AX, 0, CEIL}, {0, 0, CEIL}, HX("#c9c3b4"), {0, 0, -1}, 3.5f);
  for (int i = 0; i < 7; i++) { float x = 2 + frand() * (AX - 4), y = 2 + frand() * (AY - 4), r = .6f + frand() * 1.4f; blob(x, y, CEIL - .02f, r, 0, vary(HX("#a3957a"), .1f), {0, 0, -1}); }
  // walls: the outside, then the rooms (wall() paints each face for the room it faces)
  wall(true, 0, 0, AX, {{2, 5, 0, 7.2f}, {8, 15, 3, 7.2f}, {24, 29, 3.5f, 6.8f}}, Col());
  wall(true, AY, 0, AX, {}, Col());
  wall(false, 0, 0, AY, {{LY + 4, LY + 9, 3, 7.2f}}, Col());
  wall(false, AX, 0, AY, {{KY + 4, KY + 10, 3, 7.2f}}, Col());
  wall(true, LY, 0, 14, {}, Col()); wall(false, 14, LY, AY, {{dy0, dy0 + 3, 0, 7.2f}}, Col());
  wall(false, 20, KY, AY, {{dy0, dy0 + 3, 0, 7.2f}}, Col()); wall(true, KY, 20, AX, {}, Col());
  window(true, 0, 8, 15, 3, 7.2f, -1); window(true, 0, 24, 29, 3.5f, 6.8f, -1); window(false, 0, LY + 4, LY + 9, 3, 7.2f, -1); window(false, AX, KY + 4, KY + 10, 3, 7.2f, 1);
  // baseboards
  Col bb = HX("#d8d1bd");
  for (auto &r : std::vector<Rc>{{.25f, .25f, 18, .35f, false}, {.25f, LY - .35f, 13.75f, LY - .25f, false}}) box(r.x0, r.y0, 0, r.x1, r.y1, .35f, bb, 9);
  // holes and cracks in the drywall, room by room, until you pay to fix them
  struct WP { P3 p; P3 n; } wp[] = {{{6, .27f, 2.4f}, {0, 1, 0}}, {{16.5f, .27f, 1.2f}, {0, 1, 0}}, {{.27f, 12.0f, 3.5f}, {1, 0, 0}}, {{11.5f, LY - .27f, 1.6f}, {0, -1, 0}},
    {{13.73f, LY + 9.5f, 2.2f}, {-1, 0, 0}}, {{3.0f, AY - .27f, 4.4f}, {0, -1, 0}}, {{.27f, LY + 2.0f, 2.6f}, {1, 0, 0}},
    {{AX - .27f, 1.5f + DK, 5.6f}, {-1, 0, 0}}, {{20.27f + 0, 4.0f, 1.0f}, {1, 0, 0}}, {{22.0f, .27f, 5.0f}, {0, 1, 0}},
    {{AX - .27f, KY + 1.5f, 4.0f}, {-1, 0, 0}}, {{25.0f + DX, AY - .27f, 1.0f}, {0, -1, 0}}, {{20.27f, AY - 2.0f, 3.0f}, {1, 0, 0}}};
  for (auto &w : wp) { P3 q = w.p + w.n * .6f; int r = homeRoomAt(q.x, q.y); if (HOME.sel[HS_WALL + r]) continue;
    if (w.p.x > 19.9f && w.p.x < 20.5f && w.p.y < KY) continue;   // (no wall there: the kitchen is open)
    P3 u = std::fabs(w.n.x) > .5f ? P3{0, 1, 0} : P3{1, 0, 0}; patch(w.p, u * .45f, {0, 0, .38f}, HX("#5e5547"), w.n); patch(w.p + w.n * .012f, u * .26f, {0, 0, .22f}, HX("#2a2620"), w.n);
    for (int k = 0; k < 3; k++) { P3 a = w.p + w.n * .006f + u * (.45f + k * .35f) + P3{0, 0, .1f * (k & 1 ? 1.f : -1.f)}; patch(a, u * .18f, {0, 0, .015f}, HX("#4e463a"), w.n); } }   // a crack running off it
  for (int i = 0; i < 9; i++) { float y = .27f, x = 1 + frand() * 32, z = 1 + frand() * 6; if ((x > 1 && x < 6.2f) || (x > 7 && x < 16) || (x > 23 && x < 30)) z = std::min(z, 2.6f); if (x > 1 && x < 6.2f) continue;
    if (HOME.sel[HS_WALL + homeRoomAt(x, 1)]) continue; patch({x, y, z}, {.6f + frand(), 0, 0}, {0, 0, .03f}, HX("#6f6655"), {0, 1, 0}); }
  // the front door (and its jersey), the bathroom door
  box(2.05f, -.12f, 0, 4.95f, .12f, 7.15f, HX("#6b4a33"), 3, 0); box(4.4f, .14f, 3.3f, 4.6f, .24f, 3.5f, HX("#c8a640")); box(3.3f, -.2f, 5.4f, 3.7f, -.14f, 5.6f, HX("#222"));
  jersey();
  solid(2, -.2f, 5, .3f); HOT.push_back({APT_DOOR, {3.5f, .2f, 3.6f}, 4.5f});
  blob(3.5f, 1.2f, .035f, 1.1f, 0, HX("#5a4a3c"));   // the doormat
  box(15.5f, AY - .4f, 0, 18.5f, AY - .2f, 7.1f, HX("#e3dccb"), 3, 0); box(18.0f, AY - .5f, 3.3f, 18.2f, AY - .4f, 3.5f, HX("#9a9a9a"));
  for (float fx : {14.f, 20.f}) { Col tr = HX("#d7d0bd");   // casings: they reach into the opening (no face shared with the wall: no flicker)
    box(fx - WT - .05f, dy0 - .25f, 0, fx + WT + .05f, dy0 + .1f, 7.45f, tr, 9); box(fx - WT - .05f, dy0 + 2.9f, 0, fx + WT + .05f, dy0 + 3.25f, 7.45f, tr, 9);
    box(fx - WT - .05f, dy0 - .25f, 7.0f, fx + WT + .05f, dy0 + 3.25f, 7.45f, tr, 9, 0); }
  // bare bulbs
  for (auto &Lm : LAMPS) { box(Lm.p.x - .04f, Lm.p.y - .04f, Lm.p.z + .2f, Lm.p.x + .04f, Lm.p.y + .04f, CEIL, HX("#333")); cyl(Lm.p.x, Lm.p.y, Lm.p.z - .1f, Lm.p.z + .2f, .18f, .12f, HX("#fff2c2"), 8, true, true); }
  // ---- living room: the TV wall, the couch, a coffee table, the shelf, the mess
  entGeo(HOME.sel[HS_ENT]); HOT.push_back({APT_SLOT + HS_ENT, {1.5f, 7, entTop - .3f}, 15}); tvGeo(HOME.sel[HS_TV]); couchGeo(HOME.sel[HS_COUCH]); HOT.push_back({APT_SLOT + HS_COUCH, {11.8f, 7, 1.6f}, 15});
  if (L >= 1) reclGeo(HOME.sel[HS_RECL]);
  Col tb = HX("#5c4a36"); box(6.6f, 5.6f, 1.25f, 8.8f, 8.4f, 1.4f, tb, 3, 0); for (float x : {6.7f, 8.6f}) for (float y : {5.7f, 8.2f}) box(x, y, 0, x + .15f, y + .15f, 1.25f, tb, 9);
  solid(6.6f, 5.6f, 8.8f, 8.4f);
  if (!(HOME.junk & 8)) { box(6.9f, 6.0f, 1.4f, 8.1f, 7.2f, 1.55f, HX("#c4a066")); cyl(8.4f, 7.9f, 1.4f, 2.1f, .1f, .08f, HX("#3b6b3a")); cyl(7.2f, 8.0f, 1.4f, 2.0f, .1f, .08f, HX("#6b4a2a")); cyl(16.2f, 9.5f, 0, .1f, .35f, .1f, HX("#3b6b3a"));
    blob(14.6f, 6.2f, 0, .9f, .3f, HX("#4d566b")); blob(15.2f, 7.4f, 0, .7f, .25f, HX("#6b5d50")); blob(14.2f, 8.5f, 0, .6f, .2f, HX("#3e4a5c"));   // laundry heaped by the couch
    HOT.push_back({APT_JUNK + 3, {14.8f, 7.2f, .3f}, 7}); }
  shelfGeo();
  if (!(HOME.junk & 2)) { box(16.4f, .5f, 0, 17.6f, 1.6f, 1.5f, HX("#24302a")); box(17.0f, 1.8f, 0, 17.9f, 2.9f, 1.3f, HX("#2a352e")); solid(16.3f, .4f, 18, 3); HOT.push_back({APT_JUNK + 1, {17.2f, 1.7f, 1.2f}, 8}); }   // trash bags by the kitchen
  if (!(HOME.junk & 1)) { box(14.5f, LY - 2.5f, 0, 16.3f, LY - .6f, 1.6f, HX("#a07a4a")); box(14.8f, LY - 2.2f, 1.6f, 15.9f, LY - .9f, 2.6f, HX("#93703f")); solid(14.4f, LY - 2.6f, 16.4f, LY - .5f); HOT.push_back({APT_JUNK + 0, {15.4f, LY - 1.6f, 1.8f}, 8}); }   // moving boxes
  // ---- kitchen: base cabinets and counters along the east and back walls, upper cabinets, fridge, stove, sink, table
  Col cab = HX("#8d7a5a"), ct = HX("#8a8478"); const float EX = 31.5f + DX, KB = KY - .25f;
  box(EX, 1.0f, 0, AX - .25f, KB, 3.0f, cab); box(EX - .15f, .9f, 3.0f, AX - .25f, KB, 3.15f, ct, 3, 0); solid(EX - .1f, .9f, AX, KY);
  box(22.6f, KB - 2.25f, 0, EX, KB, 3.0f, cab); box(22.5f, KB - 2.4f, 3.0f, EX, KB, 3.15f, ct, 3, 0); solid(22.5f, KB - 2.45f, EX, KY);
  for (int i = 0; i < 6; i++) { float y = 1.2f + i * 1.75f; if (y + 1.6f < KB - .1f) box(EX - .05f, y, .3f, EX + .02f, y + 1.6f, 2.7f, vary(HX("#9a8664"), .05f)); }
  for (float x = 22.8f; x + 1.6f < EX; x += 1.75f) box(x, KB - 2.3f, .3f, x + 1.6f, KB - 2.23f, 2.7f, vary(HX("#9a8664"), .05f));
  box(EX + 1, 1.0f, 5.0f, AX - .25f, KB, 7.6f, cab); box(22.6f, KB - .95f, 5.0f, EX, KB, 7.6f, cab);
  box(EX + .92f, 1.2f, 5.6f, EX + 1.0f, 1.4f, 6.2f, HX("#a9a9a9"));   // a cabinet door hanging open
  box(20.3f, KB - 2.45f, 0, 22.4f, KB, 6.2f, HX("#d4d0c2")); box(20.25f, KB - 2.15f, 3.6f, 20.32f, KB - 2.0f, 5.0f, HX("#9a9a9a")); solid(20.2f, KB - 2.55f, 22.5f, KY);   // fridge
  box(EX, 4.2f, 3.15f, EX + 2.1f, 6.6f, 3.2f, HX("#1d1d1f")); for (int i = 0; i < 4; i++) cyl(EX + .6f + (i % 2) * .9f, 4.8f + (i / 2) * 1.2f, 3.2f, 3.22f, .3f, .3f, HX("#3a3a3a"));
  box(EX - .15f, 4.2f, 3.6f, EX, 6.6f, 3.75f, HX("#2a2a2a"));
  box(26.0f, KB - 1.95f, 2.6f, 28.4f, KB - .55f, 3.16f, HX("#5d6166"), 9, 0); cyl(27.2f, KB - .35f, 3.15f, 4.0f, .06f, .05f, HX("#b0b0b0"));
  if (!(HOME.junk & 16)) for (int i = 0; i < 4; i++) cyl(26.6f + i * .35f, KB - 1.45f, 3.16f, 3.4f + i * .05f, .25f, .25f, vary(HX("#d8d8d0"), .1f));   // dishes piled up
  if (!(HOME.junk & 16)) HOT.push_back({APT_JUNK + 4, {27.2f, KB - 1.2f, 3.4f}, 7});
  Col tt = HX("#7a6a52"); box(23.0f, 3.0f, 2.4f, 26.5f, 6.0f, 2.55f, tt, 3, 0); for (float x : {23.1f, 26.3f}) for (float y : {3.1f, 5.8f}) box(x, y, 0, x + .1f, y + .1f, 2.4f, tt, 9);
  for (float y : {2.2f, 6.2f}) { Col ch = HX("#5a5a5e"); bool s = y < 4; box(24.2f, y, 1.5f, 25.4f, y + .9f, 1.6f, ch); box(24.2f, s ? y : y + .8f, 1.6f, 25.4f, s ? y + .1f : y + .9f, 3.3f, ch);   // chairs: seat, back
    for (float lx : {24.25f, 25.27f}) for (float ly : {y + .05f, y + .77f}) box(lx, ly, 0, lx + .08f, ly + .08f, 1.5f, HX("#3d3d40"), 9); }   // and four legs each
  solid(23.0f, 2.2f, 26.5f, 7.1f);
  // the counter: up to four small appliances, and the spot to look at in build mode
  { const float ys[HOME_NCTR] = {1.8f, 3.3f, 7.6f, 9.3f}; for (int k = 0; k < HOME_NCTR; k++) if (HOME.ctr[k] >= 0 && ys[k] + .8f < KB) ctrItem(HOME.ctr[k], EX + 1.0f, ys[k], 3.15f);
    HOT.push_back({APT_COUNTER, {EX + .9f, 3.0f, 3.4f}, 14}); }
  if (L >= 1) isleGeo(HOME.sel[HS_ISLE]);
  // ---- bedroom: a mattress on the floor, a dresser, clothes
  box(1.0f, 19.0f + DY, 0, 6.5f, 25.7f + DY, .9f, HX("#bdb6a2"), 2); box(1.4f, 24.3f + DY, .9f, 4.0f, 25.4f + DY, 1.3f, HX("#e1ddd0"), 2); box(1.1f, 19.2f + DY, .9f, 6.2f, 22.8f + DY, 1.05f, HX("#4a5a73"), 2);
  solid(1.0f, 19.0f + DY, 6.5f, 25.7f + DY);
  box(9.5f, 24.4f + DY, 0, 13.5f, 25.75f + DY, 3.2f, HX("#6e5a44")); box(9.6f, 24.3f + DY, 2.2f, 13.4f, 24.4f + DY, 3.0f, HX("#5a4936")); solid(9.5f, 24.3f + DY, 13.5f, 25.8f + DY);
  box(7.0f, 24.4f + DY, 0, 8.2f, 25.6f + DY, 1.1f, HX("#2f5a9a")); cyl(7.6f, 25.0f + DY, 1.1f, 2.0f, .25f, .15f, HX("#e9e2c8"));
  if (!(HOME.junk & 8)) for (int i = 0; i < 4; i++) blob(4 + i * 1.9f, LY + 2 + (i & 1) * .9f, 0, .55f + frand() * .3f, .18f, vary(HX("#6b5a62"), .15f));   // clothes on the floor
  // ---- office: a folding table, the computer, a sagging bookshelf, boxes
  Col ft = HX("#8a8a84"); const float OX = 28.5f + DX, OY = 23.4f + DY;
  box(OX, OY, 2.4f, OX + 5, OY + 2.2f, 2.5f, ft, 3, 0); for (float x : {OX + .1f, OX + 4.8f}) for (float y : {OY + .1f, OY + 2.0f}) box(x, y, 0, x + .08f, y + .08f, 2.4f, HX("#444"), 9);
  solid(OX, OY, OX + 5, OY + 2.2f); box(OX + 1.8f, OY + .9f, 2.5f, OX + 3.4f, OY + 2.1f, 3.8f, HX("#c9c3b0")); box(OX + 1.95f, OY + .85f, 2.75f, OX + 3.25f, OY + .9f, 3.6f, HX("#2b5d8a"), 9, 0, true);
  box(OX + 2.0f, OY + .3f, 2.5f, OX + 3.2f, OY + .7f, 2.56f, HX("#d6d0bf"));   // keyboard
  HOT.push_back({APT_PC, {OX + 2.6f, OY + .85f, 3.2f}, 7});
  box(OX + 1.5f, OY - 1.8f, 1.5f, OX + 2.9f, OY - .5f, 1.6f, HX("#55555a")); box(OX + 1.5f, OY - .6f, 1.6f, OX + 2.9f, OY - .5f, 3.4f, HX("#55555a")); for (float x : {OX + 1.6f, OX + 2.7f}) for (float y : {OY - 1.7f, OY - .7f}) box(x, y, 0, x + .07f, y + .07f, 1.5f, HX("#333"), 9);
  box(20.3f, 13.0f + DK, 0, 21.2f, 17.0f + DK, 6.0f, HX("#6a5236")); for (int s = 0; s < 4; s++) { float z = .4f + s * 1.45f; for (float y = 13.2f + DK; y < 16.6f + DK; y += .25f + frand() * .2f) if (frand() < .7f) box(20.4f, y, z, 21.0f, y + .18f, z + .7f + frand() * .3f, vary(HX("#8a4a3a"), .6f)); }
  solid(20.2f, 12.9f + DK, 21.3f, 17.1f + DK);
  if (!(HOME.junk & 4)) { box(22.0f, 24.0f + DY, 0, 24.2f, 25.7f + DY, 1.8f, HX("#a07a4a")); box(22.3f, 24.3f + DY, 1.8f, 23.8f, 25.5f + DY, 3.0f, HX("#93703f")); solid(21.9f, 23.9f + DY, 24.3f, 25.8f + DY); HOT.push_back({APT_JUNK + 2, {23.1f, 24.8f + DY, 1.8f}, 8}); }
  // the GPU keeps it until something changes
  aptVer++; aptOk = true;
}

// ---------------------------------------------------------------- you
static struct { double x = 3.5, y = 2.4, yaw = .85, pitch = -.05; bool set = false, sit = false; double sitT = 0; float lx = 0, ly = 0; int tid = -1; float tx0 = 0, ty0 = 0; bool tLook = false; } Me;
bool aptBuild = false;
static void collide(double &x, double &y);
void aptReset() { Me.x = 3.5; Me.y = 2.6; Me.yaw = .85; Me.pitch = -.05; Me.set = true; Me.sit = false; }
// after a game you're on the couch (looking at the TV); X stands you up in front of it
void aptSit() { Me.x = 11.7; Me.y = 7.0; Me.yaw = 3.14159; Me.pitch = -.08; Me.set = true; Me.sit = true; Me.sitT = 0; }
bool aptSitting() { return Me.sit; }
void aptStand() { if (!Me.sit) return; Me.sit = false; Me.sitT = 1; Me.x = 9.6; Me.y = 4.6; Me.yaw = 3.14159 * .75; collide(Me.x, Me.y); }
void aptView(double x, double y, double yaw, double pitch) { Me.x = x; Me.y = y; Me.yaw = yaw; Me.pitch = pitch; Me.set = true; }
static const double EYE = 5.4, SEYE = 3.9, RAD = .9;
static void doorRects(std::vector<Rc> &v);
static void collide(double &x, double &y) {
  x = std::max(WT + RAD, std::min(AX - WT - RAD, x)); y = std::max(WT + RAD, std::min(AY - WT - RAD, y));
  static std::vector<Rc> all; all = COL; doorRects(all);
  for (int it = 0; it < 2; it++) for (auto &r : all) { double cx = std::max((double)r.x0, std::min(x, (double)r.x1)), cy = std::max((double)r.y0, std::min(y, (double)r.y1)), dx = x - cx, dy = y - cy, d2 = dx * dx + dy * dy;
    if (d2 >= RAD * RAD) continue;
    if (d2 < 1e-8) { double pl = x - r.x0, pr = r.x1 - x, pb = y - r.y0, pt = r.y1 - y, m = std::min(std::min(pl, pr), std::min(pb, pt)); if (m == pl) x = r.x0 - RAD; else if (m == pr) x = r.x1 + RAD; else if (m == pb) y = r.y0 - RAD; else y = r.y1 + RAD; continue; }
    double d = std::sqrt(d2), k = (RAD - d) / d; x += dx * k; y += dy * k; }
}

// ---------------------------------------------------------------- the hallway doors: they swing into the room and close behind you

static P3 doorDir(const HDoor &d) { double th = d.a * 1.55; return {(float)(std::sin(th) * d.side), (float)std::cos(th), 0}; }   // along the slab, hinge to latch
static P3 doorMid(const HDoor &d) { P3 u = doorDir(d); return {d.hx + u.x * DW / 2, d.hy + u.y * DW / 2, 3.6f}; }
bool aptDoorOpen(int i) { return i >= 0 && i < 2 && HD[i].tgt > .5; }
void aptDoor(int i) { if (i < 0 || i > 1) return; HDoor &d = HD[i]; d.tgt = d.tgt > .5 ? 0 : 1; d.hold = 4.5; }
static bool inSwing(const HDoor &d, double x, double y) { double dx = x - d.hx, dy = y - d.hy - DW / 2; return std::fabs(dy) < DW / 2 + RAD && dx * d.side > -RAD - .4 && dx * d.side < DW + RAD; }
static void doorsTick(double dt) {
  for (auto &d : HD) {
    if (d.tgt > .5 && d.a > .99) { d.hold -= dt; if (d.hold <= 0) { if (inSwing(d, Me.x, Me.y)) d.hold = .5; else d.tgt = 0; } }   // it waits for you to clear the swing
    double sp = 1.6 * dt; if (d.tgt > d.a) d.a = std::min(d.tgt, d.a + sp); else if (d.tgt < d.a) { if (d.a < .99 || !inSwing(d, Me.x, Me.y)) d.a = std::max(d.tgt, d.a - sp); }
  }
}
// solid while shut; once open, the slab against its swing
static void doorRects(std::vector<Rc> &v) {
  for (auto &d : HD) { if (d.a < .15) v.push_back({d.hx - .12f, d.hy, d.hx + .12f, d.hy + DW, false});
    else if (d.a > .9) { P3 u = doorDir(d); float x1 = d.hx + u.x * DW, y1 = d.hy + u.y * DW; v.push_back({std::min(d.hx, x1) - .08f, std::min(d.hy, y1) - .08f, std::max(d.hx, x1) + .08f, std::max(d.hy, y1) + .08f, false}); } }
}
static void obox(P3 o, P3 u, P3 v, float lu, float lv, float z0, float z1, Col c) {   // a box along u (length lu) and v (thickness lv, centred)
  P3 a = o - v * (lv / 2), b = a + u * lu, cc = b + v * lv, dd = a + v * lv; P3 z = {0, 0, z1 - z0}; a.z = b.z = cc.z = dd.z = z0;
  P3 nv = v * -1;
  quad(a, b, b + z, a + z, c, nv, 9); quad(cc, dd, dd + z, cc + z, c, v, 9); quad(b, cc, cc + z, b + z, c, u, 9); quad(dd, a, a + z, dd + z, c, u * -1, 9);
  quad(a + z, b + z, cc + z, dd + z, c, {0, 0, 1}, 9);
}
static void doorTris() {
  DY.clear(); OUT = &DY;
  for (auto &d : HD) { P3 u = doorDir(d), v = {-u.y, u.x, 0}, h = {d.hx, d.hy, 0};
    obox(h + u * .02f, u, v, DW, DT, 0, DH, HX("#e6dfcf"));
    for (float k : {-1.f, 1.f}) obox(h + u * (DW - .45f) + v * (k * (DT / 2 + .06f)), u, v, .14f, .12f, 3.2f, 3.4f, HX("#b8b8b8"));   // the knobs
  }
  OUT = &AG;
}
void aptMove(const Pad &pad, const Touch &touch, double dt) {
  if (!aptLoaded) return;   // not loaded: the loading screen builds it
  if (!aptOk) build();
  auto ax = [](int v) { double a = (v - 128) / 127.0; return std::fabs(a) < .18 ? 0.0 : (a - (a > 0 ? .18 : -.18)) / .82; };
  double mx = ax(pad.lx), my = -ax(pad.ly), lx = ax(pad.rx), ly = -ax(pad.ry);
  if (pad.btn & B_UP) my = 1; if (pad.btn & B_DOWN) my = -1; if (pad.btn & B_RIGHT) mx = 1;
  // touch: the left half is a stick to walk, the right half drags the view
  bool lt = false; for (int i = 0; i < touch.n; i++) { const TouchPt &p = touch.p[i];
    if (p.id != Me.tid) { Me.tid = p.id; Me.tx0 = p.x; Me.ty0 = p.y; Me.tLook = p.x > W / 2; Me.lx = p.x; Me.ly = p.y; }
    if (Me.tLook) { Me.yaw -= (p.x - Me.lx) * .006; Me.pitch -= (p.y - Me.ly) * .005; Me.lx = p.x; Me.ly = p.y; }
    else { mx = std::max(-1.0, std::min(1.0, (p.x - Me.tx0) / (.12 * U))); my = std::max(-1.0, std::min(1.0, -(p.y - Me.ty0) / (.12 * U))); }
    lt = true; break; }
  if (!lt) Me.tid = -1;
  Me.yaw -= lx * 2.3 * dt; Me.pitch = std::max(-1.2, std::min(1.1, Me.pitch + ly * 1.6 * dt));
  if (Me.sit) { Me.yaw = std::max(3.14159 * .55, std::min(3.14159 * 1.45, Me.yaw)); doorsTick(dt); return; }   // seated: look around, no walking
  if (Me.sitT > 0) Me.sitT = std::max(0.0, Me.sitT - dt * 2.5);   // getting up
  double sp = 7.5 * dt, fx = std::cos(Me.yaw), fy = std::sin(Me.yaw);
  double nx = Me.x + (fx * my + fy * mx) * sp, ny = Me.y + (fy * my - fx * mx) * sp; collide(nx, ny); Me.x = nx; Me.y = ny;
  doorsTick(dt);
}

// ---------------------------------------------------------------- the camera and the draw
static struct { P3 e, f, r, u; double F, sx, sy; } AC;
static void camSet() {
  if (!Me.set) aptReset();
  AC.e = {(float)Me.x, (float)Me.y, (float)(Me.sit ? SEYE : EYE - (EYE - SEYE) * Me.sitT)};
  AC.f = {(float)(std::cos(Me.yaw) * std::cos(Me.pitch)), (float)(std::sin(Me.yaw) * std::cos(Me.pitch)), (float)std::sin(Me.pitch)};
  AC.r = nrm3(cross3(AC.f, {0, 0, 1})); AC.u = cross3(AC.r, AC.f);
  AC.F = W / 2 / std::tan(36 * 3.14159 / 180); AC.sx = W / 2; AC.sy = H / 2;
}
int aptLook() {
  if (!aptLoaded) return APT_NONE; if (!aptOk) build(); camSet(); int best = APT_NONE; double bc = .9;
  auto seen = [&](P3 p, bool door) {   // nothing but air (no wall, no shut door) between your eyes and it
    std::vector<Rc> W2; for (auto &r : COL) if (r.wall) W2.push_back(r); if (!door) for (auto &d : HD) if (d.a < .15) W2.push_back({d.hx - .1f, d.hy, d.hx + .1f, d.hy + DW, true});
    double x0 = AC.e.x, y0 = AC.e.y, dx = p.x - x0, dy = p.y - y0;
    for (auto &r : W2) { double t0 = 0, t1 = .92; auto slab = [&](double o, double dd, double lo, double hi) { if (std::fabs(dd) < 1e-9) return o > lo && o < hi; double a = (lo - o) / dd, b = (hi - o) / dd; if (a > b) std::swap(a, b); t0 = std::max(t0, a); t1 = std::min(t1, b); return t0 < t1; };
      if (slab(x0, dx, r.x0 + .02, r.x1 - .02) && slab(y0, dy, r.y0 + .02, r.y1 - .02)) return false; }
    return true; };
  std::vector<Hot> hs = HOT; for (int i = 0; i < 2; i++) { P3 m = doorMid(HD[i]); m.z = 4.6f; hs.push_back({APT_HDOOR + i, m, 6}); }
  for (auto &h : hs) { if (!aptBuild && (h.id >= APT_SLOT || h.id == APT_COUNTER)) continue;
    P3 d = h.p - AC.e; double dl = std::sqrt(dot3(d, d)); if (dl > h.r) continue; double c = dot3(d, AC.f) / std::max(.1, dl), need = dl < 4.5 ? .78 : .9;
    if (c > need && c - need > bc - .9 && seen(h.p, h.id == APT_HDOOR || h.id == APT_HDOOR + 1)) { bc = c - need + .9; best = h.id; } }
  if (best != APT_NONE || !aptBuild) return best;
  // build mode: the floor you look down at, or the wall in front of you (drywall first, then paint), room by room
  if (AC.f.z < -.45f) { double t = -AC.e.z / AC.f.z, fx = AC.e.x + AC.f.x * t, fy = AC.e.y + AC.f.y * t; if (t < 14) return APT_SLOT + HS_FLOOR + homeRoomAt(fx, fy); }
  if (std::fabs(AC.f.z) < .5f) {   // the nearest wall along the view
    double x0 = AC.e.x, y0 = AC.e.y, dx = AC.f.x, dy = AC.f.y, bt = 1e9;
    for (auto &r : COL) { if (!r.wall) continue; double t0 = 0, t1 = 12; auto slab = [&](double o, double dd, double lo, double hi) { if (std::fabs(dd) < 1e-9) return o > lo && o < hi; double a = (lo - o) / dd, b = (hi - o) / dd; if (a > b) std::swap(a, b); t0 = std::max(t0, a); t1 = std::min(t1, b); return t0 < t1; };
      if (slab(x0, dx, r.x0, r.x1) && slab(y0, dy, r.y0, r.y1) && t0 < bt) bt = t0; }
    if (bt < 12) { int rm = homeRoomAt(x0, y0); return APT_SLOT + (HOME.sel[HS_WALL + rm] ? HS_PAINT : HS_WALL) + rm; }
  }
  return best;
}
static const double NEAR = .25, FAR = 150;
struct T2 { float x[3], y[3], d; uint32_t c; }; static std::vector<T2> Q;   // the no-GPU path's sorted triangles
bool aptReady() { return aptLoaded; }
void aptLoad() { if (!aptOk) build(); aptLoaded = true; }
void aptUnload() {
  plat_draw3d_free((const void *)&AG); std::vector<V3c>().swap(AG); std::vector<Rc>().swap(COL); std::vector<Hot>().swap(HOT); std::vector<T2>().swap(Q); std::vector<V3c>().swap(DY); aptOk = aptLoaded = false; for (auto &d : HD) { d.a = d.tgt = 0; }
}
static void clipM(float *m) {
  const double n = NEAR, f = FAR, A = 2 * AC.F / W, B = 2 * AC.sx / W - 1, Cc = 2 * AC.F / H, D = 1 - 2 * AC.sy / H, E = (f + n) / (f - n), G = -2 * f * n / (f - n);
  const P3 R = AC.r, Uu = AC.u, Fw = AC.f, e = AC.e;
  double rows[4][4] = {{A * R.x + B * Fw.x, A * R.y + B * Fw.y, A * R.z + B * Fw.z, -A * dot3(R, e) - B * dot3(Fw, e)},
    {Cc * Uu.x + D * Fw.x, Cc * Uu.y + D * Fw.y, Cc * Uu.z + D * Fw.z, -Cc * dot3(Uu, e) - D * dot3(Fw, e)},
    {E * Fw.x, E * Fw.y, E * Fw.z, -E * dot3(Fw, e) + G}, {Fw.x, Fw.y, Fw.z, -dot3(Fw, e)}};
  for (int c = 0; c < 4; c++) for (int r = 0; r < 4; r++) m[c * 4 + r] = (float)rows[r][c];
}
void aptDraw() {
  if (CR && aptOk && jerseyTeam != C.me) aptOk = false;   // traded: a new jersey on the door
  if (!aptLoaded) return; if (!aptOk) build(); camSet();
  ctx.fill("#1a1712"); ctx.fillRect(0, 0, W, H); ctx.flush();
  doorTris();
  if (plat_gpu3d()) { float M[16]; clipM(M); plat_draw3d_static(M, (const void *)&AG, AG.data(), (int)AG.size(), 0, -1, aptVer); plat_draw3d(M, DY.data(), (int)DY.size(), 0, -1); return; }
  // no GPU 3D (the vita2d build): clip at the near plane, project, sort back to front
  Q.clear();
  for (const std::vector<V3c> *L : {&AG, &DY}) for (size_t i = 0; i + 2 < L->size(); i += 3) { const std::vector<V3c> &G = *L;
    P3 cam[3]; for (int k = 0; k < 3; k++) { P3 p = {G[i + k].x, G[i + k].y, G[i + k].z}, v = p - AC.e; cam[k] = {dot3(v, AC.r), dot3(v, AC.u), dot3(v, AC.f)}; }
    P3 out[6]; int no = 0; for (int k = 0; k < 3; k++) { P3 a = cam[k], b = cam[(k + 1) % 3]; float da = a.z - (float)NEAR, db = b.z - (float)NEAR; if (da >= 0) out[no++] = a; if ((da >= 0) != (db >= 0)) out[no++] = a + (b - a) * (da / (da - db)); }
    if (no < 3) continue; float dz = 0; for (int k = 0; k < no; k++) dz = std::max(dz, out[k].z);
    for (int k = 1; k + 1 < no; k++) { T2 t; P3 q[3] = {out[0], out[k], out[k + 1]}; for (int m = 0; m < 3; m++) { t.x[m] = (float)(AC.sx + q[m].x / q[m].z * AC.F); t.y[m] = (float)(AC.sy - q[m].y / q[m].z * AC.F); } t.d = dz; t.c = G[i].c; Q.push_back(t); } }
  std::sort(Q.begin(), Q.end(), [](const T2 &a, const T2 &b) { return a.d > b.d; });
  for (auto &t : Q) ctx.rawTri(t.x[0], t.y[0], t.x[1], t.y[1], t.x[2], t.y[2], t.c);
}
void aptHUD() {
  int lk = aptLook(); bool hot = lk != APT_NONE;
  ctx.fill(hot ? rgba(255, 213, 74, .95) : rgba(255, 255, 255, .7)); ctx.oval(W / 2, H / 2, hot ? 5 : 3, hot ? 5 : 3);
}
const char *APT_JUNKN[APT_NJUNK] = {"THE MOVING BOXES", "THE TRASH BAGS", "THE OFFICE BOXES", "THE LAUNDRY AND PIZZA BOXES", "THE DIRTY DISHES"};
void aptThrow(int bit) { if (bit < 0 || bit >= APT_NJUNK) return; HOME.junk |= 1 << bit; if (CR) proSave(); aptDirty(); }
#undef C
int aptTris() { if (!aptOk) build(); return (int)AG.size() / 3; }
void aptPos(double &x, double &y) { x = Me.x; y = Me.y; }

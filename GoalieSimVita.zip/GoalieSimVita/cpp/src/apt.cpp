// CHL 2026 native - BE A PRO: the apartment. Two sizes: the starter (34 x 26 ft) and the corner unit (40 x 30 ft), both
// with 9 ft ceilings: living room and an open kitchen along the front, a hall to the bedroom and the office. Built
// from lit, vertex-coloured boxes (feet: x east, y north, z up), drawn by the GPU in one static batch, walked in first person.
#include "apt.h"
#include "pro.h"
#include "json.h"
#include <algorithm>
#include <cmath>
#include <cstring>

#define C (*CR)
// ---------------------------------------------------------------- what you can buy (fx: small rating nudges, more for the good stuff)
const char *ROOMN[HOME_NR] = {"LIVING ROOM", "KITCHEN", "BEDROOM", "OFFICE"};
static const HomeSlotDef FLOORDEF = {"FLOORING", {{"WORN CARPET", 0, "Stained, flattened, smells like the last tenant.", ""}, {"VINYL PLANK", 600, "Clean grey-oak planks. Wipes right up.", "edge:0.1"},
  {"OAK HARDWOOD", 2000, "Real wood, warm and narrow-planked.", "edge:0.25,skate:0.1"}, {"MARBLE TILE", 6000, "Polished white marble with grey veins.", "edge:0.5,skate:0.25"}}, 0};
static const HomeSlotDef PAINTDEF = {"PAINT", {{"DINGY BEIGE", 0, "Whatever the last tenant left, plus nicotine.", ""}, {"FRESH WHITE", 200, "Clean, bright, simple.", "sacc:0.1"},
  {"SAGE GREEN", 350, "Calm and earthy.", "sacc:0.15,wpow:0.1"}, {"DEEP NAVY", 600, "A moody accent colour. Very grown-up.", "sacc:0.25,wpow:0.15"}}, 0};
static const HomeSlotDef WALLDEF = {"DRYWALL", {{"HOLES AND CRACKS", 0, "Fist-sized holes and a crack you could post a letter through.", ""},
  {"PATCH, TAPE AND SAND", 400, "Smooth walls, ready for paint.", "check:0.15"}}, 0};
const HomeSlotDef HSLOT[HOME_NS] = {
  {"COUCH", {{"CURBSIDE FUTON", 0, "Found it on the curb. Sags in the middle.", ""}, {"THRIFT STORE SOFA", 250, "A brown three-seater with all its springs.", "fstam:0.25"},
    {"LEATHER SECTIONAL", 1400, "Dark leather L with a chaise for film study.", "fstam:0.5,pass:0.25"}, {"DESIGNER MODULAR", 5000, "Low, deep, pale-grey modules and bright pillows.", "fstam:1,pass:0.5"}}, 0},
  {"TV", {{"OLD CRT", 0, "Twenty-inch tube. The picture rolls.", ""}, {"40\" LED", 300, "A thin flat screen. Finally.", "pass:0.25"},
    {"65\" 4K", 1100, "Big, sharp and bright. Great for film.", "pass:0.5,deke:0.25"}, {"85\" OLED", 4000, "Wall-sized and paper thin.", "pass:1,deke:0.5"}}, 0},
  {"ENTERTAINMENT CENTER", {{"MILK CRATES", 0, "Two crates and a plank.", ""}, {"PARTICLE BOARD STAND", 150, "Black, flat-packed, a little wobbly.", "hand:0.15"},
    {"OAK MEDIA CONSOLE", 800, "Solid oak with drawers for the games.", "hand:0.35"}, {"FLOATING WALNUT UNIT", 3000, "Wall-mounted walnut with a glowing light strip.", "hand:0.75,deke:0.25"}}, 0},
  {"RECLINER", {{"EMPTY CORNER", 0, "Room for one more seat.", ""}, {"THRIFT RECLINER", 400, "Corduroy, but it reclines.", "fstam:0.25"},
    {"LEATHER POWER RECLINER", 1800, "One button and you're horizontal.", "fstam:0.5,edge:0.25"}, {"ZERO-GRAVITY MASSAGE CHAIR", 6000, "Kneads the legs after a long road trip.", "fstam:1,edge:0.5"}}, 1},
  {"KITCHEN ISLAND", {{"EMPTY FLOOR", 0, "A lot of linoleum.", ""}, {"BUTCHER BLOCK CART", 500, "Rolls around. Somewhere to chop.", "skate:0.25"},
    {"QUARTZ ISLAND", 2500, "White quartz top, stools on one side.", "skate:0.5,check:0.25"}, {"WATERFALL MARBLE ISLAND", 7000, "The marble runs down both ends.", "skate:1,check:0.5"}}, 1},
  FLOORDEF, FLOORDEF, FLOORDEF, FLOORDEF, PAINTDEF, PAINTDEF, PAINTDEF, PAINTDEF, WALLDEF, WALLDEF, WALLDEF, WALLDEF,
  {"BED", {{"MATTRESS ON THE FLOOR", 0, "Lumpy, and it's on the carpet.", ""}, {"METAL FRAME BED", 300, "Off the floor at last. Squeaks.", "fstam:0.25"},
    {"OAK PLATFORM BED", 1500, "Low oak frame, a real headboard, nightstands.", "fstam:0.5,poise:0.25"}, {"KING UPHOLSTERED BED", 5000, "A tall tufted headboard and hotel sheets. Sleep like a franchise player.", "fstam:1,poise:0.5"}}, 0},
  {"THE BAR", {{"EMPTY CORNER", 0, "A bare corner of the man cave.", ""}, {"BAR CART", 800, "Brass, on wheels, a few bottles.", "pass:0.15"},
    {"OAK BAR AND STOOLS", 3500, "A real bar top, four stools and a back shelf.", "pass:0.35,check:0.15"}, {"BACKLIT SPORTS BAR", 9000, "Glowing shelves, beer taps, a neon sign. The whole team will want to come over.", "pass:0.75,check:0.35"}}, 2},
  {"GAME TABLE", {{"NOTHING", 0, "Open floor.", ""}, {"DARTBOARD", 300, "Cork, a chalkboard, a few holes in the drywall.", "sacc:0.15"},
    {"AIR HOCKEY TABLE", 2200, "Hand-eye on the off days.", "hand:0.35,deke:0.15"}, {"TOURNAMENT POOL TABLE", 6500, "Slate bed, green felt, a light over it.", "sacc:0.5,slacc:0.35"}}, 2},
  {"CAVE SEATING", {{"FOLDING CHAIRS", 0, "Three of them, facing a bare wall.", ""}, {"GAMING SETUP", 1500, "A racing chair, a desk and three glowing monitors.", "hand:0.25,pass:0.15"},
    {"THEATER RECLINERS", 4500, "A row of leather recliners and a big screen on the wall.", "fstam:0.5,deke:0.25"}, {"STADIUM SUITE", 12000, "Two tiers of recliners, a 120-inch screen, a popcorn machine.", "fstam:1,deke:0.5"}}, 2},
  {"PAINT", {{"AS IT CAME", 0, "Whatever colour the tile grout left it.", ""}, {"FRESH PAINT", 250, "Mould-proof bathroom paint, any colour you like.", "sacc:0.1"}}, 0},
  {"PAINT", {{"CHARCOAL", 0, "Dark and moody, the way the builder left it.", ""}, {"FRESH PAINT", 400, "Any colour you like. Team colours, maybe.", "sacc:0.15"}}, 2},
  {"GAME CONSOLE", {{"NO CONSOLE", 0, "Nothing hooked up to the TV yet.", ""}, {"CHL STATION", 299, "A proof-of-concept console with one game so far: PONG. Walk up to it and press X.", "hand:0.1"}}, 0}};
// ---------------------------------------------------------------- colours
static const std::vector<Swatch> SW_FABRIC = {{"CHARCOAL", "#3a3d42"}, {"CREAM", "#d9d0bd"}, {"NAVY", "#26344f"}, {"FOREST", "#2f4a36"}, {"BURGUNDY", "#5e2330"}, {"CAMEL", "#a0784a"}, {"SKY", "#7aa3c4"}, {"MUSTARD", "#c19a2e"}, {"BLUSH", "#c98f8f"}, {"SLATE", "#5b6670"}};
static const std::vector<Swatch> SW_WOOD = {{"NATURAL OAK", "#a8743f"}, {"WALNUT", "#5a3a24"}, {"ESPRESSO", "#2e2019"}, {"WHITEWASH", "#d8d0c2"}, {"MATTE BLACK", "#1d1d20"}, {"CHERRY", "#7a3324"}, {"ASH GREY", "#8a8580"}, {"HONEY", "#c08a3e"}};
static const std::vector<Swatch> SW_PAINT = {{"BRIGHT WHITE", "#ecebe6"}, {"GREIGE", "#bdb5a6"}, {"SAGE", "#a3b79e"}, {"NAVY", "#3a4966"}, {"TERRACOTTA", "#b8694a"}, {"SLATE BLUE", "#6d8096"}, {"BLUSH", "#d8b4ac"}, {"CHARCOAL", "#45484d"}, {"BUTTER", "#e8d79a"}, {"TEAL", "#3f7a78"}, {"OLIVE", "#7c7a4a"}, {"LAVENDER", "#a89cc0"}};
static const std::vector<Swatch> SW_FLOOR = {{"HONEY", "#b98a52"}, {"WALNUT", "#6b4428"}, {"GREY OAK", "#9a9690"}, {"WHITE OAK", "#d6c7a8"}, {"EBONY", "#3a2e28"}, {"RED OAK", "#9b5a3a"}, {"CHARCOAL", "#4a4a4c"}, {"SAND", "#cdbb97"}};
static const std::vector<Swatch> SW_CAB = {{"NAVY", "#3c4a5c"}, {"WHITE", "#e7e4de"}, {"SAGE", "#7d9480"}, {"BLACK", "#202024"}, {"OAK", "#a8743f"}, {"GREY", "#8c9096"}, {"FOREST", "#2f4a36"}, {"WALNUT", "#5a3a24"}};
static const std::vector<Swatch> SW_FELT = {{"CLASSIC GREEN", "#1f6b3a"}, {"TOURNAMENT BLUE", "#1f4f8a"}, {"RED", "#8a1f24"}, {"BLACK", "#202022"}, {"PURPLE", "#55307a"}, {"TAN", "#a48a5a"}, {"TEAL", "#1f6f6a"}};
static const std::vector<Swatch> SW_METAL = {{"STAINLESS", "#b9bcc0"}, {"BLACK", "#1d1d1f"}, {"WHITE", "#ecebe8"}, {"CANDY RED", "#c8102e"}, {"MINT", "#9ad3bc"}, {"CREAM", "#ece1c4"}, {"COBALT", "#2f64d6"}, {"BUTTER", "#e9c95a"}, {"ROSE GOLD", "#c9907a"}};
static const std::vector<Swatch> SW_NONE;
const std::vector<Swatch> &homeSwatches(int s, int o) {
  if (s >= HS_WALL && s < HS_WALL + HOME_NR) return SW_NONE;                      // drywall: just fixed
  if ((s >= HS_PAINT && s < HS_PAINT + HOME_NR) || s == HS_BPAINT || s == HS_CPAINT) return o > 0 ? SW_PAINT : SW_NONE;
  if (s >= HS_FLOOR && s < HS_FLOOR + HOME_NR) return o > 0 ? SW_FLOOR : SW_NONE;   // (the old carpet / linoleum: no)
  switch (s) { case HS_COUCH: case HS_RECL: case HS_BED: case HS_CAVE: return o > 0 || s == HS_COUCH || s == HS_BED ? SW_FABRIC : SW_NONE;
    case HS_ENT: case HS_BAR: return o > 0 || s == HS_ENT ? SW_WOOD : SW_NONE; case HS_TV: return SW_METAL; case HS_ISLE: return o > 0 ? SW_CAB : SW_NONE;
    case HS_GAME: return o >= 2 ? SW_FELT : SW_NONE; }
  return SW_NONE;
}
const std::vector<Swatch> &ctrSwatches() { return SW_METAL; }
void homeSetCol(int s, int c) { if (s < 0 || s >= HOME_NS) return; const auto &v = homeSwatches(s, HOME.sel[s]); HOME.col[s] = c >= 0 && c < (int)v.size() ? c : -1; if (CR) proSave(); aptDirty(); }
void homeSetCtrCol(int i, int c) { if (i < 0 || i >= 16) return; HOME.ctrCol[i] = c >= 0 && c < (int)SW_METAL.size() ? c : -1; if (CR) proSave(); aptDirty(); }
// the colour a slot's main material comes out in: the swatch you picked, or what it came in
static Col K(int s, const char *orig) { const auto &v = homeSwatches(s, HOME.sel[s]); int c = HOME.col[s]; return c >= 0 && c < (int)v.size() ? hex(v[(size_t)c].c) : hex(orig); }
std::string homeSlotName(int s) {
  if (s >= HS_FLOOR && s < HS_FLOOR + HOME_NR) return std::string("FLOORING  |  ") + ROOMN[s - HS_FLOOR];
  if (s >= HS_PAINT && s < HS_PAINT + HOME_NR) return std::string("PAINT  |  ") + ROOMN[s - HS_PAINT];
  if (s >= HS_WALL && s < HS_WALL + HOME_NR) return std::string("DRYWALL  |  ") + ROOMN[s - HS_WALL];
  if (s == HS_BPAINT) return "PAINT  |  BATHROOM"; if (s == HS_CPAINT) return "PAINT  |  MAN CAVE";
  return s >= 0 && s < HOME_NS ? HSLOT[s].n : "";
}
const std::vector<HomeOpt> COUNTER = {{"TOASTER", 60, "Two slots, one setting: burnt.", "hand:0.05"}, {"KNIFE BLOCK", 90, "Six knives and a sharpener.", "hand:0.1"},
  {"COFFEE MAKER", 120, "Twelve cups of drip before the morning skate.", "fstam:0.1"}, {"BLENDER", 150, "Protein shakes on demand.", "skate:0.1"},
  {"AIR FRYER", 180, "Crispy without the guilt.", "check:0.1"}, {"MICROWAVE", 200, "For the meal-prep containers.", "pass:0.05"},
  {"STAND MIXER", 450, "Candy-apple red. Bakes the team cookies.", "spow:0.15"}, {"ESPRESSO MACHINE", 900, "Twin boilers, steam wand, the works.", "fstam:0.25,edge:0.1"}};
const std::vector<HomeOpt> APTS = {{"THE STARTER", 0, "34 x 26 ft. Living room, kitchen, bedroom, office. Cosy.", ""},
  {"THE CORNER UNIT", 15000, "40 x 30 ft. A deeper living room with space for a recliner, and a bigger kitchen with room for an island.", "fstam:0.25"},
  {"THE PENTHOUSE", 60000, "58 x 32 ft. A chef's kitchen with a big island, a man cave with a bar, and room for all of it.", "fstam:0.5,edge:0.25"}};
Home HOME;
J homeToJ() {
  J o = J::obj(), s = J::arr(), w = J::arr(), c = J::arr(); for (int i = 0; i < HOME_NS; i++) { s.push(HOME.sel[i]); w.push(HOME.own[i]); }
  for (int i = 0; i < HOME_NCTR; i++) c.push(HOME.ctr[i]);
  J cl = J::arr(), cc = J::arr(); for (int i = 0; i < HOME_NS; i++) cl.push(HOME.col[i]); for (int i = 0; i < 16; i++) cc.push(HOME.ctrCol[i]); o["col"] = cl; o["ctrCol"] = cc;
  o["v"] = 2; o["sel"] = s; o["own"] = w; o["junk"] = HOME.junk; o["lvl"] = HOME.lvl; o["lvlOwn"] = HOME.lvlOwn; o["ctrOwn"] = HOME.ctrOwn; o["ctr"] = c; return o;
}
void aptUnload();
void homeFromJ(const J &o) {
  HOME = Home(); aptUnload(); if (!o.isObj()) return;
  auto at = [&](const char *k, int c, int d) { const J &a = o(k); return a.isArr() && (size_t)c < a.a.size() ? a.a[(size_t)c].i(d) : d; };
  if (o("v").i() < 2) {   // the first apartment file: floor, couch, TV, stand (one floor for the whole place)
    int map[4] = {-1, HS_COUCH, HS_TV, HS_ENT};
    for (int c = 1; c < 4; c++) { HOME.sel[map[c]] = at("sel", c, 0); HOME.own[map[c]] = at("own", c, 1) | 1; }
    for (int r : {0, 2, 3}) { HOME.sel[HS_FLOOR + r] = at("sel", 0, 0); HOME.own[HS_FLOOR + r] = at("own", 0, 1) | 1; }
  } else for (int i = 0; i < HOME_NS; i++) { HOME.sel[i] = at("sel", i, 0); HOME.own[i] = at("own", i, 1) | 1; }
  for (int i = 0; i < HOME_NS; i++) { HOME.sel[i] = std::max(0, std::min((int)HSLOT[i].o.size() - 1, HOME.sel[i])); if (!(HOME.own[i] >> HOME.sel[i] & 1)) HOME.sel[i] = 0; }
  HOME.junk = o("junk").i(); HOME.lvlOwn = o("lvlOwn").i(1) | 1; HOME.lvl = std::max(0, std::min((int)APTS.size() - 1, o("lvl").i())); if (!(HOME.lvlOwn >> HOME.lvl & 1)) HOME.lvl = 0;
  for (int i = 0; i < HOME_NS; i++) { HOME.col[i] = at("col", i, -1); if (HOME.col[i] >= (int)homeSwatches(i, HOME.sel[i]).size()) HOME.col[i] = -1; }
  for (int i = 0; i < 16; i++) { HOME.ctrCol[i] = at("ctrCol", i, -1); if (HOME.ctrCol[i] >= (int)SW_METAL.size()) HOME.ctrCol[i] = -1; }
  HOME.ctrOwn = o("ctrOwn").i(); for (int i = 0; i < HOME_NCTR; i++) { int v = at("ctr", i, -1); HOME.ctr[i] = v >= 0 && v < (int)COUNTER.size() && (HOME.ctrOwn >> v & 1) ? v : -1; }
}
bool homeTestMade() { std::string s; if (!plat_read_file(plat_data_dir() + "chl_home.json", s) || s.empty()) return false; J o = J::parse(s); return o.isObj() && o("testMade").truthy(); }
void homeSetTestMade() { J o = J::obj(); o["testMade"] = true; plat_write_file(plat_data_dir() + "chl_home.json", o.dump()); }
static void bonusChanged();
int homeBuy(int s, int i) {
  if (s < 0 || s >= HOME_NS || i < 0 || i >= (int)HSLOT[s].o.size()) return 0;
  if (HSLOT[s].lvl > HOME.lvl) return -1;
  if (s >= HS_PAINT && s < HS_PAINT + HOME_NR && i > 0 && HOME.sel[HS_WALL + s - HS_PAINT] == 0) return -1;   // fix the walls first
  if (HOME.own[s] >> i & 1) { HOME.sel[s] = i; if (CR) proSave(); aptDirty(); bonusChanged(); return 2; }
  if (!CR || C.money < HSLOT[s].o[(size_t)i].c) return 0;
  C.money -= HSLOT[s].o[(size_t)i].c; HOME.own[s] |= 1 << i; HOME.sel[s] = i; proSave(); aptDirty(); bonusChanged(); return 1;
}
bool homeCtrOut(int i) { for (int k = 0; k < HOME_NCTR; k++) if (HOME.ctr[k] == i) return true; return false; }
int homeCounter(int i) {
  if (i < 0 || i >= (int)COUNTER.size()) return 0;
  for (int k = 0; k < HOME_NCTR; k++) if (HOME.ctr[k] == i) { HOME.ctr[k] = -1; if (CR) proSave(); aptDirty(); bonusChanged(); return 3; }   // put it away
  int free = -1; for (int k = 0; k < HOME_NCTR; k++) if (HOME.ctr[k] < 0) { free = k; break; }
  bool own = HOME.ctrOwn >> i & 1;
  if (free < 0) return own ? 4 : 4;
  if (!own) { if (!CR || C.money < COUNTER[(size_t)i].c) return 0; C.money -= COUNTER[(size_t)i].c; HOME.ctrOwn |= 1 << i; }
  HOME.ctr[free] = i; if (CR) proSave(); aptDirty(); bonusChanged(); return own ? 2 : 1;
}
int homeMove(int l) {
  if (l < 0 || l >= (int)APTS.size()) return 0;
  if (HOME.lvlOwn >> l & 1) { HOME.lvl = l; if (CR) proSave(); aptDirty(); bonusChanged(); return 2; }
  if (!CR || C.money < APTS[(size_t)l].c) return 0;
  C.money -= APTS[(size_t)l].c; HOME.lvlOwn |= 1 << l; HOME.lvl = l; proSave(); aptDirty(); bonusChanged(); return 1;
}
// the rating nudges: everything in use adds its fx, each rating capped at +3
static std::vector<std::pair<std::string, double>> fxParse(const char *fx) {
  std::vector<std::pair<std::string, double>> o; std::string s = fx ? fx : ""; size_t i = 0;
  while (i < s.size()) { size_t c = s.find(':', i), e = s.find(',', i); if (c == std::string::npos) break; if (e == std::string::npos) e = s.size(); o.push_back({s.substr(i, c - i), atof(s.substr(c + 1, e - c - 1).c_str())}); i = e + 1; }
  return o;
}
static struct { bool ok = false; std::vector<std::pair<std::string, double>> m; } HB;
static void bonusChanged() { HB.ok = false; gearChanged(); }
double homePts(const std::string &k) {
  if (!HB.ok) { HB.ok = true; HB.m.clear(); auto add = [&](const char *fx) { for (auto &p : fxParse(fx)) { bool f = false; for (auto &q : HB.m) if (q.first == p.first) { q.second += p.second; f = true; } if (!f) HB.m.push_back(p); } };
    for (int s = 0; s < HOME_NS; s++) if (HSLOT[s].lvl <= HOME.lvl) add(HSLOT[s].o[(size_t)HOME.sel[s]].fx);
    for (int k2 = 0; k2 < HOME_NCTR; k2++) if (HOME.ctr[k2] >= 0) add(COUNTER[(size_t)HOME.ctr[k2]].fx);
    add(APTS[(size_t)HOME.lvl].fx); }
  for (auto &q : HB.m) if (q.first == k) return std::min(3.0, q.second);
  return 0;
}
std::string homeFxTxt(const char *fx) {
  std::string o; for (auto &p : fxParse(fx)) { if (!o.empty()) o += "  "; char b[16]; snprintf(b, sizeof b, "+%g ", p.second); o += b + FNICE(p.first); }
  return o;
}

// ---------------------------------------------------------------- geometry
struct P3 { float x, y, z; };
static inline P3 operator+(P3 a, P3 b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
static inline P3 operator-(P3 a, P3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static inline P3 operator*(P3 a, float k) { return {a.x * k, a.y * k, a.z * k}; }
static inline float dot3(P3 a, P3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static inline P3 cross3(P3 a, P3 b) { return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
static inline P3 nrm3(P3 a) { float l = std::sqrt(dot3(a, a)); return l > 1e-6f ? a * (1 / l) : P3{0, 0, 1}; }
static std::vector<V3c> AG;                       // the world, ready for the GPU
static uint32_t aptVer = 1; static bool aptOk = false, aptLoaded = false;   // ok: geometry current; loaded: in memory (between the loading screen and the next game)
struct Rc { float x0, y0, x1, y1; bool wall = false; }; static std::vector<Rc> COL;     // what you bump into
struct Hot { int id; P3 p; float r; }; static std::vector<Hot> HOT;  // what you can look at and use
struct Lamp { P3 p; float k; }; static std::vector<Lamp> LAMPS;
static const float CEIL = 9, WT = .25f;
static float AX = 34, AY = 26, LY = 14, KY = 12;   // the size, where the bedroom wall and the kitchen's back wall stand (set by the apartment)
static float KX = 34, BY = 19;   // KX: the kitchen / office's east wall (the penthouse's man cave is beyond it); BY: the bathroom's wall at the end of the hall
void aptDirty() { aptOk = false; }
static uint32_t sd = 1; static float frand() { sd = sd * 1664525u + 1013904223u; return (sd >> 8) / 16777216.f; }
// light at a point on a surface: a dim warm ambient, daylight from the south windows, the ceiling bulbs
static Col litAt(Col c, P3 p, P3 n) {
  float l = .44f + .12f * std::max(0.f, n.z) + .14f * std::max(0.f, -n.y) * std::max(0.f, 1 - p.y / 16) + .05f * std::fabs(n.x);
  for (auto &L : LAMPS) { P3 d = L.p - p; float d2 = dot3(d, d), dl = std::sqrt(d2) + 1e-4f; float nd = std::max(0.f, dot3(n, d * (1 / dl))); l += L.k * (.25f + .75f * nd) / (1 + d2 * .016f); }
  l = std::min(l, 1.3f);
  return Col(std::min(255.f, c.r * l * 1.02f), std::min(255.f, c.g * l * .97f), std::min(255.f, c.b * l * .88f), 1);
}
static std::vector<V3c> DY, *OUT = &AG;   // DY: what moves (the hallway doors), rebuilt each frame
// texture coordinates for the grain (texture slot 7: a fine, near-white noise that every surface is multiplied by, so
// paint, wood and fabric read as real materials): planar, along the face's own plane, about 2.5 ft a repeat
static P3 g_curN = {0, 0, 1};
static void vtx(P3 p, uint32_t c) { V3c v; v.x = p.x; v.y = p.y; v.z = p.z; v.c = c; float ax = std::fabs(g_curN.x), ay = std::fabs(g_curN.y), az = std::fabs(g_curN.z);
  if (az >= ax && az >= ay) { v.u = p.x * .4f; v.v = p.y * .4f; } else if (ax >= ay) { v.u = p.y * .4f; v.v = p.z * .4f; } else { v.u = p.x * .4f; v.v = p.z * .4f; }
  OUT->push_back(v); }
static float FLATK = -1;   // >= 0: a flat face (walls, ceiling): one colour all over, times this (no light falloff, no blotches)
// a flat quad a-b-c-d with normal n, split into tiles so the light falls off smoothly across it; glow: unlit
static void quad(P3 a, P3 b, P3 c, P3 d, Col col, P3 n, float tile = 3, bool glow = false) {
  float lu = std::sqrt(dot3(b - a, b - a)), lv = std::sqrt(dot3(d - a, d - a)); int nu = std::max(1, std::min(10, (int)std::ceil(lu / tile))), nv = std::max(1, std::min(10, (int)std::ceil(lv / tile)));
  if (glow || FLATK >= 0) nu = nv = 1; g_curN = n;
  Col flat = FLATK >= 0 ? Col(std::min(255.f, col.r * FLATK), std::min(255.f, col.g * FLATK), std::min(255.f, col.b * FLATK), 1) : col;
  auto at = [&](float u, float v) { P3 p = a + (b - a) * u + (d - a) * v + (c - b - (d - a)) * (u * v); return p; };
  for (int i = 0; i < nu; i++) for (int j = 0; j < nv; j++) {
    P3 q[4] = {at((float)i / nu, (float)j / nv), at((float)(i + 1) / nu, (float)j / nv), at((float)(i + 1) / nu, (float)(j + 1) / nv), at((float)i / nu, (float)(j + 1) / nv)};
    uint32_t k[4]; for (int m = 0; m < 4; m++) k[m] = glow ? col.pack() : FLATK >= 0 ? flat.pack() : litAt(col, q[m], n).pack();
    vtx(q[0], k[0]); vtx(q[1], k[1]); vtx(q[2], k[2]); vtx(q[0], k[0]); vtx(q[2], k[2]); vtx(q[3], k[3]); }
}
// a box; skip bit 1 drops the bottom (anything on the floor)
static void box(float x0, float y0, float z0, float x1, float y1, float z1, Col c, float tile = 3, int skip = 1, bool glow = false) {
  if (x1 < x0) std::swap(x0, x1); if (y1 < y0) std::swap(y0, y1);
  quad({x0, y0, z1}, {x1, y0, z1}, {x1, y1, z1}, {x0, y1, z1}, c, {0, 0, 1}, tile, glow);
  if (!(skip & 1)) quad({x0, y0, z0}, {x0, y1, z0}, {x1, y1, z0}, {x1, y0, z0}, c, {0, 0, -1}, tile, glow);
  quad({x0, y0, z0}, {x1, y0, z0}, {x1, y0, z1}, {x0, y0, z1}, c, {0, -1, 0}, tile, glow);
  quad({x1, y1, z0}, {x0, y1, z0}, {x0, y1, z1}, {x1, y1, z1}, c, {0, 1, 0}, tile, glow);
  quad({x0, y1, z0}, {x0, y0, z0}, {x0, y0, z1}, {x0, y1, z1}, c, {-1, 0, 0}, tile, glow);
  quad({x1, y0, z0}, {x1, y1, z0}, {x1, y1, z1}, {x1, y0, z1}, c, {1, 0, 0}, tile, glow);
}
static void solid(float x0, float y0, float x1, float y1, bool wall = false) { COL.push_back({std::min(x0, x1), std::min(y0, y1), std::max(x0, x1), std::max(y0, y1), wall}); }
// a round thing: n sides from radius r0 at z0 to r1 at z1 (and a lid)
static void cyl(float cx, float cy, float z0, float z1, float r0, float r1, Col c, int n = 8, bool lid = true, bool glow = false) {
  for (int i = 0; i < n; i++) { float a0 = i * 6.2832f / n, a1 = (i + 1) * 6.2832f / n, am = (a0 + a1) / 2;
    P3 nn = nrm3({std::cos(am), std::sin(am), (r0 - r1) / std::max(.01f, z1 - z0)});
    quad({cx + std::cos(a0) * r0, cy + std::sin(a0) * r0, z0}, {cx + std::cos(a1) * r0, cy + std::sin(a1) * r0, z0}, {cx + std::cos(a1) * r1, cy + std::sin(a1) * r1, z1}, {cx + std::cos(a0) * r1, cy + std::sin(a0) * r1, z1}, c, nn, 9, glow);
    if (lid) { uint32_t k = glow ? c.pack() : litAt(c, {cx, cy, z1}, {0, 0, 1}).pack(); vtx({cx, cy, z1}, k); vtx({cx + std::cos(a0) * r1, cy + std::sin(a0) * r1, z1}, k); vtx({cx + std::cos(a1) * r1, cy + std::sin(a1) * r1, z1}, k); } }
}
// a thin patch on a wall or floor (stains, holes, rugs): centre p, half sizes along u and v, facing n
static void patch(P3 p, P3 u, P3 v, Col c, P3 n, bool glow = false) { P3 o = p + n * .03f; quad(o - u - v, o + u - v, o + u + v, o - u + v, c, n, 9, glow); }
static Col HX(const char *h) { return hex(h); }
static Col vary(Col c, float k) { float f = 1 + (frand() - .5f) * k; return Col(std::min(255.f, c.r * f), std::min(255.f, c.g * f), std::min(255.f, c.b * f), 1); }

// walls: a line of boxes along x (or y), with openings (doors from the floor, windows from z0)
struct Gap { float a, b, z0, z1; };
static void wbox(float x0, float y0, float z0, float x1, float y1, float z1, bool bottom);
static void wall(bool alongX, float fix, float from, float to, std::vector<Gap> gaps, Col) {
  std::sort(gaps.begin(), gaps.end(), [](const Gap &a, const Gap &b) { return a.a < b.a; });
  auto piece = [&](float a, float b, float z0, float z1, bool coll) { if (b - a < .01f || z1 - z0 < .01f) return;
    if (alongX) { wbox(a, fix - WT, z0, b, fix + WT, z1, z0 > 0); if (coll) solid(a, fix - WT, b, fix + WT, true); }
    else { wbox(fix - WT, a, z0, fix + WT, b, z1, z0 > 0); if (coll) solid(fix - WT, a, fix + WT, b, true); } };
  float cur = from;
  for (auto &g : gaps) { piece(cur, g.a, 0, CEIL, true); piece(g.a, g.b, 0, g.z0, g.z0 > 0); piece(g.a, g.b, g.z1, CEIL, false); cur = g.b; }
  piece(cur, to, 0, CEIL, true);
}
// a window in an outer wall: frame, sill, the view (the city, a bit grimy through dirty glass)
static void window(bool alongX, float fix, float a, float b, float z0, float z1, float out) {
  Col fr = HX("#cfc6ad"), sky0 = HX("#9fb0bc"), sky1 = HX("#c9cfc8");
  float t = .12f;
  if (alongX) {
    box(a - .15f, fix - WT - .25f, z0 - .15f, b + .15f, fix + WT + .25f, z0 + .05f, fr, 3, 0);   // sill: sits proud of the wall
    box(a + .01f, fix - .08f, z0 + .05f, a + t, fix + .08f, z1 - .01f, fr); box(b - t, fix - .08f, z0 + .05f, b - .01f, fix + .08f, z1 - .01f, fr); box(a + .01f, fix - .08f, z1 - t, b - .01f, fix + .08f, z1 - .01f, fr, 3, 0);
    box((a + b) / 2 - t / 2, fix - .06f, z0 + .05f, (a + b) / 2 + t / 2, fix + .06f, z1 - t, fr); box(a + t, fix - .06f, (z0 + z1) / 2 - t / 2, b - t, fix + .06f, (z0 + z1) / 2 + t / 2, fr, 3, 0);
    float yo = fix + out * 1.2f, ny = -out;
    quad({a - 4, fix + out * 2.6f, -2}, {b + 4, fix + out * 2.6f, -2}, {b + 4, fix + out * 2.6f, CEIL + 2}, {a - 4, fix + out * 2.6f, CEIL + 2}, sky1, {0, ny, 0}, 9, true);   // (a wider backdrop: no gap past the edges)
    quad({a - 1, yo, z0 - 1}, {b + 1, yo, z0 - 1}, {b + 1, yo, z1 + 1}, {a - 1, yo, z1 + 1}, sky1, {0, ny, 0}, 9, true);
    quad({a - 1, yo + out * .01f, z0 - 1}, {b + 1, yo + out * .01f, z0 - 1}, {b + 1, yo + out * .01f, (z0 + z1) / 2}, {a - 1, yo + out * .01f, (z0 + z1) / 2}, sky0, {0, ny, 0}, 9, true);
    for (float x = a - .8f; x < b + .8f; x += .5f + frand() * .7f) { float hb = z0 - .4f + frand() * 2.2f, w = .3f + frand() * .5f;   // the skyline
      quad({x, yo - out * .02f, z0 - 1}, {x + w, yo - out * .02f, z0 - 1}, {x + w, yo - out * .02f, hb}, {x, yo - out * .02f, hb}, vary(HX("#6f7a80"), .2f), {0, ny, 0}, 9, true); }
  } else {
    box(fix - WT - .25f, a - .15f, z0 - .15f, fix + WT + .25f, b + .15f, z0 + .05f, fr, 3, 0);
    box(fix - .08f, a + .01f, z0 + .05f, fix + .08f, a + t, z1 - .01f, fr); box(fix - .08f, b - t, z0 + .05f, fix + .08f, b - .01f, z1 - .01f, fr); box(fix - .08f, a + .01f, z1 - t, fix + .08f, b - .01f, z1 - .01f, fr, 3, 0);
    box(fix - .06f, (a + b) / 2 - t / 2, z0 + .05f, fix + .06f, (a + b) / 2 + t / 2, z1 - t, fr); box(fix - .06f, a + t, (z0 + z1) / 2 - t / 2, fix + .06f, b - t, (z0 + z1) / 2 + t / 2, fr, 3, 0);
    float xo = fix + out * 1.2f, nx = -out;
    quad({fix + out * 2.6f, a - 4, -2}, {fix + out * 2.6f, b + 4, -2}, {fix + out * 2.6f, b + 4, CEIL + 2}, {fix + out * 2.6f, a - 4, CEIL + 2}, sky1, {nx, 0, 0}, 9, true);
    quad({xo, a - 1, z0 - 1}, {xo, b + 1, z0 - 1}, {xo, b + 1, z1 + 1}, {xo, a - 1, z1 + 1}, sky1, {nx, 0, 0}, 9, true);
    quad({xo + out * .01f, a - 1, z0 - 1}, {xo + out * .01f, b + 1, z0 - 1}, {xo + out * .01f, b + 1, (z0 + z1) / 2}, {xo + out * .01f, a - 1, (z0 + z1) / 2}, sky0, {nx, 0, 0}, 9, true);
    for (float y = a - .8f; y < b + .8f; y += .5f + frand() * .7f) { float hb = z0 - .4f + frand() * 2.2f, w = .3f + frand() * .5f;
      quad({xo - out * .02f, y, z0 - 1}, {xo - out * .02f, y + w, z0 - 1}, {xo - out * .02f, y + w, hb}, {xo - out * .02f, y, hb}, vary(HX("#6f7a80"), .2f), {nx, 0, 0}, 9, true); }
  }
  // (the old grime streaks are gone: they read as stray bars across the glass)
}

// ---------------------------------------------------------------- floors
// an irregular flat shape (a stain, a puddle) or, with h, a soft low mound (a pile of clothes)
static void blob(float cx, float cy, float z, float r, float h, Col c, P3 n = {0, 0, 1}, int k = 10) {
  float rr[16]; for (int i = 0; i < k; i++) rr[i] = r * (.65f + .5f * frand());
  P3 ctr = {cx, cy, z + h * (n.z < 0 ? -1 : 1)}; uint32_t cc = litAt(c, ctr, n).pack();
  for (int i = 0; i < k; i++) { float a0 = i * 6.2832f / k, a1 = (i + 1) * 6.2832f / k; P3 p0 = {cx + std::cos(a0) * rr[i], cy + std::sin(a0) * rr[i], z}, p1 = {cx + std::cos(a1) * rr[(i + 1) % k], cy + std::sin(a1) * rr[(i + 1) % k], z};
    vtx(ctr, cc); vtx(p0, litAt(shade(c, -.12), p0, n).pack()); vtx(p1, litAt(shade(c, -.12), p1, n).pack()); }
}
static void floorRect(float x0, float y0, float x1, float y1, int type, bool kitchen = false, int slot = -1) {   // slot: whose colour
  P3 up = {0, 0, 1};
  if (type == 0 && kitchen) {   // the kitchen's cracked linoleum
    for (float i = x0; i < x1 - .01f; i++) for (float j = y0; j < y1 - .01f; j++) { int a = (int)i, b = (int)j; Col t = ((a + b) & 1) ? HX("#b9b29c") : HX("#8f8a7c"); if (frand() < .12f) t = HX("#7a7262");
      quad({i, j, .01f}, {std::min(x1, i + 1), j, .01f}, {std::min(x1, i + 1), std::min(y1, j + 1), .01f}, {i, std::min(y1, j + 1), .01f}, vary(t, .06f), up, 9); }
    return;
  }
  if (type == 0) {   // worn carpet: one colour, flattened paths and stains
    quad({x0, y0, 0}, {x1, y0, 0}, {x1, y1, 0}, {x0, y1, 0}, HX("#7b7060"), up, 2.5f);
    int ns = (int)((x1 - x0) * (y1 - y0) / 22); for (int i = 0; i < ns; i++) { float cx = x0 + (x1 - x0) * frand(), cy = y0 + (y1 - y0) * frand(), r = .4f + frand() * 1.1f;
      blob(cx, cy, .02f, r, 0, vary(HX("#655b4c"), .12f)); }
    return;
  }
  if (type == 3) {   // marble: 2 ft tiles, grout between, a vein across each
    quad({x0, y0, 0}, {x1, y0, 0}, {x1, y1, 0}, {x0, y1, 0}, HX("#9a968e"), up, 6);
    for (float x = x0; x < x1 - .05f; x += 2) for (float y = y0; y < y1 - .05f; y += 2) { float xe = std::min(x1, x + 2) - .04f, ye = std::min(y1, y + 2) - .04f; Col t = vary(slot >= 0 ? K(slot, "#e9e6df") : HX("#e9e6df"), .06f);
      quad({x + .04f, y + .04f, .02f}, {xe, y + .04f, .02f}, {xe, ye, .02f}, {x + .04f, ye, .02f}, t, up, 9);
      float vy = y + .3f + frand() * 1.3f, sl = (frand() - .5f) * .7f, vy1 = std::max(y + .1f, std::min(ye - .12f, vy + sl)); Col vc = shade(t, -.1);   // a thin vein, a steady width all the way
      quad({x + .1f, vy, .025f}, {xe - .1f, vy1, .025f}, {xe - .1f, vy1 + .04f, .025f}, {x + .1f, vy + .04f, .025f}, vc, up, 9); }
    return;
  }
  // planks along x: vinyl (wide, grey-tan) or oak (narrow, warm)
  float pw = type == 1 ? .62f : .38f; Col base = slot >= 0 ? K(slot, type == 1 ? "#b5a68d" : "#9b6b40") : type == 1 ? HX("#b5a68d") : HX("#9b6b40");
  quad({x0, y0, 0}, {x1, y0, 0}, {x1, y1, 0}, {x0, y1, 0}, shade(base, -.45), up, 6);
  for (float y = y0; y < y1 - .02f; y += pw) { float ye = std::min(y1, y + pw) - .025f, x = x0 - frand() * 3;
    while (x < x1) { float l = (type == 1 ? 3.5f : 2.5f) + frand() * 2, xa = std::max(x0, x), xb = std::min(x1, x + l) - .025f; if (xb > xa + .05f) quad({xa, y, .015f}, {xb, y, .015f}, {xb, ye, .015f}, {xa, ye, .015f}, vary(base, type == 1 ? .1f : .22f), up, 9); x += l; } }
}

// ---------------------------------------------------------------- the furniture you can upgrade
static void couchGeo(int v) {   // against nothing, facing west toward the TV; the seat front at x 10.4
  if (v == 0) { Col f = HX("#5b4a3a"), m = K(HS_COUCH, "#b49a4e");   // a futon: wood frame, a sagging mustard mattress
    box(10.4f, 3.6f, 0, 13.2f, 10.4f, .8f, f); box(10.5f, 3.7f, .8f, 13.1f, 10.3f, 1.35f, m, 2); box(12.6f, 3.6f, 1.2f, 13.3f, 10.4f, 3.0f, m, 2);
    box(11.4f, 6.2f, 1.33f, 12.2f, 7.8f, 1.37f, shade(m, -.22));   // the sag
    patch({11.2f, 8.6f, 1.36f}, {.4f, 0, 0}, {0, .3f, 0}, shade(m, -.38), {0, 0, 1}); solid(10.4f, 3.6f, 13.3f, 10.4f); }
  else if (v == 1) { Col c = K(HS_COUCH, "#6b4a2f");   // thrift sofa
    box(10.5f, 3.8f, 0, 13.2f, 10.2f, 1.5f, c, 2); box(12.4f, 3.8f, 1.5f, 13.2f, 10.2f, 3.0f, c, 2);
    box(10.5f, 3.4f, 0, 13.2f, 3.9f, 2.2f, c); box(10.5f, 10.1f, 0, 13.2f, 10.6f, 2.2f, c);
    for (int i = 0; i < 3; i++) box(10.6f, 4.0f + i * 2.05f, 1.5f, 12.4f, 5.95f + i * 2.05f, 1.85f, vary(shade(c, .12), .08f), 2);
    solid(10.5f, 3.4f, 13.2f, 10.6f); }
  else if (v == 2) { Col c = K(HS_COUCH, "#2e2522"), s = shade(c, .14);   // leather sectional with a chaise toward the TV
    box(10.6f, 3.0f, 0, 13.4f, 11.0f, 1.45f, c, 2); box(12.6f, 3.0f, 1.45f, 13.4f, 11.0f, 3.0f, c, 2);
    box(8.0f, 9.0f, 0, 10.6f, 11.0f, 1.45f, c, 2); box(8.0f, 10.4f, 1.45f, 10.6f, 11.0f, 3.0f, c, 2);
    box(10.6f, 2.5f, 0, 13.4f, 3.0f, 2.1f, c);
    for (int i = 0; i < 3; i++) box(10.7f, 3.1f + i * 2.0f, 1.45f, 12.6f, 4.95f + i * 2.0f, 1.85f, vary(s, .06f), 2);
    box(8.1f, 9.1f, 1.45f, 10.6f, 10.4f, 1.85f, s, 2); solid(10.6f, 2.5f, 13.4f, 11.0f); solid(8.0f, 9.0f, 10.6f, 11.0f); }
  else { Col c = K(HS_COUCH, "#c9c8c4");   // designer modular
    box(10.2f, 2.6f, 0, 13.6f, 11.4f, 1.2f, c, 2); box(12.8f, 2.6f, 1.2f, 13.6f, 11.4f, 2.6f, c, 2);
    box(10.2f, 2.2f, 0, 13.6f, 2.6f, 1.9f, c); box(10.2f, 11.4f, 0, 13.6f, 11.8f, 1.9f, c);
    const char *pc[5] = {"#e0703a", "#2b6f8f", "#e9c14b", "#2b6f8f", "#e0703a"};
    for (int i = 0; i < 5; i++) { float y = 3.2f + i * 1.65f; box(12.3f, y, 1.2f, 12.8f, y + 1.1f, 2.4f, HX(pc[i]), 2); }
    box(10.3f, 2.7f, 1.2f, 12.8f, 11.3f, 1.55f, shade(c, .06), 2); solid(10.2f, 2.2f, 13.6f, 11.8f); }
}
static float entTop = 2.2f;   // where the TV stands
static void entGeo(int v) {   // against the west wall, centred at y 7
  if (v == 0) { Col r = HX("#b0302c"), b = HX("#2f5a9a");   // two milk crates and a plank
    auto crate = [&](float y0, Col c) { box(.4f, y0, 0, 1.5f, y0 + 1.1f, 1.1f, c, 1); box(.5f, y0 + .1f, .1f, 1.4f, y0 + 1.0f, 1.12f, HX("#1a1a1a")); };
    crate(5.2f, r); crate(7.7f, b); box(.35f, 5.0f, 1.12f, 1.6f, 9.0f, 1.25f, K(HS_ENT, "#8a7352"), 2); entTop = 1.25f; solid(.25f, 5.0f, 1.6f, 9.0f); }
  else if (v == 1) { Col k = K(HS_ENT, "#1c1c1f"); box(.3f, 4.5f, 0, 1.8f, 9.5f, 1.8f, k, 2); box(.35f, 4.7f, .3f, 1.82f, 9.3f, .35f, HX("#2c2c30")); box(.35f, 4.7f, 1.0f, 1.82f, 9.3f, 1.05f, HX("#2c2c30"));
    box(1.0f, 5.0f, .36f, 1.6f, 6.2f, .6f, HX("#111")); entTop = 1.8f; solid(.25f, 4.5f, 1.8f, 9.5f); }
  else if (v == 2) { Col o = K(HS_ENT, "#9a6a3c"); box(.3f, 3.8f, 0, 1.9f, 10.2f, 2.0f, o, 2);
    for (int i = 0; i < 3; i++) { float y = 4.1f + i * 2.05f; box(1.88f, y, .3f, 1.93f, y + 1.8f, 1.7f, vary(shade(o, -.1), .05f)); box(1.92f, y + .8f, .95f, 2.0f, y + 1.0f, 1.05f, HX("#d8c08a")); }
    entTop = 2.0f; solid(.25f, 3.8f, 1.9f, 10.2f); }
  else { Col w = K(HS_ENT, "#5a3a24"); box(.3f, 2.8f, 1.2f, 1.7f, 11.2f, 2.3f, w, 2, 0); box(.32f, 2.9f, 1.15f, 1.68f, 11.1f, 1.2f, HX("#7fd6ff"), 9, 0, true);   // the light strip underneath
    for (int i = 0; i < 4; i++) box(1.68f, 3.2f + i * 2.0f, 1.3f, 1.72f, 4.9f + i * 2.0f, 2.2f, vary(shade(w, .1), .05f));
    entTop = 2.3f; solid(.25f, 2.8f, 1.7f, 11.2f); }
}
// the screen shows a rink, of course
static void screenPic(float x, float y0, float y1, float z0, float z1, bool crt) {
  Col bg = crt ? HX("#7f9a8a") : HX("#e8eef4"); quad({x, y1, z0}, {x, y0, z0}, {x, y0, z1}, {x, y1, z1}, bg, {1, 0, 0}, 9, true);
  float w = y1 - y0, h = z1 - z0, xi = x + .01f;
  auto bar = [&](float u0, float u1, float v0, float v1, Col c) { quad({xi, y1 - w * u0, z0 + h * v0}, {xi, y1 - w * u1, z0 + h * v0}, {xi, y1 - w * u1, z0 + h * v1}, {xi, y1 - w * u0, z0 + h * v1}, c, {1, 0, 0}, 9, true); };
  bar(.495f, .505f, .08f, .92f, crt ? HX("#7a3a3a") : HX("#d23b3b")); bar(.33f, .345f, .08f, .92f, crt ? HX("#3a4a7a") : HX("#2f64d6")); bar(.655f, .67f, .08f, .92f, crt ? HX("#3a4a7a") : HX("#2f64d6"));
  bar(.08f, .09f, .25f, .75f, HX("#c23")); bar(.91f, .92f, .25f, .75f, HX("#c23"));
  bar(.4f, .43f, .45f, .55f, HX("#111")); bar(.6f, .62f, .6f, .7f, HX("#222")); bar(.03f, .3f, .86f, .96f, crt ? HX("#2a3a2a") : HX("#0b1220"));   // a skater, the puck, the score bug
}
static void tvGeo(int v) {
  float z = entTop, cy = 7; P3 hot;
  if (v == 0) { box(.45f, 5.9f, z, 1.6f, 8.1f, z + 1.5f, K(HS_TV, "#4a4a46")); screenPic(1.61f, 6.15f, 7.85f, z + .2f, z + 1.3f, true); hot = {1.6f, cy, z + .75f}; }
  else { float w = v == 1 ? 3.0f : v == 2 ? 4.7f : 6.2f, h = w * .5625f, z0 = v == 3 ? 3.6f : z + .5f, x = v == 3 ? .3f : .7f, d = v == 3 ? .12f : .18f;
    box(x, cy - w / 2 - .06f, z0 - .06f, x + d, cy + w / 2 + .06f, z0 + h + .06f, K(HS_TV, "#111214"), 9, 0);
    if (v < 3) { box(x - .1f, cy - .5f, z, x + .5f, cy + .5f, z + .07f, HX("#222")); box(x + .02f, cy - .1f, z, x + .1f, cy + .1f, z0, HX("#222")); }
    screenPic(x + d + .005f, cy - w / 2, cy + w / 2, z0, z0 + h, false); hot = {x + d, cy, z0 + h / 2}; }
  HOT.push_back({APT_SLOT + HS_TV, hot, 7.5f});
}

// ---------------------------------------------------------------- the trophy shelf (every title, every career)
static void cupMini(float x, float y, float z, bool calder) {
  if (!calder) { Col s = HX("#d9dee4"), d = HX("#9aa3ad");   // the Stanley Cup: tiered barrel, collar, bowl
    cyl(x, y, z, z + .12f, .2f, .2f, HX("#2a2a2a")); cyl(x, y, z + .12f, z + .4f, .18f, .16f, s); cyl(x, y, z + .4f, z + .5f, .16f, .13f, d); cyl(x, y, z + .5f, z + .66f, .1f, .06f, s);
    cyl(x, y, z + .66f, z + .78f, .07f, .14f, s); cyl(x, y, z + .78f, z + .8f, .14f, .14f, d); }
  else { Col g = HX("#d8b04a");   // the Calder Cup: a gold urn with handles
    cyl(x, y, z, z + .08f, .14f, .14f, HX("#3a2a1a")); cyl(x, y, z + .08f, z + .25f, .05f, .05f, g); cyl(x, y, z + .25f, z + .55f, .07f, .16f, g);
    box(x - .2f, y - .02f, z + .38f, x - .16f, y + .02f, z + .5f, g); box(x + .16f, y - .02f, z + .38f, x + .2f, y + .02f, z + .5f, g); }
}
static void shelfGeo() {   // on the living-room face of the bedroom wall
  float y1 = LY - WT, y0 = y1 - .85f, x0 = 3.0f, x1 = 9.4f; Col wd = HX("#6a5236");
  float zs[3] = {3.4f, 4.7f, 6.0f};
  for (float z : zs) { box(x0, y0, z - .1f, x1, y1, z, wd, 3, 0); box(x0 + .3f, y1 - .1f, z - .5f, x0 + .45f, y1, z - .1f, HX("#333")); box(x1 - .45f, y1 - .1f, z - .5f, x1 - .3f, y1, z - .1f, HX("#333")); }
  int cups = CR ? C.titles : 0, cal = CR ? C.calder : 0, nc = std::min(cups, 20), nk = std::min(cal, 30 - nc), i = 0;
  for (int k = 0; k < nc + nk; k++, i++) { int row = i / 10, col = i % 10; if (row > 2) break; cupMini(x0 + .35f + col * .62f, (y0 + y1) / 2, zs[2 - row], k >= nc); }
  if (!nc && !nk) { patch({(x0 + x1) / 2, y0 + .02f, zs[1] + .45f}, {.45f, 0, 0}, {0, 0, .3f}, HX("#f2e27a"), {0, -1, 0}); }   // a sticky note: "win something"
  HOT.push_back({APT_SHELF, {(x0 + x1) / 2, y0, 4.8f}, 10});
}

// ---------------------------------------------------------------- the newer pieces: recliner, island, counter items, the jersey
static void reclGeo(int v) {   // beside the couch, angled toward the TV
  if (v == 0 || HOME.lvl < 1) return;
  Col c = K(HS_RECL, v == 1 ? "#7a5c3e" : v == 2 ? "#3a2a22" : "#2b2f36"); float x0 = 10.8f, y0 = 13.2f, x1 = 13.6f, y1 = 15.9f;
  box(x0, y0, 0, x1, y1, 1.5f, c, 2); box(x1 - .7f, y0, 1.5f, x1, y1, 3.6f, c, 2); box(x0, y0 - .35f, 0, x1 - .2f, y0, 2.3f, c); box(x0, y1, 0, x1 - .2f, y1 + .35f, 2.3f, c);
  box(x0 + .1f, y0 + .1f, 1.5f, x1 - .7f, y1 - .1f, 1.75f, shade(c, .12), 2);
  if (v == 3) { box(x0 - 1.3f, y0 + .3f, .3f, x0, y1 - .3f, 1.1f, c, 2); for (int i = 0; i < 3; i++) box(x1 - .72f, y0 + .5f + i * .7f, 2.0f + i * .4f, x1 - .68f, y0 + 1.0f + i * .7f, 2.3f + i * .4f, HX("#5ad1ff"), 9, 0, true); }   // footrest, a glowing panel
  solid(x0 - (v == 3 ? 1.3f : 0), y0 - .35f, x1, y1 + .35f); HOT.push_back({APT_SLOT + HS_RECL, {12.2f, 14.5f, 1.8f}, 7.5f});
}
static void isleGeo(int v) {   // the middle of the bigger kitchen
  if (HOME.lvl < 1) return;
  bool big = HOME.lvl >= 2; float x0 = big ? 29.0f : 29.5f, x1 = big ? 38.5f : 34.5f, y0 = 5.2f, y1 = big ? 8.8f : 7.8f, mx = (x0 + x1) / 2, my = (y0 + y1) / 2;   // the penthouse's: a chef's island
  if (v == 0) { HOT.push_back({APT_SLOT + HS_ISLE, {mx, my, .5f}, 7.5f}); return; }
  if (v == 1) { Col w = K(HS_ISLE, "#a8743f"); box(x0 + 1, y0 + .4f, 2.9f, x1 - 1, y1 - .4f, 3.2f, w, 3, 0); box(x0 + 1.1f, y0 + .5f, .5f, x1 - 1.1f, y1 - .5f, .6f, w, 3, 0);
    for (float x : {x0 + 1.1f, x1 - 1.2f}) for (float y : {y0 + .5f, y1 - .6f}) box(x, y, 0, x + .1f, y + .1f, 2.9f, HX("#444"), 9); solid(x0 + 1, y0 + .4f, x1 - 1, y1 - .4f); }
  else { Col top = v == 2 ? HX("#eceae6") : HX("#f3f1ee"), base = K(HS_ISLE, v == 2 ? "#3c4a5c" : "#e7e4de");
    box(x0 + .1f, y0 + .1f, 0, x1 - .1f, y1 - .1f, 2.95f, base); box(x0 - .1f, y0 - .1f, 2.95f, x1 + .1f, y1 + .4f, 3.15f, top, 3, 0);
    if (v == 3) { box(x0 - .1f, y0 - .1f, 0, x0 + .1f, y1 + .4f, 2.95f, top); box(x1 - .1f, y0 - .1f, 0, x1 + .1f, y1 + .4f, 2.95f, top); }
    int ns = big ? 5 : 3; for (int i = 0; i < ns; i++) { float x = x0 + .8f + i * 1.6f * (big ? 1.2f : 1); cyl(x, y1 + 1.0f, 0, 2.2f, .07f, .07f, HX("#333"), 6, false); cyl(x, y1 + 1.0f, 2.2f, 2.35f, .45f, .45f, v == 2 ? HX("#8a6a4a") : HX("#2b2b2b")); }
    if (big) { box(mx - 1.2f, y0 + .5f, 3.15f, mx + .2f, y0 + 1.6f, 3.17f, HX("#5d6166"), 9, 0); cyl(mx - .5f, y0 + .35f, 3.15f, 4.1f, .06f, .05f, HX("#c9a54a"));   // a prep sink
      for (int i = 0; i < 3; i++) { float x = x0 + 1.5f + i * (x1 - x0 - 3) / 2; box(x - .02f, my - .02f, 6.6f, x + .02f, my + .02f, CEIL, HX("#333")); cyl(x, my, 5.9f, 6.6f, .45f, .2f, v == 3 ? HX("#c9a54a") : HX("#2b2b2b"), 8); cyl(x, my, 5.85f, 5.9f, .3f, .3f, HX("#fff2c2"), 8, true, true); } }   // pendant lights
    solid(x0 - .1f, y0 - .1f, x1 + .1f, y1 + 1.5f); }
  HOT.push_back({APT_SLOT + HS_ISLE, {mx, my, 3.2f}, 7.5f});
}
static void ctrItem(int id, float cx, float cy, float z) {   // small appliances on the east counter (facing west)
  int co = id >= 0 && id < 16 ? HOME.ctrCol[id] : -1; const char *body = nullptr; auto HX = [&](const char *h) { if (!body) body = h; return co >= 0 && co < (int)ctrSwatches().size() && !strcmp(h, body) ? hex(ctrSwatches()[(size_t)co].c) : hex(h); };   // the body (its first colour) in yours
  switch (id) {
    case 0: box(cx - .35f, cy - .5f, z, cx + .35f, cy + .5f, z + .65f, HX("#c9cdd2")); box(cx - .2f, cy - .35f, z + .65f, cx + .2f, cy - .05f, z + .67f, HX("#222")); box(cx - .2f, cy + .05f, z + .65f, cx + .2f, cy + .35f, z + .67f, HX("#222")); break;
    case 1: box(cx - .25f, cy - .35f, z, cx + .25f, cy + .35f, z + .8f, HX("#5a3a24")); for (int i = 0; i < 4; i++) box(cx - .15f + i * .08f, cy - .2f, z + .8f, cx - .1f + i * .08f, cy + .2f, z + 1.15f, HX("#222")); break;
    case 2: box(cx - .45f, cy - .4f, z, cx + .35f, cy + .4f, z + .2f, HX("#1d1d1f")); box(cx + .05f, cy - .4f, z + .2f, cx + .35f, cy + .4f, z + 1.25f, HX("#1d1d1f")); box(cx - .45f, cy - .4f, z + 1.0f, cx + .35f, cy + .4f, z + 1.25f, HX("#1d1d1f")); cyl(cx - .2f, cy, z + .2f, z + .75f, .25f, .27f, HX("#9fb6c6")); break;
    case 3: box(cx - .3f, cy - .3f, z, cx + .3f, cy + .3f, z + .45f, HX("#d9d9d9")); cyl(cx, cy, z + .45f, z + 1.4f, .22f, .3f, HX("#bfd9e6")); cyl(cx, cy, z + 1.4f, z + 1.5f, .3f, .3f, HX("#222")); break;
    case 4: box(cx - .45f, cy - .45f, z, cx + .4f, cy + .45f, z + .95f, HX("#2a2a2a")); box(cx - .48f, cy - .3f, z + .2f, cx - .45f, cy + .3f, z + .6f, HX("#111")); break;
    case 5: box(cx - .8f, cy - .7f, z, cx + .5f, cy + .7f, z + .95f, HX("#e8e8e4")); box(cx - .82f, cy - .55f, z + .15f, cx - .8f, cy + .3f, z + .8f, HX("#20262c")); break;
    case 6: { Col r = HX("#c8102e"); box(cx - .4f, cy - .3f, z, cx + .4f, cy + .3f, z + .12f, r); box(cx + .1f, cy - .2f, z + .12f, cx + .35f, cy + .2f, z + 1.0f, r); box(cx - .45f, cy - .25f, z + .8f, cx + .35f, cy + .25f, z + 1.15f, r); cyl(cx - .2f, cy, z + .12f, z + .55f, .25f, .3f, HX("#d0d0d0")); } break;
    case 7: box(cx - .5f, cy - .6f, z, cx + .45f, cy + .6f, z + 1.15f, HX("#b9bcc0")); box(cx - .52f, cy - .45f, z + .45f, cx - .5f, cy + .45f, z + .55f, HX("#1d1d1f")); cyl(cx - .7f, cy + .25f, z + .5f, z + .9f, .04f, .04f, HX("#ddd")); cyl(cx - .62f, cy - .2f, z, z + .25f, .12f, .14f, HX("#f2efe6")); break;
  }
}
// the jersey on the back of the front door: your team's colours, a crest with its letters
static const uint8_t FONT5[36][7] = {
  {14, 17, 17, 31, 17, 17, 17}, {30, 17, 17, 30, 17, 17, 30}, {14, 17, 16, 16, 16, 17, 14}, {30, 17, 17, 17, 17, 17, 30}, {31, 16, 16, 30, 16, 16, 31}, {31, 16, 16, 30, 16, 16, 16},
  {14, 17, 16, 23, 17, 17, 15}, {17, 17, 17, 31, 17, 17, 17}, {14, 4, 4, 4, 4, 4, 14}, {7, 2, 2, 2, 2, 18, 12}, {17, 18, 20, 24, 20, 18, 17}, {16, 16, 16, 16, 16, 16, 31},
  {17, 27, 21, 21, 17, 17, 17}, {17, 17, 25, 21, 19, 17, 17}, {14, 17, 17, 17, 17, 17, 14}, {30, 17, 17, 30, 16, 16, 16}, {14, 17, 17, 17, 21, 18, 13}, {30, 17, 17, 30, 20, 18, 17},
  {15, 16, 16, 14, 1, 1, 30}, {31, 4, 4, 4, 4, 4, 4}, {17, 17, 17, 17, 17, 17, 14}, {17, 17, 17, 17, 17, 10, 4}, {17, 17, 17, 21, 21, 21, 10}, {17, 17, 10, 4, 10, 17, 17},
  {17, 17, 10, 4, 4, 4, 4}, {31, 1, 2, 4, 8, 16, 31}, {14, 17, 19, 21, 25, 17, 14}, {4, 12, 4, 4, 4, 4, 14}, {14, 17, 1, 2, 4, 8, 31}, {30, 1, 1, 14, 1, 1, 30},
  {2, 6, 10, 18, 31, 2, 2}, {31, 16, 30, 1, 1, 17, 14}, {6, 8, 16, 30, 17, 17, 14}, {31, 1, 2, 4, 8, 8, 8}, {14, 17, 17, 14, 17, 17, 14}, {14, 17, 17, 15, 1, 2, 12}};
static void letters(const std::string &s, float cx, float y, float zc, float px, Col c, int face = 1) {   // block letters on a wall facing +y (face -1: facing -y)
  float w = (float)s.size() * 6 * px - px, f = (float)face, x = cx + f * (w / 2 - px);   // facing +y, +x is to the viewer's left: lay the letters out right to left (facing -y: left to right)
  for (char ch : s) { int k = ch >= 'A' && ch <= 'Z' ? ch - 'A' : ch >= 'a' && ch <= 'z' ? ch - 'a' : ch >= '0' && ch <= '9' ? 26 + ch - '0' : -1;
    if (k >= 0) for (int r = 0; r < 7; r++) for (int b = 0; b < 5; b++) if (FONT5[k][r] >> (4 - b) & 1) {
      float x0 = x - f * b * px + (face < 0 ? -px : 0), z1 = zc + 3.5f * px - r * px;
      if (face > 0) quad({x0, y, z1 - px}, {x0 + px, y, z1 - px}, {x0 + px, y, z1}, {x0, y, z1}, c, {0, 1, 0}, 9, true);
      else quad({x0 + px, y, z1 - px}, {x0, y, z1 - px}, {x0, y, z1}, {x0 + px, y, z1}, c, {0, -1, 0}, 9, true); }
    x -= f * 6 * px; }
}
static int jerseyTeam = -1;
static void jersey() {
  if (!CR) return; int t = C.me; jerseyTeam = t; Col pc = hex(teamCol(t)), sc = hex(teamStr(t)); float y = .135f;
  auto fq = [&](float x0, float z0, float x1, float z1, Col c, float dy) { quad({x0, y + dy, z0}, {x1, y + dy, z0}, {x1, y + dy, z1}, {x0, y + dy, z1}, c, {0, 1, 0}, 9); };
  auto sl = [&](float xa, float za, float xb, float zb, float xc, float zc2, float xd, float zd, Col c, float dy) { quad({xa, y + dy, za}, {xb, y + dy, zb}, {xc, y + dy, zc2}, {xd, y + dy, zd}, c, {0, 1, 0}, 9); };
  box(3.42f, .12f, 5.95f, 3.58f, .3f, 6.1f, HX("#9a9a9a"));   // the hook
  fq(2.8f, 3.1f, 4.2f, 5.75f, pc, 0);   // body
  sl(2.8f, 5.75f, 2.8f, 4.95f, 2.15f, 4.55f, 2.25f, 5.35f, pc, 0); sl(4.2f, 4.95f, 4.2f, 5.75f, 4.75f, 5.35f, 4.85f, 4.55f, pc, 0);   // sleeves
  fq(2.8f, 3.45f, 4.2f, 3.65f, sc, .012f); fq(2.8f, 3.75f, 4.2f, 3.85f, sc, .012f);   // hem stripes
  sl(2.36f, 4.66f, 2.22f, 4.94f, 2.29f, 5.04f, 2.44f, 4.76f, sc, .012f); sl(4.64f, 4.76f, 4.71f, 5.04f, 4.78f, 4.94f, 4.56f, 4.66f, sc, .012f);   // sleeve stripes
  sl(3.25f, 5.75f, 3.75f, 5.75f, 3.6f, 5.45f, 3.4f, 5.45f, shade(pc, -.45), .012f);   // the collar
  // the crest: two discs facing out of the door, then the team's letters
  for (int L = 0; L < 2; L++) { float r = L ? .36f : .42f; Col c = L ? pc : sc; P3 ctr = {3.5f, y + .02f + L * .012f, 4.55f}; uint32_t k = litAt(c, ctr, {0, 1, 0}).pack();
    for (int i = 0; i < 16; i++) { float a0 = i * 6.2832f / 16, a1 = (i + 1) * 6.2832f / 16; vtx(ctr, k); vtx({3.5f + std::cos(a0) * r, ctr.y, 4.55f + std::sin(a0) * r}, k); vtx({3.5f + std::cos(a1) * r, ctr.y, 4.55f + std::sin(a1) * r}, k); } }
  std::string ab = C.L[(size_t)t].ab; letters(ab, 3.5f, y + .05f, 4.55f, ab.size() > 2 ? .028f : .034f, sc);
}

// ---------------------------------------------------------------- the whole place
static Col wallPaint(P3 p, P3 n) {   // the paint on a wall face: whichever room it faces
  static const char *ORIG[HOME_NR] = {"#a29a86", "#b2a98d", "#8e8e99", "#9b9a88"}, *PAL[4] = {"", "#e9e5db", "#a3b79e", "#3a4966"};
  P3 q = p + n * .6f; if (q.x < 0 || q.y < 0 || q.x > AX || q.y > AY) return HX("#a29a86");
  int r = homeRoomAt(q.x, q.y);
  if (r == ROOM_BATH) return HOME.sel[HS_BPAINT] ? K(HS_BPAINT, "#ecebe6") : HX(HOME.lvl == 0 ? "#c9c7b2" : HOME.lvl == 1 ? "#dfe6e4" : "#e9e4da");   // tile-ish: yellowed, clean, warm stone
  if (r == ROOM_CAVE) return HOME.sel[HS_CPAINT] ? K(HS_CPAINT, "#45484d") : HX("#34373d");                                                  // the man cave: charcoal
  int v = HOME.sel[HS_PAINT + r]; return v ? K(HS_PAINT + r, PAL[v]) : HX(ORIG[r]);
}
static bool LIT[APT_NLIGHT] = {true, true, true, true, true, true};
const char *APT_LIGHTN[APT_NLIGHT] = {"LIVING ROOM", "KITCHEN", "BEDROOM", "OFFICE", "BATHROOM", "MAN CAVE"};
static int lightGrp(int room) { return room == ROOM_BATH ? 4 : room == ROOM_CAVE ? 5 : room >= 0 && room < 4 ? room : 0; }
bool aptLightOn(int i) { return i >= 0 && i < APT_NLIGHT && LIT[i]; }
void aptLight(int i) { if (i < 0 || i >= APT_NLIGHT) return; LIT[i] = !LIT[i]; aptDirty(); }
// a wall's flat shade: by which way it faces (so corners still read), dimmer with the room's lights off
static float wallK(P3 p, P3 n) { P3 q = p + n * .6f; int r = (q.x < 0 || q.y < 0 || q.x > AX || q.y > AY) ? 0 : homeRoomAt(q.x, q.y);
  float k = n.z > .5f ? .8f : .86f + .05f * n.y + .03f * std::fabs(n.x); return k * (LIT[lightGrp(r)] ? 1.f : .6f); }
static void wbox(float x0, float y0, float z0, float x1, float y1, float z1, bool bottom) {   // a wall box, each face painted for its room
  auto f = [&](P3 a, P3 b, P3 c, P3 d, P3 n) { P3 m = (a + b + c + d) * .25f; FLATK = wallK(m, n); quad(a, b, c, d, wallPaint(m, n), n, 3); FLATK = -1; };
  f({x0, y0, z1}, {x1, y0, z1}, {x1, y1, z1}, {x0, y1, z1}, {0, 0, 1}); if (bottom) f({x0, y0, z0}, {x0, y1, z0}, {x1, y1, z0}, {x1, y0, z0}, {0, 0, -1});
  f({x0, y0, z0}, {x1, y0, z0}, {x1, y0, z1}, {x0, y0, z1}, {0, -1, 0}); f({x1, y1, z0}, {x0, y1, z0}, {x0, y1, z1}, {x1, y1, z1}, {0, 1, 0});
  f({x0, y1, z0}, {x0, y0, z0}, {x0, y0, z1}, {x0, y1, z1}, {-1, 0, 0}); f({x1, y0, z0}, {x1, y1, z0}, {x1, y1, z1}, {x1, y0, z1}, {1, 0, 0});
}
int homeRoomAt(double x, double y) { if (x >= KX && KX < AX - .5f) return ROOM_CAVE; if (x >= 14 && x <= 20 && y >= BY) return ROOM_BATH;
  if (x >= 18 && y < KY) return 1; if (x >= 20 && y >= KY) return 3; if (x < 14 && y >= LY) return 2; return 0; }
static const float DOORY = 4.5f;   // the hallway doors start this far up the hall
// a door: hinge (hx, hy); shut, the slab runs along (cx, cy) from the hinge; it swings toward side (left / right of that)
struct HDoor { float hx, hy, side, cx = 0, cy = 1; double a = 0, tgt = 0, hold = 0; };
static HDoor HD[APT_NHD] = {{14, 18.62f, -1}, {20, 18.62f, 1}, {19.4f, 19, 1, -1, 0}};
static P3 dShut(const HDoor &d) { return {d.cx, d.cy, 0}; }
static P3 dOpen(const HDoor &d) { return {d.cy * d.side, -d.cx * d.side, 0}; }
static const float DW = 2.76f, DH = 6.95f, DT = .14f;
// ---------------------------------------------------------------- the bathroom (every apartment: the end of the hall)
static void bathGeo(int L) {
  const float x0 = 14 + WT, x1 = 20 - WT, y0 = BY + WT, y1 = AY - WT; P3 up = {0, 0, 1};
  // the floor: small tiles (yellowed in the starter, clean grey in the corner unit, marble up top)
  if (L == 2) floorRect(14, BY, 20, AY, 3);
  else for (float x = 14; x < 20 - .01f; x += .75f) for (float y = BY; y < AY - .01f; y += .75f) { int a = (int)(x / .75f), b = (int)(y / .75f);
    Col t = L == 0 ? (((a + b) & 1) ? HX("#cfc8b0") : HX("#b9b39a")) : (((a + b) & 1) ? HX("#d9dcdc") : HX("#c3c8ca")); if (L == 0 && frand() < .1f) t = HX("#9d9478");
    quad({x + .02f, y + .02f, .012f}, {std::min(20.f, x + .75f) - .02f, y + .02f, .012f}, {std::min(20.f, x + .75f) - .02f, std::min(AY, y + .75f) - .02f, .012f}, {x + .02f, std::min(AY, y + .75f) - .02f, .012f}, vary(t, .04f), up, 9); }
  Col wh = L == 0 ? HX("#e4dcc4") : HX("#f4f4f2"), chrome = L == 2 ? HX("#c9a54a") : HX("#b8bcc0");
  if (L < 2) {   // a tub along the back wall, a shower curtain
    box(x0, y1 - 2.4f, 0, x1, y1, 1.9f, wh); box(x0 + .3f, y1 - 2.1f, 1.9f, x1 - .3f, y1 - .3f, 1.92f, L == 0 ? HX("#b8b096") : HX("#dde3e6"), 9, 0);
    if (L == 0) blob(x1 - 1.0f, y1 - 1.2f, 1.93f, .35f, 0, HX("#9a7a4a"));   // rust under the tap
    box(x1 - .5f, y1 - 1.3f, 2.2f, x1 - .3f, y1 - 1.1f, 2.45f, chrome); cyl(16.5f, y1 - .2f, 6.0f, 6.3f, .18f, .25f, chrome, 8);
    box(x0, y1 - 2.47f, 7.3f, x1, y1 - 2.43f, 7.36f, chrome, 9);   // the rod
    Col cu = L == 0 ? HX("#9fb3b8") : HX("#f2f2f0"); quad({x0 + .05f, y1 - 2.45f, 2.0f}, {x0 + 3.3f, y1 - 2.45f, 2.0f}, {x0 + 3.3f, y1 - 2.45f, 7.3f}, {x0 + .05f, y1 - 2.45f, 7.3f}, cu, {0, -1, 0}, 9);
    quad({x0 + 3.3f, y1 - 2.43f, 2.0f}, {x0 + .05f, y1 - 2.43f, 2.0f}, {x0 + .05f, y1 - 2.43f, 7.3f}, {x0 + 3.3f, y1 - 2.43f, 7.3f}, cu, {0, 1, 0}, 9);
    solid(x0, y1 - 2.5f, x1, y1); }
  else {   // the penthouse: a walk-in shower behind frosted glass, a rain head
    box(x0, y1 - 2.6f, 0, x1, y1, .12f, HX("#4a4f55"), 9); box(x0, y1 - 2.65f, .12f, x0 + 3.6f, y1 - 2.55f, 7.0f, HX("#cfe0e6"), 9, 1, true); box(x0 + 3.6f, y1 - 2.65f, 0, x0 + 3.68f, y1 - 2.55f, 7.0f, chrome);
    cyl(17.2f, y1 - 1.3f, 7.6f, 7.7f, .55f, .55f, chrome, 10); box(17.15f, y1 - 1.35f, 7.7f, 17.25f, y1, 7.76f, chrome);
    solid(x0, y1 - 2.7f, x0 + 3.7f, y1 - 2.5f); }
  // the vanity and the mirror (west wall), the toilet beside it, a towel (your team's colour) on the east wall
  Col vc = L == 0 ? HX("#8b7a5c") : L == 1 ? HX("#e8e6e0") : HX("#3b2e26");
  box(x0, y0 + .4f, 0, x0 + 1.7f, y0 + 2.5f, 2.8f, vc); box(x0, y0 + .3f, 2.8f, x0 + 1.85f, y0 + 2.6f, 2.95f, L == 2 ? HX("#efece6") : L == 1 ? HX("#cfd3d6") : HX("#a39d88"), 3, 0);
  box(x0 + .5f, y0 + 1.0f, 2.95f, x0 + 1.4f, y0 + 1.9f, 2.97f, HX("#9aa4aa"), 9, 0); box(x0 + .05f, y0 + 1.38f, 2.95f, x0 + .35f, y0 + 1.52f, 3.6f, chrome); solid(x0, y0 + .3f, x0 + 1.85f, y0 + 2.6f);
  quad({x0 + .03f, y0 + 2.35f, 3.7f}, {x0 + .03f, y0 + .55f, 3.7f}, {x0 + .03f, y0 + .55f, 6.3f}, {x0 + .03f, y0 + 2.35f, 6.3f}, HX(L == 0 ? "#9fa9a8" : "#c7d4d8"), {1, 0, 0}, 9, true);   // the mirror
  if (L == 0) patch({x0 + .04f, y0 + 1.7f, 5.4f}, {0, .5f, .35f}, {0, 0, .015f}, HX("#5f6766"), {1, 0, 0}, true);   // cracked
  if (L == 2) for (float y : {y0 + .5f, y0 + 2.4f}) box(x0 + .03f, y - .06f, 3.8f, x0 + .2f, y + .06f, 6.2f, HX("#ffe7b0"), 9, 1, true);   // backlit
  float ty = y0 + 3.4f; box(x0, ty - .55f, 1.4f, x0 + .6f, ty + .55f, 2.9f, wh); cyl(x0 + 1.15f, ty, 0, 1.3f, .32f, .48f, wh, 10); box(x0 + .65f, ty - .45f, 1.3f, x0 + 1.6f, ty + .45f, 1.38f, L == 0 ? HX("#cfc6a8") : wh); solid(x0, ty - .6f, x0 + 1.7f, ty + .6f);
  cyl(x0 + .15f, ty + 1.0f, 2.4f, 2.5f, .2f, .2f, HX("#f7f5ef"), 8);   // the toilet roll
  Col tw = CR ? hex(teamCol(C.me)) : HX("#2f5a9a"); box(x1 - .12f, y0 + 3.0f, 4.3f, x1, y0 + 4.6f, 4.38f, chrome); box(x1 - .2f, y0 + 3.1f, 2.4f, x1 - .1f, y0 + 4.5f, 4.35f, tw);
  blob(16.8f, y0 + 2.0f, .03f, .7f, 0, L == 2 ? HX("#e9e2d2") : HX("#6c7f8f"));   // a bath mat
  if (L == 0) for (int i = 0; i < 3; i++) blob(x0 + .6f + i * .5f, y1 - .4f, CEIL - .02f, .4f + frand() * .3f, 0, HX("#4f5a44"), {0, 0, -1});   // mould
}
// ---------------------------------------------------------------- the bed (upgradeable everywhere)
static void bedGeo(int v) {
  const float DY = LY - 14, bx0 = 1.0f, bx1 = 6.5f, by0 = 19.0f + DY, by1 = AY - WT - .05f;
  if (v == 0) { box(bx0, by0, 0, bx1, by0 + 6.7f, .9f, HX("#bdb6a2"), 2); box(1.4f, by0 + 5.3f, .9f, 4.0f, by0 + 6.4f, 1.3f, HX("#e1ddd0"), 2); box(1.1f, by0 + .2f, .9f, 6.2f, by0 + 3.8f, 1.05f, K(HS_BED, "#4a5a73"), 2); solid(bx0, by0, bx1, by0 + 6.7f); }
  else {
    Col fr = v == 1 ? HX("#3a3a3e") : v == 2 ? HX("#8a5e36") : HX("#5c5f6a"), sh = v == 3 ? HX("#f2efe8") : HX("#e1ddd0"), bl = K(HS_BED, v == 1 ? "#5a6f8c" : v == 2 ? "#a8483a" : "#2c3a52");
    float x0 = v == 3 ? .5f : bx0, x1 = v == 3 ? 6.9f : bx1, zb = v == 1 ? 1.2f : 1.0f;
    if (v == 1) { for (float x : {x0 + .05f, x1 - .15f}) for (float y : {by0 + .05f, by1 - .15f}) box(x, y, 0, x + .1f, y + .1f, zb, fr, 9); box(x0, by0, zb - .15f, x1, by1, zb, fr); box(x0, by1 - .15f, 0, x1, by1, 4.0f, fr); }
    else { box(x0 - .2f, by0 - .2f, 0, x1 + .2f, by1, zb, fr); box(x0 - .2f, by1 - .35f, 0, x1 + .2f, by1, v == 3 ? 6.4f : 4.2f, fr);
      if (v == 3) for (int i = 0; i < 4; i++) for (int k = 0; k < 3; k++) cyl(x0 + .6f + i * 1.7f, by1 - .37f, 3.5f + k * .9f, 3.52f + k * .9f, .06f, .06f, shade(fr, -.3), 5); }
    box(x0 + .1f, by0 + .1f, zb, x1 - .1f, by1 - .4f, zb + .8f, sh, 2); box(x0 + .05f, by0 + .05f, zb + .8f, x1 - .05f, by0 + 4.2f, zb + 1.0f, bl, 2);
    for (float x : {x0 + .4f, (x0 + x1) / 2 + .1f}) box(x, by1 - 1.5f, zb + .8f, x + (x1 - x0) / 2 - .5f, by1 - .5f, zb + 1.3f, HX("#f7f5ef"), 2);
    solid(x0 - .2f, by0 - .2f, x1 + .2f, by1); }
  HOT.push_back({APT_SLOT + HS_BED, {(bx0 + bx1) / 2, by0 + 3, 1.2f}, 7.5f});
}
// ---------------------------------------------------------------- the radio (X: the next song)
static void radioGeo() {
  box(.4f, 1.0f, 0, 1.5f, 2.2f, 2.2f, HX("#6a5236")); solid(.35f, .95f, 1.55f, 2.25f);
  box(.5f, 1.12f, 2.2f, 1.35f, 2.08f, 2.85f, HX("#2b2d31"));
  for (float y : {1.36f, 1.84f}) { patch({1.35f, y, 2.5f}, {0, .19f, 0}, {0, 0, .19f}, HX("#15161a"), {1, 0, 0}); patch({1.36f, y, 2.5f}, {0, .08f, 0}, {0, 0, .08f}, HX("#55575e"), {1, 0, 0}); }
  patch({1.36f, 1.6f, 2.74f}, {0, .09f, 0}, {0, 0, .04f}, HX("#7CFC9A"), {1, 0, 0}, true);   // the display
  box(.62f, 1.3f, 2.85f, .7f, 1.9f, 3.0f, HX("#1d1e22")); box(.55f, 1.18f, 2.85f, .58f, 1.21f, 4.0f, HX("#9a9a9a"));   // the handle, the antenna
  HOT.push_back({APT_RADIO, {1.0f, 1.6f, 2.6f}, 7});
}
// ---------------------------------------------------------------- the penthouse's man cave (east of the kitchen and office)
static void caveGeo() {
  const float x0 = KX + WT, x1 = AX - WT, y1 = AY - WT;
  Col tc = CR ? hex(teamCol(C.me)) : HX("#2f5a9a"), ts = CR ? hex(teamStr(C.me)) : HX("#e5e7eb");
  // framed jerseys on the wall by the archway (facing east)
  for (float y : {6.0f, 11.5f}) { float x = x0 + .02f; box(x0, y - 1.5f, 3.6f, x0 + .12f, y + 1.5f, 7.0f, HX("#1b1b1d"));
    quad({x + .12f, y + 1.2f, 3.9f}, {x + .12f, y - 1.2f, 3.9f}, {x + .12f, y - 1.2f, 6.7f}, {x + .12f, y + 1.2f, 6.7f}, HX("#d9d6cf"), {1, 0, 0}, 9);
    quad({x + .14f, y + .6f, 4.2f}, {x + .14f, y - .6f, 4.2f}, {x + .14f, y - .6f, 6.1f}, {x + .14f, y + .6f, 6.1f}, tc, {1, 0, 0}, 9);
    quad({x + .14f, y + 1.0f, 5.4f}, {x + .14f, y + .6f, 5.4f}, {x + .14f, y + .6f, 6.1f}, {x + .14f, y + 1.0f, 5.9f}, tc, {1, 0, 0}, 9); quad({x + .14f, y - .6f, 5.4f}, {x + .14f, y - 1.0f, 5.4f}, {x + .14f, y - 1.0f, 5.9f}, {x + .14f, y - .6f, 6.1f}, tc, {1, 0, 0}, 9);
    quad({x + .16f, y + .6f, 4.5f}, {x + .16f, y - .6f, 4.5f}, {x + .16f, y - .6f, 4.65f}, {x + .16f, y + .6f, 4.65f}, ts, {1, 0, 0}, 9); }
  // your number, retired, hanging from the ceiling in your team's colours
  { float bx = (x0 + x1) / 2, by = 10.2f, bw = 2.2f; box(bx - bw, by - .2f, 5.2f, bx + bw, by + .2f, 8.6f, tc); box(bx - bw, by - .22f, 5.5f, bx + bw, by + .22f, 5.75f, ts); box(bx - bw, by - .22f, 8.1f, bx + bw, by + .22f, 8.3f, ts);   // (thick enough that each face hides the other's number)
    for (float x : {bx - bw + .3f, bx + bw - .3f}) box(x - .02f, by - .02f, 8.6f, x + .02f, by + .02f, CEIL, HX("#555"));
    std::string n = CR ? istr(C.num) : "19"; letters(n, bx, by + .23f, 6.9f, .2f, ts, 1); letters(n, bx, by - .23f, 6.9f, .2f, ts, -1); }
  // THE BAR (south-east corner): a back bar along the east wall, the counter in front of it, stools
  int b = HOME.sel[HS_BAR];
  if (b == 1) { Col br = K(HS_BAR, "#c9a54a"); box(x1 - 2.2f, 2.0f, 0, x1 - .4f, 3.4f, .08f, br); box(x1 - 2.2f, 2.0f, 1.4f, x1 - .4f, 3.4f, 1.5f, br); box(x1 - 2.2f, 2.0f, 2.7f, x1 - .4f, 3.4f, 2.8f, br);
    for (float x : {x1 - 2.15f, x1 - .5f}) for (float y : {2.05f, 3.3f}) box(x, y, 0, x + .06f, y + .06f, 2.8f, br, 9);
    for (int i = 0; i < 5; i++) cyl(x1 - 1.9f + i * .32f, 2.7f, 2.8f, 3.6f + (i % 2) * .3f, .1f, .07f, vary(HX("#5a7a3a"), .5f), 6); solid(x1 - 2.3f, 1.9f, x1 - .3f, 3.5f); }
  else if (b >= 2) { bool lit = b == 3; Col wd = K(HS_BAR, lit ? "#2a1f1a" : "#7a4e2c"), top = lit ? HX("#1d1d20") : HX("#a8743f");
    box(x1 - 1.1f, 1.0f, 0, x1, 9.0f, 3.0f, wd); for (float z : {3.9f, 5.1f, 6.3f}) { box(x1 - .9f, 1.2f, z - .08f, x1, 8.8f, z, wd, 3, 0); if (lit) box(x1 - .05f, 1.2f, z, x1, 8.8f, z + 1.0f, HX("#ffb347"), 9, 1, true);
      for (float y = 1.4f; y < 8.5f; y += .38f + frand() * .2f) cyl(x1 - .5f, y, z, z + .6f + frand() * .3f, .1f, .06f, vary(lit ? HX("#7fb8ff") : HX("#6a8a4a"), .6f), 6); }
    solid(x1 - 1.2f, .9f, x1, 9.1f);
    float cx0 = x1 - 4.4f, cx1 = x1 - 3.0f; box(cx0, 1.0f, 0, cx1, 8.5f, 3.4f, wd); box(cx0 - .35f, .9f, 3.4f, cx1 + .1f, 8.6f, 3.6f, top, 3, 0); solid(cx0 - .35f, .9f, cx1 + .1f, 8.6f);
    if (lit) { box(cx0 - .05f, 1.0f, .3f, cx0, 8.5f, .4f, HX("#38bdf8"), 9, 1, true); for (int i = 0; i < 3; i++) { float y = 3.2f + i * .7f; box(cx1 - .5f, y - .1f, 3.6f, cx1 - .3f, y + .1f, 4.6f, HX("#c0c4c8")); box(cx1 - .7f, y - .06f, 4.4f, cx1 - .3f, y + .06f, 4.55f, HX("#c0c4c8")); }   // taps
      box(x1 - 1.1f, 9.3f, 0, x1, 10.8f, 2.9f, HX("#1d1d20")); quad({x1 - 1.12f, 10.6f, .4f}, {x1 - 1.12f, 9.5f, .4f}, {x1 - 1.12f, 9.5f, 2.6f}, {x1 - 1.12f, 10.6f, 2.6f}, HX("#9fe0ff"), {-1, 0, 0}, 9, true); solid(x1 - 1.2f, 9.2f, x1, 10.9f);   // the beer fridge
      for (int i = 0; i < 5; i++) box(x1 - .04f, 2.0f + i * 1.3f, 7.2f, x1, 2.9f + i * 1.3f, 7.4f, i & 1 ? tc : HX("#ff4fa3"), 9, 1, true); }   // neon
    for (int i = 0; i < 4; i++) { float y = 1.8f + i * 1.9f, x = cx0 - 1.2f; cyl(x, y, 0, 2.3f, .08f, .08f, HX("#2b2b2b"), 6, false); cyl(x, y, 2.3f, 2.5f, .45f, .45f, lit ? HX("#8b1d1d") : HX("#3b2a1e"), 10); } }
  HOT.push_back({APT_SLOT + HS_BAR, {x1 - 3.0f, 4.5f, 3.0f}, 7.5f});
  // THE GAME TABLE (the middle of the room)
  int g = HOME.sel[HS_GAME]; float gx = (x0 + x1) / 2, gy = 15.0f;
  if (g == 1) { float y = 14.0f; for (int r = 0; r < 4; r++) { float rr = .9f - r * .22f; Col c = r == 3 ? HX("#c8102e") : r & 1 ? HX("#1d1d1d") : HX("#e9dcb4");
      quad({x1 - .03f - r * .005f, y + rr, 5.4f - rr}, {x1 - .03f - r * .005f, y - rr, 5.4f - rr}, {x1 - .03f - r * .005f, y - rr, 5.4f + rr}, {x1 - .03f - r * .005f, y + rr, 5.4f + rr}, c, {-1, 0, 0}, 9); }
    quad({x1 - .03f, y + 3.6f, 4.4f}, {x1 - .03f, y + 1.6f, 4.4f}, {x1 - .03f, y + 1.6f, 6.4f}, {x1 - .03f, y + 3.6f, 6.4f}, HX("#22302a"), {-1, 0, 0}, 9); }   // a chalkboard
  else if (g == 2) { box(gx - 3, gy - 1.6f, 0, gx + 3, gy + 1.6f, 2.6f, K(HS_GAME, "#1d3b6b")); box(gx - 2.85f, gy - 1.45f, 2.6f, gx + 2.85f, gy + 1.45f, 2.63f, HX("#eef3f7"), 9, 0);
    box(gx - .02f, gy - 1.45f, 2.63f, gx + .02f, gy + 1.45f, 2.64f, HX("#d23b3b"), 9, 0); for (float x : {gx - 2.2f, gx + 2.2f}) cyl(x, gy, 2.63f, 2.9f, .22f, .22f, x < gx ? HX("#d23b3b") : HX("#2f64d6"), 10);
    cyl(gx + .6f, gy - .3f, 2.63f, 2.68f, .14f, .14f, HX("#ff8a00"), 8); solid(gx - 3, gy - 1.6f, gx + 3, gy + 1.6f); }
  else if (g == 3) { Col rail = HX("#4a2a18"); box(gx - 4.2f, gy - 2.4f, 0, gx + 4.2f, gy + 2.4f, 2.5f, rail); box(gx - 3.7f, gy - 1.9f, 2.5f, gx + 3.7f, gy + 1.9f, 2.52f, K(HS_GAME, "#1f6b3a"), 9, 0);
    for (float x : {gx - 4.2f, gx + 3.85f}) box(x, gy - 2.4f, 2.5f, x + .35f, gy + 2.4f, 2.75f, rail); for (float y : {gy - 2.4f, gy + 2.05f}) box(gx - 4.2f, y, 2.5f, gx + 4.2f, y + .35f, 2.75f, rail);
    for (float x : {gx - 3.7f, gx, gx + 3.7f}) for (float y : {gy - 1.9f, gy + 1.9f}) cyl(x, y, 2.5f, 2.53f, .2f, .2f, HX("#0d0d0d"), 8);
    for (int i = 0; i < 6; i++) cyl(gx + 1.5f + (i % 3) * .3f, gy - .3f + (i / 3) * .3f, 2.52f, 2.7f, .14f, .14f, vary(HX("#e0b040"), .8f), 8);
    box(gx - 2.5f, gy - .3f, 7.2f, gx + 2.5f, gy + .3f, 7.6f, HX("#1f3b2a")); box(gx - 2.4f, gy - .25f, 7.15f, gx + 2.4f, gy + .25f, 7.2f, HX("#fff2c2"), 9, 1, true);   // the light over it
    solid(gx - 4.2f, gy - 2.4f, gx + 4.2f, gy + 2.4f); }
  HOT.push_back({APT_SLOT + HS_GAME, {gx, gy, 2.6f}, 7.5f});
  // CAVE SEATING (the north end, facing the north wall)
  int sv = HOME.sel[HS_CAVE];
  if (sv == 0) { for (int i = 0; i < 3; i++) { float x = gx - 2.4f + i * 2.4f, y = 26.0f; Col c = K(HS_CAVE, "#6b6e73"); box(x - .6f, y, 1.5f, x + .6f, y + 1.1f, 1.6f, c); box(x - .6f, y, 1.6f, x + .6f, y + .1f, 3.2f, c);
      for (float lx : {x - .55f, x + .48f}) box(lx, y + .1f, 0, lx + .06f, y + 1.0f, 1.5f, HX("#3d3d40"), 9); } solid(gx - 3.1f, 26, gx + 3.1f, 27.2f); }
  else if (sv == 1) { box(gx - 3, y1 - 2.4f, 2.6f, gx + 3, y1 - .1f, 2.75f, HX("#1b1b1f"), 3, 0); for (float x : {gx - 2.8f, gx + 2.7f}) box(x, y1 - 2.3f, 0, x + .1f, y1 - .2f, 2.6f, HX("#1b1b1f"), 9);
    for (int i = -1; i <= 1; i++) { float x = gx + i * 1.9f; box(x - .85f, y1 - 1.0f, 3.2f, x + .85f, y1 - .9f, 4.3f, HX("#111")); quad({x - .78f, y1 - 1.01f, 3.27f}, {x + .78f, y1 - 1.01f, 3.27f}, {x + .78f, y1 - 1.01f, 4.23f}, {x - .78f, y1 - 1.01f, 4.23f}, i ? HX("#3b82f6") : HX("#22c55e"), {0, -1, 0}, 9, true); }
    box(gx - .2f, y1 - 2.0f, 2.75f, gx + .2f, y1 - .8f, 2.85f, HX("#ff4fa3"), 9, 1, true);
    box(gx - .9f, y1 - 4.4f, 1.2f, gx + .9f, y1 - 3.0f, 1.7f, K(HS_CAVE, "#151518")); box(gx - .9f, y1 - 4.5f, 1.7f, gx + .9f, y1 - 4.2f, 5.0f, K(HS_CAVE, "#151518")); box(gx - .9f, y1 - 4.55f, 3.6f, gx + .9f, y1 - 4.5f, 4.6f, HX("#d23b3b"));
    cyl(gx, y1 - 3.7f, 0, 1.2f, .12f, .12f, HX("#333"), 6, false); solid(gx - 3.1f, y1 - 4.5f, gx + 3.1f, y1); }
  else if (sv >= 2) { float sw = 8.5f, sz = 2.6f; box(gx - sw / 2 - .1f, y1 - .2f, sz - .1f, gx + sw / 2 + .1f, y1, sz + sw * .5625f + .1f, HX("#0b0b0d"), 9, 0);
    quad({gx - sw / 2, y1 - .21f, sz}, {gx + sw / 2, y1 - .21f, sz}, {gx + sw / 2, y1 - .21f, sz + sw * .5625f}, {gx - sw / 2, y1 - .21f, sz + sw * .5625f}, HX("#dfe8f0"), {0, -1, 0}, 9, true);
    quad({gx - .1f, y1 - .22f, sz + .3f}, {gx + .1f, y1 - .22f, sz + .3f}, {gx + .1f, y1 - .22f, sz + sw * .5625f - .3f}, {gx - .1f, y1 - .22f, sz + sw * .5625f - .3f}, HX("#d23b3b"), {0, -1, 0}, 9, true);
    auto recl = [&](float x, float y, float z) { Col c = K(HS_CAVE, "#2b1d17"); box(x - 1.3f, y, z, x + 1.3f, y + 2.4f, z + 1.6f, c, 2); box(x - 1.3f, y, z + 1.6f, x + 1.3f, y + .6f, z + 3.6f, c, 2);
      box(x - 1.45f, y, z, x - 1.15f, y + 2.4f, z + 2.3f, c); box(x + 1.15f, y, z, x + 1.45f, y + 2.4f, z + 2.3f, c); cyl(x + 1.3f, y + .3f, z + 2.3f, z + 2.35f, .14f, .14f, HX("#9a9a9a"), 6); };
    for (int i = -1; i <= 1; i++) recl(gx + i * 2.9f, y1 - 9.0f, 0); solid(gx - 4.5f, y1 - 9.0f, gx + 4.5f, y1 - 6.6f);
    if (sv == 3) { box(gx - 4.8f, y1 - 13.2f, 0, gx + 4.8f, y1 - 9.6f, 1.0f, HX("#3a2a22")); for (int i = -1; i <= 1; i++) recl(gx + i * 2.9f, y1 - 12.6f, 1.0f); solid(gx - 4.8f, y1 - 13.2f, gx + 4.8f, y1 - 9.6f);
      float px = x1 - 1.0f, py = y1 - 15.0f; box(px - .7f, py - .7f, 0, px + .7f, py + .7f, 2.6f, HX("#b91c1c")); box(px - .6f, py - .6f, 2.6f, px + .6f, py + .6f, 4.2f, HX("#fff2c2"), 9, 1, true); box(px - .7f, py - .7f, 4.2f, px + .7f, py + .7f, 4.6f, HX("#b91c1c")); solid(px - .8f, py - .8f, px + .8f, py + .8f); }
    else { box(x1 - 1.0f, y1 - 9.5f, 0, x1 - .1f, y1 - 8.0f, 1.8f, HX("#1d1d20")); } }
  HOT.push_back({APT_SLOT + HS_CAVE, {gx, y1 - 6.0f, 2.0f}, 7.5f});
}
static void build() {
  AG.clear(); COL.clear(); HOT.clear(); LAMPS.clear(); sd = 7;
  const int L = HOME.lvl; KX = L == 2 ? 44.f : L ? 40.f : 34.f; AX = L == 2 ? 58.f : KX; LY = L == 2 ? 20.f : L ? 18.f : 14.f; KY = L == 2 ? 16.f : L ? 14.f : 12.f; AY = LY + 12; BY = AY - 7;
  const float DX = KX - 34, DY = LY - 14, DK = KY - 12, dy0 = LY + 1.0f;
  HD[0].hx = 14; HD[1].hx = 20; HD[0].hy = HD[1].hy = dy0 + .12f; HD[2].hx = 19.4f; HD[2].hy = BY;
  LAMPS = {{{9, LY / 2, 8.4f}, .5f}, {{26 + DX / 2, KY / 2, 8.4f}, .45f}, {{7, LY + 6, 8.4f}, .38f}, {{27 + DX / 2, (KY + AY) / 2, 8.4f}, .38f}, {{17, LY + 2.5f, 8.4f}, .3f}, {{17, BY + 3.2f, 8.4f}, .32f}};
  if (L == 2) { LAMPS.push_back({{(KX + AX) / 2, 5, 8.4f}, .4f}); LAMPS.push_back({{(KX + AX) / 2, 15, 8.4f}, .45f}); LAMPS.push_back({{(KX + AX) / 2, 26, 8.4f}, .3f}); }
  static const int LGRP[9] = {0, 1, 2, 3, 0, 4, 5, 5, 5};   // each bulb's switch
  std::vector<Lamp> bulbs = LAMPS; std::vector<bool> bulbOn; { std::vector<Lamp> on; for (size_t i = 0; i < LAMPS.size(); i++) { bool o = LIT[LGRP[std::min<size_t>(i, 8)]]; bulbOn.push_back(o); if (o) on.push_back(LAMPS[i]); } LAMPS = on; }
  // floors, room by room
  floorRect(0, 0, 18, LY, HOME.sel[HS_FLOOR], false, HS_FLOOR); floorRect(18, KY, 20, LY, HOME.sel[HS_FLOOR], false, HS_FLOOR); floorRect(14, LY, 20, BY, HOME.sel[HS_FLOOR], false, HS_FLOOR);
  floorRect(18, 0, KX, KY, HOME.sel[HS_FLOOR + 1], true, HS_FLOOR + 1); floorRect(0, LY, 14, AY, HOME.sel[HS_FLOOR + 2], false, HS_FLOOR + 2); floorRect(20, KY, KX, AY, HOME.sel[HS_FLOOR + 3], false, HS_FLOOR + 3);
  if (L == 2) floorRect(KX, 0, AX, AY, 2);
  // the ceiling: flat, room by room (each as lit as its switch says), water-stained (less so up in the penthouse)
  { struct CR4 { float x0, y0, x1, y1; int g; }; std::vector<CR4> cs = {{0, 0, 18, LY, 0}, {18, KY, 20, LY, 0}, {14, LY, 20, BY, 0}, {18, 0, KX, KY, 1}, {0, LY, 14, AY, 2}, {20, KY, KX, AY, 3}, {14, BY, 20, AY, 4}};
    if (L == 2) cs.push_back({KX, 0, AX, AY, 5});
    for (auto &c : cs) { FLATK = LIT[c.g] ? .9f : .55f; quad({c.x0, c.y1, CEIL}, {c.x1, c.y1, CEIL}, {c.x1, c.y0, CEIL}, {c.x0, c.y0, CEIL}, HX("#e3ddd0"), {0, 0, -1}, 9); FLATK = -1; } }
  for (int i = 0; i < (L == 2 ? 2 : 7); i++) { float x = 2 + frand() * (KX - 4), y = 2 + frand() * (AY - 4), r = .6f + frand() * 1.4f; blob(x, y, CEIL - .02f, r, 0, vary(HX("#a3957a"), .1f), {0, 0, -1}); }
  // walls: the outside, then the rooms (wall() paints each face for the room it faces)
  std::vector<Gap> fg = {{2, 5, 0, 7.2f}, {8, 15, 3, 7.2f}, {24, 29, 3.5f, 6.8f}}; if (L == 2) { fg.push_back({33, 39, 3.5f, 6.8f}); fg.push_back({KX + 4, KX + 10, 3, 7.2f}); }
  wall(true, 0, 0, AX, fg, Col());
  wall(true, AY, 0, AX, {}, Col());
  wall(false, 0, 0, AY, {{LY + 4, LY + 9, 3, 7.2f}}, Col());
  wall(false, AX, 0, AY, {{KY + 4, KY + 10, 3, 7.2f}}, Col());
  if (L == 2) wall(false, KX, 0, AY, {{KY + 2, KY + 8, 0, 7.6f}}, Col());   // between the office and the man cave: a wide archway
  wall(true, LY, 0, 14, {}, Col()); wall(false, 14, LY, AY, {{dy0, dy0 + 3, 0, 7.2f}}, Col());
  wall(false, 20, KY, AY, {{dy0, dy0 + 3, 0, 7.2f}}, Col()); wall(true, KY, 20, KX, {}, Col());
  wall(true, BY, 14, 20, {{16.6f, 19.55f, 0, 7.2f}}, Col());   // the bathroom
  window(true, 0, 8, 15, 3, 7.2f, -1); window(true, 0, 24, 29, 3.5f, 6.8f, -1); window(false, 0, LY + 4, LY + 9, 3, 7.2f, -1); window(false, AX, KY + 4, KY + 10, 3, 7.2f, 1);
  if (L == 2) { window(true, 0, 33, 39, 3.5f, 6.8f, -1); window(true, 0, KX + 4, KX + 10, 3, 7.2f, -1); }
  // baseboards
  Col bb = HX("#d8d1bd");
  for (auto &r : std::vector<Rc>{{.25f, .25f, 18, .35f, false}, {.25f, LY - .35f, 13.75f, LY - .25f, false}}) box(r.x0, r.y0, 0, r.x1, r.y1, .35f, bb, 9);
  // holes and cracks in the drywall, room by room, until you pay to fix them
  struct WP { P3 p; P3 n; } wp[] = {{{6, .27f, 2.4f}, {0, 1, 0}}, {{16.5f, .27f, 1.2f}, {0, 1, 0}}, {{.27f, 12.0f, 3.5f}, {1, 0, 0}}, {{11.5f, LY - .27f, 1.6f}, {0, -1, 0}},
    {{13.73f, LY + 9.5f, 2.2f}, {-1, 0, 0}}, {{3.0f, AY - .27f, 4.4f}, {0, -1, 0}}, {{.27f, LY + 2.0f, 2.6f}, {1, 0, 0}},
    {{KX - .27f, 1.5f + DK, 5.6f}, {-1, 0, 0}}, {{20.27f + 0, 4.0f, 1.0f}, {1, 0, 0}}, {{20.9f, .27f, 4.6f}, {0, 1, 0}},
    {{KX - .27f, KY + 1.5f, 4.0f}, {-1, 0, 0}}, {{25.0f + DX, AY - .27f, 1.0f}, {0, -1, 0}}, {{20.27f, AY - 2.0f, 3.0f}, {1, 0, 0}}};
  for (auto &w : wp) { P3 q = w.p + w.n * .6f; int r = homeRoomAt(q.x, q.y); if (r >= HOME_NR || HOME.sel[HS_WALL + r]) continue;
    if (w.p.x > 19.9f && w.p.x < 20.5f && w.p.y < KY) continue;   // (no wall there: the kitchen is open)
    P3 u = std::fabs(w.n.x) > .5f ? P3{0, 1, 0} : P3{1, 0, 0}; float k = wallK(w.p, w.n); Col pc = wallPaint(w.p, w.n);
    auto fan = [&](P3 c, float r, float jag, Col col, float lift, int nseg) {   // an irregular flat shape on the wall
      P3 o = c + w.n * lift; g_curN = w.n; uint32_t cc = Col(std::min(255.f, col.r * k), std::min(255.f, col.g * k), std::min(255.f, col.b * k), 1).pack(); float rr[24];
      for (int i = 0; i < nseg; i++) rr[i] = r * (1 - jag + jag * 2 * frand());
      for (int i = 0; i < nseg; i++) { float a0 = i * 6.2832f / nseg, a1 = (i + 1) * 6.2832f / nseg; vtx(o, cc); vtx(o + u * (std::cos(a0) * rr[i]) + P3{0, 0, std::sin(a0) * rr[i] * .85f}, cc); vtx(o + u * (std::cos(a1) * rr[(i + 1) % nseg]) + P3{0, 0, std::sin(a1) * rr[(i + 1) % nseg] * .85f}, cc); } };
    fan(w.p, .62f, .35f, shade(pc, .18), .012f, 18);                // paint flaking off around it (lighter, chalky)
    fan(w.p, .44f, .3f, HX("#d6cfbd"), .02f, 16);                   // bare drywall paper
    fan(w.p, .27f, .45f, HX("#2a2620"), .028f, 14);                 // the hole itself
    fan(w.p + P3{0, 0, .05f}, .14f, .4f, HX("#14110e"), .032f, 10);
    // a crack wandering off it: a thin jagged line
    { P3 c = w.p; float ang = frand() * 6.2832f; uint32_t cc = Col(60 * k, 52 * k, 42 * k, 1).pack(); g_curN = w.n;
      for (int s = 0; s < 7; s++) { ang += (frand() - .5f) * 1.2f; P3 dir = u * std::cos(ang) + P3{0, 0, std::sin(ang)}, side = u * -std::sin(ang) + P3{0, 0, std::cos(ang)}; float L = .22f + frand() * .18f, t = .018f - s * .002f;
        P3 a = c + dir * (s == 0 ? .3f : 0) + w.n * .02f, b = a + dir * L; vtx(a - side * t, cc); vtx(b - side * t * .7f, cc); vtx(b + side * t * .7f, cc); vtx(a - side * t, cc); vtx(b + side * t * .7f, cc); vtx(a + side * t, cc); c = b - w.n * .02f; } } }
  for (int i = 0; i < 9; i++) { float y = .27f, x = 1 + frand() * 32, z = 1 + frand() * 6; if ((x > 1 && x < 6.2f) || (x > 7 && x < 16) || (x > 23 && x < 30)) z = std::min(z, 2.6f); if (x > 1 && x < 6.2f) continue;
    int r = homeRoomAt(x, 1); if (r >= HOME_NR || HOME.sel[HS_WALL + r]) continue;   // scuffs: soft irregular smudges
    float k = wallK({x, y, z}, {0, 1, 0}); Col sc = shade(wallPaint({x, y, z}, {0, 1, 0}), -.18); uint32_t cc = Col(sc.r * k, sc.g * k, sc.b * k, 1).pack(); g_curN = {0, 1, 0}; float L = .5f + frand(), hgt = .05f + frand() * .06f;
    for (int s = 0; s < 6; s++) { float x0 = x + L * s / 6, x1 = x + L * (s + 1) / 6, h0 = hgt * std::sin(3.1416f * s / 6) + .01f, h1 = hgt * std::sin(3.1416f * (s + 1) / 6) + .01f;
      vtx({x0, y + .01f, z - h0}, cc); vtx({x1, y + .01f, z - h1}, cc); vtx({x1, y + .01f, z + h1}, cc); vtx({x0, y + .01f, z - h0}, cc); vtx({x1, y + .01f, z + h1}, cc); vtx({x0, y + .01f, z + h0}, cc); } }
  // the front door (and its jersey)
  box(2.05f, -.12f, 0, 4.95f, .12f, 7.15f, HX("#6b4a33"), 3, 0); box(4.4f, .14f, 3.3f, 4.6f, .24f, 3.5f, HX("#c8a640")); box(3.3f, -.2f, 5.4f, 3.7f, -.14f, 5.6f, HX("#222"));
  jersey();
  solid(2, -.2f, 5, .3f); HOT.push_back({APT_DOOR, {3.5f, .2f, 3.6f}, 4.5f});
  blob(3.5f, 1.2f, .035f, 1.1f, 0, HX("#5a4a3c"));   // the doormat
  for (float fx : {14.f, 20.f}) { Col tr = HX("#d7d0bd");   // casings: they reach into the opening (no face shared with the wall: no flicker)
    box(fx - WT - .05f, dy0 - .25f, 0, fx + WT + .05f, dy0 + .1f, 7.45f, tr, 9); box(fx - WT - .05f, dy0 + 2.9f, 0, fx + WT + .05f, dy0 + 3.25f, 7.45f, tr, 9);
    box(fx - WT - .05f, dy0 - .25f, 7.0f, fx + WT + .05f, dy0 + 3.25f, 7.45f, tr, 9, 0); }
  { Col tr = HX("#d7d0bd"); box(16.35f, BY - WT - .05f, 0, 16.7f, BY + WT + .05f, 7.45f, tr, 9); box(19.45f, BY - WT - .05f, 0, 19.8f, BY + WT + .05f, 7.45f, tr, 9); box(16.35f, BY - WT - .05f, 7.0f, 19.8f, BY + WT + .05f, 7.45f, tr, 9, 0); }
  // bare bulbs
  for (size_t i = 0; i < bulbs.size(); i++) { const Lamp &Lm = bulbs[i]; box(Lm.p.x - .04f, Lm.p.y - .04f, Lm.p.z + .2f, Lm.p.x + .04f, Lm.p.y + .04f, CEIL, HX("#333")); cyl(Lm.p.x, Lm.p.y, Lm.p.z - .1f, Lm.p.z + .2f, .18f, .12f, bulbOn[i] ? HX("#fff2c2") : HX("#8a877c"), 8, true, bulbOn[i]); }
  // the light switches: a plate by each room's door (X flips it)
  { struct SW { int g; P3 p, n; }; std::vector<SW> sw = {{0, {5.7f, WT, 4.1f}, {0, 1, 0}}, {1, {29.6f + DX * .5f, KY - WT, 4.1f}, {0, -1, 0}}, {2, {14 - WT, dy0 + 3.7f, 4.1f}, {-1, 0, 0}},
      {3, {20 + WT, dy0 + 3.7f, 4.1f}, {1, 0, 0}}, {4, {15.9f, BY + WT, 4.1f}, {0, 1, 0}}};
    if (L == 2) sw.push_back({5, {KX + WT, KY + 8.7f, 4.1f}, {1, 0, 0}});
    for (auto &s : sw) { P3 u = std::fabs(s.n.x) > .5f ? P3{0, 1, 0} : P3{1, 0, 0}, o = s.p + s.n * .03f;
      patch(o, u * .14f, {0, 0, .22f}, HX("#f1ede4"), s.n); bool on = LIT[s.g];
      P3 t = o + s.n * .02f + P3{0, 0, on ? .05f : -.05f}; patch(t, u * .04f, {0, 0, .07f}, on ? HX("#ffffff") : HX("#cfcac0"), s.n);
      HOT.push_back({APT_LIGHT + s.g, s.p + s.n * .1f, 4.5f}); } }
  // ---- living room: the TV wall, the couch, a coffee table, the shelf, the radio, the mess
  entGeo(HOME.sel[HS_ENT]); HOT.push_back({APT_SLOT + HS_ENT, {1.5f, 7, entTop - .3f}, 7.5f});
  // the game console on the entertainment center, right of the TV (and its controller); up close, X plays
  if (HOME.sel[HS_CONSOLE]) { float z = entTop; box(.6f, 8.25f, z, 1.35f, 8.95f, z + .17f, HX("#16181d"), 2); box(1.35f, 8.4f, z + .07f, 1.37f, 8.8f, z + .1f, HX("#38bdf8"), 9, 0, true);
    box(.65f, 8.3f, z + .17f, 1.3f, 8.9f, z + .19f, HX("#2a2e36"), 2); box(1.45f, 7.95f, z, 1.7f, 8.3f, z + .06f, HX("#22252b"), 2); box(1.5f, 8.18f, z + .06f, 1.55f, 8.23f, z + .08f, HX("#ef4444"), 9, 0, true);
    HOT.push_back({APT_CONSOLE, {1.3f, 8.6f, z + .15f}, 6.5f}); }
  HOT.push_back({APT_SLOT + HS_CONSOLE, {1.2f, 8.6f, entTop + .2f}, 7.5f}); tvGeo(HOME.sel[HS_TV]); couchGeo(HOME.sel[HS_COUCH]); HOT.push_back({APT_SLOT + HS_COUCH, {11.8f, 7, 1.6f}, 7.5f});
  if (L >= 1) reclGeo(HOME.sel[HS_RECL]);
  radioGeo();
  Col tb = HX("#5c4a36"); box(6.6f, 5.6f, 1.25f, 8.8f, 8.4f, 1.4f, tb, 3, 0); for (float x : {6.7f, 8.6f}) for (float y : {5.7f, 8.2f}) box(x, y, 0, x + .15f, y + .15f, 1.25f, tb, 9);
  solid(6.6f, 5.6f, 8.8f, 8.4f);
  if (!(HOME.junk & 8)) { box(6.9f, 6.0f, 1.4f, 8.1f, 7.2f, 1.55f, HX("#c4a066")); cyl(8.4f, 7.9f, 1.4f, 2.1f, .1f, .08f, HX("#3b6b3a")); cyl(7.2f, 8.0f, 1.4f, 2.0f, .1f, .08f, HX("#6b4a2a")); cyl(16.2f, 9.5f, 0, .1f, .35f, .1f, HX("#3b6b3a"));
    blob(14.6f, 6.2f, 0, .9f, .3f, HX("#4d566b")); blob(15.2f, 7.4f, 0, .7f, .25f, HX("#6b5d50")); blob(14.2f, 8.5f, 0, .6f, .2f, HX("#3e4a5c"));   // laundry heaped by the couch
    HOT.push_back({APT_JUNK + 3, {14.8f, 7.2f, .3f}, 7}); }
  shelfGeo();
  if (!(HOME.junk & 2)) { box(16.4f, .5f, 0, 17.6f, 1.6f, 1.5f, HX("#24302a")); box(17.0f, 1.8f, 0, 17.9f, 2.9f, 1.3f, HX("#2a352e")); solid(16.3f, .4f, 18, 3); HOT.push_back({APT_JUNK + 1, {17.2f, 1.7f, 1.2f}, 8}); }   // trash bags by the kitchen
  if (!(HOME.junk & 1)) { box(14.5f, LY - 2.5f, 0, 16.3f, LY - .6f, 1.6f, HX("#a07a4a")); box(14.8f, LY - 2.2f, 1.6f, 15.9f, LY - .9f, 2.6f, HX("#93703f")); solid(14.4f, LY - 2.6f, 16.4f, LY - .5f); HOT.push_back({APT_JUNK + 0, {15.4f, LY - 1.6f, 1.8f}, 8}); }   // moving boxes
  // ---- kitchen: base cabinets and counters along the east and back walls, upper cabinets, fridge, stove, sink, table
  Col cab = L == 2 ? HX("#3d4a5a") : HX("#8d7a5a"), ct = L == 2 ? HX("#e9e6df") : HX("#8a8478"); const float EX = 31.5f + DX, KB = KY - .25f;
  box(EX, 1.0f, 0, KX - .25f, KB, 3.0f, cab); box(EX - .15f, .9f, 3.0f, KX - .25f, KB, 3.15f, ct, 3, 0); solid(EX - .1f, .9f, KX, KY);
  box(22.6f, KB - 2.25f, 0, EX, KB, 3.0f, cab); box(22.5f, KB - 2.4f, 3.0f, EX, KB, 3.15f, ct, 3, 0); solid(22.5f, KB - 2.45f, EX, KY);
  for (int i = 0; i < 6; i++) { float y = 1.2f + i * 1.75f; if (y + 1.6f < KB - .1f) box(EX - .05f, y, .3f, EX + .02f, y + 1.6f, 2.7f, vary(L == 2 ? HX("#4a5868") : HX("#9a8664"), .05f)); }
  for (float x = 22.8f; x + 1.6f < EX; x += 1.75f) box(x, KB - 2.3f, .3f, x + 1.6f, KB - 2.23f, 2.7f, vary(L == 2 ? HX("#4a5868") : HX("#9a8664"), .05f));
  box(EX + 1, 1.0f, 5.0f, KX - .25f, KB, 7.6f, cab); box(22.6f, KB - .95f, 5.0f, EX, KB, 7.6f, cab);
  if (L < 2) box(EX + .92f, 1.2f, 5.6f, EX + 1.0f, 1.4f, 6.2f, HX("#a9a9a9"));   // a cabinet door hanging open
  box(20.3f, KB - 2.45f, 0, 22.4f, KB, 6.2f, L == 2 ? HX("#c9ccd0") : HX("#d4d0c2")); box(20.25f, KB - 2.15f, 3.6f, 20.32f, KB - 2.0f, 5.0f, HX("#9a9a9a")); solid(20.2f, KB - 2.55f, 22.5f, KY);   // fridge
  box(EX, 4.2f, 3.15f, EX + 2.1f, 6.6f, 3.2f, HX("#1d1d1f")); for (int i = 0; i < 4; i++) cyl(EX + .6f + (i % 2) * .9f, 4.8f + (i / 2) * 1.2f, 3.2f, 3.22f, .3f, .3f, HX("#3a3a3a"));
  box(EX - .15f, 4.2f, 3.6f, EX, 6.6f, 3.75f, HX("#2a2a2a"));
  box(26.0f, KB - 1.95f, 2.6f, 28.4f, KB - .55f, 3.16f, HX("#5d6166"), 9, 0); cyl(27.2f, KB - .35f, 3.15f, 4.0f, .06f, .05f, HX("#b0b0b0"));
  if (!(HOME.junk & 16)) for (int i = 0; i < 4; i++) cyl(26.6f + i * .35f, KB - 1.45f, 3.16f, 3.4f + i * .05f, .25f, .25f, vary(HX("#d8d8d0"), .1f));   // dishes piled up
  if (!(HOME.junk & 16)) HOT.push_back({APT_JUNK + 4, {27.2f, KB - 1.2f, 3.4f}, 7});
  Col tt = HX("#7a6a52"); box(23.0f, 3.0f, 2.4f, 26.5f, 6.0f, 2.55f, tt, 3, 0); for (float x : {23.1f, 26.3f}) for (float y : {3.1f, 5.8f}) box(x, y, 0, x + .1f, y + .1f, 2.4f, tt, 9);
  for (float y : {2.2f, 6.2f}) { Col ch = HX("#5a5a5e"); bool s = y < 4; box(24.2f, y, 1.5f, 25.4f, y + .9f, 1.6f, ch); box(24.2f, s ? y : y + .8f, 1.6f, 25.4f, s ? y + .1f : y + .9f, 3.3f, ch);   // chairs: seat, back
    for (float lx : {24.25f, 25.27f}) for (float ly : {y + .05f, y + .77f}) box(lx, ly, 0, lx + .08f, ly + .08f, 1.5f, HX("#3d3d40"), 9); }   // and four legs each
  solid(23.0f, 2.2f, 26.5f, 7.1f);
  // the counter: up to four small appliances, and the spot to look at in build mode
  { const float ys[HOME_NCTR] = {1.8f, 3.3f, 7.6f, 9.3f}; for (int k = 0; k < HOME_NCTR; k++) if (HOME.ctr[k] >= 0 && ys[k] + .8f < KB) ctrItem(HOME.ctr[k], EX + 1.0f, ys[k], 3.15f);
    HOT.push_back({APT_COUNTER, {EX + .9f, 3.0f, 3.4f}, 14}); }
  if (L >= 1) isleGeo(HOME.sel[HS_ISLE]);
  // ---- bedroom: the bed, a dresser, clothes
  bedGeo(HOME.sel[HS_BED]);
  box(9.5f, 24.4f + DY, 0, 13.5f, 25.75f + DY, 3.2f, HX("#6e5a44")); box(9.6f, 24.3f + DY, 2.2f, 13.4f, 24.4f + DY, 3.0f, HX("#5a4936")); solid(9.5f, 24.3f + DY, 13.5f, 25.8f + DY);
  box(7.3f, 24.4f + DY, 0, 8.4f, 25.6f + DY, 1.1f, HX("#2f5a9a")); cyl(7.85f, 25.0f + DY, 1.1f, 2.0f, .25f, .15f, HX("#e9e2c8"));
  if (!(HOME.junk & 8)) for (int i = 0; i < 4; i++) blob(4 + i * 1.9f, LY + 2 + (i & 1) * .9f, 0, .55f + frand() * .3f, .18f, vary(HX("#6b5a62"), .15f));   // clothes on the floor
  // ---- the bathroom at the end of the hall
  bathGeo(L);
  // ---- office: a folding table, the computer and its chair, a sagging bookshelf, boxes
  Col ft = HX("#8a8a84"); const float OX = 28.5f + DX, OY = 23.4f + DY;
  box(OX, OY, 2.4f, OX + 5, OY + 2.2f, 2.5f, ft, 3, 0); for (float x : {OX + .1f, OX + 4.8f}) for (float y : {OY + .1f, OY + 2.0f}) box(x, y, 0, x + .08f, y + .08f, 2.4f, HX("#444"), 9);
  solid(OX, OY, OX + 5, OY + 2.2f); box(OX + 1.8f, OY + .9f, 2.5f, OX + 3.4f, OY + 2.1f, 3.8f, HX("#c9c3b0")); box(OX + 1.95f, OY + .85f, 2.75f, OX + 3.25f, OY + .9f, 3.6f, HX("#2b5d8a"), 9, 0, true);
  box(OX + 2.0f, OY + .3f, 2.5f, OX + 3.2f, OY + .7f, 2.56f, HX("#d6d0bf"));   // keyboard
  HOT.push_back({APT_PC, {OX + 2.6f, OY + .85f, 3.2f}, 7});
  // the chair, facing the desk: its back on the far (south) side, away from the screen
  box(OX + 1.5f, OY - 1.8f, 1.5f, OX + 2.9f, OY - .5f, 1.6f, HX("#55555a")); box(OX + 1.5f, OY - 1.8f, 1.6f, OX + 2.9f, OY - 1.7f, 3.4f, HX("#55555a")); for (float x : {OX + 1.6f, OX + 2.7f}) for (float y : {OY - 1.7f, OY - .7f}) box(x, y, 0, x + .07f, y + .07f, 1.5f, HX("#333"), 9);
  box(22.0f, KY + .25f, 0, 26.0f, KY + 1.15f, 6.0f, HX("#6a5236")); for (int s = 0; s < 4; s++) { float z = .4f + s * 1.45f; for (float x = 22.2f; x < 25.6f; x += .25f + frand() * .2f) if (frand() < .7f) box(x, KY + 1.15f, z, x + .18f, KY + 1.17f, z + .7f + frand() * .3f, vary(HX("#8a4a3a"), .6f)); }   // the bookshelf (backs of the books)
  solid(21.9f, KY + .2f, 26.1f, KY + 1.2f);
  if (!(HOME.junk & 4)) { box(22.0f, 24.0f + DY, 0, 24.2f, 25.7f + DY, 1.8f, HX("#a07a4a")); box(22.3f, 24.3f + DY, 1.8f, 23.8f, 25.5f + DY, 3.0f, HX("#93703f")); solid(21.9f, 23.9f + DY, 24.3f, 25.8f + DY); HOT.push_back({APT_JUNK + 2, {23.1f, 24.8f + DY, 1.8f}, 8}); }
  // ---- the penthouse's man cave
  if (L == 2) caveGeo();
  // the GPU keeps it until something changes
  aptVer++; aptOk = true;
}

// ---------------------------------------------------------------- you
static struct { double x = 3.5, y = 2.4, yaw = .85, pitch = -.05; bool set = false, sit = false; double sitT = 0; float lx = 0, ly = 0; int tid = -1; float tx0 = 0, ty0 = 0; bool tLook = false; } Me;
bool aptBuild = false;
static void collide(double &x, double &y);
void aptReset() { Me.x = 3.5; Me.y = 2.6; Me.yaw = .85; Me.pitch = -.05; Me.set = true; Me.sit = false; }
// after a game you're on the couch (looking at the TV); X stands you up in front of it
void aptSit() { Me.x = 11.7; Me.y = 7.0; Me.yaw = 3.14159; Me.pitch = -.08; Me.set = true; Me.sit = true; Me.sitT = 0; }
bool aptSitting() { return Me.sit; }
void aptStand() { if (!Me.sit) return; Me.sit = false; Me.sitT = 1; Me.x = 9.6; Me.y = 4.6; Me.yaw = 3.14159 * .75; collide(Me.x, Me.y); }
void aptView(double x, double y, double yaw, double pitch) { Me.x = x; Me.y = y; Me.yaw = yaw; Me.pitch = pitch; Me.set = true; }
static const double EYE = 5.4, SEYE = 3.9, RAD = .9;
static void doorRects(std::vector<Rc> &v);
static void collide(double &x, double &y) {
  x = std::max(WT + RAD, std::min(AX - WT - RAD, x)); y = std::max(WT + RAD, std::min(AY - WT - RAD, y));
  static std::vector<Rc> all; all = COL; doorRects(all);
  for (int it = 0; it < 2; it++) for (auto &r : all) { double cx = std::max((double)r.x0, std::min(x, (double)r.x1)), cy = std::max((double)r.y0, std::min(y, (double)r.y1)), dx = x - cx, dy = y - cy, d2 = dx * dx + dy * dy;
    if (d2 >= RAD * RAD) continue;
    if (d2 < 1e-8) { double pl = x - r.x0, pr = r.x1 - x, pb = y - r.y0, pt = r.y1 - y, m = std::min(std::min(pl, pr), std::min(pb, pt)); if (m == pl) x = r.x0 - RAD; else if (m == pr) x = r.x1 + RAD; else if (m == pb) y = r.y0 - RAD; else y = r.y1 + RAD; continue; }
    double d = std::sqrt(d2), k = (RAD - d) / d; x += dx * k; y += dy * k; }
}

// ---------------------------------------------------------------- the hallway doors: they swing into the room and close behind you

static P3 doorDir(const HDoor &d) { double th = d.a * 1.55; return dShut(d) * (float)std::cos(th) + dOpen(d) * (float)std::sin(th); }   // along the slab, hinge to latch
static Rc doorShutRc(const HDoor &d, float t) { P3 h = {d.hx, d.hy, 0}, c = dShut(d), o = dOpen(d), a = h + o * t, b = h - o * t + c * DW;
  return {std::min(a.x, b.x), std::min(a.y, b.y), std::max(a.x, b.x), std::max(a.y, b.y), false}; }
static P3 doorMid(const HDoor &d) { P3 u = doorDir(d); return {d.hx + u.x * DW / 2, d.hy + u.y * DW / 2, 3.6f}; }
bool aptDoorOpen(int i) { return i >= 0 && i < APT_NHD && HD[i].tgt > .5; }
void aptDoor(int i) { if (i < 0 || i >= APT_NHD) return; HDoor &d = HD[i]; d.tgt = d.tgt > .5 ? 0 : 1; d.hold = 4.5; }
static bool inSwing(const HDoor &d, double x, double y) { P3 c = dShut(d), o = dOpen(d); double px = x - d.hx, py = y - d.hy, al = px * c.x + py * c.y - DW / 2, pe = px * o.x + py * o.y;
  return std::fabs(al) < DW / 2 + RAD && pe > -RAD - .4 && pe < DW + RAD; }
static void doorsTick(double dt) {
  for (auto &d : HD) {
    if (d.tgt > .5 && d.a > .99) { d.hold -= dt; if (d.hold <= 0) { if (inSwing(d, Me.x, Me.y)) d.hold = .5; else d.tgt = 0; } }   // it waits for you to clear the swing
    double sp = 1.6 * dt; if (d.tgt > d.a) d.a = std::min(d.tgt, d.a + sp); else if (d.tgt < d.a) { if (d.a < .99 || !inSwing(d, Me.x, Me.y)) d.a = std::max(d.tgt, d.a - sp); }
  }
}
// solid while shut; once open, the slab against its swing
static void doorRects(std::vector<Rc> &v) {
  for (auto &d : HD) { if (d.a < .15) v.push_back(doorShutRc(d, .12f));
    else if (d.a > .9) { P3 u = doorDir(d); float x1 = d.hx + u.x * DW, y1 = d.hy + u.y * DW; v.push_back({std::min(d.hx, x1) - .08f, std::min(d.hy, y1) - .08f, std::max(d.hx, x1) + .08f, std::max(d.hy, y1) + .08f, false}); } }
}
static void obox(P3 o, P3 u, P3 v, float lu, float lv, float z0, float z1, Col c) {   // a box along u (length lu) and v (thickness lv, centred)
  P3 a = o - v * (lv / 2), b = a + u * lu, cc = b + v * lv, dd = a + v * lv; P3 z = {0, 0, z1 - z0}; a.z = b.z = cc.z = dd.z = z0;
  P3 nv = v * -1;
  quad(a, b, b + z, a + z, c, nv, 9); quad(cc, dd, dd + z, cc + z, c, v, 9); quad(b, cc, cc + z, b + z, c, u, 9); quad(dd, a, a + z, dd + z, c, u * -1, 9);
  quad(a + z, b + z, cc + z, dd + z, c, {0, 0, 1}, 9);
}
static void doorTris() {
  DY.clear(); OUT = &DY;
  for (auto &d : HD) { P3 u = doorDir(d), v = {-u.y, u.x, 0}, h = {d.hx, d.hy, 0};
    obox(h + u * .02f, u, v, DW, DT, 0, DH, HX("#e6dfcf"));
    for (float k : {-1.f, 1.f}) obox(h + u * (DW - .45f) + v * (k * (DT / 2 + .06f)), u, v, .14f, .12f, 3.2f, 3.4f, HX("#b8b8b8"));   // the knobs
  }
  OUT = &AG;
}
void aptMove(const Pad &pad, const Touch &touch, double dt) {
  if (!aptLoaded) return;   // not loaded: the loading screen builds it
  if (!aptOk) build();
  auto ax = [](int v) { double a = (v - 128) / 127.0; return std::fabs(a) < .18 ? 0.0 : (a - (a > 0 ? .18 : -.18)) / .82; };
  double mx = ax(pad.lx), my = -ax(pad.ly), lx = ax(pad.rx), ly = -ax(pad.ry);
  if (pad.btn & B_UP) my = 1; if (pad.btn & B_DOWN) my = -1; if (pad.btn & B_RIGHT) mx = 1;
  // touch: the left half is a stick to walk, the right half drags the view
  bool lt = false; for (int i = 0; i < touch.n; i++) { const TouchPt &p = touch.p[i];
    if (p.id != Me.tid) { Me.tid = p.id; Me.tx0 = p.x; Me.ty0 = p.y; Me.tLook = p.x > W / 2; Me.lx = p.x; Me.ly = p.y; }
    if (Me.tLook) { Me.yaw -= (p.x - Me.lx) * .006; Me.pitch -= (p.y - Me.ly) * .005; Me.lx = p.x; Me.ly = p.y; }
    else { mx = std::max(-1.0, std::min(1.0, (p.x - Me.tx0) / (.12 * U))); my = std::max(-1.0, std::min(1.0, -(p.y - Me.ty0) / (.12 * U))); }
    lt = true; break; }
  if (!lt) Me.tid = -1;
  Me.yaw -= lx * 2.3 * dt; Me.pitch = std::max(-1.2, std::min(1.1, Me.pitch + ly * 1.6 * dt));
  if (Me.sit) { Me.yaw = std::max(3.14159 * .55, std::min(3.14159 * 1.45, Me.yaw)); doorsTick(dt); return; }   // seated: look around, no walking
  if (Me.sitT > 0) Me.sitT = std::max(0.0, Me.sitT - dt * 2.5);   // getting up
  double sp = 7.5 * dt, fx = std::cos(Me.yaw), fy = std::sin(Me.yaw);
  double nx = Me.x + (fx * my + fy * mx) * sp, ny = Me.y + (fy * my - fx * mx) * sp; collide(nx, ny); Me.x = nx; Me.y = ny;
  doorsTick(dt);
}

// ---------------------------------------------------------------- the camera and the draw
static struct { P3 e, f, r, u; double F, sx, sy; } AC;
static void camSet() {
  if (!Me.set) aptReset();
  AC.e = {(float)Me.x, (float)Me.y, (float)(Me.sit ? SEYE : EYE - (EYE - SEYE) * Me.sitT)};
  AC.f = {(float)(std::cos(Me.yaw) * std::cos(Me.pitch)), (float)(std::sin(Me.yaw) * std::cos(Me.pitch)), (float)std::sin(Me.pitch)};
  AC.r = nrm3(cross3(AC.f, {0, 0, 1})); AC.u = cross3(AC.r, AC.f);
  AC.F = W / 2 / std::tan(36 * 3.14159 / 180); AC.sx = W / 2; AC.sy = H / 2;
}
int aptLook() {
  if (!aptLoaded) return APT_NONE; if (!aptOk) build(); camSet(); int best = APT_NONE; double bc = .9;
  auto seen = [&](P3 p, bool door) {   // nothing but air (no wall, no shut door) between your eyes and it
    std::vector<Rc> W2; for (auto &r : COL) if (r.wall) W2.push_back(r); if (!door) for (auto &d : HD) if (d.a < .15) { Rc r = doorShutRc(d, .1f); r.wall = true; W2.push_back(r); }
    double x0 = AC.e.x, y0 = AC.e.y, dx = p.x - x0, dy = p.y - y0;
    for (auto &r : W2) { double t0 = 0, t1 = .92; auto slab = [&](double o, double dd, double lo, double hi) { if (std::fabs(dd) < 1e-9) return o > lo && o < hi; double a = (lo - o) / dd, b = (hi - o) / dd; if (a > b) std::swap(a, b); t0 = std::max(t0, a); t1 = std::min(t1, b); return t0 < t1; };
      if (slab(x0, dx, r.x0 + .02, r.x1 - .02) && slab(y0, dy, r.y0 + .02, r.y1 - .02)) return false; }
    return true; };
  std::vector<Hot> hs = HOT; for (int i = 0; i < APT_NHD; i++) { P3 m = doorMid(HD[i]); m.z = 4.6f; hs.push_back({APT_HDOOR + i, m, 6}); }
  for (auto &h : hs) { if (!aptBuild && (h.id >= APT_SLOT || h.id == APT_COUNTER)) continue;
    P3 d = h.p - AC.e; double dl = std::sqrt(dot3(d, d)); if (dl > h.r) continue; double c = dot3(d, AC.f) / std::max(.1, dl), need = dl < 4.5 ? .78 : .9;
    if (c > need && c - need > bc - .9 && seen(h.p, h.id >= APT_HDOOR && h.id < APT_HDOOR + APT_NHD)) { bc = c - need + .9; best = h.id; } }
  if (best != APT_NONE || !aptBuild) return best;
  // build mode: the floor you look down at, or the wall in front of you (drywall first, then paint), room by room
  if (AC.f.z < -.45f) { double t = -AC.e.z / AC.f.z, fx = AC.e.x + AC.f.x * t, fy = AC.e.y + AC.f.y * t; if (t < 14) { int r = homeRoomAt(fx, fy); return r < HOME_NR ? APT_SLOT + HS_FLOOR + r : APT_NONE; } }
  if (std::fabs(AC.f.z) < .5f) {   // the nearest wall along the view
    double x0 = AC.e.x, y0 = AC.e.y, dx = AC.f.x, dy = AC.f.y, bt = 1e9;
    for (auto &r : COL) { if (!r.wall) continue; double t0 = 0, t1 = 12; auto slab = [&](double o, double dd, double lo, double hi) { if (std::fabs(dd) < 1e-9) return o > lo && o < hi; double a = (lo - o) / dd, b = (hi - o) / dd; if (a > b) std::swap(a, b); t0 = std::max(t0, a); t1 = std::min(t1, b); return t0 < t1; };
      if (slab(x0, dx, r.x0, r.x1) && slab(y0, dy, r.y0, r.y1) && t0 < bt) bt = t0; }   // (close enough to touch it: about two steps)
    if (bt < 7.5) { int rm = homeRoomAt(x0, y0); if (rm == ROOM_BATH) return APT_SLOT + HS_BPAINT; if (rm == ROOM_CAVE) return HOME.lvl >= 2 ? APT_SLOT + HS_CPAINT : APT_NONE; if (rm >= HOME_NR) return APT_NONE; return APT_SLOT + (HOME.sel[HS_WALL + rm] ? HS_PAINT : HS_WALL) + rm; }
  }
  return best;
}
static const double NEAR = .25, FAR = 150;
struct T2 { float x[3], y[3], d; uint32_t c; }; static std::vector<T2> Q;   // the no-GPU path's sorted triangles
// the grain: 128 x 128, tiles seamlessly - soft blotches (a roller's stipple) and a fine speckle, all near white
static void grainTex() {
  static bool made = false; if (made) return; made = true; const int N = 128; std::vector<unsigned char> t((size_t)N * N * 4); uint32_t s = 12345;
  auto R = [&]() { s = s * 1664525u + 1013904223u; return (s >> 8) / 16777216.f; };
  float lat[16][16]; for (auto &r : lat) for (float &v : r) v = R();
  auto vn = [&](float x, float y) { int x0 = (int)std::floor(x), y0 = (int)std::floor(y); float fx = x - x0, fy = y - y0; fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
    auto L = [&](int i, int j) { return lat[(j % 16 + 16) % 16][(i % 16 + 16) % 16]; }; return (L(x0, y0) * (1 - fx) + L(x0 + 1, y0) * fx) * (1 - fy) + (L(x0, y0 + 1) * (1 - fx) + L(x0 + 1, y0 + 1) * fx) * fy; };
  for (int y = 0; y < N; y++) for (int x = 0; x < N; x++) { float u = x * 16.f / N, v = y * 16.f / N, n = vn(u, v) * .6f + vn(u * 2, v * 2) * .4f;   // (16 lattice cells across: periodic)
    float g = 236 + 14 * n + (R() - .5f) * 10; g = std::max(200.f, std::min(255.f, g)); unsigned char c = (unsigned char)g; size_t i = ((size_t)y * N + x) * 4; t[i] = t[i + 1] = t[i + 2] = c; t[i + 3] = 255; }
  plat_tex(7, N, N, t.data());
}
bool aptReady() { return aptLoaded; }
void aptLoad() { if (!aptOk) build(); aptLoaded = true; }
void aptUnload() {
  plat_draw3d_free((const void *)&AG); std::vector<V3c>().swap(AG); std::vector<Rc>().swap(COL); std::vector<Hot>().swap(HOT); std::vector<T2>().swap(Q); std::vector<V3c>().swap(DY); aptOk = aptLoaded = false; for (auto &d : HD) { d.a = d.tgt = 0; }
}
static void clipM(float *m) {
  const double n = NEAR, f = FAR, A = 2 * AC.F / W, B = 2 * AC.sx / W - 1, Cc = 2 * AC.F / H, D = 1 - 2 * AC.sy / H, E = (f + n) / (f - n), G = -2 * f * n / (f - n);
  const P3 R = AC.r, Uu = AC.u, Fw = AC.f, e = AC.e;
  double rows[4][4] = {{A * R.x + B * Fw.x, A * R.y + B * Fw.y, A * R.z + B * Fw.z, -A * dot3(R, e) - B * dot3(Fw, e)},
    {Cc * Uu.x + D * Fw.x, Cc * Uu.y + D * Fw.y, Cc * Uu.z + D * Fw.z, -Cc * dot3(Uu, e) - D * dot3(Fw, e)},
    {E * Fw.x, E * Fw.y, E * Fw.z, -E * dot3(Fw, e) + G}, {Fw.x, Fw.y, Fw.z, -dot3(Fw, e)}};
  for (int c = 0; c < 4; c++) for (int r = 0; r < 4; r++) m[c * 4 + r] = (float)rows[r][c];
}
void aptDraw() {
  if (CR && aptOk && jerseyTeam != C.me) aptOk = false;   // traded: a new jersey on the door
  if (!aptLoaded) return; if (!aptOk) build(); camSet();
  ctx.fill("#1a1712"); ctx.fillRect(0, 0, W, H); ctx.flush();
  doorTris();
  if (plat_gpu3d()) { grainTex(); float M[16]; clipM(M); plat_draw3d_static(M, (const void *)&AG, AG.data(), (int)AG.size(), 0, 7, aptVer); plat_draw3d(M, DY.data(), (int)DY.size(), 0, 7); return; }
  // no GPU 3D (the vita2d build): clip at the near plane, project, sort back to front
  Q.clear();
  for (const std::vector<V3c> *L : {&AG, &DY}) for (size_t i = 0; i + 2 < L->size(); i += 3) { const std::vector<V3c> &G = *L;
    P3 cam[3]; for (int k = 0; k < 3; k++) { P3 p = {G[i + k].x, G[i + k].y, G[i + k].z}, v = p - AC.e; cam[k] = {dot3(v, AC.r), dot3(v, AC.u), dot3(v, AC.f)}; }
    P3 out[6]; int no = 0; for (int k = 0; k < 3; k++) { P3 a = cam[k], b = cam[(k + 1) % 3]; float da = a.z - (float)NEAR, db = b.z - (float)NEAR; if (da >= 0) out[no++] = a; if ((da >= 0) != (db >= 0)) out[no++] = a + (b - a) * (da / (da - db)); }
    if (no < 3) continue; float dz = 0; for (int k = 0; k < no; k++) dz = std::max(dz, out[k].z);
    for (int k = 1; k + 1 < no; k++) { T2 t; P3 q[3] = {out[0], out[k], out[k + 1]}; for (int m = 0; m < 3; m++) { t.x[m] = (float)(AC.sx + q[m].x / q[m].z * AC.F); t.y[m] = (float)(AC.sy - q[m].y / q[m].z * AC.F); } t.d = dz; t.c = G[i].c; Q.push_back(t); } }
  std::sort(Q.begin(), Q.end(), [](const T2 &a, const T2 &b) { return a.d > b.d; });
  for (auto &t : Q) ctx.rawTri(t.x[0], t.y[0], t.x[1], t.y[1], t.x[2], t.y[2], t.c);
}
void aptHUD() {
  int lk = aptLook(); bool hot = lk != APT_NONE;
  ctx.fill(hot ? rgba(255, 213, 74, .95) : rgba(255, 255, 255, .7)); ctx.oval(W / 2, H / 2, hot ? 5 : 3, hot ? 5 : 3);
}
const char *APT_JUNKN[APT_NJUNK] = {"THE MOVING BOXES", "THE TRASH BAGS", "THE OFFICE BOXES", "THE LAUNDRY AND PIZZA BOXES", "THE DIRTY DISHES"};
void aptThrow(int bit) { if (bit < 0 || bit >= APT_NJUNK) return; HOME.junk |= 1 << bit; if (CR) proSave(); aptDirty(); }
#undef C
int aptTris() { if (!aptOk) build(); return (int)AG.size() / 3; }
void aptPos(double &x, double &y) { x = Me.x; y = Me.y; }

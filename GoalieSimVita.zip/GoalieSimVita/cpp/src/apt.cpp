// CHL 2026 native - BE A PRO: the apartment. A real-sized one-bedroom-plus-office (34 x 26 ft, 9 ft ceilings):
// living room and an open kitchen along the front, a hall to the bedroom and the office. Built from lit, vertex-
// coloured boxes (feet: x east, y north, z up), drawn by the GPU in one static batch, walked in first person.
#include "apt.h"
#include "pro.h"
#include "json.h"
#include <algorithm>
#include <cmath>

#define C (*CR)
// ---------------------------------------------------------------- what you can buy, and the file it lives in
const char *HOME_CAT[HOME_NC] = {"FLOORING", "COUCH", "TV", "ENTERTAINMENT CENTER"};
const HomeOpt HOME_OPT[HOME_NC][HOME_NO] = {
  {{"WORN CARPET", 0, "Stained, flattened, smells like the last tenant."}, {"VINYL PLANK", 600, "Clean grey-oak planks. Wipes right up."},
   {"OAK HARDWOOD", 2000, "Real wood, warm and narrow-planked."}, {"MARBLE TILE", 6000, "Polished white marble with grey veins."}},
  {{"CURBSIDE FUTON", 0, "Found it on the curb. Sags in the middle."}, {"THRIFT STORE SOFA", 250, "A brown three-seater with all its springs."},
   {"LEATHER SECTIONAL", 1400, "Dark leather L with a chaise for film study."}, {"DESIGNER MODULAR", 5000, "Low, deep, pale-grey modules and bright pillows."}},
  {{"OLD CRT", 0, "Twenty-inch tube. The picture rolls."}, {"40\" LED", 300, "A thin flat screen. Finally."},
   {"65\" 4K", 1100, "Big, sharp and bright."}, {"85\" OLED", 4000, "Wall-sized and paper thin."}},
  {{"MILK CRATES", 0, "Two crates and a plank."}, {"PARTICLE BOARD STAND", 150, "Black, flat-packed, a little wobbly."},
   {"OAK MEDIA CONSOLE", 800, "Solid oak with drawers for the games."}, {"FLOATING WALNUT UNIT", 3000, "Wall-mounted walnut with a glowing light strip."}}};
Home HOME;
J homeToJ() { J o = J::obj(), s = J::arr(), w = J::arr(); for (int c = 0; c < HOME_NC; c++) { s.push(HOME.sel[c]); w.push(HOME.own[c]); } o["sel"] = s; o["own"] = w; o["junk"] = HOME.junk; return o; }
void homeFromJ(const J &o) {
  HOME = Home(); aptUnload(); if (!o.isObj()) return;
  auto at = [&](const char *k, int c, int d) { const J &a = o(k); return a.isArr() && (size_t)c < a.a.size() ? a.a[(size_t)c].i(d) : d; };
  for (int c = 0; c < HOME_NC; c++) { HOME.sel[c] = std::max(0, std::min(HOME_NO - 1, at("sel", c, 0))); HOME.own[c] = at("own", c, 1) | 1; if (!(HOME.own[c] >> HOME.sel[c] & 1)) HOME.sel[c] = 0; }
  HOME.junk = o("junk").i();
}
bool homeTestMade() { std::string s; if (!plat_read_file(plat_data_dir() + "chl_home.json", s) || s.empty()) return false; J o = J::parse(s); return o.isObj() && o("testMade").truthy(); }
void homeSetTestMade() { J o = J::obj(); o["testMade"] = true; plat_write_file(plat_data_dir() + "chl_home.json", o.dump()); }
int homeBuy(int cat, int i) {
  if (cat < 0 || cat >= HOME_NC || i < 0 || i >= HOME_NO) return 0;
  if (HOME.own[cat] >> i & 1) { HOME.sel[cat] = i; if (CR) proSave(); aptDirty(); return 2; }
  if (!CR || C.money < HOME_OPT[cat][i].c) return 0;
  C.money -= HOME_OPT[cat][i].c; HOME.own[cat] |= 1 << i; HOME.sel[cat] = i; proSave(); aptDirty(); return 1;
}

// ---------------------------------------------------------------- geometry
struct P3 { float x, y, z; };
static inline P3 operator+(P3 a, P3 b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
static inline P3 operator-(P3 a, P3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static inline P3 operator*(P3 a, float k) { return {a.x * k, a.y * k, a.z * k}; }
static inline float dot3(P3 a, P3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static inline P3 cross3(P3 a, P3 b) { return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
static inline P3 nrm3(P3 a) { float l = std::sqrt(dot3(a, a)); return l > 1e-6f ? a * (1 / l) : P3{0, 0, 1}; }
static std::vector<V3c> AG;                       // the world, ready for the GPU
static uint32_t aptVer = 1; static bool aptOk = false, aptLoaded = false;   // ok: geometry current; loaded: in memory (between the loading screen and the next game)
struct Rc { float x0, y0, x1, y1; bool wall = false; }; static std::vector<Rc> COL;     // what you bump into
struct Hot { int id; P3 p; float r; }; static std::vector<Hot> HOT;  // what you can look at and use
struct Lamp { P3 p; float k; }; static std::vector<Lamp> LAMPS;
static const float CEIL = 9, WT = .25f, AX = 34, AY = 26;
void aptDirty() { aptOk = false; }
static uint32_t sd = 1; static float frand() { sd = sd * 1664525u + 1013904223u; return (sd >> 8) / 16777216.f; }
// light at a point on a surface: a dim warm ambient, daylight from the south windows, the ceiling bulbs
static Col litAt(Col c, P3 p, P3 n) {
  float l = .44f + .12f * std::max(0.f, n.z) + .14f * std::max(0.f, -n.y) * std::max(0.f, 1 - p.y / 16) + .05f * std::fabs(n.x);
  for (auto &L : LAMPS) { P3 d = L.p - p; float d2 = dot3(d, d), dl = std::sqrt(d2) + 1e-4f; float nd = std::max(0.f, dot3(n, d * (1 / dl))); l += L.k * (.25f + .75f * nd) / (1 + d2 * .016f); }
  l = std::min(l, 1.3f);
  return Col(std::min(255.f, c.r * l * 1.02f), std::min(255.f, c.g * l * .97f), std::min(255.f, c.b * l * .88f), 1);
}
static std::vector<V3c> DY, *OUT = &AG;   // DY: what moves (the hallway doors), rebuilt each frame
static void vtx(P3 p, uint32_t c) { V3c v; v.x = p.x; v.y = p.y; v.z = p.z; v.c = c; v.u = v.v = 0; OUT->push_back(v); }
// a flat quad a-b-c-d with normal n, split into tiles so the light falls off smoothly across it; glow: unlit
static void quad(P3 a, P3 b, P3 c, P3 d, Col col, P3 n, float tile = 3, bool glow = false) {
  float lu = std::sqrt(dot3(b - a, b - a)), lv = std::sqrt(dot3(d - a, d - a)); int nu = std::max(1, std::min(10, (int)std::ceil(lu / tile))), nv = std::max(1, std::min(10, (int)std::ceil(lv / tile)));
  if (glow) nu = nv = 1;
  auto at = [&](float u, float v) { P3 p = a + (b - a) * u + (d - a) * v + (c - b - (d - a)) * (u * v); return p; };
  for (int i = 0; i < nu; i++) for (int j = 0; j < nv; j++) {
    P3 q[4] = {at((float)i / nu, (float)j / nv), at((float)(i + 1) / nu, (float)j / nv), at((float)(i + 1) / nu, (float)(j + 1) / nv), at((float)i / nu, (float)(j + 1) / nv)};
    uint32_t k[4]; for (int m = 0; m < 4; m++) k[m] = glow ? col.pack() : litAt(col, q[m], n).pack();
    vtx(q[0], k[0]); vtx(q[1], k[1]); vtx(q[2], k[2]); vtx(q[0], k[0]); vtx(q[2], k[2]); vtx(q[3], k[3]); }
}
// a box; skip bit 1 drops the bottom (anything on the floor)
static void box(float x0, float y0, float z0, float x1, float y1, float z1, Col c, float tile = 3, int skip = 1, bool glow = false) {
  if (x1 < x0) std::swap(x0, x1); if (y1 < y0) std::swap(y0, y1);
  quad({x0, y0, z1}, {x1, y0, z1}, {x1, y1, z1}, {x0, y1, z1}, c, {0, 0, 1}, tile, glow);
  if (!(skip & 1)) quad({x0, y0, z0}, {x0, y1, z0}, {x1, y1, z0}, {x1, y0, z0}, c, {0, 0, -1}, tile, glow);
  quad({x0, y0, z0}, {x1, y0, z0}, {x1, y0, z1}, {x0, y0, z1}, c, {0, -1, 0}, tile, glow);
  quad({x1, y1, z0}, {x0, y1, z0}, {x0, y1, z1}, {x1, y1, z1}, c, {0, 1, 0}, tile, glow);
  quad({x0, y1, z0}, {x0, y0, z0}, {x0, y0, z1}, {x0, y1, z1}, c, {-1, 0, 0}, tile, glow);
  quad({x1, y0, z0}, {x1, y1, z0}, {x1, y1, z1}, {x1, y0, z1}, c, {1, 0, 0}, tile, glow);
}
static void solid(float x0, float y0, float x1, float y1, bool wall = false) { COL.push_back({std::min(x0, x1), std::min(y0, y1), std::max(x0, x1), std::max(y0, y1), wall}); }
// a round thing: n sides from radius r0 at z0 to r1 at z1 (and a lid)
static void cyl(float cx, float cy, float z0, float z1, float r0, float r1, Col c, int n = 8, bool lid = true, bool glow = false) {
  for (int i = 0; i < n; i++) { float a0 = i * 6.2832f / n, a1 = (i + 1) * 6.2832f / n, am = (a0 + a1) / 2;
    P3 nn = nrm3({std::cos(am), std::sin(am), (r0 - r1) / std::max(.01f, z1 - z0)});
    quad({cx + std::cos(a0) * r0, cy + std::sin(a0) * r0, z0}, {cx + std::cos(a1) * r0, cy + std::sin(a1) * r0, z0}, {cx + std::cos(a1) * r1, cy + std::sin(a1) * r1, z1}, {cx + std::cos(a0) * r1, cy + std::sin(a0) * r1, z1}, c, nn, 9, glow);
    if (lid) { uint32_t k = glow ? c.pack() : litAt(c, {cx, cy, z1}, {0, 0, 1}).pack(); vtx({cx, cy, z1}, k); vtx({cx + std::cos(a0) * r1, cy + std::sin(a0) * r1, z1}, k); vtx({cx + std::cos(a1) * r1, cy + std::sin(a1) * r1, z1}, k); } }
}
// a thin patch on a wall or floor (stains, holes, rugs): centre p, half sizes along u and v, facing n
static void patch(P3 p, P3 u, P3 v, Col c, P3 n, bool glow = false) { P3 o = p + n * .03f; quad(o - u - v, o + u - v, o + u + v, o - u + v, c, n, 9, glow); }
static Col HX(const char *h) { return hex(h); }
static Col vary(Col c, float k) { float f = 1 + (frand() - .5f) * k; return Col(std::min(255.f, c.r * f), std::min(255.f, c.g * f), std::min(255.f, c.b * f), 1); }

// walls: a line of boxes along x (or y), with openings (doors from the floor, windows from z0)
struct Gap { float a, b, z0, z1; };
static void wall(bool alongX, float fix, float from, float to, std::vector<Gap> gaps, Col c) {
  std::sort(gaps.begin(), gaps.end(), [](const Gap &a, const Gap &b) { return a.a < b.a; });
  auto piece = [&](float a, float b, float z0, float z1, bool coll) { if (b - a < .01f || z1 - z0 < .01f) return;
    if (alongX) { box(a, fix - WT, z0, b, fix + WT, z1, c, 3, z0 > 0 ? 0 : 1); if (coll) solid(a, fix - WT, b, fix + WT, true); }
    else { box(fix - WT, a, z0, fix + WT, b, z1, c, 3, z0 > 0 ? 0 : 1); if (coll) solid(fix - WT, a, fix + WT, b, true); } };
  float cur = from;
  for (auto &g : gaps) { piece(cur, g.a, 0, CEIL, true); piece(g.a, g.b, 0, g.z0, g.z0 > 0); piece(g.a, g.b, g.z1, CEIL, false); cur = g.b; }
  piece(cur, to, 0, CEIL, true);
}
// a window in an outer wall: frame, sill, the view (the city, a bit grimy through dirty glass)
static void window(bool alongX, float fix, float a, float b, float z0, float z1, float out) {
  Col fr = HX("#cfc6ad"), sky0 = HX("#9fb0bc"), sky1 = HX("#c9cfc8");
  float t = .12f;
  if (alongX) {
    box(a - .15f, fix - WT - .25f, z0 - .15f, b + .15f, fix + WT + .25f, z0 + .05f, fr, 3, 0);   // sill: sits proud of the wall
    box(a + .01f, fix - .08f, z0 + .05f, a + t, fix + .08f, z1 - .01f, fr); box(b - t, fix - .08f, z0 + .05f, b - .01f, fix + .08f, z1 - .01f, fr); box(a + .01f, fix - .08f, z1 - t, b - .01f, fix + .08f, z1 - .01f, fr, 3, 0);
    box((a + b) / 2 - t / 2, fix - .06f, z0 + .05f, (a + b) / 2 + t / 2, fix + .06f, z1 - t, fr); box(a + t, fix - .06f, (z0 + z1) / 2 - t / 2, b - t, fix + .06f, (z0 + z1) / 2 + t / 2, fr, 3, 0);
    float yo = fix + out * 1.2f, ny = -out;
    quad({a - 1, yo, z0 - 1}, {b + 1, yo, z0 - 1}, {b + 1, yo, z1 + 1}, {a - 1, yo, z1 + 1}, sky1, {0, ny, 0}, 9, true);
    quad({a - 1, yo + out * .01f, z0 - 1}, {b + 1, yo + out * .01f, z0 - 1}, {b + 1, yo + out * .01f, (z0 + z1) / 2}, {a - 1, yo + out * .01f, (z0 + z1) / 2}, sky0, {0, ny, 0}, 9, true);
    for (float x = a - .8f; x < b + .8f; x += .5f + frand() * .7f) { float hb = z0 - .4f + frand() * 2.2f, w = .3f + frand() * .5f;   // the skyline
      quad({x, yo - out * .02f, z0 - 1}, {x + w, yo - out * .02f, z0 - 1}, {x + w, yo - out * .02f, hb}, {x, yo - out * .02f, hb}, vary(HX("#6f7a80"), .2f), {0, ny, 0}, 9, true); }
  } else {
    box(fix - WT - .25f, a - .15f, z0 - .15f, fix + WT + .25f, b + .15f, z0 + .05f, fr, 3, 0);
    box(fix - .08f, a + .01f, z0 + .05f, fix + .08f, a + t, z1 - .01f, fr); box(fix - .08f, b - t, z0 + .05f, fix + .08f, b - .01f, z1 - .01f, fr); box(fix - .08f, a + .01f, z1 - t, fix + .08f, b - .01f, z1 - .01f, fr, 3, 0);
    box(fix - .06f, (a + b) / 2 - t / 2, z0 + .05f, fix + .06f, (a + b) / 2 + t / 2, z1 - t, fr); box(fix - .06f, a + t, (z0 + z1) / 2 - t / 2, fix + .06f, b - t, (z0 + z1) / 2 + t / 2, fr, 3, 0);
    float xo = fix + out * 1.2f, nx = -out;
    quad({xo, a - 1, z0 - 1}, {xo, b + 1, z0 - 1}, {xo, b + 1, z1 + 1}, {xo, a - 1, z1 + 1}, sky1, {nx, 0, 0}, 9, true);
    quad({xo + out * .01f, a - 1, z0 - 1}, {xo + out * .01f, b + 1, z0 - 1}, {xo + out * .01f, b + 1, (z0 + z1) / 2}, {xo + out * .01f, a - 1, (z0 + z1) / 2}, sky0, {nx, 0, 0}, 9, true);
    for (float y = a - .8f; y < b + .8f; y += .5f + frand() * .7f) { float hb = z0 - .4f + frand() * 2.2f, w = .3f + frand() * .5f;
      quad({xo - out * .02f, y, z0 - 1}, {xo - out * .02f, y + w, z0 - 1}, {xo - out * .02f, y + w, hb}, {xo - out * .02f, y, hb}, vary(HX("#6f7a80"), .2f), {nx, 0, 0}, 9, true); }
  }
  // grime on the glass: streaks along the bottom of each pane
  for (int i = 0; i < 2; i++) for (int k = 0; k < 2; k++) { float u0 = a + (b - a) * (.5f * i + .03f), u1 = a + (b - a) * (.5f * i + .47f), zz = z0 + (z1 - z0) * (.5f * k) + .2f; Col g = vary(HX("#a9a58f"), .08f); float hh = .12f + frand() * .15f;
    if (alongX) quad({u0, fix - .07f * out, zz}, {u1, fix - .07f * out, zz}, {u1, fix - .07f * out, zz + hh}, {u0, fix - .07f * out, zz + hh * .4f}, g, {0, -out, 0}, 9, true);
    else quad({fix - .07f * out, u0, zz}, {fix - .07f * out, u1, zz}, {fix - .07f * out, u1, zz + hh}, {fix - .07f * out, u0, zz + hh * .4f}, g, {-out, 0, 0}, 9, true); }
}

// ---------------------------------------------------------------- floors
static void floorRect(float x0, float y0, float x1, float y1, int type) {
  P3 up = {0, 0, 1};
  if (type == 0) {   // worn carpet: one colour, flattened paths and stains
    quad({x0, y0, 0}, {x1, y0, 0}, {x1, y1, 0}, {x0, y1, 0}, HX("#7b7060"), up, 2.5f);
    int ns = (int)((x1 - x0) * (y1 - y0) / 22); for (int i = 0; i < ns; i++) { float cx = x0 + (x1 - x0) * frand(), cy = y0 + (y1 - y0) * frand(), r = .4f + frand() * 1.1f;
      patch({cx, cy, 0}, {r, 0, 0}, {0, r * (.6f + frand() * .6f), 0}, vary(HX("#5c5345"), .25f), up); }
    return;
  }
  if (type == 3) {   // marble: 2 ft tiles, grout between, a vein across each
    quad({x0, y0, 0}, {x1, y0, 0}, {x1, y1, 0}, {x0, y1, 0}, HX("#9a968e"), up, 6);
    for (float x = x0; x < x1 - .05f; x += 2) for (float y = y0; y < y1 - .05f; y += 2) { float xe = std::min(x1, x + 2) - .04f, ye = std::min(y1, y + 2) - .04f; Col t = vary(HX("#e9e6df"), .06f);
      quad({x + .04f, y + .04f, .02f}, {xe, y + .04f, .02f}, {xe, ye, .02f}, {x + .04f, ye, .02f}, t, up, 9);
      float vy = y + .3f + frand() * 1.3f; quad({x + .1f, vy, .03f}, {xe - .1f, vy + (frand() - .5f) * .8f, .03f}, {xe - .1f, vy + .05f + (frand() - .5f) * .8f, .03f}, {x + .1f, vy + .06f, .03f}, HX("#b4b0aa"), up, 9); }
    return;
  }
  // planks along x: vinyl (wide, grey-tan) or oak (narrow, warm)
  float pw = type == 1 ? .62f : .38f; Col base = type == 1 ? HX("#b5a68d") : HX("#9b6b40");
  quad({x0, y0, 0}, {x1, y0, 0}, {x1, y1, 0}, {x0, y1, 0}, type == 1 ? HX("#6e6556") : HX("#4a311d"), up, 6);
  for (float y = y0; y < y1 - .02f; y += pw) { float ye = std::min(y1, y + pw) - .025f, x = x0 - frand() * 3;
    while (x < x1) { float l = (type == 1 ? 3.5f : 2.5f) + frand() * 2, xa = std::max(x0, x), xb = std::min(x1, x + l) - .025f; if (xb > xa + .05f) quad({xa, y, .015f}, {xb, y, .015f}, {xb, ye, .015f}, {xa, ye, .015f}, vary(base, type == 1 ? .1f : .22f), up, 9); x += l; } }
}

// ---------------------------------------------------------------- the furniture you can upgrade
static void couchGeo(int v) {   // against nothing, facing west toward the TV; the seat front at x 10.4
  if (v == 0) { Col f = HX("#5b4a3a"), m = HX("#b49a4e");   // a futon: wood frame, a sagging mustard mattress
    box(10.4f, 3.6f, 0, 13.2f, 10.4f, .8f, f); box(10.5f, 3.7f, .8f, 13.1f, 10.3f, 1.35f, m, 2); box(12.6f, 3.6f, 1.2f, 13.3f, 10.4f, 3.0f, m, 2);
    box(11.4f, 6.2f, 1.33f, 12.2f, 7.8f, 1.37f, HX("#8c7535"));   // the sag
    patch({11.2f, 8.6f, 1.36f}, {.4f, 0, 0}, {0, .3f, 0}, HX("#6f5f2e"), {0, 0, 1}); solid(10.4f, 3.6f, 13.3f, 10.4f); }
  else if (v == 1) { Col c = HX("#6b4a2f");   // thrift sofa
    box(10.5f, 3.8f, 0, 13.2f, 10.2f, 1.5f, c, 2); box(12.4f, 3.8f, 1.5f, 13.2f, 10.2f, 3.0f, c, 2);
    box(10.5f, 3.4f, 0, 13.2f, 3.9f, 2.2f, c); box(10.5f, 10.1f, 0, 13.2f, 10.6f, 2.2f, c);
    for (int i = 0; i < 3; i++) box(10.6f, 4.0f + i * 2.05f, 1.5f, 12.4f, 5.95f + i * 2.05f, 1.85f, vary(HX("#7d5838"), .08f), 2);
    solid(10.5f, 3.4f, 13.2f, 10.6f); }
  else if (v == 2) { Col c = HX("#2e2522"), s = HX("#3b302b");   // leather sectional with a chaise toward the TV
    box(10.6f, 3.0f, 0, 13.4f, 11.0f, 1.45f, c, 2); box(12.6f, 3.0f, 1.45f, 13.4f, 11.0f, 3.0f, c, 2);
    box(8.0f, 9.0f, 0, 10.6f, 11.0f, 1.45f, c, 2); box(8.0f, 10.4f, 1.45f, 10.6f, 11.0f, 3.0f, c, 2);
    box(10.6f, 2.5f, 0, 13.4f, 3.0f, 2.1f, c);
    for (int i = 0; i < 3; i++) box(10.7f, 3.1f + i * 2.0f, 1.45f, 12.6f, 4.95f + i * 2.0f, 1.85f, vary(s, .06f), 2);
    box(8.1f, 9.1f, 1.45f, 10.6f, 10.4f, 1.85f, s, 2); solid(10.6f, 2.5f, 13.4f, 11.0f); solid(8.0f, 9.0f, 10.6f, 11.0f); }
  else { Col c = HX("#c9c8c4");   // designer modular
    box(10.2f, 2.6f, 0, 13.6f, 11.4f, 1.2f, c, 2); box(12.8f, 2.6f, 1.2f, 13.6f, 11.4f, 2.6f, c, 2);
    box(10.2f, 2.2f, 0, 13.6f, 2.6f, 1.9f, c); box(10.2f, 11.4f, 0, 13.6f, 11.8f, 1.9f, c);
    const char *pc[5] = {"#e0703a", "#2b6f8f", "#e9c14b", "#2b6f8f", "#e0703a"};
    for (int i = 0; i < 5; i++) { float y = 3.2f + i * 1.65f; box(12.3f, y, 1.2f, 12.8f, y + 1.1f, 2.4f, HX(pc[i]), 2); }
    box(10.3f, 2.7f, 1.2f, 12.8f, 11.3f, 1.55f, HX("#d6d5d1"), 2); solid(10.2f, 2.2f, 13.6f, 11.8f); }
}
static float entTop = 2.2f;   // where the TV stands
static void entGeo(int v) {   // against the west wall, centred at y 7
  if (v == 0) { Col r = HX("#b0302c"), b = HX("#2f5a9a");   // two milk crates and a plank
    auto crate = [&](float y0, Col c) { box(.4f, y0, 0, 1.5f, y0 + 1.1f, 1.1f, c, 1); box(.5f, y0 + .1f, .1f, 1.4f, y0 + 1.0f, 1.12f, HX("#1a1a1a")); };
    crate(5.2f, r); crate(7.7f, b); box(.35f, 5.0f, 1.12f, 1.6f, 9.0f, 1.25f, HX("#8a7352"), 2); entTop = 1.25f; solid(.25f, 5.0f, 1.6f, 9.0f); }
  else if (v == 1) { Col k = HX("#1c1c1f"); box(.3f, 4.5f, 0, 1.8f, 9.5f, 1.8f, k, 2); box(.35f, 4.7f, .3f, 1.82f, 9.3f, .35f, HX("#2c2c30")); box(.35f, 4.7f, 1.0f, 1.82f, 9.3f, 1.05f, HX("#2c2c30"));
    box(1.0f, 5.0f, .36f, 1.6f, 6.2f, .6f, HX("#111")); entTop = 1.8f; solid(.25f, 4.5f, 1.8f, 9.5f); }
  else if (v == 2) { Col o = HX("#9a6a3c"); box(.3f, 3.8f, 0, 1.9f, 10.2f, 2.0f, o, 2);
    for (int i = 0; i < 3; i++) { float y = 4.1f + i * 2.05f; box(1.88f, y, .3f, 1.93f, y + 1.8f, 1.7f, vary(HX("#875a31"), .05f)); box(1.92f, y + .8f, .95f, 2.0f, y + 1.0f, 1.05f, HX("#d8c08a")); }
    entTop = 2.0f; solid(.25f, 3.8f, 1.9f, 10.2f); }
  else { Col w = HX("#5a3a24"); box(.3f, 2.8f, 1.2f, 1.7f, 11.2f, 2.3f, w, 2, 0); box(.32f, 2.9f, 1.15f, 1.68f, 11.1f, 1.2f, HX("#7fd6ff"), 9, 0, true);   // the light strip underneath
    for (int i = 0; i < 4; i++) box(1.68f, 3.2f + i * 2.0f, 1.3f, 1.72f, 4.9f + i * 2.0f, 2.2f, vary(HX("#6b4630"), .05f));
    entTop = 2.3f; solid(.25f, 2.8f, 1.7f, 11.2f); }
}
// the screen shows a rink, of course
static void screenPic(float x, float y0, float y1, float z0, float z1, bool crt) {
  Col bg = crt ? HX("#7f9a8a") : HX("#e8eef4"); quad({x, y1, z0}, {x, y0, z0}, {x, y0, z1}, {x, y1, z1}, bg, {1, 0, 0}, 9, true);
  float w = y1 - y0, h = z1 - z0, xi = x + .01f;
  auto bar = [&](float u0, float u1, float v0, float v1, Col c) { quad({xi, y1 - w * u0, z0 + h * v0}, {xi, y1 - w * u1, z0 + h * v0}, {xi, y1 - w * u1, z0 + h * v1}, {xi, y1 - w * u0, z0 + h * v1}, c, {1, 0, 0}, 9, true); };
  bar(.495f, .505f, .08f, .92f, crt ? HX("#7a3a3a") : HX("#d23b3b")); bar(.33f, .345f, .08f, .92f, crt ? HX("#3a4a7a") : HX("#2f64d6")); bar(.655f, .67f, .08f, .92f, crt ? HX("#3a4a7a") : HX("#2f64d6"));
  bar(.08f, .09f, .25f, .75f, HX("#c23")); bar(.91f, .92f, .25f, .75f, HX("#c23"));
  bar(.4f, .43f, .45f, .55f, HX("#111")); bar(.6f, .62f, .6f, .7f, HX("#222")); bar(.03f, .3f, .86f, .96f, crt ? HX("#2a3a2a") : HX("#0b1220"));   // a skater, the puck, the score bug
}
static void tvGeo(int v) {
  float z = entTop, cy = 7; P3 hot;
  if (v == 0) { box(.45f, 5.9f, z, 1.6f, 8.1f, z + 1.5f, HX("#4a4a46")); screenPic(1.61f, 6.15f, 7.85f, z + .2f, z + 1.3f, true); hot = {1.6f, cy, z + .75f}; }
  else { float w = v == 1 ? 3.0f : v == 2 ? 4.7f : 6.2f, h = w * .5625f, z0 = v == 3 ? 3.6f : z + .5f, x = v == 3 ? .3f : .7f, d = v == 3 ? .12f : .18f;
    box(x, cy - w / 2 - .06f, z0 - .06f, x + d, cy + w / 2 + .06f, z0 + h + .06f, HX("#111214"), 9, 0);
    if (v < 3) { box(x - .1f, cy - .5f, z, x + .5f, cy + .5f, z + .07f, HX("#222")); box(x + .02f, cy - .1f, z, x + .1f, cy + .1f, z0, HX("#222")); }
    screenPic(x + d + .005f, cy - w / 2, cy + w / 2, z0, z0 + h, false); hot = {x + d, cy, z0 + h / 2}; }
  HOT.push_back({2, hot, 15});
}

// ---------------------------------------------------------------- the trophy shelf (every title, every career)
static void cupMini(float x, float y, float z, bool calder) {
  if (!calder) { Col s = HX("#d9dee4"), d = HX("#9aa3ad");   // the Stanley Cup: tiered barrel, collar, bowl
    cyl(x, y, z, z + .12f, .2f, .2f, HX("#2a2a2a")); cyl(x, y, z + .12f, z + .4f, .18f, .16f, s); cyl(x, y, z + .4f, z + .5f, .16f, .13f, d); cyl(x, y, z + .5f, z + .66f, .1f, .06f, s);
    cyl(x, y, z + .66f, z + .78f, .07f, .14f, s); cyl(x, y, z + .78f, z + .8f, .14f, .14f, d); }
  else { Col g = HX("#d8b04a");   // the Calder Cup: a gold urn with handles
    cyl(x, y, z, z + .08f, .14f, .14f, HX("#3a2a1a")); cyl(x, y, z + .08f, z + .25f, .05f, .05f, g); cyl(x, y, z + .25f, z + .55f, .07f, .16f, g);
    box(x - .2f, y - .02f, z + .38f, x - .16f, y + .02f, z + .5f, g); box(x + .16f, y - .02f, z + .38f, x + .2f, y + .02f, z + .5f, g); }
}
static void shelfGeo() {   // on the living-room face of the bedroom wall
  float y1 = 14 - WT, y0 = y1 - .85f, x0 = 3.0f, x1 = 9.4f; Col wd = HX("#6a5236");
  float zs[3] = {3.4f, 4.7f, 6.0f};
  for (float z : zs) { box(x0, y0, z - .1f, x1, y1, z, wd, 3, 0); box(x0 + .3f, y1 - .1f, z - .5f, x0 + .45f, y1, z - .1f, HX("#333")); box(x1 - .45f, y1 - .1f, z - .5f, x1 - .3f, y1, z - .1f, HX("#333")); }
  int cups = CR ? C.titles : 0, cal = CR ? C.calder : 0, nc = std::min(cups, 20), nk = std::min(cal, 30 - nc), i = 0;
  for (int k = 0; k < nc + nk; k++, i++) { int row = i / 10, col = i % 10; if (row > 2) break; cupMini(x0 + .35f + col * .62f, (y0 + y1) / 2, zs[2 - row], k >= nc); }
  if (!nc && !nk) { patch({(x0 + x1) / 2, y0 + .02f, zs[1] + .45f}, {.45f, 0, 0}, {0, 0, .3f}, HX("#f2e27a"), {0, -1, 0}); }   // a sticky note: "win something"
  HOT.push_back({APT_SHELF, {(x0 + x1) / 2, y0, 4.8f}, 10});
}

// ---------------------------------------------------------------- the whole place
static void build() {
  AG.clear(); COL.clear(); HOT.clear(); LAMPS.clear(); sd = 7;
  LAMPS = {{{9, 7, 8.4f}, .5f}, {{26, 6, 8.4f}, .45f}, {{7, 20, 8.4f}, .38f}, {{27, 19, 8.4f}, .38f}, {{17, 20, 8.4f}, .3f}};
  const int fl = HOME.sel[0];
  // floors
  floorRect(0, 0, 18, 14, fl); floorRect(14, 14, 20, AY, fl); floorRect(18, 12, 20, 14, fl); floorRect(0, 14, 14, AY, fl); floorRect(20, 12, AX, AY, fl);
  for (int i = 18; i < 34; i++) for (int j = 0; j < 12; j++) { Col t = ((i + j) & 1) ? HX("#b9b29c") : HX("#8f8a7c"); if (frand() < .12f) t = HX("#7a7262");   // kitchen linoleum, cracked here and there
    quad({(float)i, (float)j, .01f}, {(float)i + 1, (float)j, .01f}, {(float)i + 1, (float)j + 1, .01f}, {(float)i, (float)j + 1, .01f}, vary(t, .06f), {0, 0, 1}, 9); }
  // the ceiling, water-stained
  quad({0, AY, CEIL}, {AX, AY, CEIL}, {AX, 0, CEIL}, {0, 0, CEIL}, HX("#c9c3b4"), {0, 0, -1}, 3.5f);
  for (int i = 0; i < 7; i++) { float x = 2 + frand() * 30, y = 2 + frand() * 22, r = .6f + frand() * 1.4f; patch({x, y, CEIL}, {r, 0, 0}, {0, r * .7f, 0}, vary(HX("#9c8c6c"), .15f), {0, 0, -1}); }
  // walls: the outside, then the rooms
  Col wl = HX("#a29a86"), wk = HX("#b2a98d"), wb = HX("#8e8e99"), wo = HX("#9b9a88");
  wall(true, 0, 0, AX, {{2, 5, 0, 7.2f}, {8, 15, 3, 7.2f}, {24, 29, 3.5f, 6.8f}}, wl);
  wall(true, AY, 0, AX, {}, wb);
  wall(false, 0, 0, AY, {{18, 23, 3, 7.2f}}, wb);
  wall(false, AX, 0, AY, {{16, 22, 3, 7.2f}}, wo);
  wall(true, 14, 0, 14, {}, wb); wall(false, 14, 14, AY, {{18.5f, 21.5f, 0, 7.2f}}, wb);
  wall(false, 20, 12, AY, {{18.5f, 21.5f, 0, 7.2f}}, wo); wall(true, 12, 20, AX, {}, wk);
  window(true, 0, 8, 15, 3, 7.2f, -1); window(true, 0, 24, 29, 3.5f, 6.8f, -1); window(false, 0, 18, 23, 3, 7.2f, -1); window(false, AX, 16, 22, 3, 7.2f, 1);
  // baseboards
  Col bb = HX("#d8d1bd");
  for (auto &r : std::vector<Rc>{{.25f, .25f, 18, .35f, false}, {.25f, 13.65f, 13.75f, 13.75f, false}}) box(r.x0, r.y0, 0, r.x1, r.y1, .35f, bb, 9);
  // holes and cracks in the drywall, scuffs
  struct WP { P3 p; P3 n; } wp[] = {{{6, .27f, 2.4f}, {0, 1, 0}}, {{16.5f, .27f, 1.2f}, {0, 1, 0}}, {{.27f, 12.0f, 3.5f}, {1, 0, 0}}, {{11.5f, 13.73f, 1.6f}, {0, -1, 0}}, {{13.73f, 23.5f, 2.2f}, {-1, 0, 0}}, {{33.73f, 13.5f, 4.0f}, {-1, 0, 0}}, {{25.0f, 25.73f, 1.0f}, {0, -1, 0}}};
  for (auto &w : wp) { P3 u = std::fabs(w.n.x) > .5f ? P3{0, 1, 0} : P3{1, 0, 0}; patch(w.p, u * .45f, {0, 0, .38f}, HX("#5e5547"), w.n); patch(w.p + w.n * .01f, u * .26f, {0, 0, .22f}, HX("#2a2620"), w.n); }
  for (int i = 0; i < 9; i++) { float y = .27f, x = 1 + frand() * 32, z = 1 + frand() * 6; if ((x > 1 && x < 6.2f) || (x > 7 && x < 16) || (x > 23 && x < 30)) z = std::min(z, 2.6f); if (x > 1 && x < 6.2f) continue; patch({x, y, z}, {.6f + frand(), 0, 0}, {0, 0, .03f}, HX("#6f6655"), {0, 1, 0}); }
  // the front door, the bathroom door
  box(2.05f, -.12f, 0, 4.95f, .12f, 7.15f, HX("#6b4a33"), 3, 0); box(4.4f, .12f, 3.3f, 4.6f, .22f, 3.5f, HX("#c8a640")); box(3.3f, .12f, 5.4f, 3.7f, .14f, 5.6f, HX("#222"));
  solid(2, -.2f, 5, .3f); HOT.push_back({APT_DOOR, {3.5f, .2f, 3.6f}, 4.5f});
  patch({3.5f, 1.2f, 0}, {1.3f, 0, 0}, {0, .8f, 0}, HX("#5a4a3c"), {0, 0, 1});   // the doormat
  box(15.5f, 25.6f, 0, 18.5f, 25.8f, 7.1f, HX("#e3dccb"), 3, 0); box(18.0f, 25.5f, 3.3f, 18.2f, 25.6f, 3.5f, HX("#9a9a9a"));
  for (float fx : {14.f, 20.f}) { Col tr = HX("#d7d0bd");   // casings round the hallway doorways (the doors themselves move: see doorTris)
    box(fx - WT - .04f, 18.25f, 0, fx + WT + .04f, 18.5f, 7.45f, tr, 9); box(fx - WT - .04f, 21.5f, 0, fx + WT + .04f, 21.75f, 7.45f, tr, 9); box(fx - WT - .04f, 18.25f, 7.2f, fx + WT + .04f, 21.75f, 7.45f, tr, 9, 0); }
  // bare bulbs
  for (auto &L : LAMPS) { box(L.p.x - .04f, L.p.y - .04f, L.p.z + .2f, L.p.x + .04f, L.p.y + .04f, CEIL, HX("#333")); cyl(L.p.x, L.p.y, L.p.z - .1f, L.p.z + .2f, .18f, .12f, HX("#fff2c2"), 8, true, true); }
  // ---- living room: the TV wall, the couch, a coffee table, the shelf, the mess
  entGeo(HOME.sel[3]); HOT.push_back({3, {1.5f, 7, entTop - .3f}, 15}); tvGeo(HOME.sel[2]); couchGeo(HOME.sel[1]); HOT.push_back({1, {11.8f, 7, 1.6f}, 15});
  Col tb = HX("#5c4a36"); box(6.6f, 5.6f, 1.25f, 8.8f, 8.4f, 1.4f, tb, 3, 0); for (float x : {6.7f, 8.6f}) for (float y : {5.7f, 8.2f}) box(x, y, 0, x + .15f, y + .15f, 1.25f, tb, 9);
  solid(6.6f, 5.6f, 8.8f, 8.4f);
  box(6.9f, 6.0f, 1.4f, 8.1f, 7.2f, 1.55f, HX("#c4a066"));   // a pizza box
  cyl(8.4f, 7.9f, 1.4f, 2.1f, .1f, .08f, HX("#3b6b3a")); cyl(7.2f, 8.0f, 1.4f, 2.0f, .1f, .08f, HX("#6b4a2a")); cyl(16.2f, 9.5f, 0, .1f, .35f, .1f, HX("#3b6b3a"));
  shelfGeo();
  if (!(HOME.junk & 2)) { box(16.4f, .5f, 0, 17.6f, 1.6f, 1.5f, HX("#24302a")); box(17.0f, 1.8f, 0, 17.9f, 2.9f, 1.3f, HX("#2a352e")); solid(16.3f, .4f, 18, 3); HOT.push_back({APT_JUNK + 1, {17.2f, 1.7f, 1.2f}, 8}); }   // trash bags by the kitchen
  if (!(HOME.junk & 1)) { box(14.5f, 11.5f, 0, 16.3f, 13.4f, 1.6f, HX("#a07a4a")); box(14.8f, 11.8f, 1.6f, 15.9f, 13.1f, 2.6f, HX("#93703f")); solid(14.4f, 11.4f, 16.4f, 13.5f); HOT.push_back({APT_JUNK + 0, {15.4f, 12.4f, 1.8f}, 8}); }   // moving boxes
  for (int i = 0; i < 5; i++) { float x = 13.5f + frand() * 2, y = 4 + frand() * 6; box(x, y, 0, x + .5f + frand() * .6f, y + .4f + frand() * .5f, .12f + frand() * .15f, vary(HX("#56607a"), .5f)); }   // laundry
  // ---- kitchen: base cabinets and counters along the east and north walls, upper cabinets, fridge, stove, sink, table
  Col cab = HX("#8d7a5a"), ct = HX("#8a8478");
  box(31.5f, 1.0f, 0, 33.75f, 11.75f, 3.0f, cab); box(31.35f, .9f, 3.0f, 33.75f, 11.75f, 3.15f, ct, 3, 0); solid(31.4f, .9f, AX, 11.8f);
  box(22.6f, 9.5f, 0, 31.5f, 11.75f, 3.0f, cab); box(22.5f, 9.35f, 3.0f, 31.5f, 11.75f, 3.15f, ct, 3, 0); solid(22.5f, 9.3f, 31.5f, 11.8f);
  for (int i = 0; i < 6; i++) { float y = 1.2f + i * 1.75f; box(31.45f, y, .3f, 31.52f, y + 1.6f, 2.7f, vary(HX("#9a8664"), .05f)); }
  for (int i = 0; i < 5; i++) { float x = 22.8f + i * 1.75f; box(x, 9.45f, .3f, x + 1.6f, 9.52f, 2.7f, vary(HX("#9a8664"), .05f)); }
  box(32.5f, 1.0f, 5.0f, 33.75f, 11.75f, 7.6f, cab); box(22.6f, 10.8f, 5.0f, 31.5f, 11.75f, 7.6f, cab);
  box(32.42f, 1.2f, 5.6f, 32.5f, 1.4f, 6.2f, HX("#a9a9a9"));   // a cabinet door hanging open
  box(20.3f, 9.3f, 0, 22.4f, 11.75f, 6.2f, HX("#d4d0c2")); box(20.25f, 9.6f, 3.6f, 20.32f, 9.75f, 5.0f, HX("#9a9a9a")); solid(20.2f, 9.2f, 22.5f, 11.8f);   // fridge
  box(31.5f, 4.2f, 3.15f, 33.6f, 6.6f, 3.2f, HX("#1d1d1f")); for (int i = 0; i < 4; i++) cyl(32.1f + (i % 2) * .9f, 4.8f + (i / 2) * 1.2f, 3.2f, 3.22f, .3f, .3f, HX("#3a3a3a"));
  box(31.35f, 4.2f, 3.6f, 31.5f, 6.6f, 3.75f, HX("#2a2a2a"));
  box(26.0f, 9.8f, 2.6f, 28.4f, 11.2f, 3.16f, HX("#5d6166"), 9, 0); cyl(27.2f, 11.4f, 3.15f, 4.0f, .06f, .05f, HX("#b0b0b0"));
  for (int i = 0; i < 4; i++) cyl(26.6f + i * .35f, 10.3f, 3.16f, 3.4f + i * .05f, .25f, .25f, vary(HX("#d8d8d0"), .1f));   // dishes piled up
  Col tt = HX("#7a6a52"); box(23.0f, 3.0f, 2.4f, 26.5f, 6.0f, 2.55f, tt, 3, 0); for (float x : {23.1f, 26.3f}) for (float y : {3.1f, 5.8f}) box(x, y, 0, x + .1f, y + .1f, 2.4f, tt, 9);
  for (float y : {2.2f, 6.2f}) { box(24.2f, y, 1.5f, 25.4f, y + .9f, 1.6f, HX("#5a5a5e")); box(24.2f, y < 4 ? y : y + .8f, 1.6f, 25.4f, y < 4 ? y + .1f : y + .9f, 3.3f, HX("#5a5a5e")); }
  solid(23.0f, 2.2f, 26.5f, 7.1f);
  // ---- bedroom: a mattress on the floor, a dresser, clothes
  box(1.0f, 19.0f, 0, 6.5f, 25.7f, .9f, HX("#bdb6a2"), 2); box(1.4f, 24.3f, .9f, 4.0f, 25.4f, 1.3f, HX("#e1ddd0"), 2); box(1.1f, 19.2f, .9f, 6.2f, 22.8f, 1.05f, HX("#4a5a73"), 2);
  solid(1.0f, 19.0f, 6.5f, 25.7f);
  box(9.5f, 24.4f, 0, 13.5f, 25.75f, 3.2f, HX("#6e5a44")); box(9.6f, 24.3f, 2.2f, 13.4f, 24.4f, 3.0f, HX("#5a4936")); solid(9.5f, 24.3f, 13.5f, 25.8f);
  box(7.0f, 24.4f, 0, 8.2f, 25.6f, 1.1f, HX("#2f5a9a")); cyl(7.6f, 25.0f, 1.1f, 2.0f, .25f, .15f, HX("#e9e2c8"));
  for (int i = 0; i < 6; i++) { float x = 3 + frand() * 8, y = 15.5f + frand() * 3; box(x, y, 0, x + .6f + frand() * .6f, y + .5f + frand() * .5f, .1f + frand() * .2f, vary(HX("#7a5a6a"), .6f)); }
  // ---- office: a folding table, an old monitor, a sagging bookshelf, boxes
  Col ft = HX("#8a8a84"); box(28.5f, 23.4f, 2.4f, 33.5f, 25.6f, 2.5f, ft, 3, 0); for (float x : {28.6f, 33.3f}) for (float y : {23.5f, 25.4f}) box(x, y, 0, x + .08f, y + .08f, 2.4f, HX("#444"), 9);
  solid(28.5f, 23.4f, 33.5f, 25.6f); box(30.3f, 24.3f, 2.5f, 31.9f, 25.5f, 3.8f, HX("#c9c3b0")); box(30.45f, 24.25f, 2.75f, 31.75f, 24.3f, 3.6f, HX("#203040"), 9, 0, true);
  box(30.0f, 21.6f, 1.5f, 31.4f, 22.9f, 1.6f, HX("#55555a")); box(30.0f, 22.8f, 1.6f, 31.4f, 22.9f, 3.4f, HX("#55555a")); for (float x : {30.1f, 31.2f}) for (float y : {21.7f, 22.7f}) box(x, y, 0, x + .07f, y + .07f, 1.5f, HX("#333"), 9);
  box(20.3f, 13.0f, 0, 21.2f, 17.0f, 6.0f, HX("#6a5236")); for (int s = 0; s < 4; s++) { float z = .4f + s * 1.45f; for (float y = 13.2f; y < 16.6f; y += .25f + frand() * .2f) if (frand() < .7f) box(20.4f, y, z, 21.0f, y + .18f, z + .7f + frand() * .3f, vary(HX("#8a4a3a"), .6f)); }
  solid(20.2f, 12.9f, 21.3f, 17.1f);
  if (!(HOME.junk & 4)) { box(22.0f, 24.0f, 0, 24.2f, 25.7f, 1.8f, HX("#a07a4a")); box(22.3f, 24.3f, 1.8f, 23.8f, 25.5f, 3.0f, HX("#93703f")); solid(21.9f, 23.9f, 24.3f, 25.8f); HOT.push_back({APT_JUNK + 2, {23.1f, 24.8f, 1.8f}, 8}); }
  // the GPU keeps it until something changes
  aptVer++; aptOk = true;
}

// ---------------------------------------------------------------- you
static struct { double x = 3.5, y = 2.4, yaw = .85, pitch = -.05; bool set = false; float lx = 0, ly = 0; int tid = -1; float tx0 = 0, ty0 = 0; bool tLook = false; } Me;
bool aptBuild = false;
void aptReset() { Me.x = 3.5; Me.y = 2.6; Me.yaw = .85; Me.pitch = -.05; Me.set = true; }
void aptView(double x, double y, double yaw, double pitch) { Me.x = x; Me.y = y; Me.yaw = yaw; Me.pitch = pitch; Me.set = true; }
static const double EYE = 5.4, RAD = .9;
static void doorRects(std::vector<Rc> &v);
static void collide(double &x, double &y) {
  x = std::max(WT + RAD, std::min(AX - WT - RAD, x)); y = std::max(WT + RAD, std::min(AY - WT - RAD, y));
  static std::vector<Rc> all; all = COL; doorRects(all);
  for (int it = 0; it < 2; it++) for (auto &r : all) { double cx = std::max((double)r.x0, std::min(x, (double)r.x1)), cy = std::max((double)r.y0, std::min(y, (double)r.y1)), dx = x - cx, dy = y - cy, d2 = dx * dx + dy * dy;
    if (d2 >= RAD * RAD) continue;
    if (d2 < 1e-8) { double pl = x - r.x0, pr = r.x1 - x, pb = y - r.y0, pt = r.y1 - y, m = std::min(std::min(pl, pr), std::min(pb, pt)); if (m == pl) x = r.x0 - RAD; else if (m == pr) x = r.x1 + RAD; else if (m == pb) y = r.y0 - RAD; else y = r.y1 + RAD; continue; }
    double d = std::sqrt(d2), k = (RAD - d) / d; x += dx * k; y += dy * k; }
}

// ---------------------------------------------------------------- the hallway doors: they swing into the room and close behind you
struct HDoor { float hx, hy, side; double a = 0, tgt = 0, hold = 0; };   // hinge, which way it swings (-1 west, +1 east), open 0..1
static HDoor HD[2] = {{14, 18.55f, -1}, {20, 18.55f, 1}};
static const float DW = 2.9f, DH = 7.1f, DT = .14f;
static P3 doorDir(const HDoor &d) { double th = d.a * 1.55; return {(float)(std::sin(th) * d.side), (float)std::cos(th), 0}; }   // along the slab, hinge to latch
static P3 doorMid(const HDoor &d) { P3 u = doorDir(d); return {d.hx + u.x * DW / 2, d.hy + u.y * DW / 2, 3.6f}; }
bool aptDoorOpen(int i) { return i >= 0 && i < 2 && HD[i].tgt > .5; }
void aptDoor(int i) { if (i < 0 || i > 1) return; HDoor &d = HD[i]; d.tgt = d.tgt > .5 ? 0 : 1; d.hold = 4.5; }
static bool inSwing(const HDoor &d, double x, double y) { double dx = x - d.hx, dy = y - d.hy - DW / 2; return std::fabs(dy) < DW / 2 + RAD && dx * d.side > -RAD - .4 && dx * d.side < DW + RAD; }
static void doorsTick(double dt) {
  for (auto &d : HD) {
    if (d.tgt > .5 && d.a > .99) { d.hold -= dt; if (d.hold <= 0) { if (inSwing(d, Me.x, Me.y)) d.hold = .5; else d.tgt = 0; } }   // it waits for you to clear the swing
    double sp = 1.6 * dt; if (d.tgt > d.a) d.a = std::min(d.tgt, d.a + sp); else if (d.tgt < d.a) { if (d.a < .99 || !inSwing(d, Me.x, Me.y)) d.a = std::max(d.tgt, d.a - sp); }
  }
}
// solid while shut; once open, the slab against its swing
static void doorRects(std::vector<Rc> &v) {
  for (auto &d : HD) { if (d.a < .15) v.push_back({d.hx - .12f, d.hy, d.hx + .12f, d.hy + DW, false});
    else if (d.a > .9) { P3 u = doorDir(d); float x1 = d.hx + u.x * DW, y1 = d.hy + u.y * DW; v.push_back({std::min(d.hx, x1) - .08f, std::min(d.hy, y1) - .08f, std::max(d.hx, x1) + .08f, std::max(d.hy, y1) + .08f, false}); } }
}
static void obox(P3 o, P3 u, P3 v, float lu, float lv, float z0, float z1, Col c) {   // a box along u (length lu) and v (thickness lv, centred)
  P3 a = o - v * (lv / 2), b = a + u * lu, cc = b + v * lv, dd = a + v * lv; P3 z = {0, 0, z1 - z0}; a.z = b.z = cc.z = dd.z = z0;
  P3 nv = v * -1;
  quad(a, b, b + z, a + z, c, nv, 9); quad(cc, dd, dd + z, cc + z, c, v, 9); quad(b, cc, cc + z, b + z, c, u, 9); quad(dd, a, a + z, dd + z, c, u * -1, 9);
  quad(a + z, b + z, cc + z, dd + z, c, {0, 0, 1}, 9);
}
static void doorTris() {
  DY.clear(); OUT = &DY;
  for (auto &d : HD) { P3 u = doorDir(d), v = {-u.y, u.x, 0}, h = {d.hx, d.hy, 0};
    obox(h + u * .02f, u, v, DW, DT, 0, DH, HX("#e6dfcf"));
    for (float k : {-1.f, 1.f}) obox(h + u * (DW - .45f) + v * (k * (DT / 2 + .06f)), u, v, .14f, .12f, 3.2f, 3.4f, HX("#b8b8b8"));   // the knobs
  }
  OUT = &AG;
}
void aptMove(const Pad &pad, const Touch &touch, double dt) {
  if (!aptLoaded) return;   // not loaded: the loading screen builds it
  if (!aptOk) build();
  auto ax = [](int v) { double a = (v - 128) / 127.0; return std::fabs(a) < .18 ? 0.0 : (a - (a > 0 ? .18 : -.18)) / .82; };
  double mx = ax(pad.lx), my = -ax(pad.ly), lx = ax(pad.rx), ly = -ax(pad.ry);
  if (pad.btn & B_UP) my = 1; if (pad.btn & B_DOWN) my = -1; if (pad.btn & B_RIGHT) mx = 1;
  // touch: the left half is a stick to walk, the right half drags the view
  bool lt = false; for (int i = 0; i < touch.n; i++) { const TouchPt &p = touch.p[i];
    if (p.id != Me.tid) { Me.tid = p.id; Me.tx0 = p.x; Me.ty0 = p.y; Me.tLook = p.x > W / 2; Me.lx = p.x; Me.ly = p.y; }
    if (Me.tLook) { Me.yaw -= (p.x - Me.lx) * .006; Me.pitch -= (p.y - Me.ly) * .005; Me.lx = p.x; Me.ly = p.y; }
    else { mx = std::max(-1.0, std::min(1.0, (p.x - Me.tx0) / (.12 * U))); my = std::max(-1.0, std::min(1.0, -(p.y - Me.ty0) / (.12 * U))); }
    lt = true; break; }
  if (!lt) Me.tid = -1;
  Me.yaw -= lx * 2.3 * dt; Me.pitch = std::max(-1.2, std::min(1.1, Me.pitch + ly * 1.6 * dt));
  double sp = 7.5 * dt, fx = std::cos(Me.yaw), fy = std::sin(Me.yaw);
  double nx = Me.x + (fx * my + fy * mx) * sp, ny = Me.y + (fy * my - fx * mx) * sp; collide(nx, ny); Me.x = nx; Me.y = ny;
  doorsTick(dt);
}

// ---------------------------------------------------------------- the camera and the draw
static struct { P3 e, f, r, u; double F, sx, sy; } AC;
static void camSet() {
  if (!Me.set) aptReset();
  AC.e = {(float)Me.x, (float)Me.y, (float)EYE};
  AC.f = {(float)(std::cos(Me.yaw) * std::cos(Me.pitch)), (float)(std::sin(Me.yaw) * std::cos(Me.pitch)), (float)std::sin(Me.pitch)};
  AC.r = nrm3(cross3(AC.f, {0, 0, 1})); AC.u = cross3(AC.r, AC.f);
  AC.F = W / 2 / std::tan(36 * 3.14159 / 180); AC.sx = W / 2; AC.sy = H / 2;
}
int aptLook() {
  if (!aptLoaded) return APT_NONE; if (!aptOk) build(); camSet(); int best = APT_NONE; double bc = .9;
  auto seen = [&](P3 p, bool door) {   // nothing but air (no wall, no shut door) between your eyes and it
    std::vector<Rc> W2; for (auto &r : COL) if (r.wall) W2.push_back(r); if (!door) for (auto &d : HD) if (d.a < .15) W2.push_back({d.hx - .1f, d.hy, d.hx + .1f, d.hy + DW, true});
    double x0 = AC.e.x, y0 = AC.e.y, dx = p.x - x0, dy = p.y - y0;
    for (auto &r : W2) { double t0 = 0, t1 = .92; auto slab = [&](double o, double dd, double lo, double hi) { if (std::fabs(dd) < 1e-9) return o > lo && o < hi; double a = (lo - o) / dd, b = (hi - o) / dd; if (a > b) std::swap(a, b); t0 = std::max(t0, a); t1 = std::min(t1, b); return t0 < t1; };
      if (slab(x0, dx, r.x0 + .02, r.x1 - .02) && slab(y0, dy, r.y0 + .02, r.y1 - .02)) return false; }
    return true; };
  std::vector<Hot> hs = HOT; for (int i = 0; i < 2; i++) { P3 m = doorMid(HD[i]); m.z = 4.6f; hs.push_back({APT_HDOOR + i, m, 6}); }
  for (auto &h : hs) { if (!aptBuild && h.id >= 0 && h.id < HOME_NC) continue;
    P3 d = h.p - AC.e; double dl = std::sqrt(dot3(d, d)); if (dl > h.r) continue; double c = dot3(d, AC.f) / std::max(.1, dl), need = dl < 4.5 ? .78 : .9;
    if (c > need && c - need > bc - .9 && seen(h.p, h.id == APT_HDOOR || h.id == APT_HDOOR + 1)) { bc = c - need + .9; best = h.id; } }
  // the floor, in build mode: look down at it (not in the kitchen)
  if (best == APT_NONE && AC.f.z < -.45f) { double t = -AC.e.z / AC.f.z, fx = AC.e.x + AC.f.x * t, fy = AC.e.y + AC.f.y * t; if (aptBuild && t < 14 && !(fx > 18 && fy < 12)) best = 0; }
  return best;
}
static const double NEAR = .25, FAR = 150;
struct T2 { float x[3], y[3], d; uint32_t c; }; static std::vector<T2> Q;   // the no-GPU path's sorted triangles
bool aptReady() { return aptLoaded; }
void aptLoad() { if (!aptOk) build(); aptLoaded = true; }
void aptUnload() {
  plat_draw3d_free((const void *)&AG); std::vector<V3c>().swap(AG); std::vector<Rc>().swap(COL); std::vector<Hot>().swap(HOT); std::vector<T2>().swap(Q); std::vector<V3c>().swap(DY); aptOk = aptLoaded = false; for (auto &d : HD) { d.a = d.tgt = 0; }
}
static void clipM(float *m) {
  const double n = NEAR, f = FAR, A = 2 * AC.F / W, B = 2 * AC.sx / W - 1, Cc = 2 * AC.F / H, D = 1 - 2 * AC.sy / H, E = (f + n) / (f - n), G = -2 * f * n / (f - n);
  const P3 R = AC.r, Uu = AC.u, Fw = AC.f, e = AC.e;
  double rows[4][4] = {{A * R.x + B * Fw.x, A * R.y + B * Fw.y, A * R.z + B * Fw.z, -A * dot3(R, e) - B * dot3(Fw, e)},
    {Cc * Uu.x + D * Fw.x, Cc * Uu.y + D * Fw.y, Cc * Uu.z + D * Fw.z, -Cc * dot3(Uu, e) - D * dot3(Fw, e)},
    {E * Fw.x, E * Fw.y, E * Fw.z, -E * dot3(Fw, e) + G}, {Fw.x, Fw.y, Fw.z, -dot3(Fw, e)}};
  for (int c = 0; c < 4; c++) for (int r = 0; r < 4; r++) m[c * 4 + r] = (float)rows[r][c];
}
void aptDraw() {
  if (!aptLoaded) return; if (!aptOk) build(); camSet();
  ctx.fill("#1a1712"); ctx.fillRect(0, 0, W, H); ctx.flush();
  doorTris();
  if (plat_gpu3d()) { float M[16]; clipM(M); plat_draw3d_static(M, (const void *)&AG, AG.data(), (int)AG.size(), 0, -1, aptVer); plat_draw3d(M, DY.data(), (int)DY.size(), 0, -1); return; }
  // no GPU 3D (the vita2d build): clip at the near plane, project, sort back to front
  Q.clear();
  for (const std::vector<V3c> *L : {&AG, &DY}) for (size_t i = 0; i + 2 < L->size(); i += 3) { const std::vector<V3c> &G = *L;
    P3 cam[3]; for (int k = 0; k < 3; k++) { P3 p = {G[i + k].x, G[i + k].y, G[i + k].z}, v = p - AC.e; cam[k] = {dot3(v, AC.r), dot3(v, AC.u), dot3(v, AC.f)}; }
    P3 out[6]; int no = 0; for (int k = 0; k < 3; k++) { P3 a = cam[k], b = cam[(k + 1) % 3]; float da = a.z - (float)NEAR, db = b.z - (float)NEAR; if (da >= 0) out[no++] = a; if ((da >= 0) != (db >= 0)) out[no++] = a + (b - a) * (da / (da - db)); }
    if (no < 3) continue; float dz = 0; for (int k = 0; k < no; k++) dz = std::max(dz, out[k].z);
    for (int k = 1; k + 1 < no; k++) { T2 t; P3 q[3] = {out[0], out[k], out[k + 1]}; for (int m = 0; m < 3; m++) { t.x[m] = (float)(AC.sx + q[m].x / q[m].z * AC.F); t.y[m] = (float)(AC.sy - q[m].y / q[m].z * AC.F); } t.d = dz; t.c = G[i].c; Q.push_back(t); } }
  std::sort(Q.begin(), Q.end(), [](const T2 &a, const T2 &b) { return a.d > b.d; });
  for (auto &t : Q) ctx.rawTri(t.x[0], t.y[0], t.x[1], t.y[1], t.x[2], t.y[2], t.c);
}
void aptHUD() {
  int lk = aptLook(); bool hot = lk != APT_NONE;
  ctx.fill(hot ? rgba(255, 213, 74, .95) : rgba(255, 255, 255, .7)); ctx.oval(W / 2, H / 2, hot ? 5 : 3, hot ? 5 : 3);
}
const char *APT_JUNKN[APT_NJUNK] = {"THE MOVING BOXES", "THE TRASH BAGS", "THE OFFICE BOXES"};
void aptThrow(int bit) { if (bit < 0 || bit >= APT_NJUNK) return; HOME.junk |= 1 << bit; if (CR) proSave(); aptDirty(); }
#undef C
int aptTris() { if (!aptOk) build(); return (int)AG.size() / 3; }
void aptPos(double &x, double &y) { x = Me.x; y = Me.y; }

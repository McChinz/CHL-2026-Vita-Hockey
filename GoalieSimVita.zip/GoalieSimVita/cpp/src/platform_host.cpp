// CHL 2026 native - desktop test platform: a small software renderer (the same triangles and glyphs the
// Vita gets), scripted input and a simulated 30 FPS clock. Used to play and screenshot the game without a Vita.
#include "platform.h"
#include "audio.h"
#include "canvas.h"
#include "font_metrics.h"
#include <cstdio>
#include <cstdlib>
#include <functional>
#include <vector>

static const int SW = 960, SH = 544;
static std::vector<float> g_fb(SW * SH * 3);
static std::vector<uint8_t> g_font;   // RGBA atlas (tools/font.rgba, made from vita/assets/font.png)
static double g_now = 0;
std::function<void(Pad &, Touch &)> g_hostInput;   // set by the test driver
long g_hostTris = 0, g_hostGlyphs = 0, g_hostCalls = 0;
bool g_hostRaster = true;   // tests switch the (slow) software rasterizer off for frames they do not keep
int g_hostSnd[S_COUNT];

static inline void blend(int x, int y, float r, float g, float b, float a) {
  float *p = &g_fb[(y * SW + x) * 3]; p[0] += (r - p[0]) * a; p[1] += (g - p[1]) * a; p[2] += (b - p[2]) * a;
}
void plat_tris(const float *p, const uint32_t *c, int n, float ox, float oy, float k) {
  g_hostCalls++;
  if (!g_hostRaster) { g_hostTris += n / 3; return; }
  for (int t = 0; t + 2 < n; t += 3) {
    g_hostTris++;
    float X[3], Y[3], R[3], G[3], B[3], A[3];
    for (int i = 0; i < 3; i++) { X[i] = p[(t + i) * 2] * k + ox; Y[i] = p[(t + i) * 2 + 1] * k + oy; uint32_t q = c[t + i];
      R[i] = q & 255; G[i] = (q >> 8) & 255; B[i] = (q >> 16) & 255; A[i] = (q >> 24) / 255.f; }
    float area = (X[1] - X[0]) * (Y[2] - Y[0]) - (X[2] - X[0]) * (Y[1] - Y[0]);
    if (std::fabs(area) < 1e-6f) continue;
    int x0 = std::max(0, (int)std::floor(std::min({X[0], X[1], X[2]}))), x1 = std::min(SW - 1, (int)std::ceil(std::max({X[0], X[1], X[2]})));
    int y0 = std::max(0, (int)std::floor(std::min({Y[0], Y[1], Y[2]}))), y1 = std::min(SH - 1, (int)std::ceil(std::max({Y[0], Y[1], Y[2]})));
    for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) {
      float px = x + .5f, py = y + .5f;
      float w0 = ((X[1] - px) * (Y[2] - py) - (X[2] - px) * (Y[1] - py)) / area;
      float w1 = ((X[2] - px) * (Y[0] - py) - (X[0] - px) * (Y[2] - py)) / area;
      float w2 = 1 - w0 - w1;
      if (w0 < 0 || w1 < 0 || w2 < 0) continue;
      float a = A[0] * w0 + A[1] * w1 + A[2] * w2; if (a <= 0) continue;
      blend(x, y, R[0] * w0 + R[1] * w1 + R[2] * w2, G[0] * w0 + G[1] * w1 + G[2] * w2, B[0] * w0 + B[1] * w1 + B[2] * w2, a);
    }
  }
}
void plat_glyphs(const float *g, int n, uint32_t col, float ox, float oy, float k) {
  g_hostCalls++;
  if (!g_hostRaster) { g_hostGlyphs += n; return; }
  if (g_font.empty()) return;
  float cr = col & 255, cg = (col >> 8) & 255, cb = (col >> 16) & 255, ca = (col >> 24) / 255.f;
  for (int i = 0; i < n; i++, g += 7) {
    g_hostGlyphs++;
    float x = g[0] * k + ox, y = g[1] * k + oy, s = g[6] * k; int u0 = (int)g[2], v0 = (int)g[3], gw = (int)g[4], gh = (int)g[5];
    int X0 = (int)std::floor(x), Y0 = (int)std::floor(y), X1 = (int)std::ceil(x + gw * s), Y1 = (int)std::ceil(y + gh * s);
    for (int py = std::max(0, Y0); py < std::min(SH, Y1); py++) for (int px = std::max(0, X0); px < std::min(SW, X1); px++) {
      int u = u0 + (int)((px + .5f - x) / s), v = v0 + (int)((py + .5f - y) / s);
      if (u < u0 || v < v0 || u >= u0 + gw || v >= v0 + gh || u >= fontm::TEXW || v >= fontm::TEXH) continue;
      float a = g_font[(v * fontm::TEXW + u) * 4 + 3] / 255.f * ca; if (a > 0) blend(px, py, cr, cg, cb, a);
    }
  }
}
// free glyph quads: two triangles, the atlas sampled through barycentric coordinates
void plat_glyph_quads(const float *q, int n, uint32_t col) {
  g_hostCalls++;
  if (!g_hostRaster) { g_hostGlyphs += n; return; }
  if (g_font.empty()) return;
  float cr = col & 255, cg = (col >> 8) & 255, cb = (col >> 16) & 255, ca = (col >> 24) / 255.f;
  for (int i = 0; i < n; i++, q += 12) {
    g_hostGlyphs++;
    const float U[4] = {q[8], q[10], q[10], q[8]}, V[4] = {q[9], q[9], q[11], q[11]};
    const int TR[2][3] = {{0, 1, 2}, {0, 2, 3}};
    for (auto &t : TR) {
      float x0 = q[t[0] * 2], y0 = q[t[0] * 2 + 1], x1 = q[t[1] * 2], y1 = q[t[1] * 2 + 1], x2 = q[t[2] * 2], y2 = q[t[2] * 2 + 1];
      float den = (y1 - y2) * (x0 - x2) + (x2 - x1) * (y0 - y2); if (std::fabs(den) < 1e-6f) continue;
      int X0 = std::max(0, (int)std::floor(std::min({x0, x1, x2}))), X1 = std::min(SW - 1, (int)std::ceil(std::max({x0, x1, x2})));
      int Y0 = std::max(0, (int)std::floor(std::min({y0, y1, y2}))), Y1 = std::min(SH - 1, (int)std::ceil(std::max({y0, y1, y2})));
      for (int py = Y0; py <= Y1; py++) for (int px = X0; px <= X1; px++) {
        float fx = px + .5f, fy = py + .5f, a = ((y1 - y2) * (fx - x2) + (x2 - x1) * (fy - y2)) / den, b = ((y2 - y0) * (fx - x2) + (x0 - x2) * (fy - y2)) / den, c = 1 - a - b;
        if (a < 0 || b < 0 || c < 0) continue;
        int u = (int)(a * U[t[0]] + b * U[t[1]] + c * U[t[2]]), v = (int)(a * V[t[0]] + b * V[t[1]] + c * V[t[2]]);
        if (u < 0 || v < 0 || u >= fontm::TEXW || v >= fontm::TEXH) continue;
        float al = g_font[(v * fontm::TEXW + u) * 4 + 3] / 255.f * ca; if (al > 0) blend(px, py, cr, cg, cb, al);
      }
    }
  }
}
int snd_play(int id, float, float, bool) { if (id >= 0 && id < S_COUNT) g_hostSnd[id]++; return -1; }
void snd_set(int, float) {}
void snd_stop(int) {}

bool plat_init() {
  const char *fp = getenv("CHL_FONT"); FILE *f = fopen(fp ? fp : "font.rgba", "rb");
  if (f) { g_font.resize(fontm::TEXW * fontm::TEXH * 4); if (fread(g_font.data(), 1, g_font.size(), f) != g_font.size()) g_font.clear(); fclose(f); }
  return true;
}
void plat_shutdown() {}
bool plat_running() { return true; }
// the GPU 3D path, emulated (CHL_GPU3D=1): a software rasterizer with a depth buffer, to test what the vitaGL
// build sends (the same clip matrix and passes)
static std::vector<float> g_zb(SW * SH, 1.f);
long g_host3d = 0;
bool plat_gpu3d() { static bool on = getenv("CHL_GPU3D") != nullptr; return on; }
// (like the GPU: triangles crossing the near plane are clipped in clip space, not dropped)
struct HostTex { int w = 0, h = 0; std::vector<unsigned char> d; }; static HostTex g_htex[8];
void plat_tex(int slot, int w, int h, const unsigned char *rgba) { if (slot < 0 || slot >= 8) return; g_htex[slot].w = w; g_htex[slot].h = h; g_htex[slot].d.assign(rgba, rgba + (size_t)w * h * 4); }
// UQ: u/w, v/w, 1/w at each corner (perspective-correct texturing), T: the texture or null
static void rasterTri(const float X[3], const float Y[3], const float Z[3], const float C[3][4], int mode, const float UQ[3][3], const HostTex *T) {
  float area = (X[1] - X[0]) * (Y[2] - Y[0]) - (X[2] - X[0]) * (Y[1] - Y[0]); if (std::fabs(area) < 1e-6f) return;
  int x0 = std::max(0, (int)std::floor(std::min({X[0], X[1], X[2]}))), x1 = std::min(SW - 1, (int)std::ceil(std::max({X[0], X[1], X[2]})));
  int y0 = std::max(0, (int)std::floor(std::min({Y[0], Y[1], Y[2]}))), y1 = std::min(SH - 1, (int)std::ceil(std::max({Y[0], Y[1], Y[2]})));
  for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) {
    float px = x + .5f, py = y + .5f, w0 = ((X[1] - px) * (Y[2] - py) - (X[2] - px) * (Y[1] - py)) / area, w1 = ((X[2] - px) * (Y[0] - py) - (X[0] - px) * (Y[2] - py)) / area, w2 = 1 - w0 - w1;
    if (w0 < 0 || w1 < 0 || w2 < 0) continue;
    float z = Z[0] * w0 + Z[1] * w1 + Z[2] * w2; float &zb = g_zb[y * SW + x];
    if (z > zb) continue; if (mode == 0) zb = z;
    float r = C[0][0] * w0 + C[1][0] * w1 + C[2][0] * w2, g = C[0][1] * w0 + C[1][1] * w1 + C[2][1] * w2, b = C[0][2] * w0 + C[1][2] * w1 + C[2][2] * w2, a = C[0][3] * w0 + C[1][3] * w1 + C[2][3] * w2;
    if (T) { float q = UQ[0][2] * w0 + UQ[1][2] * w1 + UQ[2][2] * w2, u = (UQ[0][0] * w0 + UQ[1][0] * w1 + UQ[2][0] * w2) / q, v = (UQ[0][1] * w0 + UQ[1][1] * w1 + UQ[2][1] * w2) / q;
      float fx = u * T->w - .5f, fy = v * T->h - .5f; int ix = (int)std::floor(fx), iy = (int)std::floor(fy); float tx = fx - ix, ty = fy - iy, t4[4] = {0, 0, 0, 0};
      for (int k = 0; k < 4; k++) { int sx = ((ix + (k & 1)) % T->w + T->w) % T->w, sy = ((iy + (k >> 1)) % T->h + T->h) % T->h; float wgt = ((k & 1) ? tx : 1 - tx) * ((k >> 1) ? ty : 1 - ty);
        const unsigned char *p = &T->d[((size_t)sy * T->w + sx) * 4]; for (int c = 0; c < 4; c++) t4[c] += p[c] * wgt; }
      r *= t4[0] / 255; g *= t4[1] / 255; b *= t4[2] / 255; a *= t4[3] / 255; }
    if (mode == 3) { float *f = &g_fb[(y * SW + x) * 3]; f[0] = std::min(f[0], r); f[1] = std::min(f[1], g); f[2] = std::min(f[2], b); continue; }
    blend(x, y, r, g, b, a); }
}
void plat_draw3d(const float *m, const V3c *v, int n, int mode, int tex);
void plat_draw3d_free(const void *) {}
void plat_draw3d_static(const float *m, const void *, const V3c *v, int n, int mode, int tex, uint32_t) { plat_draw3d(m, v, n, mode, tex); }
void plat_draw3d(const float *m, const V3c *v, int n, int mode, int tex) {
  struct CV { float x, y, z, w, c[4], u, v; };
  const HostTex *T = tex >= 0 && tex < 8 && g_htex[tex].w ? &g_htex[tex] : nullptr;
  for (int t = 0; t + 2 < n; t += 3) {
    g_host3d++; if (!g_hostRaster) continue;
    CV in[3];
    for (int i = 0; i < 3; i++) { const V3c &q = v[t + i]; CV &o = in[i]; o.x = m[0] * q.x + m[4] * q.y + m[8] * q.z + m[12]; o.y = m[1] * q.x + m[5] * q.y + m[9] * q.z + m[13];
      o.z = m[2] * q.x + m[6] * q.y + m[10] * q.z + m[14]; o.w = m[3] * q.x + m[7] * q.y + m[11] * q.z + m[15];
      o.u = q.u; o.v = q.v; uint32_t c = q.c; o.c[0] = c & 255; o.c[1] = (c >> 8) & 255; o.c[2] = (c >> 16) & 255; o.c[3] = (c >> 24) / 255.f; }
    CV out[6]; int k = 0; const float E = .05f;
    for (int i = 0; i < 3; i++) { const CV &A = in[i], &B = in[(i + 1) % 3]; bool ia = A.w > E, ib = B.w > E;
      if (ia) out[k++] = A;
      if (ia != ib) { float tt = (A.w - E) / (A.w - B.w); CV r; r.x = A.x + (B.x - A.x) * tt; r.y = A.y + (B.y - A.y) * tt; r.z = A.z + (B.z - A.z) * tt; r.w = A.w + (B.w - A.w) * tt;
        r.u = A.u + (B.u - A.u) * tt; r.v = A.v + (B.v - A.v) * tt; for (int j = 0; j < 4; j++) r.c[j] = A.c[j] + (B.c[j] - A.c[j]) * tt; out[k++] = r; } }
    for (int i = 1; i + 1 < k; i++) { const CV *P[3] = {&out[0], &out[i], &out[i + 1]}; float X[3], Y[3], Z[3], C[3][4], UQ[3][3];
      for (int j = 0; j < 3; j++) { X[j] = (P[j]->x / P[j]->w + 1) * .5f * SW; Y[j] = (1 - P[j]->y / P[j]->w) * .5f * SH; Z[j] = P[j]->z / P[j]->w; for (int q = 0; q < 4; q++) C[j][q] = P[j]->c[q]; UQ[j][0] = P[j]->u / P[j]->w; UQ[j][1] = P[j]->v / P[j]->w; UQ[j][2] = 1 / P[j]->w; }
      rasterTri(X, Y, Z, C, mode, UQ, T); }
  }
}
void plat_begin_frame(uint32_t clear) {
  std::fill(g_zb.begin(), g_zb.end(), 1.f);
  if (!g_hostRaster) return;
  float r = clear & 255, g = (clear >> 8) & 255, b = (clear >> 16) & 255;
  for (int i = 0; i < SW * SH; i++) { g_fb[i * 3] = r; g_fb[i * 3 + 1] = g; g_fb[i * 3 + 2] = b; }
}
void plat_end_frame() { static double hz = getenv("CHL_HZ") ? atof(getenv("CHL_HZ")) : 30; g_now += 1000.0 / hz; }
double plat_now_ms() { return g_now; }
void plat_input(Pad &pad, Touch &touch) { pad = Pad(); touch = Touch(); if (g_hostInput) g_hostInput(pad, touch); }
void plat_log(const std::string &s) { fprintf(stderr, "[log] %s\n", s.c_str()); }
bool plat_read_file(const std::string &path, std::string &out) {
  FILE *f = fopen(path.c_str(), "rb"); if (!f) return false; char b[4096]; size_t n; out.clear();
  while ((n = fread(b, 1, sizeof b, f)) > 0) out.append(b, n); fclose(f); return true;
}
bool plat_write_file(const std::string &path, const std::string &data) { FILE *f = fopen(path.c_str(), "wb"); if (!f) return false; fwrite(data.data(), 1, data.size(), f); fclose(f); return true; }
#include <dirent.h>
std::vector<std::string> plat_list_dir(const std::string &dir) {
  std::vector<std::string> o; DIR *d = opendir(dir.c_str()); if (!d) return o;
  while (dirent *e = readdir(d)) { if (e->d_name[0] != '.' && e->d_type != DT_DIR) o.push_back(e->d_name); }
  closedir(d); return o;
}
std::string plat_data_dir() { const char *e = getenv("CHL_DATA"); return e ? std::string(e) + "/" : "./"; }
std::string plat_legacy_dir() { const char *e = getenv("CHL_LEGACY"); return e ? std::string(e) + "/" : "./legacy/"; }
// test hook: save the current frame as a PPM
void host_shot(const char *path) {
  FILE *f = fopen(path, "wb"); if (!f) return; fprintf(f, "P6\n%d %d\n255\n", SW, SH);
  std::vector<uint8_t> o(SW * SH * 3); for (size_t i = 0; i < o.size(); i++) o[i] = (uint8_t)std::max(0.f, std::min(255.f, g_fb[i] + .5f));
  fwrite(o.data(), 1, o.size(), f); fclose(f);
}

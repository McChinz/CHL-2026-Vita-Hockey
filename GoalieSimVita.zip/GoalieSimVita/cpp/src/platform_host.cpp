// CHL 2026 native - desktop test platform: a small software renderer (the same triangles and glyphs the
// Vita gets), scripted input and a simulated 30 FPS clock. Used to play and screenshot the game without a Vita.
#include "platform.h"
#include "audio.h"
#include "canvas.h"
#include "font_metrics.h"
#include <cstdio>
#include <cstdlib>
#include <functional>
#include <vector>

static const int SW = 960, SH = 544;
static std::vector<float> g_fb(SW * SH * 3);
static std::vector<uint8_t> g_font;   // RGBA atlas (tools/font.rgba, made from vita/assets/font.png)
static double g_now = 0;
std::function<void(Pad &, Touch &)> g_hostInput;   // set by the test driver
long g_hostTris = 0, g_hostGlyphs = 0, g_hostCalls = 0;
bool g_hostRaster = true;   // tests switch the (slow) software rasterizer off for frames they do not keep
int g_hostSnd[S_COUNT];

static inline void blend(int x, int y, float r, float g, float b, float a) {
  float *p = &g_fb[(y * SW + x) * 3]; p[0] += (r - p[0]) * a; p[1] += (g - p[1]) * a; p[2] += (b - p[2]) * a;
}
void plat_tris(const float *p, const uint32_t *c, int n, float ox, float oy, float k) {
  g_hostCalls++;
  if (!g_hostRaster) { g_hostTris += n / 3; return; }
  for (int t = 0; t + 2 < n; t += 3) {
    g_hostTris++;
    float X[3], Y[3], R[3], G[3], B[3], A[3];
    for (int i = 0; i < 3; i++) { X[i] = p[(t + i) * 2] * k + ox; Y[i] = p[(t + i) * 2 + 1] * k + oy; uint32_t q = c[t + i];
      R[i] = q & 255; G[i] = (q >> 8) & 255; B[i] = (q >> 16) & 255; A[i] = (q >> 24) / 255.f; }
    float area = (X[1] - X[0]) * (Y[2] - Y[0]) - (X[2] - X[0]) * (Y[1] - Y[0]);
    if (std::fabs(area) < 1e-6f) continue;
    int x0 = std::max(0, (int)std::floor(std::min({X[0], X[1], X[2]}))), x1 = std::min(SW - 1, (int)std::ceil(std::max({X[0], X[1], X[2]})));
    int y0 = std::max(0, (int)std::floor(std::min({Y[0], Y[1], Y[2]}))), y1 = std::min(SH - 1, (int)std::ceil(std::max({Y[0], Y[1], Y[2]})));
    for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) {
      float px = x + .5f, py = y + .5f;
      float w0 = ((X[1] - px) * (Y[2] - py) - (X[2] - px) * (Y[1] - py)) / area;
      float w1 = ((X[2] - px) * (Y[0] - py) - (X[0] - px) * (Y[2] - py)) / area;
      float w2 = 1 - w0 - w1;
      if (w0 < 0 || w1 < 0 || w2 < 0) continue;
      float a = A[0] * w0 + A[1] * w1 + A[2] * w2; if (a <= 0) continue;
      blend(x, y, R[0] * w0 + R[1] * w1 + R[2] * w2, G[0] * w0 + G[1] * w1 + G[2] * w2, B[0] * w0 + B[1] * w1 + B[2] * w2, a);
    }
  }
}
void plat_glyphs(const float *g, int n, uint32_t col, float ox, float oy, float k) {
  g_hostCalls++;
  if (!g_hostRaster) { g_hostGlyphs += n; return; }
  if (g_font.empty()) return;
  float cr = col & 255, cg = (col >> 8) & 255, cb = (col >> 16) & 255, ca = (col >> 24) / 255.f;
  for (int i = 0; i < n; i++, g += 7) {
    g_hostGlyphs++;
    float x = g[0] * k + ox, y = g[1] * k + oy, s = g[6] * k; int u0 = (int)g[2], v0 = (int)g[3], gw = (int)g[4], gh = (int)g[5];
    int X0 = (int)std::floor(x), Y0 = (int)std::floor(y), X1 = (int)std::ceil(x + gw * s), Y1 = (int)std::ceil(y + gh * s);
    for (int py = std::max(0, Y0); py < std::min(SH, Y1); py++) for (int px = std::max(0, X0); px < std::min(SW, X1); px++) {
      int u = u0 + (int)((px + .5f - x) / s), v = v0 + (int)((py + .5f - y) / s);
      if (u < u0 || v < v0 || u >= u0 + gw || v >= v0 + gh || u >= fontm::TEXW || v >= fontm::TEXH) continue;
      float a = g_font[(v * fontm::TEXW + u) * 4 + 3] / 255.f * ca; if (a > 0) blend(px, py, cr, cg, cb, a);
    }
  }
}
int snd_play(int id, float, float, bool) { if (id >= 0 && id < S_COUNT) g_hostSnd[id]++; return -1; }
void snd_set(int, float) {}
void snd_stop(int) {}

bool plat_init() {
  const char *fp = getenv("CHL_FONT"); FILE *f = fopen(fp ? fp : "font.rgba", "rb");
  if (f) { g_font.resize(fontm::TEXW * fontm::TEXH * 4); if (fread(g_font.data(), 1, g_font.size(), f) != g_font.size()) g_font.clear(); fclose(f); }
  return true;
}
void plat_shutdown() {}
bool plat_running() { return true; }
// the GPU 3D path, emulated (CHL_GPU3D=1): a software rasterizer with a depth buffer, to test what the vitaGL
// build sends (the same clip matrix and passes)
static std::vector<float> g_zb(SW * SH, 1.f);
long g_host3d = 0;
bool plat_gpu3d() { static bool on = getenv("CHL_GPU3D") != nullptr; return on; }
void plat_draw3d(const float *m, const V3c *v, int n, int mode) {
  for (int t = 0; t + 2 < n; t += 3) {
    g_host3d++; if (!g_hostRaster) continue;
    float X[3], Y[3], Z[3]; bool bad = false;
    for (int i = 0; i < 3; i++) { const V3c &q = v[t + i]; float cx = m[0] * q.x + m[4] * q.y + m[8] * q.z + m[12], cy = m[1] * q.x + m[5] * q.y + m[9] * q.z + m[13],
        cz = m[2] * q.x + m[6] * q.y + m[10] * q.z + m[14], cw = m[3] * q.x + m[7] * q.y + m[11] * q.z + m[15];
      if (cw <= 1e-4f) { bad = true; break; } X[i] = (cx / cw + 1) * .5f * SW; Y[i] = (1 - cy / cw) * .5f * SH; Z[i] = cz / cw; }
    if (bad) continue;
    uint32_t q = v[t].c; float r = q & 255, g = (q >> 8) & 255, b = (q >> 16) & 255, a = (q >> 24) / 255.f;
    float area = (X[1] - X[0]) * (Y[2] - Y[0]) - (X[2] - X[0]) * (Y[1] - Y[0]); if (std::fabs(area) < 1e-6f) continue;
    int x0 = std::max(0, (int)std::floor(std::min({X[0], X[1], X[2]}))), x1 = std::min(SW - 1, (int)std::ceil(std::max({X[0], X[1], X[2]})));
    int y0 = std::max(0, (int)std::floor(std::min({Y[0], Y[1], Y[2]}))), y1 = std::min(SH - 1, (int)std::ceil(std::max({Y[0], Y[1], Y[2]})));
    for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) {
      float px = x + .5f, py = y + .5f, w0 = ((X[1] - px) * (Y[2] - py) - (X[2] - px) * (Y[1] - py)) / area, w1 = ((X[2] - px) * (Y[0] - py) - (X[0] - px) * (Y[2] - py)) / area, w2 = 1 - w0 - w1;
      if (w0 < 0 || w1 < 0 || w2 < 0) continue;
      float z = Z[0] * w0 + Z[1] * w1 + Z[2] * w2; float &zb = g_zb[y * SW + x];
      if (z > zb) continue; if (mode == 0) zb = z; blend(x, y, r, g, b, a); }
  }
}
void plat_begin_frame(uint32_t clear) {
  std::fill(g_zb.begin(), g_zb.end(), 1.f);
  if (!g_hostRaster) return;
  float r = clear & 255, g = (clear >> 8) & 255, b = (clear >> 16) & 255;
  for (int i = 0; i < SW * SH; i++) { g_fb[i * 3] = r; g_fb[i * 3 + 1] = g; g_fb[i * 3 + 2] = b; }
}
void plat_end_frame() { static double hz = getenv("CHL_HZ") ? atof(getenv("CHL_HZ")) : 30; g_now += 1000.0 / hz; }
double plat_now_ms() { return g_now; }
void plat_input(Pad &pad, Touch &touch) { pad = Pad(); touch = Touch(); if (g_hostInput) g_hostInput(pad, touch); }
void plat_log(const std::string &s) { fprintf(stderr, "[log] %s\n", s.c_str()); }
bool plat_read_file(const std::string &path, std::string &out) {
  FILE *f = fopen(path.c_str(), "rb"); if (!f) return false; char b[4096]; size_t n; out.clear();
  while ((n = fread(b, 1, sizeof b, f)) > 0) out.append(b, n); fclose(f); return true;
}
bool plat_write_file(const std::string &path, const std::string &data) { FILE *f = fopen(path.c_str(), "wb"); if (!f) return false; fwrite(data.data(), 1, data.size(), f); fclose(f); return true; }
std::string plat_data_dir() { const char *e = getenv("CHL_DATA"); return e ? std::string(e) + "/" : "./"; }
std::string plat_legacy_dir() { const char *e = getenv("CHL_LEGACY"); return e ? std::string(e) + "/" : "./legacy/"; }
// test hook: save the current frame as a PPM
void host_shot(const char *path) {
  FILE *f = fopen(path, "wb"); if (!f) return; fprintf(f, "P6\n%d %d\n255\n", SW, SH);
  std::vector<uint8_t> o(SW * SH * 3); for (size_t i = 0; i < o.size(); i++) o[i] = (uint8_t)std::max(0.f, std::min(255.f, g_fb[i] + .5f));
  fwrite(o.data(), 1, o.size(), f); fclose(f);
}

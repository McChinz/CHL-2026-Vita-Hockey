# Native port: plan and conventions (working notes)

The legacy JS game (`web/goalie.html`, "legacy") is the reference. The native C++ build in `cpp/` is now
THE project; the legacy files stay only as reference. Goal: 1:1 parity, then new work happens here.

## Order of work (user's request, Nov 13 2026)
1. Main menu (modes screen) identical to legacy (same options, same look).
2. Ultimate Franchise 1:1: every real roster (TD table) + legends + 2026 draft class (new: McKenna, Stenberg...),
   goalies + ratings, packs/shop/inventory, roster editor, card menu + EXAMINE (flip, all ratings, perks,
   card stats "WITH YOUR TEAM"), opponents, Road to the Cup, salary cap, quick sell / dupes / upgrades,
   result screen + coins, save slots. Same save JSON as legacy (chl_ut.json) -> legacy saves import.
3. Controls change (all modes): L = pass modifier (hold L: Square/Triangle/Circle icons over teammates,
   press one = pass to him). Spin = quick 360 rotation of the left stick. "!" over a teammate calling for the
   puck (open net / better look). Touch: menus only (no on-ice touch).
4. Physics parity check vs legacy (bouncing pucks over sticks, chop, edge roll, skate deflections, board battles,
   carrier ring, rebounds...).
5. Be a Pro 1:1. 6. Goalie mode + practice + everything else.

## Status (end of the UT pass)
- Done: 1, 2, 3. 4 checked: every skater-engine function of the legacy forward game is in the native build
  except Be a Pro's bench view (bc*), practice drills (skDrill*), goalie mode (ug*/gc*) and on-ice touch
  (removed on purpose). skCheckStick / skStick / skDirShot / skLines (menu) are dead code in legacy.
- Parity checks (host build): `chl_host utcheck` vs node on goalie.html: all 162 sampled legacy cards (3 rarities
  each) identical (ratings, archetype, salary, perks); CPU team OVRs for 40 seeds identical; utAuto identical.
- Deliberate fixes vs legacy: SECRET can now drop from packs (legacy utRoll stopped at LEGENDARY), bench
  energy no longer carries over between Ultimate Franchise games.
- UT state is typed C++ (ut.h) serialized to the legacy JSON shape (json.h) - not J-backed.
- Draft class: in packs (UT_CUR), never in starter cards or CPU rosters (keeps legacy CPU teams identical).

## Conventions
- JSON (`json.h`): dynamic `J` mirrors JS objects; UT / career state lives in J so code ports line-by-line and
  the save files keep the legacy format. Native data dir ux0:data/GoalieSimNative; first run imports
  ux0:data/GoalieSim/*.json (legacy saves).
- Randomness: `rnd()` = Math.random. `withSeed(seed, fn)` swaps in the JS skRng (double-precision quirk
  reproduced) so card ratings / CPU teams are identical to legacy.
- JS evaluation order matters wherever Math.random is called more than once in an expression: sequence it.
- UI helpers mirror JS: tx(), txWrap(), ui(), menuItem(), footHints(), utFitTx(), cached(), rr().

// Goalie Sim - PS Vita host
// Runs the web game's JavaScript (web/goalie.html) inside QuickJS and draws it with vita2d.
// The JS side (js/vita_shim.js) turns Canvas 2D calls into triangles and glyph quads;
// this file only provides the few native hooks it needs.

#include <psp2/kernel/processmgr.h>
#include <psp2/ctrl.h>
#include <psp2/touch.h>
#include <psp2/power.h>
#include <psp2/io/stat.h>
#include <vita2d.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include "quickjs.h"

// Memory: QuickJS heap lives in the newlib heap; give the main thread a deep stack for JS recursion.
int _newlib_heap_size_user = 160 * 1024 * 1024;
unsigned int sceUserMainThreadStackSize = 4 * 1024 * 1024;

#define DATA_DIR "ux0:data/GoalieSim"
#define SCREEN_W 960
#define SCREEN_H 544

static vita2d_texture *g_font_tex = NULL;
static vita2d_pgf *g_pgf = NULL;
static char g_err[8192];
static int g_has_err = 0;

// vita2d references the shared-framebuffer API, which it only uses when running as a system
// overlay (never the case here). These no-op versions satisfy the linker on SDKs that don't
// ship a stub library for it.
int sceSharedFbOpen(int index) { (void)index; return -1; }
int sceSharedFbClose(int fb) { (void)fb; return 0; }
int sceSharedFbBegin(int fb, void *info) { (void)fb; (void)info; return -1; }
int sceSharedFbEnd(int fb) { (void)fb; return 0; }
int sceSharedFbGetInfo(int fb, void *info) { (void)fb; (void)info; return -1; }

// ---------------------------------------------------------------- helpers
static char *read_file(const char *path, size_t *out_len) {
  FILE *f = fopen(path, "rb");
  if (!f) return NULL;
  fseek(f, 0, SEEK_END);
  long n = ftell(f);
  fseek(f, 0, SEEK_SET);
  if (n < 0) { fclose(f); return NULL; }
  char *buf = (char *)malloc((size_t)n + 1);
  if (!buf) { fclose(f); return NULL; }
  size_t got = fread(buf, 1, (size_t)n, f);
  fclose(f);
  buf[got] = 0;
  if (out_len) *out_len = got;
  return buf;
}

static void append_log(const char *s) {
  FILE *f = fopen(DATA_DIR "/log.txt", "a");
  if (!f) return;
  fputs(s, f);
  fputc('\n', f);
  fclose(f);
}

static void capture_error(JSContext *ctx, const char *where) {
  JSValue ex = JS_GetException(ctx);
  const char *msg = JS_ToCString(ctx, ex);
  const char *stack = NULL;
  JSValue st = JS_UNDEFINED;
  if (JS_IsObject(ex)) {
    st = JS_GetPropertyStr(ctx, ex, "stack");
    if (!JS_IsUndefined(st)) stack = JS_ToCString(ctx, st);
  }
  snprintf(g_err, sizeof(g_err), "%s: %s\n%s", where, msg ? msg : "(unknown error)", stack ? stack : "");
  append_log(g_err);
  if (stack) JS_FreeCString(ctx, stack);
  if (msg) JS_FreeCString(ctx, msg);
  JS_FreeValue(ctx, st);
  JS_FreeValue(ctx, ex);
  g_has_err = 1;
}

static int eval_file(JSContext *ctx, const char *path) {
  size_t len = 0;
  char *src = read_file(path, &len);
  if (!src) {
    snprintf(g_err, sizeof(g_err), "Could not open %s", path);
    g_has_err = 1;
    return -1;
  }
  JSValue r = JS_Eval(ctx, src, len, path, JS_EVAL_TYPE_GLOBAL);
  free(src);
  if (JS_IsException(r)) { capture_error(ctx, path); return -1; }
  JS_FreeValue(ctx, r);
  return 0;
}

// ---------------------------------------------------------------- native functions for the shim
static JSValue js_now(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  return JS_NewFloat64(ctx, (double)sceKernelGetProcessTimeWide() / 1000.0);
}

static JSValue js_log(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  if (argc < 1) return JS_UNDEFINED;
  const char *s = JS_ToCString(ctx, argv[0]);
  if (s) { append_log(s); JS_FreeCString(ctx, s); }
  return JS_UNDEFINED;
}

static JSValue js_read_file(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  if (argc < 1) return JS_NULL;
  const char *path = JS_ToCString(ctx, argv[0]);
  if (!path) return JS_NULL;
  size_t len = 0;
  char *buf = read_file(path, &len);
  JS_FreeCString(ctx, path);
  if (!buf) return JS_NULL;
  JSValue s = JS_NewStringLen(ctx, buf, len);
  free(buf);
  return s;
}

static JSValue js_write_file(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  if (argc < 2) return JS_FALSE;
  const char *path = JS_ToCString(ctx, argv[0]);
  size_t len = 0;
  const char *data = JS_ToCStringLen(ctx, &len, argv[1]);
  int ok = 0;
  if (path && data) {
    // write to a temp file first so a crash mid-save can't corrupt the save
    char tmp[512];
    snprintf(tmp, sizeof(tmp), "%s.tmp", path);
    FILE *f = fopen(tmp, "wb");
    if (f) {
      ok = fwrite(data, 1, len, f) == len;
      fclose(f);
      if (ok) { remove(path); ok = rename(tmp, path) == 0; }
    }
  }
  if (data) JS_FreeCString(ctx, data);
  if (path) JS_FreeCString(ctx, path);
  return JS_NewBool(ctx, ok);
}

static JSValue js_remove_file(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  if (argc < 1) return JS_UNDEFINED;
  const char *path = JS_ToCString(ctx, argv[0]);
  if (path) { remove(path); JS_FreeCString(ctx, path); }
  return JS_UNDEFINED;
}

// __drawTris(xyBuffer, colorBuffer, vertexCount): colored triangles, colors packed ABGR (vita2d RGBA8 layout)
static JSValue js_draw_tris(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  if (argc < 3) return JS_UNDEFINED;
  size_t plen = 0, clen = 0;
  float *p = (float *)JS_GetArrayBuffer(ctx, &plen, argv[0]);
  uint32_t *c = (uint32_t *)JS_GetArrayBuffer(ctx, &clen, argv[1]);
  int32_t n = 0;
  if (!p || !c || JS_ToInt32(ctx, &n, argv[2]) < 0) return JS_EXCEPTION;
  if ((size_t)n > plen / (2 * sizeof(float))) n = (int32_t)(plen / (2 * sizeof(float)));
  if ((size_t)n > clen / sizeof(uint32_t)) n = (int32_t)(clen / sizeof(uint32_t));
  n -= n % 3;
  if (n <= 0) return JS_UNDEFINED;
  vita2d_color_vertex *v = (vita2d_color_vertex *)vita2d_pool_memalign(n * sizeof(vita2d_color_vertex), sizeof(vita2d_color_vertex));
  if (!v) return JS_UNDEFINED;  // frame pool exhausted; skip rather than crash
  for (int i = 0; i < n; i++) {
    v[i].x = p[i * 2];
    v[i].y = p[i * 2 + 1];
    v[i].z = 0.5f;
    v[i].color = c[i];
  }
  vita2d_draw_array(SCE_GXM_PRIMITIVE_TRIANGLES, v, n);
  return JS_UNDEFINED;
}

// __drawGlyphs(buffer of [dx,dy,u,v,w,h,scale]*n, n, color)
static JSValue js_draw_glyphs(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  if (argc < 3 || !g_font_tex) return JS_UNDEFINED;
  size_t blen = 0;
  float *b = (float *)JS_GetArrayBuffer(ctx, &blen, argv[0]);
  int32_t n = 0;
  uint32_t color = 0;
  if (!b || JS_ToInt32(ctx, &n, argv[1]) < 0 || JS_ToUint32(ctx, &color, argv[2]) < 0) return JS_EXCEPTION;
  if ((size_t)n > blen / (7 * sizeof(float))) n = (int32_t)(blen / (7 * sizeof(float)));
  for (int i = 0; i < n; i++) {
    const float *g = b + i * 7;
    vita2d_draw_texture_tint_part_scale(g_font_tex, g[0], g[1], g[2], g[3], g[4], g[5], g[6], g[6], color);
  }
  return JS_UNDEFINED;
}

// __input() -> [nFront, id,x,y..., nBack, id,x,y..., buttons]
// Touch coordinates are converted to the 960x544 screen space. Buttons: 1=L 2=R 4=START 8=SELECT 16=CROSS 32=CIRCLE
static JSValue js_input(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  SceTouchData tf, tb;
  SceCtrlData pad;
  memset(&tf, 0, sizeof(tf));
  memset(&tb, 0, sizeof(tb));
  memset(&pad, 0, sizeof(pad));
  sceTouchPeek(SCE_TOUCH_PORT_FRONT, &tf, 1);
  sceTouchPeek(SCE_TOUCH_PORT_BACK, &tb, 1);
  sceCtrlPeekBufferPositive(0, &pad, 1);

  JSValue arr = JS_NewArray(ctx);
  uint32_t k = 0;
  JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, (int32_t)tf.reportNum));
  for (unsigned i = 0; i < tf.reportNum; i++) {
    JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, tf.report[i].id));
    JS_SetPropertyUint32(ctx, arr, k++, JS_NewFloat64(ctx, tf.report[i].x * (double)SCREEN_W / 1920.0));
    JS_SetPropertyUint32(ctx, arr, k++, JS_NewFloat64(ctx, tf.report[i].y * (double)SCREEN_H / 1088.0));
  }
  JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, (int32_t)tb.reportNum));
  for (unsigned i = 0; i < tb.reportNum; i++) {
    double by = ((double)tb.report[i].y - 108.0) * SCREEN_H / (889.0 - 108.0);
    JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, tb.report[i].id));
    JS_SetPropertyUint32(ctx, arr, k++, JS_NewFloat64(ctx, tb.report[i].x * (double)SCREEN_W / 1920.0));
    JS_SetPropertyUint32(ctx, arr, k++, JS_NewFloat64(ctx, by));
  }
  int32_t bits = 0;
  if (pad.buttons & SCE_CTRL_LTRIGGER) bits |= 1;
  if (pad.buttons & SCE_CTRL_RTRIGGER) bits |= 2;
  if (pad.buttons & SCE_CTRL_START) bits |= 4;
  if (pad.buttons & SCE_CTRL_SELECT) bits |= 8;
  if (pad.buttons & SCE_CTRL_CROSS) bits |= 16;
  if (pad.buttons & SCE_CTRL_CIRCLE) bits |= 32;
  JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, bits));
  return arr;
}

static void add_fn(JSContext *ctx, JSValue global, const char *name, JSCFunction *fn, int nargs) {
  JS_SetPropertyStr(ctx, global, name, JS_NewCFunction(ctx, fn, name, nargs));
}

// ---------------------------------------------------------------- error screen
static void draw_error(void) {
  vita2d_draw_rectangle(0, 0, SCREEN_W, SCREEN_H, RGBA8(20, 8, 12, 255));
  if (!g_pgf) return;
  vita2d_pgf_draw_text(g_pgf, 20, 34, RGBA8(255, 120, 120, 255), 1.0f, "Goalie Sim hit a script error. Hold SELECT + START to exit.");
  vita2d_pgf_draw_text(g_pgf, 20, 58, RGBA8(200, 200, 200, 255), 0.8f, "(Also written to ux0:data/GoalieSim/log.txt)");
  char line[128];
  int y = 92;
  const char *s = g_err;
  while (*s && y < SCREEN_H - 10) {
    int n = 0;
    while (s[n] && s[n] != '\n' && n < 110) n++;
    memcpy(line, s, n);
    line[n] = 0;
    vita2d_pgf_draw_text(g_pgf, 20, y, RGBA8(255, 255, 255, 255), 0.8f, line);
    y += 20;
    s += n;
    if (*s == '\n') s++;
  }
}

// ---------------------------------------------------------------- main
int main(int argc, char *argv[]) {
  // the game is JS-heavy: run the CPU at full speed
  scePowerSetArmClockFrequency(444);
  scePowerSetBusClockFrequency(222);
  scePowerSetGpuClockFrequency(222);
  scePowerSetGpuXbarClockFrequency(166);

  sceIoMkdir(DATA_DIR, 0777);

  vita2d_init_advanced(8 * 1024 * 1024);  // bigger per-frame vertex pool for the shim's triangles
  vita2d_set_clear_color(RGBA8(11, 18, 32, 255));
  vita2d_set_vblank_wait(1);
  g_pgf = vita2d_load_default_pgf();
  g_font_tex = vita2d_load_PNG_file("app0:font.png");
  if (g_font_tex) vita2d_texture_set_filters(g_font_tex, SCE_GXM_TEXTURE_FILTER_LINEAR, SCE_GXM_TEXTURE_FILTER_LINEAR);

  sceTouchSetSamplingState(SCE_TOUCH_PORT_FRONT, SCE_TOUCH_SAMPLING_STATE_START);
  sceTouchSetSamplingState(SCE_TOUCH_PORT_BACK, SCE_TOUCH_SAMPLING_STATE_START);
  sceCtrlSetSamplingMode(SCE_CTRL_MODE_ANALOG);

  JSRuntime *rt = JS_NewRuntime();
  JS_SetMaxStackSize(rt, 2 * 1024 * 1024);
  JSContext *ctx = JS_NewContext(rt);
  JSValue global = JS_GetGlobalObject(ctx);
  add_fn(ctx, global, "__now", js_now, 0);
  add_fn(ctx, global, "__log", js_log, 1);
  add_fn(ctx, global, "__readFile", js_read_file, 1);
  add_fn(ctx, global, "__writeFile", js_write_file, 2);
  add_fn(ctx, global, "__removeFile", js_remove_file, 1);
  add_fn(ctx, global, "__drawTris", js_draw_tris, 3);
  add_fn(ctx, global, "__drawGlyphs", js_draw_glyphs, 3);
  add_fn(ctx, global, "__input", js_input, 0);

  if (!g_font_tex) { snprintf(g_err, sizeof(g_err), "Missing app0:font.png"); g_has_err = 1; }
  if (!g_has_err) eval_file(ctx, "app0:font_metrics.js");
  if (!g_has_err) eval_file(ctx, "app0:vita_shim.js");
  if (!g_has_err) eval_file(ctx, "app0:game.js");
  JSValue frame = JS_GetPropertyStr(ctx, global, "__vitaFrame");

  int running = 1;
  while (running) {
    SceCtrlData pad;
    memset(&pad, 0, sizeof(pad));
    sceCtrlPeekBufferPositive(0, &pad, 1);
    if ((pad.buttons & SCE_CTRL_START) && (pad.buttons & SCE_CTRL_SELECT)) running = 0;

    vita2d_start_drawing();
    vita2d_clear_screen();
    if (!g_has_err && JS_IsFunction(ctx, frame)) {
      JSValue r = JS_Call(ctx, frame, global, 0, NULL);
      if (JS_IsException(r)) capture_error(ctx, "frame");
      JS_FreeValue(ctx, r);
      JSContext *jctx;
      while (JS_ExecutePendingJob(rt, &jctx) > 0) {}
    }
    if (g_has_err) draw_error();
    vita2d_end_drawing();
    vita2d_swap_buffers();
  }

  vita2d_wait_rendering_done();
  JS_FreeValue(ctx, frame);
  JS_FreeValue(ctx, global);
  JS_FreeContext(ctx);
  JS_FreeRuntime(rt);
  if (g_font_tex) vita2d_free_texture(g_font_tex);
  if (g_pgf) vita2d_free_pgf(g_pgf);
  vita2d_fini();
  sceKernelExitProcess(0);
  return 0;
}

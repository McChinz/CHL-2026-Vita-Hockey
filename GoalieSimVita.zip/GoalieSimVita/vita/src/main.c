// CHL 2026 - PS Vita host
// Runs the web game's JavaScript (web/goalie.html) inside QuickJS and draws it with vita2d.
// The JS side (js/vita_shim.js) turns Canvas 2D calls into triangles and glyph quads;
// this file only provides the few native hooks it needs.

#include <psp2/kernel/processmgr.h>
#include <psp2/ctrl.h>
#include <psp2/touch.h>
#include <psp2/power.h>
#include <psp2/display.h>
#include <psp2/io/stat.h>
#include <vita2d.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include "quickjs.h"

// Memory: QuickJS heap lives in the newlib heap; give the main thread a deep stack for JS recursion.
int _newlib_heap_size_user = 160 * 1024 * 1024;
unsigned int sceUserMainThreadStackSize = 4 * 1024 * 1024;

#define DATA_DIR "ux0:data/GoalieSim"
#define SCREEN_W 960
#define SCREEN_H 544

static vita2d_texture *g_font_tex = NULL;
static vita2d_pgf *g_pgf = NULL;
static char g_err[8192];
static int g_has_err = 0;

// vita2d references the shared-framebuffer API, which it only uses when running as a system
// overlay (never the case here). These no-op versions satisfy the linker on SDKs that don't
// ship a stub library for it.
int sceSharedFbOpen(int index) { (void)index; return -1; }
int sceSharedFbClose(int fb) { (void)fb; return 0; }
int sceSharedFbBegin(int fb, void *info) { (void)fb; (void)info; return -1; }
int sceSharedFbEnd(int fb) { (void)fb; return 0; }
int sceSharedFbGetInfo(int fb, void *info) { (void)fb; (void)info; return -1; }

// ---------------------------------------------------------------- helpers
static char *read_file(const char *path, size_t *out_len) {
  FILE *f = fopen(path, "rb");
  if (!f) return NULL;
  fseek(f, 0, SEEK_END);
  long n = ftell(f);
  fseek(f, 0, SEEK_SET);
  if (n < 0) { fclose(f); return NULL; }
  char *buf = (char *)malloc((size_t)n + 1);
  if (!buf) { fclose(f); return NULL; }
  size_t got = fread(buf, 1, (size_t)n, f);
  fclose(f);
  buf[got] = 0;
  if (out_len) *out_len = got;
  return buf;
}

static void append_log(const char *s) {
  FILE *f = fopen(DATA_DIR "/log.txt", "a");
  if (!f) return;
  fputs(s, f);
  fputc('\n', f);
  fclose(f);
}

static void capture_error(JSContext *ctx, const char *where) {
  JSValue ex = JS_GetException(ctx);
  const char *msg = JS_ToCString(ctx, ex);
  const char *stack = NULL;
  JSValue st = JS_UNDEFINED;
  if (JS_IsObject(ex)) {
    st = JS_GetPropertyStr(ctx, ex, "stack");
    if (!JS_IsUndefined(st)) stack = JS_ToCString(ctx, st);
  }
  snprintf(g_err, sizeof(g_err), "%s: %s\n%s", where, msg ? msg : "(unknown error)", stack ? stack : "");
  append_log(g_err);
  if (stack) JS_FreeCString(ctx, stack);
  if (msg) JS_FreeCString(ctx, msg);
  JS_FreeValue(ctx, st);
  JS_FreeValue(ctx, ex);
  g_has_err = 1;
}

static int eval_file(JSContext *ctx, const char *path) {
  size_t len = 0;
  char *src = read_file(path, &len);
  if (!src) {
    snprintf(g_err, sizeof(g_err), "Could not open %s", path);
    g_has_err = 1;
    return -1;
  }
  JSValue r = JS_Eval(ctx, src, len, path, JS_EVAL_TYPE_GLOBAL);
  free(src);
  if (JS_IsException(r)) { capture_error(ctx, path); return -1; }
  JS_FreeValue(ctx, r);
  return 0;
}

// ---------------------------------------------------------------- native functions for the shim
static JSValue js_now(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  return JS_NewFloat64(ctx, (double)sceKernelGetProcessTimeWide() / 1000.0);
}

static JSValue js_log(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  if (argc < 1) return JS_UNDEFINED;
  const char *s = JS_ToCString(ctx, argv[0]);
  if (s) { append_log(s); JS_FreeCString(ctx, s); }
  return JS_UNDEFINED;
}

static JSValue js_read_file(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  if (argc < 1) return JS_NULL;
  const char *path = JS_ToCString(ctx, argv[0]);
  if (!path) return JS_NULL;
  size_t len = 0;
  char *buf = read_file(path, &len);
  JS_FreeCString(ctx, path);
  if (!buf) return JS_NULL;
  JSValue s = JS_NewStringLen(ctx, buf, len);
  free(buf);
  return s;
}

static JSValue js_write_file(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  if (argc < 2) return JS_FALSE;
  const char *path = JS_ToCString(ctx, argv[0]);
  size_t len = 0;
  const char *data = JS_ToCStringLen(ctx, &len, argv[1]);
  int ok = 0;
  if (path && data) {
    // write to a temp file first so a crash mid-save can't corrupt the save
    char tmp[512];
    snprintf(tmp, sizeof(tmp), "%s.tmp", path);
    FILE *f = fopen(tmp, "wb");
    if (f) {
      ok = fwrite(data, 1, len, f) == len;
      fclose(f);
      if (ok) { remove(path); ok = rename(tmp, path) == 0; }
    }
  }
  if (data) JS_FreeCString(ctx, data);
  if (path) JS_FreeCString(ctx, path);
  return JS_NewBool(ctx, ok);
}

static JSValue js_remove_file(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  if (argc < 1) return JS_UNDEFINED;
  const char *path = JS_ToCString(ctx, argv[0]);
  if (path) { remove(path); JS_FreeCString(ctx, path); }
  return JS_UNDEFINED;
}

// __drawTris(xyBuffer, colorBuffer, vertexCount): colored triangles, colors packed ABGR (vita2d RGBA8 layout)
static JSValue js_draw_tris(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  if (argc < 3) return JS_UNDEFINED;
  size_t plen = 0, clen = 0;
  float *p = (float *)JS_GetArrayBuffer(ctx, &plen, argv[0]);
  uint32_t *c = (uint32_t *)JS_GetArrayBuffer(ctx, &clen, argv[1]);
  int32_t n = 0;
  if (!p || !c || JS_ToInt32(ctx, &n, argv[2]) < 0) return JS_EXCEPTION;
  if ((size_t)n > plen / (2 * sizeof(float))) n = (int32_t)(plen / (2 * sizeof(float)));
  if ((size_t)n > clen / sizeof(uint32_t)) n = (int32_t)(clen / sizeof(uint32_t));
  n -= n % 3;
  if (n <= 0) return JS_UNDEFINED;
  double ox = 0, oy = 0;   // optional offset used when replaying cached layers
  if (argc >= 5) { JS_ToFloat64(ctx, &ox, argv[3]); JS_ToFloat64(ctx, &oy, argv[4]); }
  vita2d_color_vertex *v = (vita2d_color_vertex *)vita2d_pool_memalign(n * sizeof(vita2d_color_vertex), sizeof(vita2d_color_vertex));
  if (!v) return JS_UNDEFINED;  // frame pool exhausted; skip rather than crash
  for (int i = 0; i < n; i++) {
    v[i].x = p[i * 2] + (float)ox;
    v[i].y = p[i * 2 + 1] + (float)oy;
    v[i].z = 0.5f;
    v[i].color = c[i];
  }
  vita2d_draw_array(SCE_GXM_PRIMITIVE_TRIANGLES, v, n);
  return JS_UNDEFINED;
}

// __drawGlyphs(buffer of [dx,dy,u,v,w,h,scale]*n, n, color)
static JSValue js_draw_glyphs(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  if (argc < 3 || !g_font_tex) return JS_UNDEFINED;
  size_t blen = 0;
  float *b = (float *)JS_GetArrayBuffer(ctx, &blen, argv[0]);
  int32_t n = 0;
  uint32_t color = 0;
  if (!b || JS_ToInt32(ctx, &n, argv[1]) < 0 || JS_ToUint32(ctx, &color, argv[2]) < 0) return JS_EXCEPTION;
  if ((size_t)n > blen / (7 * sizeof(float))) n = (int32_t)(blen / (7 * sizeof(float)));
  double ox = 0, oy = 0;
  if (argc >= 5) { JS_ToFloat64(ctx, &ox, argv[3]); JS_ToFloat64(ctx, &oy, argv[4]); }
  for (int i = 0; i < n; i++) {
    const float *g = b + i * 7;
    vita2d_draw_texture_tint_part_scale(g_font_tex, g[0] + (float)ox, g[1] + (float)oy, g[2], g[3], g[4], g[5], g[6], g[6], color);
  }
  return JS_UNDEFINED;
}

// __input() -> [nFront, id,x,y..., nBack, id,x,y..., buttons, lx, ly, rx, ry]
// Touch coordinates are converted to the 960x544 screen space. Buttons: 1=L 2=R 4=START 8=SELECT 16=CROSS 32=CIRCLE 64=SQUARE 128=TRIANGLE
// ---------------------------------------------------------------- trophies
// Built only when this VitaSDK has the SceNpTrophy stub (see CMakeLists.txt). Needs the NoTrpDrm
// plugin on the console; without it the context fails and the game simply runs without trophies.
// The pack is app0:sce_sys/trophy/NPWR99626_00/TROPHY.TRP (tools/make_trophies.py). Never change the id.
#ifdef HAVE_TROPHIES
#include <psp2/sysmodule.h>
#include <psp2/kernel/threadmgr.h>
typedef struct { char data[9]; char term; unsigned char num; char dummy; } ChlNpCommId;
typedef struct { unsigned char data[160]; } ChlNpCommSign;
int sceNpTrophyInit(void *opt);
int sceNpTrophyCreateContext(int *context, const void *commId, const void *commSign, uint64_t options);
int sceNpTrophyCreateHandle(int *handle);
int sceNpTrophyUnlockTrophy(int context, int handle, int trophyId, int *platinumId);
#define TRP_Q 64
static volatile int trp_q[TRP_Q];
static volatile unsigned int trp_head = 0, trp_tail = 0;
static void trp_log(const char *what, int r) { char b[96]; snprintf(b, sizeof(b), "trophies: %s 0x%08X", what, (unsigned)r); append_log(b); }
// unlocking talks to the system and can take a moment, so it runs on its own thread
static int trp_thread(SceSize args, void *argp) {
  ChlNpCommId id; memset(&id, 0, sizeof(id)); memcpy(id.data, "NPWR99626", 9); id.num = 0;
  ChlNpCommSign sig; memset(&sig, 0, sizeof(sig));
  int ctx = -1, h = -1, r;
  sceSysmoduleLoadModule(SCE_SYSMODULE_NP_TROPHY);
  r = sceNpTrophyInit(NULL); if (r < 0) trp_log("init", r);
  r = sceNpTrophyCreateContext(&ctx, &id, &sig, 0); if (r < 0) { trp_log("context (is NoTrpDrm installed?)", r); return 0; }
  r = sceNpTrophyCreateHandle(&h); if (r < 0) { trp_log("handle", r); return 0; }
  for (;;) {
    while (trp_tail != trp_head) {
      int t = trp_q[trp_tail % TRP_Q], plat = -1;
      sceNpTrophyUnlockTrophy(ctx, h, t, &plat);   // already-unlocked trophies just return an error
      trp_tail++;
    }
    sceKernelDelayThread(150 * 1000);
  }
  return 0;
}
static void trp_start(void) {
  SceUID th = sceKernelCreateThread("chl_trophies", trp_thread, 0x10000100, 0x10000, 0, 0, NULL);
  if (th >= 0) sceKernelStartThread(th, 0, NULL); else trp_log("thread", th);
}
// __trophy(id): queue an unlock (the game only sends each id once per run)
static JSValue js_trophy(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  int id = -1;
  if (argc >= 1) JS_ToInt32(ctx, &id, argv[0]);
  if (id > 0 && id < 1000 && trp_head - trp_tail < TRP_Q) { trp_q[trp_head % TRP_Q] = id; trp_head++; }
  return JS_UNDEFINED;
}
#endif

// __gc(): run the cycle collector now (the game calls it at whistles and in menus, where a pause is
// not noticed) and push the automatic threshold up so it does not kick in during play.
static JSRuntime *g_rt = NULL;
static JSValue js_gc(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  if (g_rt) { JS_RunGC(g_rt); JS_SetGCThreshold(g_rt, 80 * 1024 * 1024); }
  return JS_UNDEFINED;
}
static JSValue js_input(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  SceTouchData tf, tb;
  SceCtrlData pad;
  memset(&tf, 0, sizeof(tf));
  memset(&tb, 0, sizeof(tb));
  memset(&pad, 0, sizeof(pad));
  sceTouchPeek(SCE_TOUCH_PORT_FRONT, &tf, 1);
  sceTouchPeek(SCE_TOUCH_PORT_BACK, &tb, 1);
  sceCtrlPeekBufferPositive(0, &pad, 1);

  JSValue arr = JS_NewArray(ctx);
  uint32_t k = 0;
  JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, (int32_t)tf.reportNum));
  for (unsigned i = 0; i < tf.reportNum; i++) {
    JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, tf.report[i].id));
    JS_SetPropertyUint32(ctx, arr, k++, JS_NewFloat64(ctx, tf.report[i].x * (double)SCREEN_W / 1920.0));
    JS_SetPropertyUint32(ctx, arr, k++, JS_NewFloat64(ctx, tf.report[i].y * (double)SCREEN_H / 1088.0));
  }
  JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, (int32_t)tb.reportNum));
  for (unsigned i = 0; i < tb.reportNum; i++) {
    double by = ((double)tb.report[i].y - 108.0) * SCREEN_H / (889.0 - 108.0);
    JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, tb.report[i].id));
    JS_SetPropertyUint32(ctx, arr, k++, JS_NewFloat64(ctx, tb.report[i].x * (double)SCREEN_W / 1920.0));
    JS_SetPropertyUint32(ctx, arr, k++, JS_NewFloat64(ctx, by));
  }
  int32_t bits = 0;
  if (pad.buttons & SCE_CTRL_LTRIGGER) bits |= 1;
  if (pad.buttons & SCE_CTRL_RTRIGGER) bits |= 2;
  if (pad.buttons & SCE_CTRL_START) bits |= 4;
  if (pad.buttons & SCE_CTRL_SELECT) bits |= 8;
  if (pad.buttons & SCE_CTRL_CROSS) bits |= 16;
  if (pad.buttons & SCE_CTRL_CIRCLE) bits |= 32;
  if (pad.buttons & SCE_CTRL_SQUARE) bits |= 64;
  if (pad.buttons & SCE_CTRL_TRIANGLE) bits |= 128;
  if (pad.buttons & SCE_CTRL_UP) bits |= 256;
  if (pad.buttons & SCE_CTRL_DOWN) bits |= 512;
  if (pad.buttons & SCE_CTRL_LEFT) bits |= 1024;
  if (pad.buttons & SCE_CTRL_RIGHT) bits |= 2048;
  JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, bits));
  JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, pad.lx));
  JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, pad.ly));
  JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, pad.rx));
  JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, pad.ry));
  return arr;
}

static void add_fn(JSContext *ctx, JSValue global, const char *name, JSCFunction *fn, int nargs) {
  JS_SetPropertyStr(ctx, global, name, JS_NewCFunction(ctx, fn, name, nargs));
}

// ---------------------------------------------------------------- error screen
static void draw_error(void) {
  vita2d_draw_rectangle(0, 0, SCREEN_W, SCREEN_H, RGBA8(20, 8, 12, 255));
  if (!g_pgf) return;
  vita2d_pgf_draw_text(g_pgf, 20, 34, RGBA8(255, 120, 120, 255), 1.0f, "CHL 2026 hit a script error. Hold SELECT + START to exit.");
  vita2d_pgf_draw_text(g_pgf, 20, 58, RGBA8(200, 200, 200, 255), 0.8f, "(Also written to ux0:data/GoalieSim/log.txt)");
  char line[128];
  int y = 92;
  const char *s = g_err;
  while (*s && y < SCREEN_H - 10) {
    int n = 0;
    while (s[n] && s[n] != '\n' && n < 110) n++;
    memcpy(line, s, n);
    line[n] = 0;
    vita2d_pgf_draw_text(g_pgf, 20, y, RGBA8(255, 255, 255, 255), 0.8f, line);
    y += 20;
    s += n;
    if (*s == '\n') s++;
  }
}

// ---------------------------------------------------------------- main
int main(int argc, char *argv[]) {
  // the game is JS-heavy: run the CPU at full speed
  scePowerSetArmClockFrequency(444);
  scePowerSetBusClockFrequency(222);
  scePowerSetGpuClockFrequency(222);
  scePowerSetGpuXbarClockFrequency(166);

  sceIoMkdir(DATA_DIR, 0777);

  vita2d_init_advanced(8 * 1024 * 1024);  // bigger per-frame vertex pool for the shim's triangles
  vita2d_set_clear_color(RGBA8(11, 18, 32, 255));
  vita2d_set_vblank_wait(0);   // we pace frames ourselves (steady 30 FPS, see the loop)
  g_pgf = vita2d_load_default_pgf();
  g_font_tex = vita2d_load_PNG_file("app0:font.png");
  if (g_font_tex) vita2d_texture_set_filters(g_font_tex, SCE_GXM_TEXTURE_FILTER_LINEAR, SCE_GXM_TEXTURE_FILTER_LINEAR);

  sceTouchSetSamplingState(SCE_TOUCH_PORT_FRONT, SCE_TOUCH_SAMPLING_STATE_START);
  sceTouchSetSamplingState(SCE_TOUCH_PORT_BACK, SCE_TOUCH_SAMPLING_STATE_START);
  sceCtrlSetSamplingMode(SCE_CTRL_MODE_ANALOG);

  JSRuntime *rt = JS_NewRuntime();
  JS_SetMaxStackSize(rt, 2 * 1024 * 1024);
  JS_SetGCThreshold(rt, 80 * 1024 * 1024);   // the game runs the collector itself at whistles (__gc)
  g_rt = rt;
  JSContext *ctx = JS_NewContext(rt);
  JSValue global = JS_GetGlobalObject(ctx);
  add_fn(ctx, global, "__now", js_now, 0);
  add_fn(ctx, global, "__log", js_log, 1);
  add_fn(ctx, global, "__readFile", js_read_file, 1);
  add_fn(ctx, global, "__writeFile", js_write_file, 2);
  add_fn(ctx, global, "__removeFile", js_remove_file, 1);
  add_fn(ctx, global, "__drawTris", js_draw_tris, 5);
  add_fn(ctx, global, "__drawGlyphs", js_draw_glyphs, 5);
  add_fn(ctx, global, "__input", js_input, 0);
  add_fn(ctx, global, "__gc", js_gc, 0);
#ifdef HAVE_TROPHIES
  add_fn(ctx, global, "__trophy", js_trophy, 1);
  trp_start();
#endif

  if (!g_font_tex) { snprintf(g_err, sizeof(g_err), "Missing app0:font.png"); g_has_err = 1; }
  if (!g_has_err) eval_file(ctx, "app0:font_metrics.js");
  if (!g_has_err) eval_file(ctx, "app0:vita_shim.js");
  if (!g_has_err) eval_file(ctx, "app0:game.js");
  JSValue frame = JS_GetPropertyStr(ctx, global, "__vitaFrame");

  int running = 1;
  double fps = 0, js_ms = 0;
  SceUInt64 last = sceKernelGetProcessTimeWide();
  unsigned int lastV = sceDisplayGetVcount();
  while (running) {
    SceCtrlData pad;
    memset(&pad, 0, sizeof(pad));
    sceCtrlPeekBufferPositive(0, &pad, 1);
    if ((pad.buttons & SCE_CTRL_START) && (pad.buttons & SCE_CTRL_SELECT)) running = 0;

    vita2d_start_drawing();
    vita2d_clear_screen();
    SceUInt64 t0 = sceKernelGetProcessTimeWide();
    if (!g_has_err && JS_IsFunction(ctx, frame)) {
      JSValue r = JS_Call(ctx, frame, global, 0, NULL);
      if (JS_IsException(r)) capture_error(ctx, "frame");
      JS_FreeValue(ctx, r);
      JSContext *jctx;
      while (JS_ExecutePendingJob(rt, &jctx) > 0) {}
    }
    SceUInt64 t1 = sceKernelGetProcessTimeWide();
    js_ms = js_ms * 0.9 + (double)(t1 - t0) / 1000.0 * 0.1;
    double dt = (double)(t1 - last) / 1000000.0;
    last = t1;
    if (dt > 0) fps = fps * 0.9 + (1.0 / dt) * 0.1;
    if (g_has_err) draw_error();
    else if ((pad.buttons & SCE_CTRL_SELECT) && g_pgf) {   // hold SELECT for a performance readout
      char line[96];
      snprintf(line, sizeof(line), "%.0f FPS   script %.1f ms", fps, js_ms);
      vita2d_draw_rectangle(6, 500, 300, 36, RGBA8(0, 0, 0, 180));
      vita2d_pgf_draw_text(g_pgf, 14, 526, RGBA8(124, 252, 154, 255), 1.0f, line);
    }
    vita2d_end_drawing();
    // steady 30 FPS: every frame is shown for exactly two refreshes (60 Hz screen), so motion
    // stays even instead of jumping between 60 and 40. A slow frame just shows on the next refresh.
    while ((int)(sceDisplayGetVcount() - lastV) < 2) sceDisplayWaitVblankStart();
    vita2d_swap_buffers();
    lastV = sceDisplayGetVcount();
  }

  vita2d_wait_rendering_done();
  JS_FreeValue(ctx, frame);
  JS_FreeValue(ctx, global);
  JS_FreeContext(ctx);
  JS_FreeRuntime(rt);
  if (g_font_tex) vita2d_free_texture(g_font_tex);
  if (g_pgf) vita2d_free_pgf(g_pgf);
  vita2d_fini();
  sceKernelExitProcess(0);
  return 0;
}

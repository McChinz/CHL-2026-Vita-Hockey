// CHL 2026 - PS Vita host
// Runs the web game's JavaScript (web/goalie.html) inside QuickJS and draws it with vita2d.
// The JS side (js/vita_shim.js) turns Canvas 2D calls into triangles and glyph quads;
// this file only provides the few native hooks it needs.

#include <psp2/kernel/processmgr.h>
#include <psp2/ctrl.h>
#include <psp2/touch.h>
#include <psp2/power.h>
#include <psp2/display.h>
#include <psp2/io/stat.h>
#include <psp2/audioout.h>
#include <psp2/kernel/threadmgr.h>
#include <vita2d.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>

#include "quickjs.h"

// Memory: QuickJS heap lives in the newlib heap; give the main thread a deep stack for JS recursion.
int _newlib_heap_size_user = 160 * 1024 * 1024;
unsigned int sceUserMainThreadStackSize = 4 * 1024 * 1024;

#define DATA_DIR "ux0:data/GoalieSim"
#define SCREEN_W 960
#define SCREEN_H 544

static vita2d_texture *g_font_tex = NULL;
static vita2d_pgf *g_pgf = NULL;
static char g_err[8192];
static int g_has_err = 0;

// vita2d references the shared-framebuffer API, which it only uses when running as a system
// overlay (never the case here). These no-op versions satisfy the linker on SDKs that don't
// ship a stub library for it.
int sceSharedFbOpen(int index) { (void)index; return -1; }
int sceSharedFbClose(int fb) { (void)fb; return 0; }
int sceSharedFbBegin(int fb, void *info) { (void)fb; (void)info; return -1; }
int sceSharedFbEnd(int fb) { (void)fb; return 0; }
int sceSharedFbGetInfo(int fb, void *info) { (void)fb; (void)info; return -1; }

// ---------------------------------------------------------------- helpers
static char *read_file(const char *path, size_t *out_len) {
  FILE *f = fopen(path, "rb");
  if (!f) return NULL;
  fseek(f, 0, SEEK_END);
  long n = ftell(f);
  fseek(f, 0, SEEK_SET);
  if (n < 0) { fclose(f); return NULL; }
  char *buf = (char *)malloc((size_t)n + 1);
  if (!buf) { fclose(f); return NULL; }
  size_t got = fread(buf, 1, (size_t)n, f);
  fclose(f);
  buf[got] = 0;
  if (out_len) *out_len = got;
  return buf;
}

static void append_log(const char *s) {
  FILE *f = fopen(DATA_DIR "/log.txt", "a");
  if (!f) return;
  fputs(s, f);
  fputc('\n', f);
  fclose(f);
}

static void capture_error(JSContext *ctx, const char *where) {
  JSValue ex = JS_GetException(ctx);
  const char *msg = JS_ToCString(ctx, ex);
  const char *stack = NULL;
  JSValue st = JS_UNDEFINED;
  if (JS_IsObject(ex)) {
    st = JS_GetPropertyStr(ctx, ex, "stack");
    if (!JS_IsUndefined(st)) stack = JS_ToCString(ctx, st);
  }
  snprintf(g_err, sizeof(g_err), "%s: %s\n%s", where, msg ? msg : "(unknown error)", stack ? stack : "");
  append_log(g_err);
  if (stack) JS_FreeCString(ctx, stack);
  if (msg) JS_FreeCString(ctx, msg);
  JS_FreeValue(ctx, st);
  JS_FreeValue(ctx, ex);
  g_has_err = 1;
}

static int eval_file(JSContext *ctx, const char *path) {
  size_t len = 0;
  char *src = read_file(path, &len);
  if (!src) {
    snprintf(g_err, sizeof(g_err), "Could not open %s", path);
    g_has_err = 1;
    return -1;
  }
  JSValue r = JS_Eval(ctx, src, len, path, JS_EVAL_TYPE_GLOBAL);
  free(src);
  if (JS_IsException(r)) { capture_error(ctx, path); return -1; }
  JS_FreeValue(ctx, r);
  return 0;
}

// ---------------------------------------------------------------- native functions for the shim
static JSValue js_now(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  return JS_NewFloat64(ctx, (double)sceKernelGetProcessTimeWide() / 1000.0);
}

static JSValue js_log(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  if (argc < 1) return JS_UNDEFINED;
  const char *s = JS_ToCString(ctx, argv[0]);
  if (s) { append_log(s); JS_FreeCString(ctx, s); }
  return JS_UNDEFINED;
}

static JSValue js_read_file(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  if (argc < 1) return JS_NULL;
  const char *path = JS_ToCString(ctx, argv[0]);
  if (!path) return JS_NULL;
  size_t len = 0;
  char *buf = read_file(path, &len);
  JS_FreeCString(ctx, path);
  if (!buf) return JS_NULL;
  JSValue s = JS_NewStringLen(ctx, buf, len);
  free(buf);
  return s;
}

static JSValue js_write_file(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  if (argc < 2) return JS_FALSE;
  const char *path = JS_ToCString(ctx, argv[0]);
  size_t len = 0;
  const char *data = JS_ToCStringLen(ctx, &len, argv[1]);
  int ok = 0;
  if (path && data) {
    // write to a temp file first so a crash mid-save can't corrupt the save
    char tmp[512];
    snprintf(tmp, sizeof(tmp), "%s.tmp", path);
    FILE *f = fopen(tmp, "wb");
    if (f) {
      ok = fwrite(data, 1, len, f) == len;
      fclose(f);
      if (ok) { remove(path); ok = rename(tmp, path) == 0; }
    }
  }
  if (data) JS_FreeCString(ctx, data);
  if (path) JS_FreeCString(ctx, path);
  return JS_NewBool(ctx, ok);
}

static JSValue js_remove_file(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  if (argc < 1) return JS_UNDEFINED;
  const char *path = JS_ToCString(ctx, argv[0]);
  if (path) { remove(path); JS_FreeCString(ctx, path); }
  return JS_UNDEFINED;
}

// __drawTris(xyBuffer, colorBuffer, vertexCount): colored triangles, colors packed ABGR (vita2d RGBA8 layout)
static JSValue js_draw_tris(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  if (argc < 3) return JS_UNDEFINED;
  size_t plen = 0, clen = 0;
  float *p = (float *)JS_GetArrayBuffer(ctx, &plen, argv[0]);
  uint32_t *c = (uint32_t *)JS_GetArrayBuffer(ctx, &clen, argv[1]);
  int32_t n = 0;
  if (!p || !c || JS_ToInt32(ctx, &n, argv[2]) < 0) return JS_EXCEPTION;
  if ((size_t)n > plen / (2 * sizeof(float))) n = (int32_t)(plen / (2 * sizeof(float)));
  if ((size_t)n > clen / sizeof(uint32_t)) n = (int32_t)(clen / sizeof(uint32_t));
  n -= n % 3;
  if (n <= 0) return JS_UNDEFINED;
  double ox = 0, oy = 0, k = 1;   // optional offset (and scale) used when replaying cached layers
  if (argc >= 5) { JS_ToFloat64(ctx, &ox, argv[3]); JS_ToFloat64(ctx, &oy, argv[4]); }
  if (argc >= 6) JS_ToFloat64(ctx, &k, argv[5]);
  vita2d_color_vertex *v = (vita2d_color_vertex *)vita2d_pool_memalign(n * sizeof(vita2d_color_vertex), sizeof(vita2d_color_vertex));
  if (!v) return JS_UNDEFINED;  // frame pool exhausted; skip rather than crash
  for (int i = 0; i < n; i++) {
    v[i].x = p[i * 2] * (float)k + (float)ox;
    v[i].y = p[i * 2 + 1] * (float)k + (float)oy;
    v[i].z = 0.5f;
    v[i].color = c[i];
  }
  vita2d_draw_array(SCE_GXM_PRIMITIVE_TRIANGLES, v, n);
  return JS_UNDEFINED;
}

// __drawGlyphs(buffer of [dx,dy,u,v,w,h,scale]*n, n, color)
static JSValue js_draw_glyphs(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  if (argc < 3 || !g_font_tex) return JS_UNDEFINED;
  size_t blen = 0;
  float *b = (float *)JS_GetArrayBuffer(ctx, &blen, argv[0]);
  int32_t n = 0;
  uint32_t color = 0;
  if (!b || JS_ToInt32(ctx, &n, argv[1]) < 0 || JS_ToUint32(ctx, &color, argv[2]) < 0) return JS_EXCEPTION;
  if ((size_t)n > blen / (7 * sizeof(float))) n = (int32_t)(blen / (7 * sizeof(float)));
  double ox = 0, oy = 0, k = 1;
  if (argc >= 5) { JS_ToFloat64(ctx, &ox, argv[3]); JS_ToFloat64(ctx, &oy, argv[4]); }
  if (argc >= 6) JS_ToFloat64(ctx, &k, argv[5]);
  const float kf = (float)k;
  for (int i = 0; i < n; i++) {
    const float *g = b + i * 7;
    vita2d_draw_texture_tint_part_scale(g_font_tex, g[0] * kf + (float)ox, g[1] * kf + (float)oy, g[2], g[3], g[4], g[5], g[6] * kf, g[6] * kf, color);
  }
  return JS_UNDEFINED;
}

// __input() -> [nFront, id,x,y..., nBack, id,x,y..., buttons, lx, ly, rx, ry]
// Touch coordinates are converted to the 960x544 screen space. Buttons: 1=L 2=R 4=START 8=SELECT 16=CROSS 32=CIRCLE 64=SQUARE 128=TRIANGLE
// __gc(): run the cycle collector now (the game calls it at whistles and in menus, where a pause is
// not noticed) and push the automatic threshold up so it does not kick in during play.
static JSRuntime *g_rt = NULL;
static JSValue js_gc(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  if (g_rt) { JS_RunGC(g_rt); JS_SetGCThreshold(g_rt, 80 * 1024 * 1024); }
  return JS_UNDEFINED;
}
static JSValue js_input(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  SceTouchData tf, tb;
  SceCtrlData pad;
  memset(&tf, 0, sizeof(tf));
  memset(&tb, 0, sizeof(tb));
  memset(&pad, 0, sizeof(pad));
  sceTouchPeek(SCE_TOUCH_PORT_FRONT, &tf, 1);
  sceTouchPeek(SCE_TOUCH_PORT_BACK, &tb, 1);
  sceCtrlPeekBufferPositive(0, &pad, 1);

  JSValue arr = JS_NewArray(ctx);
  uint32_t k = 0;
  JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, (int32_t)tf.reportNum));
  for (unsigned i = 0; i < tf.reportNum; i++) {
    JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, tf.report[i].id));
    JS_SetPropertyUint32(ctx, arr, k++, JS_NewFloat64(ctx, tf.report[i].x * (double)SCREEN_W / 1920.0));
    JS_SetPropertyUint32(ctx, arr, k++, JS_NewFloat64(ctx, tf.report[i].y * (double)SCREEN_H / 1088.0));
  }
  JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, (int32_t)tb.reportNum));
  for (unsigned i = 0; i < tb.reportNum; i++) {
    double by = ((double)tb.report[i].y - 108.0) * SCREEN_H / (889.0 - 108.0);
    JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, tb.report[i].id));
    JS_SetPropertyUint32(ctx, arr, k++, JS_NewFloat64(ctx, tb.report[i].x * (double)SCREEN_W / 1920.0));
    JS_SetPropertyUint32(ctx, arr, k++, JS_NewFloat64(ctx, by));
  }
  int32_t bits = 0;
  if (pad.buttons & SCE_CTRL_LTRIGGER) bits |= 1;
  if (pad.buttons & SCE_CTRL_RTRIGGER) bits |= 2;
  if (pad.buttons & SCE_CTRL_START) bits |= 4;
  if (pad.buttons & SCE_CTRL_SELECT) bits |= 8;
  if (pad.buttons & SCE_CTRL_CROSS) bits |= 16;
  if (pad.buttons & SCE_CTRL_CIRCLE) bits |= 32;
  if (pad.buttons & SCE_CTRL_SQUARE) bits |= 64;
  if (pad.buttons & SCE_CTRL_TRIANGLE) bits |= 128;
  if (pad.buttons & SCE_CTRL_UP) bits |= 256;
  if (pad.buttons & SCE_CTRL_DOWN) bits |= 512;
  if (pad.buttons & SCE_CTRL_LEFT) bits |= 1024;
  if (pad.buttons & SCE_CTRL_RIGHT) bits |= 2048;
  JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, bits));
  JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, pad.lx));
  JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, pad.ly));
  JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, pad.rx));
  JS_SetPropertyUint32(ctx, arr, k++, JS_NewInt32(ctx, pad.ry));
  return arr;
}

// ---------------------------------------------------------------- sound
// The game makes its own sounds (synthesized in JS at 22050 Hz, mono 16-bit) and hands them over with
// __sfxLoad(id, arrayBuffer). A small mixer thread plays up to AU_VOICES of them at once on the main
// audio port (48 kHz), resampling each voice by its own rate.
#define AU_RATE_IN 22050.0
#define AU_RATE_OUT 48000
#define AU_GRAIN 512
#define AU_VOICES 24
#define AU_SOUNDS 64
typedef struct { const int16_t *d; int len; double pos, step; volatile float vol; int loop; volatile int on; unsigned age; volatile unsigned gen; } AuVoice;
static AuVoice g_vo[AU_VOICES];
static int16_t *g_snd[AU_SOUNDS];
static int g_snd_len[AU_SOUNDS];
static volatile int g_au_run = 1;
static unsigned g_au_age = 0;
static SceUID g_au_thread = -1;


// ---- the sounds themselves, synthesized here at start-up (the same recipes as the web build's sndSynth;
// the ids match SND.names in the game). Built on the audio thread so nothing waits for them.
enum { S_SLAP, S_WRIST, S_PASS, S_SAVE, S_SKATE, S_STOP, S_GRUNT1, S_GRUNT2, S_GRUNT3, S_HIT, S_POST, S_AMB, S_CHEER, S_BOO, S_COUNT };
#define SR 22050
#define PI2 6.28318530718f
typedef struct { float b0, b1, b2, a1, a2, x1, x2, y1, y2; } Bq;
static unsigned g_rs = 1;
static void rng_seed(unsigned s) { g_rs = s ? s : 1; }
static float rnd(void) { g_rs = g_rs * 1664525u + 1013904223u; return (float)(g_rs >> 8) / 16777216.f * 2.f - 1.f; }
static void bq_set(Bq *f, int type, float fr, float Q) {   // type 0 bp, 1 lp, 2 hp
  if (fr > SR * 0.45f) fr = SR * 0.45f;
  float w = PI2 * fr / SR, cs = cosf(w), sn = sinf(w), a = sn / (2 * Q), b0, b1, b2;
  if (type == 0) { b0 = a; b1 = 0; b2 = -a; } else if (type == 1) { b0 = (1 - cs) / 2; b1 = 1 - cs; b2 = b0; } else { b0 = (1 + cs) / 2; b1 = -(1 + cs); b2 = b0; }
  float a0 = 1 + a;
  f->b0 = b0 / a0; f->b1 = b1 / a0; f->b2 = b2 / a0; f->a1 = -2 * cs / a0; f->a2 = (1 - a) / a0;
}
static void bq_init(Bq *f, int type, float fr, float Q) { memset(f, 0, sizeof(*f)); bq_set(f, type, fr, Q); }
static inline float bq(Bq *f, float x) { float y = f->b0 * x + f->b1 * f->x1 + f->b2 * f->x2 - f->a1 * f->y1 - f->a2 * f->y2; f->x2 = f->x1; f->x1 = x; f->y2 = f->y1; f->y1 = y; return y; }
static void syn_store(int id, float *a, int n, float pk) {
  float m = 0; for (int i = 0; i < n; i++) { float v = fabsf(a[i]); if (v > m) m = v; }
  float k = m > 0 ? pk * 32767.f / m : 0;
  int16_t *d = (int16_t *)malloc((size_t)n * 2);
  if (d) { for (int i = 0; i < n; i++) d[i] = (int16_t)(a[i] * k); g_snd_len[id] = n; g_snd[id] = d; }
  free(a);
}
static float *syn_buf(float dur, int *n) { *n = (int)(dur * SR); return (float *)calloc((size_t)*n + 1, sizeof(float)); }
typedef struct { unsigned seed; int t1; float f1, q1, d1, g1, f2, q2, d2, g2, th0, th1, thd, td, tg; } HitP;
static float *syn_hit(float dur, const HitP *o, int *n) {
  float *a = syn_buf(dur, n); if (!a) return NULL;
  Bq f1, f2; bq_init(&f1, o->t1, o->f1, o->q1 > 0 ? o->q1 : 0.7f); bq_init(&f2, 0, o->f2, o->q2 > 0 ? o->q2 : 2.f);
  rng_seed(o->seed); float ph = 0;
  for (int i = 0; i < *n; i++) { float t = (float)i / SR, x = rnd(); ph += (o->th0 + o->th1 * expf(-t / o->thd)) / SR;
    a[i] = bq(&f1, x) * expf(-t / o->d1) * o->g1 + bq(&f2, x) * expf(-t / o->d2) * o->g2 + sinf(PI2 * ph) * expf(-t / o->td) * o->tg; }
  return a;
}
typedef float (*EnvFn)(float t);
static float env_grunt(float t) { return t < .015f ? t / .015f : t < .06f ? 1.f : expf(-(t - .06f) / .075f); }
static float env_boo(float t) { return t < .35f ? t / .35f : t < 2.1f ? 1.f : fmaxf(0.f, 1.f - (t - 2.1f) / .75f); }
static void syn_voice(float *a, int alen, int off, float dur, float f0a, float f0b, const float *F, float amp, unsigned seed, EnvFn env, float vib) {
  int n = (int)(dur * SR); Bq fs[3], br; const float Q[3] = {5, 8, 10};
  for (int k = 0; k < 3; k++) bq_init(&fs[k], 0, F[k], Q[k]);
  bq_init(&br, 0, 1500, 1); rng_seed(seed); float ph = 0;
  for (int i = 0; i < n && off + i < alen; i++) { float t = (float)i / SR, k = t / dur, f0 = (f0a + (f0b - f0a) * k) * (1 + vib * sinf(t * PI2 * 5.3f + seed));
    ph += f0 / SR; ph -= floorf(ph);
    float g = 1 - 2 * ph, src = g * fabsf(g) + rnd() * .12f, e = env(t);
    a[off + i] += (bq(&fs[0], src) + bq(&fs[1], src) * .6f + bq(&fs[2], src) * .3f + bq(&br, rnd()) * .12f) * e * amp; }
}
static void syn_all(void) {
  int n; float *a; Bq b, h, f;
  { HitP o = {3, 2, 2200, .7f, .011f, 1.1f, 3200, 3, .02f, .8f, 65, 120, .03f, .075f, .75f}; a = syn_hit(.32f, &o, &n); if (a) syn_store(S_SLAP, a, n, .92f); }
  { HitP o = {5, 2, 2600, .7f, .007f, .7f, 2300, 2.2f, .016f, .9f, 80, 90, .025f, .05f, .45f}; a = syn_hit(.24f, &o, &n); if (a) syn_store(S_WRIST, a, n, .92f); }
  { HitP o = {9, 0, 1100, 4, .013f, 1, 1500, 3, .01f, .3f, 520, 0, 1, .03f, .5f}; a = syn_hit(.16f, &o, &n); if (a) syn_store(S_PASS, a, n, .92f); }
  { HitP o = {11, 1, 450, .7f, .045f, 1.4f, 900, 1.5f, .03f, .4f, 110, 40, .04f, .06f, .6f}; a = syn_hit(.22f, &o, &n); if (a) syn_store(S_SAVE, a, n, .92f); }
  if ((a = syn_buf(.2f, &n))) { rng_seed(21); bq_init(&h, 2, 2500, .7f); bq_init(&b, 0, 5200, .8f);
    for (int i = 0; i < n; i++) { float t = (float)i / SR, e = t < .03f ? t / .03f : expf(-(t - .03f) / .065f); a[i] = bq(&b, bq(&h, rnd())) * e * (.7f + .3f * rnd()); }
    syn_store(S_SKATE, a, n, .9f); }
  if ((a = syn_buf(.56f, &n))) { rng_seed(23); bq_init(&h, 2, 1800, .7f); bq_init(&b, 0, 6000, .9f);
    for (int i = 0; i < n; i++) { float t = (float)i / SR; if (i % 32 == 0) bq_set(&b, 0, 6000 - 3500 * fminf(1.f, t / .45f), .9f);
      float e = t < .02f ? t / .02f : t < .22f ? 1.f : expf(-(t - .22f) / .11f); a[i] = bq(&b, bq(&h, rnd())) * e * (.55f + .45f * fabsf(rnd())); }
    syn_store(S_STOP, a, n, .9f); }
  { const float P[3][5] = {{150, 108, 640, 1190, 2390}, {128, 95, 450, 850, 2400}, {176, 128, 760, 1300, 2550}};
    for (int v = 0; v < 3; v++) if ((a = syn_buf(.32f, &n))) { syn_voice(a, n, 0, .3f, P[v][0], P[v][1], &P[v][2], 1, 32 + v, env_grunt, .01f); syn_store(S_GRUNT1 + v, a, n, .9f); } }
  { HitP o = {13, 1, 260, .7f, .055f, 1.6f, 380, 3, .12f, .7f, 52, 30, .05f, .11f, .9f}; a = syn_hit(.38f, &o, &n);
    if (a) { rng_seed(17); bq_init(&f, 0, 1800, 6); for (int i = 0; i < n; i++) a[i] += bq(&f, rnd()) * expf(-((float)i / SR) / .09f) * .25f; syn_store(S_HIT, a, n, .92f); } }
  if ((a = syn_buf(1.05f, &n))) { const float P[6][3] = {{1050, 1, .55f}, {1053, .5f, .5f}, {2380, .7f, .4f}, {3610, .5f, .28f}, {5170, .35f, .18f}, {6890, .2f, .12f}};
    rng_seed(41); bq_init(&h, 2, 3000, .7f);
    for (int i = 0; i < n; i++) { float t = (float)i / SR, v = bq(&h, rnd()) * expf(-t / .004f) * .7f; for (int k = 0; k < 6; k++) v += sinf(PI2 * P[k][0] * t) * P[k][1] * expf(-t / P[k][2]); a[i] = v; }
    syn_store(S_POST, a, n, .9f); }
  { int L = 4 * SR, X = SR / 2; float *w = (float *)calloc((size_t)(L + X), sizeof(float));
    if (w) { Bq B[3]; const float Bf[3][3] = {{350, .8f, 1}, {700, 1, .8f}, {1400, 1.2f, .4f}}; float bv[3] = {0, 0, 0};
      for (int k = 0; k < 3; k++) bq_init(&B[k], 0, Bf[k][0], Bf[k][1]);
      rng_seed(51);
      for (int i = 0; i < L + X; i++) { float v = 0; for (int k = 0; k < 3; k++) { bv[k] += (rnd() * .9f - bv[k]) * .0006f; float m = .62f + .38f * fmaxf(-1.f, fminf(1.f, bv[k] * 3)); v += bq(&B[k], rnd()) * Bf[k][2] * m; } w[i] = v; }
      float *o = (float *)malloc((size_t)L * sizeof(float));
      if (o) { for (int i = 0; i < L; i++) o[i] = i < X ? w[i] * ((float)i / X) + w[L + i] * (1 - (float)i / X) : w[i]; syn_store(S_AMB, o, L, .5f); }
      free(w); } }
  if ((a = syn_buf(3.6f, &n))) { Bq B[3], cl; const float Bf[3][3] = {{700, 1, 1}, {1150, 1.5f, .8f}, {2600, 2, .35f}};
    for (int k = 0; k < 3; k++) bq_init(&B[k], 0, Bf[k][0], Bf[k][1]);
    bq_init(&cl, 2, 1200, .7f); rng_seed(61);
    for (int i = 0; i < n; i++) { float t = (float)i / SR, u = t / .25f, e = t < .25f ? u * u * (3 - 2 * u) : t < 2.2f ? 1.f : fmaxf(0.f, 1 - (t - 2.2f) / 1.4f), v = 0;
      for (int k = 0; k < 3; k++) v += bq(&B[k], rnd()) * Bf[k][2];
      a[i] = v * e * (.85f + .15f * sinf(t * PI2 * 7.3f)); }
    for (int k = 0; k < 140; k++) { float t0 = .25f + fabsf(rnd()) * 2.6f, g = .25f + .25f * fabsf(rnd()); int o = (int)(t0 * SR);
      for (int j = 0; j < 180 && o + j < n; j++) a[o + j] += bq(&cl, rnd()) * expf(-j / 40.f) * g; }
    for (int k = 0; k < 5; k++) { float t0 = .3f + fabsf(rnd()) * 1.4f, f0 = 1000 + fabsf(rnd()) * 300, ph = 0; int o = (int)(t0 * SR), m = (int)(.55f * SR);
      for (int j = 0; j < m && o + j < n; j++) { float u = (float)j / m, fr = f0 * (1 + .45f * sinf(3.14159265f * u)) * (1 + .01f * sinf((float)j / SR * PI2 * 6)); ph += fr / SR; a[o + j] += sinf(PI2 * ph) * sinf(3.14159265f * u) * .08f; } }
    syn_store(S_CHEER, a, n, .92f); }
  if ((a = syn_buf(3.f, &n))) { rng_seed(71);
    for (int k = 0; k < 7; k++) { float f0 = 95 + fabsf(rnd()) * 95; int off = (int)(fabsf(rnd()) * .12f * SR); float F[3] = {300 + fabsf(rnd()) * 40, 820, 2300};
      unsigned keep = g_rs; syn_voice(a, n, off, 2.85f, f0, f0 * .94f, F, .5f, 80 + k, env_boo, .02f); g_rs = keep; }
    bq_init(&f, 0, 420, 1);
    for (int i = 0; i < n; i++) a[i] += bq(&f, rnd()) * .15f * env_boo((float)i / SR);
    syn_store(S_BOO, a, n, .9f); }
}
static int au_thread(SceSize args, void *argp) {
  (void)args; (void)argp;
  syn_all();
  int port = sceAudioOutOpenPort(SCE_AUDIO_OUT_PORT_TYPE_MAIN, AU_GRAIN, AU_RATE_OUT, SCE_AUDIO_OUT_MODE_MONO);
  if (port < 0) return 0;
  int vols[2] = {SCE_AUDIO_VOLUME_0DB, SCE_AUDIO_VOLUME_0DB};
  sceAudioOutSetVolume(port, SCE_AUDIO_VOLUME_FLAG_L_CH | SCE_AUDIO_VOLUME_FLAG_R_CH, vols);
  static int16_t out[2][AU_GRAIN];
  static float mix[AU_GRAIN];
  int b = 0;
  while (g_au_run) {
    memset(mix, 0, sizeof(mix));
    for (int v = 0; v < AU_VOICES; v++) {
      AuVoice *o = &g_vo[v];
      if (!o->on || !o->d) continue;
      const unsigned gen = o->gen;   // if the game restarts this voice while we mix, we leave its new state alone
      const int16_t *d = o->d; const int len = o->len; const float vol = o->vol; const int loop = o->loop;
      double pos = o->pos; const double st = o->step;
      if (len < 2 || pos < 0) { if (o->gen == gen) o->on = 0; continue; }
      int ended = 0;
      for (int i = 0; i < AU_GRAIN; i++) {
        int ip = (int)pos;
        if (ip >= len - 1) {
          if (loop) { pos = fmod(pos, (double)(len - 1)); ip = (int)pos; if (ip >= len - 1) ip = 0; }
          else { ended = 1; break; }
        }
        float fr = (float)(pos - ip);
        mix[i] += ((float)d[ip] + (float)(d[ip + 1] - d[ip]) * fr) * vol;
        pos += st;
      }
      if (o->gen == gen) { o->pos = pos; if (ended) o->on = 0; }
    }
    for (int i = 0; i < AU_GRAIN; i++) {   // soft limiter: loud moments squash instead of clipping
      float x = mix[i], a = x < 0 ? -x : x;
      if (a > 20000.f) { float y = 20000.f + (a - 20000.f) * 12767.f / (a - 20000.f + 12767.f); x = x < 0 ? -y : y; }
      out[b][i] = (int16_t)x;
    }
    sceAudioOutOutput(port, out[b]);   // blocks until the port wants the next grain
    b ^= 1;
  }
  sceAudioOutReleasePort(port);
  return 0;
}
static void au_start(void) {
  g_au_thread = sceKernelCreateThread("chl_audio", au_thread, 0x10000100, 0x10000, 0, 0, NULL);
  if (g_au_thread >= 0) sceKernelStartThread(g_au_thread, 0, NULL);
}
static void au_stop(void) {
  g_au_run = 0;
  if (g_au_thread >= 0) { sceKernelWaitThreadEnd(g_au_thread, NULL, NULL); sceKernelDeleteThread(g_au_thread); }
}
// __sfxLoad(id, arrayBuffer of int16 samples at 22050 Hz)
static JSValue js_sfx_load(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  int32_t id = 0; size_t blen = 0;
  if (argc < 2 || JS_ToInt32(ctx, &id, argv[0]) < 0 || id < 0 || id >= AU_SOUNDS) return JS_FALSE;
  const int16_t *src = (const int16_t *)JS_GetArrayBuffer(ctx, &blen, argv[1]);
  if (!src || blen < 4) { JS_FreeValue(ctx, JS_GetException(ctx)); return JS_FALSE; }
  int n = (int)(blen / 2);
  int16_t *d = (int16_t *)malloc((size_t)n * 2);
  if (!d) return JS_FALSE;
  memcpy(d, src, (size_t)n * 2);
  for (int v = 0; v < AU_VOICES; v++) if (g_vo[v].d == g_snd[id]) g_vo[v].on = 0;   // never free a playing sound
  int16_t *old = g_snd[id];
  g_snd[id] = d; g_snd_len[id] = n;
  if (old) { sceKernelDelayThread(30000); free(old); }
  return JS_TRUE;
}
// __sfxPlay(id, vol, rate, loop) -> voice number (or -1)
static JSValue js_sfx_play(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  int32_t id = 0, loop = 0; double vol = 1, rate = 1;
  if (argc < 1 || JS_ToInt32(ctx, &id, argv[0]) < 0 || id < 0 || id >= AU_SOUNDS || !g_snd[id]) return JS_NewInt32(ctx, -1);
  if (argc > 1) JS_ToFloat64(ctx, &vol, argv[1]);
  if (argc > 2) JS_ToFloat64(ctx, &rate, argv[2]);
  if (argc > 3) JS_ToInt32(ctx, &loop, argv[3]);
  int pick = -1; unsigned oldest = 0xffffffffu;
  for (int v = 0; v < AU_VOICES; v++) if (!g_vo[v].on) { pick = v; break; }
  if (pick < 0) for (int v = 0; v < AU_VOICES; v++) if (!g_vo[v].loop && g_vo[v].age < oldest) { oldest = g_vo[v].age; pick = v; }   // steal the oldest one-shot
  if (pick < 0) return JS_NewInt32(ctx, -1);
  AuVoice *o = &g_vo[pick];
  o->on = 0; o->gen++;
  o->d = g_snd[id]; o->len = g_snd_len[id]; o->pos = 0;
  o->step = (rate > 0.05 ? rate : 0.05) * AU_RATE_IN / AU_RATE_OUT;
  o->vol = (float)vol; o->loop = loop; o->age = ++g_au_age;
  o->gen++;
  o->on = 1;
  return JS_NewInt32(ctx, pick);
}
// __sfxSet(voice, vol, rate)
static JSValue js_sfx_set(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  int32_t v = -1; double vol = 1, rate = 0;
  if (argc < 2 || JS_ToInt32(ctx, &v, argv[0]) < 0 || v < 0 || v >= AU_VOICES) return JS_UNDEFINED;
  JS_ToFloat64(ctx, &vol, argv[1]);
  g_vo[v].vol = (float)vol;
  if (argc > 2 && JS_ToFloat64(ctx, &rate, argv[2]) == 0 && rate > 0.05) g_vo[v].step = rate * AU_RATE_IN / AU_RATE_OUT;
  return JS_UNDEFINED;
}
static JSValue js_sfx_stop(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
  int32_t v = -1;
  if (argc < 1 || JS_ToInt32(ctx, &v, argv[0]) < 0) return JS_UNDEFINED;
  if (v < 0) { for (int i = 0; i < AU_VOICES; i++) g_vo[i].on = 0; }
  else if (v < AU_VOICES) g_vo[v].on = 0;
  return JS_UNDEFINED;
}

// ---- watchdog: QuickJS calls this now and then while a script runs. A frame that has been running for more
// than 2 s is stuck in a loop: interrupt it (throws), log where it was, and keep the game going.
static volatile SceUInt64 g_frame_t0 = 0;
static int g_wd_hits = 0;
static int js_watchdog(JSRuntime *rt, void *op) {
  (void)rt; (void)op;
  return g_frame_t0 && (sceKernelGetProcessTimeWide() - g_frame_t0) > 2000000ULL;
}

static void add_fn(JSContext *ctx, JSValue global, const char *name, JSCFunction *fn, int nargs) {
  JS_SetPropertyStr(ctx, global, name, JS_NewCFunction(ctx, fn, name, nargs));
}

// ---------------------------------------------------------------- error screen
static void draw_error(void) {
  vita2d_draw_rectangle(0, 0, SCREEN_W, SCREEN_H, RGBA8(20, 8, 12, 255));
  if (!g_pgf) return;
  vita2d_pgf_draw_text(g_pgf, 20, 34, RGBA8(255, 120, 120, 255), 1.0f, "CHL 2026 hit a script error. Hold SELECT + START to exit.");
  vita2d_pgf_draw_text(g_pgf, 20, 58, RGBA8(200, 200, 200, 255), 0.8f, "(Also written to ux0:data/GoalieSim/log.txt)");
  char line[128];
  int y = 92;
  const char *s = g_err;
  while (*s && y < SCREEN_H - 10) {
    int n = 0;
    while (s[n] && s[n] != '\n' && n < 110) n++;
    memcpy(line, s, n);
    line[n] = 0;
    vita2d_pgf_draw_text(g_pgf, 20, y, RGBA8(255, 255, 255, 255), 0.8f, line);
    y += 20;
    s += n;
    if (*s == '\n') s++;
  }
}

// ---------------------------------------------------------------- main
int main(int argc, char *argv[]) {
  // the game is JS-heavy: run the CPU at full speed
  scePowerSetArmClockFrequency(444);
  scePowerSetBusClockFrequency(222);
  scePowerSetGpuClockFrequency(222);
  scePowerSetGpuXbarClockFrequency(166);

  sceIoMkdir(DATA_DIR, 0777);

  vita2d_init_advanced(8 * 1024 * 1024);  // bigger per-frame vertex pool for the shim's triangles
  vita2d_set_clear_color(RGBA8(11, 18, 32, 255));
  vita2d_set_vblank_wait(0);   // we pace frames ourselves (steady 30 FPS, see the loop)
  g_pgf = vita2d_load_default_pgf();
  g_font_tex = vita2d_load_PNG_file("app0:font.png");
  if (g_font_tex) vita2d_texture_set_filters(g_font_tex, SCE_GXM_TEXTURE_FILTER_LINEAR, SCE_GXM_TEXTURE_FILTER_LINEAR);

  sceTouchSetSamplingState(SCE_TOUCH_PORT_FRONT, SCE_TOUCH_SAMPLING_STATE_START);
  sceTouchSetSamplingState(SCE_TOUCH_PORT_BACK, SCE_TOUCH_SAMPLING_STATE_START);
  sceCtrlSetSamplingMode(SCE_CTRL_MODE_ANALOG);

  JSRuntime *rt = JS_NewRuntime();
  JS_SetMaxStackSize(rt, 2 * 1024 * 1024);
  JS_SetGCThreshold(rt, 80 * 1024 * 1024);   // the game runs the collector itself at whistles (__gc)
  JS_SetInterruptHandler(rt, js_watchdog, NULL);
  g_rt = rt;
  JSContext *ctx = JS_NewContext(rt);
  JSValue global = JS_GetGlobalObject(ctx);
  add_fn(ctx, global, "__now", js_now, 0);
  add_fn(ctx, global, "__log", js_log, 1);
  add_fn(ctx, global, "__readFile", js_read_file, 1);
  add_fn(ctx, global, "__writeFile", js_write_file, 2);
  add_fn(ctx, global, "__removeFile", js_remove_file, 1);
  add_fn(ctx, global, "__drawTris", js_draw_tris, 6);
  add_fn(ctx, global, "__drawGlyphs", js_draw_glyphs, 5);
  add_fn(ctx, global, "__input", js_input, 0);
  add_fn(ctx, global, "__gc", js_gc, 0);
  add_fn(ctx, global, "__sfxLoad", js_sfx_load, 2);
  add_fn(ctx, global, "__sfxPlay", js_sfx_play, 4);
  add_fn(ctx, global, "__sfxSet", js_sfx_set, 3);
  add_fn(ctx, global, "__sfxStop", js_sfx_stop, 1);
  au_start();

  if (!g_font_tex) { snprintf(g_err, sizeof(g_err), "Missing app0:font.png"); g_has_err = 1; }
  if (!g_has_err) eval_file(ctx, "app0:font_metrics.js");
  if (!g_has_err) eval_file(ctx, "app0:vita_shim.js");
  if (!g_has_err) eval_file(ctx, "app0:game.js");
  JSValue frame = JS_GetPropertyStr(ctx, global, "__vitaFrame");

  int running = 1;
  double fps = 0, js_ms = 0;
  SceUInt64 last = sceKernelGetProcessTimeWide();
  unsigned int lastV = sceDisplayGetVcount();
  while (running) {
    SceCtrlData pad;
    memset(&pad, 0, sizeof(pad));
    sceCtrlPeekBufferPositive(0, &pad, 1);
    if ((pad.buttons & SCE_CTRL_START) && (pad.buttons & SCE_CTRL_SELECT)) running = 0;

    vita2d_start_drawing();
    vita2d_clear_screen();
    SceUInt64 t0 = sceKernelGetProcessTimeWide();
    if (!g_has_err && JS_IsFunction(ctx, frame)) {
      g_frame_t0 = sceKernelGetProcessTimeWide();
      JSValue r = JS_Call(ctx, frame, global, 0, NULL);
      int stuck = g_frame_t0 && (sceKernelGetProcessTimeWide() - g_frame_t0) > 2000000ULL;
      g_frame_t0 = 0;
      if (JS_IsException(r)) {
        if (stuck && g_wd_hits < 20) {   // the watchdog stopped a runaway frame: log it, carry on
          JSValue ex = JS_GetException(ctx);
          JSValue st = JS_IsObject(ex) ? JS_GetPropertyStr(ctx, ex, "stack") : JS_UNDEFINED;
          const char *ss = JS_IsUndefined(st) ? NULL : JS_ToCString(ctx, st);
          char line[2048]; snprintf(line, sizeof(line), "WATCHDOG: a frame ran over 2s and was stopped\n%s", ss ? ss : "(no stack)");
          append_log(line); g_wd_hits++;
          if (ss) JS_FreeCString(ctx, ss);
          JS_FreeValue(ctx, st); JS_FreeValue(ctx, ex);
        } else capture_error(ctx, "frame");
      }
      JS_FreeValue(ctx, r);
      JSContext *jctx;
      while (JS_ExecutePendingJob(rt, &jctx) > 0) {}
    }
    SceUInt64 t1 = sceKernelGetProcessTimeWide();
    js_ms = js_ms * 0.9 + (double)(t1 - t0) / 1000.0 * 0.1;
    double dt = (double)(t1 - last) / 1000000.0;
    last = t1;
    if (dt > 0) fps = fps * 0.9 + (1.0 / dt) * 0.1;
    if (g_has_err) draw_error();
    else if ((pad.buttons & SCE_CTRL_SELECT) && g_pgf) {   // hold SELECT for a performance readout
      char line[96];
      snprintf(line, sizeof(line), "%.0f FPS   script %.1f ms", fps, js_ms);
      vita2d_draw_rectangle(6, 500, 300, 36, RGBA8(0, 0, 0, 180));
      vita2d_pgf_draw_text(g_pgf, 14, 526, RGBA8(124, 252, 154, 255), 1.0f, line);
    }
    vita2d_end_drawing();
    // steady 30 FPS: every frame is shown for exactly two refreshes (60 Hz screen), so motion
    // stays even instead of jumping between 60 and 40. A slow frame just shows on the next refresh.
    while ((int)(sceDisplayGetVcount() - lastV) < 2) sceDisplayWaitVblankStart();
    vita2d_swap_buffers();
    lastV = sceDisplayGetVcount();
  }

  vita2d_wait_rendering_done();
  au_stop();
  JS_FreeValue(ctx, frame);
  JS_FreeValue(ctx, global);
  JS_FreeContext(ctx);
  JS_FreeRuntime(rt);
  if (g_font_tex) vita2d_free_texture(g_font_tex);
  if (g_pgf) vita2d_free_pgf(g_pgf);
  vita2d_fini();
  sceKernelExitProcess(0);
  return 0;
}

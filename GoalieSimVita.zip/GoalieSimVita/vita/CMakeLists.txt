cmake_minimum_required(VERSION 3.16)

# ---- VitaSDK toolchain -------------------------------------------------------
if(NOT DEFINED CMAKE_TOOLCHAIN_FILE)
  if(DEFINED ENV{VITASDK})
    set(CMAKE_TOOLCHAIN_FILE "$ENV{VITASDK}/share/vita.toolchain.cmake" CACHE PATH "toolchain file")
  else()
    message(FATAL_ERROR "Please install VitaSDK and set the VITASDK environment variable (see README.md).")
  endif()
endif()

project(CHL2026 C)
include("$ENV{VITASDK}/share/vita.cmake" REQUIRED)

# ---- app identity (change TITLEID if you fork this into another app) ----------
set(VITA_APP_NAME "CHL 2026")
set(VITA_TITLEID  "GOAL00001")
set(VITA_VERSION  "00.10")   # v0.1

# ---- the game itself: extracted from the web build -----------------------------
set(GAME_HTML "${CMAKE_SOURCE_DIR}/../web/goalie.html" CACHE FILEPATH "web build to package")
set(GAME_JS   "${CMAKE_BINARY_DIR}/game.js")
add_custom_command(
  OUTPUT  ${GAME_JS}
  COMMAND ${CMAKE_COMMAND} -DIN=${GAME_HTML} -DOUT=${GAME_JS} -P ${CMAKE_SOURCE_DIR}/cmake/extract_game.cmake
  DEPENDS ${GAME_HTML} ${CMAKE_SOURCE_DIR}/cmake/extract_game.cmake
  COMMENT "Extracting game.js from goalie.html")
add_custom_target(game_js ALL DEPENDS ${GAME_JS})

# ---- QuickJS (JavaScript engine) -----------------------------------------------
# Downloaded at configure time. For offline builds pass -DQUICKJS_DIR=/path/to/quickjs-2024-01-13
set(QUICKJS_VERSION "2024-01-13")
if(NOT QUICKJS_DIR)
  include(FetchContent)
  FetchContent_Declare(quickjs
    URL https://bellard.org/quickjs/quickjs-${QUICKJS_VERSION}.tar.xz
    DOWNLOAD_EXTRACT_TIMESTAMP TRUE)
  FetchContent_GetProperties(quickjs)
  if(NOT quickjs_POPULATED)
    FetchContent_Populate(quickjs)
  endif()
  set(QUICKJS_DIR ${quickjs_SOURCE_DIR})
endif()
# Atomics need OS threads we don't use; compile a patched copy of quickjs.c without them.
file(READ "${QUICKJS_DIR}/quickjs.c" QJS_SRC)
string(REPLACE "#define CONFIG_ATOMICS" "/* CONFIG_ATOMICS disabled for PS Vita */" QJS_SRC "${QJS_SRC}")
# The Vita C library has no tm_gmtoff (timezone offset); the game never needs it, so use UTC.
string(REPLACE "res = -tm.tm_gmtoff / 60;" "res = 0; (void)tm;" QJS_SRC "${QJS_SRC}")
# No malloc_usable_size in the Vita C library; QuickJS only uses it for memory stats.
string(REPLACE "return malloc_usable_size((void *)ptr);" "return 0;" QJS_SRC "${QJS_SRC}")
file(WRITE "${CMAKE_BINARY_DIR}/qjs/quickjs.c" "${QJS_SRC}")
add_library(quickjs STATIC
  ${CMAKE_BINARY_DIR}/qjs/quickjs.c
  ${QUICKJS_DIR}/libregexp.c
  ${QUICKJS_DIR}/libunicode.c
  ${QUICKJS_DIR}/cutils.c
  ${QUICKJS_DIR}/libbf.c)   # big-number math used internally by QuickJS (BigInt)
target_include_directories(quickjs PUBLIC ${QUICKJS_DIR})
target_compile_definitions(quickjs PRIVATE CONFIG_VERSION="${QUICKJS_VERSION}" _GNU_SOURCE)
target_compile_options(quickjs PRIVATE -O2 -w)

# ---- the Vita executable ---------------------------------------------------------
add_executable(${PROJECT_NAME} src/main.c)
add_dependencies(${PROJECT_NAME} game_js)
target_compile_options(${PROJECT_NAME} PRIVATE -O2 -Wall)
# Optional libraries: link each one only if this VitaSDK install has it, so a renamed or
# missing stub can never break the build. Extra entries cost nothing.
set(OPTIONAL_LIBS
  bz2
  SceAppMgr_stub SceSysmem_stub SceKernelDmacMgr_stub SceLibKernel_stub SceIofilemgr_stub
  SceKernelThreadMgr_stub SceRtc_stub SceSharedFb_stub SceRegistryMgr_stub SceSysmodule_stub)
set(EXTRA_LIBS "")
foreach(lib ${OPTIONAL_LIBS})
  find_library(FOUND_${lib} ${lib})
  if(FOUND_${lib})
    list(APPEND EXTRA_LIBS ${FOUND_${lib}})
  else()
    message(STATUS "optional library not present: ${lib}")
  endif()
endforeach()
target_link_libraries(${PROJECT_NAME}
  quickjs
  vita2d
  SceDisplay_stub SceGxm_stub SceSysmodule_stub SceCtrl_stub SceTouch_stub SceAudio_stub
  ScePgf_stub ScePvf_stub SceCommonDialog_stub SceAppUtil_stub ScePower_stub
  freetype png jpeg z
  ${EXTRA_LIBS}
  m c)

vita_create_self(eboot.bin ${PROJECT_NAME} UNSAFE)
vita_create_vpk(${PROJECT_NAME}.vpk ${VITA_TITLEID} eboot.bin
  VERSION ${VITA_VERSION}
  NAME ${VITA_APP_NAME}
  FILE sce_sys/icon0.png sce_sys/icon0.png
  FILE sce_sys/livearea/contents/bg.png sce_sys/livearea/contents/bg.png
  FILE sce_sys/livearea/contents/startup.png sce_sys/livearea/contents/startup.png
  FILE sce_sys/livearea/contents/template.xml sce_sys/livearea/contents/template.xml
  FILE assets/font.png font.png
  FILE js/font_metrics.js font_metrics.js
  FILE js/vita_shim.js vita_shim.js
  FILE ${GAME_JS} game.js)
if(TARGET ${PROJECT_NAME}.vpk)
  add_dependencies(${PROJECT_NAME}.vpk game_js)
endif()

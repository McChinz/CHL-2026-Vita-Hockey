cmake_minimum_required(VERSION 3.16)
# Compatibility: older build workflows run "cmake -S vita -B build" (that used to be the JavaScript build, which is
# gone). This now builds the one and only game - the native C++ / vitaGL build in ../cpp - and leaves
# CHL2026Native.vpk in the build folder, where those workflows pick it up.
option(HOST "Build the desktop test version instead of the Vita app" OFF)
if(NOT HOST AND NOT DEFINED CMAKE_TOOLCHAIN_FILE)
  if(DEFINED ENV{VITASDK})
    set(CMAKE_TOOLCHAIN_FILE "$ENV{VITASDK}/share/vita.toolchain.cmake" CACHE PATH "toolchain file")
  else()
    message(FATAL_ERROR "Please install VitaSDK and set the VITASDK environment variable.")
  endif()
endif()
project(CHL2026 CXX)
add_subdirectory(${CMAKE_CURRENT_SOURCE_DIR}/../cpp native)

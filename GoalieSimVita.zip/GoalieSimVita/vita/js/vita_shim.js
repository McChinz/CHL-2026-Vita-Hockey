// vita_shim.js
// Browser-API layer that lets the unchanged web game (web/goalie.html) run on the PS Vita.
// Runs under QuickJS before game.js. Provides: window/document stubs, a Canvas 2D context
// (paths, arcs, ellipses, gradients, text, transforms), requestAnimationFrame, performance.now,
// localStorage (files in ux0:data/GoalieSim/), pointer events from the front touch screen,
// and rear-touch / L / R shortcuts for flattening the leg pads.
//
// Native functions (implemented in src/main.c):
//   __now() -> ms            __log(str)               __input() -> [front..., back..., buttons]
//   __readFile(path)->str|null   __writeFile(path,str)->bool   __removeFile(path)
//   __drawTris(Float32Array.buffer xy, Uint32Array.buffer colors, vertexCount [, dx, dy])
//   __drawGlyphs(Float32Array.buffer [dx,dy,u,v,w,h,scale]*n, n, color [, dx, dy])
(function (G) {
  'use strict';
  // ---- tuning knobs -------------------------------------------------------
  var SW = 960, SH = 544;            // Vita screen
  var STICK_DEAD = 0.2;              // analog stick dead zone (0..1)
  var DATA = 'ux0:data/GoalieSim/';

  // ---- window / document stubs ------------------------------------------
  G.window = G; G.self = G; G.__VITA = true;
  G.innerWidth = SW; G.innerHeight = SH; G.devicePixelRatio = 1;
  G.addEventListener = function () {}; G.removeEventListener = function () {};
  G.performance = { now: function () { return __now(); } };
  G.console = { log: function () { __log([].slice.call(arguments).join(' ')); } };
  G.console.warn = G.console.error = G.console.info = G.console.log;
  var timers = [];
  G.setTimeout = function (fn, ms) { timers.push({ fn: fn, at: __now() + (ms || 0) }); return timers.length; };
  var rafQ = [];
  G.requestAnimationFrame = function (cb) { rafQ.push(cb); return rafQ.length; };
  G.localStorage = {
    getItem: function (k) { var s = __readFile(DATA + k + '.json'); return s == null ? null : s; },
    setItem: function (k, v) { __writeFile(DATA + k + '.json', String(v)); },
    removeItem: function (k) { __removeFile(DATA + k + '.json'); }
  };
  var listeners = {};
  var canvas = {
    width: SW, height: SH, style: {},
    addEventListener: function (t, f) { (listeners[t] = listeners[t] || []).push(f); },
    removeEventListener: function () {}, setPointerCapture: function () {}, releasePointerCapture: function () {},
    getContext: function () { return ctx; }
  };
  G.document = {
    getElementById: function () { return canvas; },
    createElement: function () { return { style: {}, offsetHeight: 0, offsetWidth: 0 }; },
    body: { appendChild: function () {} },
    addEventListener: function () {}
  };

  // ---- colors -------------------------------------------------------------
  var NAMED = { white: [255, 255, 255, 1], black: [0, 0, 0, 1], transparent: [0, 0, 0, 0], red: [255, 0, 0, 1] };
  var ccache = {};
  function parseColor(s) {
    var c = ccache[s]; if (c) return c;
    var t = String(s).trim().toLowerCase(), m;
    if (t[0] === '#') {
      var h = t.slice(1);
      if (h.length === 3 || h.length === 4) h = h.split('').map(function (x) { return x + x; }).join('');
      c = [parseInt(h.substr(0, 2), 16), parseInt(h.substr(2, 2), 16), parseInt(h.substr(4, 2), 16), h.length >= 8 ? parseInt(h.substr(6, 2), 16) / 255 : 1];
    } else if ((m = /^rgba?\(([^)]*)\)/.exec(t))) {
      var p = m[1].split(',').map(function (x) { return parseFloat(x); });
      c = [p[0] | 0, p[1] | 0, p[2] | 0, p.length > 3 ? p[3] : 1];
    } else c = NAMED[t] || [255, 0, 255, 1];
    ccache[s] = c; return c;
  }
  function pack(r, g, b, a) {
    a = a < 0 ? 0 : a > 1 ? 1 : a;
    return (((a * 255 + .5) | 0) << 24 | (b & 255) << 16 | (g & 255) << 8 | (r & 255)) >>> 0;
  }

  // ---- gradients ----------------------------------------------------------
  function Grad(kind, a) { this.kind = kind; this.a = a; this.stops = []; }
  Grad.prototype.addColorStop = function (o, col) { this.stops.push([o, parseColor(col)]); this.stops.sort(function (x, y) { return x[0] - y[0]; }); };
  Grad.prototype.at = function (x, y) {
    var a = this.a, t;
    if (this.kind === 'L') { var dx = a[2] - a[0], dy = a[3] - a[1], L = dx * dx + dy * dy || 1; t = ((x - a[0]) * dx + (y - a[1]) * dy) / L; }
    else { var d = Math.hypot(x - a[3], y - a[4]); t = (d - a[2]) / ((a[5] - a[2]) || 1); }
    var s = this.stops; if (!s.length) return [0, 0, 0, 0];
    if (t <= s[0][0]) return s[0][1];
    for (var i = 1; i < s.length; i++) if (t <= s[i][0]) {
      var p = s[i - 1], q = s[i], f = (t - p[0]) / ((q[0] - p[0]) || 1), A = p[1], B = q[1];
      return [A[0] + (B[0] - A[0]) * f, A[1] + (B[1] - A[1]) * f, A[2] + (B[2] - A[2]) * f, A[3] + (B[3] - A[3]) * f];
    }
    return s[s.length - 1][1];
  };

  // ---- triangle batch -----------------------------------------------------
  var MAXV = 30000, VP = new Float32Array(MAXV * 2), VC = new Uint32Array(MAXV), vn = 0;
  function flush() { if (vn) { __drawTris(VP.buffer, VC.buffer, vn); vn = 0; } }
  function vert(x, y, c) { if (vn >= MAXV) flush(); VP[vn * 2] = x; VP[vn * 2 + 1] = y; VC[vn] = c; vn++; }
  function tri(x0, y0, c0, x1, y1, c1, x2, y2, c2) { if (vn + 3 > MAXV) flush(); vert(x0, y0, c0); vert(x1, y1, c1); vert(x2, y2, c2); }

  // ---- context state ------------------------------------------------------
  function State() {
    this.a = 1; this.b = 0; this.c = 0; this.d = 1; this.e = 0; this.f = 0;
    this.globalAlpha = 1; this.fillStyle = '#000'; this.strokeStyle = '#000'; this.lineWidth = 1;
    this.font = '10px sans-serif'; this.textAlign = 'start'; this.textBaseline = 'alphabetic';
    this.lineCap = 'butt'; this.lineJoin = 'miter';
  }
  var S = new State(), stack = [];
  function copyState(s) { var n = new State(); for (var k in s) n[k] = s[k]; return n; }
  function scaleOf() { return Math.sqrt(Math.abs(S.a * S.d - S.b * S.c)) || 1; }

  // paths: each sub = {u:[x,y,...] user coords, closed}
  var subs = [], cur = null, lastX = 0, lastY = 0;
  function newSub(x, y) { cur = { u: [x, y], closed: false }; subs.push(cur); lastX = x; lastY = y; }
  function addPt(x, y) { if (!cur) newSub(x, y); else { cur.u.push(x, y); lastX = x; lastY = y; } }
  function segs(r, sweep) { var n = Math.ceil(Math.abs(sweep) * Math.max(1, r * scaleOf()) / 9); return n < 5 ? 5 : n > 48 ? 48 : n; }
  function normSweep(a0, a1, ccw) {
    var TAU = Math.PI * 2, sw = a1 - a0;
    if (!ccw) { if (sw >= TAU) sw = TAU; else { while (sw < 0) sw += TAU; } }
    else { if (sw <= -TAU) sw = -TAU; else { while (sw > 0) sw -= TAU; } }
    return sw;
  }
  function ellipsePts(x, y, rx, ry, rot, a0, a1, ccw) {
    var sw = normSweep(a0, a1, ccw), n = segs(Math.max(rx, ry), sw), cr = Math.cos(rot), sr = Math.sin(rot);
    for (var i = 0; i <= n; i++) {
      var t = a0 + sw * i / n, px = rx * Math.cos(t), py = ry * Math.sin(t);
      addPt(x + px * cr - py * sr, y + px * sr + py * cr);
    }
  }
  function txp(x, y) { return [S.a * x + S.c * y + S.e, S.b * x + S.d * y + S.f]; }
  function styleColorAt(style, x, y, alpha) {
    var c = (style instanceof Grad) ? style.at(x, y) : parseColor(style);
    return pack(c[0], c[1], c[2], c[3] * alpha);
  }

  function fillSubs(style) {
    var ga = S.globalAlpha, isG = style instanceof Grad, cc = isG ? 0 : styleColorAt(style, 0, 0, ga);
    for (var s = 0; s < subs.length; s++) {
      var u = subs[s].u, n = u.length / 2; if (n < 3) continue;
      var cx = 0, cy = 0; for (var i = 0; i < n; i++) { cx += u[i * 2]; cy += u[i * 2 + 1]; } cx /= n; cy /= n;
      var A = S.a, B = S.b, Cm = S.c, D = S.d, E = S.e, Fm = S.f;
      var Cx = A * cx + Cm * cy + E, Cy = B * cx + D * cy + Fm, Cc = isG ? styleColorAt(style, cx, cy, ga) : cc;
      var ux = u[(n - 1) * 2], uy = u[(n - 1) * 2 + 1];
      var px = A * ux + Cm * uy + E, py = B * ux + D * uy + Fm, pc = isG ? styleColorAt(style, ux, uy, ga) : cc;
      for (var j = 0; j < n; j++) {
        ux = u[j * 2]; uy = u[j * 2 + 1];
        var qx = A * ux + Cm * uy + E, qy = B * ux + D * uy + Fm, qc = isG ? styleColorAt(style, ux, uy, ga) : cc;
        if (vn + 3 > MAXV) flush();
        var o = vn * 2;
        VP[o] = Cx; VP[o + 1] = Cy; VP[o + 2] = px; VP[o + 3] = py; VP[o + 4] = qx; VP[o + 5] = qy;
        VC[vn] = Cc; VC[vn + 1] = pc; VC[vn + 2] = qc; vn += 3;
        px = qx; py = qy; pc = qc;
      }
    }
  }
  function disc(x, y, r, c) { var n = Math.max(8, Math.min(24, Math.ceil(r))); var px = x + r, py = y;
    for (var i = 1; i <= n; i++) { var t = i / n * Math.PI * 2, qx = x + r * Math.cos(t), qy = y + r * Math.sin(t); tri(x, y, c, px, py, c, qx, qy, c); px = qx; py = qy; } }
  function strokeSubs(style) {
    var ga = S.globalAlpha, c = styleColorAt(style instanceof Grad ? '#fff' : style, 0, 0, ga);
    var hw = Math.max(.5, S.lineWidth * scaleOf() / 2), round = S.lineCap === 'round';
    var A = S.a, B = S.b, Cm = S.c, D = S.d, E = S.e, Fm = S.f;
    for (var s = 0; s < subs.length; s++) {
      var u = subs[s].u, n = u.length / 2; if (n < 2) continue;
      var closedFlag = subs[s].closed, segN = closedFlag ? n : n - 1;
      var fx = A * u[0] + Cm * u[1] + E, fy = B * u[0] + D * u[1] + Fm;
      var lx = A * u[(n - 1) * 2] + Cm * u[(n - 1) * 2 + 1] + E, ly = B * u[(n - 1) * 2] + D * u[(n - 1) * 2 + 1] + Fm;
      var closed = closedFlag || (n > 2 && Math.abs(fx - lx) + Math.abs(fy - ly) < .7);
      var ax = fx, ay = fy;
      for (var k = 0; k < segN; k++) {
        var j = (k + 1) % n, bx = A * u[j * 2] + Cm * u[j * 2 + 1] + E, by = B * u[j * 2] + D * u[j * 2 + 1] + Fm;
        var dx = bx - ax, dy = by - ay, L = Math.sqrt(dx * dx + dy * dy);
        if (L > 1e-4) {
          var nx = -dy / L * hw, ny = dx / L * hw, ex = dx / L * hw * .5, ey = dy / L * hw * .5;
          var sx = (k > 0 || closed) ? ax - ex : ax, sy = (k > 0 || closed) ? ay - ey : ay, tx = bx + ex, ty = by + ey;
          tri(sx + nx, sy + ny, c, tx + nx, ty + ny, c, tx - nx, ty - ny, c);
          tri(sx + nx, sy + ny, c, tx - nx, ty - ny, c, sx - nx, sy - ny, c);
        }
        ax = bx; ay = by;
      }
      if (round && !closed) { disc(fx, fy, hw, c); disc(ax, ay, hw, c); }
    }
  }

  // ---- text (bitmap atlas from tools/make_font.py) -----------------------
  var F = G.__FONT, GBUF = new Float32Array(7 * 256);
  var glyphOut = function (buf, n, col) { __drawGlyphs(buf, n, col); };
  function fontPx() { var m = /(\d*\.?\d+)px/.exec(S.font); return m ? parseFloat(m[1]) : 10; }
  function glyph(ch) { return F.g[ch.charCodeAt(0)] || F.g[63]; }
  function measure(str, px) { var w = 0; for (var i = 0; i < str.length; i++) w += glyph(str[i])[6]; return w * px / F.size; }
  function drawText(str, x, y, style, offs) {
    str = String(str); if (!str.length) return;
    flush();
    var px = fontPx(), w = measure(str, px), al = S.textAlign;
    if (al === 'center') x -= w / 2; else if (al === 'right' || al === 'end') x -= w;
    var k = px / F.size, bl = S.textBaseline;
    if (bl === 'middle') y += (F.asc - F.desc) / 2 * k; else if (bl === 'top' || bl === 'hanging') y += F.asc * k; else if (bl === 'bottom' || bl === 'ideographic') y -= F.desc * k;
    var p = txp(x, y), sc = Math.sqrt(S.a * S.a + S.b * S.b) || 1, gs = k * sc;
    var col = styleColorAt(style instanceof Grad ? '#fff' : style, 0, 0, S.globalAlpha);
    var o = offs || [[0, 0]];
    for (var q = 0; q < o.length; q++) {
      var pen = p[0] + o[q][0], n = 0;
      for (var i = 0; i < str.length; i++) {
        var gl = glyph(str[i]);
        if (str[i] !== ' ') {
          if (n * 7 + 7 > GBUF.length) { glyphOut(GBUF.buffer, n, col); n = 0; }
          var j = n * 7;
          GBUF[j] = pen + gl[4] * gs; GBUF[j + 1] = p[1] + o[q][1] + gl[5] * gs;
          GBUF[j + 2] = gl[0]; GBUF[j + 3] = gl[1]; GBUF[j + 4] = gl[2]; GBUF[j + 5] = gl[3]; GBUF[j + 6] = gs; n++;
        }
        pen += gl[6] * gs;
      }
      if (n) glyphOut(GBUF.buffer, n, col);
    }
  }

  // ---- the 2D context -----------------------------------------------------
  var ctx = {
    canvas: canvas,
    save: function () { stack.push(copyState(S)); },
    restore: function () { if (stack.length) S = stack.pop(); },
    setTransform: function (a, b, c, d, e, f) { S.a = a; S.b = b; S.c = c; S.d = d; S.e = e; S.f = f; },
    resetTransform: function () { this.setTransform(1, 0, 0, 1, 0, 0); },
    translate: function (x, y) { S.e += S.a * x + S.c * y; S.f += S.b * x + S.d * y; },
    scale: function (x, y) { S.a *= x; S.b *= x; S.c *= y; S.d *= y; },
    rotate: function (r) { var c = Math.cos(r), s = Math.sin(r), a = S.a, b = S.b, cc = S.c, d = S.d;
      S.a = a * c + cc * s; S.b = b * c + d * s; S.c = cc * c - a * s; S.d = d * c - b * s; },
    beginPath: function () { subs = []; cur = null; },
    closePath: function () { if (cur) { cur.closed = true; lastX = cur.u[0]; lastY = cur.u[1]; cur = null; } },
    moveTo: function (x, y) { newSub(x, y); },
    lineTo: function (x, y) { addPt(x, y); },
    rect: function (x, y, w, h) { newSub(x, y); addPt(x + w, y); addPt(x + w, y + h); addPt(x, y + h); cur.closed = true; },
    arc: function (x, y, r, a0, a1, ccw) { ellipsePts(x, y, r, r, 0, a0, a1, !!ccw); },
    ellipse: function (x, y, rx, ry, rot, a0, a1, ccw) { ellipsePts(x, y, rx, ry, rot, a0, a1, !!ccw); },
    arcTo: function (x1, y1, x2, y2, r) {
      if (!cur) newSub(x1, y1);
      var x0 = lastX, y0 = lastY, v1x = x0 - x1, v1y = y0 - y1, v2x = x2 - x1, v2y = y2 - y1;
      var l1 = Math.hypot(v1x, v1y), l2 = Math.hypot(v2x, v2y);
      if (l1 < 1e-6 || l2 < 1e-6 || r <= 0) { addPt(x1, y1); return; }
      v1x /= l1; v1y /= l1; v2x /= l2; v2y /= l2;
      var cross = v1x * v2y - v1y * v2x, dot = v1x * v2x + v1y * v2y;
      if (Math.abs(cross) < 1e-6) { addPt(x1, y1); return; }
      var th = Math.acos(Math.max(-1, Math.min(1, dot))), d = r / Math.tan(th / 2);
      var t1x = x1 + v1x * d, t1y = y1 + v1y * d, t2x = x1 + v2x * d, t2y = y1 + v2y * d;
      var bx = v1x + v2x, by = v1y + v2y, bl = Math.hypot(bx, by), h = r / Math.sin(th / 2);
      var cx = x1 + bx / bl * h, cy = y1 + by / bl * h;
      addPt(t1x, t1y);
      ellipsePts(cx, cy, r, r, 0, Math.atan2(t1y - cy, t1x - cx), Math.atan2(t2y - cy, t2x - cx), cross > 0);
    },
    fill: function () { fillSubs(S.fillStyle); },
    stroke: function () { strokeSubs(S.strokeStyle); },
    fillRect: function (x, y, w, h) {
      var st = S.fillStyle, ga = S.globalAlpha, isG = st instanceof Grad;
      var c0 = styleColorAt(st, x, y, ga), c1 = isG ? styleColorAt(st, x + w, y, ga) : c0, c2 = isG ? styleColorAt(st, x + w, y + h, ga) : c0, c3 = isG ? styleColorAt(st, x, y + h, ga) : c0;
      var p0 = txp(x, y), p1 = txp(x + w, y), p2 = txp(x + w, y + h), p3 = txp(x, y + h);
      tri(p0[0], p0[1], c0, p1[0], p1[1], c1, p2[0], p2[1], c2); tri(p0[0], p0[1], c0, p2[0], p2[1], c2, p3[0], p3[1], c3);
    },
    strokeRect: function (x, y, w, h) { var sv = subs, cv = cur; subs = []; this.rect(x, y, w, h); this.stroke(); subs = sv; cur = cv; },
    clearRect: function () {},
    fillText: function (t, x, y) { drawText(t, x, y, S.fillStyle); },
    strokeText: function (t, x, y) {
      var r = Math.max(1, S.lineWidth / 2), d = r * .7071;
      drawText(t, x, y, S.strokeStyle, [[-r, 0], [r, 0], [0, -r], [0, r], [-d, -d], [d, -d], [-d, d], [d, d]]);
    },
    measureText: function (t) { return { width: measure(String(t), fontPx()) }; },
    createLinearGradient: function (x0, y0, x1, y1) { return new Grad('L', [x0, y0, x1, y1]); },
    createRadialGradient: function (x0, y0, r0, x1, y1, r1) { return new Grad('R', [x0, y0, r0, x1, y1, r1]); },
    setLineDash: function () {}, clip: function () {}, drawImage: function () {}
  };
  // Draw-list cache: game code wraps static-looking layers in ctx.cacheBlock(key, fn). The first
  // call records the triangle and glyph batches fn produces; later calls with the same key (and
  // same scale/rotation) replay them through the native side with one call per batch, shifted by
  // any change in translation. This skips all of the path math for the replayed layer.
  var cache = {}, cacheKeys = [], rec = null;
  var _flush = flush;
  flush = function () {
    if (rec && vn) rec.push({ t: 0, p: VP.slice(0, vn * 2), c: VC.slice(0, vn), n: vn });
    _flush();
  };
  glyphOut = function (buf, n, col) {
    if (rec) rec.push({ t: 1, g: new Float32Array(buf, 0, n * 7).slice(), n: n, c: col });
    __drawGlyphs(buf, n, col);
  };
  ctx.cacheBlock = function (key, fn) {
    var tk = key + '|' + S.a + ',' + S.b + ',' + S.c + ',' + S.d + '|' + S.globalAlpha;
    if (rec) { fn(); return; }        // nested blocks are recorded as part of the outer one
    var c = cache[tk];
    if (c) {
      flush();
      var dx = S.e - c.e, dy = S.f - c.f, L = c.cmds;
      for (var i = 0; i < L.length; i++) {
        var m = L[i];
        if (m.t) __drawGlyphs(m.g.buffer, m.n, m.c, dx, dy); else __drawTris(m.p.buffer, m.c.buffer, m.n, dx, dy);
      }
      return;
    }
    flush();
    rec = [];
    var e0 = S.e, f0 = S.f;
    fn();
    flush();
    cache[tk] = { cmds: rec, e: e0, f: f0 };
    rec = null;
    cacheKeys.push(tk);
    if (cacheKeys.length > 700) delete cache[cacheKeys.shift()];
  };
  ['globalAlpha', 'fillStyle', 'strokeStyle', 'lineWidth', 'font', 'textAlign', 'textBaseline', 'lineCap', 'lineJoin'].forEach(function (k) {
    Object.defineProperty(ctx, k, { get: function () { return S[k]; }, set: function (v) { S[k] = v; } });
  });

  // ---- input --------------------------------------------------------------
  var front = {}, back = {}, prevBtn = 0;
  function fire(type, id, x, y) {
    var l = listeners[type]; if (!l) return;
    var ev = { type: type, pointerId: id, clientX: x, clientY: y, button: 0, isPrimary: true, preventDefault: function () {} };
    for (var i = 0; i < l.length; i++) l[i](ev);
  }
  function flatten(side) { if (typeof flattenPad === 'function') flattenPad(side); }
  var stickOn = { L: false, R: false };
  function restOf(k) { return { x: W * (k === 'L' ? .3 : .7), y: H * .78 }; }
  function driveHand(k, ax, ay) {
    if (typeof hands === 'undefined' || typeof state === 'undefined') return;
    var h = hands[k]; if (!h || h.id !== null) return;          // a finger on the screen wins
    var nx = (ax - 128) / 127, ny = (ay - 128) / 127, mag = Math.sqrt(nx * nx + ny * ny);
    var rest = restOf(k), lim = .08 * U;
    if (mag < STICK_DEAD) {
      if (stickOn[k]) { stickOn[k] = false; h.tx = rest.x; h.ty = rest.y; }
      return;
    }
    stickOn[k] = true;
    var sc = Math.min(1, (mag - STICK_DEAD) / (1 - STICK_DEAD)) / mag; nx *= sc; ny *= sc;
    var minX = k === 'L' ? 0 : W / 2 - lim, maxX = k === 'L' ? W / 2 + lim : W;
    var tx = nx < 0 ? rest.x + nx * (rest.x - minX) : rest.x + nx * (maxX - rest.x);
    var ty = ny < 0 ? rest.y + ny * (rest.y - H * .3) : rest.y + ny * (H - rest.y);
    h.tx = Math.max(minX, Math.min(maxX, tx)); h.ty = Math.max(H * .3, Math.min(H, ty));
  }
  function handleInput(a) {
    var i = 0, n = a[i++], seen = {}, k, id, x, y;
    for (k = 0; k < n; k++) {
      id = a[i++] + 1; x = a[i++]; y = a[i++]; seen[id] = 1;
      if (!front[id]) { front[id] = { x: x, y: y }; fire('pointerdown', id, x, y); }
      else if (front[id].x !== x || front[id].y !== y) { front[id].x = x; front[id].y = y; fire('pointermove', id, x, y); }
    }
    for (k in front) if (!seen[k]) { var p = front[k]; delete front[k]; fire('pointerup', +k, p.x, p.y); }
    n = a[i++]; i += n * 3;                                       // rear touch pad: unused
    var btn = a[i++] | 0, press = btn & ~prevBtn; prevBtn = btn;
    var lx = a[i++], ly = a[i++], rx = a[i++], ry = a[i++];
    if (press & 4) { if (typeof togglePause === 'function') togglePause(); }
    var live = typeof state !== 'undefined' && state === 'play' && !(typeof paused !== 'undefined' && paused);
    // forward (top-down) games read the pad directly: sticks, X/O pass, SQUARE shoot
    var skater = typeof playType !== 'undefined' && playType === 'skater';
    G.__pad = skater && live ? { lx: lx, ly: ly, rx: rx, ry: ry, btn: btn, press: press } : null;
    if (skater) { stickOn.L = stickOn.R = false; return; }
    if (live) {
      if (press & 1) flatten('L');
      if (press & 2) flatten('R');
      if (lx !== undefined) { driveHand('L', lx, ly); driveHand('R', rx, ry); }
    } else { stickOn.L = stickOn.R = false; }
  }

  // ---- frame entry point (called by main.c once per vblank) ---------------
  G.__vitaFrame = function () {
    handleInput(__input());
    var now = __now();
    if (timers.length) { var due = timers.filter(function (t) { return t.at <= now; }); timers = timers.filter(function (t) { return t.at > now; }); due.forEach(function (t) { t.fn(); }); }
    var q = rafQ; rafQ = [];
    for (var i = 0; i < q.length; i++) q[i](now);
    flush();
  };
})(globalThis);

# Pulls the <script> block out of web/goalie.html into game.js so the web build stays the
# single source of truth. Invoked at build time: cmake -DIN=... -DOUT=... -P extract_game.cmake
file(READ "${IN}" html)
string(FIND "${html}" "<script>" s)
string(FIND "${html}" "</script>" e REVERSE)
if(s EQUAL -1 OR e EQUAL -1 OR e LESS s)
  message(FATAL_ERROR "No <script>...</script> block found in ${IN}")
endif()
math(EXPR s "${s} + 8")
math(EXPR len "${e} - ${s}")
string(SUBSTRING "${html}" ${s} ${len} js)
file(WRITE "${OUT}" "// generated from web/goalie.html - edit that file, not this one\n${js}")

# CHL 2026 - v0.1 (PS Vita build)

This folder turns the web game into a PS Vita homebrew app (`CHL2026.vpk`).

**The game itself is not rewritten.** `web/goalie.html` is the same file as the browser
version and is the only place gameplay lives. At build time its `<script>` is extracted and run on
the Vita by the QuickJS JavaScript engine. A small compatibility layer draws everything with vita2d.
So any change you make to the web version (or ask Claude to make) carries over: replace
`web/goalie.html`, rebuild, reinstall.

```
web/goalie.html            the game (edit this)
vita/src/main.c            native host: QuickJS + vita2d + touch/buttons + save files
vita/js/vita_shim.js       browser layer: Canvas 2D, pointer events, localStorage, rear touch
vita/js/font_metrics.js    generated with the font atlas
vita/assets/font.png       text atlas (DejaVu Sans Bold)
vita/sce_sys/              home-screen icon and LiveArea art
vita/CMakeLists.txt        build script; produces build/CHL2026.vpk
tools/                     font/LiveArea generators and a desktop preview
.github/workflows/         cloud build (no local SDK needed)
```

## Getting the .vpk

### Option A – build in the cloud (nothing to install)
1. Create a GitHub repository and upload this whole folder (keep the `.github` folder).
2. Open the **Actions** tab. The "Build VPK" workflow runs on every push (or press *Run workflow*).
3. When it finishes, download **CHL2026-vpk** from the run's *Artifacts* section and unzip it.

### Option B – build on your computer
1. Install VitaSDK (Linux, macOS, or Windows via WSL): https://vitasdk.org
   `export VITASDK=/usr/local/vitasdk` and `export PATH=$VITASDK/bin:$PATH`
2. Make sure the libraries are present: `vdpm libvita2d freetype libpng zlib libjpeg-turbo`
3. From this folder:
   ```
   cmake -S vita -B build
   cmake --build build -j4
   ```
   The first configure downloads QuickJS (`quickjs-2024-01-13`). Offline? Download it once and pass
   `-DQUICKJS_DIR=/path/to/quickjs-2024-01-13`.
4. Result: `build/CHL2026.vpk`

### Installing on the Vita
Requires a Vita running HENkaku/Ensō with VitaShell. Copy the `.vpk` to `ux0:` (USB or FTP in
VitaShell), select it in VitaShell, and install. The bubble is called **CHL 2026** (title ID `GOAL00001`).

## Native C++ build (CHL 2026 NATIVE) - in progress
The game is being moved off the browser layer (JavaScript in QuickJS) to plain C++, one mode at a time. The
JS build above is untouched and keeps every mode; the native build is a **separate app** next to it:
bubble **CHL 2026 NATIVE**, title ID `GOAL00002`, its own folder `ux0:data/GoalieSimNative`.

**Done so far:**
- **The legacy main menu**, 1:1: the key-art CONTINUE panel, BE A PRO / ULTIMATE FRANCHISE / QUICK PLAY /
  PRACTICE / SETTINGS, the settings screen, the name keyboard, the result screen, the YES / NO box, the mode
  transitions, D-pad / stick navigation with the legacy focus marker (touch works on every menu).
- **Ultimate Franchise**, 1:1 with the legacy build: every NHL roster (skaters and goalies), the legends, and
  the **2026 draft class** (McKenna, Stenberg, Malhotra... as cards of the clubs that drafted them). Packs,
  the shop, inventory and pack opening; the roster with the card menu (add / swap / examine / upgrade / quick
  sell), sell duplicates, auto lineup, the salary cap and cap raises; **EXAMINE** (the card flips to every
  rating, its perks, height / weight, salary and his line with your team); CPU opponents (EASY / EVEN / HARD);
  Road to the Cup; coins, records and card stats. Card ratings and CPU teams come out exactly as in the
  legacy build (checked card by card), and **legacy Ultimate Franchise saves are imported** on the first run
  (from `ux0:data/GoalieSim/`, left untouched).
- **Quick Play as a forward**, with everything from the legacy forward game (stick shooting, dekes, toe drags,
  saucer and power passes, hits, pokes, blocks, board battles, bouncing pucks and chop-downs, rebounds, tips,
  deflections, perks, penalties, icing, goalie pulls, line changes, stamina, overtime and the shootout...).
- **New controls (every mode):** hold **L** with the puck and a Square / Triangle / Circle icon appears over
  each teammate - press one to pass to him. The **spin** is a quick 360 on the left stick. A yellow **!** over
  a teammate means he's calling for it (open net, or a better look than yours). L without the puck still
  blocks shots. On the ice the game is pad-only; touch is for the menus.

- **3D view (first pass):** a perspective broadcast camera behind the play, with low-poly lit models for the
  skaters (stride, lean, wind-up, pokes, spins, falls, blocks), goalies (stance, butterfly, dives, glove and
  blocker), the ref, the puck, both nets and the arena (ice markings, boards, glass, stands). Same game
  underneath. **SELECT** switches between 3D and the classic view (remembered).
- **vitaGL renderer:** the GPU draws the 3D view with a real depth buffer (no more draw-order glitches), 4x
  anti-aliasing on everything, and polished ice that reflects the players, nets and boards. Needs
  `ur0:data/libshacccg.suprx` on the Vita (vitaGL's shader compiler - install it once with ShaRKF00D; if it's
  missing the game writes `ux0:data/GoalieSimNative/README_libshacccg.txt`). The build also makes
  `CHL2026Native-vita2d.vpk`, the same game on the old vita2d renderer, as a fallback.
- **Physical saves (every mode, Ultimate Franchise included):** the puck is a real (small, NHL-sized) object and
  the goalie's body is solid - pads, glove, blocker, stick, arms, chest and mask are the same shapes the 3D view
  draws. A shot only goes in if it finds a real hole: the five-hole, over a shoulder, past a glove that went to
  the wrong spot. Pucks flutter (they wobble and dip a little in the air) and soft ones can trickle off a pad.
- **Goalie ratings split high / low:** every goalie now has **GLOVE HIGH, GLOVE LOW, BLOCKER HIGH and BLOCKER
  LOW** (shown on his card; GLOVE and BLOCKER are their averages, so overalls didn't change). A shot's height and
  side decide which one he needs: the better it is, the more often he reads the shot and gets there. The
  **glove catches** (no rebound - a faceoff; a weak glove bobbles it); the **blocker steers** it into the corner
  or onto a teammate's stick (a weak one leaves a rebound in the slot, or lets one squeak in behind him).
  Low shots drop him into the butterfly; low and wide kicks a pad out along the ice.
- **Camera HIGH / LOW (skaters, 3D view):** HIGH is the NHL-style overhead camera (straight down, tipped a little
  toward the attack, which runs up the screen); LOW is the broadcast camera. Switch it in **Settings** or mid-game
  on the pause screen (**CAMERA: HIGH / LOW**); it's remembered.
- **Polish pass:** full NHL ice (crease outlines, hash marks and L's at the circles, the trapezoid behind each net,
  the referee's crease, the home team's logo at centre ice); slimmer, more athletic skaters with carbon sticks who
  lean into their turns; goalies seal the post (reverse-VH, pad flat along the goal line) when the puck is down low
  at a sharp angle or behind the net, and butterfly-slide when they push across the crease - with their real body,
  so those positions really cover the ice.
- **NHL-style shooting:** the shot is on the **right stick** again, so you can aim while you skate. Hold it **up**
  to prime a wrist shot, hold it **back** to wind up a slap shot, and **let go** to shoot. Once it's primed the whole
  half circle counts - slide the stick left / right while holding to aim across the net (a loaded slapper pushed
  all the way up is a fake). While you hold it, an **aim cone** runs from the puck to the net, as wide as your
  accuracy: **blue** where it would find open net, **pink** where the goalie's body is in the way (traced against
  his real body). A target ring stands in the net mouth where you're aiming - if the goalie's body hides it, he's
  covering it.
  The cone and ring only show while you're holding a shot.
- **Shot controls TYPE A / TYPE B (Settings):** TYPE A is the right-stick shot above. TYPE B: the right stick only
  aims (tilt it and the cone shows); **tap R** for a wrist shot, **hold R** to wind up a slap shot and let go to
  fire. With the puck in TYPE B, **tap X to pass, hold X to sprint** (R still sprints without the puck).
- **Hot (and cold) goalies:** about one night in eight a goalie is HOT - he reads almost everything, reacts sooner,
  holds his angle and catches more cleanly (roughly a third fewer goals against); one in eight he's off. Every save
  builds his confidence and every goal knocks it back, so a goalie can get hot during a game too ("THEIR GOALIE IS
  FEELING IT"). Ratings all count: shooters' accuracy and power, poise (shooting with a man on you), deking and hands
  (dekes, and goalies biting on them), and the AI shoots at each goalie's weaker high / low spot on each side.
- **Goalie angles:** goalies play the angle - on the line from the puck to the middle of the net. Against a shooter
  far out they skate up to the top of the crease and take the net away (long shots rarely go in); as a skater
  comes in they skate backward into the net to stay square; at a sharp angle they stay on the post. How well they
  hold that line is their **SHOT READ**: a poor reader drifts off it, and a quick pass across leaves anyone a step
  behind - open net you'll see in the aim cone.
- **Performance / looks pass:** the ice, its markings and the crowd are built once per game and handed to the GPU
  as-is each frame; the crowd is now tiered rows of individual fans (many in the home colours) instead of flat
  colour blocks. Players far from the camera are drawn with fewer polygons (and no reflection); the goalie's body is
  worked out once a frame for both the picture and the physics. Big draws go to the GPU in pieces (vitaGL draws are
  16-bit indexed, so one huge draw dropped the players drawn last), and kept geometry is cut at the camera's near
  plane every frame (otherwise it smeared into strips). The net's strands and the goalie's cage are a touch thicker so they don't crawl, and the picture
  flips on the vertical blank (no tearing).
- **Benches, ice lights, cameras:** both team benches sit behind the far boards either side of centre with the
  players who are off the ice on them - swaying, fidgeting, leaning toward the play, and up on their feet with their
  arms in the air when their team scores. The arena lights reflect in the ice as soft glows that slide across it as
  the camera moves. CAMERA HIGH is now straight overhead with the full width of the ice in view; CAMERA LOW sits up
  over the end at about 40 degrees; both run right to each end, so your own net shows at the bottom of the screen in
  your zone and theirs at the top. Goalies skate to their creases before a faceoff (the puck waits for them), and sit
  back in the crease when the play is up the ice.

Coming next: Be a Pro (1:1, careers carry over), then goalie mode, practice and the rest.

How it's built (`cpp/`):
```
cpp/src/canvas.*        the drawing model the game was written against, now in C++ (paths, gradients,
                        text, the replay cache) - turns everything into triangles and font glyphs
cpp/src/platform_vitagl.cpp the vitaGL renderer (main build); platform_vita.cpp: the vita2d one (fallback)
cpp/src/vita_sys.cpp    the rest of the Vita side: pad + touch, the audio thread, files, 30 FPS pacing
cpp/src/audio.*         the synthesized sounds and the mixer
cpp/src/sk_draw3d.cpp   the 3D view: camera, projection, low-poly models, back-to-front triangles
cpp/src/sk_*.cpp        the forward game: setup and physics (core), controls / AI / goalies (play),
                        update loop / puck / goals / lines (flow), drawing (draw)
cpp/src/hud.cpp, ui.cpp the HUD and matchup screen; pause screen, transitions
cpp/src/menu.cpp        the legacy menus, pad navigation, the router
cpp/src/league.*, data.* players and ratings (all modes), the 32 teams, legends, the 2026 draft
cpp/src/ut*.cpp         Ultimate Franchise (logic + saves, screens); save.cpp: settings, imports
cpp/src/platform_host.cpp, test_main.cpp   a PC test build: software renderer, scripted input
```
Build it with the cloud workflow (it now builds both apps; the native one is the **GoalieSim-native-vpk**
artifact, with `native-build.log` if anything fails) or locally: `cmake -S cpp -B build-native && cmake --build build-native`.
PC test build: `cmake -S cpp -B build-host -DHOST=ON && cmake --build build-host`, then
`build-host/chl_host games 100` plays 100 CPU-vs-CPU games and prints the averages
(`human 5` plays with a scripted pad, `shots DIR 300 900` saves frames; run it from a folder with `font.rgba`,
made by `python3 tools/font_rgba.py`).
Quit the native app with START + SELECT.

## Be a Pro career
- **32 real teams** in four divisions (Atlantic, Metropolitan, Central, Pacific) with their real
  colours. Each team carries its 9 best skaters and 2 goalies from the 2026-27 rosters (summer
  2026 trades and signings included). Salaries are random on every new save; draft classes are
  always made-up players.
- **80-game season**, then a **16-team bracket**: top 3 in each division + 2 wild cards per
  conference, East on the left and West on the right, best of 3 every round.
- **Three lines of three.** Lines change every other faceoff and every period (and on the fly
  after a long shift). As a forward you center every line and your wingers rotate.
- **Two goalies per team** split the starts. As a goalie you can be the backup some nights:
  sim the game or train first, then watch from the bench.
- **Office** (hub menu): contract and pay, extensions in the final year, no-trade clause
  requests, trade requests (pick up to 10 teams, you move in a week if one can fit you under the
  cap), and trade offers you can accept or reject when you have a no-trade clause. When your
  contract expires you must sign before your next game, or walk into free agency. Bigger
  contracts pay more cash per game.
- **Injuries**: rare for skaters (you included as a forward), with a minor-league call-up filling
  in. A very rare broken back ends a career for good.
- **20 seasons** (age 20 to 40).
- **Gear shop**: stick curve and length, helmets and skates for forwards; pads, masks, skates
  and gloves for goalies. Every piece costs cash and moves your ratings up and down.
- Saves from the old 24-team version carry over: your player, ratings, cash, age and titles move
  into the new league.

## Ultimate Franchise
A second mode on the main menu with three save files of its own.
- **Start**: name your team. You get the benchwarmer set (the 9 lowest-rated skaters and the 2 lowest-rated
  goalies in the league, all WORN) and 500 coins.
- **Cards**: every player from all 32 teams plus 16 retired legends and 4 legend goalies. Every card has
  the same ratings as the career modes (12 skater ratings or 7 goalie ratings), built from that player's
  own strengths and weaknesses. Rarity shifts every rating a little: WORN -4, COMMON +0, UNCOMMON +1, RARE +2,
  EPIC +4, LEGENDARY +6, full-art SECRET +10 (max 99) - big jumps come from lucky pulls of star players, and higher rarities also stretch the player's
  strengths further. Legends only show up at EPIC and above, or in the Legends pack.
- **Upgrade**: 3 spare copies of the same player at the same rarity raise a card one rarity (WORN to
  COMMON and so on). The card keeps its lineup spot. Pick the card in the roster, then UPGRADE.
- **Examine**: tap and hold any card (roster, hub, a freshly opened pack) to flip it over and see every
  rating. The card menus have EXAMINE too, and TRIANGLE examines the highlighted card on the Vita.
- **Lineup slots**: picking a filled slot on the left opens SWAP PLAYER / EXAMINE / UPGRADE / QUICK SELL.
  SWAP jumps to the cards on the right and keeps the slot highlighted (REPLACING) so you can see who goes
  out; pick the new card and it goes straight in. O (or CANCEL) backs out. Quick-selling a lineup card leaves
  its slot empty; an empty slot goes straight to picking a card.
- **Salary cap**: every card has a salary (higher OVR and rarity cost a lot more) and your 11-man lineup has
  to fit under your cap ($24M to start). Buy more cap space in the SHOP (+$2M each, every raise dearer).
  The payroll shows in the TEAM box on MY ROSTER; salaries show on every card.
- **Shop**: Entry 400 coins / 6 cards (mostly WORN, nothing above RARE), Standard 1,000 / 5, Premium 2,500 / 4
  (one RARE+), Elite 6,000 / 3 (one EPIC+), Legends 14,000 / 1 legend. Higher tiers give fewer cards but better
  odds at rare cards and star players. Bought packs go to your INVENTORY; open them there whenever you like.
- **Roster**: 11 slots, three lines of LW-C-RW plus a starting and backup goalie. You play the center
  of whichever line is on the ice. AUTO BEST fills it, SELL DUPLICATES quick-sells spare copies. Your
  own players' goals and your goalies' save % and record are tracked (Road to the Cup keeps its own numbers per run).
- **Games**: pick an EASY / EVEN / HARD CPU team. EASY is never rated above you, EVEN is within 2 OVR,
  HARD is always above you (by a little or a lot). Teams, names and colours are random. Win the reward
  (140 / 220 / 360), a quarter of it for a loss, plus 10 coins a goal. Quitting pays nothing.
- **Road to the Cup**: a short season from the Ultimate Franchise menu. 16 teams in two divisions of 8,
  20 games (division rivals twice, 6 from the other division), the top 4 of each division play single-game
  quarterfinals, semifinals and a Cup Final. Your lineup locks when the run starts and stays locked until it
  ends (roster edits in the meantime only count for PLAY GAME). Win it and 3 Standard packs go to your INVENTORY, where you
  open them for free.
- **Continue**: the big panel on the main menu loads the save you played last (career or Ultimate Franchise).

## Matchup screen
Every game opens with both teams, their records and the starting lineups: goals for each skater, save % and
record (or games played) for each goalie. Be a Pro uses the real league numbers, Ultimate Franchise tracks your
own players (the CPU side is made up for one-off games and comes from the standings in Road to the Cup).
X or a tap continues to the walk-out. There is a short pause between the transition and the opening faceoff,
and the referee is always set at the dot before the puck drops.

## Goals
In every mode the puck carries into the net, the mesh bulges and the puck slides around in there, the
scoring team celebrates (confetti in their colours), then a short GOAL screen with the new score covers
the reset to the faceoff. A goal up high knocks the water bottle off the top of the net and onto the ice;
the trainer puts it back before the next faceoff.

## Stability
- A frame whose script runs for more than 2 s is stopped by a watchdog: the game carries on, and the spot it was stuck
  in is written to `ux0:data/GoalieSim/log.txt` - send that file if a freeze ever comes back.
- The drawing cache holds up to 3000 blocks and drops ones not drawn lately without sorting (no stall when it trims).
- Player poses are recorded on a time budget (no burst at a faceoff), and the sound mixer can't race the game.

## Sound
Every sound is synthesized by the game itself - no sample files. On the Vita the native layer (vita/src/main.c)
builds them in C on its own audio thread at start-up and mixes up to 24 at once; in a browser they're built in
JavaScript and play through WebAudio after your first tap.
- **Puck**: slap shots crack, wrist shots snap, passes and catches tock, saves thud, posts ring.
- **Skates**: a stride sound for you and the skaters near the camera, a spray of ice on hard stops.
- **Hits**: a body / board thud and a grunt from the player who gets hit (three different voices).
- **Crowd**: a murmur under every game that swells when the home team presses; a cheer when the home team
  scores, boos when it gets scored on.
- SETTINGS > SOUND turns it all off.

## Perks
Every player has two perk slots: slot 1 opens at **78 OVR**, slot 2 at **89 OVR**. Each perk has three tiers -
**BRONZE / SILVER / GOLD** - set by one rating (the numbers below are B / S / G); a higher tier does much more.
- **Not everyone carries one.** CPU players and cards get perks by a fixed roll per player (elite players are
  likelier to fill both slots), then the perks they lean toward among the ones their ratings reach. Cards roll per
  rarity, so two versions of a player can differ. In a fresh league roughly a third of skaters carry a perk.
- **Over the seasons** (Be a Pro) the whole league develops or declines with age and potential, and perks follow the
  ratings: players earn perks, move up a tier, or lose them. The biggest changes make the headlines (your team first).
- **Skater perks have a few uses a game** - 3 at Bronze, 4 at Silver, 5 at Gold (Freight Train: once a game) - and
  only fire when they matter: a long pass or a feed into the slot, a wrister in the zone, a one-timer in range, a
  poke the perk actually won, a hit that would have flattened him. **Goalie perks recharge** on a cooldown (shorter
  at higher tiers). A few perks are always on.
- When a perk fires, the player flashes white and its name pops up over his head, edged in its tier colour. Your
  perks sit beside your stamina bar with their uses left. Cards show a badge per perk (ringed in its tier colour),
  the card back names them with their tier, and the pre-game lineup shows everyone's badges.
- Be a Pro: buy perks with XP (UPGRADES > PERKS) - a new perk is BRONZE. **UPGRADE** it one tier at a time, each
  costing 1.5x the last (SILVER 1.5x the perk's price, GOLD 2.25x), and only once your rating reaches that tier. Your
  tier is the lower of what you've bought and what your rating supports. The ladder shows tiers you own (filled),
  tiers your rating reaches (outlined) and tiers still out of reach (grey).

| Skater perk | Rating (B/S/G) | Uses | Effect by tier |
|---|---|---|---|
| ONE TOUCH WONDER | PASSING 80/88/95 | 3/4/5 | long passes, passes through traffic, feeds to the slot: 60% tighter -> perfect, bent onto the stick |
| ONE TIMER KING | SLAP POWER 80/88/95 | 3/4/5 | one-timer in range +15/25/35% power; 40/70/100% of saves kick to a teammate |
| SPEED DEMON | SPEED 82/89/96 | 3/4/5 | holding sprint with (or chasing) the puck builds to +10/16/22% |
| FLICK OF THE WRIST | WRIST POWER 84/90/96 | 3/4/5 | wristers in the zone +15/25/35% speed and harder to read |
| EYES ON THE PRIZE | STICKHANDLING 80/88/95 | 3/4/5 | poke checks +15/25/35% (a use counts only when it wins the puck) |
| FREIGHT TRAIN | CHECKING 82/89/96 | 1 | 6/10/15% of hits on the carrier knock him out (3 on 2 for 30s) |
| IMMOVABLE | POISE 82/89/96 | 3/4/5 | 50/75/100% chance to stay up on a big hit; holds the puck more |
| IRON LUNGS | STAMINA 82/89/96 | always on | drain -15/23/30%, bench rest +10/20/30% |
| DANGLER | DEKING 82/89/96 | 3/4/5 | 60/80/100% of mid-deke pokes miss; dekes recharge faster |

| Goalie perk | Rating (B/S/G) | Recharge | Effect by tier |
|---|---|---|---|
| FLASH OF LEATHER | GLOVE 84/90/96 | 75/55/40s | glove saves held 60/80/100% (always on); steals a glove-side goal 40/55/70% |
| ROBBERY | REFLEXES 84/90/96 | 90/65/45s | robs a goal with a desperation save 35/50/65% |
| WALL OF ST. PAUL | CHEST 82/89/95 | always on | chest saves +3/5/8%, smothered 70/85/100% |
| QUICK RESET | RECOVERY 82/89/95 | always on | slow-down between saves -40/70/100% |
| IRON MAN | STAMINA 82/89/95 | always on | tires 20/35/50% slower |
| FIVE-HOLE LOCK | LEG PADS 82/89/95 | always on | five-hole shut 50/75/100% more; low shots +2/3.5/5% |
| CROSSHAIR | - | - | yours only: 35% of shots show where they will cross your crease |

## On the ice
- Poke checks and body checks knock the puck loose and send it a good way off. A big hit puts a player
  down on the ice for a second or two before he gets back up. Rammed into the boards, now and then he goes
  right over them (out 9 seconds) or through the glass (out 14 seconds) and his team plays a man down.
- **Shots** are on the right stick only: a quick flick up is a wrist shot, pull back then push up is a slap shot,
  easing back to centre is a fake. The left stick aims; the height comes from the shooter's accuracy.
- **Deke (SQUARE)**: a tap pulls the puck out wide (toward the left stick, or away from the nearest defender) and back.
  Hold it for a toe drag: the puck is drawn back in across your body and stays there while you hold, and for a
  second after you let go so you can get your thumb to the shooting stick. Poke checks mostly miss a deked puck, a
  goalie close by may follow it out wide, and a shot off a toe drag is harder to read. Good CPU stickhandlers deke too.
- **Saucer pass (TRIANGLE)**: lifted over the sticks in the lane and landing about on the tape (a little less
  accurate than a flat pass). CPU passers lift it when a stick is in the lane.
- **Boards and glass**: a puck rimmed in flat keeps its pace around the corner; one that hits square comes back
  out; the boards are a little live. A puck that hits the glass comes off at an odd angle and drops. The glass is
  taller now and sways when a player is hit into it (or a high puck hits it).
- **Rebounds**: a goalie's rating for the part that stopped it is his control. Weak or tired goalies leave it in
  the slot; sharp ones steer it away to the corner.
- **Game feel**: a big hit holds the game for a split second and shakes the screen; posts shake it a little.
  Hard stops throw up a spray of snow (hits don't). The puck always casts a shadow, which drifts and spreads as it
  rises. Goals: the goal light flashes, camera flashes go off in the stands, the home crowd jumps section by
  section, and the scorer bangs the glass.
- **Pressure ring**: a ring under each goalie (your own goalie's ring shows your stamina when you're in the net), green for what's left and black for what's been
  drained. Every shot drains it, it refills while the puck is out of his end. Under a quarter it flashes softly
  red; when it empties the whole ring pulses red and he moves and reacts slower until it refills.
- A poke check on a player winding up a slap shot almost always strips the puck.
- **CPU skaters** read the ice before they shoot or pass: shot quality (distance, angle, bodies in the lane,
  where the goalie is), passing lanes (never through a man, never to a covered man, no soft passes across
  their own slot), and who's in the better spot. They one-time passes in the slot, aim for the bigger gap
  high or low depending on the goalie's weak spot, and only wind up a slap shot with room around them.
- **Ice tilt**: a team that's behind digs in - a step quicker, shooting a bit more, and its goalie a little
  sharper when it's 2-3 down. Blowouts still happen.
- **Pulling the goalie**: late in the 3rd, a team down one (or down two, if the coach likes its chances) pulls
  its goalie for a 4th skater - usually on the fly once it has the puck past centre. Yours too, as a forward.
- **Puck physics**: shots fly a real arc under gravity (low shots skim the ice, high ones lift over the pads),
  saucer passes sail over sticks, and the puck hops off the boards, posts, pads and shin pads, and wobbles on its edge for a
  moment afterwards (it snakes a little and dies faster). A puck in the air can't be picked up until it lands.
- **Scoring**: about 6 goals a game on average; 2-3 against great goalies, 7-9 against weak ones.
- **Poise** (PHYSICAL): how well a skater takes a hit. Hits weigh the checker's CHECKING against the target's
  POISE. Every skater has a height and weight; big men check harder and have more poise.
- **Skate marks**: skaters carve the ice as they go (hard stops spray a wider mark); the ice is fresh again at
  every faceoff.
- **Shot controls**: the shooting stick is the only shot control (no setting). Auto aim (in the attacking zone only) keeps stick shots between
  the posts; outside the zone you can clear it wherever you point. The crosshair shows where it's going (bigger =
  less accurate), green when there's lots of net, red when it's into the goalie. A wild high shot can go over the net.
  No sprinting or spin dekes while a shot is loaded, and loading a slap shot you just glide.
- **Shot fakes**: ease the stick back instead of snapping it - goalies with a low SHOT READ bite and leave the net
  open for a moment. Goalies also need a moment between saves (RECOVERY): low recovery can't chain saves, and a
  diving save costs them more.
- **Goal coins** (Ultimate Franchise): each goal against takes back one goal's coins (never the win / game pay,
  never below zero).
- **Loading screens** between menus and games hold a moment and clear out the section you left.
- **Energy and line changes**: every skater has a ring under him - green is energy left, black is spent, and it
  flashes red when he's done. A shift drains it (sprinting much faster; a higher STAMINA rating drains slower) and it
  does NOT come back on the ice - only on the bench, slowly, after a short wait (a line that stays out gets a small
  breath at the faceoff). Lines change by themselves at stoppages, 1 > 2 > 3, and line 1 only comes back once it is
  fully rested; a small note on the right shows which line came out. Your stamina bar works the same way.
- **Checking**: CIRCLE - tap for a bump, hold and let go for a big hit (the longer the hold, the harder). Bumps cost
  less energy and rarely draw a penalty on a man without the puck; a player who passed or lost the puck in the last
  0.8s can't draw an interference call.
- **Handedness and backhands**: every skater shoots left or right (real stars as they do, everyone else ~60 / 40) and
  is drawn that way. A shot across to your backhand side (more than ~30 degrees off your forehand) is a BACKHAND -
  slower and less accurate, using BACKHAND POWER / BACKHAND ACCURACY (new ratings on every player and card, trained in
  Be a Pro under SHOOTING; not part of overall). Square up to the net and it's a normal shot.
- **Loose pucks**: a bouncing puck (rebounds, off the boards, hops) can jump a player's stick; good hands chop it down
  to the ice (a quick stick slam - no shot or pass until it's down). A hard hop can stand a puck on its edge (it arcs and
  is harder to gather); a pass through someone's feet can kick off his skates.
- **Board battles**: a loose puck on the boards and two players arriving together - they pin each other. Wiggle the
  left stick side to side to push the meter your way (CHECKING and STICKHANDLING help); the winner skates off with it.
  A hidden cooldown keeps them occasional.
- **Energy**: shots cost much less (two shots won't empty you; low STAMINA still pays more), cruising without sprinting
  slowly refills, and the bench refills sooner and faster.
- **Be a Pro - the bench**: skating into the LINE CHANGE circle sits you out a shift: a CPU center from your roster takes
  your place and you watch from the bench in first person (right stick: look left and right) while the clock runs (a
  period can end while you sit). TRIANGLE sims the rest of the shift (the score can change) and you're back out at the
  faceoff with full energy; otherwise you come back at the next whistle.
- **Be a Pro - quitting a game**: the rest of it is simulated (score, time left, rosters, goalies, hot streaks) and you
  get the normal result screen with a line saying what was simmed. What your player does in the sim is worth half XP.
- **Ultimate Franchise - card stats**: every card keeps a line WITH YOUR TEAM (skaters GP / G / A / PTS / +- / P-GP,
  goalies GP / W-L / SV% / GAA / SAVES / SO) - shown when you examine the card, kept through rarity upgrades (it's per
  player), every game counts (cup too), and it's cleared when you sell your last copy of him.
- **Bench changes**: when your energy drops low (any skater mode) a pulsing green LINE CHANGE circle appears on the
  ice by your bench (an arrow at the screen edge points to it when it's out of view). Skate into it and the next line
  comes over the boards on the fly - in Ultimate Franchise you take over the new center; in Be a Pro your wingers change
  and you get a real breather. A teammate carrying the puck hands it to the man replacing him.
- **Faceoffs**: every stoppage has the draw mini game. There's always at least a second of GET READY before the ring
  appears, presses before it shows are ignored (so mashing X through a save or goal can't lose the draw), and if
  you're on the ice you take the draw.
- **Penalty kills**: shorthanded teams clear the puck down the ice and only attack on a clean break.
- **Hot starts**: now and then a CPU goalie is simply on that night and stops more.
- **One-timers**: CPU skaters fire a pass straight away when they catch it in a good spot.
- **Stop on a dime** is a hard slow-down; only elite skaters come to a full stop.
- **Practice**: GOALIE (as before), SKATING (timed gates and cones), SHOOTING (from centre ice at a goalie; rebounds
  count; a goal or a cover resets you), AIM (four corner targets, low and high). Skater drills use a 50, 70 or 99 OVR
  skater; best times / scores are kept while the game is running.
- Goalies reset fully at every faceoff.
- **CPU goalies** get set when the puck is in their end, shuffle side to side, and go for every shot: glove
  or blocker flashes, butterfly (knees together, pads flat out, like yours), kick saves, body saves, a sprawling dive when it's past them, poke checks on
  a man cutting in alone, and covering the puck.
- **Faceoff transition**: after every goal and every whistle (saves, icing, penalties, period breaks) a
  FACEOFF transition covers the reset, then a short beat before the draw. The referee is always set at the dot.
- A referee drops the puck, follows the play along the boards and raises his arm on penalties.
- Soft mirrored reflections under the skaters and the referee, carved skate lines, soft pools of light from the arena lights, sponsor ads along the end and side boards.

## Settings
- **Goalie assist**: your goalie squares up to the puck when the left stick is centred.
- **Auto aim (shots)**: ON keeps stick shots in the attacking zone between the posts. OFF sends them exactly
  where the left stick points.

## Positions
Be a Pro asks for a position after you name your player. Both play the same top-down 3v3 game
(three 2-minute periods, overtime, shootout) with the same league, contracts, Office and upgrades.
- **Forward**: you center every line. Ratings: speed, edge work, shooting, passing, stickhandling,
  deking, faceoffs, checking, stamina.
- **Goalie**: you are in the net for your team (drafted into one of its two goalie spots). When
  the other team crosses centre ice the camera cuts to a goalie cam behind your net and you and the
  net turn see-through so you can read the shot. Ratings: reflexes (how fast pads drop and hands
  get out), strafing (side to side, auto-lock speed), stamina, pressure (less stamina lost per shot),
  recovery (pad to pad, back up), glove, leg pads, chest, blocker (fewer pucks slipping past, better
  rebounds). Every shot that hits you costs stamina and you only get it back once the puck leaves your end. What you see is your hitbox: the glove, blocker, pads and body drawn on
  screen are exactly what stops the puck.

### Forward controls
| | Vita | Phone (touch) |
|---|---|---|
| Skate | left stick | drag left thumb |
| Shots | RIGHT STICK: quick flick up = wrist shot (no wind-up); pull back, then push up = slap shot (ease back to centre = fake). LEFT STICK aims. Height comes from the shooter's ratings | right-thumb drag, same motions |
| Checks | no puck - RIGHT STICK: quick flick up = bump; pull back (you can keep skating), then push up = big hit | right-thumb drag |
| Deke | SQUARE: tap = pull it wide, hold = toe drag (holds 1s after release) | DEKE button |
| Saucer pass | TRIANGLE | SAUCER button |
| Stop on a dime | flick the left stick against the way you're skating | - |
| Block shots (no puck) | L | BLOCK button |
| Spin deke (with the puck) | L | SPIN button |
| Pass (with puck) | X (aims toward your left-stick direction) | tap right side |
| Call for the puck | X while a teammate has it | tap right side |
| Poke check | X next to the puck carrier | tap right side |
| Pause | START | pause button |

### Goalie controls
| | Vita | Phone (touch) |
|---|---|---|
| Slide left / right | left stick | drag left thumb |
| Glove out (top / middle, glove side) | hold L | hold GLOVE button |
| Blocker out (top / middle, blocker side) | hold R | hold BLOCKER button |
| Drop the left / right pad (REFLEXES set how fast) | right stick left / right | drag right thumb left / right |
| Butterfly | right stick down | drag right thumb down |
| Get back up | let go of the right stick (RECOVERY sets the speed) | let go |
| Goalie cam / rink view | D-pad UP (any time) | CAM button |
| Puck in the glove: pass | X (left stick picks the teammate) | PASS button |
| Puck in the glove: cover | O or SQUARE (or wait 3 seconds: faceoff) | COVER button |
| Pause | START | pause button |

GOALIE ASSIST (Settings, on by default) squares you up to the puck when the left stick is centred
on Casual and Standard.

### Menus
- D-pad or left stick moves, X selects, O goes back.
- L / R switch tabs on Upgrades and the Gear Shop.
- SQUARE deletes the highlighted save file (asks first).
- Ultimate Franchise roster: L / R flip pages, SQUARE quick-sells the highlighted card (asks first).

### Other buttons
- **Hold SELECT**: performance readout (FPS and script time per frame).
- **SELECT + START**: quit the app.

Stick dead zone: `STICK_DEAD` at the top of `vita/js/vita_shim.js`.

## Performance
The shim caches layers that don't change from frame to frame (rink, net, skaters waiting for the
puck, glove/blocker shapes, scoreboard, stamina bar) and replays them instead of rebuilding them.
Game code marks those layers with `cached(key, fn)`. On the web it just calls `fn()`.

## Memory
The game runs QuickJS's garbage collector itself at whistles and in menus (`__gc()` in `main.c`), so
collection pauses don't land in the middle of play.

## Saves and logs
Saves live in `ux0:data/GoalieSim/goalie4.json` (careers) and `chl_ut.json` (Ultimate Franchise), the same data
the browser keeps in localStorage.
If the game ever hits a script error it shows the message on screen and writes it to
`ux0:data/GoalieSim/log.txt`. Send that text back and it can be fixed quickly.

## Making changes
- **Gameplay, UI, balance**: edit `web/goalie.html` (or drop in a new version), then rebuild.
- **App name, title ID, version**: top of `vita/CMakeLists.txt`.
- **Icon / LiveArea art**: replace the PNGs in `vita/sce_sys/`. Keep the sizes (128×128,
  840×500, 280×158) and save them as 8-bit indexed PNGs. `tools/make_livearea.py` regenerates the defaults.
- **New characters in text** (accents, symbols): add them to `CHARS` in `tools/make_font.py` and run it.
- **Preview without a Vita**: `node tools/preview_vita.js && python3 tools/render_frames.py`
  runs the Vita JavaScript layer on your computer and saves screenshots to `preview_out/`.

## Notes
- Built for the 960×544 screen. The game lays itself out for that size automatically.
- CPU is set to 444 MHz while running.
- Text uses a bundled DejaVu Sans Bold atlas (license in `tools/DejaVu-LICENSE.txt`). Font
  weights from the web version all render in this one weight.

## Flicker and speed pass
- Board flicker fixed: the yellow kick plate sat exactly on the boards (two surfaces fighting for the same pixels); it now sits slightly off them. The depth range was also tightened (near 4 ft, far 500 ft) so distant surfaces stay stable.
- Faster on the Vita: all 3D maths now in single precision (the Vita's CPU is much slower with doubles), built with -O3, NEON and Cortex-A9 tuning, and the shot-lane check only samples near the goalie.
- Pause screen: SHOW FPS toggle. Shows frames per second plus how long the game logic, the drawing, and the GPU/vsync wait take each frame.
- SELECT still swaps between the 3D and the classic 2D view (intentional).

## 20 FPS cap fix
- The Vita build was locked to 20 FPS no matter how fast a frame was: the game waited two screen refreshes and then the buffer swap waited for a third. Pacing now waits one refresh before the vsynced swap, so frames that finish in time run at 30 (or better).
- Goalies at the opening faceoff: their bodies now follow them to the crease (the body was cached on the game clock, which stands still before the puck drops, so only the shadow moved).

## Skating stride and Type B sprint
- New skating stride, matched to broadcast skating: chest well over the knees (more lean the faster he goes), hips low and back, head up. Each leg pushes out to the side and back until it's nearly straight, the toe turns out, then the foot comes back in under him. Knees are placed by two-bone IK. The stride is slower and longer (about two strides a second at full speed) instead of a fast forward kick.
- Shot type B: hold X to sprint at all times (with or without the puck). Tap X = pass / call for it / poke. R is only the shot. Hold time is measured in real time, so it feels the same at any frame rate.

## Model pass (PS2-era players)
- Skaters and goalies rebuilt from smooth lofted surfaces instead of boxes and balls. Skaters: hockey pants, socks with stripe bands over shin pads, skates with holder and steel, jersey with hem band, sleeve bands, collar, chest crest, the player's number on the back, cuffed gloves, helmet with ear pieces, brow and a clear visor. Goalies: flat-faced leg pads with knee rolls, boot break, outer roll and thigh rise, wide chest-protector jersey with crest, open trapper with binding and pocket, blocker with border and stripes, painted mask with cage and throat guard, taped stick.
- Goalie ready stance matched to the reference: feet wide, knees in (pads in a V), glove out and open, blocker out with the stick across the five-hole. Same body is used for saves, so what you see still stops the puck. Scoring re-checked over 80 simulated games (about 4.8 goals per game, same as the old stance in the same test).
- Lighting: key light, camera fill, bounce light off the ice, rim light on silhouettes, gloss per material (helmets and masks shine, cloth does not), darkened creases and hems. All in vertex colours: no textures.
- Soft shadows under players (fade out at the edge).
- Goal camera: on a goal the camera comes down and in on the scorer, then eases back for the faceoff.
- Speed: every vertex is lit once instead of once per triangle corner, players outside the picture are skipped, and limbs no longer allocate memory each frame. In the PC test build the players and goalies together cost about 20% less time than before, with more detail.

## Texture pass (toward a broadcast look)
- The 3D view is now textured. Two 1024x1024 texture sheets are drawn by code (`tools/make_textures.py`, no outside images or real brands) and built into the app: one for people, one for the arena. Every vertex carries a texture coordinate; plain shapes point at a white patch, so everything still draws in a few batches.
- Players: realistic (slimmer) proportions, cloth folds and weave on jerseys, pants and socks, real digits for the number, the player's last name across the shoulders, a team crest, a face, helmet vents. Goalies: stitched pads with straps, a trapper and blocker with their own art, a cage, name and number on the back. The referee wears stripes.
- Arena: a packed crowd in a lower and an upper bowl that run unbroken round the corners and right up to the benches, a lit ribbon board, sponsor boards (invented names), ice scratches, on-ice logos and a centre-ice logo.
- The people's sheet is kept at three sizes and the one that suits the camera is used (stops distant players shimmering).
- Pause screen: TEXTURES ON/OFF. OFF gives the plain shaded look, as a fallback if a Vita shows textures wrongly.
- Cost in the PC test build: the textured arena draws about 3,500 fewer triangles per frame than the old crowd of individual fans, and total draw time went down.

## Heads, helmets and cast shadows
- One human head for every skater, goalie and official: a sculpted head (jaw, cheeks, brow, cranium, nose, ears) with a single face texture wrapped right round it (eyes, brows, nose, mouth, stubble, ears, short hair), on a human-sized neck. Same head size for everyone. Darker skin tones tint the same texture.
- Skater helmet: sits on the skull down to the brows, ear guards with ear openings, brim, vents, chin strap and cup, clear visor from the brim to the nose. Officials wear it without the visor.
- Goalie mask: one shell from over the crown to below the chin, open at the face behind a bowed wire cage, team colour over the top and on the chin, painted stripes and vent holes.
- Cast shadows: every body part throws a soft-edged shadow on the ice. They are drawn with a "keep the darker pixel" blend (plat_draw3d mode 3, glBlendEquation(GL_MIN) on the Vita) so overlapping shadows never add up; if a machine lacks that blend they fall back to ordinary see-through shadows.
- The goalie's head hit area is unchanged for now (still the old, larger head), so scoring is unchanged: 4.83 goals per game over 80 simulated games. It will be matched to the new head when the bodies are redone.

## Goalie body: real proportions
- The goalie's body is now sized to the human head (it was about a third larger than life): overall scale 1.75 -> 1.3, shoulders about two and a half mask-widths across, a chest that tapers to the waist, slimmer arms, eleven-inch pads, glove and blocker at real size. Crest, number and name re-seated on the new chest and back.
- What stops the puck follows the new shapes (body, arms, pads and the mask-sized head).
- A real-sized goalie covers a real goalie's share of the net, so two things changed to keep the game balanced: on a shot going wider than he can reach he now pushes across toward it (a butterfly slide when it is quick), and he misreads shots half as often (ratings, perks and hot/cold form still scale his misses the same way). Scoring: 4.85 goals per game over 160 simulated games.
- Note: the game stretches heights by 1.7 (puck flight and the net), so the net is taller than life next to a real-sized goalie.

## Goalie size: larger, same proportions
- The goalie (head included) is scaled up about a third from the previous build (scale 1.3 -> 1.72), keeping the human proportions: in his stance his mask is at the crossbar and he fills the net like a real goalie does.
- Bigger leg pads: wider, with a taller thigh rise and a longer boot. What stops the puck matches.
- Balance: the misread halving and the hard lateral push added for the small goalie are gone; agile goalies keep a slight push toward wide shots. Scoring: 4.86 goals per game over 200 simulated games.

## Goalie head and shoulders
- Head and mask about 18% larger, with a fuller mask shell; shoulders narrower and sloping, slimmer upper arms. The mask is now about a third of the shoulder width, as on a real goalie, and sits down on the collar. What stops the puck matches. Scoring: 5.03 goals per game over 160 simulated games.
- Shoulders and torso widened slightly again (about 6%): a goalie's chest protector is bulkier than a skater's pads. What stops the puck matches. Scoring: 4.91 goals per game over 160 simulated games.

## Smaller net and goalie-rating balance
- The net is 12% smaller (width, height and depth, in both the 3D and 2D views): next to the goalie the crossbar now meets his chest with his whole mask above it, as in real photos.
- Save tuning by goalie rating (both goalies at that rating, simulated games): a 90 goalie 2.35 goals per game total, a 78 goalie 3.04, a 60 goalie 6.79; quick-play's mixed goalies 4.28. Below 72 a goalie's misses climb quickly.
- Nothing is guaranteed: a team is shut out in 15-35% of games depending on the goalie (8% even against a 60 goalie), and a 60 goalie gives up 6+ to one team about 17% of the time.
- A goal rattles a goalie more than before (confidence drops further and can sink lower), so a team that keeps coming can chase even a good goalie; a cold night hurts a little more too.
- Test build: CHL_GOVR=N puts every goalie at rating N; `games` now prints the spread of game totals and how often a team is shut out or scores 6+.

## Crease and the goalie's depth
- The goal crease now ends at the posts: straight out from each post for 4.5 ft, then a flat arc 6 ft out (the NHL shape, net-wide). Same in the 3D and 2D views.
- The goalie's depth by puck distance: in the middle of his crease (3 ft out) with the play up the ice; moving up as the play comes over the blue line; holding the top of his crease (5.7 ft) from the blue line to the slot; then skating backward with a shooter inside 28 ft, to about 1.5 ft out at the doorstep; deeper still from sharp angles, then sealing the post from the goal line. Measured in simulated games: about 5 ft out with the puck 30-60 ft away, 2.5 ft at 10-20 ft, under 2 ft in tight.
- Scoring with the new depth (160 games each): 90 goalie 2.16, 78 goalie 3.05, 60 goalie 6.87, quick-play mix 4.42.
- Test build: CHL_DEPTHLOG prints puck distance, target depth and actual depth; script tokens `waitdistN` and `waitgtop`, and CHL_CAMG aims a camera at a goalie.

## Goalie, net and crease sized to the skaters
- The goalie is now just a little bigger than a skater (a 6'2"+ player in his gear): body scale 1.72 -> 1.38, head and mask with him. He was about a third bigger than the skaters.
- The net and crease are sized with him, so the goalie still fills the net the way he does in real photos: the net is 8.2 ft wide and 5.3 tall on screen (was 10.2 x 6.6), 2.6 deep; the crease ends at the posts, 3.6 ft straight then a flat arc 4.8 ft out. The 2D view matches.
- His top-of-crease depth follows the crease (about 4.7 ft out), backing in to about a foot out at the doorstep.
- Scoring (200 simulated games each): 90 goalie 2.00 goals per game, 78 goalie 2.81, 60 goalie 5.89, quick-play mix 4.01.

## Goalie squares up to the shooter
- The goalie turns square to the puck (up to 60 degrees off straight out; back along the goal line when sealing a post) and sets up on the shooter's side of the crease, out to just inside the post. His whole body turns, so what stops the puck turns with him, and which side a shot is on (glove or blocker, and where his glove reaches) is measured across his turned body.
- He follows the puck a beat behind it: about .05 s for a quick goalie (high Shot Read and agility) up to about .19 s for a slow one, and he turns at a pace set by his agility. So a quick pass across the crease leaves a slow goalie turning and pushing late. In simulated games, goals off a pass in the last second rose about 50% against a 60-rated goalie.
- Rebalanced: the weak-goalie misread penalty is gone (a weak goalie now pays through his slow eyes and feet). Scoring (200 games each): 90 goalie 2.42 goals per game, 78 goalie 3.53, 60 goalie 6.63, quick-play mix 4.67.
- Test build: script tokens `waitsideL` / `waitsideR` (puck carried on one side of the away net); GOAL debug lines now show how long since the last pass.

## Be a Pro (skater careers) and Practice
- BE A PRO is back for forwards, with the legacy career rules ported to native code (new files: src/pro.h, pro.cpp, pro_draw.cpp, prac.cpp). Goalie careers are marked COMING SOON on the new-career screen.
- New career: name, jersey number, position, difficulty (Casual / Standard / Hardcore set the game difficulty). Then draft night: the 32 picks come in until your team takes you.
- The league: the 32 real teams and rosters, with random contracts on every save, a $70M cap (rises 2.5% a year), 9 skaters + 2 goalies per team.
- The season: 80 games on a calendar (October to April) with off days. On off days you can rest or train ($ for points toward 2-4 ratings). There are three weekly goals a week (XP + cash), and the hub shows headlines, the matchup, your last results and the next five games.
- Games: PLAY puts you on the ice with your real teammates against the opponent's real roster and goalies. CPU skaters are scaled to the league level. XP comes from goals (+30), assists (+10), shots on goal, hits, blocks, passes, faceoffs, pokes and wins.
- Your ratings also grow as you play: shooting builds shot power and accuracy, skating builds speed and edges, hitting builds checking, getting hit builds poise. Quitting a game simulates the rest of it (your part counts at half XP).
- SIM GAME / SIM 10 / SIM SERIES use the legacy sim formulas, including your scoring share and rating growth.
- Upgrades: buy rating points with XP (+1 / +5) and buy, upgrade (bronze / silver / gold) and equip the 9 skater perks. Perk slots open at 78 and 89 OVR, and equipped perks work in games.
- Gear shop: stick curve, stick length, helmet (injury risk) and skates. Each piece has rating trade-offs that apply in Be a Pro games.
- Injuries for everyone: call-ups fill in, a rare career-ending injury happens, and your own injuries cost games and a point in two ratings (SIM UNTIL HEALTHY).
- League activity: AI trades that have to fit under the cap, stars rising and falling, and perks earned or lost over the summer.
- Office: contract card, performance and loyalty, contract negotiation (term, ask for more, the no-trade clause, walk away to free agency), extensions in your final year, requesting a no-trade clause (one ask a season), trade requests (pick up to 10 teams), and trade offers (with a no-trade clause you decide). The trade deadline is game 60, and the trade alert screen shows when you move.
- Playoffs: top 3 per division + 2 wild cards per conference, best-of-3 every round, with a full bracket screen.
- League screen: four divisions (with x / w playoff spots), top scorers, goalies (SV%), news, your team (roster, injuries, call-ups, payroll) and the playoffs.
- Off-season: aging and development, retirements, contracts expiring (raises, sign-and-trades, free agents), the draft (top picks develop fast), free agency, and trades. Your contract can expire (sign before your next game, or walk away) or you can be moved.
- Retirement at 40 (or a broken back): the career summary (seasons, games, goals, assists, titles) and a Hall of Fame count.
- Saves start fresh: chl_pro.json (index + Hall of Fame) and chl_pro1-3.json (one per career). The legacy goalie4.json careers are left untouched. CONTINUE on the main menu picks up your last Be a Pro career.
- PRACTICE (skaters): skating gates (best time), shooting on a goalie (goals / shots) and aim training (all four corners in the fewest shots), each with a 50, 70 or 99 OVR skater. Best scores are saved in chl_prac.json.
- Speed: a sim day takes about 3 ms on a PC (roughly 30-50 ms on the Vita), and the off-season about 45 ms (well under a second on the Vita).
- Live CPU-played career games averaged 4.1-4.9 total goals per game.
- Test build: `chl_host pro SEASONS [LIVE_EVERY] [SEED]` simulates a career. It checks every roster (9 + 2), does a save/load round trip each season and times the off-season. `chl_host proshots DIR` renders every career and practice screen, and `chl_host proflow` walks the menus by button. A 20-season career ran to retirement, and the memory-error and 32-bit checks are clean.

## NHL-like career scoring, the career bench, line changes, in-game settings, faceoff ring, performance
- Simulated scoring follows your overall, like an NHL career. A season on an average team works out to about:

  | Overall | Goals per season |
  |---|---|
  | 70 | 18 |
  | 80 | 30 |
  | 90 | 46 |
  | 99 | 60 |

  Assists run about 1.25 per goal. Each season has its own form, so a hot year runs about 25% over (an elite 99 can approach 90 in a career year), and a better team helps a little. Quitting a game uses the same rates. Across the league, every goal now gets a primary and usually a secondary assist.
- Be a Pro lines: you center the top line with your two best wingers, and lines 2 and 3 take their shifts while you're on the bench. The bench view shows the line on the ice and your stamina refilling, and TRIANGLE sims to your next shift. That stretch of time is played out by the numbers (lines, goalies), you return fresh, and play restarts with a faceoff.
- Shift lengths (game time): the top line about 38 s, the second 28 s, the third 20 s. The other team now changes on the fly when a shift runs long (not with the puck deep in their own end). At a whistle you come off if you're spent.
- D-PAD RIGHT when you're tired: a flashing reminder sits above the stamina bar, and the CPU skates you to the bench circle (passing the puck off first if you have it). The fresh line steps on and you get control back: in quick play you take the breather, in Ultimate Franchise you take over the new center, and in Be a Pro you go to the bench. Press RIGHT again to stay on. While you head to the bench (or skate there tired) the camera eases toward the bench and lifts a little, then eases back.
- Pause menu SETTINGS tab: frame rate (30 FPS cap or unlocked up to 60), show FPS, 3D / classic 2D view, camera low / high, textures, shot assist (auto aim) and shot controls (type A / B), all saved. SELECT no longer switches the view in a game.
- Faceoff: the timing rings lie on the ice at the size of the centre-ice logo (round in perspective, like the logo) at whichever dot the draw is on, painted under the players. They show a red face, a blue ring to hit and a green ring closing in from the edge.
- Performance (frame CPU work down about 45% in the 3D view):
  - The rink, crowd, nets, boards, ads and glass are built once and sent to the GPU from their caches. There is no per-frame copy or CPU clipping, and on the Vita their GPU arrays are converted once.
  - Players away from the play are rebuilt every third frame and re-sent moved to their new spot in between. You, the puck carrier, players near the puck or the camera, and anyone deking, spinning or stunned are rebuilt every frame.
  - Goalies are rebuilt every other frame except during saves. The bench crowd is rebuilt 12 times a second.
  - Heads use fewer segments at broadcast distance, and reflections are colored with integer math.
- Render caches are tied to a per-game serial number, so a new game never reuses the last game's meshes.
- Test build: `chl_host benchrun` (D-pad RIGHT in quick play and Be a Pro), `probench` (line rotation, bench time and the shift sim; SIMSHIFT=1) and `gshots DIR` (faceoff, tired, run to the bench, settings tab, career bench).

## Build fix: "segment 1 overlaps"
- vita-elf-create appends its module tables (a few KB) right after the code segment, and VitaSDK starts the data segment at the next 64 KB boundary. When the code ends just short of a boundary the conversion fails ("Cannot allocate N bytes for SCE data at end of segment 0; segment 1 overlaps"). It comes and goes as the code grows.
- The Vita build now compiles the game once (an object library) and links it twice:
  - The probe link measures the room after the code with arm-vita-eabi-readelf (tools/sce_pad.cmake).
  - If there is less than 12 KB, the real link adds a read-only pad (src/sce_pad.cpp) that pushes the end of the code just past the boundary, which leaves about 60 KB of room.
- With enough room, the pad is 4 bytes. The build log shows the measurement ("SCE room after the code: ...").

## Freeze fix (after ~18 minutes)
- Frame pacing waited until the vblank counter was n past the last swap. If the counter wraps (at 16 bits that is 65,536 vblanks, about 18 minutes at 60 Hz), the difference went hugely negative and the wait would never end: a hard freeze about two matches in, in a game or in the menus. The difference is now taken mod 65,536, and the wait is bounded (never more than n vblanks; a long frame or a reset means no wait).
- Hardening:
  - The GPU copies of the static geometry are keyed on their cache (not the data address), and any not drawn for ~10 s are freed.
  - Replayed player meshes for skaters who left the ice are freed every second.

## Be a Pro: AHL career (Nov 2026)

- **Real rosters, 2026-27.** All 32 NHL rosters are updated to the 2026-27 season. Gavin McKenna is on Toronto and Ivar Stenberg is on San Jose. Offseason moves are in too, for example Hellebuyck to New Jersey, Quinn Hughes to Minnesota, Marner to Vegas and Marchenko to Toronto.
- **The AHL.** Every club has its real AHL affiliate (Providence, Rochester, Grand Rapids and so on, 32 teams) with real players from the 2026-27 rosters. Ages and overall ratings are estimates; AHL overalls run about 60-71. The AHL uses its own divisions: Atlantic, North, Central and Pacific.
- **Your career starts at 18.** The NHL club that drafts you sends you to its farm team. You still retire at 40.
- **Proving yourself.** The front office compares you with the weakest regular on the NHL club. It weighs three things: your overall, your production against what that overall should give, and your age. Young kids get a look, and long-time pros get a chance in their late 20s.
  - The hub shows CALL-UP (your rating / the bar) and a front-office note.
  - Good play gets you called up at 19-20. Average play takes until about 23-25. Poor play can keep you down for close to a decade.
- **Moves.**
  - Weekly reviews in the season can call you up. At training camp you either make the team or start in the AHL.
  - Young players (25 and under) can be sent down when someone on the farm is clearly better.
  - If the club gives up on you (age 21+, far below the bar), it can trade your rights to another AHL club. That club's NHL team becomes your organization.
  - Trade requests made from the AHL send you to the chosen club's farm team.
  - In free agency, if you are below a club's bar you sign with its farm team.
- **Injuries.**
  - An NHL injury calls up the farm team's best healthy player. That can be you, if you are close to the bar. Play well and you stay when the regular returns; otherwise you go back down.
  - An AHL injury brings up a randomly generated ECHL call-up.
- **A full AHL season.** Both leagues play every game day over 80 games, with separate standings, scoring and goalie leaders, and news.
  - The Calder Cup playoffs run alongside the Stanley Cup playoffs. Whichever league you are not in is simulated when your playoffs start.
  - The LEAGUE screen has NHL / AHL buttons for standings, leaders and both brackets.
- **Organizations.** Draft picks start on the farm, and young NHL cuts go down instead of to free agency. Teams promote AHL players who pass an NHL regular.
- **Stats.** Career NHL and AHL totals are kept separately. The retired screen shows Calder Cups and your NHL debut age. AHL games pay half (two-way deal).
- **Old saves** load fine: the AHL is added around your career and you stay with your NHL club.
- Tests: `chl_host pro N [LIVE_EVERY] [SEED]` prints league, readiness, bar and every call-up or send-down. `chl_host proload SLOT N` loads a save and sims on.

## Ultimate Franchise: AHL cards and Training Camp (Nov 2026)

- **AHL cards.** All 32 AHL rosters (2026-27) are in the card pool. They have the same 7 rarity tiers, upgrades and perks as NHL cards. Cards show the club abbreviation with an AHL tag.
- **New files** start with 11 random AHL depth players, all WORN, about 56-60 OVR (team OVR ~59).
- **Pack odds.** The percentages below are the chance that a card is an NHL player. The rest are AHL players, and AHL stars (67+) show up in about 8-9% of cards in the cheap packs.

  | Pack | NHL players | NHL stars (85+) |
  |------|-------------|-----------------|
  | Entry | ~1% | Almost never |
  | Standard | ~5% | At most one per pack, about 1 pack in 200 |
  | Premium | ~30% | |
  | Elite | ~65% | |

  The shop shows the NHL odds under each pack.
- **CUP pack.** Winning Road to the Cup now pays 3 CUP packs. Each has 4 cards (UNCOMMON+ guaranteed), one NHL player guaranteed, and about 65% NHL overall. CUP packs are never sold in the shop.
- **Training Camp** (hub menu, or a card's menu > TRAINING CAMP):
  - Send one card at a time for 3 games. It can't dress while it's there; the lineup refills itself.
  - Pick a stat group. Skaters: Skating, Shooting, Playmaking, Two-Way. Goalies: Reflexes, Positioning, Endurance.
  - When camp ends, every stat in the group gains +4 (WORN) up to +16 (SECRET), depending on the card's rarity.
  - Each player can train once per rarity. Gains belong to the player, so they carry through upgrades.
  - You need a spare player at the same position to send someone to camp.
- **Old saves** keep working. Cards of players who changed teams are moved to their new club.
- Test: `chl_host utsim [DIR]` prints a new file's OVR, pack odds over thousands of packs, a full camp run, and optional screenshots.

## Pack opening and foil packs (Nov 2026)

- **Opening animation**, in order:
  1. The pack shakes, glowing in the colour of the best card inside.
  2. The top strip tears off along a jagged line and spins away.
  3. Light pours out of the opening. The beams are coloured and sized by the best rarity in the pack: a few dim rays for WORN, up to a wide fan with sparkles for LEGENDARY. SECRET beams cycle rainbow.
  4. The cards peek out, a flash goes off (tinted for EPIC and up), and the cards burst out spinning along arcs into their slots.
  5. The cards flip one by one, as before.
  - X / tap still reveals everything at once.
- **Foil packs.** Each tier gets fancier:

  | Pack | Foil |
  |------|------|
  | Entry | Brushed metal |
  | Standard | Plus silver diagonal foil |
  | Premium | Plus a diamond lattice |
  | Elite and Cup | Plus prismatic rainbow bands and sparkles |
  | Legends | Plus a gold sunburst, extra sparkles and gold edges |

  Every pack except Entry gets a moving shine; on Elite and up it is rainbow.
- The pack art is drawn in two parts (body and tear-off strip) so the rip lines up. The art is cached; only the shine and the light beams are drawn each frame.
- Test: `chl_host utopen DIR` renders frames of the animation for several packs and rarities, plus the shop and inventory.

## 3D card viewer (Nov 2026)

- **Opening it:**
  - X (or a tap) on a card in MY ROSTER opens it big in the 3D viewer.
  - After a pack opening, select a revealed card and press X, or tap it.
  - TRIANGLE in the viewer (or the OPTIONS button) opens the old card menu: add to lineup, upgrade, training camp, sell.
- **Controls:**
  - Right stick: tilt the card in 3D (perspective, with a visible card edge).
  - Hold the right stick hard left or right: flip to the stats on the back, and back again.
  - L / R: flip.
  - O, or a tap off the card: close.
  - Touch: drag on the card to tilt it; tap or swipe to flip.
- **Foil effects** react to the tilt and get more elaborate by rarity:

  | Rarity | Foil |
  |--------|------|
  | All | Moving glare |
  | Rare | Holographic rainbow bands |
  | Epic | Plus sparkles that glint as the angle changes |
  | Legendary | Plus gold light rays |
  | Secret | Full prism: more bands, rainbow rays, lots of sparkles |

  The back has a subtle sheen.
- **How it works:** the canvas has a projective warp mode (`ctx.setWarp`). Triangles map through it exactly, and cached blocks (the card faces) replay through it, so the card art isn't redrawn. Text becomes warped textured quads (`plat_glyph_quads`, on all three platforms).
- Test: `chl_host utview DIR` renders the viewer at several tilts, rarities and both sides.

## Be a Pro: the apartment hub
- **The place:** Be a Pro's hub is now a first-person apartment (`apt.cpp`), about 34 x 26 ft with 9 ft ceilings.
  - Living room with an open kitchen, a hall, a bedroom and an office.
  - It starts rundown: worn carpet, holes in the drywall, water-stained ceiling, bare bulbs, pizza boxes, trash bags, a mattress on the floor.
  - Lighting is baked into the vertex colours. The whole place (~5,000 triangles) is one static GPU batch, rebuilt only when something changes.
- **Controls:**
  - Left stick walks, right stick looks. D-pad up/down walk, and D-pad right strafes.
  - Touch: left half of the screen is a stick, drag the right half to look, tap the phone in the corner to open it.
  - X uses what the crosshair is on. SELECT opens and closes the phone.
- **Build mode:** D-pad LEFT turns it on and off. Upgrade prompts only show in build mode.
  - Look at the couch, the TV, the TV stand or the floor and press X. The phone opens the home store for that item.
  - Each item has its original junk plus 3 to buy:

    | Item | Options |
    |---|---|
    | Flooring | vinyl $600, oak $2,000, marble $6,000 |
    | Couch | thrift sofa $250, leather sectional $1,400, designer modular $5,000 |
    | TV | 40" $300, 65" $1,100, 85" OLED $4,000 |
    | Entertainment center | particle board $150, oak console $800, floating walnut $3,000 |

  - Owned items can be swapped back in for free.
- **One apartment per save file:** what's in it is saved inside that career's save, so file 1 and file 2 have their own places. A new career starts in the junk apartment.
  - The trophy shelf shows that career's titles: a miniature Stanley Cup or Calder Cup for each one.
- **Loading:** the apartment is only in memory while you're home.
  - Coming home (continuing a file, after draft night, after a game) shows a short "HEADING HOME" loading screen while it's built.
  - Starting a game or leaving Be a Pro frees all of it, including the GPU copy (`aptUnload`, `plat_draw3d_free`), so it costs nothing in game.
  - Buying furniture rebuilds it in place, with no loading screen.
- **Hallway doors:** the bedroom and office doors are solid. Look at one (within about 6 ft) and press X to open it.
  - The door swings into the room, then closes on its own after about 4.5 seconds, but only once you're out of its way. X also closes it early.
  - A shut door blocks you, and blocks the crosshair from things on the other side.
- **Junk:** the moving boxes in the living room, the trash bags by the kitchen and the boxes in the office can be thrown out. Look at one, press X and confirm. You don't need build mode, it's free, and it's saved with the career.
- **Interaction range:** the front door prompt only shows within about 4.5 ft. Prompts never show through walls.
- **The front door:** this is where games start. O backs out of the door panel to the apartment. Play, sim, sim 10 or series, rest or train on off days, sign an expired contract, next season, main menu.
- **The phone (SELECT):** it slides up bottom right. Move between apps with the left stick or D-pad, or tap them. Apps open sideways on a big phone screen. BACK or O returns to the phone's home screen, and SELECT puts the phone away.
  - **Schedule:** the season schedule.
  - **My Health:** injury status, risk per game and per season, and the breakdown by age, contact (hits a game over your last 10 games) and gear. The game now uses this for your injury rolls.
  - **Upgrades:** ratings and perks.
  - **Training:** has an iOS-style update ring that's only full and lit on off days.
  - **GM Connect:** the office, with contract talks, no-trade clause, trade requests, offers and trade alerts.
  - **Gear Shop.**
  - **Performance:** the league screens, opening on My Team.
  - **Messages:** a placeholder for now.
- **Test file:** the first time Be a Pro opens, file 3 is created as "TEST" with $100,000 (only if file 3 is empty). A flag in `chl_home.json` records that it was made, so deleting it leaves an ordinary empty slot. Its apartment goes with it.
- Test: `chl_host apt DIR` (with `CHL_GPU3D=1` for the GPU path).

## Music and sound effect folders
- `assets/music/` and `assets/sfx/` sit at the top of the project. Each folder's README says which formats and names to use.
- Every file in them, including files in subfolders, is packed into the native VPK as `music/...` and `sfx/...` (read in the game as `app0:music/...`). The READMEs themselves are not packed.
- The build picks up new files automatically, so no list needs editing.
- **Soundtrack:** 10 songs in `assets/music/soundtrack/`, listed in `tracks.txt` (see `assets/music/README.md`).
  - The songs play shuffled through every menu and the apartment, fading out when a game starts and back in afterwards.
  - Each new song brings up a now-playing card in the bottom left: an animated equaliser, the title and artist, and the time. It shows for about 5 seconds, then lowers out of the screen.
  - Settings > SOUND & MUSIC has separate SFX and MUSIC switches.
- **How playback works:**
  - On the Vita, the songs are decoded by the system's own MP3 decoder (SceAudiodec, in `mus_vita.cpp`) on a separate decoder thread, through a 1.5-second ring buffer.
  - The mixer now outputs stereo at 48 kHz.
  - If the decoder can't start, the card shows the error code instead of the song.
  - Test on PC with `CHL_ASSETS=../assets chl_host music out.wav [shots dir]`, which uses ffmpeg in place of the Vita decoder.

## Be a Pro: the apartment, round 3
- **The phone (START):** 13 apps.
  - **Schedule** and **My Health**.
  - **Upgrades:** ratings and perks.
  - **Training:** the update ring is only full on off days.
  - **GM Connect.**
  - **Gear Shop.**
  - **Performance:** shots taken, goals, assists, completed passes, checks, PIM, average TOI, shots blocked and shot accuracy for the season.
  - **League:** standings, scorers, goalies, my team and playoffs.
  - **News:** shows a "!" badge when there's news you haven't read; new items are marked.
  - **Goals:** this week's goals pay XP and cash. The season's goals pay a contract-style bonus (about 55-70 games of pay each, +50% with performance bonuses in your deal).
  - **Messages.**
  - **Settings:** the normal settings screen, inside the phone.
  - **Exit Be a Pro.**
  - O in any app returns to the phone's home screen; START closes the phone.
- **Incoming calls:** trades, call-ups and send-downs, an expired contract, and offers from other teams make the phone ring.
  - ANSWER opens GM Connect on that screen.
  - DECLINE leaves it waiting in GM Connect.
- **Rooms:** floor, drywall and paint are bought per room (living room with the hall, kitchen, bedroom, office).
  - Walls show holes and cracks until the room's drywall is fixed; then the wall prompt becomes PAINT.
  - Build mode: look down to see the floor prompt, look at a wall to see the drywall/paint prompt.
- **The counter (build mode):** 8 small appliances; up to 4 sit on the counter at once.
  - Owned items can be put out and put away for free.
- **The office computer:** the Apartment Finder.
  - THE CORNER UNIT ($15,000) is 40 x 30 ft with a deeper living room (a recliner slot beside the couch) and a bigger kitchen (an island slot).
  - You can move back and forth between places you own.
- **Rating nudges:** everything in use adds a small amount to one or two ratings (more for the expensive tiers, capped at +3 per rating).
  - The bonuses show in green in each store.
  - They're added the same way gear bonuses are (`homePts` in `gearPts`).
- **Front door:** your team's jersey hangs on it, in your team's colours with a crest and the team's letters. It changes when you're traded.
- **Hallway doors:** the bedroom and office doors open and close as before.
- **Fixes:**
  - **Door flicker:** the casings no longer share faces with the walls.
  - **Odd blocks on the floor:** the rectangular stains and laundry are now irregular stains and soft clothes piles. The laundry, pizza boxes and dirty dishes can be thrown out.
  - **Kitchen chairs:** they have legs.
- **After a game:**
  - Final score, goals and shots by period, and your line.
  - Then your skill bars fill up with what the game earned.
  - Then you're home, sitting on the couch facing the TV. X stands you up.
- **Contracts:**
  - The office shows ENTRY-LEVEL until your first real deal.
  - **Contract talks:** salary, term, a no-trade clause, a signing bonus (cash up front for less salary) and performance bonuses (season goals pay 50% more for less salary).
  - A no-trade clause now only comes with a new contract; it can't be requested mid-deal.
- **Pre-game lineup:** shows real records, real season goals and the real goalie SV% / games played from the career (it was showing made-up numbers).

## Gameplay changes
- **The rebound sprawl:** when a blocker or pad save leaves a rebound in the slot with a shooter right there and no defender closer, the goalie throws himself flat toward it, hands out front.
  - He first takes a beat to see it; a slower reader takes longer.
  - If he lands on the puck, it's covered and goes to a faceoff.
  - If he misses, he lies out of position, net open, until he gets up (about 0.6-1 s, faster with good recovery).
- **Passes at the net:** a pass or loose puck sliding at the goal mouth is played like a shot (he drops and seals the ice).
  - Fixed: a puck that had just touched the goalie could pass through him for a fraction of a second on its way into the net.
  - Pass goals are down by more than half.
- **Hits:** a hard hit knocks the player over the way he was hit, with a twist, flat on the ice, then he gets back up.
  - The puck is only knocked a few feet that way, not fired across the ice.
- **Goals per game (1,000 CPU-played games):** 4.70 at 50 OVR and 5.01 at 70 OVR (before: 4.79 and 5.15).

## Cards, positions, the coach and the rules (round 4)

**Ultimate Franchise cards.** Every card shows the real 3D player model, textured, with different poses and backdrops: arena lights, boards and spray, team stripes, spotlights, crowd and burst. The foil now sits over card-stock grain. Worn cards are yellowed and stained, with creases, scratches, chipped corners, and scuffed lettering.

**Card viewer.**
- A solid strip across the top hides the screen behind, so no line runs through OPTIONS.
- The prompt reads "PRESS TRIANGLE OR TAP THE CARD TO OPEN OPTIONS". A tap on the card opens the options and a swipe flips it.
- The card's perks are listed next to it: name, tier, what the perk does and what it does at that tier.

**Positions (C / LW / RW).**
- Every forward has his real NHL / AHL position, listed in `POS_TBL` in `data.cpp`. Defensemen who play forward here go on their shooting side's wing; I picked those, along with the 2026 draft class and the legends.
- Cards show C / LW / RW next to the overall. Any card can play any slot.
- Natural centers get a better faceoff rating, so they win more draws. CPU lines put their centers in the middle and their wingers on their own wing.

**Be a Pro creation.**
- First and last name in two boxes.
- The keyboard is lowercase. SHIFT gives one capital and a double tap turns on CAPS LOCK.
- New position pick (center / left wing / right wing) and a LEFT / RIGHT shot pick.

**The coach.**
- His view of you runs from 0 to 100 and starts at 55. Goals, assists, hits, poke checks, time in the attacking zone, plus/minus and blocked shots raise it. Penalties, offsides, a minus and quiet nights lower it.
- His view, together with your overall, sets your line (1st, 2nd or 3rd), with a little hysteresis so you don't bounce between lines.
- Lower lines get shorter shifts and fewer simmed points.
- The post-game screen shows his view, the change from tonight, your line, your role, +/-, faceoffs, zone time, poke checks and what he said.

**Faceoffs in Be a Pro.**
- A center takes most of his line's draws. When a linemate is winning more, the linemate takes some.
- A winger takes the occasional draw on the power play or penalty kill.
- A winger who wins draws (faceoff 70+, or 55%+) gets asked to move to center: MOVE TO CENTER or STAY ON THE WING.
- A center whose draws fall under 40% (or whose coach loses patience) for a few games goes back to the wing, and a linemate gets his shot.

**Skating.** Skating and edges level about half a point a game now, so four games land around 52-53.

**Gear shop.** There are now six categories:
- Curve: new WRIST curve (+wrist power, −slap) and PLAYMAKER curve (+passing, +deking, worse shooting).
- Shaft (new): HOLLOWED (+accuracy, −power) and REINFORCED (+power, −touch).
- Helmet: FIBERGLASS and NO VISOR.
- Skates: PADDED and LIGHT.
- Chest (new): LIGHTWEIGHT, ARMORED and HYBRID FLEX.

**Perk descriptions.** The Be a Pro perk list now says what each perk does, at your tier or at Bronze. The UT card viewer spells out each card's perks.

**Rules: offsides, icing, penalties.** All three can be switched on or off. The toggles are in Settings from the main menu, in Be a Pro's Settings app and in Ultimate Franchise's new SETTINGS item, never in the pause menu.
- Offsides is new. If an attacker is over the blue line before the puck, play stops and the faceoff is at the neutral-zone dot outside that line. The puck carrier is fine. If the puck pops out and straight back in within 2.5 seconds, play goes on.
- CPU skaters hold up at the line and tag up, and they don't pass to a man who's offside.
- About 1.8 offsides are called per game. Goals per game: 4.64 at 50 OVR, 5.01 at 70 OVR.

## Round 5: the penthouse, bathrooms, the radio, your own music

**Your own music, without rebuilding the VPK.**
- Copy MP3s to `ux0:data/GoalieSimNative/music/` on the memory card (VitaShell over USB or FTP). Create the `music` folder if it isn't there.
- Name each file `Artist - Title.mp3` and the popup shows the artist and title. Without the " - ", the file name is the title.
- The songs join the soundtrack's shuffle on the next launch. The popup shows elapsed time only, since their length isn't listed anywhere.
- The packed soundtrack (`assets/music/soundtrack`, `tracks.txt`) still works the same way.

**The radio.** A boombox sits on a stand inside the front door. X on it plays the next song; if music is off in Settings, X turns it on.

**Bathrooms.** Every apartment now has a bathroom at the end of the hall, behind its own door:
- Starter: yellowed tile, a tub with a shower curtain, a cracked mirror and mould.
- Corner unit: clean tile.
- Penthouse: marble, a walk-in shower behind frosted glass with a rain head, and a backlit mirror.
- The towel is in your team's colour.

The bedroom and office doors moved closer to the living room to make room.

**The Penthouse ($60,000).** 58 x 32 ft. A navy-and-quartz chef's kitchen, plus two more front windows. The man cave sits beyond an archway in the office, with framed jerseys and your number hanging from the ceiling as a retired banner. The big island has a prep sink, five stools and pendant lights. New buys for the man cave:
- **The bar:** bar cart → oak bar and stools → backlit sports bar with glowing shelves, taps, a beer fridge and neon.
- **Game table:** dartboard → air hockey → tournament pool table.
- **Cave seating:** gaming setup → theater recliners and a big screen → stadium suite with two tiers, a 120" screen and a popcorn machine.

**The bed** can be upgraded in every apartment: metal frame → oak platform bed → king upholstered bed.

**Fixes.**
- The office chair now faces the desk.
- Phone app text is about 10% bigger.
- The FPS box is as wide as its text.
- In a match, players near the puck are still redrawn every frame. The rest are rebuilt every 4th frame (was 3rd), and goalies every 3rd (was 2nd), when not busy.
- The Ultimate Franchise card viewer no longer draws the whole roster (every card and its 3D portrait) behind itself every frame. That was the frame-rate drop that didn't happen on the pack screen.

## Round 6: one build, colours everywhere, new sounds, one-of-a-kind cards

**One build.**
- The cloud build (`.github/workflows/build-vpk.yml`) now makes one VPK, `CHL2026Native.vpk`: the native C++ game on the vitaGL 3D renderer. It installs as "CHL 2026" (title ID GOAL00002, the same app as before).
- Gone: the old JavaScript build (`web/`, `vita/js`, `vita/src`, `vita/CMakeLists.txt`, `vita/cmake`), the vita2d fallback (`cpp/src/platform_vita.cpp`) and `tools/preview_vita.js`.
- `vita/sce_sys` (the LiveArea art) and `vita/assets/font.png` stay, because the build uses them.
- If you upload files to the repo instead of replacing it, delete those folders on GitHub too.

**Colours for everything in the apartment.** Buying (or re-picking) anything in the home store opens a colour picker:
- a row of swatches with a big preview;
- ORIGINAL keeps it as it comes;
- then BUY or USE IT;
- re-colouring something you own is free.

What can be coloured:
- couch, recliner, bed, man-cave seating: fabric;
- entertainment centre, bar: wood;
- TV frame: metal;
- kitchen island: cabinet colours;
- game table: felt or frame;
- every floor you've upgraded: wood or stone tones;
- every wall you've painted: 12 paint colours;
- the counter appliances.

The bathroom and the man cave can be painted too: build mode, look at a wall. Your colours are saved with the career.

**Moving keeps everything.** Furniture, colours, paint, floors, repaired walls, the counter and the junk you threw out all carry over between apartments. A bigger place only adds new things to buy.

**Sounds.**
- The post is a short bright TING.
- The goal horn (your goals) is a truck air horn: two long BRRRRRRRP blasts.
- A wrist shot is a quick SHHHT across the ice.
- A slap shot is a sharp CLAP.

**Cards: every copy is its own.**
- Each card copy has its own serial number ("No. 0347").
- Each copy also gets its own texture over the art (halftone, hatching, ripples or crackle) and its own finish in the frame (glitter, etched lines, a sheen or a pinstripe). Its holo bands sit and slope differently, and its backdrop lights fall differently.
- Worn copies are each worn their own way: different stains, creases, scratches, pin holes, chipped corners, a torn notch, faded ink.
- Wear, grain, stripes and sparkles are now clipped to the card and no longer spill past the border.

## Round 7: goals, bonuses, light switches, cleaner walls

**Be a Pro money.**
- **Performance bonus** every game, simmed or played:
  - AHL: $10 a goal and $5 an assist.
  - NHL: $25 a goal and $10 an assist.
- **All weekly goals done:** +$100 in the AHL or +$250 in the NHL, plus 60 XP.
- **All season goals done:** about 100 games' pay, plus 250 XP.
- Both completion bonuses are paid once per week or season and saved with the career.

**After a game: a GOALS page.** It comes after SKILL PROGRESS. Both columns, the week's goals and the season's, fill up from where they stood before the game. A goal that finishes says DONE!. Each column shows what clearing every goal is worth, and the bottom line lists the performance bonus and any completion bonuses.

**Light switches.** Every room has a plate by its door:
- living room (by the front door, it also runs the hall);
- kitchen (backsplash);
- bedroom;
- office;
- bathroom;
- man cave.

X flips it. Lights start on: with them off, the bulbs go dark, the walls dim and the room loses its lamp light.

**Build mode.** The things you can buy prompt when you're close to them (about two steps), the way the doors do. Walls for paint and drywall work the same. The floor still prompts when you look down at it.

**Walls, done properly.**
- Walls and ceilings are now one flat colour per face. No more blotchy light falloff or seams between wall pieces.
- Every surface is multiplied by a fine, tiling grain texture, so paint, wood and fabric read as real materials.
- Holes in unrepaired walls are irregular: flaking paint, bare drywall paper, a dark ragged hole and a hairline crack wandering off it. Scuffs are soft smudges.

**Other fixes.**
- Marble veins no longer make dark slivers.
- Windows have a wider view behind them, so there's no black gap at the edges when you look at an angle.
- The grime bars across the glass are gone.
- The kitchen's front-wall hole moved off the window frame.
- The wall-mounted TV sits on the wall.

## Build fix (round 7b)

The repo's own workflow still runs `cmake -S vita -B build`, which used to be the JavaScript build. `vita/CMakeLists.txt` is now a small shim that builds the native 3D game from `cpp/` and copies `CHL2026Native.vpk` into `build/`, so that step's artifact upload finds it. `cpp/CMakeLists.txt` now uses `CMAKE_CURRENT_SOURCE_DIR` and `CMAKE_CURRENT_BINARY_DIR`, so it builds both on its own and as part of the shim.

## Round 8: menus with polish, and a 3D hero

**Main menu.**
- The big panel shows a real 3D player model on a lit stage:
  - **Be a Pro:** your player, in your current team's jersey and number;
  - **Ultimate Franchise:** the best card on your roster;
  - **otherwise:** the best player of the quick-play team you played last as;
  - with no save at all, a generic CHL player.
- He turns slowly and cycles through poses (stride, slapshot wind-up, burst, poke, glide; goalies through their stances). Sweeping spotlights, out-of-focus arena lights, his giant number behind him and his reflection on the ice complete the stage.
- The menu rows are glass cards: a coloured edge, a line under each label, a sheen across the focused one and an animated chevron.
- A "CHL WIRE" ticker scrolls your saves' headlines and tips.
- A slow light sweeps the background.

**Ultimate Franchise hub.**
- The menu uses the same cards, with a line under each row.
- The top three cards stand on a lit stage in your club's colours, with gold dust rising.

**Settings.**
- A new header with a shimmering accent rule.
- Each setting is a glass card with a coloured icon badge.
- On/off settings are pill switches with sliding knobs. Shot controls (TYPE A / B) and the camera (LOW / HIGH) are two-way segmented choices.
- The focused row lights up.

`ProSlotInfo` now also saves the team's colours, your number and shooting side, so the menu can dress your player. An older save picks these up the next time it's loaded.

## Round 9: minimalist menus
- **Background:** the stripes are gone. A deep navy gradient carries big soft lights (blue, teal, lime, indigo) that drift and breathe, light beams sway in from the top right, and particles rise and twinkle, with the odd out-of-focus bokeh.
- **Main menu:** just words. The selected mode is big and white, with a line about it; the rest sit back in grey, and sizes glide as you move. The 3D player stands free on the right in a glow of his colours, with a pool of light at his feet. A band across the bottom right shows what you'd continue, with a white CONTINUE button. The ticker is gone.
- **Ultimate Franchise hub:** the same text list, and a glow in your club's colours behind the top three cards.
- **Settings:** no boxes, just hairlines between rows. Teal pill switches, and white segmented choices.
- **Buttons everywhere:** flat rounded buttons with a thin outline, and round X / O button hints.
- **Main menu panel:** a soft, semi-transparent rounded square frames the player and the continue band; the whole square is the tap target, and its outline brightens and pulses when it has pad focus.
- **Skater placement:** the menu's skater now stands with his skates on the ice like the goalie (he used to be lifted so his stick blade touched the floor line).
- **Main menu panel:** the small name / team line at the top of the panel is gone; the banner under the player already says it.
- **Volume sliders:** SFX and MUSIC in Settings (and the phone's Settings app) are 0-100 sliders now. With a slider selected:
  - L / R: 10 a press;
  - D-pad or left stick left / right: 1 a press; hold it and after a moment it runs, speeding up the longer you hold;
  - X: mute, and X again goes back to where it was;
  - touch: tap or drag along the track.
  SFX plays a tick as you slide so you can hear the level. 0 shows OFF. The change is saved shortly after you stop. Old saves keep their on/off (on = 100). Turning the radio on in the apartment sets music to 60 if it was off.

## Version 0.6
- The main menu's top right shows just the version, v0.6 (the VPK's version is 00.60 too).
- Be a Pro's line: "Live the life, become an NHL star".
- The highlighted menu option (main menu and the Ultimate Franchise hub) sits in a soft, semi-transparent rounded square whose edge gently pulses, on top of the grow-and-slide.
- Settings: no subtitle; SOUND EFFECTS and MUSIC are separate rows, each just a slider; OFFSIDES, ICING and PENALTIES are spread with equal gaps.

## The UI overhaul (rounded glass everywhere)
- **One look across every menu:** the old square panels and slanted boxes are now rounded, semi-transparent "glass" panels with a hairline edge. Colour edges became slim rounded bars and lines. This covers Ultimate Franchise (slots, hub, shop, inventory, opponents, Road to the Cup, roster, the card details), Be a Pro (slots, new career, draft, contract talks, trades, the post-game screens) and every phone app, plus Quick Play, Practice, naming and the pause screen.
- **Focus:** whatever the pad is on gets a soft rounded box whose edge pulses at the same brightness as the main menu's right panel. The old red rectangle and arrow are gone. The main menu and Ultimate Franchise lists use the same box.
- **Pause screen:** the menu background, white pill for the selected tab, and a rounded score chip.
- **Transitions:** the slanted wipe is now a fade to deep navy with a glow of the mode's colour.
- **Ultimate Franchise:** the toast is a floating pill. Opponent cards have a rounded block in the club's colours.
- **Main menu:** D-pad left from the right panel goes back to BE A PRO, at the top. ULTIMATE FRANCHISE shrinks to fit inside its box when selected.

## Plus / minus and the coach in the phone
- **Performance app:** the season's PLUS / MINUS, green when positive and red when negative, in a 5 x 2 grid of tiles. Live games count it at even strength (power-play goals don't). Simulated games give you a + for each of your own points, and the rest of the goals for and against by your share of the ice. It's saved with the season; older saves start it at 0.
- **GM Connect (Office):** a COACH'S APPRECIATION meter (0-100) under Performance and Loyalty. Under it are his mood (ON THIN ICE / WANTS MORE / LIKES WHAT HE SEES / TRUSTS YOU / LOVES YOUR GAME), how much it moved last game, your line and center or wing. His last word after a game shows in the Inbox.

## 3D everywhere, and league ranks
- **The last 2D players are gone.** The draft-night pick and the Career Over screen show your player in 3D, in your team's sweater and number, with a soft light on the ice. The old Be a Pro hub art and its head-and-shoulders avatar are 3D too, clipped to the frame (`model3D`, cached per look and pose). Ultimate Franchise card art and the main menu hero were already 3D.
- **In-game:** the "classic 2D" top-down view option is removed from the pause settings. Every game is in 3D, and old settings files are switched to 3D on load.
- **Performance app ranks:** each of the ten tiles has a chip with your rank in your league (e.g. "23RD IN AHL", "LEADS THE NHL"). It's gold in the top 10 and green in the top 50, ranked against every skater in your league. Goals and assists use the league's real tallies. The other stats aren't tracked for other players, so they're estimated from each player's goals, assists, quality and team record, with a fixed per-player variation.

## Teammates text you, My Team, and a clarity pass
- **Messages:** after a game you played, a teammate may text you:
  - **Praise** after a big night: two goals, a 3-point night, +2 or better, or a winning point. The odds are about 70% after a great game and 20% after a quiet win with a point.
  - **A scolding** after a rough one: lots of penalty minutes, -2 or worse, no shots, or a flat loss.
  - **Three answers:** humble, cocky or a joke (or own it, push back, or offer an extra skate). Each moves your chemistry with him (+5 to -6), and he answers back.
  - **Layout:** conversations are on the left with a green dot when one is waiting. The chat is on the right, with your chemistry with him. The app icon shows how many texts wait for an answer. Texts and chemistry are saved (the last 40 texts).
- **My Team (new phone app):**
  - **The coach:** his appreciation meter, his mood and last-game change, your line (and center or wing) and a **progress bar to the next line**. It also says roughly what coach appreciation gets you there at your overall, and quotes his last word.
  - **Team chemistry:** your average with the roster, plus every teammate (goalies too) with a bar and a number, best first. Answering texts builds it. There's more to come here.
  - The coach meter moved here from GM Connect.
- **Clarity pass:** the main menu player is now sized so his stick blade stays inside his frame too. It can't reach the CONTINUE band's text in any skater or goalie pose, and the faint ice reflection under him on the menu is gone. The draft and Career Over players were re-placed earlier so nothing touches the text. Every pose was checked on screen.

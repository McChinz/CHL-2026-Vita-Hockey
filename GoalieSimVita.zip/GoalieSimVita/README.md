# CHL 2026 - v0.1 (PS Vita build)

This folder turns the web game into a PS Vita homebrew app (`CHL2026.vpk`).

**The game itself is not rewritten.** `web/goalie.html` is the same file as the browser
version and is the only place gameplay lives. At build time its `<script>` is extracted and run on
the Vita by the QuickJS JavaScript engine. A small compatibility layer draws everything with vita2d.
So any change you make to the web version (or ask Claude to make) carries over: replace
`web/goalie.html`, rebuild, reinstall.

```
web/goalie.html            the game (edit this)
vita/src/main.c            native host: QuickJS + vita2d + touch/buttons + save files
vita/js/vita_shim.js       browser layer: Canvas 2D, pointer events, localStorage, rear touch
vita/js/font_metrics.js    generated with the font atlas
vita/assets/font.png       text atlas (DejaVu Sans Bold)
vita/sce_sys/              home-screen icon and LiveArea art
vita/CMakeLists.txt        build script; produces build/CHL2026.vpk
tools/                     font/LiveArea generators and a desktop preview
.github/workflows/         cloud build (no local SDK needed)
```

## Getting the .vpk

### Option A – build in the cloud (nothing to install)
1. Create a GitHub repository and upload this whole folder (keep the `.github` folder).
2. Open the **Actions** tab. The "Build VPK" workflow runs on every push (or press *Run workflow*).
3. When it finishes, download **CHL2026-vpk** from the run's *Artifacts* section and unzip it.

### Option B – build on your computer
1. Install VitaSDK (Linux, macOS, or Windows via WSL): https://vitasdk.org
   `export VITASDK=/usr/local/vitasdk` and `export PATH=$VITASDK/bin:$PATH`
2. Make sure the libraries are present: `vdpm libvita2d freetype libpng zlib libjpeg-turbo`
3. From this folder:
   ```
   cmake -S vita -B build
   cmake --build build -j4
   ```
   The first configure downloads QuickJS (`quickjs-2024-01-13`). Offline? Download it once and pass
   `-DQUICKJS_DIR=/path/to/quickjs-2024-01-13`.
4. Result: `build/CHL2026.vpk`

### Installing on the Vita
Requires a Vita running HENkaku/Ensō with VitaShell. Copy the `.vpk` to `ux0:` (USB or FTP in
VitaShell), select it in VitaShell, and install. The bubble is called **CHL 2026** (title ID `GOAL00001`).

## Be a Pro career
- **32 real teams** in four divisions (Atlantic, Metropolitan, Central, Pacific) with their real
  colours. Each team carries its 9 best skaters and 2 goalies from the 2026-27 rosters (summer
  2026 trades and signings included). Salaries are random on every new save; draft classes are
  always made-up players.
- **80-game season**, then a **16-team bracket**: top 3 in each division + 2 wild cards per
  conference, East on the left and West on the right, best of 3 every round.
- **Three lines of three.** Lines change every other faceoff and every period (and on the fly
  after a long shift). As a forward you center every line and your wingers rotate.
- **Two goalies per team** split the starts. As a goalie you can be the backup some nights:
  sim the game or train first, then watch from the bench.
- **Office** (hub menu): contract and pay, extensions in the final year, no-trade clause
  requests, trade requests (pick up to 10 teams, you move in a week if one can fit you under the
  cap), and trade offers you can accept or reject when you have a no-trade clause. When your
  contract expires you must sign before your next game, or walk into free agency. Bigger
  contracts pay more cash per game.
- **Injuries**: rare for skaters (you included as a forward), with a minor-league call-up filling
  in. A very rare broken back ends a career for good.
- **20 seasons** (age 20 to 40).
- **Gear shop**: stick curve and length, helmets and skates for forwards; pads, masks, skates
  and gloves for goalies. Every piece costs cash and moves your ratings up and down.
- Saves from the old 24-team version carry over: your player, ratings, cash, age and titles move
  into the new league.

## Positions
Be a Pro asks for a position after you name your player. Both play the same top-down 3v3 game
(three periods, overtime, shootout) with the same league, contracts, Office and upgrades.
- **Forward**: you center every line. Ratings: speed, edge work, shooting, passing, stickhandling,
  deking, faceoffs, checking, stamina.
- **Goalie**: you are in the net for your team (drafted into one of its two goalie spots). When
  the other team crosses centre ice the camera cuts to a goalie cam behind your net and you and the
  net turn see-through so you can read the shot. Ratings: reflexes, stamina, recovery, glove, leg
  pads, chest, blocker. What you see is your hitbox: the glove, blocker, pads and body drawn on
  screen are exactly what stops the puck.

### Forward controls
| | Vita | Phone (touch) |
|---|---|---|
| Skate | left stick | drag left thumb |
| Aim + shoot (with puck) | hold right stick to aim/charge, let go to shoot | drag right thumb, let go |
| Quick shot | SQUARE | - |
| Pass (with puck) | X (aims toward your left-stick direction) | tap right side |
| Call for the puck | X / O while a teammate has it | tap right side |
| Body check (no puck) | flick right stick | drag right thumb |
| Poke check | X next to the puck carrier | tap right side |
| Pause | START | pause button |

### Goalie controls
| | Vita | Phone (touch) |
|---|---|---|
| Slide left / right | left stick | drag left thumb |
| Glove snap (top corner, glove side) | L | GLOVE button |
| Blocker snap | R | BLOCKER button |
| Drop the left / right pad | right stick left / right | drag right thumb left / right |
| Butterfly | right stick down | drag right thumb down |
| Get back up | let go of the right stick (RECOVERY sets the speed) | let go |
| Puck in the glove: pass | X (left stick picks the teammate) | PASS button |
| Puck in the glove: cover | O or SQUARE (or wait 3 seconds: faceoff) | COVER button |
| Pause | START | pause button |

GOALIE ASSIST (Settings, on by default) squares you up to the puck when the left stick is centred
on Casual and Standard.

### Menus
- D-pad or left stick moves, X selects, O goes back.
- L / R switch tabs on Upgrades and the Gear Shop.
- SQUARE deletes the highlighted save file (asks first).

### Other buttons
- **Hold SELECT**: performance readout (FPS and script time per frame).
- **SELECT + START**: quit the app.

Stick dead zone: `STICK_DEAD` at the top of `vita/js/vita_shim.js`.

## Performance
The shim caches layers that don't change from frame to frame (rink, net, skaters waiting for the
puck, glove/blocker shapes, scoreboard, stamina bar) and replays them instead of rebuilding them.
Game code marks those layers with `cached(key, fn)`. On the web it just calls `fn()`.

## Saves and logs
Saves live in `ux0:data/GoalieSim/goalie4.json`, the same data the browser keeps in localStorage.
If the game ever hits a script error it shows the message on screen and writes it to
`ux0:data/GoalieSim/log.txt`. Send that text back and it can be fixed quickly.

## Making changes
- **Gameplay, UI, balance**: edit `web/goalie.html` (or drop in a new version), then rebuild.
- **App name, title ID, version**: top of `vita/CMakeLists.txt`.
- **Icon / LiveArea art**: replace the PNGs in `vita/sce_sys/`. Keep the sizes (128×128,
  840×500, 280×158) and save them as 8-bit indexed PNGs. `tools/make_livearea.py` regenerates the defaults.
- **New characters in text** (accents, symbols): add them to `CHARS` in `tools/make_font.py` and run it.
- **Preview without a Vita**: `node tools/preview_vita.js && python3 tools/render_frames.py`
  runs the Vita JavaScript layer on your computer and saves screenshots to `preview_out/`.

## Notes
- Built for the 960×544 screen. The game lays itself out for that size automatically.
- CPU is set to 444 MHz while running.
- Text uses a bundled DejaVu Sans Bold atlas (license in `tools/DejaVu-LICENSE.txt`). Font
  weights from the web version all render in this one weight.

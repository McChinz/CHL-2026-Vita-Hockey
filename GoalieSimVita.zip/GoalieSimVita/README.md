# CHL 2026 - v0.1 (PS Vita build)

This folder turns the web game into a PS Vita homebrew app (`CHL2026.vpk`).

**The game itself is not rewritten.** `web/goalie.html` is the same file as the browser
version and is the only place gameplay lives. At build time its `<script>` is extracted and run on
the Vita by the QuickJS JavaScript engine. A small compatibility layer draws everything with vita2d.
So any change you make to the web version (or ask Claude to make) carries over: replace
`web/goalie.html`, rebuild, reinstall.

```
web/goalie.html            the game (edit this)
vita/src/main.c            native host: QuickJS + vita2d + touch/buttons + save files
vita/js/vita_shim.js       browser layer: Canvas 2D, pointer events, localStorage, rear touch
vita/js/font_metrics.js    generated with the font atlas
vita/assets/font.png       text atlas (DejaVu Sans Bold)
vita/sce_sys/              home-screen icon and LiveArea art
vita/CMakeLists.txt        build script; produces build/CHL2026.vpk
tools/                     font/LiveArea generators and a desktop preview
.github/workflows/         cloud build (no local SDK needed)
```

## Getting the .vpk

### Option A – build in the cloud (nothing to install)
1. Create a GitHub repository and upload this whole folder (keep the `.github` folder).
2. Open the **Actions** tab. The "Build VPK" workflow runs on every push (or press *Run workflow*).
3. When it finishes, download **CHL2026-vpk** from the run's *Artifacts* section and unzip it.

### Option B – build on your computer
1. Install VitaSDK (Linux, macOS, or Windows via WSL): https://vitasdk.org
   `export VITASDK=/usr/local/vitasdk` and `export PATH=$VITASDK/bin:$PATH`
2. Make sure the libraries are present: `vdpm libvita2d freetype libpng zlib libjpeg-turbo`
3. From this folder:
   ```
   cmake -S vita -B build
   cmake --build build -j4
   ```
   The first configure downloads QuickJS (`quickjs-2024-01-13`). Offline? Download it once and pass
   `-DQUICKJS_DIR=/path/to/quickjs-2024-01-13`.
4. Result: `build/CHL2026.vpk`

### Installing on the Vita
Requires a Vita running HENkaku/Ensō with VitaShell. Copy the `.vpk` to `ux0:` (USB or FTP in
VitaShell), select it in VitaShell, and install. The bubble is called **CHL 2026** (title ID `GOAL00001`).

## Be a Pro career
- **32 real teams** in four divisions (Atlantic, Metropolitan, Central, Pacific) with their real
  colours. Each team carries its 9 best skaters and 2 goalies from the 2026-27 rosters (summer
  2026 trades and signings included). Salaries are random on every new save; draft classes are
  always made-up players.
- **80-game season**, then a **16-team bracket**: top 3 in each division + 2 wild cards per
  conference, East on the left and West on the right, best of 3 every round.
- **Three lines of three.** Lines change every other faceoff and every period (and on the fly
  after a long shift). As a forward you center every line and your wingers rotate.
- **Two goalies per team** split the starts. As a goalie you can be the backup some nights:
  sim the game or train first, then watch from the bench.
- **Office** (hub menu): contract and pay, extensions in the final year, no-trade clause
  requests, trade requests (pick up to 10 teams, you move in a week if one can fit you under the
  cap), and trade offers you can accept or reject when you have a no-trade clause. When your
  contract expires you must sign before your next game, or walk into free agency. Bigger
  contracts pay more cash per game.
- **Injuries**: rare for skaters (you included as a forward), with a minor-league call-up filling
  in. A very rare broken back ends a career for good.
- **20 seasons** (age 20 to 40).
- **Gear shop**: stick curve and length, helmets and skates for forwards; pads, masks, skates
  and gloves for goalies. Every piece costs cash and moves your ratings up and down.
- Saves from the old 24-team version carry over: your player, ratings, cash, age and titles move
  into the new league.

## Ultimate Franchise
A second mode on the main menu with three save files of its own.
- **Start**: name your team. You get the benchwarmer set (the 9 lowest-rated skaters and the 2 lowest-rated
  goalies in the league, all WORN) and 500 coins.
- **Cards**: every player from all 32 teams plus 16 retired legends and 4 legend goalies. Every card has
  the same ratings as the career modes (12 skater ratings or 7 goalie ratings), built from that player's
  own strengths and weaknesses. Rarity shifts every rating a little: WORN -4, COMMON +0, UNCOMMON +1, RARE +2,
  EPIC +4, LEGENDARY +6, full-art SECRET +10 (max 99) - big jumps come from lucky pulls of star players, and higher rarities also stretch the player's
  strengths further. Legends only show up at EPIC and above, or in the Legends pack.
- **Upgrade**: 3 spare copies of the same player at the same rarity raise a card one rarity (WORN to
  COMMON and so on). The card keeps its lineup spot. Pick the card in the roster, then UPGRADE.
- **Examine**: tap and hold any card (roster, hub, a freshly opened pack) to flip it over and see every
  rating. The card menus have EXAMINE too, and TRIANGLE examines the highlighted card on the Vita.
- **Lineup slots**: picking a filled slot on the left opens SWAP PLAYER / EXAMINE / UPGRADE / QUICK SELL.
  SWAP jumps to the cards on the right and keeps the slot highlighted (REPLACING) so you can see who goes
  out; pick the new card and it goes straight in. O (or CANCEL) backs out. Quick-selling a lineup card leaves
  its slot empty; an empty slot goes straight to picking a card.
- **Salary cap**: every card has a salary (higher OVR and rarity cost a lot more) and your 11-man lineup has
  to fit under your cap ($24M to start). Buy more cap space in the SHOP (+$2M each, every raise dearer).
  The payroll shows in the TEAM box on MY ROSTER; salaries show on every card.
- **Shop**: Entry 400 coins / 6 cards (mostly WORN, nothing above RARE), Standard 1,000 / 5, Premium 2,500 / 4
  (one RARE+), Elite 6,000 / 3 (one EPIC+), Legends 14,000 / 1 legend. Higher tiers give fewer cards but better
  odds at rare cards and star players. Bought packs go to your INVENTORY; open them there whenever you like.
- **Roster**: 11 slots, three lines of LW-C-RW plus a starting and backup goalie. You play the center
  of whichever line is on the ice. AUTO BEST fills it, SELL DUPLICATES quick-sells spare copies. Your
  own players' goals and your goalies' save % and record are tracked (Road to the Cup keeps its own numbers per run).
- **Games**: pick an EASY / EVEN / HARD CPU team. EASY is never rated above you, EVEN is within 2 OVR,
  HARD is always above you (by a little or a lot). Teams, names and colours are random. Win the reward
  (140 / 220 / 360), a quarter of it for a loss, plus 10 coins a goal. Quitting pays nothing.
- **Road to the Cup**: a short season from the Ultimate Franchise menu. 16 teams in two divisions of 8,
  20 games (division rivals twice, 6 from the other division), the top 4 of each division play single-game
  quarterfinals, semifinals and a Cup Final. Your lineup locks when the run starts and stays locked until it
  ends (roster edits in the meantime only count for PLAY GAME). Win it and 3 Standard packs go to your INVENTORY, where you
  open them for free.
- **Continue**: the big panel on the main menu loads the save you played last (career or Ultimate Franchise).

## Matchup screen
Every game opens with both teams, their records and the starting lineups: goals for each skater, save % and
record (or games played) for each goalie. Be a Pro uses the real league numbers, Ultimate Franchise tracks your
own players (the CPU side is made up for one-off games and comes from the standings in Road to the Cup).
X or a tap continues to the walk-out. There is a short pause between the transition and the opening faceoff,
and the referee is always set at the dot before the puck drops.

## Goals
In every mode the puck carries into the net, the mesh bulges and the puck slides around in there, the
scoring team celebrates (confetti in their colours), then a short GOAL screen with the new score covers
the reset to the faceoff. A goal up high knocks the water bottle off the top of the net and onto the ice;
the trainer puts it back before the next faceoff.

## Sound
Every sound is synthesized by the game itself - no sample files. On the Vita the native layer (vita/src/main.c)
builds them in C on its own audio thread at start-up and mixes up to 24 at once; in a browser they're built in
JavaScript and play through WebAudio after your first tap.
- **Puck**: slap shots crack, wrist shots snap, passes and catches tock, saves thud, posts ring.
- **Skates**: a stride sound for you and the skaters near the camera, a spray of ice on hard stops.
- **Hits**: a body / board thud and a grunt from the player who gets hit (three different voices).
- **Crowd**: a murmur under every game that swells when the home team presses; a cheer when the home team
  scores, boos when it gets scored on.
- SETTINGS > SOUND turns it all off.

## Perks
Every player has two perk slots: slot 1 opens at **78 OVR**, slot 2 at **89 OVR**. Each perk has three tiers -
**BRONZE / SILVER / GOLD** - set by one rating (the numbers below are B / S / G); a higher tier does much more.
- **Not everyone carries one.** CPU players and cards get perks by a fixed roll per player (elite players are
  likelier to fill both slots), then the perks they lean toward among the ones their ratings reach. Cards roll per
  rarity, so two versions of a player can differ. In a fresh league roughly a third of skaters carry a perk.
- **Over the seasons** (Be a Pro) the whole league develops or declines with age and potential, and perks follow the
  ratings: players earn perks, move up a tier, or lose them. The biggest changes make the headlines (your team first).
- **Skater perks have a few uses a game** - 3 at Bronze, 4 at Silver, 5 at Gold (Freight Train: once a game) - and
  only fire when they matter: a long pass or a feed into the slot, a wrister in the zone, a one-timer in range, a
  poke the perk actually won, a hit that would have flattened him. **Goalie perks recharge** on a cooldown (shorter
  at higher tiers). A few perks are always on.
- When a perk fires, the player flashes white and its name pops up over his head, edged in its tier colour. Your
  perks sit beside your stamina bar with their uses left. Cards show a badge per perk (ringed in its tier colour),
  the card back names them with their tier, and the pre-game lineup shows everyone's badges.
- Be a Pro: buy perks with XP (UPGRADES > PERKS) - a new perk is BRONZE. **UPGRADE** it one tier at a time, each
  costing 1.5x the last (SILVER 1.5x the perk's price, GOLD 2.25x), and only once your rating reaches that tier. Your
  tier is the lower of what you've bought and what your rating supports. The ladder shows tiers you own (filled),
  tiers your rating reaches (outlined) and tiers still out of reach (grey).

| Skater perk | Rating (B/S/G) | Uses | Effect by tier |
|---|---|---|---|
| ONE TOUCH WONDER | PASSING 80/88/95 | 3/4/5 | long passes, passes through traffic, feeds to the slot: 60% tighter -> perfect, bent onto the stick |
| ONE TIMER KING | SLAP POWER 80/88/95 | 3/4/5 | one-timer in range +15/25/35% power; 40/70/100% of saves kick to a teammate |
| SPEED DEMON | SPEED 82/89/96 | 3/4/5 | holding sprint with (or chasing) the puck builds to +10/16/22% |
| FLICK OF THE WRIST | WRIST POWER 84/90/96 | 3/4/5 | wristers in the zone +15/25/35% speed and harder to read |
| EYES ON THE PRIZE | STICKHANDLING 80/88/95 | 3/4/5 | poke checks +15/25/35% (a use counts only when it wins the puck) |
| FREIGHT TRAIN | CHECKING 82/89/96 | 1 | 6/10/15% of hits on the carrier knock him out (3 on 2 for 30s) |
| IMMOVABLE | POISE 82/89/96 | 3/4/5 | 50/75/100% chance to stay up on a big hit; holds the puck more |
| IRON LUNGS | STAMINA 82/89/96 | always on | drain -15/23/30%, bench rest +10/20/30% |
| DANGLER | DEKING 82/89/96 | 3/4/5 | 60/80/100% of mid-deke pokes miss; dekes recharge faster |

| Goalie perk | Rating (B/S/G) | Recharge | Effect by tier |
|---|---|---|---|
| FLASH OF LEATHER | GLOVE 84/90/96 | 75/55/40s | glove saves held 60/80/100% (always on); steals a glove-side goal 40/55/70% |
| ROBBERY | REFLEXES 84/90/96 | 90/65/45s | robs a goal with a desperation save 35/50/65% |
| WALL OF ST. PAUL | CHEST 82/89/95 | always on | chest saves +3/5/8%, smothered 70/85/100% |
| QUICK RESET | RECOVERY 82/89/95 | always on | slow-down between saves -40/70/100% |
| IRON MAN | STAMINA 82/89/95 | always on | tires 20/35/50% slower |
| FIVE-HOLE LOCK | LEG PADS 82/89/95 | always on | five-hole shut 50/75/100% more; low shots +2/3.5/5% |
| CROSSHAIR | - | - | yours only: 35% of shots show where they will cross your crease |

## On the ice
- Poke checks and body checks knock the puck loose and send it a good way off. A big hit puts a player
  down on the ice for a second or two before he gets back up. Rammed into the boards, now and then he goes
  right over them (out 9 seconds) or through the glass (out 14 seconds) and his team plays a man down.
- **Shots** are on the right stick only: a quick flick up is a wrist shot, pull back then push up is a slap shot,
  easing back to centre is a fake. The left stick aims; the height comes from the shooter's accuracy.
- **Deke (SQUARE)**: a tap pulls the puck out wide (toward the left stick, or away from the nearest defender) and back.
  Hold it for a toe drag: the puck is drawn back in across your body and stays there while you hold, and for a
  second after you let go so you can get your thumb to the shooting stick. Poke checks mostly miss a deked puck, a
  goalie close by may follow it out wide, and a shot off a toe drag is harder to read. Good CPU stickhandlers deke too.
- **Saucer pass (TRIANGLE)**: lifted over the sticks in the lane and landing about on the tape (a little less
  accurate than a flat pass). CPU passers lift it when a stick is in the lane.
- **Boards and glass**: a puck rimmed in flat keeps its pace around the corner; one that hits square comes back
  out; the boards are a little live. A puck that hits the glass comes off at an odd angle and drops. The glass is
  taller now and sways when a player is hit into it (or a high puck hits it).
- **Rebounds**: a goalie's rating for the part that stopped it is his control. Weak or tired goalies leave it in
  the slot; sharp ones steer it away to the corner.
- **Game feel**: a big hit holds the game for a split second and shakes the screen; posts shake it a little.
  Hard stops throw up a spray of snow (hits don't). The puck always casts a shadow, which drifts and spreads as it
  rises. Goals: the goal light flashes, camera flashes go off in the stands, the home crowd jumps section by
  section, and the scorer bangs the glass.
- **Pressure ring**: a ring under each goalie (your own goalie's ring shows your stamina when you're in the net), green for what's left and black for what's been
  drained. Every shot drains it, it refills while the puck is out of his end. Under a quarter it flashes softly
  red; when it empties the whole ring pulses red and he moves and reacts slower until it refills.
- A poke check on a player winding up a slap shot almost always strips the puck.
- **CPU skaters** read the ice before they shoot or pass: shot quality (distance, angle, bodies in the lane,
  where the goalie is), passing lanes (never through a man, never to a covered man, no soft passes across
  their own slot), and who's in the better spot. They one-time passes in the slot, aim for the bigger gap
  high or low depending on the goalie's weak spot, and only wind up a slap shot with room around them.
- **Ice tilt**: a team that's behind digs in - a step quicker, shooting a bit more, and its goalie a little
  sharper when it's 2-3 down. Blowouts still happen.
- **Pulling the goalie**: late in the 3rd, a team down one (or down two, if the coach likes its chances) pulls
  its goalie for a 4th skater - usually on the fly once it has the puck past centre. Yours too, as a forward.
- **Puck physics**: shots fly a real arc under gravity (low shots skim the ice, high ones lift over the pads),
  saucer passes sail over sticks, and the puck hops off the boards, posts, pads and shin pads, and wobbles on its edge for a
  moment afterwards (it snakes a little and dies faster). A puck in the air can't be picked up until it lands.
- **Scoring**: about 6 goals a game on average; 2-3 against great goalies, 7-9 against weak ones.
- **Poise** (PHYSICAL): how well a skater takes a hit. Hits weigh the checker's CHECKING against the target's
  POISE. Every skater has a height and weight; big men check harder and have more poise.
- **Skate marks**: skaters carve the ice as they go (hard stops spray a wider mark); the ice is fresh again at
  every faceoff.
- **Shot controls**: the shooting stick is the only shot control (no setting). Auto aim (in the attacking zone only) keeps stick shots between
  the posts; outside the zone you can clear it wherever you point. The crosshair shows where it's going (bigger =
  less accurate), green when there's lots of net, red when it's into the goalie. A wild high shot can go over the net.
  No sprinting or spin dekes while a shot is loaded, and loading a slap shot you just glide.
- **Shot fakes**: ease the stick back instead of snapping it - goalies with a low SHOT READ bite and leave the net
  open for a moment. Goalies also need a moment between saves (RECOVERY): low recovery can't chain saves, and a
  diving save costs them more.
- **Goal coins** (Ultimate Franchise): each goal against takes back one goal's coins (never the win / game pay,
  never below zero).
- **Loading screens** between menus and games hold a moment and clear out the section you left.
- **Energy and line changes**: every skater has a ring under him - green is energy left, black is spent, and it
  flashes red when he's done. A shift drains it (sprinting much faster; a higher STAMINA rating drains slower) and it
  does NOT come back on the ice - only on the bench, slowly, after a short wait (a line that stays out gets a small
  breath at the faceoff). Lines change by themselves at stoppages, 1 > 2 > 3, and line 1 only comes back once it is
  fully rested; a small note on the right shows which line came out. Your stamina bar works the same way.
- **Bench changes**: when your energy drops low (any skater mode) a pulsing green LINE CHANGE circle appears on the
  ice by your bench (an arrow at the screen edge points to it when it's out of view). Skate into it and the next line
  comes over the boards on the fly - in Ultimate Franchise you take over the new center; in Be a Pro your wingers change
  and you get a real breather. A teammate carrying the puck hands it to the man replacing him.
- **Faceoffs**: every stoppage has the draw mini game. There's always at least a second of GET READY before the ring
  appears, presses before it shows are ignored (so mashing X through a save or goal can't lose the draw), and if
  you're on the ice you take the draw.
- **Penalty kills**: shorthanded teams clear the puck down the ice and only attack on a clean break.
- **Hot starts**: now and then a CPU goalie is simply on that night and stops more.
- **One-timers**: CPU skaters fire a pass straight away when they catch it in a good spot.
- **Stop on a dime** is a hard slow-down; only elite skaters come to a full stop.
- **Practice**: GOALIE (as before), SKATING (timed gates and cones), SHOOTING (from centre ice at a goalie; rebounds
  count; a goal or a cover resets you), AIM (four corner targets, low and high). Skater drills use a 50, 70 or 99 OVR
  skater; best times / scores are kept while the game is running.
- Goalies reset fully at every faceoff.
- **CPU goalies** get set when the puck is in their end, shuffle side to side, and go for every shot: glove
  or blocker flashes, butterfly (knees together, pads flat out, like yours), kick saves, body saves, a sprawling dive when it's past them, poke checks on
  a man cutting in alone, and covering the puck.
- **Faceoff transition**: after every goal and every whistle (saves, icing, penalties, period breaks) a
  FACEOFF transition covers the reset, then a short beat before the draw. The referee is always set at the dot.
- A referee drops the puck, follows the play along the boards and raises his arm on penalties.
- Soft mirrored reflections under the skaters and the referee, carved skate lines, soft pools of light from the arena lights, sponsor ads along the end and side boards.

## Settings
- **Goalie assist**: your goalie squares up to the puck when the left stick is centred.
- **Auto aim (shots)**: ON keeps stick shots in the attacking zone between the posts. OFF sends them exactly
  where the left stick points.

## Positions
Be a Pro asks for a position after you name your player. Both play the same top-down 3v3 game
(three 2-minute periods, overtime, shootout) with the same league, contracts, Office and upgrades.
- **Forward**: you center every line. Ratings: speed, edge work, shooting, passing, stickhandling,
  deking, faceoffs, checking, stamina.
- **Goalie**: you are in the net for your team (drafted into one of its two goalie spots). When
  the other team crosses centre ice the camera cuts to a goalie cam behind your net and you and the
  net turn see-through so you can read the shot. Ratings: reflexes (how fast pads drop and hands
  get out), strafing (side to side, auto-lock speed), stamina, pressure (less stamina lost per shot),
  recovery (pad to pad, back up), glove, leg pads, chest, blocker (fewer pucks slipping past, better
  rebounds). Every shot that hits you costs stamina and you only get it back once the puck leaves your end. What you see is your hitbox: the glove, blocker, pads and body drawn on
  screen are exactly what stops the puck.

### Forward controls
| | Vita | Phone (touch) |
|---|---|---|
| Skate | left stick | drag left thumb |
| Shots | RIGHT STICK: quick flick up = wrist shot (no wind-up); pull back, then push up = slap shot (ease back to centre = fake). LEFT STICK aims. Height comes from the shooter's ratings | right-thumb drag, same motions |
| Checks | no puck - RIGHT STICK: quick flick up = bump; pull back (you can keep skating), then push up = big hit | right-thumb drag |
| Deke | SQUARE: tap = pull it wide, hold = toe drag (holds 1s after release) | DEKE button |
| Saucer pass | TRIANGLE | SAUCER button |
| Stop on a dime | flick the left stick against the way you're skating | - |
| Block shots (no puck) | L | BLOCK button |
| Spin deke (with the puck) | L | SPIN button |
| Pass (with puck) | X (aims toward your left-stick direction) | tap right side |
| Call for the puck | X while a teammate has it | tap right side |
| Poke check | X next to the puck carrier | tap right side |
| Pause | START | pause button |

### Goalie controls
| | Vita | Phone (touch) |
|---|---|---|
| Slide left / right | left stick | drag left thumb |
| Glove out (top / middle, glove side) | hold L | hold GLOVE button |
| Blocker out (top / middle, blocker side) | hold R | hold BLOCKER button |
| Drop the left / right pad (REFLEXES set how fast) | right stick left / right | drag right thumb left / right |
| Butterfly | right stick down | drag right thumb down |
| Get back up | let go of the right stick (RECOVERY sets the speed) | let go |
| Goalie cam / rink view | D-pad UP (any time) | CAM button |
| Puck in the glove: pass | X (left stick picks the teammate) | PASS button |
| Puck in the glove: cover | O or SQUARE (or wait 3 seconds: faceoff) | COVER button |
| Pause | START | pause button |

GOALIE ASSIST (Settings, on by default) squares you up to the puck when the left stick is centred
on Casual and Standard.

### Menus
- D-pad or left stick moves, X selects, O goes back.
- L / R switch tabs on Upgrades and the Gear Shop.
- SQUARE deletes the highlighted save file (asks first).
- Ultimate Franchise roster: L / R flip pages, SQUARE quick-sells the highlighted card (asks first).

### Other buttons
- **Hold SELECT**: performance readout (FPS and script time per frame).
- **SELECT + START**: quit the app.

Stick dead zone: `STICK_DEAD` at the top of `vita/js/vita_shim.js`.

## Performance
The shim caches layers that don't change from frame to frame (rink, net, skaters waiting for the
puck, glove/blocker shapes, scoreboard, stamina bar) and replays them instead of rebuilding them.
Game code marks those layers with `cached(key, fn)`. On the web it just calls `fn()`.

## Memory
The game runs QuickJS's garbage collector itself at whistles and in menus (`__gc()` in `main.c`), so
collection pauses don't land in the middle of play.

## Saves and logs
Saves live in `ux0:data/GoalieSim/goalie4.json` (careers) and `chl_ut.json` (Ultimate Franchise), the same data
the browser keeps in localStorage.
If the game ever hits a script error it shows the message on screen and writes it to
`ux0:data/GoalieSim/log.txt`. Send that text back and it can be fixed quickly.

## Making changes
- **Gameplay, UI, balance**: edit `web/goalie.html` (or drop in a new version), then rebuild.
- **App name, title ID, version**: top of `vita/CMakeLists.txt`.
- **Icon / LiveArea art**: replace the PNGs in `vita/sce_sys/`. Keep the sizes (128×128,
  840×500, 280×158) and save them as 8-bit indexed PNGs. `tools/make_livearea.py` regenerates the defaults.
- **New characters in text** (accents, symbols): add them to `CHARS` in `tools/make_font.py` and run it.
- **Preview without a Vita**: `node tools/preview_vita.js && python3 tools/render_frames.py`
  runs the Vita JavaScript layer on your computer and saves screenshots to `preview_out/`.

## Notes
- Built for the 960×544 screen. The game lays itself out for that size automatically.
- CPU is set to 444 MHz while running.
- Text uses a bundled DejaVu Sans Bold atlas (license in `tools/DejaVu-LICENSE.txt`). Font
  weights from the web version all render in this one weight.

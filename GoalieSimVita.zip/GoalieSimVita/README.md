# Goalie Sim – PS Vita build

This folder turns the web game into a PS Vita homebrew app (`GoalieSim.vpk`).

**The game itself is not rewritten.** `web/goalie.html` is the same file as the browser
version and is the only place gameplay lives. At build time its `<script>` is extracted and run on
the Vita by the QuickJS JavaScript engine. A small compatibility layer draws everything with vita2d.
So any change you make to the web version (or ask Claude to make) carries over: replace
`web/goalie.html`, rebuild, reinstall.

```
web/goalie.html            the game (edit this)
vita/src/main.c            native host: QuickJS + vita2d + touch/buttons + save files
vita/js/vita_shim.js       browser layer: Canvas 2D, pointer events, localStorage, rear touch
vita/js/font_metrics.js    generated with the font atlas
vita/assets/font.png       text atlas (DejaVu Sans Bold)
vita/sce_sys/              home-screen icon and LiveArea art
vita/CMakeLists.txt        build script; produces build/GoalieSim.vpk
tools/                     font/LiveArea generators and a desktop preview
.github/workflows/         cloud build (no local SDK needed)
```

## Getting the .vpk

### Option A – build in the cloud (nothing to install)
1. Create a GitHub repository and upload this whole folder (keep the `.github` folder).
2. Open the **Actions** tab. The "Build VPK" workflow runs on every push (or press *Run workflow*).
3. When it finishes, download **GoalieSim-vpk** from the run's *Artifacts* section and unzip it.

### Option B – build on your computer
1. Install VitaSDK (Linux, macOS, or Windows via WSL): https://vitasdk.org
   `export VITASDK=/usr/local/vitasdk` and `export PATH=$VITASDK/bin:$PATH`
2. Make sure the libraries are present: `vdpm libvita2d freetype libpng zlib libjpeg-turbo`
3. From this folder:
   ```
   cmake -S vita -B build
   cmake --build build -j4
   ```
   The first configure downloads QuickJS (`quickjs-2024-01-13`). Offline? Download it once and pass
   `-DQUICKJS_DIR=/path/to/quickjs-2024-01-13`.
4. Result: `build/GoalieSim.vpk`

### Installing on the Vita
Requires a Vita running HENkaku/Ensō with VitaShell. Copy the `.vpk` to `ux0:` (USB or FTP in
VitaShell), select it in VitaShell, and install. The bubble is called **Goalie Sim** (title ID `GOAL00001`).

## Controls on the Vita
- **Front touch**: everything the phone version does. Left thumb drives the glove and right thumb
  drives the blocker; tap a pad to drop it; tap menus.
- **Rear touch, left / right half**: drops the left / right leg pad flat.
- **L / R triggers**: also drop the left / right pad.
- **SELECT + START**: quit.

If rear-left and rear-right feel swapped on your unit, set `REAR_SWAP = true` at the top of
`vita/js/vita_shim.js`.

## Saves and logs
Saves live in `ux0:data/GoalieSim/goalie4.json`, the same data the browser keeps in localStorage.
If the game ever hits a script error it shows the message on screen and writes it to
`ux0:data/GoalieSim/log.txt`. Send that text back and it can be fixed quickly.

## Making changes
- **Gameplay, UI, balance**: edit `web/goalie.html` (or drop in a new version), then rebuild.
- **App name, title ID, version**: top of `vita/CMakeLists.txt`.
- **Icon / LiveArea art**: replace the PNGs in `vita/sce_sys/`. Keep the sizes (128×128,
  840×500, 280×158) and save them as 8-bit indexed PNGs. `tools/make_livearea.py` regenerates the defaults.
- **New characters in text** (accents, symbols): add them to `CHARS` in `tools/make_font.py` and run it.
- **Preview without a Vita**: `node tools/preview_vita.js && python3 tools/render_frames.py`
  runs the Vita JavaScript layer on your computer and saves screenshots to `preview_out/`.

## Notes
- Built for the 960×544 screen. The game lays itself out for that size automatically.
- CPU is set to 444 MHz while running.
- Text uses a bundled DejaVu Sans Bold atlas (license in `tools/DejaVu-LICENSE.txt`). Font
  weights from the web version all render in this one weight.

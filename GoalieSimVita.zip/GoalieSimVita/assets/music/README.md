# Music

The game's soundtrack lives in `soundtrack/`. Anything in this folder is packed into the VPK as `app0:music/...`. This README is not packed.

- **`soundtrack/tracks.txt`:** one song per line, written as `file|artist|title|seconds`, for example `staind_mudshovel.mp3|Staind|Mudshovel|282`.
  - The popup shows the artist and title from this file, so the MP3 tags don't matter.
  - The seconds value drives the popup's progress bar.
  - Lines starting with `#` are ignored.
- **When it plays:** the songs play shuffled in all the menus and the apartment. A song never repeats until every song has played.
  - The music fades out when a game starts and comes back with a new song afterwards.
  - Settings > SOUND & MUSIC turns it off.
- **Format:** real MP3s (MPEG layer III, not AAC/M4A renamed to .mp3), 44.1 kHz stereo, no spaces in file names. The current files are 80 kbps so the project zip stays under GitHub's 25 MB browser upload limit.

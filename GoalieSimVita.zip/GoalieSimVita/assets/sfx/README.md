# Sound effects

Put sound effects here. Anything in this folder (and its subfolders) is packed into the VPK as `app0:sfx/...`.

- **Format:** WAV is best for short sounds (16-bit, mono, 22050 to 48000 Hz). Short MP3s also work.
- **Names:** no spaces, e.g. `ui/phone_open.wav`.
- **Folders:** organize however you like, for example `ui/`, `apartment/`, `game/`. Then tell Claude what each one is for.
- **Replacing a built-in sound:** the game's current sounds are made in code (shots, saves, skates, hits, posts, crowd). To replace one, put a file here and say which sound it replaces.

This README is not packed into the game.
